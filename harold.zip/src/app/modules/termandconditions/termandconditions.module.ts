import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TermandconditionsComponent } from './termandconditions/termandconditions.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [TermandconditionsComponent]
})
export class TermandconditionsModule { }
