import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder, FormArray } from '@angular/forms';
import { ServiceService } from 'src/app/Shared/service.service';
import { ActivatedRoute, Router } from '@angular/router';
import { AngularFirestore } from '@angular/fire/firestore';
import { IMyDpOptions, IMyDateModel } from 'mydatepicker';

@Component({
  selector: 'app-edit-activity',
  templateUrl: './edit-activity.component.html',
  styleUrls: ['./edit-activity.component.css']
})
export class EditActivityComponent implements OnInit {
  activityArr = ['Flatwork','Cavelli','Jumps','Trot poles','Lungeing','Trail ride','Trot','Canter']
  editTemplateForm: FormGroup;
  selectWeekArr:any=['1','2','3','4','5','6','7','8','9','10','11','12','13','All'];
  weekArr:any=[];
  dayArr:any=[];
  editactivityForm: FormGroup;
  restDaysArr =  ['Monday','Tuseday','Wednesday','Thursday','Friday','Saturday','Sunday'];
weekArrOne =  ['1','2','3','4','5','6','7']; 
weekArrTwo = ['8','9','10','11','12','13','All'];
weekArray:any=[];
  templateId: any;
  trainingDetails:any=[];
  beDisable: boolean=true;
  constructor(public fb: FormBuilder,public service:ServiceService , public routes: ActivatedRoute , public router: Router, public firestore:AngularFirestore) { 
    this.editTemplateForm = new FormGroup({
      'templateName': new FormControl('',Validators.required),
      'totalWeek': new FormControl('',Validators.required),
    //   'warmup': new FormControl('',[Validators.required,Validators.pattern(/^(0|[1-9][0-9]*)$/)]),
    // 'warmdown': new FormControl('',[Validators.required,Validators.pattern(/^(0|[1-9][0-9]*)$/)]),
    // 'startDate': new FormControl('',Validators.required),
    // 'endDate': new FormControl('',Validators.required)
    })
    this.editactivityForm =  this.fb.group({
      activityData: this.fb.array([])
    });
  }

  ngOnInit() {
    this.routes.params.subscribe(params => {
      this.templateId = params['id'];     
      console.log("template id ===>>",this.templateId)
    });    
    this.getTrainingTemplate();
     this.onDateChanged();
  }


    /**************** Date managing***************/
    public myDatePickerOptions: IMyDpOptions = {
      dateFormat: 'yyyy-mm-dd',
      editableDateField: false,
      openSelectorOnInputClick: false,
      disableSince: { year: 0, month: 0, day: 0 }
    };
    public toDate: IMyDpOptions = {
      dateFormat: 'yyyy-mm-dd',
      editableDateField: false,
      openSelectorOnInputClick: false,
      disableUntil: { year: 0, month: 0, day: 0 }
    };
  
    onDateChanged() {
      let d = new Date();
      let copy1 = this.getCopyOfOptions();
      copy1.disableUntil = {
        year: d.getFullYear(),
        month: d.getMonth() + 1,
        day: d.getDate()
      };
      this.myDatePickerOptions = copy1;
    }
    //Returns copy of myDatePickerOptions
    getCopyOfOptions(): IMyDpOptions {
      return JSON.parse(JSON.stringify(this.myDatePickerOptions));
    }
  
    public onChange(event: IMyDateModel) {
      if (event.formatted) {
        this.beDisable = false
        let d: Date = new Date(event.jsdate.getTime());
        d.setDate(d.getDate() - 1);
        let copy: IMyDpOptions = this.getCopyOfToDateOpt();
        copy.disableUntil = {
          year: d.getFullYear(),
          month: d.getMonth() + 1,
          day: d.getDate()
        };
        this.toDate = copy;
      } else {
        this.beDisable = true
      }
  
    }
    getCopyOfToDateOpt(): IMyDpOptions {
      return JSON.parse(JSON.stringify(this.toDate));
    }
    /*******************Date managing Ends Here**************/

   // Get Training Template List 
   getTrainingTemplate(){
    this.service.showSpinner();
    this.service.getAdminTrainingTemplate().subscribe(res=>{
    var templateList = res.map(item => {        
        return {
          id: item.payload.doc.id,
          ...item.payload.doc.data()
        };
    })   
    this.trainingDetails = templateList.filter(x=>(x['id'] == this.templateId));
    // var date = new Date(this.trainingDetails[0].startDate);
    // var date2 = new Date(this.trainingDetails[0].enddate);
    this.editTemplateForm.patchValue({
      'templateName':this.trainingDetails[0].templateName,
      'totalWeek': this.trainingDetails[0].trainingWeeks,
  //     'warmup':this.trainingDetails[0].warmUpTime,
  //     'warmdown':this.trainingDetails[0].warmDownTime,
  //     'startDate':{
  //       date: {
  //           year: date.getFullYear(),
  //           month: date.getMonth() + 1,
  //           day: date.getDate()
  //       }
  //   } , 
  //   'endDate': {
  //     date: {
  //         year: date2.getFullYear(),
  //         month: date2.getMonth() + 1,
  //         day: date2.getDate()
  //     }
  // }
    });
    this.getWeeks(this.trainingDetails[0].trainingWeeks);
    this.dayArr = this.trainingDetails[0].restDaysArray;
 
    this.weekArr = this.trainingDetails[0].restWeekArray;
    for(var i=0;i<this.trainingDetails[0].trainingActivity.length ; i++)
  {  
    var duration = this.trainingDetails[0].trainingActivity[i].activityDuration
    const control = new FormGroup({
        'activityType': new FormControl(this.trainingDetails[0].trainingActivity[i].activityType,[Validators.required]),
        'activityDuration': new FormControl(duration,[Validators.required]),
        'activityRestDaysArr': new FormControl(this.trainingDetails[0].trainingActivity[i].activityRestDaysArr,),
        'activityRestWeekArr':new FormControl(this.trainingDetails[0].trainingActivity[i].activityRestWeekArr,)
      }); 
      (<FormArray>this.editactivityForm.get('activityData')).push(control);   
  }
 console.log('trainingDetails---->>>', this.trainingDetails ,this.dayArr);

//  ************* Delete the Day which are selected in Rest days****************
this.dayArr.forEach((element,ind) => {
   const index = this.restDaysArr.findIndex(x => x == element);
     this.restDaysArr.splice(index,1);
});
 
    this.service.hideSpinner();
  })
  
}

// Week Selection Functionality
getWeeks(event){
  var data = 1
  this.weekArrOne = [];
  this.weekArrTwo=[];
  var totalWeek = event;
  for(var i= 1; i<=totalWeek;i++){
    this.weekArr.push(String(i));
  }


  
  for(var i= 1; i<=totalWeek;i++){
    this.weekArr.push(String(i));
  }
  console.log('weekArr===>>',this.weekArr);
  if(totalWeek > 7)
  {
    for(var i=1;i<=7;i++){
      this.weekArrOne.push(''+i);
    }
    for(var j=8;j<=totalWeek;j++){
      this.weekArrTwo.push(''+j);
    }
  }
  else{
    for(var i=1;i<=totalWeek;i++){
      this.weekArrOne.push(''+i);
    }
  }
  console.log('weekArr===>>',this.weekArr);
 }

  createWeekarr(val){
    if(!this.weekArr.includes(val)){
      this.weekArr.push(val)
     
    }else{
        var index = this.weekArr.indexOf(val);
        this.weekArr.splice(index,1);
        
      }
      console.log('WeekArr-->>',this.weekArr);
   }
 
   createDayArr(val){
   
     if(!this.dayArr.includes(val)){
       if(this.restDaysArr.length != 1){
     this.dayArr.push(val)

     const index = this.restDaysArr.findIndex(x => x == val);
     this.restDaysArr.splice(index,1);
     console.log('dayArrrr==-->>', this.restDaysArr,val);
    }else{
      this.service.toastErr('Please do not select all the rest days')
    }

   }else{
       var index = this.dayArr.indexOf(val);
       const addDay = this.dayArr[index];
       this.dayArr.splice(index,1);

       this.restDaysArr.splice(index, 0, addDay);
        console.log('dayArr-->>',this.dayArr,addDay,index);
     }
  
   }

   // Activity Related
   onActivityData() {
    const control = new FormGroup({
      'activityType': new FormControl('',[Validators.required]),
      'activityDuration': new FormControl('',[Validators.required]),
      'activityRestDaysArr': new FormControl([]),
      'activityRestWeekArr':new FormControl([])
    });
    (<FormArray>this.editactivityForm.get('activityData')).push(control);
    // debugger;
    // console.log(this.editactivityForm.value.activityData)
  }

  removeActivity(index) {

    let control = <FormArray>this.editactivityForm.controls.activityData;
    control.removeAt(index)

  }

  selectedDay(day, i) {
    if(this.editactivityForm.value.activityData[i].activityRestDaysArr.includes(day))
      this.editactivityForm.value.activityData[i].activityRestDaysArr.splice(this.editactivityForm.value.activityData[i].activityRestDaysArr.indexOf(day), 1 );
    else
      this.editactivityForm.value.activityData[i].activityRestDaysArr.push(day);
  }

  selectedWeek(week, i) {
    if(week == 'All') {
      this.editactivityForm.value.activityData[i].activityRestWeekArr=[];
      this.editactivityForm.value.activityData[i].activityRestWeekArr.push('All');
    }
    else {
      if(this.editactivityForm.value.activityData[i].activityRestWeekArr.includes('All'))
        this.editactivityForm.value.activityData[i].activityRestWeekArr=[];
      if(this.editactivityForm.value.activityData[i].activityRestWeekArr.includes(week))
        this.editactivityForm.value.activityData[i].activityRestWeekArr.splice(this.editactivityForm.value.activityData[i].activityRestWeekArr.indexOf(week), 1 );
      else{
          this.editactivityForm.value.activityData[i].activityRestWeekArr.push(week);
      }
    }
  }
  

  save() {
    this.service.showSpinner();
    console.log(this.editactivityForm.value)
    console.log('template--->>',this.editTemplateForm.value)
    var templateDetails = {
      'templateName': this.editTemplateForm.value.templateName,
      'trainingWeeks': this.editTemplateForm.value.totalWeek,
      'restDaysArray': this.dayArr,
      'restWeekArray': this.weekArr,
      'startDate':'',
      'enddate':'',
      'warmUpTime': '' ,   //this.editTemplateForm.value.warmup,
      'warmDownTime':'', //this.editTemplateForm.value.warmdown,
      'trainingActivity':this.editactivityForm.value.activityData,
      'horseID'                    :   '',
      'horseTitle'                  :   '',
      'horseImage'                  :   '',
      'nonTrainingDay'              :   '',
      'templateNotes' : ''
    }
    console.log('Detail--->>',templateDetails);
    this.firestore.collection('adminTrainingTemplate').doc(this.templateId).update(templateDetails);
    this.service.hideSpinner();
    this.service.showSuccess('Template has been update successfully.');
    this.router.navigate(['/trainingMagement']);
  }


  numberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;

  }

}
