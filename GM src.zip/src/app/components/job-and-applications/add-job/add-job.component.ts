import { Router, ActivatedRoute } from '@angular/router';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { ServiceService } from 'src/app/service/service.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { AppComponent } from 'src/app/app.component';
import { CookieService } from 'ngx-cookie-service';

declare var $: any;

@Component({
    selector: 'app-add-job',
    templateUrl: './add-job.component.html',
    styleUrls: ['./add-job.component.css']
})
export class AddJobComponent implements OnInit, OnDestroy {

    addJobForm: FormGroup;
    saveApiResponse: any = { status: 809, message: '' };
    paramData: any;
    subscription: any;
    userIp: any;

    constructor(
        private spinner: NgxSpinnerService,
        private service: ServiceService,
        private router: Router,
        private activatedroute: ActivatedRoute,
        private appC: AppComponent,
        private cookie: CookieService
    ) {
        this.addJobForm = new FormGroup({
            title: new FormControl('', [Validators.required]),
            editorValue: new FormControl('', [Validators.required]),
            noOfOpenings: new FormControl('', [Validators.required, Validators.pattern(/^[0-9]*$/)])
        });
        this.subscription = this.service.authVerify.subscribe(val => {
            if (val == 'add-job') {
                this.submitJob();
                this.service.authVerify.next('false');
            }
        });
    }

    /** Function to get data values */
    get title(): any {
        return this.addJobForm.get('title');
    }
    get editorValue(): any {
        return this.addJobForm.get('editorValue');
    }
    get noOfOpenings(): any {
        return this.addJobForm.get('noOfOpenings');
    }

    /** Function to send value */
    addJobFormTest(...val) {
        this.addJobForm.controls.title.setValue(val[0]);
        this.addJobForm.controls.editorValue.setValue(val[1]);
        this.addJobForm.controls.noOfOpenings.setValue(val[2]);
        return this.addJobForm.valid;
    }

    ngOnInit() {
        window.scrollTo(0, 0);
        this.getParamData();
        this.userIp = (this.cookie.get('userInfo')) ? JSON.parse(this.cookie.get('userInfo')) : this.service.initialUserInfo;
    }

    ngOnDestroy() {
        this.subscription.unsubscribe();
    }

    getParamData() {
        this.activatedroute.params.subscribe(param => {
            this.paramData = param;
        });
    }

    /** Function to verify google authentication */
    verifyGoogleAuth() {
        this.appC.google = { one: '', two: '', three: '', four: '', five: '', six: '' };
        this.appC.response = { 'message': '' };
        this.service.googleAuthCalledFrom = 'add-job';
        $('#google-auth-modal').modal({ keyboard: false, backdrop: 'static' });

    }

    /** Function to add job */

    submitJob() {
        if (this.addJobForm.invalid) {
            return;
        }
        this.spinner.show();
        const data = {
            languageShortName: this.service.encrypt(this.paramData.lang),
            description: this.service.encrypt(this.addJobForm.value.editorValue),
            noOfOpening: this.service.encrypt(this.addJobForm.value.noOfOpenings),
            title: this.service.encrypt(this.addJobForm.value.title),
            slug: this.service.encrypt(this.addJobForm.value.title.replace(' ', '_')),
            location: this.service.encrypt(this.userIp.city + ',' + this.userIp.country_name),
            ipAddress: this.service.encrypt(this.userIp.ip),
        };
        this.service.postMethod('career/admin/save-job-details', data, 1).subscribe((response: any) => {
            const decryptedData = response.data ? JSON.parse(this.service.decrypt(response.data)) : {};
            this.spinner.hide();
            this.saveApiResponse = decryptedData;
            if (decryptedData.status === 809) {
                this.router.navigate(['/jobs']);
            }
        }, (error) => {
            this.spinner.hide();
            this.saveApiResponse.status = error.error.status;
            this.saveApiResponse.message = error.error.error;
        });
    }
}
