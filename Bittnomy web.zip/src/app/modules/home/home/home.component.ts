import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HeaderComponent } from '../../header/header/header.component';
import { ServerService } from '../../../service/server.service';

@Component({
    selector: 'app-home',
    templateUrl: './home.component.html',
    styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
    loginStatus: boolean;
    quickTab: any = '';
    dataArr: any[];
    coinID: any;

    constructor(public router: Router,public header: HeaderComponent, public myService: ServerService) { 
        this.header.fireToChild().subscribe(message => {
            this.quickTab = message.text;
            if(this.quickTab== "logout")
            this.check();
        });
    }

    ngOnInit() {
        window.scrollTo(0, 0);
        this.check();
        this.header.getprofile();
        //this.getCoinList();
    }

    signup() {
        this.router.navigateByUrl('header/signup');
    }

    check() {
        if(localStorage.getItem("token")) {
            this.loginStatus = true;
        } else {
            this.loginStatus = false;
        }
    }

    goToMarket() {
        this.router.navigateByUrl('header/exchange-pair');
    }

    /** Function to get coin list from api */
    getCoinList() {
        this.dataArr = [];
        let data = {
            "eventExternal":  {
                "name":"request_get_coin_list",
                "key":"mykey"
            },
            "transferObjectMap":{}
        }
        this.myService.postApi('',data,0).subscribe((succ) => {
            if(succ.transferObjectMap.statusCode == 200) {
                succ.transferObjectMap.coinList.forEach(obj => {
                    if(obj.coinShortName == 'BTC'|| obj.coinShortName == 'ETH'|| obj.coinShortName == 'XRP'|| obj.coinShortName == 'BCH'|| obj.coinShortName == 'XLM'|| obj.coinShortName == 'LTC'|| obj.coinShortName == 'IOTA' || obj.coinShortName == 'USDT' || obj.coinShortName == 'XVG') {
                        this.dataArr.push({
                            "coinFullName": obj.coinFullName,
                            "coinShortName":obj.coinShortName,
                            "marketPrice":'',
                            "price":'',
                            "volume24":'',
                            "change24":'',
                        });
                    }
                    if(obj.coinShortName == 'BTC'|| obj.coinShortName == 'ETH'|| obj.coinShortName == 'XRP'|| obj.coinShortName == 'BCH'|| obj.coinShortName == 'XLM'|| obj.coinShortName == 'LTC'|| obj.coinShortName == 'IOTA' || obj.coinShortName == 'USDT' || obj.coinShortName == 'XVG') {
                        this.myService.get("https://min-api.cryptocompare.com/data/pricemultifull?fsyms="+obj.coinShortName+"&tsyms=USD").subscribe((succ) => {
                            let ind = this.dataArr.findIndex((x) => x.coinShortName == obj.coinShortName);
                            this.dataArr[ind].marketPrice = succ.DISPLAY[obj.coinShortName].USD.MKTCAP;
                            this.dataArr[ind].price = succ.DISPLAY[obj.coinShortName].USD.PRICE;
                            this.dataArr[ind].volume24 = succ.DISPLAY[obj.coinShortName].USD.VOLUME24HOUR;
                            this.dataArr[ind].change24 = succ.DISPLAY[obj.coinShortName].USD.CHANGE24HOUR;
                        }, (err) => {
                        });
                    }
                    
                });
               
            }
        }, (err) => {
        });
        this.getHomeData();
    }

    /**Function to get coin list & data from cryptoCompare site */
    getHomeData() {
        this.coinID = setInterval((data) => {
            for(let i = 0; i < this.dataArr.length;i++) {
                this.myService.get("https://min-api.cryptocompare.com/data/pricemultifull?fsyms="+this.dataArr[i].coinShortName+"&tsyms=USD").subscribe((succ) => {
                    let ind = this.dataArr.findIndex((x) => x.coinShortName == this.dataArr[i].coinShortName);
                    this.dataArr[ind].marketPrice = succ.DISPLAY[this.dataArr[i].coinShortName].USD.MKTCAP;
                    this.dataArr[ind].price = succ.DISPLAY[this.dataArr[i].coinShortName].USD.PRICE;
                    this.dataArr[ind].volume24 = succ.DISPLAY[this.dataArr[i].coinShortName].USD.VOLUME24HOUR;
                    this.dataArr[ind].change24 = succ.DISPLAY[this.dataArr[i].coinShortName].USD.CHANGE24HOUR;
                }, (err) => {
                });
                
            }
        },60000);
    }

    ngOnDestroy() {
        if (this.coinID) {
            clearInterval(this.coinID);
        }
    }

    
}
