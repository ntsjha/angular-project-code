import { ServiceService } from 'src/app/service/service.service';
import { FormGroup, FormControl } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { IMyDpOptions } from 'mydatepicker';

@Component({
  selector: 'app-reward-transaction',
  templateUrl: './reward-transaction.component.html',
  styleUrls: ['./reward-transaction.component.css']
})
export class RewardTransactionComponent implements OnInit {

  searchForm: FormGroup;
  public fromPickerOptions: IMyDpOptions = {
    disableSince: { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() + 1 },
    dateFormat: 'dd/mm/yyyy',
  };
  englishShortCode: any;
  public toPickerOptions: IMyDpOptions = {
    disableSince: { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() + 1 },
    dateFormat: 'dd/mm/yyyy',
  };
  paginationData: any = {limit: 10, currPage: 1, total: 0};
  rewardsTransactionList: any = [];

  constructor(
    private service: ServiceService
  ) { }

  ngOnInit() {
    this.form();
    this.getTransactionList('reset');
    window.scrollTo(0, 0);
  }

  form() {
    this.searchForm = new FormGroup({
      search          : new FormControl(''),
      transactionType : new FormControl(null),
      fromDate        : new FormControl(''),
      toDate          : new FormControl(''),
    });
  }

  fromDateChanged(event) {
    if (event.epoc) {
      this.toPickerOptions = {
        disableUntil: { year: new Date(event.epoc * 1000).getFullYear(), month: new Date(event.epoc * 1000).getMonth() + 1, day: new Date(event.epoc * 1000).getDate() - 1 }
      };
    } else {
      this.toPickerOptions = {
        disableUntil: { year: 0, month: 0, day: 0 },
        disableSince: { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() + 1 }
      };
    }
  }

  toDateChanged(event) {
    if (event.epoc) {
      this.fromPickerOptions = {
        disableSince: { year: new Date(event.epoc * 1000).getFullYear(), month: new Date(event.epoc * 1000).getMonth() + 1, day: new Date(event.epoc * 1000).getDate() + 1 }
      };
    } else {
      this.fromPickerOptions = {
        disableSince: { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() + 1 },
      };
    }
  }

  getTransactionList(event) {
    let apireq;
    if (event === 'reset') {
      apireq = {
        page     : this.paginationData.currPage - 1,
        pageSize : this.paginationData.limit,
        search   : null,
        status   : null,
        fromDate : null,
        toDate   : null,
      };
      this.paginationData.currPage = 1;
    } else {
      apireq = {
          page     : this.paginationData.currPage - 1,
          pageSize : this.paginationData.limit,
          search   : this.searchForm.value.search ? this.searchForm.value.search.trim() : null,
          status   : this.searchForm.value.transactionType ? (this.searchForm.value.transactionType === 'true' ? true : (this.searchForm.value.transactionType === 'false' ? false : null)) : null,
          fromDate : this.searchForm.value.fromDate ? (this.searchForm.value.fromDate.epoc ? (this.searchForm.value.fromDate.epoc * 1000) : null) : null,
          toDate   : this.searchForm.value.toDate ? (this.searchForm.value.toDate.epoc ? ((this.searchForm.value.toDate.epoc * 1000) + 86399999) : null) : null,
      };
    }
    this.service.postMethod('rewards/search-and-filter-reward-transaction', apireq, 1).subscribe((success: any) => {
      if (success.status === 918) {
        this.rewardsTransactionList = success.data.list;
        this.paginationData.total = success.data.size;
      } else {
        this.rewardsTransactionList = [];
      }
    }, error => {
      this.rewardsTransactionList = [];
    });
  }

  changePage(event) {
    this.paginationData.currPage = event;
    this.getTransactionList('apply');
  }

}
