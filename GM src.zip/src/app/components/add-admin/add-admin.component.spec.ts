import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { AddAdminComponent } from './add-admin.component';
import { SharedModuleModule } from 'src/app/shared-module/shared-module.module';
import { MarketingSidebarComponent } from '../sidebar/sidebar.component';
import { RouterTestingModule } from '@angular/router/testing';
import { RouterModule } from '@angular/router';
import { AppComponent } from 'src/app/app.component';
import { DeviceDetectorService } from 'ngx-device-detector';
import { FormGroup, Validators, FormControl } from '@angular/forms';
declare var $: any;
describe('AddAdminComponent', () => {
  let component: AddAdminComponent;
  let fixture: ComponentFixture<AddAdminComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddAdminComponent, MarketingSidebarComponent,  ],
      imports: [SharedModuleModule, RouterModule,
        RouterTestingModule,],
        providers: [AppComponent, DeviceDetectorService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddAdminComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    this.addAdmin = new FormGroup({
      firstName: new FormControl('', [Validators.required, Validators.pattern(/^[a-z ,.'-]+$/i), Validators.maxLength(255), Validators.minLength(3)]),
      lastName: new FormControl('', [Validators.required, Validators.pattern(/^[a-z ,.'-]+$/i), Validators.maxLength(255), Validators.minLength(3)]),
      email: new FormControl('', [Validators.required, Validators.pattern(/^[a-zA-Z0-9_+&*-]+(?:\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,7}$/),Validators.maxLength(256)]),
      phone: new FormControl('', [Validators.required, Validators.pattern(/^[0-9]*$/),Validators.maxLength(15)]),
      gender: new FormControl('', [Validators.required]),

  });
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('general form invalid when empty', async(() => {
    const emptyValue = component.addAdminTest('','','','','');
    expect(emptyValue).toBeFalsy();
  }));

  it('general form valid with all fields', async(() => {
    const value = component.addAdminTest('alpha','beta','mk@gmail.com','8998998985','female');
    expect(value).toBeTruthy();
  }));
});
