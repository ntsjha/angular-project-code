import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SignupComponent } from './signup/signup.component';
import { ForgetComponent } from './forget/forget.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { LoginComponent } from './login/login.component';
import { AppComponent } from './app.component';
import { MainComponent } from './main/main.component';
import { TestComponent } from './test/test.component';
const routes: Routes = [
  { path: '', redirectTo: '/login', pathMatch: 'full'},
   { path: 'signup', component: SignupComponent },
    { path: 'forget', component: ForgetComponent, },
    { path: 'login', component: LoginComponent},
    { path: 'main', component: MainComponent, },
    { path: 'test', component: TestComponent ,  }
   
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
