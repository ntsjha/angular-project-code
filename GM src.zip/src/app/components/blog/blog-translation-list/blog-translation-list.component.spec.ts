import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BlogTranslationListComponent } from './blog-translation-list.component';

describe('BlogTranslationListComponent', () => {
  let component: BlogTranslationListComponent;
  let fixture: ComponentFixture<BlogTranslationListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BlogTranslationListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BlogTranslationListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
