import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ServerService } from '../../../service/server.service';
import { AppComponent } from '../../../app.component';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { Router } from '@angular/router';

@Component({
    selector: 'app-forgetpassword',
    templateUrl: './forgetpassword.component.html',
    styleUrls: ['./forgetpassword.component.css']
})
export class ForgetpasswordComponent implements OnInit {
    forgetForm: FormGroup;

    constructor(private router: Router , private server: ServerService , private appC: AppComponent, private spinnerService: Ng4LoadingSpinnerService) { }

    ngOnInit() {
        window.scrollTo(0,0)
        this.checkInputs();
    }

    /** Function to validate form inputs */
    checkInputs() {
        this.forgetForm = new FormGroup({
            email: new FormControl('', [Validators.required, Validators.pattern(/^[A-Z0-9_-]+([\.][A-Z0-9_]+)*@[A-Z0-9-]+(\.[a-zA-Z]{2,5})+$/i)]),
        })
    }

    /** to get the value of field  */
    get email(): any {
        return this.forgetForm.get('email');
    }

    submit() {
        this.spinnerService.show();
        this.server.getApi('account/forget-password?email='+this.forgetForm.value.email+'&webUrl='+this.server.websiteURL+"header/reset",0).subscribe(response => {
            this.spinnerService.hide();
            if (response.status == 200) {
                this.appC.showSuccToast('Password reset link has been sent to your e-mail id.');
                this.router.navigateByUrl('header/login') 
            } else {
                this.appC.showErrToast(response.message)
            }
            
        }, error => {
            this.spinnerService.hide();
            if(error.status == 400){
                 this.appC.showErrToast(error.error.error);
            } else{
                this.appC.showErrToast(error.error.message);
            } 
        });       
    }

}
