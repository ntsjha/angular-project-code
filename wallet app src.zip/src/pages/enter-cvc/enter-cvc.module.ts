import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { EnterCvcPage } from './enter-cvc';

@NgModule({
  declarations: [
    EnterCvcPage,
  ],
  imports: [
    IonicPageModule.forChild(EnterCvcPage),
  ],
})
export class EnterCvcPageModule {}
