import { Component, OnInit } from '@angular/core';
import { MarketPanelSideBar } from './sidebarData.model';
import { sideBarDataArr, sideBarDataSuperAdmin } from './sideBarData';
import { Router } from '@angular/router';
import { ServiceService } from 'src/app/service/service.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { CookieService } from 'ngx-cookie-service';
import { AppComponent } from 'src/app/app.component';
import { Subject, Observable } from 'rxjs';

declare var $: any;
@Component({
    selector: 'app-sidebar',
    templateUrl: './sidebar.component.html',
    styleUrls: ['./sidebar.component.css']
})
export class MarketingSidebarComponent implements OnInit {
    activeTab: any = 'dashboard';
    sideBarData: MarketPanelSideBar[];
    sideBarDataArr: MarketPanelSideBar[];
    localSideBarData: any;
    url: any = 'dashboard';
    private subject = new Subject<any>();
    toggle: any = true;
    profileData: any;
    manageDataAccRoles: MarketPanelSideBar[];
    sideBarDataSuperAdmin: MarketPanelSideBar[];
    getNotification: any;
    notificationLength: any;
    dataFour = [];
    errorNotification: any;
    notificationSeen: any = 0;
    dataQwerty: any;
    profileRole = false;


    constructor(private router: Router, private service: ServiceService, private spinner: NgxSpinnerService, private cookie: CookieService, private appC: AppComponent) {
        this.appC.fireToChild().subscribe(message => {
            message.text === 'urlChange' ? this.getUrl() : this.url = 'dashboard';
        });
        this.manageDataAccRoles = sideBarDataArr;
    }
    fireToChild(): Observable<any> {
        return this.subject.asObservable();
    }


    ngOnInit() {
        this.sideBarData = this.service.localSideBarData;
        this.getProfile();
        this.checkForSession();
        window.scrollTo(0, 0);
    }

    checkForSession() {
        this.service.getMethod('account/check-session', 1)
            .subscribe((response) => {
            });
    }

    getUserPermission() {
        this.sideBarData = [];
        this.service.sideBarData = [];
        this.service.sideMenuArr = [];
        const obj = {
            name: 'Dashboard',
            icon: 'fa fa-dashboard',
            subtopic: [],
            url: 'dashboard',
            routing: 'dashboard'
        };
        const data = [];
        data.push(obj);
        this.sideBarData.push(obj);
        this.service.sideBarData = ['dashboard'];
        this.service.postMethod('account/get-users-role-permissions', {}, 1).subscribe((res) => {
            let responseData = this.service.decrypt(res.data);
            responseData = JSON.parse(responseData);
            console.log(responseData);
            if (responseData.status === 2011) {
                this.sideBarData = [];
                var subTopicArr = [];
                responseData.data.menuList.forEach(obj => {
                    this.manageDataAccRoles.forEach(element => {
                        if (element.url === obj.menuname) {
                            data.push(element);
                        }
                    });
                });
                subTopicArr = data;
                subTopicArr.forEach((element, index) => {
                    var count = 0;
                    if (element.subtopic.length) {
                        element.subtopic.forEach((arr, ind) => {
                            responseData.data.subMenuList.forEach(menu => {
                                if (arr.url == menu.subMenuname) {
                                    count = 1;
                                }
                            });
                        });
                    }
                });
                this.sideBarData = data;
                this.sideBarData.forEach(element => {
                    this.service.sideBarData.push(element.url);
                });
                responseData.data.subMenuList.forEach(element => {
                    this.service.sideMenuArr.push(element.subMenuname);
                    this.service.sideBarData.push(element.subMenuname);
                });
            }
            this.service.localSideBarData = this.sideBarData;
        }, (err) => {
        });

    }

    getUrl() {
        this.url = this.appC.url;
    }

    navigationFunction(val) {
        if (val.routing) {
            this.activeTab = val.routing;
            this.router.navigateByUrl(val.routing);
        }
    }

    logout() {
        this.service.sideBarData = [];
        this.service.localSideBarData = [];
        this.service.sideMenuArr = [];
        const data = {
            token: this.service.encrypt(this.cookie.get('token')),
            languageCode: this.service.encrypt(this.service.currLang)
        };
        this.cookie.delete('token', '/');
        this.router.navigateByUrl('login');
        this.service.postMethod('account/common-permit/logoutSession', data, 1).subscribe((res) => {
        }, (err) => {
        });
    }

    removeDisplayNone(index) {
        if (this.toggle) {
            $('#toggle' + index).css('display', 'block');
            $(".treeview" + index).addClass("menu-open");
        } else {
            $('#toggle' + index).css('display', 'none');
            $(".treeview" + index).removeClass("menu-open");
        }
        this.toggle = !this.toggle;
    }

    getProfile() {
        this.service.getMethod('account/my-account', 1).subscribe((response: any) => {
            let responseData = this.service.decrypt(response.data);
            responseData = JSON.parse(responseData);
            if (responseData.status === 200) {
                this.profileData = responseData.data;
                this.service.setRole(this.profileData.roles);
                if (this.profileData.roles === 'USER') {
                    this.cookie.delete('token', '/');
                    this.router.navigate(['/login']);
                } else if (this.profileData.roles === 'SUPERADMIN') {
                    if (!(this.service.localSideBarData.length > 1)) {
                        this.sideBarData = sideBarDataSuperAdmin;
                        this.service.localSideBarData = sideBarDataSuperAdmin;
                    }
                } else {
                    this.profileRole = true;
                    if (this.service.localSideBarData.length > 2) {
                        this.sideBarData = this.service.localSideBarData;
                    } else {
                        this.getUserPermission();
                    }
                }
                if (this.profileData.roles !== 'SUPERADMIN') {
                    this.getNotificationData();
                }
                // this.profileData = JSON.parse(this.service.decrypt(response.data)).data;
            }

        }, (error) => {
        });

    }


    getNotificationData() {
        this.spinner.show();
        this.service.getMethod('notification-service/common-permit/get-notification-data', 1).subscribe((response: any) => {
            this.spinner.hide();
            if (response.status === 1618) {
                this.getNotification = response.data;
                this.getNotification.reverse();
                let count = 0;
                this.getNotification.forEach((element, index) => {
                    if (!element.isSeen) {
                        count++;
                        this.dataFour.push(element);
                    }
                    if (this.dataFour.length > 4) {
                        this.dataFour.splice(0, 4);
                    }
                });
                this.notificationLength = response.data.length;
                this.notificationSeen = count;

            }
        }, (error) => {
            this.spinner.hide();
        });
        this.spinner.hide();

    }

    getNotificationRead() {
        this.spinner.show();
        this.service.getMethod('notification-service/common-permit/read-notification', 1).subscribe((response: any) => {
            this.spinner.hide();
            if (response.status == 1617) {
                this.errorNotification = response.message;
            }

        }, (error) => {
            this.spinner.hide();
        });
        this.spinner.hide();

    }
}
