import { Component, OnInit } from '@angular/core';
import { ServiceService } from 'src/app/service/service.service';
import { ActivatedRoute } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NgxSpinner } from 'ngx-spinner/lib/ngx-spinner.enum';
import { NgxSpinnerService } from 'ngx-spinner';
declare var $: any;
@Component({
  selector: 'app-state-name',
  templateUrl: './state-name.component.html',
  styleUrls: ['./state-name.component.css']
})
export class StateNameComponent implements OnInit {
  countryName: string;
  stateList: any = [];
  newState: string;
  currentUser: any;
  filterFunction: FormGroup;
  page: any = 0;
  countryId: any;
  selectedStateId: any;
  p: any = 1;
  total: any;
  stateNameEdit: FormGroup;
  constructor(private service: ServiceService, private activatedRoutes: ActivatedRoute, private spinner: NgxSpinnerService, private fb: FormBuilder) { }

  ngOnInit() {
    this.activatedRoutes.params.subscribe((data) => {
      this.countryName = data.id1;
      this.countryId = data.id2;
    });
    this.service.currentUserInfo.subscribe((response) => {
      this.currentUser = response;
    });
    this.filterFunction = this.fb.group({
      search: [null],
      status: [null],
    });
    this.stateNameEdit = this.fb.group({
      stateName: ['', [Validators.required, Validators.minLength(3)]]
    });
    this.getStateList();
    window.scrollTo(0, 0);
  }

  getStateList() {
    this.spinner.show();
    const data = {
      page: this.service.encrypt(this.page),
      pageSize: this.service.encrypt('10'),
      search: ((this.filterFunction.value.search != null) ? this.service.encrypt(this.filterFunction.value.search.trim()) : null),
      status: ((this.filterFunction.value.status != null) ? this.service.encrypt(this.filterFunction.value.status) : null),
    };

    this.service.postMethod('setting/admin/search-and-filter-states/?countryId=' + encodeURIComponent(this.service.encrypt(this.countryId)), data, 1)
      .subscribe((res) => {
        this.spinner.hide();
        const responseData = JSON.parse(this.service.decrypt(res.data));
        if (responseData.status === 729) {
          this.stateList = [];
          this.total = 0;
        } else {
          if (responseData.data.list) {
            this.stateList = responseData.data.list;
            this.total = responseData.data.size;
            this.stateList.forEach(element => {
              if(element.updatedBy == null) {
                element.updatedAt = null;
              }
            });
          }
        }
      }, (err) => {
        this.spinner.hide();
      });
  }

  openModal(modal, id) {
    this.stateList.findIndex((x) => x.stateId === id);
    this.selectedStateId = id;
    $('#' + modal).modal('show');
  }

  resetFilter() {
    this.filterFunction.patchValue({
      search: null,
      status: null,
    });
    this.p = 1;
    this.page = 0;
    this.getStateList();
  }
  changeStatus() {
    this.service.postMethod('setting/admin/change-state-status/?ipAddress=' + encodeURIComponent(this.service.encrypt(this.currentUser.ip)) + '&location=' + encodeURIComponent(this.service.encrypt(this.currentUser.city)) + '&stateId=' + encodeURIComponent(this.service.encrypt(this.selectedStateId)), {}, 1)
      .subscribe((res) => {
        $('#unPublishdeleteModal').modal('hide');
      });
  }

  editState(id) {
    if (this.service.sideMenuArr.includes('updateStateList')) {
      $('#editState').modal('show');
      this.selectedStateId = id;
      this.service.postMethod('setting/admin/get-state-detail?stateId=' + encodeURIComponent(this.service.encrypt(id)) + '&language=' + encodeURIComponent(this.service.encrypt('en')), {}, 1)
        .subscribe((response) => {
          if (response.status === 726) {
            this.stateNameEdit.patchValue({
              stateName: response.data.stateName
            });
          }
        }, (error) => {
        });
    }
  }

  updatedState() {
    const data = {
      ipAddress: this.service.encrypt(this.currentUser.ip),
      location: this.service.encrypt(this.currentUser.city + ', ' + this.currentUser.country_name),
      stateId: this.service.encrypt(this.selectedStateId),
      stateName: this.service.encrypt(this.stateNameEdit.value.stateName)
    };
    this.service.postMethod('setting/admin/edit-state', data, 1)
      .subscribe((res) => {
        if (res.status === 725) {
          $('#editState').modal('hide');
          this.getStateList();
        }
      }, (error) => {
        this.getStateList();
        $('#editState').modal('hide');
      });
  }

  addState() {
    const data = {
      countriesId: this.service.encrypt(this.countryId),
      ipAddress: this.service.encrypt(this.currentUser.ip),
      location: this.service.encrypt(this.currentUser.city + ', ' + this.currentUser.country_name),
      stateName: this.service.encrypt(this.newState)
    };
    this.service.postMethod('setting/admin/add-new-state', data, 1)
      .subscribe((res) => {
        $('#addState').modal('hide');
        this.getStateList();
      });
  }

  deleteState() {
    this.service.postMethod('setting/admin/delete-state/?ipAddress=' + encodeURIComponent(this.service.encrypt(this.currentUser.ip)) + '&location=' + encodeURIComponent(this.service.encrypt(this.currentUser.city)) + '&stateId=' + encodeURIComponent(this.service.encrypt(this.selectedStateId)), {}, 1)
      .subscribe((res) => {
        $('#deleteState').modal('hide');
        this.getStateList();
      }, (error) => {
        $('#deleteState').modal('hide');
      });
  }

  changePage(page) {
    this.p = page;
    this.page = page - 1;
    this.getStateList();
  }
}
