declare var CanvasJS: any;

export class hrTradeChartService {
  chart: any;
  chartCoinData = [];

  hrTradeChartData(data, chartId) {
    this.chartCoinData = [];
    const resData = data;
    if (resData.length) {
      resData.forEach((element) => {
        let arr = [];
        if (element.graphObj.length) {
          element.graphObj.forEach(graphData => {
            const cordinates = {
              x: (new Date(graphData.timestamp)),
              y: graphData.value,
            };
            arr.push(cordinates);
          });
        } else {
           arr = [{ x: (new Date()), y: 0 }];
        }
        const coinData = {
          type: 'spline',
          xValueFormatString: 'hh:mm TT',
          yValueFormatString: '#,##0.###',
          name: element.instrument,
          dataPoints: arr,
        };
        this.chartCoinData.push(coinData);
      });
    } else {
      this.chartCoinData = [ {
          type: 'spline',
          xValueFormatString: 'hh:mm TT',
          yValueFormatString: '#,##0.###',
          name: '',
          dataPoints: [{ x: (new Date()), y: 0 }],
        }
      ];
    }
    this.chart = new CanvasJS.Chart(chartId, {
      exportEnabled: true,
      zoomEnabled: true,
      animationEnabled: true,
      axisX: {
        valueFormatString: 'hh:mm TT'
      },
      axisY: {
        valueFormatString: '#,##0.###',
        includeZero: true,
      },
      legend: {
        cursor: 'pointer',
        fontSize: 16,
      },
      toolTip: {
        shared: true
      },
      data: this.chartCoinData,
    });
    return this.chart.render();
  }
}



