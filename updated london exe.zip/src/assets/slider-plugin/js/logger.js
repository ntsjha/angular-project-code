! function(t, e, n) {
    function r() {
        function t() {
            return Math.floor(65536 * (1 + Math.random())).toString(16).substring(1)
        }
        return t() + t() + "-" + t() + "-" + t() + "-" + t() + "-" + t() + t() + t()
    }

    function o(t, e) {
        for (var n in e) t[n] = e[n];
        return t
    }

    function a(t) {
        if ("[object Array]" === Object.prototype.toString.call(t)) {
            for (var e = [], n = 0; n < t.length; n++) e[n] = a(t[n]);
            return e
        }
        if ("object" == typeof t) {
            var e = {};
            for (var r in t) t.hasOwnProperty(r) && (e[r] = a(t[r]));
            return e
        }
        return t
    }

    function s(t, e) {
        t.debugMsg("Sending event as image");
        var n = document.createElement("img"),
            o = r();
        n.setAttribute("id", o), n.setAttribute("src", e), n.setAttribute("height", "1"), n.setAttribute("width", "1"), n.style.display = "none", document.body.appendChild(n), setTimeout(function() {
            var t = document.getElementById(o);
            t && (t.outerHTML = "", delete t)
        }, 100)
    }

    function u() {
        if (!localStorage) return null;
        try {
            var t = localStorage.getItem(y);
            return t || localStorage.setItem(y, r()), t = localStorage.getItem(y)
        } catch (e) {
            return null
        }
    }

    function c(t) {
        var e = t.prototype.SessionGuid;
        return e ? e : r()
    }

    function g(t, e, n, r, o, i, a) {
        var s = e ? "info" : "error",
            u = null,
            c = new Date;
        o.target && (u = o.target.status), t.debugMsg("HTTP callback ", {
            success: e,
            status: u,
            url: n
        }), t.send([{
            Level: s,
            Message: "networkLog",
            Performance_RequestTime: c - i,
            Request_Url: n,
            Request_Method: r,
            Request_Status: u,
            Request_Id: a
        }])
    }

    function l(t, e) {
        var n = !1;
        for (i = 0; i < M.length; i++) M[i].msg == t && (n = !0, M[i].count++);
        n || M.push({
            msg: t,
            count: 1
        }), setTimeout(function() {
            var t = [];
            if (0 != M.length) {
                for (i = 0; i < M.length; i++) t.push({
                    Level: "error",
                    Message: "JS error/exception",
                    errorMessage: M[i].msg,
                    errorMessageCount: M[i].count
                });
                e.send(t), M = []
            }
        }, 2e3)
    }

    function f(e) {
        e.debugMsg("Info: catchJSErrors");
        var n = function(n, r, o, i) {
            var i = i || t.event && t.event.errorCharacter,
                a = [];
            try {
                for (var s = arguments.callee.caller; s;) a.push(s.name), s = s.caller
            } catch (u) {}
            try {
                var c = n + "from" + JSON.stringify(a);
                l(c, e)
            } catch (u) {
                e.debugMsg("Faild to parse JS error ", u)
            }
            return !1
        };
        t.onerror = n
    }

    function p(e, r) {
        var o = r.actionsRecorder;
        t[n][e] = new S;
        var a = t[n][e];
        if (S.apply(a, r.settings), o)
            for (i = 0; i < o.length; i++) {
                var s = o[i],
                    u = s[0];
                s.shift(), a[u] && a[u].apply(a, s)
            }
    }

    function d() {
        var e = t[n];
        e && Object.keys(e).forEach(function(t) {
            p(t, e[t])
        })
    }
    var v = {
            production: "https://etorologsapi.etoro.com/api/v2/monitoring?applicationIdentifier=",
            staging: "http://etoro-logs-api-staging.cloudapp.net/api/v2/monitoring?applicationIdentifier="
        },
        h = ["info", "error", "warn", "debug"],
        m = ["LP", "innerPages", "HomePage", "registrationFrom", "RAF"],
        y = "etoroMarketingUserSession",
        b = "marketingSites",
        M = [],
        S = function(e, n, r, i, a, s) {
            var g = this;
            g.config = {
                ApplicationIdentifier: b,
                ApplicationVersion: n,
                AppName: e,
                Categories: m.indexOf(r) > -1 ? r : "marketingUnknown",
                SessionGuid: c(S),
                UserSessionGuid: u(),
                Location: location.href,
                Message: null,
                DOMLoadTime: function() {
                    var e = null;
                    try {
                        var e = t.performance.timing.domContentLoadedEventEnd - t.performance.timing.navigationStart;
                        e = e > 0 && 1e5 > e ? e : null
                    } catch (n) {}
                    return e
                }(),
                Level: "info"
            }, o(this.config, i), g.debug = a, g.environment = function() {
                var t = v[s] ? s : "staging";
                return g.debugMsg("environment: " + t), t
            }(), g.init()
        };
    S.prototype.debugMsg = function() {
        if (this.debug) {
            var t = Function.prototype.bind.call(console.warn, console);
            t.apply(this, arguments)
        }
    }, S.prototype.createEvent = function(e) {
        if (!e.Level || !e.Message) return this.debugMsg("Missing 'Level' or 'Message'"), null;
        var n = a(this.config);
        return o(n, e), n.Level = h.indexOf(n.Level) > -1 ? n.Level : "info", n.DomComplete = function() {
            var e = null;
            try {
                var e = t.performance.timing.domComplete - t.performance.timing.navigationStart;
                e = e > 0 && 1e5 > e ? e : null
            } catch (n) {}
            return e
        }(), n.ClientDateTime = function() {
            return (new Date).toISOString().split(".")[0] + "Z"
        }(), n
    }, S.prototype.send = function(t) {
        var e = this;
        if (!t || !t.length || "object" != typeof t) return void e.debugMsg("The argument have to be Array with objects");
        var n = [];
        for (k = 0; k < t.length; k++) {
            var r = e.createEvent(t[k]);
            r && n.push(r)
        }
        if (0 == n.length) return void e.debugMsg("no events was passed");
        try {
            objToUrlParm = encodeURIComponent(JSON.stringify(n))
        } catch (o) {
            return
        }
        fullUrlGetMethod = e.logUrl + "&LogEvents=" + objToUrlParm, this.http("POST", e.logUrl, {}, "", null, JSON.stringify({
            LogEvents: n
        }), function(t, n) {
            t || (e.debugMsg("Faild to send the event as POST request"), s(e, fullUrlGetMethod))
        })
    }, S.prototype.http = function(t, e, n, o, i, a, s) {
        var u = this,
            c = function() {
                return e.indexOf(u.logUrl) > -1
            }(),
            l = new Date,
            u = this,
            f = e;
        if (!c) {
            var p = r(),
                d = e.indexOf("?") > -1 ? "&" : "?";
            e = e + d + "client_request_id=" + p
        }
        var v = function(e, n) {
                c || g(u, e, f, t, n, l, p), s(e, n)
            },
            h = new XMLHttpRequest;
        try {
            h.open(t, e)
        } catch (m) {
            return void v(!1, m)
        }
        "object" == typeof n && Object.keys(n).forEach(function(t) {
            h.setRequestHeader(t, n[t])
        }), "json" == o && h.setRequestHeader("Content-Type", "application/json; charset=utf-8"), i && (h.timeout = i), h.onprogress = function() {}, h.ontimeout = function(t) {
            v(!1, t)
        }, h.onerror = function(t) {
            v(!1, t)
        }, h.onreadystatechange = function(t) {}, h.onload = function(t) {
            return t && t.target && 0 != t.target.status && t.target.status < 300 ? void v(!0, t) : void v(!1, t)
        }, h.send(a)
    }, S.prototype.load = !0, S.prototype.SessionGuid = c(S), S.prototype.init = function() {
        this.logUrl = v[this.environment] + this.config.ApplicationIdentifier, this.debugMsg("Log mode: " + this.environment), f(this)
    }, t[e] = S, d()
}(window, "etoroLogger", "etoroLoggerApps");