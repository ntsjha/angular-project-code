import { Component, OnInit } from '@angular/core';
import { AngularFirestore } from '@angular/fire/firestore';
import { ServiceService } from 'src/app/Shared/service.service';
import { Employee } from 'src/app/Shared/employee.model';
import { Router } from '@angular/router';
import { AngularFireAuth } from 'angularfire2/auth';
import * as firebase from 'firebase/app';
declare var $:any;
@Component({
  selector: 'app-user-management',
  templateUrl: './user-management.component.html',
  styleUrls: ['./user-management.component.css']
})
export class UserManagementComponent implements OnInit {
  list: Employee[];
  p: number = 1;
  pageSize = 5;
  total = 0
  searchText: string = "";
  userid: string;
  email: any;
  constructor(private service: ServiceService,private afAuth: AngularFireAuth,
    private afs: AngularFirestore, public router: Router,
  ) { }

  ngOnInit() {   
   this.getUserList()
  }
  
 
  getUserList(){
    this.searchText = ''
    this.service.showSpinner();
    this.service.getEmployees().subscribe(actionArray => {
      // console.log('=========>', actionArray)
      var list = actionArray.map(item => {
        // console.log('Items====>', item)
        return {
          id: item.payload.doc.id,
          ...item.payload.doc.data()
        } as Employee;
      })
      this.service.hideSpinner();
      this.list = list.filter(x=>(x['type']!='Contributor'))
      this.total = this.list.length;
      console.log('USer List--->>>',this.list);
    });
  }

  page(event) {
    console.log(event);
    this.p = event
  }

  onDelete(email:string,id: string) {
    this.userid=id
    this.email=email
    // if (confirm("Are you sure to delete this record?")) {
    //   this.afs.doc('people/' + id).delete();
    // }
  }
  Deleteuser(){
    this.afs.doc('people/' + this.userid).delete();
    $('#delete').modal('hide');
    this.service.showSuccess('User has been deleted sucessfully.');
 
    // console.log('User Deleted===>',user)
    // var user = firebase.auth().currentUser;
    // console.log('User Deleted===>',user)
    // user.delete();
    // this.service.deleuserfromuAuth(this.email,this.userid)
   
    this.afAuth.auth.currentUser.delete().then(() => {
      this.afAuth.auth.signOut()
    })
    
  }

   // Search Functionality
search(){ 
  console.log(this.searchText)
  var searchData = this.list.filter(x=>(x['userName'] == this.searchText || x['email']==this.searchText || x['Mobile']==this.searchText ));
  this.list = searchData;
  this.total = this.list.length;
  console.log("Contributor List-->>",this.list.length)
}

  userDetailsFunc(data) {
    console.log(data)
    this.service.userData = data;
     this.router.navigate(['/userManagement/userManagementView', data.id])
    }
}
