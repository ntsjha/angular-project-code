import { Component, OnInit } from '@angular/core';
import { Router } from '../../../../../node_modules/@angular/router';
import { AppComponent } from '../../../app.component';
import { ServerService } from '../../../service/server.service';
import { Ng4LoadingSpinnerService } from '../../../../../node_modules/ng4-loading-spinner';
import { HeaderComponent } from '../../header/header/header.component';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { fail } from 'assert';
declare var $: any;

@Component({
    selector: 'app-profile',
    templateUrl: './profile.component.html',
    styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
    imageUrl: any;
    editInfo: FormGroup
    activeTab: any = 'info';
    toggle: any = { 'sms': '', 'google': '' }
    countryData: any;
    myCode: any;
    phoneCountryCode: any = '';
    phoneNo: any = '';
    userImage: string = 'assets/images/profile-img.jpg';
    firstname: any;
    lastName: any;
    emailID: any;
    addressUser: any;
    phoneNum: string;
    country: any;
    myImage: any;
    fileName: any;
    fileData: any = 'assets/images/profile-img.jpg';
    authObj: any = { 'docFile': '', 'docFile1': '', 'docFile2': '' };
    numRegxForPattern: any = (/^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})/i);
    changeForm: FormGroup
    check: boolean;
    kycDoc: FormGroup;
    fileName1: any = '';
    fileData1: any = '';
    fileName2: any = '';
    fileData2: any = '';
    obj = { docNum: '', attachmentDataFront: '', attachmentDataBack: '', attachmentDataSelfie: '' };
    front: any = '';
    back: any = '';
    kyc: any = [];
    checkyc: boolean;
    google11: string;
    sms11: string;
    qrCode = { Code1: "" }
    otp = { one: "", two: "", three: "", four: "" };
    count: number;
    googleEnabled: string;
    smsEnabled: string;
    myAngularxQrCode: string;
    code: string;
    seconds: number = 59;
    const: any;
    fileName3: any = '';
    fileData3: any = '';
    selfie: any;
    kycArr: any = [];
    kycArrList: any = [];
    fileName4: any;
    fileData4: any;
    uploadArr: any[];
    attachmentUpload: any = { 'name': '', 'category': '', 'id': '' }
    secretKey: any;
    constructor(private router: Router, public appC: AppComponent, private server: ServerService, private spinnerService: Ng4LoadingSpinnerService, public header: HeaderComponent) { }

    ngOnInit() {
        window.scrollTo(0, 0);
        this.checkpoints();
        this.checkInputs();
        this.checkInput();
        this.getprofile();
    }

    checkpoints() {
        this.editInfo = new FormGroup({
            email: new FormControl(this.emailID),
            name: new FormControl(this.firstname, [Validators.required, Validators.pattern(/^[a-z ,.'-]+$/i)]),
            lastname: new FormControl(this.lastName, [Validators.required, Validators.pattern(/^[a-z ,.'-]+$/i)]),
            country: new FormControl(this.country),
            phone: new FormControl(this.phoneNo),
            address: new FormControl(this.addressUser, [Validators.required]),
        });
    }

    get email(): any {
        return this.editInfo.get('email');
    }
    get phone(): any {
        return this.editInfo.get('phone');
    }
    get name(): any {
        return this.editInfo.get('name');
    }
    get lastname(): any {
        return this.editInfo.get('lastname');
    }
    get address(): any {
        return this.editInfo.get('address');
    }

    preventSpace(event) {
        if (event.keyCode == 32 && event.target.value == '') {
            return false;
        }
    }


    tabActive(val) {
        this.activeTab = val;
        if (this.activeTab == 'kyc')
            this.checkKycStatus();
        else if (this.activeTab == 'identity') {
            this.kycDoc.reset();
            this.kycDoc.patchValue({
                docName: ''
            })
            this.front = '';
            this.back = '';
            this.fileName1 = '';
            this.fileName2 = '';
        }

    }

    getprofile() {
        this.spinnerService.show();
        this.server.getApi("account/my-account", localStorage.getItem('token')).subscribe((succ) => {
            console.log(succ)
            this.spinnerService.hide();
            this.firstname = succ.body.data.firstName;
            this.lastName = succ.body.data.lastName;
            this.emailID = succ.body.data.email;
            this.userImage = (succ.body.data.imageUrl) ? succ.body.data.imageUrl : "assets/images/profile-img.jpg";
            this.fileData = (succ.body.data.imageUrl) ? succ.body.data.imageUrl : "assets/images/profile-img.jpg";
            this.country = succ.body.data.country;
            this.phoneNo = succ.body.data.phoneNo;
            this.addressUser = succ.body.data.address;
            this.googleEnabled = succ.body.data.twoFaType;
            if (this.googleEnabled == "GOOGLE") {
                this.toggle.google = true;
            } else {
                this.toggle.google = false;
            }
        }, (err) => {
            this.spinnerService.hide();
        });
    }

    editProfile() {
        this.activeTab = 'edit';
        this.getprofile();
        this.editInfo.patchValue({
            name: this.firstname,
            lastname: this.lastName,
            address: this.addressUser,
            email: this.emailID,
            phone: this.phoneNo,
        })
    }

    saveProfileData() {
        let data = {
            "address": this.editInfo.value.address,
            "firstName": this.editInfo.value.name,
            "imageUrl": this.imageUrl,
            "lastName": this.editInfo.value.lastname
        }
        this.spinnerService.show();
        this.server.postApi('account/profile-update',data,localStorage.getItem('token')).subscribe(response => {
            this.spinnerService.hide();
            if (response.body.status == 200) {
                this.appC.showSuccToast(response.message);
                this.activeTab = 'info';
                this.getprofile();
                this.header.getprofile();
            } else {
                this.appC.showErrToast(response.message);
            }
        }, error => {
            this.spinnerService.hide();
            this.appC.showErrToast(error.error.message);
        });
    }

    profilePic(event) {
        var self = this;
        let formData = new FormData();
        let count = 0
        if (event.target.files && event.target.files[0]) {
            var type = event.target.files[0].type;
            if (type === 'image/png' || type === 'image/jpg') {
                self.authObj.docFile = event.target.files[0].name;
                this.fileName = event.target.files[0];
                formData.append('file', this.fileName);
                var reader = new FileReader()
                reader.onload = (e) => {
                    self.fileData = e.target['result']
                    self.myImage = e.target['result'].substring(22);
                }
                reader.readAsDataURL(event.target.files[0]);
                count++;
            } else if (type === 'image/jpeg') {
                self.authObj.docFile = event.target.files[0].name;
                this.fileName = event.target.files[0];
                formData.append('file', this.fileName);
                var reader = new FileReader()
                reader.onload = (e) => {
                    self.fileData = e.target['result'];
                    self.myImage = e.target['result'].substring(23);
                }
                reader.readAsDataURL(event.target.files[0]);
                count++
            } else {
                this.appC.showErrToast("Please select png, jpeg and jpg format.");
                self.authObj.docFile = "";

            }
        }
        if (count != 0) {
            this.spinnerService.show();
            this.server.postApi('account/upload-file', formData, 1).subscribe(res => {
                this.spinnerService.hide();
                if (res.body.status == 200) {
                    this.imageUrl = res.body.data;
                }
                else {
                    this.appC.showErrToast('Please select valid file')
                }
            }, err => {
                this.spinnerService.hide();
                this.appC.showErrToast('Please select valid file')
            })

        }
    }

    backPage() {
        this.activeTab = 'info';
    }

    checkInputs() {
        this.changeForm = new FormGroup({
            password: new FormControl('', [Validators.required]),
            newPassword: new FormControl('', [Validators.required, Validators.pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})/i)]),
            confirmPassword: new FormControl('', [Validators.required]),
        }, passwordMatchValidator);
        /** Function for password match and mismatch */
        function passwordMatchValidator(g: FormGroup) {
            let pass = g.get('newPassword').value;
            let confPass = g.get('confirmPassword').value;
            if (pass != confPass) {
                g.get('confirmPassword').setErrors({ mismatch: true });
            } else {
                g.get('confirmPassword').setErrors(null)
                return null
            }
        }
    }

    /** Function for old password  and new password match and mismatch */
    passwordValidator() {
        this.check = true
        if (this.changeForm.value.newPassword != '') {
            if (this.changeForm.value.newPassword == this.changeForm.value.password)
                this.changeForm.get('newPassword').setErrors({ mismatch: true });
            else if (!this.numRegxForPattern.test(this.changeForm.value.newPassword)) {
                this.changeForm.get('newPassword').setErrors({ pattern: true });
            } else {
                this.changeForm.get('newPassword').setErrors(null)
                this.check = false
            }
        }
    }


    /** to get the value of field  */
    get password(): any {
        return this.changeForm.get('password');
    }
    get newPassword(): any {
        return this.changeForm.get('newPassword');
    }
    get confirmPassword(): any {
        return this.changeForm.get('confirmPassword');
    }

    /** to change password  */
    changePass() {
        let data = {
            "newPassword": this.changeForm.value.newPassword,
            "oldPassword": this.changeForm.value.password
        }
        this.spinnerService.show();
        this.server.postApi('account/change-password', data, localStorage.getItem('token')).subscribe(response => {
            this.spinnerService.hide();
            if (response.body.status == 200) {
                this.appC.showSuccToast(response.body.message);
                this.changeForm.reset();
                this.backPage();
            } else {
                this.appC.showSuccToast(response.body.message);
                this.changeForm.reset()
            }
        }, error => {
            this.spinnerService.hide();
            this.appC.showErrToast('Something went wrong');
        });
    }

    /** To validate inputs fields */
    checkInput() {
        this.kycDoc = new FormGroup({
            docNum: new FormControl('', [Validators.required]),
            docName: new FormControl('', [Validators.required]),
            attachmentfront: new FormControl('', [Validators.required]),
            attachmentback: new FormControl('', [Validators.required]),
        })
    }

    get docNum(): any {
        return this.kycDoc.get('docNum');
    }

    get docName(): any {
        return this.kycDoc.get('docName');
    }

    /**Function To upload front side of pic */
    handleFileInputFront(event) {
        var self = this;
        let formData = new FormData();
        //formData.append('file', this.image);
        if (event.target.files && event.target.files[0]) {
            var type = event.target.files[0].type;
            var size = event.target.files[0].size;
            let count = 0;
            if (size < 2000000) {
                if (type === 'image/png' || type === 'image/jpg') {
                    //self.authObj.docFile1 = event.target.files[0].name;
                    this.fileName1 = event.target.files[0];
                    formData.append('file', this.fileName1);
                    count++;
                } else if (type === 'application/pdf') {
                    this.fileName1 = event.target.files[0];
                    formData.append('file', this.fileName1);
                    count++;
                } else if (type === 'image/jpeg') {
                    this.fileName1 = event.target.files[0];
                    formData.append('file', this.fileName1);
                    count++;
                } else {
                    this.appC.showErrToast("Select only pdf, jpg, jpeg and png file.");
                    self.authObj.docFile1 = "";
                    self.fileData1 = "";
                    self.front = "assets/images/upload-icon.png";
                }
            } else {
                this.appC.showErrToast("Size should be less than 2 MB.");
                self.authObj.docFile1 = "";
                self.fileData1 = "";
                self.front = "assets/images/upload-icon.png";

            }
            if (count != 0) {
                this.spinnerService.show();
                this.server.postApi('account/upload-file', formData, 1).subscribe(res => {
                    this.spinnerService.hide();
                    if (res.body.status == 200) {
                        this.obj.attachmentDataFront = res.body.data;
                    }
                    else {
                        this.appC.showErrToast('Please select valid file')
                    }

                }, err => {
                    this.spinnerService.hide();
                    this.appC.showErrToast('Please select valid file');
                })
            }
        }
    }

    /**Function To upload back side of pic */

    handleFileInputBack(event) {
        var self = this;
        let formData = new FormData();
        if (event.target.files && event.target.files[0]) {
            var type = event.target.files[0].type;
            var size = event.target.files[0].size;
            let count = 0;
            if (size < 2000000) {
                if (type === 'image/png' || type === 'image/jpg') {
                    self.authObj.docFile2 = event.target.files[0].name;
                    this.fileName2 = event.target.files[0];
                    formData.append('file', this.fileName2);
                    count++;
                } else if (type === 'application/pdf') {
                    self.authObj.docFile2 = event.target.files[0].name;
                    this.fileName2 = event.target.files[0];
                    formData.append('file', this.fileName2);
                    count++;
                } else if (type === 'image/jpeg') {
                    self.authObj.docFile2 = event.target.files[0].name;
                    this.fileName2 = event.target.files[0];
                    formData.append('file', this.fileName2);
                    count++;
                } else {
                    this.appC.showErrToast("Select only pdf, jpg, jpeg and png file.");
                    self.authObj.docFile2 = "";
                    self.fileData2 = "";
                    self.back = "assets/images/upload-icon.png";
                }
            } else {
                this.appC.showErrToast("Size should be less than 2MB.");
                self.authObj.docFile2 = "";
                self.fileData2 = "";
                self.back = "assets/images/upload-icon.png";
            }
            if (count != 0) {
                this.spinnerService.show();
                this.server.postApi('account/upload-file', formData, 1).subscribe(res => {
                    this.spinnerService.hide();
                    if (res.status == 200) {
                        this.obj.attachmentDataBack = res.body.data;
                    }
                    else {
                        this.appC.showErrToast('Please select valid file')
                    }
                }, err => {
                    this.spinnerService.hide();
                    this.appC.showErrToast('Please select valid file')
                })
            }
        }
    }

    /**Function To upload selfie  */
    handleFileInputSelfie(event) {
        var self = this;
        if (event.target.files && event.target.files[0]) {
            var type = event.target.files[0].type;
            var size = event.target.files[0].size;
            if (size < 2000000) {
                if (type === 'image/png' || type === 'image/jpg') {
                    self.authObj.docFile3 = event.target.files[0].name;
                    this.fileName3 = self.authObj.docFile3;
                    var reader = new FileReader()
                    reader.onload = (e) => {
                        self.fileData3 = e.target['result'].substring(22);
                        self.selfie = e.target['result'];
                    }
                    reader.readAsDataURL(event.target.files[0]);
                } else if (type === 'application/pdf') {
                    self.authObj.docFile3 = event.target.files[0].name;
                    this.fileName3 = self.authObj.docFile3;
                    var reader = new FileReader()
                    reader.onload = (e) => {
                        self.fileData3 = e.target['result'].substring(28);
                        self.selfie = "assets/images/pdf.png";
                    }
                    reader.readAsDataURL(event.target.files[0]);
                } else if (type === 'image/jpeg') {
                    self.authObj.docFile3 = event.target.files[0].name;
                    this.fileName3 = self.authObj.docFile3;
                    var reader = new FileReader()
                    reader.onload = (e) => {
                        self.fileData3 = e.target['result'].substring(23);
                        self.selfie = e.target['result'];
                    }
                    reader.readAsDataURL(event.target.files[0]);
                } else {
                    this.appC.showErrToast("Select only pdf, jpg, jpeg and png file.");
                    self.authObj.docFile3 = "";
                    self.fileData3 = "";
                    self.selfie = "assets/images/upload-icon.png";
                }

            } else {
                this.appC.showErrToast("Size should be less than 2MB.");
                self.authObj.docFile3 = "";
                self.fileData3 = "";
                self.selfie = "assets/images/upload-icon.png";
            }
        }
    }

    /** Function to submit KYC documents  */
    submitDoc() {
        this.kycArr = [];
        if (this.kycDoc.get('docName').value == 'Passport') {
            if (this.fileData1 != 'undefined') {
                if (this.fileData1 != '') {
                    this.kycArr.push({
                        "number": this.kycDoc.value.docNum,
                        "name": this.kycDoc.get('docName').value,
                        "attachment": this.fileData1,
                        "category": 'front',
                        "level": 1
                    })
                }
            }
            if (this.fileData2 != 'undefined') {
                if (this.fileData2 != '') {
                    this.kycArr.push({
                        "number": this.kycDoc.value.docNum,
                        "name": this.kycDoc.get('docName').value,
                        "attachment": this.fileData2,
                        "category": 'back',
                        "level": 1
                    })
                }
            }
        } else if (this.kycDoc.get('docName').value == 'Driving Licence') {
            if (this.fileData1 != 'undefined') {
                if (this.fileData1 != '') {
                    this.kycArr.push({
                        "number": this.kycDoc.value.docNum,
                        "name": this.kycDoc.get('docName').value,
                        "attachment": this.fileData1,
                        "category": 'front',
                        "level": 2
                    })
                }
            }
            if (this.fileData2 != 'undefined') {
                if (this.fileData2 != '') {
                    this.kycArr.push({
                        "number": this.kycDoc.value.docNum,
                        "name": this.kycDoc.get('docName').value,
                        "attachment": this.fileData2,
                        "category": 'back',
                        "level": 2
                    })
                }
            }
        } else if (this.kycDoc.get('docName').value == 'National ID') {
            if (this.fileData1 != 'undefined') {
                if (this.fileData1 != '') {
                    this.kycArr.push({
                        "number": this.kycDoc.value.docNum,
                        "name": this.kycDoc.get('docName').value,
                        "attachment": this.fileData1,
                        "category": 'front',
                        "level": 3
                    })
                }
            }
            if (this.fileData2 != 'undefined') {
                if (this.fileData2 != '') {
                    this.kycArr.push({
                        "number": this.kycDoc.value.docNum,
                        "name": this.kycDoc.get('docName').value,
                        "attachment": this.fileData2,
                        "category": 'back',
                        "level": 3
                    })
                }
            }
        }

        /**KYC API */
        let data = {
            "document": [{
                "name": this.kycDoc.value.docName,
                "number": this.kycDoc.value.docNum,
                "backUrl": this.obj.attachmentDataBack,
                "frontUrl": this.obj.attachmentDataFront
            }]
        }
        this.spinnerService.show();
        this.server.postApi('account/save-kyc-details', data, localStorage.getItem('token')).subscribe(response => {
            if (response.status == 200) {
                this.appC.showSuccToast(response.message)
                this.spinnerService.hide();
                this.backPage();
            } else {
                this.appC.showErrToast(response.message);
            }
        }, error => {
            this.spinnerService.hide();
            this.appC.showErrToast(error.error.message);
        });
    }

    /** To check Kyc status */
    checkKycStatus() {
        this.kycArrList = [];
        this.kyc = [];
        this.front = '';
        this.back = '';
        this.selfie = '';
        this.spinnerService.show();
        this.server.getApi('account/get-kyc-details', localStorage.getItem('token')).subscribe(response => {
            this.spinnerService.hide();
            console.log(response)
            if (response.body.status == 200) {
                this.kyc = response.body.data;
                if (this.kyc.document.length == 0) {
                    this.front = "assets/images/upload-icon.png";
                    this.back = "assets/images/upload-icon.png";
                    this.selfie = "assets/images/upload-icon.png";
                    this.checkyc = true;
                } else {
                    this.checkyc = false;
                    this.kycArrList = this.kyc.document;
                }
            } else {
                this.appC.showErrToast(response.body.message);
            }
        }, error => {
            this.appC.showErrToast(error.error.message);
            this.spinnerService.hide();
        });
    }

    /**toggle management */
    changeToggle() {
        console.log(this.googleEnabled)
        if (this.googleEnabled == "GOOGLE") {
            this.qrCode.Code1 = "" ;
            $('#googleAuth').modal('show');
        } else if (this.googleEnabled == "SKIP") {
            this.request_google();
        }

    }

    disableTwoFa() {
        this.spinnerService.show();
        let data = {
            "code": this.qrCode.Code1
        }
        this.server.postApi('account/twoFa-disable', data, localStorage.getItem('token')).subscribe(res => {
            this.spinnerService.hide();
            if (res.body.status == 200) {
                $('#googleAuth').modal('hide');
                this.appC.showSuccToast("Google Authentication disabled successfully.");
                this.toggle.google = false;
            } else {
                this.qrCode.Code1 = "" ;
                this.toggle.google = true;
                this.appC.showErrToast('Please enter valid authentication code.');
            }
        }, err => {
            this.qrCode.Code1 = "" ;
            this.toggle.google = true;
            this.spinnerService.hide();
            this.appC.showErrToast(err.error.message);
        })

    }

    qrVerify() {
        let data = {
            "code": this.qrCode.Code1,
            "secretKey": localStorage.getItem('key')
        }
        this.spinnerService.show();
        this.server.postApi('account/verify-google-code', data, localStorage.getItem('token')).subscribe(response => {
            this.spinnerService.hide();
            if (response.body.status == 200) {
                $('#googleAuthModal').modal('hide');
                this.toggle.google = true;
                this.appC.showSuccToast("Google authentication enabled successfully.");
            } else {
                this.spinnerService.hide();
                this.appC.showErrToast("Please enter valid authentication code.");
                this.qrCode.Code1 = "" ;
                this.toggle.google = false;

            }
        }, error => {
            this.spinnerService.hide();
            this.appC.showErrToast(error.error.message);
            this.qrCode.Code1 = "" ;
            this.toggle.google = false;
        });
    }

    /**requesting google authentication  */
    request_google() {
        this.qrCode.Code1 = "" ;
        this.spinnerService.show();
        this.server.getApi('account/google-auth', localStorage.getItem('token')).subscribe(response => {
            this.spinnerService.hide();
            if (response.body.status == 200) {
                $('#googleAuthModal').modal({ backdrop: 'static', keyboard: false });
                localStorage.setItem('key', response.body.data.secretKey);
                this.myAngularxQrCode = response.body.data.qrCode;
            } else {
                this.appC.showErrToast(response.body.message);
            }
        }, error => {
            this.spinnerService.hide();
            this.appC.showErrToast(error.error.message);
        });
    }

    /** Toggle management on closing modal by clicking on close button */
    closeModal() {
        $('#googleAuthModal').modal('hide');
        $('#googleAuth').modal('hide');
        this.getprofile();
    }

    /**FUNCTION TO RE-UPLOAD IMAGE */
    upload() {
        this.uploadArr = [];
        if (this.fileData4 == '')
            this.appC.showErrToast("Please upload image.");
        else {
            if (this.attachmentUpload.category == 'front') {
                this.uploadArr.push({
                    "number": this.attachmentUpload.number,
                    "attachment": this.fileData4,
                    "level": 1,
                    "category": 'front'

                });
            } else if (this.attachmentUpload.category == 'selfie') {
                this.uploadArr.push({
                    "number": this.attachmentUpload.number,
                    "attachment": this.fileData4,
                    "level": 3,
                    "category": 'selfie'

                });
            } else if (this.attachmentUpload.category == 'back') {
                this.uploadArr.push({
                    "number": this.attachmentUpload.number,
                    "attachment": this.fileData4,
                    "level": 2,
                    "category": 'back'
                });
            }
            let data = {
                "eventExternal": {
                    "name": "request_update_particular_kyc_detail",
                    "key": "mykey"
                },
                "transferObjectMap": {
                    "gatewayrequest": {
                        "token": localStorage.getItem("token"),
                        "kycId": this.attachmentUpload.id,
                        "proofAttachment": this.fileData4,
                    }
                }
            }

            this.spinnerService.show();
            this.server.postApi('', data, 0).subscribe(response => {
                if (response.transferObjectMap.statusCode == 200) {
                    this.appC.showSuccToast("Image uploaded successfully");
                    this.checkKycStatus();
                    this.spinnerService.hide();
                } else if (response.transferObjectMap.statusCode == 403) {
                    this.header.tokenExpire();
                } else {
                    this.appC.showErrToast(response.transferObjectMap.message);
                }
            }, error => {
                this.spinnerService.hide();
                this.appC.showErrToast('Something went wrong');
            });
        }



    }

    /**Function To reupload pic */
    imageUpload(event) {
        var self = this;
        if (event.target.files && event.target.files[0]) {
            var type = event.target.files[0].type;
            var size = event.target.files[0].size;
            if (size < 2000000) {
                if (type === 'image/png' || type === 'image/jpg') {
                    self.authObj.docFile4 = event.target.files[0].name;
                    self.fileName4 = self.authObj.docFile2;
                    var reader = new FileReader()
                    reader.onload = (e) => {
                        self.fileData4 = e.target['result'].substring(22);
                        this.upload();
                    }
                    reader.readAsDataURL(event.target.files[0]);
                } else if (type === 'application/pdf') {
                    self.authObj.docFile4 = event.target.files[0].name;
                    self.fileName4 = self.authObj.docFile2;
                    var reader = new FileReader()
                    reader.onload = (e) => {
                        self.fileData4 = e.target['result'].substring(28);
                        this.upload();
                    }
                    reader.readAsDataURL(event.target.files[0]);
                } else if (type === 'image/jpeg') {
                    self.authObj.docFile4 = event.target.files[0].name;
                    this.fileName4 = self.authObj.docFile2;
                    var reader = new FileReader()
                    reader.onload = (e) => {
                        self.fileData4 = e.target['result'].substring(23);
                        this.upload();
                    }
                    reader.readAsDataURL(event.target.files[0]);
                } else {
                    this.appC.showErrToast("Select only pdf, jpg, jpeg and png file.");
                    self.authObj.docFile4 = "";
                    self.fileData4 = "";
                }
            } else {
                this.appC.showErrToast("Size should be less than 2MB.");
                self.authObj.docFile4 = "";
                self.fileData4 = "";
                self.fileName4 = "";
            }

        }
    }

    imageData(category, number, id) {
        this.attachmentUpload.category = category;
        this.attachmentUpload.number = number;
        this.attachmentUpload.id = id;
    }
}
