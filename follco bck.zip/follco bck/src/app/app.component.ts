import { Component ,ViewChild} from '@angular/core';
import { Nav,Platform, ToastController, NavController, App } from 'ionic-angular';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { LoginPage } from '../pages/login/login';
import { ForgotPage } from '../pages/forgot/forgot';
import { SignupPage } from '../pages/signup/signup';
import { HomePage } from '../pages/home/home';
import { SettingPage } from '../pages/setting 3/setting';
import { ChangepassPage } from '../pages/changepass/changepass';
import { TabsPage } from '../pages/tabs/tabs';
import { EmailCampaingsPage } from '../pages/email-campaings/email-campaings';
import { ViewEmailCampaingPage } from '../pages/view-email-campaing/view-email-campaing';
import { SmsCampaignPage } from '../pages/sms-campaign/sms-campaign';
import { SmsCampaignListPage } from '../pages/sms-campaign-list/sms-campaign-list';
import { TimelinePostPage } from '../pages/timeline-post/timeline-post';
import { TabsScreensPage } from '../pages/tabs-screens/tabs-screens';
import { Network } from '@ionic-native/network';
import { RestProvider } from '../providers/rest/rest';
import { CusttabPage } from '../pages/custtab/custtab';


@Component({
  templateUrl: 'app.html'
})
export class MyApp {
  @ViewChild(Nav) nav: Nav;
  rootPage:any ;
  counter = 0;
  pages: Array<{title: string, component: any}>;
  type: any;
  // || this.nav.getActive().name == 'TabsScreensPage'
  constructor(platform: Platform, statusBar: StatusBar, splashScreen: SplashScreen, public globalServ : RestProvider,  public app :App,public network: Network,public toastCtrl:ToastController) {
    platform.ready().then(() => {
      this.checkNetworkConnection();
      this.checkLoggedInFunc();      
      platform.registerBackButtonAction(()=>{
          const overlayView = this.app._appRoot._overlayPortal._views[0];
          if (overlayView && overlayView.dismiss) {
            overlayView.dismiss();
          }
        if(this.nav.getActive().name == 'LoginPage'||this.nav.getActive().name == 'HomePage'||this.nav.getActive().name == 'BusinessHomePage'){
          if(this.counter == 0){
            this.counter++;
            this.myHandlerFunction();
            setTimeout(() => { this.counter = 0 }, 3000)
          }else{
            platform.exitApp();
          }
        }
        else if(this.nav.getActive().name == 'EmailCampaingsPage' ||  
        this.nav.getActive().name == 'SmsCampaignPage' ||  
        this.nav.getActive().name == 'TimelinePostPage' ||  
        this.nav.getActive().name == 'FollowingPage' || 
        this.nav.getActive().name == 'ViewEmailCampaingPage' ||
        this.nav.getActive().name == 'TimelinePostViewPage' ||
        this.nav.getActive().name == 'SmsCampaignListPage' || 
        this.nav.getActive().name == 'FollowingproPage' ||
        this.nav.getActive().name == 'ChangepassPage' ||
        this.nav.getActive().name == 'CrmInvoicesPage' ||
        this.nav.getActive().name == 'CrmInvoicesViewPage' ||
        this.nav.getActive().name == 'CrmProductsviewPage' ||
        this.nav.getActive().name == 'CrmProductsPage' ||
        this.nav.getActive().name == 'CrmLeadsPage' ||
        this.nav.getActive().name == 'CrmFollowersPage'||
         this.nav.getActive().name == 'CrmCutomersPage' ||
         this.nav.getActive().name ==  'SettingPage' ||
         this.nav.getActive().name ==  'MySettingsPage' || 
         this.nav.getActive().name == 'LeadPage'||
         this.nav.getActive().name == 'SettingprivacyPage'||
         this.nav.getActive().name =='CrmPage' ||
         this.nav.getActive().name =='DiscoverPage' ||
         this.nav.getActive().name =='CreateleadsPage' || 
         this.nav.getActive().name =='EditleadscustomerPage'||
         this.nav.getActive().name =='CrmfollowersViewPage'||
         this.nav.getActive().name =='CrMcreateeventPage'||
         this.nav.getActive().name =='CrMediteventPage'||
         this.nav.getActive().name =='CrmEventsViewPage'||
         this.nav.getActive().name =='CustomerLeadsSingleViewPage'||
         this.nav.getActive().name =='DashboardPage'||
         this.nav.getActive().name == 'DashboardcustPage'||
         this.nav.getActive().name ==  'ViewPage'||
         this.nav.getActive().name == 'NewPage'||
         this.nav.getActive().name =='EditadvancedpostsPage'||
         this.nav.getActive().name =='HairstylePage'||
         this.nav.getActive().name =='ViewslidepostsPage'||
         this.nav.getActive().name =='ModalPage'
        ){
            this.nav.pop();
          }
        
      
      });
      statusBar.styleDefault();
      splashScreen.hide();      
    });
    // this.pages = [
    //   { title: 'setting', component: SettingPage },
    //   { title: 'forgotpassword', component: ForgotPage },
    //   { title: '', component: LoginPage },
    //   { title: 'Signup', component: SignupPage },     
    //   { title: 'Home', component: HomePage },
    // ];
  }


  checkLoggedInFunc(){    
      if(localStorage.getItem('isLoggedIn') ==  'true'){
        this.type = localStorage.getItem('modeType');
            console.log(this.type);
           
            if(this.type == 'customer'){
              // this.navCtrl.setRoot(CusttabPage); 
              this.rootPage = CusttabPage ;
            }
            else if(this.type == 'business'){
              this.rootPage = TabsScreensPage
            }
        
      }else {
        this.rootPage = LoginPage
      }
  }

  checkNetworkConnection(){
    this.globalServ.netWorkStatus = navigator.onLine;
    console.log('CheckingInternetConnection')
   this.network.onDisconnect().subscribe(() => {
      console.log('network was disconnected');
      this.globalServ.netWorkStatus = false;
    });
    // watch network for a connection
     this.network.onConnect().subscribe((res) => {
      console.log(res)    
      this.globalServ.netWorkStatus = true;
    });  
    console.log(this.globalServ.netWorkStatus);
  }


  myHandlerFunction(){
    let toast = this.toastCtrl.create({
     message: "Press again to confirm exit",
     duration: 3000
   });
   toast.present(); 
    }

  // openPage(page) {
  //   // Reset the content nav to have just this page
  //   // we wouldn't want the back button to show in this scenario
  //   this.nav.setRoot(page.component);
  // }
}
