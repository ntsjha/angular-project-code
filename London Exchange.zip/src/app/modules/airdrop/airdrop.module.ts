import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AirdropComponent } from './airdrop/airdrop.component';

@NgModule({
    imports: [
        CommonModule
    ],
    declarations: [AirdropComponent]
})
export class AirdropModule { }
