import { Component, OnInit } from '@angular/core';
import { ServiceService } from 'src/app/Shared/service.service';
import { Router, ActivatedRoute } from '@angular/router';
import { formatDate } from '@angular/common';

import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-edit-static-content',
  templateUrl: './edit-static-content.component.html',
  styleUrls: ['./edit-static-content.component.css']
})
export class EditStaticContentComponent implements OnInit {
  public editorValue: string = '';
  contentname: any;
  docname: any;
  editdescription: FormGroup;
  constructor(public router: Router, private firebaseServ: ServiceService, public route: ActivatedRoute) { }

  ngOnInit() {
    this.route.queryParams.subscribe((res) => {
      console.log('params--->>> ', res);

      this.contentname = res.value
      this.docname = res.docname
    })

    this.getstaticContent()

    this.editdescription = new FormGroup({
      editvalue: new FormControl('', [Validators.required, Validators.maxLength(30000)]),
      title: new FormControl('', [Validators.required, Validators.pattern(/^[^-\s][a-zA-Z0-9_&?\s-]*$/),Validators.maxLength(50)])
    })
  }


  getstaticContent() {
    this.firebaseServ.showSpinner();
    this.firebaseServ.getStaticContentFunc(this.docname).then(res => {

      setTimeout(() => {
        this.firebaseServ.hideSpinner();
        this.editdescription.patchValue({
          editvalue: res.Description,
          title: res.Title


        })
        console.log('staticContentdata', this.editdescription.value.editvalue)
        // this.editorValue = res.Description       
      }, 2000)

    }).catch(err => {
      console.log(err)
    })

  }

  UpdateStaticdata() {

    var time = formatDate(new Date(), 'yyyy/MM/dd h:mm:ss', 'en');
    console.log('data==>', time, this.editdescription.value.editvalue)
    this.firebaseServ.UpdatestaticContent(this.docname, this.editdescription.value.editvalue, this.editdescription.value.title, time).then(res => {

      this.firebaseServ.showSuccess('Static content has been updated successfully.');
    });
    this.router.navigate(['/static-content/view-static-content/id'], {
      queryParams: { value: this.editdescription.value.title, docname: this.docname }
    })
  }

  backtostaticview() {
    this.router.navigate(['/static-content'])
  }


preventSpace(event){
  if(event.charCode==32 && !event.target.value){
  event.preventDefault()
  } else{
  console.log(event)
  }
  console.log('event',event.charCode)
  }

}

