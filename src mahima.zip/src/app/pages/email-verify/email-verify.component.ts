import { MainServiceService } from './../../main-service.service';
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-email-verify',
  templateUrl: './email-verify.component.html',
  styleUrls: ['./email-verify.component.css']
})
export class EmailVerifyComponent implements OnInit {
  emailVerify:any
  constructor(public service:MainServiceService, public router:Router) { }

  ngOnInit() {
    this.emailVerify=new FormGroup({
      emailOtp:new FormControl('',[Validators.required])
    })
  }

  optVerify(){
      let data={'otp':this.emailVerify.value.emailOtp}
      this.service.post('user/otpVerify',data,1).subscribe(res=>{
        
        if(res['responseCode']==200){
           this.router.navigate(['login'])
        }
      },err=>{
        console.log(err)
      })
   }
   resend(){

   }

}
