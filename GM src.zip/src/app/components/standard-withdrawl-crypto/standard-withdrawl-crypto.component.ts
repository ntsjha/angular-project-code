import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ServiceService } from 'src/app/service/service.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { ActivatedRoute, Router } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'app-standard-withdrawl-crypto',
  templateUrl: './standard-withdrawl-crypto.component.html',
  styleUrls: ['./standard-withdrawl-crypto.component.css']
})
export class StandardWithdrawlCryptoComponent implements OnInit {
  cryptoFunction: FormGroup;
  currentUser: any;
  coinName: any;
  cryptoFiat: any;
  userIp: any;
  response: any = { 'message': '' };

  constructor(
    private service: ServiceService,
    private spinner: NgxSpinnerService,
    private activatedRoute: ActivatedRoute,
    private route: Router,
    private cookie: CookieService) {
    this.cryptoFunction = new FormGroup({
      fee: new FormControl(null, [Validators.required, Validators.maxLength(8),Validators.pattern(/^^\d+(\.\d{1,8})*$/)]),

    });

    this.service.currentUserInfo.subscribe((response) => {
      this.currentUser = response;
    });
    this.userIp = (this.cookie.get('userInfo')) ? JSON.parse(this.cookie.get('userInfo')) : this.service.initialUserInfo;
  }

  ngOnInit() {
    this.activatedRoute.params.subscribe(id => {
      this.coinName = id.id;
    });
    this.stdWithdrawlCrypto();
    
    window.scrollTo(0, 0);
  }

  stdWithdrawlCrypto() {
    this.spinner.show();
    this.service.getMethod('wallet/admin/fees/get-fee-details?currencyName=' + this.coinName + '&currencyType=crypto', 1).subscribe((response: any) => {
      this.spinner.hide();
      response = JSON.parse(this.service.decrypt(response.data))
      if (response.status === 845 || response.status === 842) {
        this.cryptoFiat = response.data;
        this.loadform();
      }
    }, (error) => {
      this.spinner.hide();
    });
    this.spinner.hide();

  }


  loadform() {
    this.cryptoFunction.patchValue({
      fee: this.cryptoFiat.stdWithdrawalFee
    });
  }


  withdrawlCrypto() {
    this.spinner.show();
    const data = {
      amount: this.cryptoFunction.value.fee,
      coinName: this.coinName,
      ipAddress: this.userIp.ip,     
      location: this.userIp.city + ',' + this.userIp.country_name
    };

    this.service.postMethod('wallet/admin/fees/set-std-crypto-withdraw-fee', data, 1).subscribe((response: any) => {
      this.spinner.hide();
      if (response.status === 843 || response.status === 842) {
        this.route.navigate(['/standard-withdrawl']);
      } else {
        this.response = response;
      }
    }, (error) => {
      this.spinner.hide();
    });
  }

}
