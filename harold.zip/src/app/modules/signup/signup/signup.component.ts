import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ServerService } from '../../../server.service';
import { AppComponent } from '../../../app.component';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
declare var $: any;
@Component({
    selector: 'app-signup',
    templateUrl: './signup.component.html',
    styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
    myCode: any;
    countryData: any;
    signupForm: FormGroup;
    websiteURL2: string;
    refStatus = false;

    constructor(public router: Router, private server: ServerService, private appC: AppComponent, private spinnerService: Ng4LoadingSpinnerService) { }

    ngOnInit() {
        window.scrollTo(0,0);
        this.websiteURL2= this.server.websiteURL + '/TermsAndConditions'
         /**Code snippet for country code */
         $("#phone").intlTelInput({
            autoPlaceholder: true,
            autoFormat: false,
            autoHideDialCode: false,
            initialCountry: 'in',
            nationalMode: false,
            onlyCountries: [],
            preferredCountries: ["us"],
            formatOnInit: true,
            separateDialCode: true
        });
        this.checkInputs();
        this.checkRefCode();
    }

    /** Function for check ref code in url */
    checkRefCode() {
        let url = window.location.href.split('/');
        let code = url[url.length - 1];
        if(code == "newUser") {
           this.refStatus = false; 
        } else {
            this.refStatus = true;
            this.signupForm.controls['refCode'].setValue(code);
        }
    }

    /** To navigate to login page */
    login() {
        this.router.navigateByUrl('login');
    }

    term() {
        this.router.navigateByUrl('term');
    }

    /** Function to validate form inputs */
    checkInputs() {
        this.signupForm = new FormGroup({
            semail: new FormControl('', [Validators.required, Validators.pattern(/^[A-Z0-9_]+([\.-][A-Z0-9_]+)*@[A-Z0-9-]+(\.[a-zA-Z]{2,12})+$/i)]),
            password: new FormControl('', [Validators.required, Validators.pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})/i)]),
            name: new FormControl('', [Validators.required, Validators.minLength(2), Validators.pattern(/^[a-zA-Z ]*$/i)]),
            lastname: new FormControl('', [Validators.required, Validators.minLength(2), Validators.pattern(/^[a-zA-Z ]*$/i)]),
            agree: new FormControl('', [Validators.required]),
            phone: new FormControl('', [Validators.required, Validators.minLength(7), Validators.pattern(/^[1-9]{1}[0-9]*$/), Validators.maxLength(14), Validators.minLength(7)]),
            confirmPassword: new FormControl('', [Validators.required]),
            refCode: new FormControl(''),
        }, passwordMatchValidator);
        /** Function for password match and mismatch */
        function passwordMatchValidator(g: FormGroup) {
            let pass = g.get('password').value;
            let confPass = g.get('confirmPassword').value;
            if (pass != confPass) {
                g.get('confirmPassword').setErrors({ mismatch: true });
            } else {
                g.get('confirmPassword').setErrors(null)
                return null
            }
        }
    }

    /** to get the value of field  */
    get semail(): any {
        return this.signupForm.get('semail');
    }
    get password(): any {
        return this.signupForm.get('password');
    }
    get confirmPassword(): any {
        return this.signupForm.get('confirmPassword');
    }
    get name(): any {
        return this.signupForm.get('name');
    }

    get lastname(): any {
        return this.signupForm.get('lastname');
    }
    get phone(): any {
        return this.signupForm.get('phone');
    }
    get refCode(): any {
        return this.signupForm.get('refCode');
    }



    signUp() { 
        if(this.signupForm.value.refCode != '' && this.signupForm.value.refCode != null) {
            let data = {
                "referrerCode"  : this.signupForm.value.refCode,
            }
            this.spinnerService.show();
            this.server.postApi('reference-service/check-referrer-code',data).subscribe((succ) => {
                this.spinnerService.hide();
                if (succ.status == 200) {
                    this.countryData = $("#phone").intlTelInput("getSelectedCountryData");
                    this.myCode = this.countryData.dialCode;
                    this.spinnerService.show();
                    let data = {
                        "email": this.signupForm.value.semail,
                        "firstName": this.signupForm.value.name,
                        "lastName":this.signupForm.value.lastname,
                        "country":'',
                        "password": this.signupForm.value.password,
                        "phoneNo": '+'+this.myCode+this.signupForm.value.phone,
                        "webUrl": this.server.websiteURL+"/login",
                        "referrerCode": this.signupForm.value.refCode,
                    }
                    localStorage.setItem('email', this.signupForm.value.semail)
                    this.server.postApi('account/signup', data).subscribe((res) => {
                        this.spinnerService.hide();
                        if (res.status == 200) {
                            this.router.navigateByUrl('emailverify/signup');
                            this.appC.showSuccToast("User registered successfully");

                        }
                        else {
                            this.appC.showErrToast(res.message);
                        }
                        
                    }, (err) => {
                        this.spinnerService.hide();
                        this.appC.showErrToast(err.error.message)
                    })
                } else if(succ.status == 201 || succ.status == 205){
                    this.appC.showErrToast(succ.message);
                    return;
                }
            }, (err) => {
                this.spinnerService.hide();
                this.appC.showErrToast(err.error.message);
                return;
            });
        } else {
            this.countryData = $("#phone").intlTelInput("getSelectedCountryData");
            this.myCode = this.countryData.dialCode;
            this.spinnerService.show();
            let data = {
                "email": this.signupForm.value.semail,
                "firstName": this.signupForm.value.name,
                "lastName":this.signupForm.value.lastname,
                "country":'',
                "password": this.signupForm.value.password,
                "phoneNo": '+'+this.myCode+this.signupForm.value.phone,
                "webUrl": this.server.websiteURL+"/login",
                "referrerCode": this.signupForm.value.refCode,
            }
            this.server.postApi('account/signup', data).subscribe((res) => {
                localStorage.setItem('email', this.signupForm.value.semail)
                this.spinnerService.hide();
                if (res.status == 200) {
                    this.router.navigateByUrl('emailverify/signup');
                    this.appC.showSuccToast("User registered successfully");

                }
                else {
                    this.appC.showErrToast(res.message);
                }
                
            }, (err) => {
                this.spinnerService.hide();
                this.appC.showErrToast('Something went wrong')
            })
        }
    }

    /** Function for get user's reference data */
    validateReferralCode() {
        let data = {
            "userId"  : localStorage.getItem('userId')
        }
        this.spinnerService.show();
        this.server.postApi('reference-service/bounty-record',data).subscribe((succ) => {
            this.spinnerService.hide();
            if (succ.status == 200) {
            } else {
                this.appC.showErrToast(succ.message);
            }
        }, (err) => {
            this.spinnerService.hide();
            this.appC.showErrToast(err.error.message);
        });
    }
}
