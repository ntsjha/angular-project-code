import { BrowserModule } from '@angular/platform-browser';
import { NgModule, ApplicationRef } from '@angular/core';

import { AppComponent } from './app.component';
import { SignupComponent } from './signup/signup.component';
import { AddressComponent } from './address/address.component';
import { AppRoutingModule } from './app-routing.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { AgmCoreModule } from '@agm/core';
import { CommonModule } from '@angular/common';
import { ServeService } from './serve.service';
import { HttpModule } from '@angular/http';
import { GooglePlaceModule } from "ngx-google-places-autocomplete";
import { StudentComponent } from './student/student.component';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { StudentlistComponent } from './student/studentlist/studentlist.component';
import { StudentMapComponent } from './student/student-map/student-map.component';
import { AddstudentComponent } from './student/addstudent/addstudent.component';
import { ProfileComponent } from './profile/profile.component';
import { ActiveGuard } from './active.guard';

@NgModule({
  declarations: [
    AppComponent,
    SignupComponent,
    AddressComponent,
    StudentComponent,
    LoginComponent,
    DashboardComponent,
    StudentlistComponent,
    StudentMapComponent,
    AddstudentComponent,
    ProfileComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    CommonModule,
    FormsModule,
    HttpModule,
    GooglePlaceModule,
    AgmCoreModule.forRoot({
      apiKey: 'AIzaSyCm8rnRUZU0ecO8hpCF3KVANv9LmAXv0hc'
    })
  ],
  providers: [ActiveGuard,ServeService],
  bootstrap: [AppComponent],
  exports: [FormsModule]
})
export class AppModule { }
