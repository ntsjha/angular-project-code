import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '../../../../../node_modules/@angular/forms';
import { Ng4LoadingSpinnerService } from '../../../../../node_modules/ng4-loading-spinner';
import { HeaderComponent } from '../../header/header/header.component';
import { AppComponent } from '../../../app.component';
import { ServerService } from '../../../service/server.service';
import { Router } from '../../../../../node_modules/@angular/router';

@Component({
    selector: 'app-reset',
    templateUrl: './reset.component.html',
    styleUrls: ['./reset.component.css']
})
export class ResetComponent implements OnInit {
    resetForm: FormGroup;
    page: string;
    constructor(private spinnerService :Ng4LoadingSpinnerService, private router: Router, private header:HeaderComponent, private appC:AppComponent ,private server:ServerService) { }

    ngOnInit() {
        window.scrollTo(0, 0);
        let url = window.location.href.split('?');
        this.page = url[url.length - 1];
        this.checkInputs();
    }

    checkInputs() {
        this.resetForm = new FormGroup ({
            newpassword: new FormControl('', [Validators.required, Validators.pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})/i)]),
            confrmpassword: new FormControl('', [Validators.required]),
        }, passwordMatchValidator);
        /** Function for password match and mismatch */
        function passwordMatchValidator(g: FormGroup) {
            let pass = g.get('newpassword').value;
            let confPass = g.get('confrmpassword').value;
            if (pass != confPass) {
                g.get('confrmpassword').setErrors({ mismatch: true });
            } else {
                g.get('confrmpassword').setErrors(null)
                return null
            }
        }
    }

    get newpassword(): any {
        return this.resetForm.get('newpassword');
    }

    get confrmpassword(): any {
        return this.resetForm.get('confrmpassword');
    }

    resetPassword() {
        let data = {          
            "password": this.resetForm.value.newpassword,
             "token": this.page
        }
        this.spinnerService.show();
        this.server.postApi('account/reset-password', data,0).subscribe(response => {
            this.spinnerService.hide();
            if (response.status == 200) {
                this.appC.showSuccToast("Password changed successfully.");
                this.router.navigate(['header']);    
            } else {
                this.appC.showErrToast(response.body.message);
                
            }
        }, error => {
            this.spinnerService.hide();
            this.appC.showErrToast(error.error.message);
        });
    }

}
