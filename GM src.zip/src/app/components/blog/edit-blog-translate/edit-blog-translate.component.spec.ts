import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditBlogTranslateComponent } from './edit-blog-translate.component';

describe('EditBlogTranslateComponent', () => {
  let component: EditBlogTranslateComponent;
  let fixture: ComponentFixture<EditBlogTranslateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditBlogTranslateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditBlogTranslateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
