import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OperationKycComponent } from './operation-kyc.component';

describe('OperationKycComponent', () => {
  let component: OperationKycComponent;
  let fixture: ComponentFixture<OperationKycComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OperationKycComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OperationKycComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
