export class HorseContacts{
    id:string
    s_no:string
    first_Name:string
    last_Name:string
    type:string
    email:string
    mobile_No:string
    address:string
}