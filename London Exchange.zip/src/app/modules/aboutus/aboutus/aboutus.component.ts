import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ServerService } from '../../../service/server.service';
import { AppComponent } from '../../../app.component';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';

@Component({
    selector: 'app-aboutus',
    templateUrl: './aboutus.component.html',
    styleUrls: ['./aboutus.component.css']
})
export class AboutusComponent implements OnInit {
    pageData = "";

    constructor(private router: Router , private server: ServerService , private appC: AppComponent, private spinnerService: Ng4LoadingSpinnerService) { }

    ngOnInit() {
        window.scrollTo(0,0);
        this.getContentFromAPI();
    }

    /** Function to fetch data from api */
    getContentFromAPI() {
        
         
        this.spinnerService.show();
        this.server.getApi('static/get-static-content?pageKey=Aboutus',0).subscribe((succ) => {
            this.spinnerService.hide();
            if (succ.body.status == 200) {
                this.pageData = succ.body.data.pageData;
            } else {
                this.pageData = "";
            }
        }, (err) => {
            this.spinnerService.hide();
            this.appC.showErrToast("Something went wrong.");
        });
    }
}
