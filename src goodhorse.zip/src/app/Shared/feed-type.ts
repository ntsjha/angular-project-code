export class FeedType {
    id: string;
   


}


export class StaticContent {
    id: string;
    Lastupdate:string;
    Title:string;
    Description:string;

}

export class StaticContentFAQ {
    id:string;
    Answer: string;
    Question:string;
    Lastupdate:string


}


export class Featurelist {
    id:string;
    Title: string;
    Description:string;
    Lastupdate:string
    Image:string


}


export class UserGuide {
    id:string;
    Title: string;
    Lastupdate:string
    VideoUrl:string


}



