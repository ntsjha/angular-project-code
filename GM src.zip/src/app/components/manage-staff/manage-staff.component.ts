import { Component, OnInit, OnDestroy } from '@angular/core';
import { ServiceService } from 'src/app/service/service.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { IMyDpOptions } from 'mydatepicker';
import { FormGroup, FormControl } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { DatePipe } from '@angular/common';
import { AppComponent } from 'src/app/app.component';
import { DeviceDetectorService } from 'ngx-device-detector';

declare var $: any;

@Component({
    selector: 'app-manage-staff',
    templateUrl: './manage-staff.component.html',
    styleUrls: ['./manage-staff.component.css']
})
export class ManageStaffComponent implements OnInit, OnDestroy {
    toDateInTimestamp: any = 0;
    fromDateInTimestamp: any = 0;
    google: any = { one: '', two: '', three: '', four: '', five: '', six: '' };
    getStaff: any = [];
    total: number;
    page: any = 0;
    currentId: any;
    filterFunction: FormGroup;
    p: any;
    permission: any;
    rolesArr = [];
    showApiMessage = false;
    response: any;
    subscription: any;
    englishShortCode: any;
    currentUser: any;
    browser:any;
    public fromPickerOptions: IMyDpOptions = {
        disableSince: { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() + 1 },
        dateFormat: 'dd/mm/yyyy',
    };
    public toPickerOptions: IMyDpOptions = {
        disableSince: { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() + 1 },
        dateFormat: 'dd/mm/yyyy',
    };

    constructor(private service: ServiceService, private spinner: NgxSpinnerService, private deviceService: DeviceDetectorService, private router: Router, public datepipe: DatePipe, activatedRoute: ActivatedRoute, private appC: AppComponent) {
        this.permission = activatedRoute.snapshot.data[`menuName`];
        this.filterFunction = new FormGroup({
            search: new FormControl(null),
            status: new FormControl(null),
            role: new FormControl(null),
            fromDate: new FormControl(null),
            toDate: new FormControl(null),
        });
        this.subscription = this.service.authVerify.subscribe(val => {
            if (val === 'delete-staff') {
                this.deleteStaff();
                this.service.authVerify.next('false');
            }
        });
        this.service.currentUserInfo.subscribe((response) => {
            this.currentUser = response;
        });
        this.getUserAgent();
    }

    ngOnInit() {
        this.getRoles();
        this.getStaffList();
        window.scrollTo(0, 0);
    }
    getUserAgent() {
        const sUsrAg = this.deviceService.getDeviceInfo().userAgent;
        if (sUsrAg.indexOf('Firefox') > -1) {
            this.browser = 'Mozilla Firefox';
        } else if (sUsrAg.indexOf('Opera') > -1 || sUsrAg.indexOf('OPR') > -1) {
            this.browser = 'Opera';
        } else if (sUsrAg.indexOf('Trident') > -1) {
            this.browser = 'Microsoft Internet Explorer';
        } else if (sUsrAg.indexOf('Edge') > -1) {
            this.browser = 'Microsoft Edge';
        } else if (sUsrAg.indexOf('Chrome') > -1) {
            this.browser = 'Google Chrome or Chromium';
        } else if (sUsrAg.indexOf('Safari') > -1) {
            this.browser = 'Apple Safari';
        } else {
            this.browser = 'unknown';
        }
    }

    ngOnDestroy() {
        this.subscription.unsubscribe();
    }

    openGoogleAuth() {
        $('#deleteStaff').modal('hide');
        this.appC.google = { one: '', two: '', three: '', four: '', five: '', six: '' };
        this.appC.response = { message: '' };
        this.service.googleAuthCalledFrom = 'delete-staff';
        $('#google-auth-modal').modal({ keyboard: false, backdrop: 'static' });
    }

    convertFormat(time) {
        if (time != null) {
            return this.datepipe.transform(time, 'MM/dd/yyy, hh:mm a');
        }
    }

    exportData() {
        this.service.getMethod('account/common-permit/export-customer-data-list?findBy=STAFF', 1).subscribe((response: any) => {
            if (response.status === 2500) {
                if (response.data.length > 0) {
                    const data = [];
                    response.data.forEach((ele) => {
                        data.push({
                            'First Name': ele.firstName,
                            'Last Name': ele.lastName,
                            Email: ele.email,
                            Phone: ele.phoneNo,
                            'Created By': (ele.createdBy != null) ? ele.createdBy : '',
                            'Created At': (ele.createdAt != null) ? this.convertFormat(ele.createdAt) : '',
                            'Updated By': (ele.updatedBy != null) ? ele.updatedBy : '',
                            Role: (ele.role != null) ? ele.role : '',
                            Status: (ele.userStatus != null) ? ele.userStatus : '',
                        });
                    });
                    this.service.exportAsExcelFile(data, 'Staff List');
                }
            }
        }, () => {
            this.spinner.hide();
        });
    }
    // Auto focus functionality
    onKey(event, next, previous) {
        if (event.key === 'Backspace') {
            document.getElementById(previous).focus();
        } else {
            if (event.keyCode >= 48 && event.keyCode <= 57) {
                if (event.target.value.trim() !== '') {
                    document.getElementById(next).focus();
                } else {
                    event.target.value = '';
                }
            } else {
                event.target.value = '';
            }
        }
    }

    searchStaff() {
        this.page = 0;
        this.getStaffList();
    }
    
    getStaffList() {
        this.getStaff = [];
        this.total = 0;
        this.spinner.show();
        const data = {
            page: this.service.encrypt(String(this.page)),
            pageSize: this.service.encrypt('10'),
            search: (this.filterFunction.value.search != null) ? this.service.encrypt(this.filterFunction.value.search.trim()) : null,
            fromDate: this.filterFunction.value.fromDate ? (this.filterFunction.value.fromDate.epoc ? this.service.encrypt(this.filterFunction.value.fromDate.epoc * 1000) : null) : null,
            toDate: this.filterFunction.value.toDate ? (this.filterFunction.value.toDate.epoc ? this.service.encrypt((this.filterFunction.value.toDate.epoc * 1000) + (86400000 - 1)) : null) : null,
            status: (this.filterFunction.value.status) ? (this.filterFunction.value.status !== 'null' ? this.service.encrypt(this.filterFunction.value.status) : null) : null,
            role: (this.filterFunction.value.role != null) ? (this.filterFunction.value.role !== 'null' ? this.service.encrypt(this.filterFunction.value.role) : null) : null,
        };
        this.service.postMethod('account/admin/search-and-filter-staff', data, 1).subscribe((response: any) => {
            let responseData = this.service.decrypt(response.data);
            responseData = JSON.parse(responseData);
            this.spinner.hide();
            if (responseData.status === 563) {
                if (responseData.data.list) {
                    this.getStaff = responseData.data.list;
                    this.total = responseData.data.size;
                    this.getStaff.forEach(element => {
                        if(element.updatedByName == null) {
                            element.updatedAt = null;
                        }
                    });
                }
            }
        }, () => {
            this.spinner.hide();
        });
    }

    changePage(page) {
        this.p = page;
        this.page = page - 1;
        this.getStaffList();
    }

    fromDateChanged(event) {
        if (event.epoc) {
            this.toPickerOptions = {
                disableUntil: { year: new Date(event.epoc * 1000).getFullYear(), month: new Date(event.epoc * 1000).getMonth() + 1, day: new Date(event.epoc * 1000).getDate() - 1 }
            };
        } else {
            this.toPickerOptions = {
                disableUntil: { year: 0, month: 0, day: 0 },
                disableSince: { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() + 1 }
            };
        }
    }

    toDateChanged(event) {
        if (event.epoc) {
            this.fromPickerOptions = {
                disableSince: { year: new Date(event.epoc * 1000).getFullYear(), month: new Date(event.epoc * 1000).getMonth() + 1, day: new Date(event.epoc * 1000).getDate() + 1 }
            };
        } else {
            this.fromPickerOptions = {
                disableSince: { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() + 1 },
            };
        }
    }

    openModal(modal, id) {
        if (this.service.sideMenuArr.includes('deleteStaffProfile')) {
            $('#' + modal).modal('show');
            this.currentId = id;
        }
    }

    deleteStaff() {
        this.spinner.show();
        const data = {
            userId: this.service.encrypt(String(this.currentId)),
            location: this.service.encrypt(this.currentUser.city + ',' + this.currentUser.country_name),
            ipAddress: this.service.encrypt(this.currentUser.ip),
            browserName: this.service.encrypt(this.browser),
        };
        this.service.postMethod('account/admin/delete-staff', data, 1).subscribe((response: any) => {
            const responseData = JSON.parse(this.service.decrypt(response.data));
            if (responseData.status === 906 || responseData.status === 559) {
                this.spinner.hide();
                this.getStaffList();
            } else {
                this.spinner.hide();
            }
        }, () => {
            this.spinner.hide();
        });
    }

    viewStaff(data) {
        if (this.service.sideMenuArr.includes('viewStaffProfile')) {
            this.router.navigateByUrl('view-staff/' + data.userId);
        }
    }

    editStaff(data) {
        if (this.service.sideMenuArr.includes('updateStaffProfile')) {
            this.router.navigateByUrl('edit-staff/' + data.userId);
        }

    }

    resetFunc() {
        this.filterFunction.reset();
        this.fromDateInTimestamp = 0;
        this.toDateInTimestamp = 0;
        this.fromPickerOptions = {
            disableSince: { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() + 1 },
            disableUntil: { year: 0, month: 0, day: 0}
        };
        this.toPickerOptions = {
            disableSince: { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() + 1 },
            disableUntil: { year: 0, month: 0, day: 0}
        };
        this.p = 1;
        this.page = 0;
        this.getStaffList();
    }

    changePasswordStaff(staff) {
        if (this.service.sideMenuArr.includes('updateStaffPassword')) {
            this.router.navigate(['/password-change/' + staff.email]);
        }
    }

    getRoles() {
        this.service.getMethod('account/common-permit/get-roles-without-superadmin-user', 1).subscribe((response: any) => {
            const resData = this.service.decrypt(response.data);
            this.rolesArr = (JSON.parse(resData)).data;
            const ind = this.rolesArr.findIndex((x) => x.role === 'ADMIN');
            if (ind > -1) {
                this.rolesArr.splice(ind, 1);
            }
            if (response) {
                this.spinner.hide();
            } else {
                this.showApiMessage = true;
                this.response = response;
                this.spinner.hide();
            }
        }, (error) => {
            if (error) {
                this.showApiMessage = true;
                this.response = 'Something went wrong!';
                this.spinner.hide();
                return;
            }
            if (error.error) {
                this.showApiMessage = true;
                this.response = error.error.error;
                this.spinner.hide();
            } else {
                this.showApiMessage = true;
                this.response = 'Something went wrong!';
                this.spinner.hide();
            }
        });
    }
}
