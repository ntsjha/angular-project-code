import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OfferTranslationListComponent } from './offer-translation-list.component';

describe('OfferTranslationListComponent', () => {
  let component: OfferTranslationListComponent;
  let fixture: ComponentFixture<OfferTranslationListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OfferTranslationListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OfferTranslationListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
