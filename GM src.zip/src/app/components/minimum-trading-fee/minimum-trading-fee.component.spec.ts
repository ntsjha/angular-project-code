import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MinimumTradingFeeComponent } from './minimum-trading-fee.component';

describe('MinimumTradingFeeComponent', () => {
  let component: MinimumTradingFeeComponent;
  let fixture: ComponentFixture<MinimumTradingFeeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MinimumTradingFeeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MinimumTradingFeeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
