import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AppComponent } from '../../../app.component';
import { ServerService } from '../../../service/server.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { HeaderComponent } from '../../header/header/header.component';

declare var $: any;
declare const TradingView: any;
declare const Datafeeds: any;
declare const AmCharts: any;

@Component({
    selector: 'app-exchange',
    templateUrl: './exchange.component.html',
    styleUrls: ['./exchange.component.css']
})
export class ExchangeComponent implements OnInit {
    webNamesArr = [{
          "websiteName": "Poloniex",
          "status": "2",
          "active": "false"
        },
        {
          "websiteName": "Binance",
          "status": "1",
          "active": "false"
        },
        {
          "websiteName": "HitBTC",
          "status": "3",
          "active": "false"
        }
    ]
    loginStatus = false;
    hitbtcIntervalID: any;
    headerPriceObj = {currPrice:"", highest:"", average:"", lowest:"", volume:""};
    currentCoinObj = {coinShort:"", coinFullName:"", coinId:""};    
    currentPairCoinObj = {coinShort:"", coinFullName:"", coinId:""};
    searchText = "";
    currTab = "BUY";
    buyOrderType = "LIMIT";
    sellOrderType = "LIMIT";
    coinListArr = [];
    coinPairListArr = [];
    tradeViewPair =  "BTC/ETH";
    openOrderArr = [];
    orderHistoryArr = [];
    tradeHistoryArr = [];
    sellOrderArr = [];
    buyOrderArr = [];
    userData = {baseCoinBal:"",pairCoinBal:""};
    limitBuyObj = {price:"", amount:"", total:""};
    limitSellObj = {price:"", amount:"", total:""};
    marketBuyObj = {amount:""};
    marketSellObj = {amount:""};
    sLimitBuyObj = {stop:"", price:"", amount:"", total:""};
    sLimitSellObj = {stop:"", price:"", amount:"", total:""};
    regexForEightChar = (/^(\d+)?([.]?\d{0,8})?$/);
    currentTab: any = 'BID';
    SocketDataStatus :any = false;
    count: number=0;
    poloniexTradePair: any;
    PoloArr: any=[];
    polo_id: any;
    const: any;
    HitBTCPair = "BTCETH";
    symbolArr: any = [];
    feeList: any[];
    takerFee: any = '0.00';
    makerFee: any = '0.00';
    feeListApi = false;
    kyc: any;
    checkyc: any = "";
    kycMessage: string;
    tradingChart: any;

    constructor(private activatedRoutes: ActivatedRoute, private router: Router, private appC: AppComponent, private server: ServerService, private spinnerService: Ng4LoadingSpinnerService, public header: HeaderComponent) {
        // this.activatedRoutes.params.subscribe(res => {
        //     this.getCoinListExchange();
        //     this.currentCoinObj.coinShort = res.base;
        //     this.currentPairCoinObj.coinShort = res.exe;
        // });
        // this.header.fireToChild().subscribe(message => {
        //     message.text == "modeChange" ? "this.drawTradingChart()" : "";
        // });

        // this.server.fireToChild().subscribe(message => {
        //     if(message.text == "liquidity") {
        //         this.server.liquidityWS.addEventListener('message', function (event) {
        //             self.SocketDataStatus = true;
        //             let data = JSON.parse(event.data);
        //             self.headerPriceObj = {currPrice:"", highest:"", average:"", lowest:"", volume:""};
        //             self.headerPriceObj.currPrice = data.o;
        //             self.headerPriceObj.highest = data.h;
        //             self.headerPriceObj.lowest = data.l;
        //             self.headerPriceObj.average = ((Number(data.h) + Number(data.l)) / 2).toString();
        //             self.headerPriceObj.volume = data.v; 

        //             let currPairArr = self.coinPairListArr.filter(obj => obj.coin == self.currentPairCoinObj.coinShort);
        //             if(currPairArr.length) {
        //                 currPairArr[0].last_price = self.headerPriceObj.currPrice;
        //                 currPairArr[0].volume = self.headerPriceObj.volume;
        //                 currPairArr[0].average = self.headerPriceObj.average;
        //             }
        //         });
        //         let len = this.server.liquidityWSTicker.length;
        //         for(let i = 0; i < len; i++) {
        //             this.server.liquidityWSTicker[i].addEventListener('message', function (event) {
        //                 self.SocketDataStatus = true;
        //                 let data = JSON.parse(event.data);
        //                 let str = data.s.replace(self.currentCoinObj.coinShort,'')
        //                 let ind = self.coinPairListArr.findIndex(obj => obj.coin == str);
        //                 if(ind != -1) {
        //                     self.coinPairListArr[ind].last_price = data.o;
        //                     self.coinPairListArr[ind].volume = data.v; 
        //                     self.coinPairListArr[ind].average = ((Number(data.h) + Number(data.l)) / 2).toString();
        //                 }
        //             });
        //         }
        //         this.server.liquidityWSTrade.addEventListener('message', function (event) {
        //             self.SocketDataStatus = true;
        //             let data = JSON.parse(event.data);
        //             if(data.m == true) {
        //                 data.m = 'BUY'
        //             } else {
        //                 data.m = 'SELL'
        //             }
        //             self.tradeHistoryArr.push({
        //                 price: data.p,
        //                 amount: data.q,
        //                 total: (data.p*data.q),
        //                 time: data.T,
        //                 type: data.m
        //             });
        //             //self.tradeHistoryArr = self.functionToManageTradeHisOrder(self.tradeHistoryArr);
        //             self.tradeHistoryArr = self.tradeHistoryArr.slice(0,50);
        //         });
        //         this.server.liquidityWSDepth.addEventListener('message', function (event) {
        //             self.SocketDataStatus = true;
        //             let data = JSON.parse(event.data);
        //             data.bids.forEach(element => {
        //                 self.buyOrderArr.push({
        //                     price: element[0],
        //                     amount: element[1],
        //                     total: element[0]*element[1]
        //                 });
        //                 // self.buyOrderArr = self.functionToManageTradeHisOrder(self.buyOrderArr);
        //                 self.buyOrderArr = self.buyOrderArr.slice(0,50);
        //             });
        //             data.asks.forEach(element => {
        //                 self.sellOrderArr.push({
        //                     price: element[0],
        //                     amount: element[1],
        //                     total: element[0]*element[1]
        //                 });
        //                 // self.sellOrderArr = self.functionToManageTradeHisOrder(self.sellOrderArr);
        //                 self.sellOrderArr = self.sellOrderArr.slice(0,50);
        //             });
        //         });
        //     } else if(message.text == "poloniex") {
        //         let symbolArray = [];
        //         self.PoloArr.forEach(obj => {
        //             if(obj.pair == self.poloniexTradePair) {
        //                 this.poloTradeHistory();
        //                 this.polo_id = obj.id;
        //             }
        //             this.symbolArr.forEach(element => {
        //                 if(element == obj.pair) {
        //                     symbolArray.push({
        //                         pair : element,
        //                         id   : obj.id 
        //                     })
        //                 }
        //             });
        //         });
        //         this.callPolyneixSocket(1)
        //         this.callPoloTrade(1)
        //         this.server.liquidityWSPoloneix.addEventListener('message', function (event){
        //             self.SocketDataStatus = true;
        //             let data = JSON.parse(event.data);
                    
        //             if(data.error == "Invalid channel") {
        //                //self.callPolyneixSocket(2)
        //                self.SocketDataStatus= false;
        //             }
        //             if(data.length > 2 && data[0]== 1002 ) {
        //                 let tickerArr = data[2];
        //                 if(tickerArr[0] == self.polo_id) { 
        //                     let selected_arr = data[2]
        //                     self.SocketDataStatus= true;
        //                     self.headerPriceObj = {currPrice:"", highest:"", average:"", lowest:"", volume:""};
        //                     self.headerPriceObj.currPrice = selected_arr[1];
        //                     self.headerPriceObj.highest = selected_arr[8];
        //                     self.headerPriceObj.lowest = selected_arr[9];
        //                     self.headerPriceObj.average = ((Number(selected_arr[8]) + Number(selected_arr[9])) / 2).toString();
        //                     self.headerPriceObj.volume = selected_arr[5]; 

        //                     let currPairArr = self.coinPairListArr.filter(obj => obj.coin == self.currentPairCoinObj.coinShort);
        //                     if(currPairArr.length) {
        //                         currPairArr[0].last_price = self.headerPriceObj.currPrice;
        //                         currPairArr[0].volume = self.headerPriceObj.volume;
        //                         currPairArr[0].average = self.headerPriceObj.average;
        //                     }
        //                 } 
        //                 symbolArray.forEach(obj => {
        //                     if(obj.id == tickerArr[0]) {
        //                         let arr = data[2];
        //                         let currCoinPair = self.coinPairListArr.filter(ob => ob.coin == obj.pair.split('_')[1]);
        //                         currCoinPair[0].last_price = arr[1];
        //                         currCoinPair[0].volume = arr[5];
        //                         currCoinPair[0].average = ((Number(arr[8]) + Number(arr[9])) / 2).toString();
        //                     }
        //                 });
                        
        //             }else if(data.length > 2 && data[0]!= 1002 ) {
        //                 let selected_arr = data[2]
        //                 if(selected_arr.length == 2) {
        //                     let curr_arr0 = selected_arr[0];
        //                     let curr_arr1 = selected_arr[1]
        //                     if(curr_arr0[0]== "o" && curr_arr0[3]!= 0){
        //                         if(curr_arr0[1]== 0){
        //                             self.sellOrderArr.push({
        //                                 price: curr_arr0[2],
        //                                 amount: curr_arr0[3],
        //                                 total: curr_arr0[2] * curr_arr0[3]
        //                             });
        //                             // self.sellOrderArr = self.functionToManageTradeHisOrder(self.sellOrderArr);
        //                             self.sellOrderArr = self.sellOrderArr.slice(0,50);
        //                         } else if(curr_arr0[1]== 1){
        //                             self.buyOrderArr.push({
        //                                 price: curr_arr0[2],
        //                                 amount: curr_arr0[3],
        //                                 total: curr_arr0[2] * curr_arr0[3]
        //                             });
        //                             // self.buyOrderArr = self.functionToManageTradeHisOrder(self.buyOrderArr);
        //                             self.buyOrderArr = self.buyOrderArr.slice(0,50);
        //                         }
        //                     }
        //                     if(curr_arr1[0]== "o" && curr_arr1[3]!= 0){
        //                         if(curr_arr1[1]== 0){
        //                             self.sellOrderArr.push({
        //                                 price: curr_arr1[2],
        //                                 amount: curr_arr1[3],
        //                                 total: curr_arr1[2] * curr_arr1[3]
        //                             });
        //                             // self.sellOrderArr = self.functionToManageTradeHisOrder(self.sellOrderArr);
        //                             self.sellOrderArr = self.sellOrderArr.slice(0,50);
        //                         } else if(curr_arr1[1]== 1){
        //                             self.buyOrderArr.push({
        //                                 price: curr_arr1[2],
        //                                 amount: curr_arr1[3],
        //                                 total: curr_arr1[2] * curr_arr1[3]
        //                             });
        //                             // self.buyOrderArr = self.functionToManageTradeHisOrder(self.buyOrderArr);
        //                             self.buyOrderArr = self.buyOrderArr.slice(0,50);
        //                         }
        //                     }
        //                 }
        //             }
        //             if(data[0]== 1010) {
        //                 self.SocketDataStatus= false;
        //             }
        //         })
        //     } else if(message.text == "HitBTC") {
        //         this.updateLiquiditySocket(1);
        //         this.server.liquidityWSHitBTC.addEventListener('message', function (event) {
        //             let data = JSON.parse(event.data);
        //             if(data.params) {
        //                 self.SocketDataStatus = true;
        //                 switch(data.method) {
        //                     case "ticker":
        //                         self.headerPriceObj.currPrice = data.params.last;
        //                         self.headerPriceObj.highest = data.params.high;
        //                         self.headerPriceObj.lowest = data.params.low;
        //                         self.headerPriceObj.average = ((Number(data.params.high) + Number(data.params.high)) / 2).toString();
        //                         self.headerPriceObj.volume = data.params.volume; 
                
        //                         /** Code to set coin pair list data as per selected pair */
        //                         let currPairArr = self.coinPairListArr.filter(obj => obj.coin == self.currentPairCoinObj.coinShort);
        //                         if(currPairArr.length) {
        //                             currPairArr[0].last_price = self.headerPriceObj.currPrice;
        //                             currPairArr[0].volume = self.headerPriceObj.volume;
        //                             currPairArr[0].average = self.headerPriceObj.average;
        //                         }
        //                         break;
        //                     case "snapshotOrderbook":
        //                     case "updateOrderbook":
        //                         if(data.params.bid.length) {
        //                             data.params.bid.forEach((obj) => {
        //                                 var ind = self.buyOrderArr.findIndex((x) => x.price == obj.price);
        //                                 if(ind != -1) {
        //                                     self.buyOrderArr[ind].amount = (Number(self.buyOrderArr[ind].amount) + Number(obj.size)).toFixed(8);
        //                                     self.buyOrderArr[ind].total = (self.buyOrderArr[ind].price * self.buyOrderArr[ind].amount).toFixed(8);
        //                                 } else {
        //                                     self.buyOrderArr.push({
        //                                         price: Number(obj.price).toFixed(8),
        //                                         amount: Number(obj.size).toFixed(8),
        //                                         total: (obj.price*obj.size).toFixed(8)
        //                                     });
        //                                 }
        //                             });  
        //                             self.buyOrderArr = self.buyOrderArr.slice(0,50);
        //                             //self.buyOrderArr = self.functionToManageTradeHisOrder(self.buyOrderArr); 
        //                         }
        //                         if(data.params.ask.length) {
        //                             data.params.ask.forEach((obj) => {
        //                                 var ind = self.sellOrderArr.findIndex((x) => x.price == obj.price);
        //                                 if(ind != -1) {
        //                                     self.sellOrderArr[ind].amount = (Number(self.sellOrderArr[ind].amount) + Number(obj.size)).toFixed(8);
        //                                     self.sellOrderArr[ind].total = (self.sellOrderArr[ind].price * self.sellOrderArr[ind].amount).toFixed(8);
        //                                 } else {
        //                                     self.sellOrderArr.push({
        //                                         price: Number(obj.price).toFixed(8),
        //                                         amount: Number(obj.size).toFixed(8),
        //                                         total: (obj.price*obj.size).toFixed(8)
        //                                     });
        //                                 }
        //                             });  
        //                             self.sellOrderArr = self.sellOrderArr.slice(0,50);
        //                             //self.sellOrderArr = self.functionToManageTradeHisOrder(self.sellOrderArr); 
        //                         }
        //                         break;
        //                     case "snapshotTrades":
        //                     case "updateTrades":
        //                         if(data.params.data.length) {
        //                             data.params.data.forEach((obj) => {
        //                                 self.tradeHistoryArr.push({
        //                                     price: Number(obj.price).toFixed(8),
        //                                     amount: Number(obj.quantity).toFixed(8),
        //                                     total: Number(obj.price*obj.quantity).toFixed(8),
        //                                     time: new Date(obj.timestamp).getTime(),
        //                                     type: obj.side.toUpperCase()
        //                                 });
        //                             });     
        //                             self.tradeHistoryArr = self.tradeHistoryArr.slice(0,50);
        //                             //self.tradeHistoryArr = self.functionToManageTradeHisOrder(self.tradeHistoryArr);
        //                         }
        //                         break;
        //                 }                
        //             }          
        //             if(data.error) {
        //                 if(data.error.code == 2001) {
        //                     self.SocketDataStatus = false;
        //                     // self.tradeHistoryArr = [];
        //                     // self.sellOrderArr = [];
        //                     // self.buyOrderArr = [];

        //                     /** Code to set coin pair list data as per selected pair */
        //                     let currPairArr = self.coinPairListArr.filter(obj => obj.coin == self.currentPairCoinObj.coinShort);
        //                     if(currPairArr.length) {
        //                         currPairArr[0].last_price = 0.000000;
        //                         currPairArr[0].volume = 0.000000;
        //                         currPairArr[0].average = 0.000000;
        //                     }
        //                 }
        //             }    
        //         });
        //     }
        // });
        // var self = this;
        // if(self.SocketDataStatus == false) {
        //     this.server.wsExchange.addEventListener('message', function (event) {
        //         let data = JSON.parse(event.data);
        //         if(data.payload.buyOrders.length) {
        //             self.buyOrderArr = [];
        //             let buyArr = data.payload.buyOrders.filter((x) => x.executableCurrencyCoinId == self.currentPairCoinObj.coinId && x.baseCurrencyCoinId == self.currentCoinObj.coinId);
        //             buyArr.forEach((obj) => {
        //                 var ind = self.buyOrderArr.findIndex((x) => x.price == obj.price);
        //                 if(ind != -1) {
        //                     self.buyOrderArr[ind].amount = (Number(self.buyOrderArr[ind].amount) + Number(obj.amount)).toFixed(8);
        //                     self.buyOrderArr[ind].total = (self.buyOrderArr[ind].price * self.buyOrderArr[ind].amount).toFixed(8);
        //                 } else {
        //                     self.buyOrderArr.push({
        //                         price: obj.price.toFixed(8),
        //                         amount: obj.amount.toFixed(8),
        //                         total: (obj.price*obj.amount).toFixed(8)
        //                     });
        //                 }
        //             });
        //         } else {
        //             self.buyOrderArr = [];
        //         }
        //         if(data.payload.sellOrders.length) {
        //             self.sellOrderArr = [];
        //             let sellArr = data.payload.sellOrders.filter((x) => x.executableCurrencyCoinId == self.currentPairCoinObj.coinId && x.baseCurrencyCoinId == self.currentCoinObj.coinId);
        //             sellArr.forEach((obj) => {
        //                 var ind = self.sellOrderArr.findIndex((x) => x.price == obj.price);
        //                 if(ind != -1) {
        //                     self.sellOrderArr[ind].amount = (Number(self.sellOrderArr[ind].amount) + Number(obj.amount)).toFixed(8);
        //                     self.sellOrderArr[ind].total = (self.sellOrderArr[ind].price * self.sellOrderArr[ind].amount).toFixed(8);
        //                 } else {
        //                     self.sellOrderArr.push({
        //                         price: obj.price.toFixed(8),
        //                         amount: obj.amount.toFixed(8),
        //                         total: (obj.price*obj.amount).toFixed(8)
        //                     });
        //                 }
        //             });
        //         } else {
        //             self.sellOrderArr = [];
        //         }
        //         if(data.payload.tradeHistory.length) {
        //             self.tradeHistoryArr = [];
        //             let tradeArr = data.payload.tradeHistory.filter((x) => x.executableCurrencyCoinId == self.currentPairCoinObj.coinId && x.baseCurrencyCoinId == self.currentCoinObj.coinId);
        //             tradeArr.forEach((obj) => {
        //                 self.tradeHistoryArr.push({
        //                     price: obj.price.toFixed(8),
        //                     amount: obj.amount.toFixed(8),
        //                     total: (obj.price*obj.amount).toFixed(8),
        //                     time: obj.orderExecutionTime,
        //                     type: obj.orderType
        //                 });
        //             });
        //         } else {
        //             self.tradeHistoryArr = [];
        //         }
        //         if(data.payload.userSpecific) {
        //             self.getHeaderPrice();
        //             self.getCoinPairAfterExecution();
        //             if(data.payload.userIdList.length) {
        //                 if(localStorage.getItem("userId")) {
        //                     let ind = data.payload.userIdList.findIndex((x) => x == localStorage.getItem("userId"));
        //                     if(ind != -1) {
        //                         self.getUserBaseCoinBalance();
        //                         self.getUserPairCoinBalance();
        //                         if(localStorage.getItem("token")) {
        //                             self.getUserOpenOrder();
        //                             self.getUserOrderHistory();
        //                         }
        //                     }
        //                 }
        //             }
        //         }
        //     });
        // }ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQC2CFM50exDgvsQPmRd4kbfyyBr99tzPSZIxMK7G+L+Vo0O7N+JekoDfWuEHLgJYCqsCoUjRAHtgZZ54yGIcmfvgCP5XtVWEMFuz7cItz6B+sJaPdcO/xwJxEuT4YgBuVzo50QwScYPjmZgR6zbfRS3i8bBMgYNueAEO+8Xi6wzQIYJxmBmiD77rOaesUHVAsVGwtOu8nmsPm8p+sgzPK3dd6f3vUqN2SMh9q1LxGhbtIgH/+e4klSjDta0bk4/CQSWUGd2LZu5bq4S2Hr2/HPyOBEcw7rAllDRLmBm7acTD1paq7uXUvFu4k4VEB1Uxo6hDmT4AczgV1ymla7/i1UP mobiloitte@mac-111.local
        
    }

    /** Function to get coin list from api */
    getCoinListExchange() {
        let data = {
            "eventExternal":  {
                "name":"request_get_coin_list",
                "key":"mykey"
            },
            "transferObjectMap":{}
        }
        this.spinnerService.show();
        this.server.postApi('',data,0).subscribe((succ) => {
            this.spinnerService.hide();
            if(succ.transferObjectMap.statusCode == 200) {
                let data = succ.transferObjectMap.coinList;
                this.coinListArr = data.filter((x) => x.coinType=="crypto" && (x.coinShortName == 'IPR' ||x.coinShortName == 'BTC' || x.coinShortName == 'ETH' || x.coinShortName == 'USDT'));
                let ind = this.coinListArr.findIndex(x => x.coinShortName == this.currentCoinObj.coinShort);
                if(ind > -1) {
                    this.currentCoinObj.coinId = this.coinListArr[ind].coinId;
                    this.currentCoinObj.coinFullName = this.coinListArr[ind].coinFullName;
                }
                this.coinPairListArr = [];
                this.getCoinPair();
            } else {
                this.appC.showErrToast(succ.transferObjectMap.message);
            }
        }, (err) => {
            this.spinnerService.hide();
        });
    }

    /** Function to manage trade history data */
    functionToManageTradeHisOrder(arr) {
        arr.sort((a,b) => {
            return b.time - a.time;
        });  
        //arr = arr.slice(0, 5);
        return arr;
    }

    /** for polyneix socket */
    callPolyneixSocket(type) {
        let data = {
            "command": "",
            "channel": 1002
        }
        switch(type) {
            case 1: 
                data.command = "subscribe";
                this.server.liquidityWSPoloneix.send(JSON.stringify(data));
                break;
            case 2:
                data.command = "unsubscribe";
                this.server.liquidityWSPoloneix.send(JSON.stringify(data));
                break;
        }
    }

    /** for poloneix ticker */
    callPoloTrade(type) {
        let data = {
            "command": "",
            "channel": this.poloniexTradePair
        }
        switch(type) {
            case 1: 
                data.command = "subscribe"
                this.server.liquidityWSPoloneix.send(JSON.stringify(data));
                break;
            case 2:
                data.command = "unsubscribe"
                this.server.liquidityWSPoloneix.send(JSON.stringify(data));
                break;
        }
    }

    callCoinListWithSocket(msg, type) {
        switch(msg) {
            case 'Binance' : 
                switch(type) {
                    case 1 :
                        let i = 0;
                        this.symbolArr.forEach(element => {
                            element = element.toLowerCase();
                            this.server.binanceTickerFunc(element,i);
                            i++;
                        }); 
                        break;
                    case 2: 
                        this.server.liquidityWSTicker.close();
                        break;
                }
                break;
            case 'Poloniex' : 
                let data = {
                    "command": "",
                    "channel": 1002
                }
                switch(type) {
                    case 1 :
                        data.command = "subscribe"
                        this.server.liquidityWSPoloneix.send(JSON.stringify(data));
                        break;
                    case 2: 
                        data.command = "unsubscribe"
                        this.server.liquidityWSPoloneix.send(JSON.stringify(data));
                        break;
                }
                break;
            case 'HitBTC' : 
                this.symbolArr.forEach(element => {
                    let data1 = {
                        "method": "",
                        "params": {
                            "symbol": element,
                            "limit": ""
                        },
                        "id": ""
                    }
                    switch(type) {
                        case 1 :
                            if(this.server.liquidityWSHitBTC.readyState) {
                                data1.method = "subscribeTicker";
                                this.server.liquidityWSHitBTC.send(JSON.stringify(data));
                            }  
                            break;
                        case 2: 
                            if(this.server.liquidityWSHitBTC.readyState) {                    
                                data1.method = "unsubscribeTicker";
                                this.server.liquidityWSHitBTC.send(JSON.stringify(data));                   
                            }       
                            break;
                    }
                });
                break;
        }


    }

    /** Function to fetch coin symbol */
    getCoinSymbol(arr) {
        let symbolArr = [];
        if(this.server.activatedSocket == "Poloniex") {
            arr.forEach((obj) => {
                if(!obj.selected) {
                    symbolArr.push(this.currentCoinObj.coinShort+ '_'+(obj.coin == 'ECH' ? "ETC": obj.coin)); 
                }
            });
            return symbolArr;
        } else if(this.server.activatedSocket == "Binance") {
            arr.forEach((obj) => {
                if(!obj.selected) {
                    symbolArr.push((obj.coin == "ECH" ? "ETC": obj.coin)+this.currentCoinObj.coinShort); 
                }
            });
            return symbolArr;
        } else {
            let symbolArr = [];
            arr.forEach((obj) => {
                if(!obj.selected) {
                    if(this.currentCoinObj.coinShort == "USD") {    
                        if(obj.coin == "XRP") {
                            symbolArr.push(obj.coin+"USDT");
                        } else {
                            symbolArr.push(obj.coin+this.currentCoinObj.coinShort);    
                        }
                    } else {
                        symbolArr.push(obj.coin+this.currentCoinObj.coinShort);
                    }                
                }
            });
            return symbolArr;
        }
    }

    ngOnInit() {
        window.scrollTo(0,0);
        this.getfeeList();
        this.getPoloneixCurrencyPair();
        this.getLiquidityWebsite();
        this.currTab = "BUY";
        if(localStorage.getItem("token")) {
            this.loginStatus = true;
        } else {
            this.loginStatus = false;
        }
        this.getCoinList();
        this.header.getprofile();


       
    }

    poloTradeHistory() {
        if(this.server.activatedSocket == "Poloniex") {
            this.const = setTimeout(()=>{
                this.tradeHistoryArr = [];
                this.server.thirdpartyGetApi('https://poloniex.com/public?command=returnTradeHistory&currencyPair='+this.poloniexTradePair).subscribe((res) => {
                    if(!res.error) {
                        res.forEach(element => {
                            let obj = {
                                price: element.rate,
                                amount: element.amount,
                                total: (element.rate*element.amount),
                                time: element.date,
                                type: element.type
                            }
                            this.tradeHistoryArr.push(obj)
                        });
                    } else{
                        clearTimeout(this.const)
                        this.tradeHistoryArr =[]
                    }
                })
            this.poloTradeHistory()
            },50000)
        }
       
    }

    /** to get liquidity poloneix website */
    getPoloneixCurrencyPair() {
        this.server.getCurrency_PairJson().subscribe((res) => {
            this.PoloArr = res
        });
    }

    /** To check Kyc status */
    checkKycStatus(val) {
        if(val == 1) {
            switch(this.buyOrderType) {
                case 'LIMIT':
                    if(this.limitBuyObj.price == "") {
                        this.appC.showErrToast("Enter price value.");
                        return;
                    } else if(this.limitBuyObj.price == ".") {
                        this.appC.showErrToast("Enter valid price value.");
                        return;
                    } else if(Number(this.limitBuyObj.price) <= 0) {
                        this.appC.showErrToast("Enter valid price value.");
                        return;
                    } else if(this.limitBuyObj.amount == "") {
                        this.appC.showErrToast("Enter amount value.");
                        return;
                    } else if(this.limitBuyObj.amount == ".") {
                        this.appC.showErrToast("Enter valid amount value.");
                        return;
                    } else if(Number(this.limitBuyObj.amount) <= 0) {
                        this.appC.showErrToast("Enter valid amount value.");
                        return;
                    } else if(Number(this.limitBuyObj.total) > Number(this.userData.baseCoinBal)){
                        this.appC.showErrToast("You can't buy coins more than your wallet amount.");
                        return;            
                    } else {
                        this.checkyc = "";
                        this.kyc = [];
                        let kycDetails= { 
                            "eventExternal": { 
                                "name":"request_kyc_list", 
                                "key":"mykey" 
                            }, 
                            "transferObjectMap": {
                                "gatewayrequest": {
                                    "token":localStorage.getItem('token')
                                } 
                            } 
                        } 
                        this.spinnerService.show();
                        this.server.postApi('', kycDetails,0).subscribe(response => {
                            this.spinnerService.hide();
                            if (response.transferObjectMap.statusCode == 200) {
                                this.kyc = response.transferObjectMap.result;   
                                if(this.kyc.length == 0) {
                                    this.checkyc = false;
                                    this.appC.showInfoToast("To get the functionalities of the Bittnomy exchange you need to get your kyc done");
                                } else {
                                        response.transferObjectMap.result.forEach(element => {
                                            if(element.status == 'VERIFIED') {
                                                this.checkyc = true;
                                            }    
                                        });
                                        if(this.checkyc) {
                                            this.buyFunc();
                                        } else
                                            this.appC.showInfoToast("KYC verification is needed to proceed further.");
                                }
                            } else if(response.transferObjectMap.statusCode == 403) {
                                this.appC.showErrToast(response.transferObjectMap.message);
                                this.header.tokenExpire();
                            } else {
                                this.appC.showErrToast(response.transferObjectMap.message);
                            }
                        }, error => {
                                this.appC.showErrToast('Something went wrong');
                                this.spinnerService.hide();
                        });  
                    }
                    break;
                case 'MARKET':
                    if(this.marketBuyObj.amount == "") {
                        this.appC.showErrToast("Enter amount value.");
                        return;
                    } else if(this.marketBuyObj.amount == ".") {
                        this.appC.showErrToast("Enter valid amount value.");
                        return;
                    } else if(Number(this.marketBuyObj.amount) <= 0) {
                        this.appC.showErrToast("Enter valid amount value.");
                        return;
                    } else {
                        this.checkyc = "";
                        this.kyc = [];
                        let kycDetails= { 
                            "eventExternal": { 
                                "name":"request_kyc_list", 
                                "key":"mykey" 
                            }, 
                            "transferObjectMap": {
                                "gatewayrequest": {
                                    "token":localStorage.getItem('token')
                                } 
                            } 
                        } 
                        this.spinnerService.show();
                        this.server.postApi('', kycDetails,0).subscribe(response => {
                            this.spinnerService.hide();
                            if (response.transferObjectMap.statusCode == 200) {
                                this.kyc = response.transferObjectMap.result;   
                                if(this.kyc.length == 0) {
                                    this.checkyc = false;
                                    this.appC.showInfoToast("To get the functionalities of the Bittnomy exchange you need to get your kyc done");
                                } else {
                                        response.transferObjectMap.result.forEach(element => {
                                            if(element.status == 'VERIFIED') {
                                                this.checkyc = true;
                                            }    
                                        });
                                        if(this.checkyc) {
                                            this.buyFunc();
                                        } else
                                            this.appC.showInfoToast("KYC verification is needed to proceed further.");
                                }
                            } else if(response.transferObjectMap.statusCode == 403) {
                                this.appC.showErrToast(response.transferObjectMap.message);
                                this.header.tokenExpire();
                            } else {
                                this.appC.showErrToast(response.transferObjectMap.message);
                            }
                        }, error => {
                                this.appC.showErrToast('Something went wrong');
                                this.spinnerService.hide();
                        });  
                        } 
                    break;
                case 'STOPLIMIT':
                    if(this.sLimitBuyObj.stop == "") {
                        this.appC.showErrToast("Enter stop value.");
                        return;
                    } else if(this.sLimitBuyObj.stop == ".") {
                        this.appC.showErrToast("Enter valid stop value.");
                        return;
                    } else if(Number(this.sLimitBuyObj.stop) <= 0) {
                        this.appC.showErrToast("Enter valid stop value.");
                        return;
                    } else if(this.sLimitBuyObj.price == "") {
                        this.appC.showErrToast("Enter limit value.");
                        return;
                    } else if(this.sLimitBuyObj.price == ".") {
                        this.appC.showErrToast("Enter valid limit value.");
                        return;
                    } else if(Number(this.sLimitBuyObj.price) <= 0) {
                        this.appC.showErrToast("Enter valid limit value.");
                        return;
                    } else if(this.sLimitBuyObj.amount == "") {
                        this.appC.showErrToast("Enter amount value.");
                        return;
                    } else if(this.sLimitBuyObj.amount == ".") {
                        this.appC.showErrToast("Enter valid amount value.");
                        return;
                    } else if(Number(this.sLimitBuyObj.amount) <= 0) {
                        this.appC.showErrToast("Enter valid amount value.");
                        return;
                    } else if(Number(this.sLimitBuyObj.total) > Number(this.userData.baseCoinBal)){
                        this.appC.showErrToast("You can't buy coins more than your wallet amount.");
                        return;
                    } else {
                        this.checkyc = "";
                        this.kyc = [];
                        let kycDetails= { 
                            "eventExternal": { 
                                "name":"request_kyc_list", 
                                "key":"mykey" 
                            }, 
                            "transferObjectMap": {
                                "gatewayrequest": {
                                    "token":localStorage.getItem('token')
                                } 
                            } 
                        } 
                        this.spinnerService.show();
                        this.server.postApi('', kycDetails,0).subscribe(response => {
                            this.spinnerService.hide();
                            if (response.transferObjectMap.statusCode == 200) {
                                this.kyc = response.transferObjectMap.result;   
                                if(this.kyc.length == 0) {
                                    this.checkyc = false;
                                    this.appC.showInfoToast("To get the functionalities of the Bittnomy exchange you need to get your kyc done");
                                } else {
                                        response.transferObjectMap.result.forEach(element => {
                                            if(element.status == 'VERIFIED') {
                                                this.checkyc = true;
                                            }    
                                        });
                                        if(this.checkyc) {
                                            this.buyFunc();
                                        } else
                                            this.appC.showInfoToast("KYC verification is needed to proceed further.");
                                }
                            } else if(response.transferObjectMap.statusCode == 403) {
                                this.appC.showErrToast(response.transferObjectMap.message);
                                this.header.tokenExpire();
                            } else {
                                this.appC.showErrToast(response.transferObjectMap.message);
                            }
                        }, error => {
                                this.appC.showErrToast('Something went wrong');
                                this.spinnerService.hide();
                        });  
                        } 
                        break;
            }
        } else if(val == 2) {
            switch(this.sellOrderType) {
                case 'LIMIT':
                    if(this.limitSellObj.price == "") {
                        this.appC.showErrToast("Enter price value.");
                        return;
                    } else if(this.limitSellObj.price == ".") {
                        this.appC.showErrToast("Enter valid price value.");
                        return;
                    } else if(Number(this.limitSellObj.price) <= 0) {
                        this.appC.showErrToast("Enter valid price value.");
                        return;
                    } else if(this.limitSellObj.amount == "") {
                        this.appC.showErrToast("Enter amount value.");
                        return;
                    } else if(this.limitSellObj.amount == ".") {
                        this.appC.showErrToast("Enter valid amount value.");
                        return;
                    } else if(Number(this.limitSellObj.amount) <= 0) {
                        this.appC.showErrToast("Enter valid amount value.");
                        return;
                    } else if(Number(this.limitSellObj.amount) > Number(this.userData.pairCoinBal)){
                        this.appC.showErrToast("You can't sell coins more than your wallet amount.");
                        return;
                    } else {
                        this.checkyc = "";
                        this.kyc = [];
                        let kycDetails= { 
                            "eventExternal": { 
                                "name":"request_kyc_list", 
                                "key":"mykey" 
                            }, 
                            "transferObjectMap": {
                                "gatewayrequest": {
                                    "token":localStorage.getItem('token')
                                } 
                            } 
                        } 
                        this.spinnerService.show();
                        this.server.postApi('', kycDetails,0).subscribe(response => {
                            this.spinnerService.hide();
                            if (response.transferObjectMap.statusCode == 200) {
                                this.kyc = response.transferObjectMap.result;   
                                if(this.kyc.length == 0) {
                                    this.checkyc = false;
                                    this.appC.showInfoToast("To get the functionalities of the Bittnomy exchange you need to get your kyc done");
                                } else {
                                        response.transferObjectMap.result.forEach(element => {
                                            if(element.status == 'VERIFIED') {
                                                this.checkyc = true;
                                            }    
                                        });
                                        if(this.checkyc) {
                                            this.sellFunc();
                                        } else
                                            this.appC.showInfoToast("KYC verification is needed to proceed further.");
                                }
                            } else if(response.transferObjectMap.statusCode == 403) {
                                this.appC.showErrToast(response.transferObjectMap.message);
                                this.header.tokenExpire();
                            } else {
                                this.appC.showErrToast(response.transferObjectMap.message);
                            }
                        }, error => {
                                this.appC.showErrToast('Something went wrong');
                                this.spinnerService.hide();
                        });  
                    } 
                        break;
                case 'MARKET':
                    if(this.marketSellObj.amount == "") {
                        this.appC.showErrToast("Enter amount value.");
                        return;
                    } else if(this.marketSellObj.amount == ".") {
                        this.appC.showErrToast("Enter valid amount value.");
                        return;
                    } else if(Number(this.marketSellObj.amount) <= 0) {
                        this.appC.showErrToast("Enter valid amount value.");
                        return;
                    } else if(Number(this.marketSellObj.amount) > Number(this.userData.pairCoinBal)) {
                        this.appC.showErrToast("You can't sell coins more than your wallet amount.");
                        return;
                    } else {
                        this.checkyc = "";
                        this.kyc = [];
                        let kycDetails= { 
                            "eventExternal": { 
                                "name":"request_kyc_list", 
                                "key":"mykey" 
                            }, 
                            "transferObjectMap": {
                                "gatewayrequest": {
                                    "token":localStorage.getItem('token')
                                } 
                            } 
                        } 
                        this.spinnerService.show();
                        this.server.postApi('', kycDetails,0).subscribe(response => {
                            this.spinnerService.hide();
                            if (response.transferObjectMap.statusCode == 200) {
                                this.kyc = response.transferObjectMap.result;   
                                if(this.kyc.length == 0) {
                                    this.checkyc = false;
                                    this.appC.showInfoToast("To get the functionalities of the Bittnomy exchange you need to get your kyc done");
                                        response.transferObjectMap.result.forEach(element => {
                                            if(element.status == 'VERIFIED') {
                                                this.checkyc = true;
                                            }    
                                        });
                                        if(this.checkyc) {
                                            this.sellFunc();
                                        } else
                                            this.appC.showInfoToast("KYC verification is needed to proceed further.");
                                }
                            } else if(response.transferObjectMap.statusCode == 403) {
                                this.appC.showErrToast(response.transferObjectMap.message);
                                this.header.tokenExpire();
                            } else {
                                this.appC.showErrToast(response.transferObjectMap.message);
                            }
                        }, error => {
                                this.appC.showErrToast('Something went wrong');
                                this.spinnerService.hide();
                        });  
                    } 
                    break;
                case 'STOPLIMIT':
                    if(this.sLimitSellObj.stop == "") {
                        this.appC.showErrToast("Enter stop value.");
                        return;
                    } else if(this.sLimitSellObj.stop == ".") {
                        this.appC.showErrToast("Enter valid stop value.");
                        return;
                    } else if(Number(this.sLimitSellObj.stop) <= 0) {
                        this.appC.showErrToast("Enter valid stop value.");
                        return;
                    } else if(this.sLimitSellObj.price == "") {
                        this.appC.showErrToast("Enter limit value.");
                        return;
                    } else if(this.sLimitSellObj.price == ".") {
                        this.appC.showErrToast("Enter valid limit value.");
                        return;
                    } else if(Number(this.sLimitSellObj.price) <= 0) {
                        this.appC.showErrToast("Enter valid limit value.");
                        return;
                    } else if(this.sLimitSellObj.amount == "") {
                        this.appC.showErrToast("Enter amount value.");
                        return;
                    } else if(this.sLimitSellObj.amount == ".") {
                        this.appC.showErrToast("Enter valid amount value.");
                        return;
                    } else if(Number(this.sLimitSellObj.amount) <= 0) {
                        this.appC.showErrToast("Enter valid amount value.");
                        return;
                    } else if(Number(this.sLimitSellObj.amount) > Number(this.userData.pairCoinBal)){
                        this.appC.showErrToast("You can't sell coins more than your wallet amount.");
                        return;
                    } else {
                        this.checkyc = "";
                        this.kyc = [];
                        let kycDetails= { 
                            "eventExternal": { 
                                "name":"request_kyc_list", 
                                "key":"mykey" 
                            }, 
                            "transferObjectMap": {
                                "gatewayrequest": {
                                    "token":localStorage.getItem('token')
                                } 
                            } 
                        } 
                        this.spinnerService.show();
                        this.server.postApi('', kycDetails,0).subscribe(response => {
                            this.spinnerService.hide();
                            if (response.transferObjectMap.statusCode == 200) {
                                this.kyc = response.transferObjectMap.result;   
                                if(this.kyc.length == 0) {
                                    this.checkyc = false;
                                    this.appC.showInfoToast("To get the functionalities of the Bittnomy exchange you need to get your kyc done");
                                } else {
                                        response.transferObjectMap.result.forEach(element => {
                                            if(element.status == 'VERIFIED') {
                                                this.checkyc = true;
                                            }    
                                        });
                                        if(this.checkyc) {
                                            this.sellFunc();
                                        } else
                                            this.appC.showInfoToast("KYC verification is needed to proceed further.");
                                }
                            } else if(response.transferObjectMap.statusCode == 403) {
                                this.appC.showErrToast(response.transferObjectMap.message);
                                this.header.tokenExpire();
                            } else {
                                this.appC.showErrToast(response.transferObjectMap.message);
                            }
                        }, error => {
                                this.appC.showErrToast('Something went wrong');
                                this.spinnerService.hide();
                        });  
                    } 
                    break;
            }
        } 
    }


    /**to call on destroy */
    ngOnDestroy() {
        clearTimeout(this.tradingChart)
        if(this.server.activatedSocket == "Binance") {
            this.server.liquidityWS.close();
            this.server.liquidityWSTrade.close();
            this.server.liquidityWSDepth.close();
        } else if(this.server.activatedSocket == "Poloniex") {
            clearTimeout(this.const);
        } else if(this.server.activatedSocket == "HitBTC") {
            clearInterval(this.hitbtcIntervalID);
        }
    }


    /** to get liquidity website */
    getLiquidityWebsite() {
        let data = {
            "eventExternal": {
                "name":"request_get_liquidity-website",
                "key":"mykey"
            },
            "transferObjectMap":{
                "gatewayrequest": {}
            }
        }
        this.spinnerService.show();
        this.server.postApi('',data,0).subscribe(succ => {
            this.spinnerService.hide();
            if(succ.transferObjectMap.statusCode == 200) {
                let status = succ.transferObjectMap.Liquidity_status;
                let index = this.webNamesArr.findIndex(x=> x.status == status)
                this.server.activatedSocket = this.webNamesArr[index].websiteName;
            }
        }, error => {
            this.spinnerService.hide();
            this.appC.showErrToast('Something went wrong');
        })
    }

    /** Function for buy/sell tab click */
    tabClick(type) {
        this.currTab = type;
    }

    /** Function for buy/sell tab click */
    tabClicked(type) {
        this.currentTab = type;
    }

    /** Function for coin change */
    coinChangeFunc() {
        this.clearMarketBuyObj();
        this.clearMarketSellObj();
        this.clearLimitBuyObj();
        this.clearLimitSellObj();
        if(this.server.activatedSocket == "Binance") {
            this.server.liquidityWS.close();
            this.server.liquidityWSTrade.close();
            this.server.liquidityWSDepth.close();
            this.SocketDataStatus = false;
        }
        if(this.server.activatedSocket == "Poloniex") {
            //this.callPolyneixSocket(2)
            //this.callPoloTrade(2)
        }
        if(this.server.activatedSocket == 'HitBTC') {
            this.updateLiquiditySocket(2);
            this.stopInterval();
            this.getLiveDataFromHitBTCForCoinPair(this.getCoinSymbol(this.coinPairListArr));
        }
        this.searchText = "";
        this.currentCoinObj.coinShort = this.coinListArr.filter((x) => x.coinId == this.currentCoinObj.coinId)[0].coinShortName;
        this.currentCoinObj.coinFullName = this.coinListArr.filter((x) => x.coinId == this.currentCoinObj.coinId)[0].coinFullName;
        this.coinPairListArr = [];
        // this.updateLiquiditySocket(2);
        this.getCoinPairOnCoinChange();
    }

    /** Function for select coin pair */
    selectPair(data) {
        this.clearMarketBuyObj();
        this.clearMarketSellObj();
        this.clearLimitBuyObj();
        this.clearLimitSellObj();
        if(this.server.activatedSocket == "Binance") {
            this.SocketDataStatus = false;
        }
        data.selected = true;
        this.currentPairCoinObj.coinId = data.coinID;
        this.currentPairCoinObj.coinShort = data.coin;
        this.currentPairCoinObj.coinFullName = data.coinFullName;
        if(this.feeListApi) {
            let ind = this.feeList.findIndex(x => x.coinShortName == this.currentPairCoinObj.coinShort);
            this.takerFee = this.feeList[ind].takerFee;
            this.makerFee = this.feeList[ind].makerFee;
        }
        this.tradeViewPair = this.currentCoinObj.coinShort+"/"+this.currentPairCoinObj.coinShort;
        if(this.server.activatedSocket == "Binance") {
            this.server.liquidityWS.close();
            this.server.liquidityWSTrade.close();
            this.server.liquidityWSDepth.close();
            this.server.pair = this.currentPairCoinObj.coinShort + this.currentCoinObj.coinShort;
            this.server.pair = this.server.pair.toLowerCase();   
            this.server.thirdPartySocket()
        } else if(this.server.activatedSocket == "Poloniex") {
            //this.callPolyneixSocket(2)
            //this.callPoloTrade(2);
            this.poloniexTradePair = this.currentCoinObj.coinShort+"_"+this.currentPairCoinObj.coinShort;
            this.server.thirdPartySocket();
        } else if(this.server.activatedSocket == "HitBTC") {
            //this.updateLiquiditySocket(2);
            this.HitBTCPair = this.currentPairCoinObj.coinShort+this.currentCoinObj.coinShort;
            this.server.thirdPartySocket();
            // this.stopInterval();
            // this.getLiveDataFromHitBTCForCoinPair(this.getCoinSymbol(this.coinPairListArr));
        }
        this.coinPairListArr.forEach((obj) => {
            if(data.coinID != obj.coinID) {
                obj.selected = false;
            }
        });
        if(this.feeListApi) {
            let ind = this.feeList.findIndex(x => x.coinShortName == this.currentPairCoinObj.coinShort);
            this.takerFee = this.feeList[ind].takerFee;
            this.makerFee = this.feeList[ind].makerFee;
        }
        this.getTradeHistory();
        this.getSellOrder();
        this.getBuyOrder();
        //this.drawTradingChart();
        this.getHeaderPrice();
        if(localStorage.getItem("token")) {
            this.getUserPairCoinBalance();
            this.getUserOpenOrder();
            this.getUserOrderHistory();
        }
    }

    /** Function for socket subscribe/unsubcribe */
    updateLiquiditySocket(type) {
        let data = {
            "method": "",
            "params": {
                "symbol": this.HitBTCPair,
                "limit": ""
            },
            "id": ""
        }
        switch(type) {
            case 1:                
                if(this.server.liquidityWSHitBTC.readyState) {
                    data.method = "subscribeTicker";
                    this.server.liquidityWSHitBTC.send(JSON.stringify(data));
                    /** Subscribe for order book data */
                    data.method = "subscribeOrderbook";
                    this.server.liquidityWSHitBTC.send(JSON.stringify(data));
                    /** Subscribe for trade history data */
                    data.method = "subscribeTrades";
                    data.params.limit = "50";
                    this.server.liquidityWSHitBTC.send(JSON.stringify(data));
                }  

                break;
            case 2:
                if(this.server.liquidityWSHitBTC.readyState) {                    
                    data.method = "unsubscribeTicker";
                    this.server.liquidityWSHitBTC.send(JSON.stringify(data));

                    /** Unsubscribe order book data */
                    data.method = "unsubscribeOrderbook";
                    this.server.liquidityWSHitBTC.send(JSON.stringify(data));

                    /** Unsubscribe trade history data */
                    data.method = "unsubscribeTrades";
                    this.server.liquidityWSHitBTC.send(JSON.stringify(data));                    
                }                
                break;
        }
    }

    /** Function for modify coin pair list after trade execute */
    getCoinPairAfterExecution() {
        let data = {
            "eventExternal": {
                "name":"request_coin_pair_list",
                "key":"mykey"
            },
            "transferObjectMap": {
                "gatewayrequest": {
	                "baseCurrency": this.currentCoinObj.coinId
                }
            }
        }
        this.server.postApi("",data,0).subscribe((succ) => {
            if(succ.transferObjectMap.statusCode == 200) {
                let data = succ.transferObjectMap.coinPairList;
                let cPairListArr = succ.transferObjectMap.coinLastPairList;
                data.forEach((obj) => {
                    let ind = this.coinPairListArr.findIndex((x) => x.coinID == obj.coin_id);
                    if(ind != -1) {
                        this.coinPairListArr[ind].volume = obj.volume;
                        this.coinPairListArr[ind].average = obj.average;
                    }
                });
                cPairListArr.forEach((obj) => {
                    let ind = this.coinPairListArr.findIndex((x) => x.coin == obj.COIN_SHORT_NAME);
                    if(ind != -1) {
                        this.coinPairListArr[ind].last_price = obj.LAST_PRICE;
                    }
                });
            }
        }, (err) => {
        });
    }

    /** Function to get coin list from api */
    getCoinList() {
        let data = {
            "eventExternal":  {
                "name":"request_get_coin_list",
                "key":"mykey"
            },
            "transferObjectMap":{}
        }
        this.spinnerService.show();
        this.server.postApi('',data,0).subscribe((succ) => {
            this.spinnerService.hide();
            if(succ.transferObjectMap.statusCode == 200) {
                let data = succ.transferObjectMap.coinList;
                this.coinListArr = data.filter((x) => x.coinType=="crypto" && (x.coinShortName == 'IPR' ||x.coinShortName == 'BTC' || x.coinShortName == 'ETH' || x.coinShortName == 'USDT'));
                this.currentCoinObj.coinId = this.coinListArr[0].coinId;
                this.currentCoinObj.coinShort = this.coinListArr[0].coinShortName;
                this.currentCoinObj.coinFullName = this.coinListArr[0].coinFullName;
                this.coinPairListArr = [];
                this.getCoinPair();
            } else {
                this.appC.showErrToast(succ.transferObjectMap.message);
            }
        }, (err) => {
            this.spinnerService.hide();
        });
    }

    /** Function to get coin pair list from api*/
    getCoinPairOnCoinChange() {
        this.coinPairListArr = [];
        let data = {
            "eventExternal": {
                "name": "request_coin_pair_list",
                "key": "mykey"
            },
            "transferObjectMap": {
                "gatewayrequest": {
                    "baseCurrency":this.currentCoinObj.coinId
                }
            }
        }
        this.spinnerService.show();
        this.server.postApi('',data,0).subscribe((succ) => {
            this.spinnerService.hide();
            if(succ.transferObjectMap.statusCode == 200) {
                // let data = succ.transferObjectMap.coinPairList;
                let data = [];
                succ.transferObjectMap.coinPairList.forEach(obj => {
                    if(obj.coin_short_name == 'BTC'|| obj.coin_short_name == 'ETH'|| obj.coin_short_name == 'XRP'|| obj.coin_short_name == 'BCH'|| obj.coin_short_name == 'XLM'|| obj.coin_short_name == 'LTC'|| obj.coin_short_name == 'IOTA' || obj.coin_short_name == 'USDT' || obj.coin_short_name == 'XVG'|| obj.coin_short_name == 'IPR' || obj.coin_short_name == 'ECH') {
                        data.push(obj);
                    }
                });
                data.forEach(obj => {
                    this.coinPairListArr.push({
                        coinID: obj.coin_id,
                        coin: obj.coin_short_name,
                        coinFullName: obj.coin_full_name,
                        volume: obj.volume,
                        average: obj.average,
                        last_price: ''
                    });
                });
                let cPairListArr = succ.transferObjectMap.coinLastPairList;
                this.symbolArr = this.getCoinSymbol(this.coinPairListArr);
                this.coinPairListArr.forEach((obj) => {
                    obj.last_price = cPairListArr.filter((x) => x.COIN_SHORT_NAME == obj.coin)[0].LAST_PRICE;
                    obj.selected = false;
                });
                if(this.coinPairListArr.length) {
                    this.currentPairCoinObj.coinShort = this.coinPairListArr[0].coin;
                    this.currentPairCoinObj.coinId = this.coinPairListArr[0].coinID;
                    this.currentPairCoinObj.coinFullName = this.coinPairListArr[0].coinFullName;
                    this.coinPairListArr[0].selected = true;
                    this.tradeViewPair = this.currentCoinObj.coinShort+"/"+this.currentPairCoinObj.coinShort;
                    this.HitBTCPair = this.currentPairCoinObj.coinShort+this.currentCoinObj.coinShort;
                    if(this.feeListApi) {
                        let ind = this.feeList.findIndex(x => x.coinShortName == this.currentPairCoinObj.coinShort);
                        this.takerFee = this.feeList[ind].takerFee;
                        this.makerFee = this.feeList[ind].makerFee;
                    }
                    
                    /** for binance socket */
                    if(this.server.activatedSocket == "Binance") {
                        this.server.pair = this.currentPairCoinObj.coinShort + this.currentCoinObj.coinShort
                        this.server.pair = this.server.pair.toLowerCase();
                        this.server.thirdPartySocket();   
                        this.callCoinListWithSocket(this.server.activatedSocket,1);
                    } else if(this.server.activatedSocket == "Poloniex") {
                        this.poloniexTradePair = this.currentCoinObj.coinShort+"_"+this.currentPairCoinObj.coinShort;
                        this.server.thirdPartySocket();
                        //this.callCoinListWithSocket(this.server.activatedSocket,1);
                    } else if(this.server.activatedSocket == "HitBTC") {
                        this.server.thirdPartySocket();
                        this.getLiveDataFromHitBTCForCoinPair(this.getCoinSymbol(this.coinPairListArr));
                        //this.callCoinListWithSocket(this.server.activatedSocket,1);
                    }
                    
                    this.getTradeHistory();
                    this.getSellOrder();
                    this.getBuyOrder();
                    //this.drawTradingChart();
                    this.getHeaderPrice();
                    if(localStorage.getItem("token")) {
                        this.getUserBaseCoinBalance();
                        this.getUserPairCoinBalance();
                        this.getUserOpenOrder();
                        this.getUserOrderHistory();
                    }
                }
            } else {
                this.coinPairListArr = [];
                this.appC.showErrToast(succ.transferObjectMap.message);
            }
        }, (err) => {
            this.spinnerService.hide();
        });
    }

    /** Function to get coin pair list from api*/
    getCoinPair() {
        this.coinPairListArr = [];
        let data = {
            "eventExternal": {
                "name": "request_coin_pair_list",
                "key": "mykey"
            },
            "transferObjectMap": {
                "gatewayrequest": {
                    "baseCurrency":this.currentCoinObj.coinId
                }
            }
        }
        this.spinnerService.show();
        this.server.postApi('',data,0).subscribe((succ) => {
            this.spinnerService.hide();
            if(succ.transferObjectMap.statusCode == 200) {
                // let data = succ.transferObjectMap.coinPairList;
                let data = [];
                succ.transferObjectMap.coinPairList.forEach(obj => {
                    if(obj.coin_short_name == 'BTC'|| obj.coin_short_name == 'ETH'|| obj.coin_short_name == 'XRP'|| obj.coin_short_name == 'BCH'|| obj.coin_short_name == 'XLM'|| obj.coin_short_name == 'LTC'|| obj.coin_short_name == 'IOTA' || obj.coin_short_name == 'USDT' || obj.coin_short_name == 'XVG'|| obj.coin_short_name == 'IPR' || obj.coin_short_name == 'ECH') {
                        data.push(obj);
                    }
                });
                data.forEach(obj => {
                    this.coinPairListArr.push({
                        coinID: obj.coin_id,
                        coin: obj.coin_short_name,
                        coinFullName: obj.coin_full_name,
                        volume: obj.volume,
                        average: obj.average,
                        last_price: ''
                    });
                });
                let cPairListArr = succ.transferObjectMap.coinLastPairList;
                    // if(this.currentCoinObj.coinShort == 'USDT') {
                    //     data.forEach((obj) => {
                    //         if(obj.coin_short_name == 'BTC'|| obj.coin_short_name == 'ETH'|| obj.coin_short_name == 'XRP'|| obj.coin_short_name == 'BCH'|| obj.coin_short_name == 'XLM'|| obj.coin_short_name == 'LTC'|| obj.coin_short_name == 'IOTA'|| obj.coin_short_name == 'IPR') {
                    //             this.coinPairListArr.push({
                    //                 coinID: obj.coin_id,
                    //                 coin: obj.coin_short_name,
                    //                 coinFullName: obj.coin_full_name,
                    //                 volume: obj.volume,
                    //                 average: obj.average
                    //             });
                    //         } 
                    //     });
                    // } else if(this.currentCoinObj.coinShort == 'IPR') {
                    //     data.forEach((obj) => {
                    //         if(obj.coin_short_name == 'XRP'|| obj.coin_short_name == 'XLM'|| obj.coin_short_name == 'LTC'|| obj.coin_short_name == 'IOTA') {
                    //             this.coinPairListArr.push({
                    //                 coinID: obj.coin_id,
                    //                 coin: obj.coin_short_name,
                    //                 coinFullName: obj.coin_full_name,
                    //                 volume: obj.volume,
                    //                 average: obj.average
                    //             });
                    //         } 
                    //     });

                    // } else {
                    //     data.forEach((obj) => {
                    //         if(obj.coinType == 'crypto' && obj.coin_id > this.currentCoinObj.coinId) {
                    //             this.coinPairListArr.push({
                    //                 coinID: obj.coin_id,
                    //                 coin: obj.coin_short_name,
                    //                 coinFullName: obj.coin_full_name,
                    //                 volume: obj.volume,
                    //                 average: obj.average
                    //             });
                    //         } 
                    //     });
                    // }
                this.symbolArr = this.getCoinSymbol(this.coinPairListArr);
                this.coinPairListArr.forEach((obj) => {
                    obj.last_price = cPairListArr.filter((x) => x.COIN_SHORT_NAME == obj.coin)[0].LAST_PRICE;
                    obj.selected = false;
                });
                if(this.coinPairListArr.length) {
                    let ind = this.coinPairListArr.findIndex(x => x.coin == this.currentPairCoinObj.coinShort);
                    if(ind > -1) {
                        this.coinPairListArr[ind].selected = true;
                        this.currentPairCoinObj.coinId = this.coinPairListArr[ind].coinID;
                        this.currentPairCoinObj.coinFullName = this.coinPairListArr[ind].coinFullName;
                    }
                    
                    // this.currentPairCoinObj.coinShort = this.coinPairListArr[0].coin;
                    // this.currentPairCoinObj.coinId = this.coinPairListArr[0].coinID;
                    // this.currentPairCoinObj.coinFullName = this.coinPairListArr[0].coinFullName;
                    this.tradeViewPair = this.currentCoinObj.coinShort+"/"+this.currentPairCoinObj.coinShort;
                    this.HitBTCPair = this.currentPairCoinObj.coinShort+this.currentCoinObj.coinShort;
                    if(this.feeListApi) {
                        let ind = this.feeList.findIndex(x => x.coinShortName == this.currentPairCoinObj.coinShort);
                        this.takerFee = this.feeList[ind].takerFee;
                        this.makerFee = this.feeList[ind].makerFee;
                    }
                    
                    /** for binance socket */
                    if(this.server.activatedSocket == "Binance") {
                        this.server.pair = this.currentPairCoinObj.coinShort + this.currentCoinObj.coinShort
                        this.server.pair = this.server.pair.toLowerCase();
                        this.server.thirdPartySocket();   
                        this.callCoinListWithSocket(this.server.activatedSocket,1);
                    } else if(this.server.activatedSocket == "Poloniex") {
                        this.poloniexTradePair = this.currentCoinObj.coinShort+"_"+this.currentPairCoinObj.coinShort;
                        this.server.thirdPartySocket();
                        //this.callCoinListWithSocket(this.server.activatedSocket,1);
                    } else if(this.server.activatedSocket == "HitBTC") {
                        this.server.thirdPartySocket();
                        this.getLiveDataFromHitBTCForCoinPair(this.getCoinSymbol(this.coinPairListArr));
                        //this.callCoinListWithSocket(this.server.activatedSocket,1);
                    }
                    
                    this.getTradeHistory();
                    this.getSellOrder();
                    this.getBuyOrder();
                    //this.drawTradingChart();
                    this.getHeaderPrice();
                    if(localStorage.getItem("token")) {
                        this.getUserBaseCoinBalance();
                        this.getUserPairCoinBalance();
                        this.getUserOpenOrder();
                        this.getUserOrderHistory();
                    }
                }
            } else {
                this.coinPairListArr = [];
                this.appC.showErrToast(succ.transferObjectMap.message);
            }
        }, (err) => {
            this.spinnerService.hide();
        });
    }

    /** Function to get trade history */
    getTradeHistory() {
        this.tradeHistoryArr = [];
        // let data = {
        //     "eventExternal":{
        //         "name":"request_get_order",
        //         "key":"mykey"
        //     },
        //     "transferObjectMap":{
        //         "type": "tradeHistory",
        //         "baseCurrency": this.currentCoinObj.coinId,
        //         "executableCurrency": this.currentPairCoinObj.coinId
        //     }
        // }
        let data = {
            "baseCoin": this.currentCoinObj.coinId,
            "exeCoin": this.currentPairCoinObj.coinId,
        }
        this.spinnerService.show();
        this.server.postApi('trade-history/get-detail',data,0).subscribe((succ) => {
            this.spinnerService.hide();
            if(succ.transferObjectMap.statusCode == 200) {
                succ.transferObjectMap.tradeHistoryList.forEach((obj) => {
                    this.tradeHistoryArr.push({
                        price: obj.price.toFixed(8),
                        amount: obj.amount.toFixed(8),
                        total: (obj.price*obj.amount).toFixed(8),
                        time: obj.orderExecutionTime,
                        type: obj.orderType
                    });
                });
            } else {
                this.appC.showErrToast(succ.transferObjectMap.message);
            }
        }, (err) => {
            this.spinnerService.hide();
        });
    }

    /** Function to fetch sell order from api */
    getSellOrder() {
        this.sellOrderArr = [];
        let data = {
            "eventExternal": {
                "name":"request_get_order",
                "key":"mykey"
            },
            "transferObjectMap": {
                "type": "sell",
                "baseCurrency": this.currentCoinObj.coinId,
                "executableCurrency": this.currentPairCoinObj.coinId
            }        
        }
        this.server.postApi("",data,0).subscribe((succ) => {
            if(succ.transferObjectMap.statusCode == 200) {
                succ.transferObjectMap.sellOrderList.forEach((obj) => {
                    var ind = this.sellOrderArr.findIndex((x) => x.price == obj.price);
                    if(ind != -1) {
                        this.sellOrderArr[ind].amount = (Number(this.sellOrderArr[ind].amount) + Number(obj.amount)).toFixed(8);
                        this.sellOrderArr[ind].total = (this.sellOrderArr[ind].price * this.sellOrderArr[ind].amount).toFixed(8);
                    } else {
                        this.sellOrderArr.push({
                            price: obj.price.toFixed(8),
                            amount: obj.amount.toFixed(8),
                            total: (obj.price*obj.amount).toFixed(8)
                        });
                    }
                });
            }
        }, (err) => {
        });
    }

    /** Function to fetch buy order from api */
    getBuyOrder() {
        this.buyOrderArr = [];
        let data = {
            "eventExternal": {
                "name":"request_get_order",
                "key":"mykey"
            },
            "transferObjectMap": {
                "type": "buy",
                "baseCurrency": this.currentCoinObj.coinId,
                "executableCurrency": this.currentPairCoinObj.coinId
            }        
        }
        this.server.postApi("",data,0).subscribe((succ) => {
            if(succ.transferObjectMap.statusCode == 200) {
                succ.transferObjectMap.buyOrderList.forEach((obj) => {
                    var ind = this.buyOrderArr.findIndex((x) => x.price == obj.price);
                    if(ind != -1) {
                        this.buyOrderArr[ind].amount = (Number(this.buyOrderArr[ind].amount) + Number(obj.amount)).toFixed(8);
                        this.buyOrderArr[ind].total = (this.buyOrderArr[ind].price * this.buyOrderArr[ind].amount).toFixed(8);
                    } else {
                        this.buyOrderArr.push({
                            price: obj.price.toFixed(8),
                            amount: obj.amount.toFixed(8),
                            total: (obj.price*obj.amount).toFixed(8),
                        });
                    }
                });
            }
        }, (err) => {
        });
    }

    /** Function to draw trading chart */ 
    drawTradingChart() {
        let currVal = this.tradeViewPair.split("/")[0];
        let exeVal = this.tradeViewPair.split("/")[1];
        if(exeVal == 'ECH') {
            exeVal = 'ETC';
        }
        this.tradingChart = setTimeout(() => {
            if($('body').hasClass('nightmode')) {
                new TradingView.widget({
                    fullscreen: true,
                    symbol: exeVal+"/"+currVal,
                    interval: 'D',
                    container_id: "tradingChart",
                    //datafeed: new Datafeeds.UDFCompatibleDatafeed("http://172.16.21.20:8083/bitnomyChart/exchange-feed",60000),
                    datafeed: new Datafeeds.UDFCompatibleDatafeed("https://londonex.io:8443/LCXChart/exchange-feed",60000),
                    library_path: "assets/lib/charting_library_night/",
                    locale: "en",
                    drawings_access: { type: 'black', tools: [{ name: "Regression Trend" }] },
                    disabled_features: ["use_localstorage_for_settings"],
                    overrides: {
                        "paneProperties.background": "#000",
                        "paneProperties.vertGridProperties.color": "#454545",
                        "paneProperties.horzGridProperties.color": "#454545",
                        "symbolWatermarkProperties.transparency": 90,
                        "scalesProperties.textColor": "#AAA"
                    }
                });
            } else {
                new TradingView.widget({
                    fullscreen: true,
                    symbol: exeVal+"/"+currVal,
                    interval: 'D',
                    container_id: "tradingChart",
                    //datafeed: new Datafeeds.UDFCompatibleDatafeed("http://172.16.21.20:8083/bitnomyChart/exchange-feed",60000),
                    datafeed: new Datafeeds.UDFCompatibleDatafeed("https://londonex.io:8443/LCXChart/exchange-feed",60000),
                    library_path: "assets/lib/charting_library/",
                    locale: "en",
                    drawings_access: { type: 'black', tools: [{ name: "Regression Trend" }] },
                    disabled_features: ["use_localstorage_for_settings"]
                });
            }
        },500);
    }
    
    /** Function for get header price for selected pair coin */
    getHeaderPrice() {
        let data = {
            "eventExternal": {
                "name":"request_get_header_data",
                "key":"mykey"
            },
            "transferObjectMap": {
                "gatewayrequest": {
                    "baseCurrency": this.currentCoinObj.coinId,
                    "executableCurrency": this.currentPairCoinObj.coinId
                }
           }            
        }
        this.server.postApi("",data,0).subscribe((succ) => {
            if(succ.transferObjectMap.statusCode == 200) {
                this.headerPriceObj.average = succ.transferObjectMap.average;
                this.headerPriceObj.currPrice = succ.transferObjectMap.lastPrice;
                this.headerPriceObj.highest = succ.transferObjectMap.maxPrice;
                this.headerPriceObj.lowest = succ.transferObjectMap.minPrice;
                this.headerPriceObj.volume = succ.transferObjectMap.volume;

                let currPairArr = this.coinPairListArr.filter(obj => obj.coin == this.currentPairCoinObj.coinShort);
                if(currPairArr.length) {
                    currPairArr[0].last_price = this.headerPriceObj.currPrice;
                    currPairArr[0].volume = this.headerPriceObj.volume;
                    currPairArr[0].average = this.headerPriceObj.average;
                }
            } else {
                this.headerPriceObj.average = "";
                this.headerPriceObj.currPrice = "";
                this.headerPriceObj.highest = "";
                this.headerPriceObj.lowest = "";
                this.headerPriceObj.volume = "";
            }
        }, (err) => {
        });
    }

    /** Function for getting user balance of selected coin */
    getUserBaseCoinBalance() {
        let data = {
            "eventExternal": {
                "name":"request_get_wallet_balance",
                "key":"mykey"
            },
            "transferObjectMap": {
                "coinId": this.currentCoinObj.coinId,       
                "loginToken": localStorage.getItem("token")
            }
        }
        this.server.postApi("",data,0).subscribe((succ) => {
            if(succ.transferObjectMap.statusCode == 200) {
                this.userData.baseCoinBal = succ.transferObjectMap.walletBalance;
            } else if(succ.transferObjectMap.statusCode == 403) {
                this.header.logOut();
            } else {
                this.appC.showErrToast(succ.transferObjectMap.message);
            }
        }, (err) => {
        });
    }

    /** Function for getting user balance of selected coin */
    getUserPairCoinBalance() {
        let data = {
            "eventExternal": {
                "name":"request_get_wallet_balance",
                "key":"mykey"
            },
            "transferObjectMap": {
                "coinId": this.currentPairCoinObj.coinId,       
                "loginToken": localStorage.getItem("token")
            }
        }
        this.server.postApi("",data,0).subscribe((succ) => {
            if(succ.transferObjectMap.statusCode == 200) {
                this.userData.pairCoinBal = succ.transferObjectMap.walletBalance;
            } else if(succ.transferObjectMap.statusCode == 403) {
                this.header.logOut();
            } else {
                this.appC.showErrToast(succ.transferObjectMap.message);
            }
        }, (err) => {
        });
    }

    /** Function to get user's open order */
    getUserOpenOrder() {
        this.openOrderArr = [];
        // let data = {
        //     "eventExternal": {
        //         "name":"request_open_order",
        //         "key":"mykey"
        //     },
        //     "transferObjectMap": {
        //         "gatewayrequest": {
        //             "baseCurrency": this.currentCoinObj.coinId,
        //             "executableCurrency": this.currentPairCoinObj.coinId,
        //             "loginToken": localStorage.getItem("token")
        //         }
        //     }
        // }
        let data = {
            "baseCoin": this.currentCoinObj.coinId,
            "exeCoin": this.currentPairCoinObj.coinId,
        }
        this.server.postApi('my-active-orders',data,0).subscribe((succ) => {
            if(succ.transferObjectMap.statusCode == 200) {
                this.openOrderArr = succ.transferObjectMap.openOrderList;
                this.openOrderArr.forEach((obj) => {
                    if(obj.pair.includes('ECH')) {

                    }
                    obj.click = false;
                    if(obj.triggerCondition == "0") {
                        obj.tri_cond = ">";
                    } else if(obj.triggerCondition == "1") {
                        obj.tri_cond = "<";
                    } else if(obj.triggerCondition == "2") {
                        obj.tri_cond = "----";
                    } else {
                        obj.tri_cond = "";
                    }
                });
            } else if(succ.transferObjectMap.statusCode == 403) {
                this.header.logOut();
            } else {
                this.appC.showErrToast(succ.transferObjectMap.message);
            }
        }, (err) => {
        });
    }

    /** Function to get user's order history */
    getUserOrderHistory() {
        this.orderHistoryArr = [];
        // let data = {
        //     "eventExternal": {
        //         "name":"request_order__history",
        //         "key":"mykey"
        //     },
        //     "transferObjectMap": {
        //         "gatewayrequest": {
        //             "baseCurrency": this.currentCoinObj.coinId,
        //             "executableCurrency": this.currentPairCoinObj.coinId,
        //             "loginToken": localStorage.getItem("token")
        //         }
        //     }
        // }
        let data = {
            "baseCoin": this.currentCoinObj.coinId,
            "exeCoin": this.currentPairCoinObj.coinId,
        }
        this.server.postApi('my-order-history',data,0).subscribe((succ) => {
            if(succ.transferObjectMap.statusCode == 200) {
                this.orderHistoryArr = succ.transferObjectMap.orderHistoryList;
                this.orderHistoryArr.forEach((obj) => {
                    switch(obj.orderStatus) {
                        case 'ACTIVE':
                            obj.amount = (obj.tradeHistoryAmount - obj.amount).toFixed(8);
                            obj.total = (obj.amount * obj.price).toFixed(8);
                            break;
                        case 'INACTIVE':
                            obj.amount = obj.tradeHistoryAmount.toFixed(8);
                            obj.total = (obj.amount * obj.price).toFixed(8);
                            break;
                        case 'CANCEL':
                            obj.amount = obj.amount.toFixed(8);
                            obj.total = (obj.amount * obj.price).toFixed(8);
                            break;
                    }
                });
            } else if(succ.transferObjectMap.statusCode == 403) {
                this.header.logOut();
            } else {
                this.appC.showErrToast(succ.transferObjectMap.message);
            }
        }, (err) => {
        });
    }

    /** Function to navigate login page */
    goToLogin() {
        this.router.navigateByUrl('header/login');
    }

    /** Function to restrict space */
    restrictSpace(event) {
        var k = event.charCode;
        if (k === 32) return false;
    }

    /** Function to restrict character */
    restrictChar(event) {
        var k = event.charCode;
        if (event.key === 'Backspace')
            k = 8;
        if (k >= 48 && k <= 57 || k == 8 || k == 46)
            return true;
        else
            return false;    
    }

    /** Function to restrict length after dot */
    restrictLength(type) {
        switch(type) {
            case 'lbp':
                if(this.limitBuyObj.price.includes(".")) {
                    if (!this.regexForEightChar.test(this.limitBuyObj.price)) {
                        let tempVal = this.limitBuyObj.price.split('.');
                        this.limitBuyObj.price = tempVal[0] + '.' + tempVal[1].slice(0, 8);
                    }
                }
                break;
            case 'lba':
                if(this.limitBuyObj.amount.includes(".")) {
                    if (!this.regexForEightChar.test(this.limitBuyObj.amount)) {
                        let tempVal = this.limitBuyObj.amount.split('.');
                        this.limitBuyObj.amount = tempVal[0] + '.' + tempVal[1].slice(0, 8);
                    }
                }
                break;
            case 'lsp':
                if(this.limitSellObj.price.includes(".")) {
                    if (!this.regexForEightChar.test(this.limitSellObj.price)) {
                        let tempVal = this.limitSellObj.price.split('.');
                        this.limitSellObj.price = tempVal[0] + '.' + tempVal[1].slice(0, 8);
                    }
                }
                break;
            case 'lsa':
                if(this.limitSellObj.amount.includes(".")) {
                    if (!this.regexForEightChar.test(this.limitSellObj.amount)) {
                        let tempVal = this.limitSellObj.amount.split('.');
                        this.limitSellObj.amount = tempVal[0] + '.' + tempVal[1].slice(0, 8);
                    }
                }
                break;
            case 'mba':
                if(this.marketBuyObj.amount.includes(".")) {
                    if (!this.regexForEightChar.test(this.marketBuyObj.amount)) {
                        let tempVal = this.marketBuyObj.amount.split('.');
                        this.marketBuyObj.amount = tempVal[0] + '.' + tempVal[1].slice(0, 8);
                    }
                }
                break;
            case 'msa':
                if(this.marketSellObj.amount.includes(".")) {
                    if (!this.regexForEightChar.test(this.marketSellObj.amount)) {
                        let tempVal = this.marketSellObj.amount.split('.');
                        this.marketSellObj.amount = tempVal[0] + '.' + tempVal[1].slice(0, 8);
                    }
                }
                break;
            case 'sbs':
                if(this.sLimitBuyObj.stop.includes(".")) {
                    if (!this.regexForEightChar.test(this.sLimitBuyObj.stop)) {
                        let tempVal = this.sLimitBuyObj.stop.split('.');
                        this.sLimitBuyObj.stop = tempVal[0] + '.' + tempVal[1].slice(0, 8);
                    }
                }
                break;
            case 'sbp':
                if(this.sLimitBuyObj.price.includes(".")) {
                    if (!this.regexForEightChar.test(this.sLimitBuyObj.price)) {
                        let tempVal = this.sLimitBuyObj.price.split('.');
                        this.sLimitBuyObj.price = tempVal[0] + '.' + tempVal[1].slice(0, 8);
                    }
                }
                break;
            case 'sba':
                if(this.sLimitBuyObj.amount.includes(".")) {
                    if (!this.regexForEightChar.test(this.sLimitBuyObj.amount)) {
                        let tempVal = this.sLimitBuyObj.amount.split('.');
                        this.sLimitBuyObj.amount = tempVal[0] + '.' + tempVal[1].slice(0, 8);
                    }
                }
                break;
            case 'sss':
                if(this.sLimitSellObj.stop.includes(".")) {
                    if (!this.regexForEightChar.test(this.sLimitSellObj.stop)) {
                        let tempVal = this.sLimitSellObj.stop.split('.');
                        this.sLimitSellObj.stop = tempVal[0] + '.' + tempVal[1].slice(0, 8);
                    }
                }
                break;
            case 'ssp':
                if(this.sLimitSellObj.price.includes(".")) {
                    if (!this.regexForEightChar.test(this.sLimitSellObj.price)) {
                        let tempVal = this.sLimitSellObj.price.split('.');
                        this.sLimitSellObj.price = tempVal[0] + '.' + tempVal[1].slice(0, 8);
                    }
                }
                break;
            case 'ssa':
                if(this.sLimitSellObj.amount.includes(".")) {
                    if (!this.regexForEightChar.test(this.sLimitSellObj.amount)) {
                        let tempVal = this.sLimitSellObj.amount.split('.');
                        this.sLimitSellObj.amount = tempVal[0] + '.' + tempVal[1].slice(0, 8);
                    }
                }
                break;
        }
    }

    /** Function to calculate total amount */
    valueChangeFunc(type) {
        if(type == "LBP" || type == "LBA") {
            if(this.limitBuyObj.amount && this.limitBuyObj.price && Number(this.limitBuyObj.amount) >= 0 && Number(this.limitBuyObj.price) >= 0) {
                this.limitBuyObj.total = (Number(this.limitBuyObj.amount) * Number(this.limitBuyObj.price)).toFixed(8);
            } else {
                this.limitBuyObj.total = "";
            }
        }
        if(type == "SBP" || type == "SBA") {
            if(this.sLimitBuyObj.price && this.sLimitBuyObj.amount && Number(this.sLimitBuyObj.price) >= 0 && Number(this.sLimitBuyObj.amount) >= 0) {
                this.sLimitBuyObj.total = (Number(this.sLimitBuyObj.price) * Number(this.sLimitBuyObj.amount)).toFixed(8);
            } else {
                this.sLimitBuyObj.total = "";
            }
        }
        if(type == "LSP" || type == "LSA") {
            if(this.limitSellObj.amount && this.limitSellObj.price && Number(this.limitSellObj.amount) >= 0 && Number(this.limitSellObj.price) >= 0) {
                this.limitSellObj.total = (Number(this.limitSellObj.amount) * Number(this.limitSellObj.price)).toFixed(8);
            } else {
                this.limitSellObj.total = "";
            }
        }        
        if(type == "SSP" || type == "SSA") {
            if(this.sLimitSellObj.price && this.sLimitSellObj.amount && Number(this.sLimitSellObj.price) >= 0 && Number(this.sLimitSellObj.amount) >= 0) {
                this.sLimitSellObj.total = (Number(this.sLimitSellObj.price) * Number(this.sLimitSellObj.amount)).toFixed(8);
            } else {
                this.sLimitSellObj.total = "";
            }
        }
    }

    /** Function for buy order */
    buyFunc() {
        switch(this.buyOrderType) {
            case 'LIMIT':
                this.limitBuyFunc();
                break;
            case 'MARKET':
                this.marketBuyFunc();
                break;
            case 'STOPLIMIT':
                this.stopBuyFunc();
                break;
        }
    }

    /** Function for limit buy */
    limitBuyFunc() {
        if(this.limitBuyObj.price == "") {
            this.appC.showErrToast("Enter price value.");
            return;
        } else if(this.limitBuyObj.price == ".") {
            this.appC.showErrToast("Enter valid price value.");
            return;
        } else if(Number(this.limitBuyObj.price) <= 0) {
            this.appC.showErrToast("Enter valid price value.");
            return;
        } else if(this.limitBuyObj.amount == "") {
            this.appC.showErrToast("Enter amount value.");
            return;
        } else if(this.limitBuyObj.amount == ".") {
            this.appC.showErrToast("Enter valid amount value.");
            return;
        } else if(Number(this.limitBuyObj.amount) <= 0) {
            this.appC.showErrToast("Enter valid amount value.");
            return;
        } else if(Number(this.limitBuyObj.total) > Number(this.userData.baseCoinBal)){
            this.appC.showErrToast("You can't buy coins more than your wallet amount.");
            return;            
        } else {
            let data = {
                "eventExternal": {
                    "name": "request_buy_add_order",
                    "key": "mykey"
                },
                "transferObjectMap": {
                    "tradingType": "LIMIT",
                    "orderType": "BUY", 
                    "amount": Number(this.limitBuyObj.amount),
                    "price": Number(this.limitBuyObj.price),
                    "total": Number(this.limitBuyObj.total),
                    "baseCurrency": this.currentCoinObj.coinId,
                    "executableCurrency": this.currentPairCoinObj.coinId, 
                    "tradeStop": Number(0),
                    "tradeLimit": Number(0),
                    "loginToken": localStorage.getItem("token")
                }
            }
            this.spinnerService.show();
            this.server.postApi("",data,0).subscribe((succ) => {
                this.spinnerService.hide();
                if(succ.transferObjectMap.statusCode == 200) {
                    this.appC.showSuccToast(succ.transferObjectMap.message);
                    this.clearLimitBuyObj();
                    this.getUserBaseCoinBalance();
                    this.getUserPairCoinBalance();
                    if(localStorage.getItem("token")) {
                        this.getUserOpenOrder();
                        this.getUserOrderHistory();
                    }
                    if(succ.transferObjectMap.isTradeExecuted) {
                        this.getHeaderPrice();
                        this.getCoinPairAfterExecution();
                    }
                } else if(succ.transferObjectMap.statusCode == 403) {
                    this.header.logOut();
                } else {
                    this.appC.showErrToast(succ.transferObjectMap.message);
                }
            }, (err) => {
                this.spinnerService.hide();
            });
        }
    }

    /** Function for market buy */
    marketBuyFunc() {
        if(this.marketBuyObj.amount == "") {
            this.appC.showErrToast("Enter amount value.");
            return;
        } else if(this.marketBuyObj.amount == ".") {
            this.appC.showErrToast("Enter valid amount value.");
            return;
        } else if(Number(this.marketBuyObj.amount) <= 0) {
            this.appC.showErrToast("Enter valid amount value.");
            return;
        } else {
            if(this.SocketDataStatus) {
                let data = {
                    "eventExternal": {
                        "name":"request_buy_add_order",
                        "key":"mykey"
                    },
                    "transferObjectMap": {
                        "tradingType":"MARKET",                    
                        "orderType": "BUY", 
                        "amount": this.marketBuyObj.amount,
                        "price": this.headerPriceObj.currPrice,
                        "baseCurrency": this.currentCoinObj.coinId,
                        "executableCurrency": this.currentPairCoinObj.coinId, 
                        "tradeStop": 0.0,
                        "tradeLimit": 0.0,
                        "loginToken": localStorage.getItem("token")
                    }
                }
                this.spinnerService.show();
                this.server.postApi("",data,0).subscribe((succ1) => {
                    this.spinnerService.hide();
                    if(succ1.transferObjectMap.statusCode == 200) {
                        this.appC.showSuccToast(succ1.transferObjectMap.message);
                        this.getUserBaseCoinBalance();
                        this.getUserPairCoinBalance();
                        if(succ1.transferObjectMap.isTradeExecuted) {
                            // this.getHeaderPrice();
                            this.getCoinPairAfterExecution();
                        }
                    } else if(succ1.transferObjectMap.statusCode == 403) {
                        this.header.logOut();
                    } else {
                        this.appC.showErrToast(succ1.transferObjectMap.message);
                    }
                }, (err1) => {
                    this.spinnerService.hide();                            
                });
            } else {
                let data = {
                    "eventExternal": {
                        "name":"request_estimate_buy_order",
                        "key":"mykey"
                    },
                    "transferObjectMap": {
                        "amount": this.marketBuyObj.amount,
                        "baseCurrency": this.currentCoinObj.coinId,
                        "executableCurrency": this.currentPairCoinObj.coinId,
                        "orderType": "BUY",
                        "loginToken": localStorage.getItem("token")            
                    }
                }        
                this.spinnerService.show();
                this.server.postApi("",data,0).subscribe((succ) => {
                    if(succ.transferObjectMap.statusCode == 200) {
                        if(succ.transferObjectMap.orderContains) {
                            let price = (succ.transferObjectMap.estimatePrice / succ.transferObjectMap.estimateAmount);
                            let amount = succ.transferObjectMap.estimateAmount;
                            let total = (amount * price);
                            if(amount <= Number(this.userData.baseCoinBal)) {
                                let data = {
                                    "eventExternal": {
                                        "name":"request_buy_add_order",
                                        "key":"mykey"
                                    },
                                "transferObjectMap": {
                                        "tradingType":"MARKET",                    
                                        "orderType": "BUY", 
                                        "amount": amount,
                                        "price": price,
                                        "total": total,
                                        "baseCurrency": this.currentCoinObj.coinId,
                                        "executableCurrency": this.currentPairCoinObj.coinId, 
                                        "tradeStop": 0.0,
                                        "tradeLimit": 0.0,
                                        "loginToken": localStorage.getItem("token")
                                    }
                                }
                                this.server.postApi("",data,0).subscribe((succ1) => {
                                    this.spinnerService.hide();
                                    if(succ1.transferObjectMap.statusCode == 200) {
                                        this.appC.showSuccToast(succ1.transferObjectMap.message);
                                        this.clearMarketBuyObj();
                                        this.getUserBaseCoinBalance();
                                        this.getUserPairCoinBalance();
                                        if(localStorage.getItem("token")) {
                                            this.getUserOpenOrder();
                                            this.getUserOrderHistory();
                                        }
                                        if(succ1.transferObjectMap.isTradeExecuted) {
                                            this.getHeaderPrice();
                                            this.getCoinPairAfterExecution();
                                        }
                                    } else if(succ1.transferObjectMap.statusCode == 403) {
                                        this.header.logOut();
                                    } else {
                                        this.appC.showErrToast(succ1.transferObjectMap.message);
                                    }
                                }, (err1) => {
                                    this.spinnerService.hide();                            
                                });
                            } else {
                                this.spinnerService.hide();
                                this.appC.showErrToast("You can't execute the market order because you don't have enough amount to your wallet balance.");
                            }
                        } else {
                            this.spinnerService.hide();
                            this.appC.showErrToast("Don't have enough order.");    
                        }
                    } else if(succ.transferObjectMap.statusCode == 403) {
                        this.spinnerService.hide();
                        this.header.logOut();
                    } else {
                        this.spinnerService.hide();
                        this.appC.showErrToast(succ.transferObjectMap.message);
                    }
                }, (err) => {
                    this.spinnerService.hide();
                });
            }
        }
    }

    /** Function for stop limit buy */
    stopBuyFunc() {
        if(this.sLimitBuyObj.stop == "") {
            this.appC.showErrToast("Enter stop value.");
            return;
        } else if(this.sLimitBuyObj.stop == ".") {
            this.appC.showErrToast("Enter valid stop value.");
            return;
        } else if(Number(this.sLimitBuyObj.stop) <= 0) {
            this.appC.showErrToast("Enter valid stop value.");
            return;
        } else if(this.sLimitBuyObj.price == "") {
            this.appC.showErrToast("Enter limit value.");
            return;
        } else if(this.sLimitBuyObj.price == ".") {
            this.appC.showErrToast("Enter valid limit value.");
            return;
        } else if(Number(this.sLimitBuyObj.price) <= 0) {
            this.appC.showErrToast("Enter valid limit value.");
            return;
        } else if(this.sLimitBuyObj.amount == "") {
            this.appC.showErrToast("Enter amount value.");
            return;
        } else if(this.sLimitBuyObj.amount == ".") {
            this.appC.showErrToast("Enter valid amount value.");
            return;
        } else if(Number(this.sLimitBuyObj.amount) <= 0) {
            this.appC.showErrToast("Enter valid amount value.");
            return;
        } else if(Number(this.sLimitBuyObj.total) > Number(this.userData.baseCoinBal)){
            this.appC.showErrToast("You can't buy coins more than your wallet amount.");
            return;
        } else {
            let data = {
                "eventExternal": {
                    "name":"request_get_stop_limit_count_status",
                    "key":"mykey"
                },
                "transferObjectMap": {
                    "gatewayrequest": {
                        "baseCurrency": this.currentCoinObj.coinId,
                        "executableCurrency": this.currentPairCoinObj.coinId,
                        "loginToken": localStorage.getItem("token")                        
                    }
                }                  
            }
            this.spinnerService.show();
            this.server.postApi("",data,0).subscribe((succ) => {
                if(succ.transferObjectMap.statusCode == 200) {
                    if(succ.transferObjectMap.stopLimitCount <= 1) {
                        let reqData = {
                            "eventExternal": {
                                "name":"request_buy_add_order",
                                "key":"mykey"
                            },
                            "transferObjectMap": {
                                "tradingType":"STOPLIMIT",
                                "orderType": "BUY", 
                                "amount": this.sLimitBuyObj.amount,
                                "price": this.sLimitBuyObj.price,
                                "total": this.sLimitBuyObj.total,
                                "baseCurrency": this.currentCoinObj.coinId,
                                "executableCurrency": this.currentPairCoinObj.coinId, 
                                "tradeStop": this.sLimitBuyObj.stop,
                                "tradeLimit": this.sLimitBuyObj.price,
                                "loginToken": localStorage.getItem("token")
                            }
                        }
                        this.server.postApi("",reqData,0).subscribe((succ1) => {
                            this.spinnerService.hide();
                            if(succ1.transferObjectMap.statusCode == 200) {
                                this.appC.showSuccToast(succ1.transferObjectMap.message);
                                this.clearStopLimitBuyObj();
                                this.getUserBaseCoinBalance();
                                this.getUserPairCoinBalance();
                                if(localStorage.getItem("token")) {
                                    this.getUserOpenOrder();
                                    this.getUserOrderHistory();
                                }
                                if(succ1.transferObjectMap.isTradeExecuted) {
                                    this.getHeaderPrice();
                                    this.getCoinPairAfterExecution();
                                }
                            } else if(succ1.transferObjectMap.statusCode == 403) {
                                this.header.logOut();
                            } else {
                                this.appC.showErrToast(succ1.transferObjectMap.message);
                            }
                        }, (err) => {
                            this.spinnerService.hide();
                        });
                    } else {
                        this.spinnerService.hide();
                        this.appC.showSuccToast("You have reached your maximum buy order limit.");    
                    }
                } else if(succ.transferObjectMap.statusCode == 403) {
                    this.spinnerService.hide();
                    this.header.logOut();
                } else {
                    this.spinnerService.hide();
                    this.appC.showErrToast(succ.transferObjectMap.message);
                }
            }, (err) => {
                this.spinnerService.hide();
            });
        }
    }

    /** Function for sell order*/ 
    sellFunc() {
        switch(this.sellOrderType) {
            case 'LIMIT':
                this.limitSellFunc();
                break;
            case 'MARKET':
                this.marketSellFunc();
                break;
            case 'STOPLIMIT':
                this.stopSellFunc();
                break;
        }
    }

    /** Function for limit sell */
    limitSellFunc() {
        if(this.limitSellObj.price == "") {
            this.appC.showErrToast("Enter price value.");
            return;
        } else if(this.limitSellObj.price == ".") {
            this.appC.showErrToast("Enter valid price value.");
            return;
        } else if(Number(this.limitSellObj.price) <= 0) {
            this.appC.showErrToast("Enter valid price value.");
            return;
        } else if(this.limitSellObj.amount == "") {
            this.appC.showErrToast("Enter amount value.");
            return;
        } else if(this.limitSellObj.amount == ".") {
            this.appC.showErrToast("Enter valid amount value.");
            return;
        } else if(Number(this.limitSellObj.amount) <= 0) {
            this.appC.showErrToast("Enter valid amount value.");
            return;
        } else if(Number(this.limitSellObj.amount) > Number(this.userData.pairCoinBal)){
            this.appC.showErrToast("You can't sell coins more than your wallet amount.");
            return;
        } else {
            let data = {
                "eventExternal": {
                    "name": "request_sell_add_order",
                    "key": "mykey"
                },
                "transferObjectMap": {
                    "tradingType": "LIMIT",
                    "orderType": "SELL", 
                    "amount": Number(this.limitSellObj.amount),
                    "price": Number(this.limitSellObj.price),
                    "total": Number(this.limitSellObj.total),
                    "baseCurrency": this.currentCoinObj.coinId,
                    "executableCurrency": this.currentPairCoinObj.coinId, 
                    "tradeStop": 0.0,
                    "tradeLimit": 0.0,
                    "loginToken": localStorage.getItem("token")
                }
            }
            this.spinnerService.show();
            this.server.postApi("",data,0).subscribe((succ) => {
                this.spinnerService.hide();
                if(succ.transferObjectMap.statusCode == 200) {
                    this.appC.showSuccToast(succ.transferObjectMap.message);
                    this.clearLimitSellObj();
                    this.getUserBaseCoinBalance();
                    this.getUserPairCoinBalance();
                    if(localStorage.getItem("token")) {
                        this.getUserOpenOrder();
                        this.getUserOrderHistory();
                    }
                    if(succ.transferObjectMap.isTradeExecuted) {
                        this.getHeaderPrice();
                        this.getCoinPairAfterExecution();
                    }
                } else if(succ.transferObjectMap.statusCode == 403) {
                    this.header.logOut();
                } else {
                    this.appC.showErrToast(succ.transferObjectMap.message);
                }
            }, (err) => {
                this.spinnerService.hide();
            });
        }
    }

    /** Function for market sell */
    marketSellFunc() {
        if(this.marketSellObj.amount == "") {
            this.appC.showErrToast("Enter amount value.");
            return;
        } else if(this.marketSellObj.amount == ".") {
            this.appC.showErrToast("Enter valid amount value.");
            return;
        } else if(Number(this.marketSellObj.amount) <= 0) {
            this.appC.showErrToast("Enter valid amount value.");
            return;
        } else if(Number(this.marketSellObj.amount) > Number(this.userData.pairCoinBal)) {
            this.appC.showErrToast("You can't sell coins more than your wallet amount.");
            return;
        } else { 
            if(this.SocketDataStatus) {
                let data = {
                    "eventExternal": {
                        "name": "request_sell_add_order",
                        "key": "mykey"
                    },
                   "transferObjectMap": {
                        "tradingType": "Market",                    
                        "orderType": "SELL", 
                        "amount": this.marketSellObj.amount,
                        "price": this.headerPriceObj.currPrice,
                        "baseCurrency": this.currentCoinObj.coinId,
                        "executableCurrency": this.currentPairCoinObj.coinId, 
                        "tradeStop": 0.0,
                        "tradeLimit": 0.0,
                        "loginToken": localStorage.getItem("token")
                    }
                }
                this.server.postApi("",data,0).subscribe((succ1) => {
                    this.spinnerService.hide();
                    if(succ1.transferObjectMap.statusCode == 200) {
                        this.appC.showSuccToast(succ1.transferObjectMap.message);
                        this.clearMarketSellObj();
                        this.getUserBaseCoinBalance();
                        this.getUserPairCoinBalance();
                        if(succ1.transferObjectMap.isTradeExecuted) {
                            //this.getHeaderPrice();
                            this.getCoinPairAfterExecution();
                        }
                    } else if(succ1.transferObjectMap.statusCode == 403) {
                        this.header.logOut();
                    } else {
                        this.appC.showErrToast(succ1.transferObjectMap.message);
                    }
                }, (err1) => {
                    this.spinnerService.hide();                            
                });
            } else {
                let data = {
                    "eventExternal": {
                        "name":"request_estimate_sell_order",
                        "key":"mykey"
                    },
                    "transferObjectMap": {
                        "amount": this.marketSellObj.amount,
                        "baseCurrency": this.currentCoinObj.coinId,
                        "executableCurrency": this.currentPairCoinObj.coinId,
                        "orderType": "SELL",
                        "loginToken": localStorage.getItem("token")            
                    }
                }        
                this.spinnerService.show();
                this.server.postApi("",data,0).subscribe((succ) => {
                    if(succ.transferObjectMap.statusCode == 200) {
                        if(succ.transferObjectMap.orderContains) {
                            let price = (succ.transferObjectMap.estimatePrice / succ.transferObjectMap.estimateAmount);
                            let amount = succ.transferObjectMap.estimateAmount;
                            let total = (amount * price);
                            if(amount <= Number(this.userData.pairCoinBal)) {
                                let data = {
                                    "eventExternal": {
                                        "name": "request_sell_add_order",
                                        "key": "mykey"
                                    },
                                   "transferObjectMap": {
                                        "tradingType": "Market",                    
                                        "orderType": "SELL", 
                                        "amount": amount,
                                        "price": price,
                                        "total": total,
                                        "baseCurrency": this.currentCoinObj.coinId,
                                        "executableCurrency": this.currentPairCoinObj.coinId, 
                                        "tradeStop": 0.0,
                                        "tradeLimit": 0.0,
                                        "loginToken": localStorage.getItem("token")
                                    }
                                }
                                this.server.postApi("",data,0).subscribe((succ1) => {
                                    this.spinnerService.hide();
                                    if(succ1.transferObjectMap.statusCode == 200) {
                                        this.appC.showSuccToast(succ1.transferObjectMap.message);
                                        this.clearMarketSellObj();
                                        this.getUserBaseCoinBalance();
                                        this.getUserPairCoinBalance();
                                        if(localStorage.getItem("token")) {
                                            this.getUserOpenOrder();
                                            this.getUserOrderHistory();
                                        }
                                        if(succ1.transferObjectMap.isTradeExecuted) {
                                            this.getHeaderPrice();
                                            this.getCoinPairAfterExecution();
                                        }
                                    } else if(succ1.transferObjectMap.statusCode == 403) {
                                        this.header.logOut();
                                    } else {
                                        this.appC.showErrToast(succ1.transferObjectMap.message);
                                    }
                                }, (err1) => {
                                    this.spinnerService.hide();                            
                                });
                            } else {
                                this.spinnerService.hide();
                                this.appC.showErrToast("You can't execute the market order because you don't have enough amount to your wallet balance.");
                            }
                        } else {
                            this.spinnerService.hide();
                            this.appC.showErrToast("Don't have enough order in market.");
                        }
                    } else if(succ.transferObjectMap.statusCode == 403) {
                        this.spinnerService.hide();
                        this.header.logOut();
                    } else {
                        this.spinnerService.hide();
                        this.appC.showErrToast(succ.transferObjectMap.message);
                    }
                }, (err) => {
                    this.spinnerService.hide();
                });
            }
        }
    }

    /** Function for stop limit sell */
    stopSellFunc() {
        if(this.sLimitSellObj.stop == "") {
            this.appC.showErrToast("Enter stop value.");
            return;
        } else if(this.sLimitSellObj.stop == ".") {
            this.appC.showErrToast("Enter valid stop value.");
            return;
        } else if(Number(this.sLimitSellObj.stop) <= 0) {
            this.appC.showErrToast("Enter valid stop value.");
            return;
        } else if(this.sLimitSellObj.price == "") {
            this.appC.showErrToast("Enter limit value.");
            return;
        } else if(this.sLimitSellObj.price == ".") {
            this.appC.showErrToast("Enter valid limit value.");
            return;
        } else if(Number(this.sLimitSellObj.price) <= 0) {
            this.appC.showErrToast("Enter valid limit value.");
            return;
        } else if(this.sLimitSellObj.amount == "") {
            this.appC.showErrToast("Enter amount value.");
            return;
        } else if(this.sLimitSellObj.amount == ".") {
            this.appC.showErrToast("Enter valid amount value.");
            return;
        } else if(Number(this.sLimitSellObj.amount) <= 0) {
            this.appC.showErrToast("Enter valid amount value.");
            return;
        } else if(Number(this.sLimitSellObj.amount) > Number(this.userData.pairCoinBal)){
            this.appC.showErrToast("You can't sell coins more than your wallet amount.");
            return;
        } else {
            let data = {
                "eventExternal": {
                    "name": "request_get_stop_limit_count_status",
                    "key": "mykey"
                },
                "transferObjectMap": {
                    "gatewayrequest": {
                        "baseCurrency": this.currentCoinObj.coinId,
                        "executableCurrency": this.currentPairCoinObj.coinId,
                        "loginToken": localStorage.getItem("token")                        
                    }
                }                  
            }
            this.spinnerService.show();
            this.server.postApi("",data,0).subscribe((succ) => {
                if(succ.transferObjectMap.statusCode == 200) {
                    if(succ.transferObjectMap.stopLimitCount <= 1) {
                        let reqData = {
                            "eventExternal": {
                                "name":"request_sell_add_order",
                                "key":"mykey"
                            },
                            "transferObjectMap": {
                                "tradingType":"STOPLIMIT",
                                "orderType": "SELL", 
                                "amount": this.sLimitSellObj.amount,
                                "price": this.sLimitSellObj.price,
                                "total": this.sLimitSellObj.total,
                                "baseCurrency": this.currentCoinObj.coinId,
                                "executableCurrency": this.currentPairCoinObj.coinId, 
                                "tradeStop": this.sLimitSellObj.stop,
                                "tradeLimit": this.sLimitSellObj.price,
                                "loginToken": localStorage.getItem("token")
                            }
                        }
                        this.server.postApi("",reqData,0).subscribe((succ1) => {
                            this.spinnerService.hide();
                            if(succ1.transferObjectMap.statusCode == 200) {
                                this.appC.showSuccToast(succ1.transferObjectMap.message);
                                this.clearStopLimitSellObj();
                                this.getUserBaseCoinBalance();
                                this.getUserPairCoinBalance();
                                if(localStorage.getItem("token")) {
                                    this.getUserOpenOrder();
                                    this.getUserOrderHistory();
                                }
                                if(succ1.transferObjectMap.isTradeExecuted) {
                                    //this.getLastPriceForOrder();
                                    this.getHeaderPrice();
                                    this.getCoinPairAfterExecution();
                                }
                            } else if(succ1.transferObjectMap.statusCode == 403) {
                                this.header.logOut();
                            } else {
                                this.appC.showErrToast(succ1.transferObjectMap.message);
                            }
                        }, (err) => {
                            this.spinnerService.hide();
                        });
                    } else {
                        this.spinnerService.hide();
                        this.appC.showSuccToast("You have reached your maximum sell order limit.");    
                    }
                } else if(succ.transferObjectMap.statusCode == 403) {
                    this.spinnerService.hide();
                    this.header.logOut();
                } else {
                    this.spinnerService.hide();
                    this.appC.showErrToast(succ.transferObjectMap.message);
                }
            }, (err) => {
                this.spinnerService.hide();
            });
        }
    }

    /** Function to clear limit buy obj */
    clearLimitBuyObj() {
        this.limitBuyObj.amount = "";
        this.limitBuyObj.price = "";
        this.limitBuyObj.total = "";
    }

    /** Function to clear market buy obj */
    clearMarketBuyObj() {
        this.marketBuyObj.amount = "";
    }

    /** Function to clear stop limit buy obj */
    clearStopLimitBuyObj() {
        this.sLimitBuyObj.amount = "";
        this.sLimitBuyObj.price = "";
        this.sLimitBuyObj.stop = "";
        this.sLimitBuyObj.total = "";
    }

    /** Function to clear limit sell obj */
    clearLimitSellObj() {
        this.limitSellObj.amount = "";
        this.limitSellObj.price = "";
        this.limitSellObj.total = "";
    }

    /** Function to clear market sell obj */
    clearMarketSellObj() {
        this.marketSellObj.amount = "";
    }

    /** Function to clear stop limit sell obj */
    clearStopLimitSellObj() {
        this.sLimitSellObj.amount = "";
        this.sLimitSellObj.price = "";
        this.sLimitSellObj.stop = "";
        this.sLimitSellObj.total = "";
    }

    /**Function to cancel order */
    cancelOrder(order) {
        order.click = true;
        let data = {
            "eventExternal": {
                    "name":"request_cancel_order",
                    "key":"mykey"
                },
            "transferObjectMap": {
                "gatewayrequest": {
                    "loginToken": localStorage.getItem("token"),
                    "orderList":[order.orderId]
                }
            }
        }
        this.spinnerService.show();
        this.server.postApi('',data,0).subscribe((succ) => {
            this.spinnerService.hide();
            if(succ.transferObjectMap.statusCode == 200) {
                this.appC.showInfoToast(succ.transferObjectMap.message);
                if(localStorage.getItem("token")) {
                    this.getUserOpenOrder();
                    this.getUserOrderHistory();
                }
                this.getUserBaseCoinBalance();
                this.getUserPairCoinBalance();                
            }  else if(succ.transferObjectMap.statusCode == 403)  { 
                this.header.logOut();
            } else {
                this.appC.showErrToast(succ.transferObjectMap.message);
                order.click = false;
            }
        }, (err) => {
            this.spinnerService.hide();
        });
    }

    /**to draw depth chart */
    drawDepthChart() {
        let currVal = this.tradeViewPair.split("/")[0];
        let exeVal = this.tradeViewPair.split("/")[1];
        AmCharts.makeChart("depthChartID", {
            "type": "serial",
            "theme": "light",
            "dataLoader": {
                "url": "http://172.16.21.20:8083/bitnomyChart/exchange-feed/depth-chart?currency="+currVal+"&exchangeCurrency="+exeVal,
                "format": "json",
                "reload": 30,
                "postProcess": function(data) {
                    var response = JSON.stringify(data);
                    var parsedData = JSON.parse(response);
                    var asks = parsedData.asks;
                    var bids = parsedData.bids;
                    // Function to process (sort and calculate cummulative volume)
                    function processData(list, type, desc) {
                        // Convert to data points
                        for(var i = 0; i < list.length; i++) {
                            list[i] = {
                                value: Number(list[i][0]),
                                volume: Number(list[i][1]),
                            }
                        }                 
                        // Sort list just in case
                        list.sort(function(a, b) {
                            if (a.value > b.value) {
                                return 1;
                            }
                            else if (a.value < b.value) {
                                return -1;
                            }
                            else {
                                return 0;
                            }
                        });                  
                        // Calculate cummulative volume
                        if (desc) {
                            for(var i = list.length - 1; i >= 0; i--) {
                                if (i < (list.length - 1)) {
                                    list[i].totalvolume = list[i+1].totalvolume + list[i].volume;
                                }
                                else {
                                    list[i].totalvolume = list[i].volume;
                                }
                                var dp = {};
                                dp["value"] = list[i].value;
                                dp[type + "volume"] = list[i].volume;
                                dp[type + "totalvolume"] = list[i].totalvolume;
                                res.unshift(dp);
                            }
                        } else {
                            for(var i = 0; i < list.length; i++) {
                                if (i > 0) {
                                    list[i].totalvolume = list[i-1].totalvolume + list[i].volume;
                                }
                                else {
                                    list[i].totalvolume = list[i].volume;
                                }
                                var dp = {};
                                dp["value"] = list[i].value;
                                dp[type + "volume"] = list[i].volume;
                                dp[type + "totalvolume"] = list[i].totalvolume;
                                res.push(dp);
                            }
                        }                 
                    }
                    
                    var res = [];
                    processData(bids, "bids", true);
                    processData(asks, "asks", false);
                    return res;
                }
            },
            "graphs": [{
                "id": "bids",
                "fillAlphas": 0.1,
                "lineAlpha": 1,
                "lineThickness": 2,
                "lineColor": "#0f0",
                "type": "step",
                "valueField": "bidstotalvolume",
                "balloonFunction": balloon
            }, {
                "id": "asks",
                "fillAlphas": 0.1,
                "lineAlpha": 1,
                "lineThickness": 2,
                "lineColor": "#f00",
                "type": "step",
                "valueField": "askstotalvolume",
                "balloonFunction": balloon
            }, {
                "lineAlpha": 0,
                "fillAlphas": 0.2,
                "lineColor": "#000",
                "type": "column",
                "clustered": false,
                "valueField": "bidsvolume",
                "showBalloon": false
            }, {
                "lineAlpha": 0,
                "fillAlphas": 0.2,
                "lineColor": "#000",
                "type": "column",
                "clustered": false,
                "valueField": "asksvolume",
                "showBalloon": false
            }],
            "categoryField": "value",
            "chartCursor": {},
            "balloon": {
                "textAlign": "left"
            },
            "categoryAxis": {
                "minHorizontalGap": 100,
                "startOnAxis": true,
                "showFirstLabel": false,
                "showLastLabel": false
            },
            "export": {
                "enabled": false
            }
        });
          
        function balloon(item, graph) {
            var txt;
            if (graph.id == "asks") {
                txt = "Ask: <strong>" + formatNumber(item.dataContext.value, graph.chart, 8) + "</strong><br />"
                + "Total volume: <strong>" + formatNumber(item.dataContext.askstotalvolume, graph.chart, 8) + "</strong><br />"
                + "Volume: <strong>" + formatNumber(item.dataContext.asksvolume, graph.chart, 8) + "</strong>";
            }
            else {
                txt = "Bid: <strong>" + formatNumber(item.dataContext.value, graph.chart, 8) + "</strong><br />"
                + "Total volume: <strong>" + formatNumber(item.dataContext.bidstotalvolume, graph.chart, 8) + "</strong><br />"
                + "Volume: <strong>" + formatNumber(item.dataContext.bidsvolume, graph.chart, 8) + "</strong>";
            }
            return txt;
        }
        
        function formatNumber(val, chart, precision) {
            return AmCharts.formatNumber(val, {
                precision: precision ? precision : chart.precision, 
                decimalSeparator: chart.decimalSeparator,
                thousandsSeparator: chart.thousandsSeparator
            });
        }
    }

    /** Function to get selected chart tab */
    selectChartTab(chart) {
        switch(chart) {
            case 'OHLC':
                //this.drawTradingChart();
                break;
            case 'DepthChart':
                //this.drawDepthChart();
                break;
        }
    }
    
    /** Function to manage exponential data */
    manageExponential(num) {
        //if the number is in scientific notation remove it
        if (/\d+\.?\d*e[\+\-]*\d+/i.test(num)) {
            var zero = '0',
            parts = String(num).toLowerCase().split('e'), //split into coeff and exponent
            es = Number(parts.pop()), //store the exponential part
            l = Math.abs(es), //get the number of zeros
            sign = es / l,
            coeff_array = parts[0].split('.');
            if (sign === -1) {
                num = zero + '.' + new Array(l).join(zero) + coeff_array.join('');
            } else {
                var dec = coeff_array[1];
                if (dec) l = l - dec.length;
                num = coeff_array.join('') + new Array(l + 1).join(zero);
            }
            return num;
        } else {
            return num;
        }
    };

    selectBID(data) {
        this.limitBuyObj.price = data.price;
        this.limitBuyObj.amount = data.amount;
        this.valueChangeFunc('LBP');
        this.marketBuyObj.amount = data.amount;
        this.limitSellObj.price = data.price;
        this.limitSellObj.amount = data.amount;
        this.valueChangeFunc('LSP');
        this.marketSellObj.amount = data.amount;
    }


    /** Function to get live data for other pair */
    getLiveDataFromHitBTCForCoinPair(symArr) {
        if(symArr.length) {
            let data = {
                "eventExternal": {
                    "name": "request_get_live_data_for_symbols",
                    "key": ""
                },
                "transferObjectMap": {
                    "gatewayrequest": {
                        "url": "https://api.hitbtc.com/api/2/public/ticker",
                        "symbols": symArr
                    }
                }
            }
            this.server.postApi('',data,0).subscribe((succ) => {
                if(succ.transferObjectMap.statusCode == 200) {
                    this.coinPairListArr.forEach((obj) => {
                        var ind = succ.transferObjectMap.data.findIndex((data) => data.symbol.substring(0,3) == obj.coin);
                        if(ind != -1) {
                            obj.last_price = succ.transferObjectMap.data[ind].last;
                            obj.volume = succ.transferObjectMap.data[ind].volume;
                            obj.average = (Number(succ.transferObjectMap.data[ind].low) + Number(succ.transferObjectMap.data[ind].high))/2;
                        }
                    });
                    clearInterval(this.hitbtcIntervalID);
                    this.startInterval(symArr);
                }
            }, (err) => {
            });        
        }        
    }

    /** Function to start interval for getting latest value for pair */
    startInterval(symbolArr) {
        this.hitbtcIntervalID = setInterval((obj) => {
            let data = {
                "eventExternal": {
                    "name": "request_get_live_data_for_symbols",
                    "key": ""
                },
                "transferObjectMap": {
                    "gatewayrequest": {
                        "url": "https://api.hitbtc.com/api/2/public/ticker",
                        "symbols": symbolArr
                    }
                }
            }
            this.server.postApi('',data,0).subscribe((succ) => {
                if(succ.transferObjectMap.statusCode == 200) {
                    this.coinPairListArr.forEach((obj) => {
                        var ind = succ.transferObjectMap.data.findIndex((data) => data.symbol.substring(0,3) == obj.coin);
                        if(ind != -1) {
                            obj.last_price = succ.transferObjectMap.data[ind].last;
                            obj.volume = succ.transferObjectMap.data[ind].volume;
                            obj.average = (Number(succ.transferObjectMap.data[ind].low) + Number(succ.transferObjectMap.data[ind].high))/2;
                        }
                    });
                }
            }, (err) => {
            });
        }, 10000);
    }

    /** Function to stop interval for getting latest value for pair */
    stopInterval() {
        clearInterval(this.hitbtcIntervalID);
    }  

    getfeeList() {
        this.feeList = [];
        let data = {
            "eventExternal": {
                "name": "get_fee_lists",
                "key": "mykey"
            },
            "transferObjectMap": {
                "gatewayrequest": {
                    
                }
            }
        }
        this.spinnerService.show();
        this.server.postApi("",data,0).subscribe((succ) => {
            if(succ.transferObjectMap.statusCode == 200) {
                this.spinnerService.hide();
                this.feeList = succ.transferObjectMap.result;
                this.feeListApi = true;
            } else if(succ.transferObjectMap.statusCode == 403){
                this.spinnerService.hide();
                this.header.goToPage(7);
            } else {
                this.spinnerService.hide();
                // this.appC.showErrToast(succ.transferObjectMap.message);
            }
        }, error => {
            this.spinnerService.hide();
            // this.appC.showErrToast('Something went wrong');
        });   
        
    }

    

    
}
