import { BrowserModule } from '@angular/platform-browser';
import { RouterModule, Routes } from '@angular/router';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MainComponent } from './main/main.component';
import { SignupComponent } from './signup/signup.component';
import { ForgetComponent } from './forget/forget.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { LoginComponent } from './login/login.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule } from '@angular/common/http';
import { InMemoryDataService }  from './in-memory-data.service';
import { TestComponent } from './test/test.component';
import { StoreService } from './store.service';
import { AgmCoreModule } from '@agm/core';
import { CompanyModule } from './company/company.module';


@NgModule({
  declarations: [
    AppComponent,
    MainComponent,
    SignupComponent,
    ForgetComponent,
    PagenotfoundComponent,
    LoginComponent,
    TestComponent
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    HttpClientModule,
    AppRoutingModule,
    CompanyModule,
    AgmCoreModule.forRoot({
      apiKey:'AIzaSyAKAFToJ29Kdi4YLqjpO5KJi8EOt_6T1PQ'
    })
    
  ],
  providers: [StoreService],
  bootstrap: [AppComponent]
})
export class AppModule { }
