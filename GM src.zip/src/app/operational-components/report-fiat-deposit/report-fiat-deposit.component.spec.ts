import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportFiatDepositComponent } from './report-fiat-deposit.component';

describe('ReportFiatDepositComponent', () => {
  let component: ReportFiatDepositComponent;
  let fixture: ComponentFixture<ReportFiatDepositComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReportFiatDepositComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReportFiatDepositComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
