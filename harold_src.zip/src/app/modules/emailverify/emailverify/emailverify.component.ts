import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ServerService } from '../../../server.service';
import { AppComponent } from '../../../app.component';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';

@Component({
  selector: 'app-emailverify',
  templateUrl: './emailverify.component.html',
  styleUrls: ['./emailverify.component.css']
})
export class EmailverifyComponent implements OnInit {
  page: boolean;

  constructor(public router: Router, private server: ServerService, private appC: AppComponent, private spinnerService: Ng4LoadingSpinnerService) { }

  ngOnInit() {
    window.scrollTo(0,0);
    let url = window.location.href.split('/')
    let page = url[url.length-1];
    if(page == 'login')
      this.page = true;
  }

  resendEmail() {
    this.spinnerService.show();
    this.server.getApi('account/resend-verify-email?email='+localStorage.getItem('email')+'&webUrl='+this.server.websiteURL+"/login").subscribe((res) => {
        this.spinnerService.hide();
        if (res.status == 200) {
            this.appC.showSuccToast("E-mail has been sent successfully.");
        }
        else
            this.appC.showErrToast(res.message);
    }, (err) => {
        this.spinnerService.hide();
        if(err.error.status == 400)
          this.appC.showErrToast(err.error.message)
        else
          this.appC.showErrToast('Something went wrong')
    })
  }

}
