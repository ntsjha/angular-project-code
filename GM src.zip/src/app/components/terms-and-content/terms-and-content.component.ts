import { Component, OnInit } from '@angular/core';
import { ServiceService } from 'src/app/service/service.service';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-terms-and-content',
  templateUrl: './terms-and-content.component.html',
  styleUrls: ['./terms-and-content.component.css']
})
export class TermsAndContentComponent implements OnInit {
  termandCondition: string;
  termNConditionId: any;
  modeOfAction: string;
  selectedLanguage: string;
  canView: boolean;
  canAdd: boolean;
  canEdit: boolean;
  termsObj: any;
  currentUser: any;
  langId: any;
  translationId: any;
  termsAndCondtionForm: FormGroup;
  showErrorForNull: boolean;
  showApiMessage = false;
  response: any;

  constructor(private service: ServiceService, private activatedRoutes: ActivatedRoute, private router: Router, private fb: FormBuilder, private spinner: NgxSpinnerService) { }

  ngOnInit() {
    this.activatedRoutes.params.subscribe((data) => {
      this.modeOfAction = data.id1;
      this.languageSelection(data.id2);
    });
    this.modeSelection();
    this.getTermsAndCondition();
    this.service.currentUserInfo.subscribe((response) => {
      this.currentUser = response;
    });
    this.termsAndCondtionForm = this.fb.group({
      updatedTermsAndCondition: ['', [Validators.required]],
    });
    window.scrollTo(0, 0);
  }

  checkforSpaces() {
    const termsData = (this.termsAndCondtionForm.value.updatedTermsAndCondition);
    if (termsData === '') {
      this.showErrorForNull = true;
    } else {
      this.showErrorForNull = false;
    }
  }

  languageSelection(lang) {
    if (lang === 'th') {
      this.selectedLanguage = 'th';
    } else if (lang === 'ch') {
      this.selectedLanguage = 'ch';
    } else {
      this.selectedLanguage = 'en';
    }
  }

  modeSelection() {
    if (this.modeOfAction === 'edit' || this.modeOfAction === 'add') {
      this.canEdit = true;
      this.canAdd = false;
      this.canView = false;
    } else {
      this.canEdit = false;
      this.canAdd = false;
      this.canView = true;
    }
  }
  cancelEdit() {
    this.router.navigate(['/manage-site-content']);
  }

  getTermsAndCondition() {
    this.service.postMethod('static/admin/view-terms-and-condition', {}, 1)
      .subscribe((response) => {
        if (response.status === 676) {
          this.termandCondition = response.data[0].description;
          this.termsObj = response.data[0];
          this.termNConditionId = response.data[0].termsNConditionId;
          if (this.selectedLanguage !== 'en') {
            this.getTranslation();
          } else {
            setTimeout(() => {
              this.termsAndCondtionForm.patchValue({
                updatedTermsAndCondition: response.data[0].description,
              });
            }, 500);
          }
        }
      }, (error) => {
      });
  }

  getTranslation() {
    this.service.postMethod('static/admin/get-terms-and-condition-translation?termsNConditionId=' + encodeURIComponent(this.service.encrypt(this.termNConditionId)), {}, 1)
      .subscribe((response) => {
        this.getThaiAndChaiTranslation(response);
      }, (error) => {
      });
  }

  getThaiAndChaiTranslation(response) {
    const langList = response.data.languageList.data;
    langList.forEach(element => {
      if (element.languageShortName === this.selectedLanguage) {
        this.langId = element.languageId;
      }
    });
    const translationData = response.data.translationList;
    translationData.forEach(element => {
      if (element.fkLanguageId === this.langId) {
        this.translationId = element.termsNConditionId;
        this.termsAndCondtionForm.patchValue({
          updatedTermsAndCondition: element.description,
        });
        this.termsObj = element;
      }
    });
  }

  submit() {
    if (this.termsAndCondtionForm.invalid) {
      return;
    }
    if (this.selectedLanguage === 'en') {
      const obj = {
        description: this.service.encrypt(this.termsAndCondtionForm.value.updatedTermsAndCondition),
        ipAddress: this.service.encrypt(this.currentUser.ip),
        location: this.service.encrypt(this.currentUser.city + ', ' + this.currentUser.country_name),
        termsNConditionId: this.service.encrypt(this.termsObj.termsNConditionId),
        title: this.service.encrypt(this.termsObj.title),
      };
      this.spinner.show();
      this.service.postMethod('static/admin/edit-terms-and-condition-data', obj, 1)
        .subscribe((response) => {
          this.spinner.hide();
          if (response.status === 1074) {
            this.showApiMessage = true;
            this.response = response;
            this.response.message = 'Terms and Condition updated successfully';
            window.scrollTo(0,0);
            this.router.navigate(['/translation/terms-and-content']);
          }
        }, (error) => {
          this.spinner.hide();
          if (error.error) {
            this.showApiMessage = true;
            this.response = error.error;
          } else {
            this.showApiMessage = true;
            this.response = 'Something went wrong!';
          }
        });
    } else {

      const obj = {
        description: this.service.encrypt(this.termsAndCondtionForm.value.updatedTermsAndCondition),
        ipAddress: this.service.encrypt(this.currentUser.ip),
        location: this.service.encrypt(this.currentUser.city + ', ' + this.currentUser.country_name),
        translationId: this.service.encrypt(this.translationId),
        title: this.service.encrypt(this.termsObj.title),
      };
      this.spinner.show();
      this.service.postMethod('static/admin/edit-terms-and-condition-translation', obj, 1)
        .subscribe((succ) => {
          this.spinner.hide();
          if (succ.status === 1080) {
            this.showApiMessage = true;
            this.response = succ;
            this.response.message = 'Terms and Condition translation updated successfully';
            window.scrollTo(0,0);
            this.router.navigate(['/translation/terms-and-content']);
          }
        }, (err) => {
          this.spinner.hide();
          if (err.error) {
            this.showApiMessage = true;
            this.response = err.error;
          } else {
            this.showApiMessage = true;
            this.response = 'Something went wrong!';
          }
        });
    }
  }

}
