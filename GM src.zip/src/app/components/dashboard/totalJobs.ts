declare var CanvasJS: any;
// declare var angular: any;

export class totalJobsService {
    chart: any;
    chartData: any = [
        {
            month: 'January',
            JobList: [
                0
            ]
        },
        {
            month: 'Feburary',
            JobList: [
                0
            ]
        },
        {
            month: 'March',
            JobList: [
                0
            ]
        },
        {
            month: 'April',
            JobList: [
                0
            ]
        },
        {
            month: 'May',
            JobList: [
                1
            ]
        },
        {
            month: 'June',
            JobList: [
                2
            ]
        },
        {
            month: 'July',
            JobList: [
                3
            ]
        },
        {
            month: 'August',
            JobList: [
                14
            ]
        },
        {
            month: 'September',
            JobList: [
                1
            ]
        },
        {
            month: 'October',
            JobList: [
                0
            ]
        },
        {
            month: 'November',
            JobList: [
                0
            ]
        },
        {
            month: 'December',
            JobList: [
                0
            ]
        }
    ];
    chartData2 = [
        {
            month: 'January',
            JobList: [
                0
            ]
        },
        {
            month: 'Feburary',
            JobList: [
                0
            ]
        },
        {
            month: 'March',
            JobList: [
                0
            ]
        },
        {
            month: 'April',
            JobList: [
                0
            ]
        },
        {
            month: 'May',
            JobList: [
                1
            ]
        },
        {
            month: 'June',
            JobList: [
                2
            ]
        },
        {
            month: 'July',
            JobList: [
                3
            ]
        },
        {
            month: 'August',
            JobList: [
                14
            ]
        },
        {
            month: 'September',
            JobList: [
                1
            ]
        },
        {
            month: 'October',
            JobList: [
                0
            ]
        },
        {
            month: 'November',
            JobList: [
                0
            ]
        },
        {
            month: 'December',
            JobList: [
                0
            ]
        }
    ];
    chartData3 = [
        {
            date: (new Date(2019, 7, 12, 12, 12, 12)),
            rewardType: 'ReferFriendPoint ',
            sum: 0
        },
        {
            date: (new Date(2019, 8, 12, 12, 12, 12)),
            rewardType: 'CompleteKycPoint ',
            sum: 0
        },
        {
            date: (new Date(2019, 9, 12, 12, 12, 12)),
            rewardType: 'TradingPercentage',
            sum: 0
        },
        {
            date: (new Date()),
            rewardType: 'Refund',
            sum: 0
        }
    ];
    chartData4 = [];
    jobChart: any = [];
    title = '';

    totalJobsData(data, chartId, point) {
        // if ( !angular.element('#' + chartId).length ) {
        //     return;
        // }
        this.chartData = data;
        this.jobChart = [];
        if (this.chartData.length) {
            this.title = '';
            const len = (this.chartData.length - 1);
            let i = 0;
            if (point === 1) {
                this.chartData.forEach((element) => {
                    if (i < len) {
                        const obj = {
                            label: (element.month),
                            y: element.JobList[0],
                        };
                        this.jobChart.push(obj);
                        i++;
                    }
                });
            } else if (point === 2) {
                this.chartData.forEach((element: any) => {
                    const obj = {
                        label: this.getMonthName(element.month),
                        y: this.getSumOfArray(element.data),
                    };
                    this.jobChart.push(obj);
                });
            } else {
                this.chartData3.forEach((element) => {
                    const obj = {
                        label: element.rewardType,
                        x: (new Date(element.date)),
                        y: 0,
                    };
                    this.jobChart.push(obj);
                });
            }
        } else {
            this.title = 'No data found';
            this.jobChart = [
                {
                    label: 'Jan',
                    y: 0,
                },
                {
                    label: 'Feb',
                    y: 0,
                },
                {
                    label: 'Mar',
                    y: 0,
                },
                {
                    label: 'Apr',
                    y: 0,
                },
                {
                    label: 'May',
                    y: 0,
                },
                {
                    label: 'June',
                    y: 0,
                },
                {
                    label: 'July',
                    y: 0,
                },
                {
                    label: 'Aug',
                    y: 0,
                },
                {
                    label: 'Sept',
                    y: 0,
                },
                {
                    label: 'Oct',
                    y: 0,
                },
                {
                    label: 'Nov',
                    y: 0,
                },
                {
                    label: 'Dec',
                    y: 0,
                },
            ];
        }
        this.chart = new CanvasJS.Chart(chartId, {
            title: {
                text: this.title,
            },
            axisX: {
                interval: 1,
            },
            data: [{
                type: 'column',
                indexLabelFontColor: '#5A5757',
                indexLabelPlacement: 'outside',
                dataPoints: this.jobChart,
            }]
        });
        return this.chart.render();
    }

    getMonthName(month) {
        let monthName = '';
        switch (month) {
            case 1: monthName = 'Jan';
                    break;
            case 2: monthName = 'Feb';
                    break;
            case 3: monthName = 'Mar';
                    break;
            case 4: monthName = 'Apr';
                    break;
            case 5: monthName = 'May';
                    break;
            case 6: monthName = 'Jun';
                    break;
            case 7: monthName = 'Jul';
                    break;
            case 8: monthName = 'Aug';
                    break;
            case 9: monthName = 'Sept';
                    break;
            case 10: monthName = 'Oct';
                     break;
            case 11: monthName = 'Nov';
                     break;
            case 12: monthName = 'Dec';
                     break;
        }
        return monthName;
    }

    getSumOfArray(data) {
        let sum = 0;
        data.forEach(element => {
            sum = sum + element.finalPoint;
        });
        return sum;
    }
}
