export class HorseList{
    id: string;
    name:string;
    DOB: string;
    height: string;
    weight: string;
    age: string;
    teeth: string;
    speed: string
}