import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MimimumWithdrawlCryptoSidebarComponent } from './mimimum-withdrawl-crypto-sidebar.component';

describe('MimimumWithdrawlCryptoSidebarComponent', () => {
  let component: MimimumWithdrawlCryptoSidebarComponent;
  let fixture: ComponentFixture<MimimumWithdrawlCryptoSidebarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MimimumWithdrawlCryptoSidebarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MimimumWithdrawlCryptoSidebarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
