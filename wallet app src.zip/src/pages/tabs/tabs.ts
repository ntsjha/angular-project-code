import { Component, ViewChild } from '@angular/core';
import { HomePage } from '../home/home';
import { AddmoneyPage } from '../addmoney/addmoney';
import { WithdrawPage } from '../withdraw/withdraw';
import { SendPage } from '../send/send';
import { SettingNewPage } from '../setting-new/setting-new';
import { Events, NavController, Tabs, NavParams } from 'ionic-angular';
import { LoginPage } from '../login/login';
import { ReceivePage } from "../receive/receive";

@Component({
  templateUrl: 'tabs.html'
})
export class TabsPage {
  @ViewChild('myTabs') tabRef: Tabs;

  private selectedTab: number;
  tab1Root = AddmoneyPage;
  tab2Root = SendPage;
  tab3Root = HomePage;
  tab4Root = ReceivePage
  tab5Root = WithdrawPage;
  tab6Root = SettingNewPage;

  constructor(public events:Events,public navCtrl:NavController,private navParams: NavParams) {
    events.subscribe('user:logout',() =>{
      this.navCtrl.setRoot(LoginPage);
    })
    this.selectedTab = this.navParams.get('selectedTab') || 0;
  }

  ionViewWillEnter() {
    if(this.selectedTab) {
      this.tabRef.select(this.selectedTab);
    }
  }

}
