import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NewipdetectComponent } from './newipdetect/newipdetect.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [NewipdetectComponent]
})
export class NewipdetectModule { }
