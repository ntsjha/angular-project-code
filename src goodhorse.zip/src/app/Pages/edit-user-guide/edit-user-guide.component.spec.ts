import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditUserGuideComponent } from './edit-user-guide.component';

describe('EditUserGuideComponent', () => {
  let component: EditUserGuideComponent;
  let fixture: ComponentFixture<EditUserGuideComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditUserGuideComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditUserGuideComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
