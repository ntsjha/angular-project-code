import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DeposithistoryComponent } from './deposithistory/deposithistory.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [DeposithistoryComponent]
})
export class DeposithistoryModule { }
