import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PosttrdeComponent } from './posttrde.component';

describe('PosttrdeComponent', () => {
  let component: PosttrdeComponent;
  let fixture: ComponentFixture<PosttrdeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PosttrdeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PosttrdeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
