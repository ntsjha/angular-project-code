import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CrmInvoicesPage } from './crm-invoices';

@NgModule({
  declarations: [
    CrmInvoicesPage,
  ],
  imports: [
    IonicPageModule.forChild(CrmInvoicesPage),
  ],
})
export class CrmInvoicesPageModule {}
