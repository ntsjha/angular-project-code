import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, NgForm } from '@angular/forms';
import { ServerService } from '../../../server.service';
import { AppComponent } from '../../../app.component';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { Router } from '@angular/router';

@Component({
    selector: 'app-changepassword',
    templateUrl: './changepassword.component.html',
    styleUrls: ['./changepassword.component.css']
})
export class ChangepasswordComponent implements OnInit {
    changeForm: FormGroup
    numRegxForPattern: any = (/^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})/i);
    check: boolean;
    constructor(private server: ServerService, public appC: AppComponent, private spinnerService: Ng4LoadingSpinnerService, private router: Router) { }
    
    ngOnInit() {
        window.scrollTo(0,0);
        this.checkInputs();
    }

    checkInputs() {
        this.changeForm = new FormGroup({
            password: new FormControl('', [Validators.required]),
            newPassword: new FormControl('', [Validators.required, Validators.pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})/i)]),
            confirmPassword: new FormControl('', [Validators.required, Validators.pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})/i)]),
        }, passwordMatchValidator);
        /** Function for password match and mismatch */
        function passwordMatchValidator(g: FormGroup) {
            let pass = g.get('newPassword').value;
            let confPass = g.get('confirmPassword').value;
            if (pass != confPass) {
                g.get('confirmPassword').setErrors({ mismatch: true });
            } else {
                g.get('confirmPassword').setErrors(null)
                return null
            }
        }
    }
    /** Function for old password  and new password match and mismatch */
    passwordValidator() {
        this.check = true
        if (this.changeForm.value.newPassword != '') {
            if (this.changeForm.value.newPassword == this.changeForm.value.password)
                this.changeForm.get('newPassword').setErrors({ mismatch: true });
            else if (!this.numRegxForPattern.test(this.changeForm.value.newPassword)) {
                this.changeForm.get('newPassword').setErrors({ pattern: true });
            } else {
                this.changeForm.get('newPassword').setErrors(null)
                this.check = false
            }
        }
    }

    /** to get the value of field  */
    get password(): any {
        return this.changeForm.get('password');
    }
    get newPassword(): any {
        return this.changeForm.get('newPassword');
    }
    get confirmPassword(): any {
        return this.changeForm.get('confirmPassword');
    }

    back() {
        this.router.navigateByUrl('profile')
    }

    changePass() {
        if (this.changeForm.value.newPassword == "" ||  this.changeForm.value.password == "") {
            this.appC.showErrToast("Please enter a password");
            return;
        } 
        let data = {
            "newPassword": this.changeForm.value.newPassword,
            "oldPassword": this.changeForm.value.password

        }
        this.spinnerService.show();
        this.server.postApi('account/change-password', data).subscribe((res) => {
            this.spinnerService.hide();
            if (res.status == 200) {
                this.appC.showSuccToast("Password changed scuccesfully"); 
                this.router.navigate(['profile']);
            }
            else {
                this.spinnerService.hide();
                this.appC.showErrToast(res.message);
            }

        }, (err) => {
            this.spinnerService.hide();
            this.appC.showErrToast('Something went wrong')
        })
    }



}
