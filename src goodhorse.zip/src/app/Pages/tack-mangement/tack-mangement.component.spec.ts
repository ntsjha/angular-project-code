import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TackMangementComponent } from './tack-mangement.component';

describe('TackMangementComponent', () => {
  let component: TackMangementComponent;
  let fixture: ComponentFixture<TackMangementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TackMangementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TackMangementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
