import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, AlertController, Events, App } from 'ionic-angular';
import { AccountPage } from '../account/account';
import { ChangepassPage } from '../changepass/changepass';
import { FaqPage } from '../faq/faq';
import { TermsPage } from '../terms/terms';
import { LoginPage } from '../login/login';
import { SignpinPage } from "../signpin/signpin";
import { ServiceServicesProvider } from "../../providers/service-services/service-services";
import { FormGroup, FormControl, Validators } from '@angular/forms';

@IonicPage()
@Component({
  selector: 'page-setting-new',
  templateUrl: 'setting-new.html',
})
export class SettingNewPage {


  constructor(public navCtrl: NavController, public navParams: NavParams, public alerCtrl: AlertController, private events: Events, private appCtrl: App, public server: ServiceServicesProvider) {
  }
  // myNumber : number = 10.747647;
  // newNumber:string;
  

  AccountDetails() {
    this.navCtrl.push(AccountPage)
  }

  changePass() {
    this.navCtrl.push(ChangepassPage)
  }

  FAQ() {
    this.navCtrl.push(FaqPage)
  }

  termsOfUse() {
    this.navCtrl.push(TermsPage)
  }

  logout() {
    let confirm = this.alerCtrl.create({
      title: 'Logout?',
      message: 'Are you sure you want to Logout?',
      buttons: [
        {
          text: 'No',
          handler: () => {
            console.log('no');
          }
        },
        {
          text: 'Yes',
          handler: () => {
            localStorage.removeItem('userId')
            localStorage.removeItem('JWT')
            localStorage.removeItem('notibadge')
            this.checkPin();
          }
        }
      ]
    });
    confirm.present()
  }

  checkPin() {
    if (navigator.onLine) {
      this.server.presentLoading();
      let data = {
        userName: localStorage.getItem('userName')
      }
      this.server.postApi(data, 'user/pinExists', 0).subscribe((response: any) => {
        this.server.dismissLoading();
        if (response[`response_code`] == 200)
          this.appCtrl.getRootNav().setRoot(SignpinPage);
        else if (response.response_code == 403 || response.response_code == 409 || response.response_code == 401) {
          this.server.presentToast(response.response_message)
          this.server.logout();
        }
        else
          this.appCtrl.getRootNav().setRoot(LoginPage);
      }, err => {
        this.appCtrl.getRootNav().setRoot(LoginPage);
        this.server.dismissLoading();
        this.server.presentToast('Something went wrong')
      })
    }
    else {
      this.server.presentToast('Your internet connection seems to be lost')
      this.appCtrl.getRootNav().setRoot(LoginPage);
    }
  }

  // Opencheck(){
  //   this.newNumber = this.myNumber.toFixed(2);
  //  }
}
