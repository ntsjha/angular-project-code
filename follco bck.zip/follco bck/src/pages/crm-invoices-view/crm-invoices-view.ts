import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, App } from 'ionic-angular';
import { RestProvider } from '../../providers/rest/rest';
import { SettingprivacyPage } from '../settingprivacy/settingprivacy';

/**
 * Generated class for the CrmInvoicesViewPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-crm-invoices-view',
  templateUrl: 'crm-invoices-view.html',
})
export class CrmInvoicesViewPage {
  crmInvoicesViewList: any=[];
    title: any;
    date1: any;
    time: any;
    image: any;
    description: any;

  constructor(public navCtrl: NavController, public app :App,private service: RestProvider, public navParams: NavParams) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad CrmInvoicesViewPage');
    this.crmInvoicesList();
  }
  back(){
      this.navCtrl.pop();
  }
  setting(){
    this.app.getRootNav().push(SettingprivacyPage);
  }
  crmInvoicesList() {
    this.service.presentLoadingDefault('Loading...');
    this.service.get('invoices/single/'+ localStorage.getItem('invoicesID')+'?follco_token=' + localStorage.getItem('new_token'),0).subscribe(res =>{
        console.log(res);
        if(res) {
            this.service.dismissLoading();
            // this.crmInvoicesViewList = res["record"];
            this.title = res["record"].title;
            // console.log(this.title)
            this.date1 = res["record"].created_at;
            this.time=res["record"].creation_time;
            this.image=res["record"].image_thumb;
            this.description = res["record"].html;
            // console.log(this.description)
        }
       
    }, err => {
        this.service.dismissLoading();
        console.log(err);
    })
}
}
