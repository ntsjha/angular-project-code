import { Component, OnInit } from '@angular/core';
import { ServerService } from '../../../server.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { Router } from '@angular/router';

@Component({
    selector: 'app-news',
    templateUrl: './news.component.html',
    styleUrls: ['./news.component.css']
})
export class NewsComponent implements OnInit {
    pageData: any = [];
    p = 1;

    constructor(private server : ServerService, private spinnerService: Ng4LoadingSpinnerService, private router: Router) { }


    ngOnInit() {
        window.scrollTo(0,0);
        this.getPageData();
    }

    getPageData() {
        this.spinnerService.show();
        this.server.getApi('static/news/getNewsList').subscribe((succ) => {
            this.spinnerService.hide();
            succ.data.forEach(element => {
                if(element.newsContent.length > 55) {
                    element.newsContent = element.newsContent.substring(0,55)+'.....';
                } 
                if(element.newsImage == null) {
                    element.newsImage = '';
                } else if(element.newsImage.includes('https')) {
                } else {
                    element.newsImage = '';
                }
                this.pageData.push({
                    "newsId" : element.newsId,
                    "newsHeading" : element.newsHeading,
                    "newsContent" : element.newsContent,
                    "newsImage" : element.newsImage,
                    "creationDate" : element.creationDate,
                });
            });
            
        },err =>{
            this.spinnerService.hide();
        });
    }

    pageChange(page) {
        this.p = page;
        this.getPageData();
    }

    continue(id) {
        this.router.navigateByUrl('newsdetail/'+id);
    }

}
