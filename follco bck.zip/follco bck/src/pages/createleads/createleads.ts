import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, App } from 'ionic-angular';
import { SettingprivacyPage } from '../settingprivacy/settingprivacy';
import { RestProvider } from '../../providers/rest/rest';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { LeadPage } from '../lead/lead';
import { CrmCutomersPage } from '../crm-cutomers/crm-cutomers';
import { CrmPage } from '../crm/crm';

/**
 * Generated class for the CreateleadsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-createleads',
  templateUrl: 'createleads.html',
})
export class CreateleadsPage {
  leadTypeNew : any
  myDate:any;
  leadsForm:FormGroup;
  validation_messages = {
     'email': [
      { type: 'required', message: 'Email is required.' },
      { type: 'pattern', message: 'Please enter a valid email.' }
    ],
    'type': [
      { type: 'required', message: 'Type is required.' },
      
    ],
    'phone1':[
      { type: 'pattern', message: 'Please enter valid number.' }
    ],
    'phone2':[
      { type: 'pattern', message: 'Please enter valid number.' }
    ]
  };
  fullName: any;
  leadArr :any=[];
  leadType: any;
  value: any;
  type1: any;
  CategoryARR: any=[];
  newArr: any=[];
  newArrrr = [];
  constructor(public navCtrl: NavController, private service: RestProvider,public app :App,public navParams: NavParams) {

    this.leadsForm = new FormGroup({
     email: new FormControl('', Validators.compose([
        Validators.required,
        Validators.pattern(/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/)
      ])),
      firstname: new FormControl('', Validators.compose([
        
      ])),
      lastname: new FormControl('', Validators.compose([
        
      ])),
      type: new FormControl('', Validators.compose([
        Validators.required,
      ])),
      phone1: new FormControl('', Validators.compose([
        // Validators.pattern(/^[0-9\b]+$/)
      ])),
      phone2: new FormControl('', Validators.compose([
        // Validators.pattern(/^[0-9\b]+$/)
      ])),
      // gender: new FormControl('', Validators.compose([
        
      // ])),
      leadtype: new FormControl('', Validators.compose([
        
      ])),
      // dob: new FormControl('', Validators.compose([
        
      // ])),
      categoryId:new FormControl('', Validators.compose([
        
      ])),
    });
  }

  ionViewWillEnter(){
    this.leadTypeNew = this.service.leadType;    
    this.leadsForm.patchValue({
      'type' :  (this.leadTypeNew ? 'customer': 'lead')
    })

    console.log(this.leadTypeNew)
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad CreateleadsPage');
    this.getleadtype();
    this.getCatId();
  }

  back(){
    this.navCtrl.pop();
  }
  setting()
{
  this.app.getRootNav().push(SettingprivacyPage);
}
onChange(type1) {
  console.log(type1);
 
 
  if(this.type1 == 'customer') {
    this.value = 'customer';
    this.value = '';
   
    
  }
  else if (this.type1 == 'lead') {
    this.value = 'lead'; 
   
    console.log(this.value);
  }
}

Createleads(data){
   
    console.log(data);
    console.log(data.type);
    this.service.presentLoadingDefault('Creating account');

   this.fullName = this.leadsForm.value.firstname + " " + this.leadsForm.value.lastname
   console.log(this.fullName);
    if(data.type == 'customer'){
      let data1= new FormData();
      data1.append('first_name',this.leadsForm.value.firstname);
      data1.append('last_name',this.leadsForm.value.lastname);
      data1.append('email',this.leadsForm.value.email);
      data1.append('phone',this.leadsForm.value.phone1);
      // data1.append('birth_date',this.leadsForm.value.dob);
      data1.append('type',this.leadsForm.value.type);
      data1.append('category_id',this.leadsForm.value.categoryId);
      console.log("data1===+++>>",data1)
      this.service.post('customers/save?follco_token=' + localStorage.getItem('new_token'),data1,0).subscribe(res =>{
      console.log("Succ"+JSON.stringify(res)); 
      
      
      if(res.message){
        this.service.dismissLoading();
        this.service.presentToast(res.message) ; 
        this.navCtrl.pop();
      }else{
        this.service.presentToast(res.error) ; 
        this.service.dismissLoading();
        
      }
     
     
    },err =>{
      console.log(err);
      
    })

    }
    else if(data.type == 'lead'){
      let data1= new FormData();
      data1.append('first_name',this.leadsForm.value.firstname);
      data1.append('last_name',this.leadsForm.value.lastname);
      data1.append('email',this.leadsForm.value.email);
      data1.append('phone',this.leadsForm.value.phone1);
      // data1.append('birth_date',this.leadsForm.value.dob);
      data1.append('type',this.leadsForm.value.type);
      data1.append('lead_type',this.leadsForm.value.leadtype);
      data1.append('category_id',this.leadsForm.value.categoryId);
      console.log("data1===+++>>",data1)
      this.service.post('customers/save?follco_token=' + localStorage.getItem('new_token'),data1,0).subscribe(res =>{
      console.log("Succ"+JSON.stringify(res)); 
      
      
      if(res.message){
        this.service.dismissLoading();
        this.service.presentToast(res.message) ; 
        this.navCtrl.pop();
      }else{
        this.service.presentToast(res.error) ; 
        this.service.dismissLoading();
        
      }
     
     
    },err =>{
      console.log(err);
      
    })


    }
   
   
 
  }
  getleadtype(){
    // console.log('Country')
     this.service.get('misc/lead_type_list',0).subscribe(res =>{
       // console.log('CountryList'+JSON.stringify(res));
       if(res){
        this.leadArr = res['list'];
        console.log('leadsList'+JSON.stringify(this.leadArr));
        for (let [key, value] of (<any>Object).entries(this.leadArr)) {  
          // console.log('Aashish====> ',key + ':' + value);
         this. newArrrr.push({
            'Key' : key,
            'Type' : value
          })
        }
        console.log('shivam===>',this.newArrrr);

       }
     
     },err =>{
       console.log(err)
     })
  }
  getCatId(){
    // this.service.presentLoadingDefault('Loading...');
    this.service.get('customers/categories?follco_token=' + localStorage.getItem('new_token'),0).subscribe(res =>{
        console.log(res);
        if(res) {
            // this.service.dismissLoading();           
            console.log(res['categories']);
             this.CategoryARR = res['categories'];
             console.log(this.CategoryARR);        
            //  var newArr = [];
            for (let [key, value] of (<any>Object).entries(this.CategoryARR)) {  
              // console.log('Aashish====> ',key + ':' + value);
             this. newArr.push({
                'Key' : key,
                'Category' : value
              })
            }
            console.log('aashish===>',this.newArr)
        }
    }, err => {
        // this.service.dismissLoading();
        console.log(err);
    })
  }
}
