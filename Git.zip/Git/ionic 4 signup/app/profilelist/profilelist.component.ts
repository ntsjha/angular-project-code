import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profilelist',
  templateUrl: './profilelist.component.html',
  styleUrls: ['./profilelist.component.scss'],
})
export class ProfilelistComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
