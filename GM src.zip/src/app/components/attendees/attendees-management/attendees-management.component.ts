import { ActivatedRoute } from '@angular/router';
import { FormGroup, FormControl } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { ServiceService } from 'src/app/service/service.service';
import { DatePipe } from '@angular/common';

declare var $: any;

@Component({
  selector: 'app-attendees-management',
  templateUrl: './attendees-management.component.html',
  styleUrls: ['./attendees-management.component.css']
})
export class AttendeesManagementComponent implements OnInit {

  attendeesList: any = [];
  paginationData: any = { limit: 10, currPage: 1, total: 0 };
  modalType: any;
  selectedData: any;
  englishShortCode: any;
  searchForm: FormGroup;
  paramData: any;
  selectedId: any = [];
  userData: any;

  constructor(
    private service: ServiceService,
    private activatedRoute: ActivatedRoute,
    private datepipe: DatePipe
  ) { }

  ngOnInit() {
    window.scrollTo(0, 0);
    this.form();
    this.getParamData();
    this.getUserInfo();
    this.getattendeesList('reset');
    this.englishShortCode = this.service.englishLanguageShortCode;
  }

  getUserInfo() {
    this.service.userInfo.subscribe(success => {
      this.userData = success;
    });
  }

  form() {
    this.searchForm = new FormGroup({
      search: new FormControl('')
    });
  }

  getParamData() {
    this.activatedRoute.params.subscribe(param => {
      this.paramData = param;
    });
  }

  getattendeesList(event) {
    let apireq;
    if (event === 'reset') {
      apireq = {
        page: this.paginationData.currPage != 0 ? this.paginationData.currPage - 1 : this.paginationData.currPage,
        pageSize: this.paginationData.limit,
        search: null,
        contentId: this.paramData.id
      };
      this.paginationData.currPage = 1;
    } else {
      if (event === 'apply') {
        apireq = {
          page: this.paginationData.currPage != 0 ? this.paginationData.currPage - 1 : this.paginationData.currPage,
          pageSize: this.paginationData.limit,
          search: this.searchForm.value.search ? this.searchForm.value.search : null,
          contentId: this.paramData.id
        };
      }
    }
    this.service.postMethod('event/admin/get-attendees-list', apireq, 1).subscribe(success => {
      if (success.status === 1040) {
        this.attendeesList = success.data.list;
        this.paginationData.total = success.data.totalCount;
      } else {
        this.attendeesList = [];
      }
    }, error => {
      this.attendeesList = [];
    });
  }

  changePage(event) {
    this.paginationData.currPage = event;
    this.getattendeesList('apply');
  }

  openModal(data, whichOne) {
    this.modalType = whichOne;
    this.selectedData = data;
    $('#unPublishdeleteModal').modal({ backdrop: 'static', keyboard: false });
  }

  yesModal() {

  }

  remove() {
    if (!this.selectedId.length) {
      return;
    }
    this.service.postMethod(`event/admin/remove-participants-details?contentId=${this.paramData.id}&participantIds=${this.selectedId}&ipAddress=${this.userData.ip}&location=${this.userData.country_name}`, {}, 1).subscribe(success => {
      if (success.status === 1047) {
        this.getattendeesList('apply');
      }
    }, error => {
    });
  }

  export() {
    const data = [];
    if (this.attendeesList.length) {
      this.attendeesList.forEach((ele) => {
        data.push({
          'Customer Name': ele.customerName,
          Email: ele.email,
          Phone: ele.phone,
          'No. of Tickets': ele.noOfSeats,
          'Registration Date': (ele.createdAt != null) ? this.convertFormat(ele.createdAt) : ''
        });
      });
      this.service.exportAsExcelFile(data, 'Attendees List');
    }

  }

  /** Function to convert date format */
  convertFormat(time) {
    if (time != null) {
      return this.datepipe.transform(time, 'medium');
    }
  }

  selectAll() {
    this.selectedId = [];
    if ($('#selectAll').is(':checked')) {
      this.attendeesList.forEach((element, i) => {
        this.selectedId.push(element.eventRegistrationId);
        $('#attendeesId' + i).prop('checked', true);
      });
    } else {
      this.attendeesList.forEach((element, i) => {
        $('#attendeesId' + i).prop('checked', false);
      });
      this.selectedId = [];
    }
  }

  singleSelection(index, data) {
    if ($('#attendeesId' + index).is(':checked')) {
      if (this.selectedId.indexOf(data.eventRegistrationId) < 0) {
        this.selectedId.push(data.eventRegistrationId);
      }
    } else {
      this.selectedId.splice(this.selectedId.indexOf(data.eventRegistrationId), 1);
    }
  }
}
