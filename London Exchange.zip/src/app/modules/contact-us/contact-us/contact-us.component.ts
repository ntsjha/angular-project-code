import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ServerService } from '../../../service/server.service';
import { AppComponent } from '../../../app.component';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
declare var $:any;

@Component({
  selector: 'app-contact-us',
  templateUrl: './contact-us.component.html',
  styleUrls: ['./contact-us.component.css']
})
export class ContactUsComponent implements OnInit {
  contactForm: FormGroup;

      constructor(private server: ServerService , private appC: AppComponent, private spinnerService: Ng4LoadingSpinnerService) { }

      ngOnInit() {
        window.scrollTo(0,0);
        this.checkInputs();
        $("#phone").intlTelInput({
          autoPlaceholder: true,
          autoFormat: false,
          autoHideDialCode: false,
          initialCountry: 'in',
          nationalMode: false,
          onlyCountries: [],
          preferredCountries: ["us"],
          formatOnInit: true,
          separateDialCode: true
        });
        
      }

      /** Function to validate form inputs */
      checkInputs() {
        this.contactForm = new FormGroup ({
            semail: new FormControl('', [Validators.required, Validators.pattern(/^[A-Z0-9_]+([\.][A-Z0-9_]+)*@[A-Z0-9-]+(\.[a-zA-Z]{2,3})+$/i)]),
            phone: new FormControl('', [Validators.required, Validators.pattern(/^[1-9]{1}[0-9]*$/), Validators.minLength(7)]),
            name: new FormControl('', [Validators.required, Validators.minLength(3), Validators.pattern(/^[a-zA-Z ]*$/i)]),
            message: new FormControl('', [Validators.required,]),
            
        });
        
      }


      /** to get the value of field  */
      get semail(): any {
        return this.contactForm.get('semail');
      }
      get phone(): any {
        return this.contactForm.get('phone');
      }
      get name(): any {
        return this.contactForm.get('name');
      }
      get message(): any {
        return this.contactForm.get('message');
      }

      submit()  {
          let data =  {
              "eventExternal":  {
                        "name":"request_contact_us",
                        "key":"mykey"
              },
              "transferObjectMap":  {
                    "gatewayrequest": {
                        "email":this.contactForm.value.semail,
                        "description":this.contactForm.value.message,
                        "attachment":"",
   
                    }
              }
          }
          this.spinnerService.show();
            this.server.postApi('', data,0).subscribe(response => {
                this.spinnerService.hide();
                if (response.transferObjectMap.statusCode == 200) {
                    this.appC.showSuccToast(response.transferObjectMap.message);
                    
                } else {
                  this.appC.showErrToast(response.transferObjectMap.message)
                }
            }, error => {
                this.spinnerService.hide();
                this.appC.showErrToast('Something went wrong.');  
            })
      }

}
