import { ActivatedRoute } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { ServiceService } from 'src/app/service/service.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { FormGroup, FormControl } from '@angular/forms';
import { DatePipe } from '@angular/common';

declare var $: any;

@Component({
    selector: 'app-job-application',
    templateUrl: './job-application.component.html',
    styleUrls: ['./job-application.component.css']
})

export class JobApplicationComponent implements OnInit {
    jobApplication: FormGroup;
    paginationData: any = { limit: 10, currPage: 1, total: 0 };
    paramData: any;
    jobApplicationData: any = [];
    modalType: any;
    selectedApplicationData: any;
    rejectStatus: any = true;
    selectStatus: any = true;


    constructor(
        private service: ServiceService,
        private spinner: NgxSpinnerService,
        private ativatedRoute: ActivatedRoute,
        private datepipe: DatePipe
    ) {
        this.jobApplication = new FormGroup({
            search: new FormControl(''),
            status: new FormControl(''),
        });
        // approve/RejectApplication
    }

    /** Function to get data values */
    get search(): any {
        return this.jobApplication.get('search');
    }
    get status(): any {
        return this.jobApplication.get('status');
    }

    /** Function to send value */
    jobApplicationTest(...val) {
        this.jobApplication.controls.search.setValue(val[0]);
        this.jobApplication.controls.status.setValue(val[1]);
        return this.jobApplication.valid;
    }

    ngOnInit() {
        window.scrollTo(0, 0);
        this.getParamData();
        this.rejectStatus = this.service.sideMenuArr.length ? this.service.sideMenuArr.includes('approve/RejectApplication') : true;
        this.selectStatus = this.service.sideMenuArr.length ? this.service.sideMenuArr.includes('selectApplication') : true;
    }

    getParamData() {
        this.ativatedRoute.params.subscribe(param => {
            this.paramData = param;
            this.getApplicationList('reset');
        });
    }

    /** Function to get job application list */
    getApplicationList(event) {
        this.spinner.show();
        let apireq;
        if (event === 'reset') {
            apireq = {
                page: this.service.encrypt(this.paginationData.currPage),
                pageSize: this.service.encrypt(this.paginationData.limit),
                jobStatus: null,
                search: null,
                contentId: this.service.encrypt(this.paramData.id)
            };
            this.paginationData.currPage = 1;
        } else {
            if (event === 'apply') {
                apireq = {
                    page: this.service.encrypt(this.paginationData.currPage),
                    pageSize: this.service.encrypt(this.paginationData.limit),
                    jobStatus: (this.jobApplication.value.status !== '') ? this.service.encrypt(this.jobApplication.value.status) : null,
                    search: (this.jobApplication.value.search !== '') ? this.service.encrypt(this.jobApplication.value.search) : null,
                    contentId: this.service.encrypt(this.paramData.id)
                };
            }
        }
        this.service.postMethod(`career/admin/search-job-application-filter`, apireq, 1).subscribe((response: any) => {
            this.spinner.hide();
            let responseData = this.service.decrypt(response.data);
            responseData = JSON.parse(responseData);
            if (responseData.status === 753) {
                this.jobApplicationData = responseData.data.reasponseData;
                this.paginationData.total = responseData.data.size;
            } else {
                this.jobApplicationData = [];
            }
            this.spinner.hide();
        }, (error) => {
            this.jobApplicationData = [];
            this.spinner.hide();
        });
    }

    exportFunc() {
        if (this.jobApplicationData.length > 0) {
            const data = [];
            this.jobApplicationData.forEach((ele) => {
                data.push({
                    Applicant_Name: ele.firstName + ele.lastName,
                    Applied_On: (ele.applicationDate != null) ? this.convertFormat(ele.applicationDate) : '',
                    Email: ele.email,
                    Phone: ele.phone,
                    Application_Status: ele.jobStatus,
                });
            });
            this.service.exportAsExcelFile(data, 'Job Application List');
        }
    }

    convertFormat(time) {
        if (time != null) {
            return this.datepipe.transform(time, 'MM/dd/yyy, hh:mm a');
        }
    }

    changePage(event) {
        this.paginationData.currPage = event;
        this.getApplicationList('apply');
    }

    openModal(data, whichModal) {
        const type = (whichModal === 'REJECTED') ? 'approve/RejectApplication' : 'selectApplication';
        if (this.service.sideMenuArr.includes(type)) {
            this.selectedApplicationData = data;
            this.modalType = whichModal;
            $('#manage-application').modal({ backdrop: 'static', keyboard: false });
        }

    }

    modalYesButton() {
        this.spinner.show();
        const apireq = {
            contentId: this.service.encrypt(this.selectedApplicationData.applicationId),
            jobStatus: this.service.encrypt(this.modalType)
        };
        this.service.postMethod('career/admin/change-job-application-status', apireq, 1).subscribe((success: any) => {
            this.spinner.hide();
            const decryptedData = success.data ? JSON.parse(this.service.decrypt(success.data)) : {};
            if (decryptedData.status === 827) {
                $('#manage-application').modal('hide');
                this.getApplicationList('apply');
            }
        }, error => {
            this.spinner.hide();
        });
    }

}
