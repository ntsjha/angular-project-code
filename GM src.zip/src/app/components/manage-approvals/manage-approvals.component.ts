import { Component, OnInit, OnDestroy } from '@angular/core';
import { ServiceService } from 'src/app/service/service.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { CookieService } from 'ngx-cookie-service';
import { FormGroup, FormBuilder, FormArray } from '@angular/forms';
import { AppComponent } from 'src/app/app.component';

declare var $: any;

@Component({
    selector: 'app-manage-approvals',
    templateUrl: './manage-approvals.component.html',
    styleUrls: ['./manage-approvals.component.css']
})
export class ManageApprovalsComponent implements OnInit, OnDestroy {

    google: any = { one: '', two: '', three: '', four: '', five: '', six: '' };
    rolesArr: any;
    showApiMessage: boolean;
    response: any;
    approvalData: any;
    dualRoles: any;
    manageApprovalForm: FormGroup;
    approvals: FormArray;
    currentUser: any;
    levelOne: any = {};
    levelTwo: any = {};
    TEST: any = 'ADMIN';
    approvalArray = [];
    subscription: any;

    constructor(private service: ServiceService, private spinner: NgxSpinnerService, private cookie: CookieService, private fb: FormBuilder, private appC: AppComponent) {
        this.subscription = this.service.authVerify.subscribe(val => {
           
            if (val === 'manage-approval') {
                this.submitApproval();
                this.service.authVerify.next('false');
            }
        });
    }
    ngOnInit() {
        this.getApprovals();
        this.manageApprovalForm = this.fb.group({
            approvals: this.fb.array([])
        });
        this.service.currentUserInfo.subscribe((response) => {
            this.currentUser = response;
        });
        window.scrollTo(0, 0);
    }

    ngOnDestroy() {
        this.subscription.unsubscribe();
    }

    changeLevelOne(myvalue, pageIndex) {
        const arr = myvalue.split(':');
        const index = arr[0];
        this.approvalArray[pageIndex].levelOneApproval.role = this.rolesArr[index - 1].role;
        this.approvalArray[pageIndex].levelOneApproval.rolesId = this.rolesArr[index - 1].rolesId;
    }

    changeLevelTwo(myvalue, pageIndex) {
        const arr = myvalue.split(':');
        const index = arr[0];
        this.approvalArray[pageIndex].levelTwoApproval.role = this.rolesArr[index - 1].role;
        this.approvalArray[pageIndex].levelTwoApproval.rolesId = this.rolesArr[index - 1].rolesId;
    }

    /** Function to verify google authentication */
    verifyGoogleAuth() {
        this.appC.google = { one: '', two: '', three: '', four: '', five: '', six: '' };
        this.appC.response = { 'message': '' };
        this.service.googleAuthCalledFrom = 'manage-approval';
        $('#google-auth-modal').modal({ keyboard: false, backdrop: 'static' });

    }

    submitApproval() {
        this.spinner.show();
        const data = {
            approvalPermissionSubDto: this.approvalArray,
            ipAddress: this.currentUser.ip,
            location: this.currentUser.city + ',' + this.currentUser.country_name,
        };
        this.service.postMethod('account/superAdmin/user-management/set-approval-permission', data, 1)
            .subscribe((response) => {
                window.scrollTo(0, 0);
                this.spinner.hide();
                if (response.status === 2008) {
                    this.showApiMessage = true;
                    this.response = response;
                    this.response.message = 'Dual approval list updated successfully.';
                }
            }, (error) => {
                this.spinner.hide();
                window.scrollTo(0, 0);
                this.showApiMessage = true;
                this.response = error.error;
                this.response.message = error.error.message;
            });
    }

    getApprovals() {
        this.spinner.show();
        this.dualRoles = [];
        this.service.postMethod('account/superAdmin/user-management/dual-approval-pages', {}, 1)
            .subscribe((response) => {
                this.spinner.hide();
                if (response.status === 2704) {
                    this.approvalData = response.data;
                    this.rolesArr = this.approvalData.roles ? this.approvalData.roles : '';
                    this.approvalData.approvalPages.forEach(element => {
                        const arr = {
                            levelOneApproval: {
                                role: element.levelOneApproval ? (element.levelOneApproval.role ? element.levelOneApproval.role : '') : '',
                                rolesId: element.levelOneApproval ? (element.levelOneApproval.rolesId ? element.levelOneApproval.rolesId : '') : '',
                            },
                            levelTwoApproval: {
                                role: element.levelTwoApproval ? (element.levelTwoApproval.role ? element.levelTwoApproval.role : '') : '',
                                rolesId: element.levelTwoApproval ? (element.levelTwoApproval.rolesId ? element.levelTwoApproval.rolesId : '') : '',
                            },
                            menuPermissionId: element.menuPermission ? (element.menuPermission.menuPermissionId ? element.menuPermission.menuPermissionId : '') : '',
                            name: element.menuPermission.menuName || element.menuPermission.dataSubMenu
                        };
                        this.dualRoles.push(arr);
                    });
                    this.createRoleAndApproval();
                }
            }, (error) => {
                this.spinner.hide();
            });
    }

    createRoleAndApproval() {
        this.dualRoles.forEach(element => {
            const arr = {
                levelOneApproval: {
                    role: element.levelOneApproval ? (element.levelOneApproval.role ? element.levelOneApproval.role : '') : '',
                    rolesId: element.levelOneApproval ? (element.levelOneApproval.rolesId ? element.levelOneApproval.rolesId : '') : '',
                },
                levelTwoApproval: {
                    role: element.levelTwoApproval ? (element.levelTwoApproval.role ? element.levelTwoApproval.role : null) : null,
                    rolesId: element.levelTwoApproval ? (element.levelTwoApproval.rolesId ? element.levelTwoApproval.rolesId : null) : null,
                },
                menuPermissionId: element.menuPermissionId ? element.menuPermissionId : ''
            };
            this.approvalArray.push(arr);
        });
    }

    /** Auto focus functionality */
    onKey(event, next, previous) {
        if (event.key === 'Backspace') {
            document.getElementById(previous).focus();
        } else {
            if (event.keyCode >= 48 && event.keyCode <= 57) {
                if (event.target.value.trim() !== '') {
                    document.getElementById(next).focus();
                } else {
                    event.target.value = '';
                }
            } else {
                event.target.value = '';
            }
        }
    }


}
