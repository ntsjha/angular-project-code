import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { DatePipe } from '@angular/common';
import { ServiceService } from 'src/app/service/service.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-update-reward-setting',
  templateUrl: './update-reward-setting.component.html',
  styleUrls: ['./update-reward-setting.component.css']
})
export class UpdateRewardSettingComponent implements OnInit {
  rewardFunction: FormGroup;
  getRewardsettingDefault: any;
  updateApiResponse: any = { status: 1326, message: '' };
  show: any = false;

  constructor(private service: ServiceService,
    public datepipe: DatePipe,
    private spinner: NgxSpinnerService,
    private route: Router) {
    this.rewardFunction = new FormGroup({
      maxPointFriend: new FormControl(null, [Validators.required, Validators.pattern(/^[0-9]*$/), Validators.minLength(1), Validators.maxLength(10)]),
      maxPointKYC: new FormControl(null, [Validators.required, Validators.pattern(/^[0-9]*$/), Validators.minLength(1), Validators.maxLength(10)]),
      maxPercentageTrading: new FormControl(null, [Validators.required, Validators.pattern(/^(100(?:\.00)?|0(?:\.\d\d)?|\d?\d(?:\.\d\d)?)$/)]),
    });
  }

  ngOnInit() {
    this.getRewardDefault();
    window.scrollTo(0, 0);
  }

  getRewardDefault() {
    this.spinner.show();
    this.service.getMethod('rewards/common-permit/get-default-reward-setting', 1).subscribe((response: any) => {
      this.spinner.hide();
      if (response.status === 1328) {
        this.getRewardsettingDefault = response.data.defaultRewardData;
        this.rewardFunction.patchValue({
          maxPointFriend: this.getRewardsettingDefault[0].rewardPointOrpercentage,
          maxPointKYC: this.getRewardsettingDefault[1].rewardPointOrpercentage,
          maxPercentageTrading: this.getRewardsettingDefault[2].rewardPointOrpercentage,
        });
      }
    }, (error) => {
      this.spinner.hide();
    });
    this.spinner.hide();
  }

  goBackToReward() {
    this.route.navigate(['/reward-setting-sidebar']);
  }

  updateReward() {
    if (this.rewardFunction.invalid) {
      return;
    }
    this.spinner.show();
    const apireq = {
      pointsForKyc: this.rewardFunction.value.maxPointKYC,
      percentageForTrading: this.rewardFunction.value.maxPercentageTrading,
      pointForRefering: this.rewardFunction.value.maxPointFriend
    };
    this.service.postMethod('rewards/common-permit/update-default-reward-point', apireq, 1).subscribe((response: any) => {
      this.spinner.hide();
      this.show = true;
      this.updateApiResponse = response;
      if (response.status === 200) {
        this.route.navigate(['/reward-setting-sidebar']);
      }
    }, (error) => {
      this.spinner.hide();
      this.show = true;
      this.updateApiResponse.message = error ? (error.error ? (error.error.error ? error.error.error : 'Internal server error') : 'Internal server error') : 'Internal server error';
      this.updateApiResponse.status = 500;
    });
  }

  /** Function to restrict negative and positive symbol */
  restrictChar(e) {
    if (!((e.keyCode > 95 && e.keyCode < 106)
      || (e.keyCode > 47 && e.keyCode < 58)
      || e.keyCode == 8)) {
      return false;
    }
  }
}
