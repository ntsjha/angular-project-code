import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { MarketingSidebarComponent } from './sidebar.component';
import { RouterModule } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { SharedModuleModule } from 'src/app/shared-module/shared-module.module';
import { DeviceDetectorService } from 'ngx-device-detector';
import { AppComponent } from 'src/app/app.component';

describe('MarketingSidebarComponent', () => {
  let component: MarketingSidebarComponent;
  let fixture: ComponentFixture<MarketingSidebarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MarketingSidebarComponent ],
      imports: [RouterModule, RouterTestingModule, SharedModuleModule],
      providers: [DeviceDetectorService, AppComponent]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MarketingSidebarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
