import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, App, AlertController } from 'ionic-angular';
import { RestProvider } from '../../providers/rest/rest';
import { SettingprivacyPage } from '../settingprivacy/settingprivacy';
import { CreateleadsPage } from '../createleads/createleads';
import { EditleadscustomerPage } from '../editleadscustomer/editleadscustomer';
import { CallNumber } from '@ionic-native/call-number';
import { CustomerLeadsSingleViewPage } from '../customer-leads-single-view/customer-leads-single-view';
import { CrmPage } from '../crm/crm';

/**
 * Generated class for the CrmCutomersPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-crm-cutomers',
  templateUrl: 'crm-cutomers.html',
})
export class CrmCutomersPage {
  customerList: any=[];
  leadsList: any=[];

  constructor(public navCtrl: NavController,public alertController: AlertController, public app :App,private service: RestProvider,private callNumber: CallNumber,public navParams: NavParams) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad CrmCutomersPage');
    this.getleads();
  }
  back(){
    this.navCtrl.pop();
  }
  addleads(){
    this.app.getRootNav().push(CreateleadsPage);
  }
  callMe(phone){
    this.callNumber.callNumber(phone, true)
    .then(res => console.log('Launched dialer!', res))
    .catch(err => console.log('Error launching dialer', err));
  }
  setting(){
    this.app.getRootNav().push(SettingprivacyPage);
  }
  doRefresh(refresher) {
    console.log('Begin async operation', refresher);
     this.getleads();
    setTimeout(() => {
      console.log('Async operation has ended');
      refresher.complete();
    }, 2000);
  }
  
  doPulling(refresher) {
    // console.log('DOPULLING', refresher.progress);
  //   console.log('Begin async operation', refresher);
  //   this.getFollowers();
  //  setTimeout(() => {
  //    console.log('Async operation has ended');
  //    refresher.complete();
  //  }, 2000);
  }
  getleads() {
    this.service.presentLoadingDefault('Loading...');
    this.service.get('customers/list?follco_token=' + localStorage.getItem('new_token'),0).subscribe(res =>{
        console.log(res);
        if(res) {
            this.service.dismissLoading();
            this.leadsList = res['list'];
            // this.time = new Date (this.campaignList[0].created_at);
            // this.time1 =this.time.getDate() + '/' + (this.time.getMonth()+1) + '/' + this.time.getFullYear();
            // console.log(this.time1); 
         
          
        }
    }, err => {
        this.service.dismissLoading();
        console.log(err);
    })
  }
  leadId(ID){
    console.log(ID);
    localStorage.setItem('customer_id',ID);
    this.navCtrl.push(EditleadscustomerPage);
  
  }
  Viewsingleleads(id){
    console.log(id);
    localStorage.setItem('customer_id',id);
    this.navCtrl.push(CustomerLeadsSingleViewPage);
  
  }

  deletecustomer(id){
    localStorage.setItem('customer_id',id);
    let method = this.alertController.create({			
      message: 'Do you want to delete?',
      buttons: [
        {
          text: 'Yes',
          cssClass: 'method-color',
          handler: () => {
            console.log('Yes');
            this.service.presentLoadingDefault('Deleting...');
            let data1= new FormData();
            this.service.post('customers/delete/'+localStorage.getItem('customer_id')+'?follco_token='+ localStorage.getItem('new_token'),data1,0).subscribe(res =>{
            console.log("Succ"+JSON.stringify(res)); 
            
            
            if(res.message){
              this.service.dismissLoading();
              this.service.presentToast(res.message) ; 
              this.navCtrl.push(CrmPage);
            }else{
              this.service.presentToast(res.error) ; 
              this.service.dismissLoading();
              
            }
           
           
          },err =>{
            console.log(err)
            
          })
          }
        },
        {
          text: 'No',
          role: 'cancel',
          cssClass: 'method-color',
          handler: () => {
            console.log('No');
          }
        }
      ]
    });
    method.present();
  
   
  }
}
