import { Component, OnInit } from '@angular/core';
import { AngularFirestore } from '@angular/fire/firestore';
import { ServiceService } from 'src/app/Shared/service.service';
import {  UserGuide } from 'src/app/Shared/feed-type';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-user-guide',
  templateUrl: './user-guide.component.html',
  styleUrls: ['./user-guide.component.css']
})
export class UserGuideComponent implements OnInit {
  Subscriptionplan: {}[];
  p: number = 1;
  pageSize = 5;
  total = 0
  searchText: any;
  id: any;
  featurelist: any;
  featurelistLength: number;
  featurelistview: any;
  userGuidelistLength: number;
  userguidelist: UserGuide[];
  constructor(private afs: AngularFirestore, private firebaseServ: ServiceService, public route: ActivatedRoute) { }

  ngOnInit() {
    this.getUserGuide()
  }

  getUserGuide() {
    // var userguidelist=[];
    this.firebaseServ.showSpinner();
    this.firebaseServ.getuserguied().subscribe(res => {
      this.userguidelist = res.map(item => {
        return {
          
          id: item.payload.doc.id,
          ...item.payload.doc.data()
          // Declare model at FeedType for resuable
        } as UserGuide 
      })
      this.firebaseServ.hideSpinner();
      this.userGuidelistLength = this.userguidelist.length
      console.log('DATA===>', this.userguidelist)
    })

  }
  viewFuction(id) {
   
   var data  = this.featurelist.filter(x => (x.id == id));
   this.featurelistview=data[0]
    console.log(id,this.featurelistview)

  }
 


  deleteFuction(id) {
    this.id = id
    console.log(this.id)

  }
  onDelete() {
    this.firebaseServ.showSpinner();
    this.afs.doc('UserGuide/' + this.id).delete();
    this.firebaseServ.hideSpinner();
    this.firebaseServ.showSuccess('User guide has been deleted successfully.');
    this.getUserGuide()
  }

  // search() {
   
  //   let searchData = []
  //   searchData = this.featurelist.filter(x => (x['Title'] == this.searchText));

  //   console.log("Nts jha -->>", this.Subscriptionplan, searchData)
  //   this.featurelist = searchData;
  //   this.total = this.featurelist.length;

  // }
  

  page(event) {
    console.log(event);
    this.p = event
  }

}
