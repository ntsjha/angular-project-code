import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AngularFirestore } from '@angular/fire/firestore';
import { ServiceService } from 'src/app/Shared/service.service';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { formatDate } from '@angular/common';
import { StaticContentFAQ } from 'src/app/Shared/feed-type';
@Component({
  selector: 'app-edit-static-faq',
  templateUrl: './edit-static-faq.component.html',
  styleUrls: ['./edit-static-faq.component.css']
})
export class EditStaticFAQComponent implements OnInit {
  contentname: any;
  docname: any;
  addFaqform: FormGroup;
  staticContentFAQ: StaticContentFAQ[];

  docID: any;
  staticContentFAQLength: StaticContentFAQ[];

  constructor(public router: Router, private afb: AngularFirestore, private firebaseServ: ServiceService, public route: ActivatedRoute) { }

  ngOnInit() {
    this.route.queryParams.subscribe((res) => {
      console.log('params--->>> ', res);

      this.contentname = res.value
      this.docname = res.docname
      this.docID = res.id
    })
    this.checkInput()
    this.getStaticFAQ()
  }

  checkInput() {
    this.addFaqform = new FormGroup({
      question: new FormControl('', [Validators.required, ,Validators.pattern(/^[^-\s][a-zA-Z0-9_:'@$()/%;.&*?\s-]*$/), Validators.maxLength(150)]),
      answer: new FormControl('', [Validators.required, Validators.pattern(/^[^-\s][a-z\d\-$=%()!#%/^;:_?@.'",*&?\s]*$/i), Validators.maxLength(350)]),

    })
  }

  getStaticFAQ() {
    this.firebaseServ.showSpinner();
    this.firebaseServ.getstaticFAQ(this.docname).subscribe(res => {
      this.staticContentFAQ = res.map(item => {
        return {
          id: item.payload.doc.id,
          ...item.payload.doc.data()
        } as StaticContentFAQ
      })
      this.firebaseServ.hideSpinner();



      console.log('DATA===>', this.staticContentFAQ)
      this.staticContentFAQLength = this.staticContentFAQ.filter(x => (x.id == this.docID))
      this.addFaqform.patchValue({
        'answer': this.staticContentFAQLength[0].Answer ? this.staticContentFAQLength[0].Answer : '',
        'question': this.staticContentFAQLength[0].Question ? this.staticContentFAQLength[0].Question : '',

      })
      this.firebaseServ.hideSpinner();
      console.log(this.staticContentFAQLength)
    });

  }

  editstatic() {
    var time = formatDate(new Date(), 'yyyy/MM/dd h:mm:ss', 'en');
    console.log(this.addFaqform.value, this.staticContentFAQLength[0].id)
    this.afb.collection('StaticContent').doc('FAQ').collection('FAQ').doc(this.staticContentFAQLength[0].id).update({
      Answer: this.addFaqform.value.answer,
      Question: this.addFaqform.value.question,
      // Lastupdate:time

    });
    this.firebaseServ.showSuccess('FAQ has been updated successfully.');
    this.router.navigate(['/static-content/view-static-content/id'], {
      queryParams: { value: this.docname, docname: this.docname }
    })
  }






  viewFaq() {
    this.router.navigate(['/static-content/view-static-content/id'], {
      queryParams: { value: this.docname, docname: this.docname }
    })

  }

  preventSpace(event){
    if(event.charCode==32 && !event.target.value){
    event.preventDefault()
    } else{
    console.log(event)
    }
    console.log('event',event.charCode)
    }
}
