import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UsdtransactionComponent } from './usdtransaction.component';

describe('UsdtransactionComponent', () => {
  let component: UsdtransactionComponent;
  let fixture: ComponentFixture<UsdtransactionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UsdtransactionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UsdtransactionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
