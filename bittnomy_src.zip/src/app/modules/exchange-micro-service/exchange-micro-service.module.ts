import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ExchangeMicroServiceComponent } from './exchange-micro-service/exchange-micro-service.component';
import { FormsModule } from '@angular/forms';
 import { FilterdataPipe } from '../../filterdata.pipe';
@NgModule({
  declarations: [ExchangeMicroServiceComponent,],
  imports: [
    CommonModule,
    FormsModule
  ]
})
export class ExchangeMicroServiceModule { }
