import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ServiceService } from 'src/app/service/service.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'app-daily-clouser',
  templateUrl: './daily-clouser.component.html',
  styleUrls: ['./daily-clouser.component.css']
})
export class DailyClouserComponent implements OnInit {
  getHour: any;
  dateTime2: any = '';
  userIp: any;

  constructor(
    private service: ServiceService,
    private spinner: NgxSpinnerService,
    private cookie: CookieService
  ) {
    this.userIp = (this.cookie.get('userInfo')) ? JSON.parse(this.cookie.get('userInfo')) : this.service.initialUserInfo;
  }

  ngOnInit() {
    window.scrollTo(0, 0);
    this.getDailyClouserAlert();
  }

  getDailyClouserAlert() {
    this.spinner.show();
    this.service.getMethod('setting-service/admin/exchange-control-alert/check-and-create-closure-hours', 1).subscribe((response: any) => {
      this.spinner.hide();
      if (response.status === 700) {
        this.getDailyClouserTime();
      }
    }, (error) => {
      this.spinner.hide();
    });
    this.spinner.hide();
  }

  getDailyClouserTime() {
    this.spinner.show();
    this.service.getMethod('setting-service/admin/exchange-control-alert/get-closure-hours', 1).subscribe((response: any) => {
      this.spinner.hide();
      if (response.status === 700) {
        this.getHour = response.data;
        this.loadForm();
      }
    }, (error) => {
      this.spinner.hide();
    });
    this.spinner.hide();

  }

  loadForm() {
    var today = new Date();
    this.dateTime2 = new Date(today.getFullYear(), today.getMonth(), today.getDay(), this.getHour.closureHour, this.getHour.closureMins, today.getMinutes());
  }

  postHour() {
    if (this.dateTime2) {
      this.spinner.show();
      const data = {
        closureHours: this.dateTime2.getHours(),
        closureMins: this.dateTime2.getMinutes(),
        ipAddress: this.userIp.ip,
        location: this.userIp.city + ',' + this.userIp.country_name
      };
      this.service.postMethod('setting-service/admin/exchange-control-alert/update-closure-hours', data, 1).subscribe((res: any) => {
        this.spinner.hide();
        if (res.status === 700) {
          this.getDailyClouserTime();
        }
      }, (error) => {
        this.spinner.hide();
      });
    }

  }

}
