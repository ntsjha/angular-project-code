import { Component, OnInit } from '@angular/core';
import { ServiceService } from 'src/app/service/service.service';
import { Router } from '@angular/router';
import { AngularCsv } from 'angular7-csv/dist/Angular-csv';

declare var $:any;
@Component({
    selector: 'app-inquiries',
    templateUrl: './inquiries.component.html',
    styleUrls: ['./inquiries.component.css']
})
export class InquiriesComponent implements OnInit {
    inquiryList: any = [];
    disable: boolean = false;
    page:any = 1;
    status:any; 
    search_key: any = '';
    pageSize: any = 10;
    obj:any = {search_key: ''};
    totalItems: any = 0;
    constructor(public service: ServiceService, public router:Router) { 
        
    }

    ngOnInit() {
        window.scrollTo(0,0);
        this.getInquiryList();
    }

    getInquiryList() {
        this.inquiryList = [];
        let data = {
            "page": this.page != 0 ? this.obj.search_key != '' ? this.service.encrypt(0) : this.service.encrypt(this.page - 1) : this.service.encrypt(0),
            "pageSize": this.service.encrypt(this.pageSize),
            "search" : this.obj.search_key != '' ? this.service.encrypt(this.obj.search_key.trim()) : null
        };
        // if(this.search_key != '') {
        //     data['search'] = this.service.encrypt(this.search_key);
        // }
        // if(this.status) {
        //     data['status'] = this.service.encrypt(this.status);
        // }
        this.service.postMethod('static/common-permit/search-filter-inquiry-list',data,1).subscribe((res)=>{
            if(res.data) {
                this.inquiryList = res.data.list;
                this.totalItems = res.data.size;
            }
        });
    }
    viewDetail(id) {
       this.router.navigate(['reply-history/',id]);
    }

    filterBySearch() {
       this.status  = '';
       this.search_key = '';
       this.getInquiryList();
    }

    onStatusChange(val) {
        this.status = val;
    }

    managePagination(page) {
        this.page = page;
        this.totalItems = 0;
        this.getInquiryList();
    }

    exportList() {
        var options = { 
            fieldSeparator: ',',
            quoteStrings: '"',
            decimalseparator: '.',
            showLabels: true,
            showTitle: true,
            title: 'Inquiry List :',
            useBom: true,
            noDownload: false,
            headers: ['S.No.','Subject','Message','Name','Email','Phone','Request Date','Status','Operator']
        };

        let data = [];

        this.inquiryList.forEach((element,index) => {
            let obj = {
                's.no' : index+1,
                'subject': element.subject || '---',
                'message': element.message || '---',
                'name': element.name  || '---',
                'email': element.email || '---',
                'date': new Date(element.createdAt),
                'phone': element.phone || '---',
                'status': element.status || '---',
                'operator': element.operator || '---',
            };
            data.push(obj);
        });
        new AngularCsv(data, 'Inquiry List', options);
    }

    pagination(page) {
        this.page = page;
    }
    resetData() {
        this.inquiryList = [];
        this.page = 1;
        this.totalItems = 0;
        this.obj.fromDate = '';
        this.obj.toDate = '';
        this.obj.search_key = '';
        this.status = '';
        this.getInquiryList();
    }

}
