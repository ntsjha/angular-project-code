import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TermsAndContentComponent } from './terms-and-content.component';

describe('TermsAndContentComponent', () => {
  let component: TermsAndContentComponent;
  let fixture: ComponentFixture<TermsAndContentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TermsAndContentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TermsAndContentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
