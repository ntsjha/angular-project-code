import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageApprovalsComponent } from './manage-approvals.component';
import { MarketingSidebarComponent } from '../sidebar/sidebar.component';
import { SharedModuleModule } from 'src/app/shared-module/shared-module.module';
import { RouterModule } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { DeviceDetectorService } from 'ngx-device-detector';
import { AppComponent } from 'src/app/app.component';

describe('ManageApprovalsComponent', () => {
  let component: ManageApprovalsComponent;
  let fixture: ComponentFixture<ManageApprovalsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManageApprovalsComponent, MarketingSidebarComponent,  ],
      imports: [SharedModuleModule, RouterModule,
        RouterTestingModule,],
        providers: [AppComponent, DeviceDetectorService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageApprovalsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
