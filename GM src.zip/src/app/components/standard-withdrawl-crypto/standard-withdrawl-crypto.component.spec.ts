import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StandardWithdrawlCryptoComponent } from './standard-withdrawl-crypto.component';

describe('StandardWithdrawlCryptoComponent', () => {
  let component: StandardWithdrawlCryptoComponent;
  let fixture: ComponentFixture<StandardWithdrawlCryptoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StandardWithdrawlCryptoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StandardWithdrawlCryptoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
