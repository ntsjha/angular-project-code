import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-manage-fee',
  templateUrl: './manage-fee.component.html',
  styleUrls: ['./manage-fee.component.css']
})
export class ManageFeeComponent implements OnInit {

  constructor(
    private route: Router
  ) { }

  ngOnInit() {
    window.scrollTo(0, 0);
  }

  goToMinTrading() {
  this.route.navigate(['/minimum-trading']);
  }

  goToStandradTrading() {
    this.route.navigate(['/standard-trading']);
  }
  goToMinWithdrawl() {
    this.route.navigate(['/minimum-withdrawl']);
  }
  goToStdWithdrawl() {
    this.route.navigate(['/standard-withdrawl']);
  }
  goToMinDeposit() {
    this.route.navigate(['/minimum-deposit']);
  }
  goToStdDeposit() {
    this.route.navigate(['/standard-deposit']);
  }

}
