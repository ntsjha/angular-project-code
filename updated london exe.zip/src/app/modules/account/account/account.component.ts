import { Component, OnInit } from '@angular/core';
import { ServerService } from '../../../service/server.service';
import { AppComponent } from '../../../app.component';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { HeaderComponent } from '../../header/header/header.component';
import { Observable } from '../../../../../node_modules/rxjs/Observable';
declare var $: any;

@Component({
    selector: 'app-account',
    templateUrl: './account.component.html',
    styleUrls: ['./account.component.css']
})
export class AccountComponent implements OnInit {
    currTab = "deposit";
    depBank = "EUR";
    withBank = "EUR";
    bankObj = {euroBal:"", gbpBal:"", usdBal:""};
    accObj = {iban:"", bic_swift_code:"", bank_name:"", bank_address:"", recipient_name:"", recipient_address:"", user_ref_no:""};
    withdrawObj = {iban:"", bic_swift_code:"", bank_name:"", bank_address:"", recipient_name:"", recipient_address:"", amount:""};
    numRegexForDot = (/(?: |^)\d*\.?\d+(?: |$)/);
    securityType: any;
    otp = { one: "", two: "", three: "", four: "",five:"",six:"" };
    time: number;
    seconds: number = 59;
    qrCode = {Code1:""};
    code: string;
    depositAmount: any;

    constructor(private server: ServerService, private appC: AppComponent, private spinnerService: Ng4LoadingSpinnerService, public header:HeaderComponent) { }

    ngOnInit() {
        this.currTab = "deposit";
        this.depBank = "EUR";
        this.withBank = "EUR";
        this.getAccountDetails();
        this.getFiatBalance();
        this.getProfile();
    }

    getProfile() {
        this.server.getApi("account/my-account",localStorage.getItem('token')).subscribe((succ) => {     
        if(succ.body.data.twoFaType=='GOOGLE') {
                this.securityType = "GOOGLE";
            } else if(succ.body.data.twoFaType=='SMS') {
                this.securityType = "SMS";
            }
        }, (err) => {
            //this.spinnerService.hide();
        });
    }

    /** Function to get account details of admin */
    getAccountDetails() {
        let data = {
            "eventExternal" : {
                "name" : "get_admin_account_detail",
                "key" : "mykey"
            },
            "transferObjectMap" : {
                "gatewayrequest": {
                    "loginToken": localStorage.getItem("token"),
                    "paymentType": "LCX"
                }
            }
        }
        this.server.post('',data).subscribe((succ) => {
            if(succ.transferObjectMap.statusCode == 200) {
                if(succ.transferObjectMap.result.length) {
                    this.accObj.bank_address = succ.transferObjectMap.result[0].bankAddress;
                    this.accObj.bank_name = succ.transferObjectMap.result[0].bankName;
                    this.accObj.bic_swift_code = succ.transferObjectMap.result[0].swiftCode;
                    this.accObj.iban = succ.transferObjectMap.result[0].international_bank_acc_no;
                    this.accObj.recipient_address = succ.transferObjectMap.result[0].recipientAddress;
                    this.accObj.recipient_name = succ.transferObjectMap.result[0].recipientName;
                    this.accObj.user_ref_no = succ.transferObjectMap.uniqueReferrenceNumber;
                }
            }
        }, (err) => {
        });
    }

    /** Function to get fiat balance */
    getFiatBalance() {
        let data = {
            "eventExternal" : {
                "name" : "request_get_coin_list",
                "key" : "mykey"
            },
            "transferObjectMap" : {
                "loginToken": localStorage.getItem("token")
            }
        }
        this.spinnerService.show();
        this.server.post('',data).subscribe((succ) => {
            this.spinnerService.hide();
            if(succ.transferObjectMap.statusCode == 200) {
                let fiatArr = succ.transferObjectMap.coinList.filter((x) => x.coinType == "fiat");
                if(fiatArr.length) {
                    this.bankObj.euroBal = fiatArr.filter((x) => x.coinShortName == "EUR")[0].balance;
                    this.bankObj.gbpBal = fiatArr.filter((x) => x.coinShortName == "GBP")[0].balance;
                    this.bankObj.usdBal = fiatArr.filter((x) => x.coinShortName == "USD")[0].balance;
                }
            }
        }, (err) => {
            this.spinnerService.hide();
        });
    }

    /** Function for tab click */
    tabClick(type) {
        this.currTab = type;
        this.depBank = "EUR";
        this.withBank = "EUR";
    }

    /** Function for bank list click of deposit */
    depBankClick(type) {
        this.depBank = type;
    }

    /** Function for bank list click of withdraw */
    withBankClick(type) {
        this.withBank = type;
    }

    /** Function for copy data */
    copyData(data) {
        this.appC.showInfoToast("Text has been copied to clipboard.");
        let selBox = document.createElement('textarea');
        selBox.style.position = 'fixed';
        selBox.style.left = '0';
        selBox.style.top = '0';
        selBox.style.opacity = '0';
        selBox.value = data;
        document.body.appendChild(selBox);
        selBox.focus();
        selBox.select();
        document.execCommand('copy');
        document.body.removeChild(selBox);
    }

    /** Function to clear withdraw obj */
    clearWithdrawObj() {
        this.withdrawObj.amount = "";
        this.withdrawObj.bank_address = "";
        this.withdrawObj.bank_name = "";
        this.withdrawObj.bic_swift_code = "";
        this.withdrawObj.iban = "";
        this.withdrawObj.recipient_address = "";
        this.withdrawObj.recipient_name = "";
    }

    /** Function for withdraw submit */
    withdrawFunc() {
        //console.log("obj -> "+JSON.stringify(this.withdrawObj));
        if(this.withdrawObj.iban.trim().length == 0) {
            this.appC.showErrToast("Please enter iban number.");
            return;
        } else if(this.withdrawObj.bic_swift_code.trim().length == 0) {
            this.appC.showErrToast("Please enter bic/swift code.");
            return;
        } else if(this.withdrawObj.bank_name.trim().length == 0) {
            this.appC.showErrToast("Please enter bank name.");
            return;
        } else if(this.withdrawObj.bank_address.trim().length == 0) {
            this.appC.showErrToast("Please enter bank address.");
            return;
        } else if(this.withdrawObj.recipient_name.trim().length == 0) {
            this.appC.showErrToast("Please enter recipient name.");
            return;
        } else if(this.withdrawObj.recipient_address.trim().length == 0) {
            this.appC.showErrToast("Please enter recipient address.");
            return;
        } else if(this.withdrawObj.amount.trim().length == 0) {
            this.appC.showErrToast("Please enter amount.");
            return;
        } else if(Number(this.withdrawObj.amount) == 0) {
            this.appC.showErrToast("Please enter valid amount.");
            return;
        } else if(!this.numRegexForDot.test(this.withdrawObj.amount)) {
            this.appC.showErrToast("Please enter valid amount.");
            return;
        } else if(this.withBank == "EUR"){
            if(this.withdrawObj.amount > this.bankObj.euroBal) {
                this.appC.showErrToast("Sorry, you don't have enough amount to withdraw.");
                return;
            } else {
                this.submitWithdraw();
            }
        } 
        else if(this.withBank == "GBP"){
            if(this.withdrawObj.amount > this.bankObj.gbpBal) {
                this.appC.showErrToast("Sorry, you don't have enough amount to withdraw.");
                return;
            } else {
                this.submitWithdraw();
            }
        } 
        else if(this.withBank == "USD"){
            if(this.withdrawObj.amount > this.bankObj.usdBal) {
                this.appC.showErrToast("Sorry, you don't have enough amount to withdraw.");
                return;
            } else {
                this.submitWithdraw();
            }
        }
    }

    /** Function for submit withdraw request */
    submitWithdraw() {
        if(this.securityType == 'SMS') {

            $("#otp").modal({ backdrop: 'static', keyboard: false });
            this.server.getApi('auth/send-sms-code',localStorage.getItem('token')).subscribe((res)=> {

             this.spinnerService.hide();
             this.myTimer();
          
            })
        } else if(this.securityType == "GOOGLE") {
            this.qrCode = { Code1: ""};
            $('#googleAuth').modal({backdrop: 'static',keyboard: false});
        }
        let data = {
            "eventExternal": {
                "name":"save_withdraw",
                "key":"mykey"
            },
           "transferObjectMap": {
               "gatewayrequest": {
                    "loginToken": localStorage.getItem('token'),
                    "paymentType": "LCX",
                    "templateId": null,
                    "bankAccountNumber": this.withdrawObj.iban,
                    "swiftCode": this.withdrawObj.bic_swift_code,
                    "accountHolderAddress": this.withdrawObj.recipient_address,
                    "accountHolderName": this.withdrawObj.recipient_name,
                    "bankName": this.withdrawObj.bank_name,
                    "bankAddress": this.withdrawObj.bank_address,
                    "withdrawAmount": this.withdrawObj.amount,
                    "currency": this.withBank
                }
            }
        }
        // this.spinnerService.show();
        // this.server.post('',data).subscribe((succ) => {
        //     this.spinnerService.hide();
        //     if(succ.transferObjectMap.statusCode == 200) {
        //         this.appC.showSuccToast(succ.transferObjectMap.message);
        //         this.getFiatBalance();
        //         this.clearWithdrawObj();
        //     } else if(succ.transferObjectMap.statusCode == 403) {
        //         this.header.tokenExpire();
        //     } else {
        //         this.appC.showErrToast(succ.transferObjectMap.message);
        //     }
        // }, (err) => {
        //     this.spinnerService.hide();
        //     this.appC.showErrToast("Something went wrong.");
        // });
    }

    otpSend() {
        // let data =   {
        //     "eventExternal": {
        //         "name":"request_sms_auth",
        //         "key":"mykey"
        //     },
        //     "transferObjectMap": {
        //         "gatewayrequest": {
        //             "phoneCountryCode":'',
        //             "phone":'',
        //             "token": localStorage.getItem("token")
        //         }
        //     }
        // }    
        // this.spinnerService.show();
        // this.server.postApi('', data,0).subscribe(response => {
        //     this.spinnerService.hide();
        //     if (response.transferObjectMap.statusCode == 200) {
        //         this.appC.showSuccToast(response.transferObjectMap.message);
        //         this.otp = { one: "", two: "", three: "", four: "" };
        //         this.seconds = 59;
        //         $('#otp').modal({backdrop: 'static',keyboard: false});
        //         this.myTimer();                
        //     } else {
        //         this.appC.showErrToast(response.transferObjectMap.message);
                
        //     }
        // }, error => {
        //     this.spinnerService.hide();
        //     this.appC.showErrToast('Something went wrong');
        // });
    }

    myTimer() {
        Observable.interval(1000)
        .takeWhile(() => this.seconds > 0 || (this.seconds != 60 && this.seconds > 0))
        .subscribe(i => { 
            --this.seconds;
        })
        if(this.seconds==0) {
            clearInterval(this.seconds);
        }
    }
    
    
    resendOtp() {
        this.seconds= 59;
        this.resend();
    }

    resend() {
       
        this.myTimer();
        this.spinnerService.show();
        this.server.getApi('auth/send-sms-code',localStorage.getItem('token')).subscribe(response => {
            this.spinnerService.hide();
            if (response.body.status == 200) {
                
                
               this.otp = { one: "", two: "", three: "", four: "" ,five: "", six: ""};
                
            } else {
                this.otp = { one: "", two: "", three: "", four: "" ,five: "", six: ""};
       
                this.appC.showErrToast(response.body.message);                
            }
        }, error => {
            this.spinnerService.hide();
            this.appC.showErrToast('Something went wrong');
        });
    }

    smsVerify() {
        // this.code =  this.otp.one + this.otp.two + this.otp.three + this.otp.four ;
        // //console.log(this.code) ;
        // let data = {
        //     "eventExternal": {
        //         "name":"request_sms_verify",
        //         "key":"mykey"
        //     },
        //     "transferObjectMap": {
        //         "gatewayrequest": {
        //             "code": this.code,
        //             "token": localStorage.getItem("token"),
        //             "clientTime":  new Date().getTime()
        //         }
        //     }
        // }
        // this.spinnerService.show();
        // this.server.postApi('', data,0).subscribe(response => {
        //     this.spinnerService.hide();
        //     if (response.transferObjectMap.statusCode == 200) {
        //         this.appC.showSuccToast(response.transferObjectMap.message);
        //         this.requestWithdraw();
        //         $('#otp').modal('hide');
        //     } else {
        //         this.otp = { one: "", two: "", three: "", four: "" };   
        //         this.appC.showErrToast("Please enter correct OTP ");
        //     }
        // }, error => {
        //     this.spinnerService.hide();
        //     this.appC.showErrToast('Something went wrong');
        // });    

        this.code =  this.otp.one + this.otp.two + this.otp.three + this.otp.four + this.otp.five  + this.otp.six ;
        let data = {
                    "code":this.code,
                 }
        this.spinnerService.show();
        this.server.postApi('auth/verify-sms', data,localStorage.getItem('token')).subscribe(response => {
            this.spinnerService.hide();
            if (response.body.status == 200) {
                this.appC.showSuccToast(response.body.message);
                // localStorage.setItem('token',response.body.data);
                this.requestWithdraw();
                $('#otp').modal('hide');
             
            } else {
                this.otp = { one: "", two: "", three: "", four: "",five:"",six:"" };   
                this.appC.showErrToast("Please enter correct OTP.");
            }
        }, error => {
            this.spinnerService.hide();
            this.appC.showErrToast('Something went wrong');
        });    
    }

    qrVerify() {
        // let data = {
        //     "eventExternal": {
        //         "name":"request_google_verify",
        //         "key":"mykey"
        //     },
        //     "transferObjectMap": {   
        //         "gatewayrequest": {
        //             "otp": this.qrCode.Code1,
        //             "secretKey":localStorage.getItem('key'),
        //             "token": localStorage.getItem("token"),
        //             "clientTime":  new Date().getTime()
        //         }
        //     }
        // }
        // this.spinnerService.show();
        // this.server.postApi('', data,0).subscribe(response => {
        //     this.spinnerService.hide();
        //     if (response.transferObjectMap.statusCode == 200) {
        //         this.appC.showSuccToast(response.transferObjectMap.message);
        //         this.requestWithdraw();
        //         $('#googleAuth').modal('hide');
        //     } else {
        //         this.qrCode = {Code1:""} 
        //         this.appC.showErrToast(response.transferObjectMap.message);
        //     }
        // }, error => {
        //     this.spinnerService.hide();
        //     this.appC.showErrToast('Something went wrong');
        // });
        let data = {
            "otp": this.qrCode.Code1,
        }
  
this.spinnerService.show();
this.server.postApi('auth/verify-google', data,localStorage.getItem('token')).subscribe(response => {
    this.spinnerService.hide();
    if (response.body.status == 200) {
        this.appC.showSuccToast("Qr Code verified successfully");
        // localStorage.setItem('token',response.body.data);
        this.requestWithdraw();
        $('#googleAuth').modal('hide');
      
    } else {
        this.qrCode = {Code1:""} 
        this.appC.showErrToast(response.body.message);
    }
}, error => {
    this.spinnerService.hide();
    this.appC.showErrToast('Something went wrong');
});
    }

    requestWithdraw() {
        let data = {
            "eventExternal": {
                "name":"save_withdraw",
                "key":"mykey"
            },
           "transferObjectMap": {
               "gatewayrequest": {
                    "loginToken": localStorage.getItem('token'),
                    "paymentType": "LCX",
                    "templateId": null,
                    "bankAccountNumber": this.withdrawObj.iban,
                    "swiftCode": this.withdrawObj.bic_swift_code,
                    "accountHolderAddress": this.withdrawObj.recipient_address,
                    "accountHolderName": this.withdrawObj.recipient_name,
                    "bankName": this.withdrawObj.bank_name,
                    "bankAddress": this.withdrawObj.bank_address,
                    "withdrawAmount": this.withdrawObj.amount,
                    "currency": this.withBank
                }
            }
        }
        this.spinnerService.show();
        this.server.post('',data).subscribe((succ) => {
            this.spinnerService.hide();
            if(succ.transferObjectMap.statusCode == 200) {
                this.appC.showSuccToast(succ.transferObjectMap.message);
                this.getFiatBalance();
                this.clearWithdrawObj();
            } else if(succ.transferObjectMap.statusCode == 403) {
                this.header.tokenExpire();
            } else {
                this.appC.showErrToast(succ.transferObjectMap.message);
            }
        }, (err) => {
            this.spinnerService.hide();
            this.appC.showErrToast("Something went wrong.");
        });
    }

    /** Auto focus functionality */
    onKey(value, type) {
        if (type == 1) {
            if (value != "") {
                $('#otp2').focus();
            }
        } else if (type == 2) {
            if (value != "") {
                $('#otp3').focus();
            }
        } else if (type == 3) {
            if (value != "") {
                $('#otp4').focus();
            }
        } else if (type == 4) {
            if (value != "") {
                $('#otp5').focus();
            }
            
        } 
        else if (type == 5) {
            if (value != "") {
                $('#otp6').focus();
            }
            
        } 
        else if (type == 6) {
            if (value != "") {
                $('#otp6').focus();
            }
            
        } 
    }

    /** Function for I have paid */
    ihavePaidFunc() {
        this.depositAmount = "";
        $('#depositAmountModal').modal({backdrop: 'static',keyboard: false});
    }

    paid() {
        if(Number(this.depositAmount) == 0) {
            this.appC.showErrToast("Please enter valid amount.");
            this.depositAmount = "";
            return;
        } else if(!this.numRegexForDot.test(this.depositAmount)) {
            this.appC.showErrToast("Please enter valid amount.");
            this.depositAmount = "";
            return;
        } else {
            let data = {
                "eventExternal": {
                    "name": "payment_callback",
                    "key": ""
                },
                "transferObjectMap": {
                    "gatewayrequest": {
                        "token": localStorage.getItem('token'),
                        "currency": this.depBank,
                        "code": "200",
                        "message": "success",
                        "amount": this.depositAmount          
                    }
                }
            }
            this.spinnerService.show();
            this.server.post('',data).subscribe((succ) => {
                this.spinnerService.hide();
                if(succ.transferObjectMap.statusCode == 200) {
                    this.appC.showSuccToast("Request submitted successfully. Admin will take action on your request shortly.");
                    $('#depositAmountModal').modal('hide');
                } else if(succ.transferObjectMap.statusCode == 403) {
                    this.header.tokenExpire();
                } else {
                    this.appC.showErrToast(succ.transferObjectMap.message);
                }
            }, (err) => {
                this.spinnerService.hide();
                this.appC.showErrToast("Something went wrong.");
            });
        }
    }
}
