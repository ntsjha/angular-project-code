import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddNewReqComponent } from './add-new-req.component';

describe('AddNewReqComponent', () => {
  let component: AddNewReqComponent;
  let fixture: ComponentFixture<AddNewReqComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddNewReqComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddNewReqComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
