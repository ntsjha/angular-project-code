import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payment-screen',
  templateUrl: './payment-screen.component.html',
  styleUrls: ['./payment-screen.component.css']
})
export class PaymentScreenComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
