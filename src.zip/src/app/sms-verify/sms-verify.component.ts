import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sms-verify',
  templateUrl: './sms-verify.component.html',
  styleUrls: ['./sms-verify.component.css']
})
export class SmsVerifyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
