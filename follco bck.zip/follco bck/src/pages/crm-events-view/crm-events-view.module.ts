import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CrmEventsViewPage } from './crm-events-view';

@NgModule({
  declarations: [
    CrmEventsViewPage,
  ],
  imports: [
    IonicPageModule.forChild(CrmEventsViewPage),
  ],
})
export class CrmEventsViewPageModule {}
