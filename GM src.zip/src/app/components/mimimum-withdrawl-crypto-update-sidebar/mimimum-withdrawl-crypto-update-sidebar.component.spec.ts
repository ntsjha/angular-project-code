import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MimimumWithdrawlCryptoUpdateSidebarComponent } from './mimimum-withdrawl-crypto-update-sidebar.component';

describe('MimimumWithdrawlCryptoUpdateSidebarComponent', () => {
  let component: MimimumWithdrawlCryptoUpdateSidebarComponent;
  let fixture: ComponentFixture<MimimumWithdrawlCryptoUpdateSidebarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MimimumWithdrawlCryptoUpdateSidebarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MimimumWithdrawlCryptoUpdateSidebarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
