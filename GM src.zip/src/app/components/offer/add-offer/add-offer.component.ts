import { Router } from '@angular/router';
import { ServiceService } from 'src/app/service/service.service';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { IMyDpOptions } from 'mydatepicker';
import { NgxSpinnerService } from 'ngx-spinner';
import { AppComponent } from 'src/app/app.component';
import { CookieService } from 'ngx-cookie-service';

declare var $: any;

@Component({
  selector: 'app-add-offer',
  templateUrl: './add-offer.component.html',
  styleUrls: ['./add-offer.component.css']
})
export class AddOfferComponent implements OnInit, OnDestroy {

  addofferForm: FormGroup;
  apiResponse: any = { status: 1366 };
  fileData: any = {};
  fileName: any;
  startDateMax: any = null;
  todayEndDate: any = new Date();
  todayDate: any = new Date();
  public fromPickerOptions: IMyDpOptions = {
    disableUntil: { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() - 1 },
    dateFormat: 'dd/mm/yyyy',
  };
  englishShortCode: any;
  public toPickerOptions: IMyDpOptions = {
    disableUntil: { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() - 1 },
    dateFormat: 'dd/mm/yyyy',
  };
  fileUrl: any = null;
  invalidfileUrl: any = true;
  paramData: any;
  subscription: any;
  userIp: any;

  constructor(
    private service: ServiceService,
    private fb: FormBuilder,
    private spinner: NgxSpinnerService,
    private router: Router,
    private appC: AppComponent,
    private cookie: CookieService
  ) {
    this.subscription = this.service.authVerify.subscribe(val => {
      if (val === 'add-offer') {
        this.addOffer();
        this.service.authVerify.next('false');
      }
    });
  }

  ngOnInit() {
    this.form();
    window.scrollTo(0, 0);
    this.userIp = (this.cookie.get('userInfo')) ? JSON.parse(this.cookie.get('userInfo')) : this.service.initialUserInfo;
    
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  form() {
    this.addofferForm = this.fb.group({
      offerType: ['', [Validators.required]],
      offerName: ['', [Validators.required, Validators.pattern(/^[a-zA-Z0-9][a-zA-Z0-9 ]*$/), Validators.minLength(2), Validators.maxLength(255)]],
      offerStartDate: ['', [Validators.required]],
      offerEndDate: ['', [Validators.required]],
      thbperPoint: [null, [Validators.pattern(/^[0-9]*$/), Validators.minLength(1), Validators.maxLength(255)]],
      maxPoint: [null, [Validators.pattern(/^[0-9]*$/), Validators.minLength(1), Validators.maxLength(255)]],
      totalRedeem: [null, [Validators.pattern(/^[0-9]*$/), Validators.minLength(1), Validators.maxLength(255)]],
      numberOfPoints: [null, [Validators.pattern(/^[0-9]*$/), Validators.minLength(1), Validators.maxLength(255)]],

    });
  }

  fromDateChanged(event) {
    if (event.epoc) {
      this.toPickerOptions = {
        disableUntil: { year: new Date(event.epoc * 1000).getFullYear(), month: new Date(event.epoc * 1000).getMonth() + 1, day: new Date(event.epoc * 1000).getDate() - 1 }
      };
    } else {
      this.toPickerOptions = {
        disableUntil: { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() - 1 }
      };
    }
  }

  toDateChanged(event) {
    if (event.epoc) {
      this.fromPickerOptions = {
        disableSince: { year: new Date(event.epoc * 1000).getFullYear(), month: new Date(event.epoc * 1000).getMonth() + 1, day: new Date(event.epoc * 1000).getDate() + 1 }
      };
    } else {
      this.fromPickerOptions = {
        disableSince: { year: 0, month: 0, day: 0 },
      };
    }
  }

  startDateChange() {
    if (this.addofferForm.value.offerStartDate) {
      this.todayEndDate = new Date(this.addofferForm.value.offerStartDate);
    } else {
      this.todayEndDate = new Date();
    }
  }

  endDateChange() {
    if (this.addofferForm.value.offerEndDate) {
      this.startDateMax = new Date(this.addofferForm.value.offerEndDate);
    } else {
      this.startDateMax = null;
    }
  }


  /** Function to verify google authentication */
  verifyGoogleAuth() {
    if ((this.addofferForm.value.thbperPoint !== null && this.addofferForm.value.maxPoint !== null) || (this.addofferForm.value.totalRedeem !== null && this.addofferForm.value.numberOfPoints !== null)) {
      this.appC.google = { one: '', two: '', three: '', four: '', five: '', six: '' };
      this.appC.response = { message: '' };
      this.service.googleAuthCalledFrom = 'add-offer';
      $('#google-auth-modal').modal({ keyboard: false, backdrop: 'static' });
    }
  }

  resetFormValue() {
    this.addofferForm.patchValue({
      thbperPoint: null,
      maxPoint: null,
      totalRedeem: null,
      numberOfPoints: null,
    });
  }

  addOffer() {
    this.spinner.show();
    if (this.addofferForm.invalid) {
      this.spinner.hide();
      return;
    }
    if (this.invalidfileUrl) {
      this.spinner.hide();
      return;
    }
    const apireq = {
      languageName: 'en',
      offerType: this.addofferForm.value.offerType,
      offerName: this.addofferForm.value.offerName,
      offerImage: this.fileUrl,
      thbPerPointValue: this.addofferForm.value.thbperPoint,
      maxPoint: this.addofferForm.value.maxPoint,
      maxNumberOfCouponRedeemable: this.addofferForm.value.totalRedeem,
      pointValue: this.addofferForm.value.numberOfPoints,
      offerStartdate: this.addofferForm.value.offerStartDate ? new Date(this.addofferForm.value.offerStartDate).getTime() : null,
      offerEndDate: this.addofferForm.value.offerEndDate ? new Date(this.addofferForm.value.offerEndDate).getTime() : null,
      ipAddress: this.userIp.ip,
      location: this.userIp.city + ',' + this.userIp.country_name,

    };
    this.service.postMethod('rewards/marketing/save-offer', apireq, 1).subscribe(success => {
      this.spinner.hide();
      this.apiResponse = success;
      if (success.status === 1366 || success.status === 1452)  {
        this.router.navigate(['/offer-management']);
      }
    }, error => {
      if (error) {
        this.spinner.hide();
        if (error.error) {
          this.apiResponse.status = error.error.status;
          this.apiResponse.message = error.error.error;
        } else {
          this.apiResponse.status = 500;
          this.apiResponse.message = 'Something went wrong';
        }
      } else {
        this.apiResponse.status = 500;
        this.apiResponse.message = 'Something went wrong';
      }
    });
  }

  getFile(event) {
    this.fileData = this.service.uploadImage(event);
    this.fileName = this.fileData.fileData.name;
    if (this.fileData.error === 'formatError') {
      this.fileData.error = 'Image accept only jpg, jpeg, png format.';
    } else {
      if (this.fileData.error === 'sizeError') {
        this.fileData.error = 'Image size should be less than 5Mb.';
      }
    }
    if (!this.fileData.valid) {
      return;
    }
    this.uploadImage();
  }

  uploadImage() {
    const formData = new FormData();
    formData.append('file', this.fileData.fileData);
    this.service.postMethod('account/uploadFile', formData, 2).subscribe(success => {
      if (success.fileName) {
        this.fileUrl = success.fileName;
        this.invalidfileUrl = false;
      } else {
        this.invalidfileUrl = true;
      }
    }, error => {
      this.invalidfileUrl = true;
    });
  }

}
