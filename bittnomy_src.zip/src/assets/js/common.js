$(document).ready(function() {

    /*$('.dot-top .head-drop-down').click(function() {
        $('body').toggleClass('nightmode');
    });*/


    /* Toggle Header User info Drop Down */

    /*********header-bg-clolor*********/
    $(window).scroll(function() {
        var scroll = $(window).scrollTop();
        var bannerheight = $('.masthead').height();

        if (scroll >= bannerheight) {
            //clearHeader, not clearheader - caps H
            $(".mainNav").addClass("darkHeader");
        } else {
            $(".mainNav").removeClass("darkHeader");
        }
    }); //missing );

});



function headerbg() {
    var scroll = $(window).scrollTop();
    if (scroll >= 100) {
        $("header").addClass("header-bg");
    } else {
        $("header").removeClass("header-bg");
    }
}

$(window).scroll(function() {
    headerbg();
});


$("#menuShow").on('click', function(e) {
    $('#menubox').toggleClass('menu-slide');
});
$("#menuClose").on('click', function(e) {
    $('#menubox').toggleClass('menu-slide');
});

/*
$(window).resize(function(){*/
/*if($(window).width()<=1024){
		$(".top-dropdown .dropdown-toggle").removeAttr("data-toggle");
	} else {
		$(".top-dropdown .dropdown-toggle").attr("data-toggle", "dropdown");
	}
});

if($(window).width()<=1024){
	$(".top-dropdown .dropdown-toggle").removeAttr("data-toggle");
} 
else {
	$(".top-dropdown .dropdown-toggle").attr("data-toggle", "dropdown");
}*/

/*$("#showUser").on('click', function(e){
    $('.chat-user-box').toggle();
    $(this).children('i.fas').toggleClass('fa-users fa-times')
});

$("#showSearch").on('click', function(e){
    $('.header-search').toggle();
});

$(".security-input").keyup(function () {
    console.log(this.value.length);
    if (this.value.length == this.maxLength) {
      $(this).next('.security-input').focus();
    } else{
      $(this).prev('.security-input').focus();
    }
});*/

/*$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();   
});*/

$(document).ready(function() {
    /* Toggle Header User info Drop Down */
    $(document).on("click", ".user_top_box ", function() {
        $(".user_top_box .dropdown-menu").toggleClass("show");
    });

    $(document).click(function(e) {
        if (!$(e.target).is(".head-drop-down, .head-drop-down *, .user_top_box, .user_top_box *")) {
            $(".user_top_box .dropdown-menu").removeClass('show');
        }
    });
});