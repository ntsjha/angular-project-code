import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WithdrawverifyComponent } from './withdrawverify.component';

describe('WithdrawverifyComponent', () => {
  let component: WithdrawverifyComponent;
  let fixture: ComponentFixture<WithdrawverifyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WithdrawverifyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WithdrawverifyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
