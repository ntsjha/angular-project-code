import { Component, OnInit } from '@angular/core';
import { AppComponent } from '../../../app.component';
import { ServerService } from '../../../service/server.service';
import { Ng4LoadingSpinnerService } from '../../../../../node_modules/ng4-loading-spinner';
import { HeaderComponent } from '../../header/header/header.component';
import { Angular5Csv } from 'angular5-csv/Angular5-csv';
import { DatePipe } from '@angular/common';
import { Router } from '@angular/router';

@Component({
    selector: 'app-transaction-detail',
    templateUrl: './transaction-detail.component.html',
    styleUrls: ['./transaction-detail.component.css']
})
export class TransactionDetailComponent implements OnInit {
    tab: any = 'deposit';
    coinName: any = 'BTC'
    depositArr: any = [];
    withdrawArr: any = [];
    p: any = 1;
    page: any = 1;
    coinListArr: any = [];

    constructor(public router:Router,private appC: AppComponent, private server: ServerService, private spinnerService: Ng4LoadingSpinnerService, public header: HeaderComponent, public datepipe: DatePipe) { }

    ngOnInit() {
        window.scrollTo(0, 0);
        this.getCoinListWithBalance();
        // this.server.initSocket();
    }

    /** Function to get coin list with their balance */
    getCoinListWithBalance() {
        let url = window.location.href.split('/');
        this.page = url[url.length - 1];
        this.coinListArr = [];
        // let data = {
        //     "eventExternal" : {
        //         "name" : "request_get_coin_list",
        //         "key" : "mykey"
        //     },
        //     "transferObjectMap" : {
        //         //"loginToken": localStorage.getItem("token")
        //     }
        // }
        let data = {
            "coinName": this.coinName
        }
        console.log('coinListArr>>>>>',this.coinListArr)
        this.spinnerService.show();
        this.server.getApi("wallet/coin/get-coin-list?coinName="+data.coinName,localStorage.getItem('token')).subscribe((succ) => {     
            this.spinnerService.hide(); 
            console.log('>>>>>>>>>>>>coinlist',succ)          
            if(succ.status == 200) {
                
                succ.body.data.forEach(element => {
                    if(element.coinShortName == 'BTC'|| element.coinShortName == 'ETH'|| element.coinShortName == 'XRP'|| element.coinShortName == 'BCH'|| element.coinShortName == 'XLM'|| element.coinShortName == 'LTC'|| element.coinShortName == 'IOTA' || element.coinShortName == 'USDT' || element.coinShortName == 'ECH' || element.coinShortName == 'XVG' || element.coinShortName == 'IPR') {
                        this.coinListArr.push(element);
                    } 
                });
                this.coinName = this.page;
                this.searchDetails();
            } else if(succ.status == 403){
                this.header.tokenExpire();
            } else {
                this.appC.showErrToast(succ.body.message);
            }
        }, (err) => {
            this.spinnerService.hide();
        });
    }

    activeTab(val) {
        this.tab = val;
        this.searchDetails();
    }

    searchDetails() {
        if (this.tab == 'deposit') {
            // let data = {
            //     "eventExternal": {
            //         "name":"request_deposits",
            //         "key":"mykey"                    
            //     },   
            //     "transferObjectMap": { 
            //         "gatewayrequest": { 
            //             "coinType":this.coinType,
            //             "token":localStorage.getItem('token')
            //         }
            //     }
            // }

            let data = {
                "coinName": this.coinName

            }
            console.log(data);
           this.router.navigateByUrl('header/transactionDetail/'+this.coinName)
            //this.spinnerService.show();
            this.server.getApi('wallet/wallet/get-deposits?coinName='+data.coinName,localStorage.getItem('token')).subscribe(response => {
                this.spinnerService.hide();
                if (response.status == 200) {
                    // this.appC.showSuccToast('Deposit History Fetched Successfully');
                    console.log('deposit data--->',response.body.data)
                   this.depositArr = response.body.data;
                } else if(response.status == 403){ 
                    this.header.tokenExpire()
                } else {
                    this.appC.showErrToast(response.body.message);                     
                }
            }, error => {
                this.spinnerService.hide();
                this.appC.showErrToast(error.error.message);
            });
        } else {
            // let data = {
            //     "eventExternal": {
            //         "name": "withdrawlist_history",
            //         "key": "mykey"
            //     },
            //     "transferObjectMap": {
            //         "gatewayrequest": {
            //             "coinType": this.coinType,
            //             "token": localStorage.getItem("token")
            //         }
            //     }
            // }

            let data = {
                "coinName": this.coinName

           }
           this.router.navigateByUrl('header/transactionDetail/'+this.coinName)
           console.log('COINTYPE>>>>>>>>>>>>>>>',this. coinName);
           this.spinnerService.show();
           this.server.getApi('wallet/wallet/get-withdrawlist?coinName='+data.coinName,localStorage.getItem('token')).subscribe(response => {
               this.spinnerService.hide();
               if (response.status == 200) {
                   this.appC.showSuccToast(response.message);
                   this.withdrawArr = response.body.data;
               } else if(response.status == 403){
                   this.appC.showErrToast(response.body.message); 
                   this.header.tokenExpire()
               } else {
                   this.appC.showErrToast(response.body.message);                     
               }
            }, error => {
                this.spinnerService.hide();
                this.appC.showErrToast(error.error.message);
            });

        }
    }

    pageChange1(val) {
        this.page = val;
        this.searchDetails();
    }

    changePage(val) {
        this.p = val;
        this.searchDetails();
    }

    exportData() {
        if (this.tab == 'deposit') {
            let data = [];
            data.push({
                TransactionID: "Transaction Id",
                Coin: "Coin Symbol",
                Units: "Units",
                Status: "Status",
                Date: "Date & Time"
            });
            this.depositArr.forEach((obj) => {
                data.push({
                    TransactionID: obj.txnId,
                    Coin: obj.coinType,
                    Units: obj.units,
                    Status: obj.status,
                    Date: this.convertFormat(obj.txnTime),

                });
            });
            new Angular5Csv(data, 'Bittnomy Deposit History Report');

        } else {
            let data = [];
            data.push({
                TransactionID: "Transaction Id",
                Coin: "Coin Symbol",
                Units: "Units",
                Status: "Status",
                Date: "Date & Time"
            });
            this.withdrawArr.forEach((obj) => {
                data.push({
                    TransactionID: obj.txnId,
                    Coin: obj.coinType,
                    Units: obj.units,
                    Status: obj.status,
                    Date: this.convertFormat(obj.txnTime),
                });
            });
            new Angular5Csv(data, 'Bittnomy Withdraw History Report');
        }
    }

    /** Function to convert date format */
    convertFormat(time) {
        return this.datepipe.transform(time, 'MM/dd/yyy, hh:mm a');
    }

}
