import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ServiceService } from 'src/app/Shared/service.service';
import { AngularFirestore } from '@angular/fire/firestore';
import { StaticContentFAQ } from 'src/app/Shared/feed-type';


@Component({
  selector: 'app-view-static-content',
  templateUrl: './view-static-content.component.html',
  styleUrls: ['./view-static-content.component.css']
})
export class ViewStaticContentComponent implements OnInit {
  editorValue: any = [];
  contentname: any;
  docname: any;

  p: number = 1;
  pageSize = 5;
  total = 0
  pagetitle: any;
  staticContentFAQ: any[];
  FAQLength: number;
  id: any;
  constructor(public router: Router, private afs: AngularFirestore, private firebaseServ: ServiceService, public route: ActivatedRoute) { }

  ngOnInit() {

    this.route.queryParams.subscribe((res) => {
      console.log('params--->>> ', res);

      this.contentname = res.value
      this.docname = res.docname
    })

    this.getstaticContent()

  }


  async getstaticContent() {


    this.firebaseServ.showSpinner();

    if (this.docname == 'FAQ') {
      this.pagetitle = this.contentname
      this.firebaseServ.hideSpinner();

      this.firebaseServ.getstaticFAQ(this.docname).subscribe(res => {
        this.staticContentFAQ = res.map(item => {
          return {
            id: item.payload.doc.id,
            ...item.payload.doc.data()
          } as StaticContentFAQ
        })
        this.firebaseServ.hideSpinner();
        this.total = this.staticContentFAQ.length
        console.log('DATA===>', this.staticContentFAQ)
      })

    }
    else {
      this.firebaseServ.getStaticContentFunc(this.docname).then(res => {

        console.log('staticContentdata', res)
        setTimeout(() => {
          this.firebaseServ.hideSpinner();
          this.editorValue = res.Description ? res.Description :''
          this.pagetitle = res.Title ?res.Title:''
        }, 2000)

      }).catch(err => {
        this.firebaseServ.hideSpinner();
        console.log(err)
      })
    }
  }

  UpdateStaticdata() {
    this.router.navigate(['/static-content/edit-static-content/id'], {
      queryParams: { value: this.contentname, docname: this.docname }
    })
  }


  addFaq() {
    this.router.navigate(['/static-content/add-faq/id'], {
      queryParams: { value: this.contentname, docname: this.docname }
    })

  }

  updateFaq(id) {
    this.contentname = 'EditFAQ'
    this.router.navigate(['/static-content/edit-faq/id'], {
      queryParams: { value: this.contentname, docname: this.docname, id: id }
    })
  }


  deleteFuction(id) {
    this.id = id
    console.log(this.id)

  }
  onDelete() {
    this.afs.collection('StaticContent').doc('FAQ/FAQ/' + this.id).delete();
    // this.afs.doc('SubscriptionPlan/'+this.id).delete();
    this.firebaseServ.showSuccess('FAQ has been deleted sucessfully.')
    this.getstaticContent()
  }
  page(event) {
    console.log(event);
    this.p = event
  }

  backtostaticview() {
    this.router.navigate(['/static-content'])
  }


}
