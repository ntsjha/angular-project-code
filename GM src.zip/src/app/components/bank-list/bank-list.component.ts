import { Component, OnInit, OnDestroy } from '@angular/core';
import { ServiceService } from 'src/app/service/service.service';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormBuilder } from '@angular/forms';
import { AppComponent } from 'src/app/app.component';
import { NgxSpinnerService } from 'ngx-spinner';


declare var $: any;
@Component({
  selector: 'app-bank-list',
  templateUrl: './bank-list.component.html',
  styleUrls: ['./bank-list.component.css']
})
export class BankListComponent implements OnInit, OnDestroy {
  filterFunction: FormGroup;
  currentId: string;
  page: any = 0;
  bankList: any;
  total: number;
  currentUser: any;
  p: any = 1;
  subscription: any;
  response: any ='';

  constructor(private service: ServiceService, private spinner: NgxSpinnerService ,private router: Router, private activatedRoute: ActivatedRoute, private fb: FormBuilder, private appC: AppComponent) {
    this.subscription = this.service.authVerify.subscribe(val => {
      if (val === 'bank-list') {
        this.deleteBank();
        this.service.authVerify.next('false');
      }
    });
  }

  ngOnInit() {
    window.scrollTo(0, 0);
    this.filterFunction = this.fb.group({
      search: [],
      status: [],
    });
    this.service.currentUserInfo.subscribe((response) => {
      this.currentUser = response;
    });
    this.getBankList();
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  /** Function to verify google authentication */
  verifyGoogleAuth() {
    $('#deleteBank').modal('hide');
    this.appC.google = { one: '', two: '', three: '', four: '', five: '', six: '' };
    this.appC.response = { message: '' };
    this.service.googleAuthCalledFrom = 'bank-list';
    $('#google-auth-modal').modal({ keyboard: false, backdrop: 'static' });

  }

  openModal(modalName, id) {
    this.response=''
    this.currentId = id;
    if (this.service.sideMenuArr.includes('deleteBanks')) {
      $('#' + modalName).modal('show');
    } else { }

    console.log('DATA==>',this.currentId )
    this.service.getMethod('account/common-permit/is-bank-deleteable?bankId='+encodeURIComponent(this.service.encrypt(this.currentId)), 1)
    .subscribe((response : any) => {
        console.log('DATA==>',response)
      this.spinner.hide();
      if (response.status === 640) {
        this.response = response.message;
       
      }  
    }, (error) => {
      this.spinner.hide();
    
    });


  }


  getBankList() {
    this.spinner.show();
    const data = {
      page: (this.page),
      pageSize: ('10'),
      search: ((this.filterFunction.value.search != null) ? (this.filterFunction.value.search.trim()) : null),
      status: ((this.filterFunction.value.status != null) ? (this.filterFunction.value.status) : null),
    };
    this.service.postMethod('account/common-permit/search-and-filter-bank-detail', data, 1)
      .subscribe((response) => {
        this.spinner.hide();
        if (response.status === 200) {
          this.bankList = response.data.list;
          this.total = response.data.size;
          this.bankList.forEach(element => {
            if(element.updatedBy == null) {
              element.updatedAt = null;
            }
          });
        } else if(response.status === 635 ) {
          this.bankList = [];
          this.total = 0;
        }
      }, (error) => {
        this.spinner.hide();
        this.bankList = [];
      });
  }

  addBank() {
    if (this.service.sideMenuArr.includes('createBanks')) {
      this.router.navigate(['/add-edit-bank/no']);
    }
  }

  deleteBank() {
    this.service.postMethod('account/common-permit/delete-bank/?bankId=' + encodeURIComponent(this.service.encrypt(this.currentId)) + '&ipAddress=' + encodeURIComponent(this.service.encrypt(this.currentUser.ip)) + '&location=' + encodeURIComponent(this.service.encrypt(this.currentUser.city)), {}, 1)
      .subscribe((res) => {
        this.spinner.hide();
        $('#deleteBank').modal('hide');
        this.getBankList();
      });
  }

  editBank(id) {
    if (this.service.sideMenuArr.includes('updateBanks')) {
      this.router.navigate(['/add-edit-bank/' + id]);
    }
  }

  disableBank() {
    this.service.postMethod('account/common-permit/disable-able-bank/?bankId=' + encodeURIComponent(this.service.encrypt(this.currentId)) + '&ipAddress=' + encodeURIComponent(this.service.encrypt(this.currentUser.ip)) + '&location=' + encodeURIComponent(this.service.encrypt(this.currentUser.city)), {}, 1)
      .subscribe(() => {
        $('#disableBank').modal('hide');
        this.getBankList();
      });
  }
  resetFunction() {
    this.filterFunction.patchValue({
      search: null,
      status: null,
    });
    this.p = 1;
    this.page = 0;
    this.getBankList();
  }

  changePage(page) {
    this.p = page;
    this.page = page - 1;
    this.getBankList();
  }
}
