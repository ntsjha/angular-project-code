import { Component, OnInit } from '@angular/core';
//import { Router } from '@angular/router';
import { AppComponent } from '../../../app.component';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { ServerService } from '../../../service/server.service';
import { HeaderComponent } from '../../header/header/header.component';
import { Observable } from '../../../../../node_modules/rxjs/Observable';
import { Router } from '@angular/router';

declare var $: any;

@Component({
  selector: 'app-wallet',
  templateUrl: './wallet.component.html',
  styleUrls: ['./wallet.component.css']
})
export class WalletComponent implements OnInit {
    address:any;
    textValue = '';
    currency: any = [];
    myAngularxQrCode:any= null;
    coinFullName = "";
    tagID = "";
    usdPrice: number = 6000;
    totalAmount: number;
    symbol: any;
    
    // withdrawObj = {amount: "", address: "", tagID: "", fee: ""}
    numRegxForDot = (/(?: |^)\d*\.?\d+(?: |$)/);
    regexForEightChar = (/^(\d+)?([.]?\d{0,8})?$/);
    regexForBtc = (/^[123][a-km-zA-HJ-NP-Z1-9]{25,34}$/);
    regexForLtc = (/^[LM3][a-km-zA-HJ-NP-Z1-9]{26,33}$/);
    regexForEth = (/^0x[a-fA-F0-9]{40}$/);
    mybtc: any;
    myltc: any;
    myeth: any;
    myxrp: any;
    mycpc: any;
    mybch: any;
    myneo: any;
    myxlm: any;
    myusdt: any;
    myxvg: any;
    mydash: any;
    mylcx: any;
    coinFee: any;
    securityType: string;
    otp = { one: "", two: "", three: "", four: "" };
    time: number;
    seconds: number = 59;
    qrCode = {Code1:""};
    code: string;
    public obj={address:'', amount: ''};
    convertObj = { coinType: '', amt: "0.0", marketPrice: 0.0 };
      coinListArr = [];
    coinList = [];
    coinBalance: any;
    kyc: any = [];
    tagId: any;
    withdrawObj = { amount: "", address: "", tagID: "", fee: "" }
    coinShortName: any;
    constructor( public router:Router,private appC: AppComponent, private spinnerService: Ng4LoadingSpinnerService, private server: ServerService, public header:HeaderComponent) { 
        /** data for table */
        // this.currency = [];
        // [{
        //         CurrencyName: "LCX Coin",
        //         Symbol: "LCX",
        //         AvailableBalance: "",
        //         reserved: '',
        //         Total: '',
        //         ESTBTC: '',
        //         change: '',
        //         blockBal: ''
        //     },
        //     {
        //         CurrencyName: 'Bitcoin',
        //         Symbol: 'BTC',
        //         AvailableBalance: "",
        //         reserved: '',
        //         Total: '',
        //         ESTBTC: '',
        //         change: '',
        //         blockBal: ''
        //     },{
        //         CurrencyName: 'Litecoin',
        //         Symbol: 'LTC',
        //         AvailableBalance: "",
        //         reserved: '',
        //         Total: '',
        //         ESTBTC: '',
        //         change: '',
        //         blockBal: ''
        //     },{
        //         CurrencyName: 'Ethereum',
        //         Symbol: 'ETH',
        //         AvailableBalance: "",
        //         reserved: '',
        //         Total: '',
        //         ESTBTC: '',
        //         change: '',
        //         blockBal: ''
        //     },{
        //         CurrencyName: 'Ripple',
        //         Symbol: 'XRP',
        //         AvailableBalance: "",
        //         reserved: '',
        //         Total: '',
        //         ESTBTC: '',
        //         change: '',
        //         blockBal: ''
        //     },
        //     {
        //         CurrencyName: "Dash",
        //         Symbol: "DASH",
        //         AvailableBalance: "",
        //         reserved: '',
        //         Total: '',
        //         ESTBTC: '',
        //         change: '',
        //         blockBal: ''
        //     },
        //     {
        //         CurrencyName: "Bitcoin Cash",
        //         Symbol: "BCH",
        //         AvailableBalance: "",
        //         reserved: '',
        //         Total: '',
        //         ESTBTC: '',
        //         change: '',
        //         blockBal: ''
        //     },
        //     {
        //         CurrencyName: "Neo",
        //         Symbol: "NEO",
        //         AvailableBalance:"",
        //         reserved: '',
        //         Total: '',
        //         ESTBTC: '',
        //         change: '',
        //         blockBal: ''
        //     },
        //     {
        //         CurrencyName: "Stellar",
        //         Symbol: "XLM",
        //         AvailableBalance: "",
        //         reserved: '',
        //         Total: '',
        //         ESTBTC: '',
        //         change: '',
        //         blockBal: ''
        //     },
        //     {
        //         CurrencyName: "Tether",
        //         Symbol: "USDT",
        //         AvailableBalance: "",
        //         reserved: '',
        //         Total: '',
        //         ESTBTC: '',
        //         change: '',
        //         blockBal: ''
        //     },
        //     {
        //         CurrencyName: "Verge",
        //         Symbol: "XVG",
        //         AvailableBalance: "",
        //         reserved: '',
        //         Total: '',
        //         ESTBTC: '',
        //         change: '',
        //         blockBal: ''
        //     }            
        // ]
    }

    /** data for dropdown list */
    public options=[1,2,3];
    
  
    ngOnInit() {        
        // this.spinnerService.show();
        // $(".loader_fade").show();
        // this.updateUserBalanceInDB(0);
        window.scrollTo(0,0);
        // this.getProfile();
        this.getCoinListWithBalance();
    }

  
   
   
    getCoinListWithBalance() {
        this.coinListArr=[];
        this.spinnerService.show();
        this.server.getApi("wallet/coin/get-coin-list", 0).subscribe((succ) => {
            this.spinnerService.hide();
            if (succ.body.status == 200) {
                this.spinnerService.hide();
                succ.body.data.forEach(element => {
                    if (element.coinShortName == 'BTC' || element.coinShortName == 'ETH' || element.coinShortName == 'XRP' || element.coinShortName == 'NEO' || element.coinShortName == 'LCX' || element.coinShortName == 'DASH' || element.coinShortName == 'LTC' || element.coinShortName == 'XLM' || element.coinShortName == 'XVG') {
                        this.coinListArr.push({
                            "coinId": element.coinId,
                            "coinFee": element.withdrawlFee,
                            "coinFullName": element.coinFullName,
                            "coinImage": element.coinImage,
                            "coinMarketPrice": element.coinMarketPrice,
                            "coinShortName": element.coinShortName,
                            "coinType": element.coinType,
                            "withdrawlFee": element.withdrawlFee,
                            "coinDescription": element.coinDescription,
                            "usdPrice": element.usdPrice,
                            "balance": element.balance,
                            "blockBalance": element.blockBalance,
                        });
                    } 
                      else if (element.coinShortName == 'BTC' || element.coinShortName == 'ETH' || element.coinShortName == 'XRP' || element.coinShortName == 'NEO' || element.coinShortName == 'LCX' || element.coinShortName == 'DASH' || element.coinShortName == 'LTC' || element.coinShortName == 'XLM' || element.coinShortName == 'XVG') {
                        this.coinListArr.push(element);
                    }
                });
                this.convertObj.coinType = this.coinListArr[0].Symbol;
                this.getCoinWalletBalance();
                // this.getCoinAvailableBalance(this.coinList[0].coinShortName);
                // this.getCurrentUSDMktPrice(this.coinList[0].coinShortName);
            }
        }, (err) => {
            this.spinnerService.hide();
        });
    }


    getCoinWalletBalance() {
        for (let i = 0; i < this.coinListArr.length; i++) {
            let data = {
               
                        "coinType": this.coinListArr[i].coinShortName,
                        
            }
           
            this.spinnerService.show();
            this.server.getApi("wallet/wallet/get-balance?coinName="+data.coinType, localStorage.getItem('token')).subscribe((succ) => {
                this.spinnerService.hide();
                if (succ.status == 200) {
                let getdata=  succ.body.data?succ.body.data:'';
                    this.coinListArr[i].balance =getdata.walletBalance?getdata.walletBalance:'';
                    this.coinListArr[i].blockBalance = getdata.blockedBalance;
                    this.coinListArr[i].Total=Number(getdata.walletBalance)+Number(getdata.blockedBalance)
                } else if (succ.status == 403) {
                    this.header.tokenExpire();
                } else {
                }
            }, (err) => {
                this.spinnerService.hide();
            });
        }
    }



    getCoinAvailableBalance(coin) {
        
        this.server.getApi("wallet/wallet/get-balance?coinName="+coin, localStorage.getItem('token')).subscribe((succ) => {
            if (succ.status == 200) {
                this.coinBalance = (succ.body.data.walletBalance).toFixed(5);
            } else if (succ.statusCode == 403) {
                this.header.tokenExpire();
            } else {
            }
        }, (err) => {
        });

    }
    checkKycStatus() {
        this.kyc = [];
        let kycDetails = {

            "token": localStorage.getItem('token')
        }

        this.spinnerService.show();
        this.server.getApi('account/get-kyc-details', localStorage.getItem('token')).subscribe(response => {
            this.spinnerService.hide();
            if (response.body.status == 200) {
                // console.log('KYC data-->')
                // console.log('KYC-->', response.body)
                this.kyc = response.body.data
                if (response.body.document == "undefined") {
                    this.appC.showInfoToast("To get the functionalities of the Bittnomy exchange you need to get your kyc done");
                } else if (this.kyc.kycStatus == 'ACCEPTED' ) {
                   
                    // this.checkyc = true;
                    this.submitWithdraw();
                }
                else if (this.kyc.kycStatus == null){
                    this.appC.showInfoToast('KYC verification is required to withdraw amount.');
                }

            } else {
                this.appC.showErrToast(response.body.message);
            }
        }, error => {
            this.appC.showErrToast(error.error.message);
            this.spinnerService.hide();
        });
    }
  
    depositFunc(obj) {
        
        if (obj.coinShortName == "USD") {
            // this.router.navigateByUrl('header/deposit');
        } else if (obj.coinShortName == "XRP" || obj.coinShortName == "XLM") {

            this.spinnerService.show();
            this.server.getApi("wallet/wallet-type2/get-address?coinName=" + obj.coinShortName, localStorage.getItem('token')).subscribe((succ) => {
                this.spinnerService.hide();
                if (succ.body.status == 200) {
                   
                    this.coinFullName = succ.body.data.coinName;
                    this.textValue = succ.body.data.walletAddress;
                    this.myAngularxQrCode = succ.body.data.walletAddress;
                    this.tagId = succ.tag;
                    $('#wallet-address').modal({backdrop: 'static', keyboard: false});
                } else {
                    this.appC.showErrToast(succ.body.message);
                }
            }, (err) => {
                this.spinnerService.hide();
                this.appC.showErrToast(err.error.message);
            });

        }

        else {
            this.spinnerService.show();
            this.server.getApi("wallet/wallet/get-address?coinName=" + obj.coinShortName, localStorage.getItem('token')).subscribe((succ) => {
                this.spinnerService.hide();
                if (succ.body.status == 200) {
                    // this.appC.showInfoToast('Address fetched successfully.');
                    this.coinFullName = succ.body.data.coinName;
                    this.textValue = succ.body.data.walletAddress;
                    this.myAngularxQrCode = succ.body.data.walletAddress;
                    this.tagId = succ.tag;
                    $('#wallet-address').modal({backdrop: 'static', keyboard: false});
                } else if (succ.body.status == 403) {
                    this.header.tokenExpire();
                } else {
                    this.appC.showErrToast(succ.body.message);
                }
            }, (err) => {
                this.spinnerService.hide();
                this.appC.showErrToast(err.error.message);
            });
        }
    }
    withdrawFunc() {
        // console.log('coinname-->',this.coinFullName,this.symbol)
        if (this.withdrawObj.address == "") {
            this.appC.showErrToast("Enter address");
            return;
        } else if (this.coinFullName == 'BITCOIN') {
            if (!this.regexForBtc.test(this.withdrawObj.address)) {
                this.appC.showErrToast("Enter valid address ");
                return;
            }
        } else if (this.coinFullName == 'LITECOIN') {
            if (!this.regexForLtc.test(this.withdrawObj.address)) {
                this.appC.showErrToast("Enter valid address ");
                return;
            }
        } else if (this.coinFullName == 'ETHEREUM') {
            if (!this.regexForEth.test(this.withdrawObj.address)) {
                this.appC.showErrToast("Enter valid address ");
                return;
            }
        } else if (this.withdrawObj.amount == "") {
            this.appC.showErrToast("Enter amount value");
            return;
        } else if (!this.numRegxForDot.test(this.withdrawObj.amount)) {
            this.appC.showErrToast("Enter valid amount value");
            return;
        } else if (this.symbol == "XRP" || this.symbol == "XLM") {
            if (this.withdrawObj.tagID == "") {
                this.appC.showErrToast("Enter Tag ID.");
                return;
            }
        }
        this.checkKycStatus();
    }

  /** Function to submit withdraw after validation */
  submitWithdraw() {
    let data = {
        "amount": this.withdrawObj.amount,
        "coinName": this.symbol,
        "tag": this.withdrawObj.tagID,
        "toAddress": this.withdrawObj.address
    }
    // console.log('withdrwa')
    this.spinnerService.show();
    this.server.postApi("wallet/wallet/withdraw", data, localStorage.getItem('token')).subscribe((succ) => {
        this.spinnerService.hide();
        if (succ.body.status == 200) {
            this.appC.showInfoToast("A confirmation mail has been sent to your registered E-mail ID. Please click on that link to complete the process.");
            $('#withdral').modal("hide");
        } else {
            this.appC.showErrToast(succ.body.message);
        }
    }, (err) => {
        this.spinnerService.hide();
        this.appC.showErrToast(err.error.message);
    });
}

    withdraw(obj) {
        if (obj.coinShortName == "USD") {
            // this.router.navigateByUrl('header/withdraw');
        } else if (obj.balance > 0) {
            // this.clearWithdrawFields();
            this.symbol = obj.coinShortName;
            this.coinFullName = obj.coinFullName;
            this.getCoinFee(obj);
        } else
            this.appC.showErrToast('Insufficient balance')
    }
    getCoinFee(obj) {
        this.coinFee = obj.withdrawlFee;
        $('#withdral').modal({ backdrop: 'static', keyboard: false });
    }
    clearWithdrawFields() {
        this.withdrawObj.address = "";
        this.withdrawObj.amount = "";
        this.withdrawObj.tagID = "";
    }
    transactionDetail(obj) {
        this.coinShortName = obj.coinShortName;
        this.router.navigateByUrl('header/transactionDetail/' + this.coinShortName);
    }

    transactionDetailUSD() {
        this.router.navigateByUrl('header/TransactionDetail');
    }
 
 
    /** Function to restrict space */
    restrictSpace(event) {
        var k = event.charCode;
        if (k === 32) return false;
    }

    /** Function to restrict character */
    restrictChar(event) {
        var k = event.charCode;
        if (event.key === 'Backspace')
            k = 8;
        if (k >= 48 && k <= 57 || k == 8 || k == 46)
            return true;
        else
            return false;    
    }

    /** FUnction for restrict length */
    restrictLength() {
        if(this.withdrawObj.amount.includes(".")) {
            if (!this.regexForEightChar.test(this.withdrawObj.amount)) {
                let tempVal = this.withdrawObj.amount.split('.');
                this.withdrawObj.amount = tempVal[0] + '.' + tempVal[1].slice(0, 8);
            }
        }
    }
    copyToClipboard(data) {
        this.appC.showInfoToast("Text has been copied to clipboard.");
        let selBox = document.createElement('textarea');
        selBox.style.position = 'fixed';
        selBox.style.left = '0';
        selBox.style.top = '0';
        selBox.style.opacity = '0';
        selBox.value = data;
        document.body.appendChild(selBox);
        selBox.focus();
        selBox.select();
        document.execCommand('copy');
        document.body.removeChild(selBox);
    }

}


//     /** Function for fetch user's coin balance */
//     updateUserBalanceInDB(currInd) {
//         if(currInd < 11) {
//             let data = {
//             //     "eventExternal": {
//             //         "name": "request_deposits",
//             //         "key": "mykey"                
//             //     },   
//             //    "transferObjectMap": { 
//             //        "gatewayrequest": { 
//             //            "coinType": this.currency[currInd].Symbol,
//             //             "token": localStorage.getItem('token')
//             //         }
//             //     }
//             }
//             this.server.postApi('', data,0).subscribe(succ => {                
//                 if (succ.transferObjectMap.statusCode == 200) {
//                     currInd++;
//                     this.updateUserBalanceInDB(currInd);
//                 } else if(succ.transferObjectMap.statusCode == 403){
//                     this.spinnerService.hide();
//                     this.appC.showErrToast(succ.transferObjectMap.message); 
//                     this.header.tokenExpire();
//                 } else {
//                     this.spinnerService.hide();
//                     // this.appC.showErrToast(succ.transferObjectMap.message);
//                     currInd++;
//                     this.updateUserBalanceInDB(currInd);
//                 }
//             }, error => {
//                 this.spinnerService.hide();
//                 // this.appC.showErrToast('Something went wrong');
//                 currInd++;
//                 this.updateUserBalanceInDB(currInd);
//             });
//         } else {
//             console.log("user db update");
//             this.getCoinBalance();
//         }        
//     }

//     getProfile() {
//         this.server.getApi("?key="+localStorage.getItem('token')+"USER",0).subscribe((succ) => { 
//             if(succ[0].google2faEnabled == "1" || succ[0].google2faEnabled == "true") {
//                 this.securityType = "GA";
//             } else if(succ[0].smsEnabled == "1" || succ[0].smsEnabled == "false") {
//                 this.securityType = "SMS";
//             }
//         }, (err) => {
//             //this.spinnerService.hide();
//         });
//     }

//     /** Function to get coin balance */
//     getCoinBalance() {
//         // let data = {
//         //     "eventExternal" : {
//         //         "name" : "request_get_coin_list",
//         //         "key" : "mykey"
//         //     },
//         //     "transferObjectMap" : {
//         //         "loginToken": localStorage.getItem("token")
//         //     }
//         // }    
//         for (let i = 0; i < this.currency.length; i++) {
//             let data = {
               
//                         "coinType": this.currency[i].Symbol,
                        
//             }    
//         this.server.post('',data).subscribe((succ) => {
//             // this.spinnerService.hide();
//             $(".loader_fade").hide();
//              if(succ.body.status == 200) {
//             //     // BCH Value Set
//             //     this.mybch = succ.transferObjectMap.coinList.filter((obj) => obj.coinShortName == "BCH")[0].balance;
//             //     this.currency[6].AvailableBalance = succ.transferObjectMap.coinList.filter((obj) => obj.coinShortName == "BCH")[0].balance;
//             //     this.currency[6].blockBal = succ.transferObjectMap.coinList.filter((obj) => obj.coinShortName == "BCH")[0].blockBalance;
//             //     this.currency[6].Total = this.currency[6].AvailableBalance + this.currency[6].blockBal;            
//             //     // BTC Value Set
//             //     this.mybtc = succ.transferObjectMap.coinList.filter((obj) => obj.coinShortName == "BTC")[0].balance;
//             //     this.currency[1].AvailableBalance = succ.transferObjectMap.coinList.filter((obj) => obj.coinShortName == "BTC")[0].balance;
//             //     this.currency[1].blockBal = succ.transferObjectMap.coinList.filter((obj) => obj.coinShortName == "BTC")[0].blockBalance;
//             //     this.currency[1].Total = this.currency[1].AvailableBalance + this.currency[1].blockBal;
//             //     // ETH Value Set
//             //     this.myeth = succ.transferObjectMap.coinList.filter((obj) => obj.coinShortName == "ETH")[0].balance;
//             //     this.currency[3].AvailableBalance = succ.transferObjectMap.coinList.filter((obj) => obj.coinShortName == "ETH")[0].balance;
//             //     this.currency[3].blockBal = succ.transferObjectMap.coinList.filter((obj) => obj.coinShortName == "ETH")[0].blockBalance;
//             //     this.currency[3].Total = this.currency[3].AvailableBalance + this.currency[3].blockBal;
//             //     // LTC Value Set
//             //     this.myltc = succ.transferObjectMap.coinList.filter((obj) => obj.coinShortName == "LTC")[0].balance;
//             //     this.currency[2].AvailableBalance = succ.transferObjectMap.coinList.filter((obj) => obj.coinShortName == "LTC")[0].balance;
//             //     this.currency[2].blockBal = succ.transferObjectMap.coinList.filter((obj) => obj.coinShortName == "LTC")[0].blockBalance;
//             //     this.currency[2].Total = this.currency[2].AvailableBalance + this.currency[2].blockBal;
//             //     // NEO Value Set
//             //     this.myneo = succ.transferObjectMap.coinList.filter((obj) => obj.coinShortName == "NEO")[0].balance;
//             //     this.currency[7].AvailableBalance = succ.transferObjectMap.coinList.filter((obj) => obj.coinShortName == "NEO")[0].balance;
//             //     this.currency[7].blockBal = succ.transferObjectMap.coinList.filter((obj) => obj.coinShortName == "NEO")[0].blockBalance;
//             //     this.currency[7].Total = this.currency[7].AvailableBalance + this.currency[7].blockBal;
//             //     // USDT Value Set
//             //     this.myusdt = succ.transferObjectMap.coinList.filter((obj) => obj.coinShortName == "USDT")[0].balance;
//             //     this.currency[9].AvailableBalance = succ.transferObjectMap.coinList.filter((obj) => obj.coinShortName == "USDT")[0].balance;
//             //     this.currency[9].blockBal = succ.transferObjectMap.coinList.filter((obj) => obj.coinShortName == "USDT")[0].blockBalance;
//             //     this.currency[9].Total = this.currency[9].AvailableBalance + this.currency[9].blockBal;
//             //     // XLM Value Set
//             //     this.myxlm = succ.transferObjectMap.coinList.filter((obj) => obj.coinShortName == "XLM")[0].balance;
//             //     this.currency[8].AvailableBalance = succ.transferObjectMap.coinList.filter((obj) => obj.coinShortName == "XLM")[0].balance;
//             //     this.currency[8].blockBal = succ.transferObjectMap.coinList.filter((obj) => obj.coinShortName == "XLM")[0].blockBalance;
//             //     this.currency[8].Total = this.currency[8].AvailableBalance + this.currency[8].blockBal;
//             //     // XRP Value Set
//             //     this.myxrp = succ.transferObjectMap.coinList.filter((obj) => obj.coinShortName == "XRP")[0].balance;
//             //     this.currency[4].AvailableBalance = succ.transferObjectMap.coinList.filter((obj) => obj.coinShortName == "XRP")[0].balance;
//             //     this.currency[4].blockBal = succ.transferObjectMap.coinList.filter((obj) => obj.coinShortName == "XRP")[0].blockBalance;
//             //     this.currency[4].Total = this.currency[4].AvailableBalance + this.currency[4].blockBal;
//             //     // XVG Value Set
//             //     this.myxvg = succ.transferObjectMap.coinList.filter((obj) => obj.coinShortName == "XVG")[0].balance;
//             //     this.currency[10].AvailableBalance = succ.transferObjectMap.coinList.filter((obj) => obj.coinShortName == "XVG")[0].balance;
//             //     this.currency[10].blockBal = succ.transferObjectMap.coinList.filter((obj) => obj.coinShortName == "XVG")[0].blockBalance;
//             //     this.currency[10].Total = this.currency[10].AvailableBalance + this.currency[10].blockBal;
//             //     // DASH Value Set
//             //     this.mydash = succ.transferObjectMap.coinList.filter((obj) => obj.coinShortName == "DASH")[0].balance;
//             //     this.currency[5].AvailableBalance = succ.transferObjectMap.coinList.filter((obj) => obj.coinShortName == "DASH")[0].balance;
//             //     this.currency[5].blockBal = succ.transferObjectMap.coinList.filter((obj) => obj.coinShortName == "DASH")[0].blockBalance;
//             //     this.currency[5].Total = this.currency[5].AvailableBalance + this.currency[5].blockBal;
//             //     // LCX Value Set
//             //     this.mylcx = succ.transferObjectMap.coinList.filter((obj) => obj.coinShortName == "LCX")[0].balance;
//             //     this.currency[0].AvailableBalance = succ.transferObjectMap.coinList.filter((obj) => obj.coinShortName == "LCX")[0].balance;
//             //     this.currency[0].blockBal = succ.transferObjectMap.coinList.filter((obj) => obj.coinShortName == "LCX")[0].blockBalance;
//             //     this.currency[0].Total = this.currency[0].AvailableBalance + this.currency[0].blockBal;
//             //     //this.currency = this.sortCoin(this.currency);
//             } else {
//                 this.appC.showErrToast(succ.transferObjectMap.message);
//             }
//         }, (err) => {
//             // this.spinnerService.hide();
//             $(".loader_fade").hide();
//         });
//     }
// }

//     /** Function for short coin list */
//     sortCoin(arr) {
//         arr.splice(0, 0, arr[10]);
//         arr.splice(11, 1);
//         return arr;
//     }    

//     goTopage(type) {
//         switch(type) {
//             case 0:
//                 $('#wallet-address').modal('show');
//                 $('#wallet-address').modal('show')
//                 break;
//             case 1:
//                 $('#withdral').modal('show')
//                 $('#withdral').modal('show')
//                 break;
//         }
//     }

//     /** Function for deposit */
//     depositFunc(obj) {
//         if(obj.Symbol != "LCX") {
//             let data = {
//                 "eventExternal":{
//                     "name":"request_getWalletAddress",                
//                     "key":"mykey"
//                 },
//                "transferObjectMap":{
//                     "gatewayrequest":{
//                         "token": localStorage.getItem("token"),
//                         "coinType": obj.Symbol                    
//                     }
//                 }
//             }       
//             this.spinnerService.show();
//             this.server.postApi("",data,0).subscribe((succ) => {
//                 this.spinnerService.hide();
//                 if(succ.transferObjectMap.statusCode == 200) {
//                     this.appC.showInfoToast("Address fetched successfully.");
//                     this.coinFullName = obj.CurrencyName;
//                     this.textValue = succ.transferObjectMap.address;
//                     this.myAngularxQrCode = succ.transferObjectMap.address;
//                     if(obj.Symbol == "XRP" || obj.Symbol == "XLM") {
//                        this.tagID =  succ.transferObjectMap.tag;
//                     }
//                     $('#wallet-address').modal({backdrop: 'static', keyboard: false});
//                 } else if(succ.transferObjectMap.statusCode == 403){
//                     this.appC.showErrToast(succ.transferObjectMap.message); 
//                     this.header.tokenExpire();
//                 } else {
//                     this.appC.showErrToast(succ.transferObjectMap.message);
//                 }
//             }, (err) => {
//                 this.spinnerService.hide();
//                 this.appC.showErrToast("Something went wrong.");
//             });
//         } else {
//             $('#lcxConfirmPopup').modal({backdrop: 'static', keyboard: false});
//         }                
//     }

//     /** Function for lcx token confirm popup */
//     lcxPopupConfirm() {
//         let data = {
//             "eventExternal":{
//                 "name":"request_getWalletAddress",                
//                 "key":"mykey"
//             },
//            "transferObjectMap":{
//                 "gatewayrequest":{
//                     "token": localStorage.getItem("token"),
//                     "coinType": "LCX"                    
//                 }
//             }
//         }       
//         this.spinnerService.show();
//         this.server.postApi("",data,0).subscribe((succ) => {
//             this.spinnerService.hide();
//             if(succ.transferObjectMap.statusCode == 200) {
//                 $('#lcxConfirmPopup').modal("hide");
//                 this.appC.showInfoToast("Address fetched successfully.");
//                 this.coinFullName = "LCX Coin";
//                 this.textValue = succ.transferObjectMap.address;
//                 this.myAngularxQrCode = succ.transferObjectMap.address;
//                 $('#wallet-address').modal({backdrop: 'static', keyboard: false});
//             } else if(succ.transferObjectMap.statusCode == 403){
//                 this.appC.showErrToast(succ.transferObjectMap.message); 
//                 this.header.tokenExpire();
//             } else {
//                 this.appC.showErrToast(succ.transferObjectMap.message);
//             }
//         }, (err) => {
//             this.spinnerService.hide();
//             this.appC.showErrToast("Something went wrong.");
//         });
//     }

//     /** Function for withdraw */
//     /*withdrawFunc() {
//         if(this.withdrawObj.address == "") {
//             this.appC.showErrToast("Enter address");
//             return;
//         } else if(this.coinFullName == 'Bitcoin') {
//             if(!this.regexForBtc.test(this.withdrawObj.address))
//                 this.appC.showErrToast("Enter valid address ");
                
//         } else if(this.coinFullName == 'Litecoin') {
//             if(!this.regexForLtc.test(this.withdrawObj.address))
//                 this.appC.showErrToast("Enter valid address ");
                
//         } else if(this.coinFullName == 'Ethereum') {
//             if(!this.regexForEth.test(this.withdrawObj.address))
//                 this.appC.showErrToast("Enter valid address ");
               
//         } else if(this.withdrawObj.amount == "") {
//             this.appC.showErrToast("Enter amount value");
//             return;
//         } else if(!this.numRegxForDot.test(this.withdrawObj.amount)) {
//             this.appC.showErrToast("Enter valid amount value");
//             return;
//         } else if(this.symbol == "XRP" || this.symbol == "XLM") {
//             if(this.withdrawObj.tagID == "") {
//                 this.appC.showErrToast("Enter Tag ID.");
//                 return;
//             } else {
//                 this.submitWithdraw();    
//             }
//         } else {
//             this.submitWithdraw();
//         }
//     }*/

//     /** Function for withdraw */
//     withdrawFunc() {
//         if(this.withdrawObj.address == "") {
//             this.appC.showErrToast("Enter address");
//             return;
//         } else if(this.withdrawObj.amount == "") {
//             this.appC.showErrToast("Enter amount value");
//             return;
//         } else if(Number(this.withdrawObj.amount) <=0) {
//             this.appC.showErrToast("Enter valid amount value");
//             return;
//         } else if(this.withdrawObj.amount == ".") {
//             this.appC.showErrToast("Enter valid amount value");
//             return;
//         } else {
//             if(this.symbol == "XRP" || this.symbol == "XLM") {
//                 if(this.withdrawObj.tagID == "") {
//                     this.appC.showErrToast("Enter Tag ID.");
//                     return;
//                 } else {                        
//                     this.checkUserBalance();
//                 }
//             } else {
//                 this.checkUserBalance();
//             }
//         }
//     }

//     /** Function to check user balance before withdraw */
//     checkUserBalance() {
//         switch(this.symbol) {
//             case 'BTC':
//                 if(this.withdrawObj.amount > this.mybtc) {
//                     this.appC.showErrToast("You can't withdraw more than your wallet amount.");
//                     return;
//                 } else {
//                     this.submitWithdraw();
//                 }
//                 break;
//             case 'LTC':
//                 if(this.withdrawObj.amount > this.myltc) {
//                     this.appC.showErrToast("You can't withdraw more than your wallet amount.");
//                     return;
//                 } else {
//                     this.submitWithdraw();
//                 }
//                 break;
//             case 'ETH':
//                 if(this.withdrawObj.amount > this.myeth) {
//                     this.appC.showErrToast("You can't withdraw more than your wallet amount.");
//                     return;
//                 } else {
//                     this.submitWithdraw();
//                 }
//                 break;
//             case 'XRP':
//                 if(this.withdrawObj.amount > this.myxrp) {
//                     this.appC.showErrToast("You can't withdraw more than your wallet amount.");
//                     return;
//                 } else {
//                     this.submitWithdraw();
//                 }
//                 break;
//             case 'DASH':
//                 if(this.withdrawObj.amount > this.mydash) {
//                     this.appC.showErrToast("You can't withdraw more than your wallet amount.");
//                     return;
//                 } else {
//                     this.submitWithdraw();
//                 }
//                 break;
//             case 'BCH':
//                 if(this.withdrawObj.amount > this.mybch) {
//                     this.appC.showErrToast("You can't withdraw more than your wallet amount.");
//                     return;
//                 } else {
//                     this.submitWithdraw();
//                 }
//                 break;
//             case 'NEO':
//                 if(this.withdrawObj.amount > this.myneo) {
//                     this.appC.showErrToast("You can't withdraw more than your wallet amount.");
//                     return;
//                 } else {
//                     this.submitWithdraw();
//                 }
//                 break;
//             case 'XLM':
//                 if(this.withdrawObj.amount > this.myxlm) {
//                     this.appC.showErrToast("You can't withdraw more than your wallet amount.");
//                     return;
//                 } else {
//                     this.submitWithdraw();
//                 }
//                 break;
//             case 'USDT':
//                 if(this.withdrawObj.amount > this.myusdt) {
//                     this.appC.showErrToast("You can't withdraw more than your wallet amount.");
//                     return;
//                 } else {
//                     this.submitWithdraw();
//                 }
//                 break;
//             case 'XVG':
//                 if(this.withdrawObj.amount > this.myxvg) {
//                     this.appC.showErrToast("You can't withdraw more than your wallet amount.");
//                     return;
//                 } else {
//                     this.submitWithdraw();
//                 }
//                 break;
//             case 'LCX':
//                 if(this.withdrawObj.amount > this.mylcx) {
//                     this.appC.showErrToast("You can't withdraw more than your wallet amount.");
//                     return;
//                 } else {
//                     this.submitWithdraw();
//                 }
//                 break;
//         }
//     }

//     withdraw(obj) {
//         this.clearWithdrawFields();
//         this.symbol = obj.Symbol
//         this.coinFullName = obj.CurrencyName;
//         this.getCoinFee();
//         $('#withdral').modal({backdrop: 'static', keyboard: false});
//     }

//     limitDigit() {
//         let str = "" + this.withdrawObj.amount
//         this.withdrawObj.amount = str.split('.')[0]+'.'+ str.split('.')[1].slice(0,8);
//     }

//     /** Function to submit withdraw after validation */
//     submitWithdraw() {
//         if(this.securityType == 'SMS') {
//             this.otpSend();
//         } else if(this.securityType == "GA") {
//             this.qrCode = { Code1: ""};
//             $('#googleAuth').modal({backdrop:'static',keyboard: false});
//         }
//         // let data =  {
//         //     "eventExternal": {
//         //         "name":"request_withdraw",
//         //         "key":"mykey"
//         //     },
//         //     "transferObjectMap": {
//         //         "gatewayrequest": {
//         //             "coinType": this.symbol,
//         //             "token": localStorage.getItem("token"),
//         //             "sentTo": this.withdrawObj.address,
//         //             "amount": this.withdrawObj.amount,
//         //             "tagId": this.withdrawObj.tagID,
//         //             "isWithdrawSupport": true,
//         //             // "url": this.server.webiteUrl + 'withdrawverify'
//         //         }
//         //     }              
//         // }
//         // //console.log("withdraw data -> "+JSON.stringify(data));
//         // this.spinnerService.show();
//         // this.server.postApi("",data).subscribe((succ) => {
//         //     this.spinnerService.hide();
//         //     if(succ.transferObjectMap.statusCode == 200) {
//         //         this.appC.showInfoToast("Withdraw submitted successfully.");
//         //         this.getCoinBalance();
//         //         $('#withdral').modal("hide");
//         //     } else if(succ.transferObjectMap.statusCode == 403){
//         //         this.appC.showErrToast(succ.transferObjectMap.message); 
//         //         this.header.tokenExpire()
//         //     } else {
//         //         this.appC.showErrToast(succ.transferObjectMap.message);
//         //     }
//         // }, (err) => {
//         //     this.spinnerService.hide();
//         //     this.appC.showErrToast("Something went wrong.");
//         // });
//     }

//     requestWithdraw() {
//         let data =  {
//             "eventExternal": {
//                 "name":"request_withdraw",
//                 "key":"mykey"
//             },
//             "transferObjectMap": {
//                 "gatewayrequest": {
//                     "coinType": this.symbol,
//                     "token": localStorage.getItem("token"),
//                     "sentTo": this.withdrawObj.address,
//                     "amount": this.withdrawObj.amount,
//                     "tagId": this.withdrawObj.tagID,
//                     "isWithdrawSupport": true,
//                     // "url": this.server.webiteUrl + 'withdrawverify'
//                 }
//             }              
//         }
//         this.spinnerService.show();
//         this.server.postApi("",data,0).subscribe((succ) => {
//             this.spinnerService.hide();
//             if(succ.transferObjectMap.statusCode == 200) {
//                 this.appC.showInfoToast("Withdraw submitted successfully.");
//                 this.getCoinBalance();
//                 $('#withdral').modal("hide");
//             } else if(succ.transferObjectMap.statusCode == 403){
//                 this.appC.showErrToast(succ.transferObjectMap.message); 
//                 this.header.tokenExpire()
//             } else {
//                 this.appC.showErrToast(succ.transferObjectMap.message);
//             }
//         }, (err) => {
//             this.spinnerService.hide();
//             this.appC.showErrToast("Something went wrong.");
//         });
//     }

//     qrVerify() {
//         let data = {
//             "eventExternal": {
//                 "name":"request_google_verify",
//                 "key":"mykey"
//             },
//             "transferObjectMap": {   
//                 "gatewayrequest": {
//                     "otp": this.qrCode.Code1,
//                     "secretKey":localStorage.getItem('key'),
//                     "token": localStorage.getItem("token"),
//                     "clientTime":  new Date().getTime()
//                 }
//             }
//         }
//         this.spinnerService.show();
//         this.server.postApi('', data,0).subscribe(response => {
//             this.spinnerService.hide();
//             if (response.transferObjectMap.statusCode == 200) {
//                 this.appC.showSuccToast(response.transferObjectMap.message);
//                 this.requestWithdraw();
//                 $('#googleAuth').modal('hide');
//             } else {
//                 this.qrCode = {Code1:""} 
//                 this.appC.showErrToast(response.transferObjectMap.message);
//             }
//         }, error => {
//             this.spinnerService.hide();
//             this.appC.showErrToast('Something went wrong');
//         });
//     }

//     otpSend() {
//         let data =   {
//             "eventExternal": {
//                 "name":"request_sms_auth",
//                 "key":"mykey"
//             },
//             "transferObjectMap": {
//                 "gatewayrequest": {
//                     "phoneCountryCode":'',
//                     "phone":'',
//                     "token": localStorage.getItem("token")
//                 }
//             }
//         }    
//         this.spinnerService.show();
//         this.server.postApi('', data,0).subscribe(response => {
//             this.spinnerService.hide();
//             if (response.transferObjectMap.statusCode == 200) {
//                 this.appC.showSuccToast(response.transferObjectMap.message);
//                 this.otp = { one: "", two: "", three: "", four: "" };
//                 this.seconds = 59;
//                 $('#otp').modal({backdrop: 'static',keyboard: false});
//                 this.myTimer();                
//             } else {
//                 this.appC.showErrToast(response.transferObjectMap.message);
                
//             }
//         }, error => {
//             this.spinnerService.hide();
//             this.appC.showErrToast('Something went wrong');
//         });
//     }

//     myTimer() {
//         Observable.interval(1000)
//         .takeWhile(() => this.seconds > 0 || (this.seconds != 60 && this.seconds > 0))
//         .subscribe(i => { 
//             --this.seconds;
//         })
//         if(this.seconds==0) {
//             clearInterval(this.seconds);
//         }
//     }
    
//     resendOtp() {
//         this.seconds= 59;
//         this.resend();
//     }

//     resend() {
//         this.myTimer();
//         let data =   {
//             "eventExternal": {
//                 "name":"request_sms_auth",
//                 "key":"mykey"
//             },
//            "transferObjectMap": {
//                 "gatewayrequest": {
//                     "phoneCountryCode":'',
//                     "phone":'',
//                     "token":localStorage.getItem('token')
//                 }
//             }
//         }        
//         this.spinnerService.show();
//         this.server.postApi('', data,0).subscribe(response => {
//             this.spinnerService.hide();
//             if (response.transferObjectMap.statusCode == 200) {
//                 this.otp = { one: "", two: "", three: "", four: "" };
//             } else {
//                 this.appC.showErrToast(response.transferObjectMap.message);                
//             }
//         }, error => {
//             this.spinnerService.hide();
//             this.appC.showErrToast('Something went wrong');
//         });
//     }

//     /** Auto focus functionality */
//     onKey(value, type) {
//         if (type == 1) {
//             if (value != "") {
//                 $('#otp2').focus();
//             }
//         } else if (type == 2) {
//             if (value != "") {
//                 $('#otp3').focus();
//             }
//         } else if (type == 3) {
//             if (value != "") {
//                 $('#otp4').focus();
//             }
//         } else if (type == 4) {
//             if (value != "") {
//                 $('#otp5').focus();
//             }
//         } 
//     }

//     smsVerify() {
//         this.code =  this.otp.one + this.otp.two + this.otp.three + this.otp.four ;
//         //console.log(this.code) ;
//         let data = {
//             "eventExternal": {
//                 "name":"request_sms_verify",
//                 "key":"mykey"
//             },
//             "transferObjectMap": {
//                 "gatewayrequest": {
//                     "code": this.code,
//                     "token": localStorage.getItem("token"),
//                     "clientTime":  new Date().getTime()
//                 }
//             }
//         }
        
//         //console.log(this.otp.one+this.otp.two+this.otp.three+this.otp.four)
//         this.spinnerService.show();
//         this.server.postApi('', data,0).subscribe(response => {
//             this.spinnerService.hide();
//             if (response.transferObjectMap.statusCode == 200) {
//                 this.appC.showSuccToast(response.transferObjectMap.message);
//                 this.requestWithdraw();
//                 $('#otp').modal('hide');
//                 //this.myAngularxQrCode = response.transferObjectMap.address;                
//             } else {
//                 this.otp = { one: "", two: "", three: "", four: "" };   
//                 this.appC.showErrToast("Please enter correct OTP ");
//             }
//         }, error => {
//             this.spinnerService.hide();
//             this.appC.showErrToast('Something went wrong');
//         });    
//     }
    
//     /** Function to clear withdraw fields */
//     clearWithdrawFields() {
//         this.withdrawObj.address = "";
//         this.withdrawObj.amount = "";
//         this.withdrawObj.tagID = "";
//     }

//     /**Start add account  function */
//     addAmount(){
        
//     }

//     /**Start filter  function */
//     filter(){
//         //  
//     }
    
//     copyToClipboard(data) {
//         this.appC.showInfoToast("Text has been copied to clipboard.");
//         let selBox = document.createElement('textarea');
//         selBox.style.position = 'fixed';
//         selBox.style.left = '0';
//         selBox.style.top = '0';
//         selBox.style.opacity = '0';
//         selBox.value = data;
//         document.body.appendChild(selBox);
//         selBox.focus();
//         selBox.select();
//         document.execCommand('copy');
//         document.body.removeChild(selBox);
//     }

//     /** to convert crypto currency into usd*/
//     convertToUsd(val) {
//         this.totalAmount = Number(this.obj.amount) * this.usdPrice
//         let str = "" + val.target.value
//         // console.log(str)
//         if(str.match(/^\d+(\.\d{1,8})?$/)) {
//           // console.log("true")
//         } else {
//           this.obj.amount = str.split('.')[0]+'.'+str.split('.')[1].slice(0,8);
//           // console.log(str.split('.')[0])
//           // console.log(str.split('.')[1])
//         }
//         //  console.log(this.totalAmount)
        
//     }

//     /** get coin fee */
//     getCoinFee() {
//         let data = {
//             "eventExternal":    {
//                 "name":"get_fee_from_coin",
//                 "key":"mykey"
//             },
//            "transferObjectMap": {
//                 "gatewayrequest":   {
//                     "coinType": this.symbol,
//                     "token": localStorage.getItem("token"),
//                 }
//             }
//         }
//         this.spinnerService.show();
//         this.server.postApi("",data,0).subscribe((succ) => {
//             this.spinnerService.hide();
//             if(succ.transferObjectMap.statusCode == 200) {
//                 this.coinFee = succ.transferObjectMap.result[0].withdrawlFee;
//             } else if(succ.transferObjectMap.statusCode == 403){
//                 this.appC.showErrToast(succ.transferObjectMap.message); 
//                 this.header.tokenExpire()
//             } else {
//                 this.appC.showErrToast(succ.transferObjectMap.message);
//             }
//         }, (err) => {
//             this.spinnerService.hide();
//             this.appC.showErrToast("Something went wrong.");
//         });        
//     }

//     /** Function to restrict space */
//     restrictSpace(event) {
//         var k = event.charCode;
//         if (k === 32) return false;
//     }

//     /** Function to restrict character */
//     restrictChar(event) {
//         var k = event.charCode;
//         if (event.key === 'Backspace')
//             k = 8;
//         if (k >= 48 && k <= 57 || k == 8 || k == 46)
//             return true;
//         else
//             return false;    
//     }

//     /** FUnction for restrict length */
//     restrictLength() {
//         if(this.withdrawObj.amount.includes(".")) {
//             if (!this.regexForEightChar.test(this.withdrawObj.amount)) {
//                 let tempVal = this.withdrawObj.amount.split('.');
//                 this.withdrawObj.amount = tempVal[0] + '.' + tempVal[1].slice(0, 8);
//             }
//         }
//     }
//}
