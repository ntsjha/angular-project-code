import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AddMoneyOptionsPage } from './add-money-options';

@NgModule({
  declarations: [
    AddMoneyOptionsPage,
  ],
  imports: [
    IonicPageModule.forChild(AddMoneyOptionsPage),
  ],
})
export class AddMoneyOptionsPageModule {}
