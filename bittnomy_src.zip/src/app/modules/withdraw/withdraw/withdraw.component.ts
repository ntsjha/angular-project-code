import { Component, OnInit } from '@angular/core';
import { AppComponent } from '../../../app.component';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { ServerService } from '../../../service/server.service';
import { HeaderComponent } from '../../header/header/header.component';
import { Router } from '@angular/router';

@Component({
    selector: 'app-withdraw',
    templateUrl: './withdraw.component.html',
    styleUrls: ['./withdraw.component.css']
})
export class WithdrawComponent implements OnInit {
    withdrawObj = {iban:"", bic_swift_code:"", bank_name:"", bank_address:"", recipient_name:"", recipient_address:"", amount:""};
    regexForSixChar = (/^(\d+)?([.]?\d{0,6})?$/);
    user = {usdBal:""};
    docFile: any;
    fileName: any;
    myImage: any = '';

    constructor(private appC: AppComponent, private spinnerService: Ng4LoadingSpinnerService, private server: ServerService, public header:HeaderComponent, public router: Router) { }

    ngOnInit() {
        window.scrollTo(0, 0);
        this.getFiatBalance();
    }

    /** Function to get fiat balance */
    getFiatBalance() {
        // let data = {
        //     "eventExternal" : {
        //         "name" : "request_get_coin_list",
        //         "key" : "mykey"
        //     },
        //     "transferObjectMap" : {}
        // }
        // this.spinnerService.show();
        // this.server.postApi('',data).subscribe((succ) => {
        //     this.spinnerService.hide();
        //     if(succ.transferObjectMap.statusCode == 200) {
        //         let fiatArr = succ.transferObjectMap.coinList.filter((x) => x.coinType == "fiat");
        //         if(fiatArr.length) {
        //             this.user.usdBal = fiatArr.filter((x) => x.coinShortName == "USD")[0].balance;
        //         }
        //     } else if(succ.transferObjectMap.statusCode == 403){
        //         this.header.tokenExpire();
        //     } else {
        //         this.appC.showErrToast(succ.transferObjectMap.message);
        //     }
        // }, (err) => {
        //     this.spinnerService.hide();
        // });
        // let data = {
        //     "eventExternal": { 
        //         "name":"request_getBalance",
        //         "key":"mykey" 
        //     },
        //     "transferObjectMap": {
        //         "gatewayrequest": {
        //             "coinType":'USD',
        //             "token":localStorage.getItem('token')
        //         }
        //     }
        // }
        this.server.getApi("wallet/wallet/get-withdrawlist?coinName="+localStorage.getItem('token'),0).subscribe((succ) => {              
            if(succ.transferObjectMap.statusCode == 200) {
                this.user.usdBal = this.manageExponential((succ.transferObjectMap.result.walletBalance).toFixed(8));
            } else if(succ.transferObjectMap.statusCode == 403){
                this.header.tokenExpire();
            } else {
            }
        }, (err) => {
        });
    }

    /** Function to restrict space */
    restrictSpace(event) {
        var k = event.charCode;
        if (k === 32) return false;
    }

    /** Function to restrict character */
    restrictChar(event) {
        var k = event.charCode;
        if (event.key === 'Backspace')
            k = 8;
        if (k >= 48 && k <= 57 || k == 8 || k == 46)
            return true;
        else
            return false;    
    }

    /** Function to restrict length after dot */
    restrictLength() {
        if(this.withdrawObj.amount.includes(".")) {
            if (!this.regexForSixChar.test(this.withdrawObj.amount)) {
                let tempVal = this.withdrawObj.amount.split('.');
                this.withdrawObj.amount = tempVal[0] + '.' + tempVal[1].slice(0, 6);
            }
        }
    }

    /** Function for withdraw submit */
    withdrawSubmit() {
        if(this.withdrawObj.iban.trim().length == 0) {
            this.appC.showErrToast("Enter IBAN number.");
            return;
        } else if(this.withdrawObj.bic_swift_code.trim().length == 0) {
            this.appC.showErrToast("Enter BIC/Swift code.");
            return;
        } else if(this.withdrawObj.bank_name.trim().length == 0) {
            this.appC.showErrToast("Enter bank name.");
            return;
        } else if(this.withdrawObj.bank_address.trim().length == 0) {
            this.appC.showErrToast("Enter bank address.");
            return;
        } else if(this.withdrawObj.recipient_name.trim().length == 0) {
            this.appC.showErrToast("Enter recipent name.");
            return;
        } else if(this.withdrawObj.recipient_address.trim().length == 0) {
            this.appC.showErrToast("Enter recipent address.");
            return;
        } else if(this.withdrawObj.amount.trim().length == 0) {
            this.appC.showErrToast("Enter amount value.");
            return;
        } else if(this.withdrawObj.amount == ".") {
            this.appC.showErrToast("Enter valid amount value.");
            return;
        } else if(Number(this.withdrawObj.amount) <= 0) {
            this.appC.showErrToast("Enter valid amount value.");
            return;
        } else if(this.myImage == '') {
            this.appC.showErrToast("Please upload image.");
            return;
        } else if(Number(this.user.usdBal) < Number(this.withdrawObj.amount)) {
            this.appC.showErrToast("Sorry, you don't have enough amount to withdraw.");
            return;
        } else {
            let data = {
                "eventExternal": {
                    "name":"save_withdraw",
                    "key":"mykey"
                },
               "transferObjectMap": {
                   "gatewayrequest": {
                        "loginToken": localStorage.getItem('token'),
                        "paymentType": "bittnomy",
                        "templateId": null,
                        "bankAccountNumber": this.withdrawObj.iban,
                        "swiftCode": this.withdrawObj.bic_swift_code,
                        "accountHolderAddress": this.withdrawObj.recipient_address,
                        "accountHolderName": this.withdrawObj.recipient_name,
                        "bankName": this.withdrawObj.bank_name,
                        "bankAddress": this.withdrawObj.bank_address,
                        "withdrawAmount": this.withdrawObj.amount,
                        "currency": "USD",
                        "url": this.server.websiteURL+'header/withdrawVerify',
                        "attachment": this.myImage
                    }
                }
            }
            this.spinnerService.show();
            this.server.postApi('',data,0).subscribe((succ) => {
                this.spinnerService.hide();
                if(succ.transferObjectMap.statusCode == 200) {
                    this.appC.showSuccToast(succ.transferObjectMap.message);
                    this.getFiatBalance();
                    this.clearWithdrawObj();
                } else if(succ.transferObjectMap.statusCode == 403) {
                    this.header.tokenExpire();
                } else {
                    this.appC.showErrToast(succ.transferObjectMap.message);
                }
            }, (err) => {
                this.spinnerService.hide();
                this.appC.showErrToast("Something went wrong.");
            });
        }
    }

    /** Function to clear withdraw form */
    clearWithdrawObj() {
        this.withdrawObj.iban = "";
        this.withdrawObj.bic_swift_code = "";
        this.withdrawObj.bank_name = "";
        this.withdrawObj.bank_address = "";
        this.withdrawObj.recipient_name = "";
        this.withdrawObj.recipient_address = "";
        this.withdrawObj.amount = "";
    }

    /** Function to manage exponential data */
    manageExponential(num) {
        //if the number is in scientific notation remove it
        if (/\d+\.?\d*e[\+\-]*\d+/i.test(num)) {
            var zero = '0',
            parts = String(num).toLowerCase().split('e'), //split into coeff and exponent
            es = Number(parts.pop()), //store the exponential part
            l = Math.abs(es), //get the number of zeros
            sign = es / l,
            coeff_array = parts[0].split('.');
            if (sign === -1) {
                num = zero + '.' + new Array(l).join(zero) + coeff_array.join('');
            } else {
                var dec = coeff_array[1];
                if (dec) l = l - dec.length;
                num = coeff_array.join('') + new Array(l + 1).join(zero);
            }
            return num;
        } else {
            return num;
        }
    };

    /**Function to upload attachment */
    attachment(event) {
        var self = this;
        if(event.target.files && event.target.files[0]){
            var type = event.target.files[0].type;
            if(type === 'image/png' || type === 'image/jpg') {
                self.docFile = event.target.files[0].name;
                this.fileName = self.docFile;
                var reader = new FileReader()
                reader.onload = (e) =>  {
                    self.myImage = e.target['result'].substring(22);
                }
                reader.readAsDataURL(event.target.files[0]);
            }  else if(type === 'image/jpeg') {
                self.docFile = event.target.files[0].name;
                this.fileName = self.docFile;
                var reader = new FileReader()
                reader.onload = (e) =>  {
                    self.myImage = e.target['result'].substring(23);
                }
                reader.readAsDataURL(event.target.files[0]);
            } else {
                this.appC.showErrToast("Please select png, jpeg and jpg format.");
                self.docFile = "";
                
            }
        }
    }
}
