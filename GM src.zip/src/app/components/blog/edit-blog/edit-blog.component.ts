import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { ServiceService } from 'src/app/service/service.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { AppComponent } from 'src/app/app.component';

declare var $: any;

@Component({
  selector: 'app-edit-blog',
  templateUrl: './edit-blog.component.html',
  styleUrls: ['./edit-blog.component.css']
})
export class EditBlogComponent implements OnInit, OnDestroy {

  editBlogForm: FormGroup;
  fileData: any = {};
  paramData: any;
  userInfo: any;
  apiResponse: any = { status: 626 };
  selectedFileName: any;
  subscription: any;

  constructor(
    private service: ServiceService,
    private spinner: NgxSpinnerService,
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private appC: AppComponent
  ) {
    this.subscription = this.service.authVerify.subscribe(val => {
      if (val == 'edit-blog') {
        this.editBlog();
        this.service.authVerify.next('false');
      }
    });
  }

  ngOnInit() {
    window.scrollTo(0, 0);
    this.form();
    this.getIpAddress();
    this.getParamData();
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  /** Function to verify google authentication */
  verifyGoogleAuth() {
    if (this.editBlogForm.invalid || !this.fileData.valid || !this.fileData.url) {
      return;
    }
    this.appC.google = { one: '', two: '', three: '', four: '', five: '', six: '' };
    this.appC.response = { 'message': '' };
    this.service.googleAuthCalledFrom = 'edit-blog';
    $('#google-auth-modal').modal({ keyboard: false, backdrop: 'static' });

  }

  form() {
    this.editBlogForm = new FormGroup({
      title: new FormControl('', [Validators.required, Validators.minLength(2), Validators.maxLength(255)]),
      detail: new FormControl('', [Validators.required, Validators.minLength(2)]),
      authorBy: new FormControl('', [Validators.required, Validators.minLength(2), Validators.maxLength(255)])
    });
  }

  getParamData() {
    this.activatedRoute.params.subscribe(param => {
      this.paramData = param;
      this.getBlogData();
    });
  }

  getIpAddress() {
    this.service.userInfo.subscribe(success => {
      this.userInfo = success;
    });
  }

  getBlogData() {
    this.spinner.show();
    this.service.postMethod(`blog/admin/get-blog-detail?contentId=${encodeURIComponent(this.service.encrypt(this.paramData.id))}&language=${encodeURIComponent(this.service.encrypt(this.paramData.lang))}`, {}, 1).subscribe(success => {
      this.spinner.hide();
      if (success.status === 628) {
        this.editBlogForm.patchValue({
          title: success.data.title,
          detail: success.data.description,
          authorBy: success.data.author
        });
        this.fileData.fileData = success.data.image;
        this.selectedFileName = success.data.image;
        this.fileData.url = success.data.image;
        this.fileData.valid = true;
      }
    }, error => {
      this.spinner.hide();
    });
  }

  editBlog() {
    if (this.editBlogForm.invalid || !this.fileData.valid || !this.fileData.url) {
      return;
    }
    this.spinner.show();
    const data = JSON.stringify({
      author: this.editBlogForm.value.authorBy,
      description: this.editBlogForm.value.detail,
      title: this.editBlogForm.value.title,
      slug: this.editBlogForm.value.title.trim().replace(' ', '_'),
      ipAddress: this.userInfo.ip,
      location: this.userInfo.city + ',' + this.userInfo.country_name,
      image: this.fileData.url
    });
    const formData = new FormData();
    formData.append('blogDto', this.service.encrypt(data));
    formData.append('contentId', this.service.encrypt(this.paramData.id));
    this.service.postMethod('blog/admin/edit-blog-detail', formData, 2).subscribe(success => {
      this.spinner.hide();
      if (success.status === 626) {
        this.router.navigate(['/blog-management']);
      } else {
        this.apiResponse = success;
      }
    }, error => {
      this.spinner.hide();
      this.apiResponse.status = error.error.status;
      this.apiResponse.message = error.error.error;
    });
  }

  getFile(event) {
    this.fileData = this.service.uploadImage(event);
    this.selectedFileName = this.fileData.fileData.name;
    if (this.fileData.error === 'formatError') {
      this.fileData.error = 'Image accept only jpg, jpeg, png format.';
    } else {
      if (this.fileData.error === 'sizeError') {
        this.fileData.error = 'Image size should be less than 5Mb.';
      }
    }
    if (this.fileData.valid) {
      this.uploadFile();
    }
  }

  uploadFile() {
    this.spinner.show();
    const formData = new FormData();
    formData.append('file', this.fileData.fileData);
    this.service.postMethod('account/uploadFile', formData, 2).subscribe(success => {
      this.spinner.hide();
      this.fileData.url = success.fileName;;
    }, error => {
      this.spinner.hide();
      this.fileData.url = null;
    });
  }

}
