import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportFiatWithdrawComponent } from './report-fiat-withdraw.component';

describe('ReportFiatWithdrawComponent', () => {
  let component: ReportFiatWithdrawComponent;
  let fixture: ComponentFixture<ReportFiatWithdrawComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReportFiatWithdrawComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReportFiatWithdrawComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
