import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StandardTradingComponent } from './standard-trading.component';

describe('StandardTradingComponent', () => {
  let component: StandardTradingComponent;
  let fixture: ComponentFixture<StandardTradingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StandardTradingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StandardTradingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
