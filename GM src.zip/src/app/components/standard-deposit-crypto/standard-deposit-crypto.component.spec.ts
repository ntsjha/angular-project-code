import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StandardDepositCryptoComponent } from './standard-deposit-crypto.component';

describe('StandardDepositCryptoComponent', () => {
  let component: StandardDepositCryptoComponent;
  let fixture: ComponentFixture<StandardDepositCryptoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StandardDepositCryptoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StandardDepositCryptoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
