import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { GooglePlaceDirective } from 'ngx-google-places-autocomplete';
import { Address } from 'ngx-google-places-autocomplete/objects/address';
declare var google:any;
/**
 * Generated class for the ProfilePage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-profile',
  templateUrl: 'profile.html',
})
export class ProfilePage {
  lat: number = 51.678418;
  lng: number = 7.809007;
  teacher: any;
  item: any;
  map: any;
  message:any;
  constructor(public navCtrl: NavController, public navParams: NavParams) {
  }

  ngOnInit() {
    
    this.item = JSON.parse(localStorage.getItem('teacher'));
    
   //   this.empinfo=this.serve.empp;
   //  console.log(this.empinfo)
   console.log(this.item);
   //console.log(this.teacher[i].teacherlatlng.lat,this.teacher[i].teacherlatlng.lng);
   this.initializeMap(this.item[0].teacherlatlng.lat,this.item[0].teacherlatlng.lng)
       
   }
  initializeMap(Lattt,lnggg){
    console.log(Lattt,lnggg)
    var mapProp = {
        center:new google.maps.LatLng(Lattt,lnggg),
        zoom:5,
    };
    this.map = new google.maps.Map(document.getElementById("googleMap"),mapProp);
    for(let i=0;i<this.item.length;i++){
      console.log(this.item[i].teacherlatlng.lat,this.item[i].teacherlatlng.lng);
      this.addMarker(this.item[i].teacherlatlng.lat,this.item[i].teacherlatlng.lng);
    }
    
   }
  
   addMarker(lat1,lng1){

    var contentString =(this.item);

     console.log(lat1,lng1);
     var infowindow = new google.maps.InfoWindow({
      content: contentString
    });

    var myLatLng = {lat:lat1, lng:lng1};
    var marker = new google.maps.Marker({
      position: myLatLng,
      map: this.map,
      title: 'Hello World!'

    });
    marker.addListener('click', function() {
      infowindow.open(this.map,marker);
    });

    marker.setMap(this.map);
   }
   

}
