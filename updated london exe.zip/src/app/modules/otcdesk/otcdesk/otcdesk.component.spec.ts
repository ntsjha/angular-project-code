import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OtcdeskComponent } from './otcdesk.component';

describe('OtcdeskComponent', () => {
  let component: OtcdeskComponent;
  let fixture: ComponentFixture<OtcdeskComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OtcdeskComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OtcdeskComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
