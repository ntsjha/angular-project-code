import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ServerService } from '../../../service/server.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { AppComponent } from '../../../app.component';
import { HeaderComponent } from '../../header/header/header.component';
declare var $: any;

@Component({
    selector: 'app-buysell',
    templateUrl: './buysell.component.html',
    styleUrls: ['./buysell.component.css']
})
export class BuysellComponent implements OnInit {
    pairArr = [];
    baseCoinArr = [];
    currTab = "BUY";
    exchangeObj = {baseCoin:"", baseCoinId:"", exeCoin:"", exeCoinId:"", amtToSpend:"", amtToReceive:"", currValue:""};
    userObj = {availBal:""};
    baseCoinObj = {coin:"", coinId:""};
    executableCoinObj = {coin:"", coinId:""};
    regexForEightChar = (/^(\d+)?([*]?\d{0,8})?$/);
    reqData: any;
    allCoinArr = [];
    mySymbol = "";

    constructor(private router: Router, private server: ServerService, private appC: AppComponent, private spinnerService: Ng4LoadingSpinnerService, public header: HeaderComponent) {
        var self = this;
        this.server.wsExchange.addEventListener('message', function (event) {
            let data = JSON.parse(event.data); 
            console.log("socket data -> ",data);
            if(data.payload.userSpecific) {
                self.getCoinPrice(self.exchangeObj.baseCoinId,self.exchangeObj.exeCoinId);
            }
        });
        this.server.liqWSObj.addEventListener('message', function (event) {
            let data = JSON.parse(event.data);
            if(data.params) {
                console.log("data -> ",data);
                self.exchangeObj.currValue = data.params.last;
            }
        });
    }

    ngOnInit() {
        this.currTab = "BUY";
        this.getCoinList();
        $(document).ready(function() {
            $('[data-toggle="tooltip"]').tooltip();
        });
    }

    ngOnDestroy() {
        this.manageLiquiditySocket(2);
    }

    /** Function to get coin list from api */
    getCoinList() {
        // let data = {
        //     "eventExternal": {
        //       "name": "request_get_coin_list",
        //       "key": "mykey"
        //     },
        //     "transferObjectMap": {
        //         "gatewayrequest": {}
        //     }
        // }
        this.spinnerService.show();
        this.server.getApi('wallet/coin/get-coin-list', 0).subscribe((succ) => {
            this.spinnerService.hide();
            if(succ.body.status == 200) {
                this.baseCoinArr = [];
                this.allCoinArr = succ.body.data;
                succ.body.data.forEach((obj) => {
                    if(obj.coinShortName == 'BTC' || obj.coinShortName == 'ETH' || obj.coinShortName == 'USD' || obj.coinShortName == 'GBP' || obj.coinShortName == 'EUR')  {
                        this.baseCoinArr.push({
                            coin: obj.coinShortName,
                            coinId: obj.coinId,
                            coinType: obj.coinType
                        });
                    }
                });
                if(this.baseCoinArr.length) {
                    this.exchangeObj.baseCoin = this.baseCoinArr[0].coin;
                    this.exchangeObj.baseCoinId = this.baseCoinArr[0].coinId;
                    this.getCoinPair(this.exchangeObj.baseCoin,this.exchangeObj.baseCoinId,this.baseCoinArr[0].coinType);
                }
            }
        }, (err) => {
            this.spinnerService.hide();
        });
    }

    /** Function to get coin pair of selected coin */
    getCoinPair(coinName,coinId,coinType) {
      
        this.spinnerService.show();
        this.server.getApi('wallet/coin/get-coin-pair-list?baseCoin=' + coinName, 0).subscribe((succ) => {
          console.log('coin Pair==>',coinName,coinId,coinType)
            this.spinnerService.hide();
            if(succ.body.status == 200) {
                this.pairArr = [];
                succ.body.data.forEach((obj) => {
                    if(coinType == "crypto") {
                        if(obj.coinType == "crypto" && obj.coinShortName == 'BTC' || obj.coinShortName == 'ETH' || obj.coinShortName == 'XRP' || obj.coinShortName == 'NEO' || obj.coinShortName == 'LCX' || obj.coinShortName == 'DASH' || obj.coinShortName == 'LTC' || obj.coinShortName == 'XLM' || obj.coinShortName == 'XVG' ) {
                            this.pairArr.push({                            
                                baseCoin: coinName,
                                baseCoinId: coinId,
                                executeableCoin: obj.coinShortName,
                                executeableCoinId: obj.coinId,
                                label: obj.coinShortName+"/"+coinName
                            });
                        }
                    }    
                    if(coinType == "fiat") {
                        if(obj.coinType == "crypto") {
                            this.pairArr.push({                            
                                baseCoin: coinName,
                                baseCoinId: coinId,
                                executeableCoin: obj.coinShortName,
                                executeableCoinId: obj.coinId,
                                label: obj.coinShortName+"/"+coinName
                            });
                        }
                    }                
                });
                if(this.pairArr.length) {
                    this.exchangeObj.exeCoin = this.pairArr[0].executeableCoin;
                    this.exchangeObj.exeCoinId = this.pairArr[0].executeableCoinId;
                    this.mySymbol = this.pairArr[0].label;
                    this.manageLiquiditySocket(1);
                    // this.getCoinPrice(this.exchangeObj.baseCoinId,this.exchangeObj.exeCoinId);
                    switch(this.currTab) {
                        case 'BUY':
                            this.getUserBalance(this.exchangeObj.baseCoinId);
                            break;
                        case 'SELL':
                            this.getUserBalance(this.exchangeObj.exeCoinId);
                            break;
                    }
                }
            } else {
                this.appC.showErrToast(succ.body.message);
            }
        }, (err) => {
            this.spinnerService.hide();
        });
    }

    /** Function for change base coin */
    baseCoinChangeFunc() {
        this.clearObj();
        this.manageLiquiditySocket(2);
        this.exchangeObj.baseCoin = this.baseCoinArr.filter((obj) => obj.coinId == this.exchangeObj.baseCoinId)[0].coin;
        let coinType = this.baseCoinArr.filter((obj) => obj.coinId == this.exchangeObj.baseCoinId)[0].coinType;        
        this.getCoinPair(this.exchangeObj.baseCoin,this.exchangeObj.baseCoinId,coinType);
    }

    /** Function for select tab */
    tabSelect(type) {
        switch(type) {
            case 1:
                this.currTab = "BUY";
                this.clearObj();
                this.getUserBalance(this.exchangeObj.baseCoinId);
                break;
            case 2:
                this.currTab = "SELL";
                this.clearObj();
                this.getUserBalance(this.exchangeObj.exeCoinId);
                break;
        }
    }

    /** Function for pair change */
    pairChangeFunc() {
        this.clearObj();
        this.exchangeObj.exeCoin = this.pairArr.filter((obj) => obj.executeableCoinId == this.exchangeObj.exeCoinId)[0].executeableCoin;
        this.manageLiquiditySocket(2);
        this.mySymbol = this.pairArr.filter((obj) => obj.executeableCoinId == this.exchangeObj.exeCoinId)[0].label;
        this.manageLiquiditySocket(1);
        // this.getCoinPrice(this.exchangeObj.baseCoinId,this.exchangeObj.exeCoinId);
        switch(this.currTab) {
            case 'BUY':
                this.getUserBalance(this.exchangeObj.baseCoinId);                
                break;
            case 'SELL':
                this.getUserBalance(this.exchangeObj.exeCoinId);
                break;
        }
    }

    /** Function to clear exchange obj */
    clearObj() {
        this.exchangeObj.amtToReceive = "";
        this.exchangeObj.amtToSpend = "";
    }

    /** Function to get coin price based on selected coin */
    getCoinPrice(baseId,exeId) {
        let data = {
            "eventExternal":{
                "name":"request_get_header_data",
                "key":"mykey"
            },
            "transferObjectMap":{
                "gatewayrequest": {  
                    "baseCurrency": baseId,
                    "executableCurrency": exeId
                }
            }
        }
        this.spinnerService.show();
        this.server.post('',data).subscribe((succ) => {
            this.spinnerService.hide();
            if(succ.transferObjectMap.statusCode == 200) {
                this.exchangeObj.currValue = succ.transferObjectMap.lastPrice;
            }
        }, (err) => {
            this.spinnerService.hide();
        });
    }

    /** Function to get user balance */
    getUserBalance(coinId) {
       
        this.server.getApi("wallet/wallet/get-balance?coinName="+this.exchangeObj.baseCoin,localStorage.getItem('token')).subscribe((succ) => {
            if(succ.body.status == 200) {
                this.userObj.availBal = succ.body.data.walletBalance;
            } else if(succ.body.statusCode == 403){
                this.header.tokenExpire()
            } else {
                this.appC.showErrToast(succ.body.message);
            }
        }, (err) => {
            this.spinnerService.hide();
        });
    }

    /** Function to restrict space */
    restrictSpace(event) {
        var k = event.charCode;
        if (k === 32) return false;
    }

    /** Function to restrict character */
    restrictChar(event) {
        var k = event.charCode;
        if (event.key === 'Backspace')
            k = 8;
        if (k >= 48 && k <= 57 || k == 8 || k == 46)
            return true;
        else
            return false;    
    }

    /** Function to restrict length after dot */
    restrictLength(type) {
        switch(type) {
            case 'as':
                if(this.exchangeObj.amtToSpend.includes(".")) {
                    if (!this.regexForEightChar.test(this.exchangeObj.amtToSpend)) {
                        let tempVal = this.exchangeObj.amtToSpend.split('.');
                        this.exchangeObj.amtToSpend = tempVal[0] + '.' + tempVal[1].slice(0, 8);
                    }
                }
                break;
        }
    }

    /** Function to calculate total amount */
    valueChangeFunc(type) {
        switch(type) {
            case 'AS':
                if(this.currTab == "SELL") {
                    if(this.exchangeObj.amtToSpend && this.exchangeObj.currValue && Number(this.exchangeObj.amtToSpend) >= 0 && Number(this.exchangeObj.currValue) >= 0) {
                        this.exchangeObj.amtToReceive = (Number(this.exchangeObj.amtToSpend) * Number(this.exchangeObj.currValue)).toFixed(8);
                    } else {
                        this.exchangeObj.amtToReceive = "";
                    }
                }
                if(this.currTab == "BUY") {
                    if(this.exchangeObj.amtToSpend && this.exchangeObj.currValue && Number(this.exchangeObj.amtToSpend) >= 0 && Number(this.exchangeObj.currValue) >= 0) {
                        this.exchangeObj.amtToReceive = (Number(this.exchangeObj.amtToSpend) / Number(this.exchangeObj.currValue)).toFixed(8);
                    } else {
                        this.exchangeObj.amtToReceive = "";
                    }
                }                
                break;
        }
    }

    /** Function for confirm button */
    confirmFunc() {
        if(this.exchangeObj.amtToReceive == "") {
            this.appC.showErrToast("Amount to be received is mandatory.");
            return;
        } else if(Number(this.exchangeObj.amtToReceive) <= 0) {
            this.appC.showErrToast("Enter valid amount for buy/sell.");
            return;
        } else if(Number(this.exchangeObj.amtToSpend) > Number(this.userObj.availBal)) {
            this.appC.showErrToast("You can't buy/sell more then your wallet balance.");
            return;
        } else {
            switch(this.currTab) {
                case 'BUY':
                    this.reqData =  {
                      
                            "tradingType": "BASIC",
                            "orderType": "BUY", 
                            "amount": this.exchangeObj.amtToSpend,
                            "price": this.exchangeObj.currValue,
                            "baseCurrency": this.exchangeObj.baseCoinId,
                            "executableCurrency": this.exchangeObj.exeCoinId, 
                            "tradeStop": 0.0,
                            "tradeLimit": 0.0,
                            "loginToken": localStorage.getItem('token')
                       
                    }
                    break;
                case 'SELL':
                    this.reqData =  {
                        "eventExternal":  {
                            "name":"request_sell_add_order",
                            "key":"mykey"
                        },
                        "transferObjectMap": {
                            "tradingType": "BASIC",
                            "orderType": "SELL", 
                            "amount": this.exchangeObj.amtToSpend,
                            "price": this.exchangeObj.currValue,
                            "baseCurrency": this.exchangeObj.baseCoinId,
                            "executableCurrency": this.exchangeObj.exeCoinId, 
                            "tradeStop": 0.0,
                            "tradeLimit": 0.0,
                            "loginToken": localStorage.getItem('token')
                        } 
                    }
                    break;
            }
            console.log("data -> ",this.reqData);
            this.spinnerService.show();
            this.server.post('',this.reqData).subscribe((succ) => {
                this.spinnerService.hide();
                if(succ.transferObjectMap.statusCode == 200) {
                    this.clearObj();
                    this.appC.showInfoToast(succ.transferObjectMap.message);            
                    switch(this.currTab) {
                        case 'BUY':
                            this.getUserBalance(this.exchangeObj.baseCoinId);                
                            break;
                        case 'SELL':
                            this.getUserBalance(this.exchangeObj.exeCoinId);
                            break;
                    }
                } else if(succ.transferObjectMap.statusCode == 403) {
                    this.header.tokenExpire();
                } else {
                    this.appC.showErrToast(succ.transferObjectMap.message);
                    this.clearObj();
                }
            }, (err) => {
                this.spinnerService.hide();
            });
        }
    }

    /** Function for navigate to respected screen when click on add */
    goToAddBalance() {
        switch(this.currTab) {
            case 'BUY':
                if(this.exchangeObj.baseCoin == "BTC" || this.exchangeObj.baseCoin == "ETH") {
                    this.router.navigateByUrl('/header/wallet');
                } else if(this.exchangeObj.baseCoin == "USD" || this.exchangeObj.baseCoin == "GBP" || this.exchangeObj.baseCoin == "EUR") {
                    this.router.navigateByUrl('/header/account');
                }
                break;
            case 'SELL':
                this.router.navigateByUrl('/header/wallet');
                break;
        }
    }

    /** Function for manage liquidit socket event */
    manageLiquiditySocket(type) {
        let data = {
            "method": "",
            "params": {
                "symbol": this.mySymbol.replace("/","").replace("GBP","USD"),
                "limit": ""
            },
            "id": "LCX"
        }
        switch(type) {
            case 1:
                if(this.server.liqWSObj.readyState) {
                    data.method = "subscribeTicker";
                    this.server.liqWSObj.send(JSON.stringify(data));
                }          
                break;
            case 2:
                this.exchangeObj.currValue = "";
                if(this.server.liqWSObj.readyState) {
                    data.method = "unsubscribeTicker";
                    this.server.liqWSObj.send(JSON.stringify(data));
                }                
                break;
        }
    }
}
