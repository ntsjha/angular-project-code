import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddmachineReadingComponent } from './addmachine-reading.component';

describe('AddmachineReadingComponent', () => {
  let component: AddmachineReadingComponent;
  let fixture: ComponentFixture<AddmachineReadingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddmachineReadingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddmachineReadingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
