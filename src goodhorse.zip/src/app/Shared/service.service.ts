import { Injectable } from '@angular/core';
import { AngularFireAuth } from '@angular/fire/auth';
import { AngularFirestore, AngularFirestoreDocument } from '@angular/fire/firestore';
import * as firebase from 'firebase/app';
import { Router } from '@angular/router';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Employee } from './employee.model';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import 'firebase/storage';

interface User {
  uid: string;
  email: string;
  photoURL?: string;
  displayName?: string;
  
}
@Injectable({
  providedIn: 'root'
})
export class ServiceService {
  private snapshotChangesSubscription: any;
  formData: Employee;
  userData : any;
  constructor(private afAuth: AngularFireAuth,
    private afs: AngularFirestore,
    private router: Router,
    private spinner: NgxSpinnerService,
    private toastr: ToastrService,
    
    ) { }

   
    
  private updateUserData(user) {
    // Sets user data to firestore on login

    const userRef: AngularFirestoreDocument<any> = this.afs.doc(`users/${user.uid}`);
    const data: User = {
      uid: user.uid,
      email: user.email,
      displayName: user.displayName,
      photoURL: user.photoURL
    }
    console.log('USER==>')
    return userRef.set(data, { merge: true })
  }
  getEmployees() {
    return this.afs.collection('people').snapshotChanges();
  }
  getContributor() {
    return this.afs.collection('people').snapshotChanges();
  }
 

  getHorseList(userid){
    return this.afs.collection('people').doc(userid).collection('Horses').snapshotChanges();
  }

  getHorseHealth(){
    return this.afs.collection('GlobalFeedList').snapshotChanges();
  }

  getHorserHealthRugs(){
    return this.afs.collection('GlobalRugList').snapshotChanges();
  }

  getHorseHealthService(){
    return this.afs.collection('GlobalServiceList').snapshotChanges();
  }

  getEmployeeDetails(){
    return this.afs.collection('people').snapshotChanges()
  }

  getHorseTack(userId,horseId){
    return this.afs.collection('people').doc(userId).collection('Horses').doc(horseId).collection('horseTacks').snapshotChanges();
  }

  // ***************globle tack****************** //
  getGlobalTack(){
    return this.afs.collection('GlobalTackList').snapshotChanges();
  }


  getHorseTraining(){
    return this.afs.collection('GlobalTrainingList').snapshotChanges();
  }

 

  getHorseEvents(){
    return this.afs.collection('Events').snapshotChanges();
  }
  getHorseContact(){
    return this.afs.collection('contacts').snapshotChanges();
  }

  getAdminTrainingTemplate(){
    return this.afs.collection('adminTrainingTemplate').snapshotChanges();
  }

  getSubscriptionplan() {
    return this.afs.collection('SubscriptionPlan').snapshotChanges();
  }

  doRegister(value){
    return new Promise<any>((resolve, reject) => {
      firebase.auth().createUserWithEmailAndPassword(value.email, value.password)
      .then(
        res => resolve(res),
        err => reject(err))
    })
   }
  
  emailLogin(email: string, password: string) {
    this.showSpinner();
      return this.afAuth.auth
      .signInWithEmailAndPassword(email, password)
      .then(credential => {
       console.log(credential);
        // this.showSuccess('Successfully Login');
        localStorage.setItem('key', credential.user.uid);
         this.spinner.hide();
        this.router.navigate(['/dash']);       
        return this.updateUserData(credential.user);        
      })
      .catch(error => this.toastErr('Invalid user')
      );
      
  }
deleuserfromuAuth(email: string, userid: string){
  console.log('User Deleted===>',email,userid)
  firebase.auth().signInWithEmailAndPassword(email, userid)
    .then(function (info) {
       var user = firebase.auth().currentUser;
       console.log('User Deleted===>',user)
       user.delete();
       
    });
  }

  showSuccess(msg) {
    this.toastr.success(msg);
    }
    toastErr(msg) {
   this.toastr.error(msg);  
    }    
  resetPassword(email) {
    var auth = firebase.auth();
    return auth.sendPasswordResetEmail(email)
      .then(() => {
        this.showSuccess('Email has been sent to the registered email address.');
        this.router.navigate(['/'])
      })
      .catch((error) => {
        console.log(error)
        this.toastErr(error.message);
      })
  }



  // ********Add subscriptionplan ******************
  addsubscriptionplan(value){
    return new Promise<any>((resolve,reject)=>{
      let currentUser = firebase.auth().currentUser;
      this.snapshotChangesSubscription = this.afs.collection('SubscriptionPlan').doc('SubscriptionPlan').set(
        { BreedType: value },
        { merge: true }
      )
      .then(res=>{
        resolve(res)
      }).catch(err => {
        reject(err)
      })
    })
  }  


  // ********Get BreedType dropdown ******************
  getBreedTypeFunc(){
    return new Promise<any>((resolve,reject)=>{
      let currentUser = firebase.auth().currentUser;
      this.snapshotChangesSubscription = this.afs.collection('BreedType').valueChanges()
    .subscribe(snapshots => {      
      resolve(snapshots);
    })
    })
  }

  // ********add NewBreed dropdown ******************
  addNewBreedFunc(value){
    return new Promise<any>((resolve,reject)=>{
      let currentUser = firebase.auth().currentUser;
      this.snapshotChangesSubscription = this.afs.collection('BreedType').doc('BreedType').set(
        { BreedType: value },
        { merge: true }
      )
      .then(res=>{
        resolve(res)
      }).catch(err => {
        reject(err)
      })
    })
  }

  

  // ********get ColorType dropdown ******************
  getColorTypeFunc(){
    return new Promise<any>((resolve,reject)=>{
      let currentUser = firebase.auth().currentUser;
      this.snapshotChangesSubscription = this.afs.collection('ColorType').valueChanges()
    .subscribe(snapshots => {      
      resolve(snapshots);
    })
    })
  }

  // ********Add  NewColourdropdown ******************
  addNewColourFunc(value){
    return new Promise<any>((resolve,reject)=>{
      let currentUser = firebase.auth().currentUser;
      this.snapshotChangesSubscription = this.afs.collection('ColorType').doc('ColorType').set(
        { ColorType: value },
        { merge: true }
      )
      .then(res=>{
        resolve(res)
      }).catch(err => {
        reject(err)
      })
    })
  }

  // ********Get  NewServiceType dropdown ******************
  getServiceTypeFunc(){
    return new Promise<any>((resolve,reject)=>{
      let currentUser = firebase.auth().currentUser;
      this.snapshotChangesSubscription = this.afs.collection('ServiceType').valueChanges()
    .subscribe(snapshots => {      
      resolve(snapshots);
    })
    })
  }

  // ********Add NewServiceType dropdown ******************
  addNewServiceTypeFunc(value){
    return new Promise<any>((resolve,reject)=>{
      let currentUser = firebase.auth().currentUser;
      this.snapshotChangesSubscription = this.afs.collection('ServiceType').doc('ServiceType').set(
        { ServiceType: value },
        { merge: true }
      )
      .then(res=>{
        resolve(res)
      }).catch(err => {
        reject(err)
      })
    })
  }

  // ********Get TackTypeList dropdown ******************
  getTackTypeListFunc(){
    return new Promise<any>((resolve,reject) => {
      let currentUser = firebase.auth().currentUser;
      this.snapshotChangesSubscription = this.afs.collection('TackTypes').doc('TackType').valueChanges().subscribe(snapshots => {
        resolve(snapshots)
      })
    });
  }


  // ********Add  NewTackType  dropdown ******************
  addNewTackTypeFunc(value){
    return new Promise<any>((resolve,reject)=>{
      let currentUser = firebase.auth().currentUser;
      this.snapshotChangesSubscription = this.afs.collection('TackTypes').doc('TackType').set(
        { TackType: value },
        { merge: true }
      )
      .then(res=>{
        resolve(res)
      }).catch(err => {
        reject(err)
      })
    })
  }

  // ********Get TackBrandList  dropdown ******************
  getTackBrandListFunc(){
    return new Promise<any>((resolve,reject) => {
      let currentUser = firebase.auth().currentUser;
      this.snapshotChangesSubscription = this.afs.collection('TackTypes').doc('TackBrand').valueChanges().subscribe(snapshots => {
        resolve(snapshots)
      })
    });
  }



  // ********Add NewTackBrand  dropdown ******************
  addNewTackBrandFunc(value){
    return new Promise<any>((resolve,reject)=>{
      let currentUser = firebase.auth().currentUser;
      this.snapshotChangesSubscription = this.afs.collection('TackTypes').doc('TackBrand').set(
        { TackBrand: value },
        { merge: true }
      )
      .then(res=>{
        resolve(res)
      }).catch(err => {
        reject(err)
      })
    })
  }

  // ********Get TackUseList  dropdown ******************
  getTackUseListFunc(){
    return new Promise<any>((resolve,reject) => {
      let currentUser = firebase.auth().currentUser;
      this.snapshotChangesSubscription = this.afs.collection('TackTypes').doc('TackUse').valueChanges().subscribe(snapshots => {
        resolve(snapshots)
      })
    });
  }


  // ********Add NewTackUse  dropdown ******************
  addNewTackUseFunc(value){
    return new Promise<any>((resolve,reject)=>{
      let currentUser = firebase.auth().currentUser;
      this.snapshotChangesSubscription = this.afs.collection('TackTypes').doc('TackUse').set(
        { TackUse: value },
        { merge: true }
      )
      .then(res=>{
        resolve(res)
      }).catch(err => {
        reject(err)
      })
    })
  }

  // ********Get DisciplineType  dropdown ******************
  getDisciplineTypeFunc(){
    return new Promise<any>((resolve,reject) => {
      let currentUser = firebase.auth().currentUser;
      this.snapshotChangesSubscription = this.afs.collection('Discipline').doc('Discipline').valueChanges().subscribe(snapshots => {
        resolve(snapshots)
      })
    });
  }

  // ********Add  NewDisciplineUse  dropdown ******************
  addNewDisciplineUseFunc(value){
    return new Promise<any>((resolve,reject)=>{
      let currentUser = firebase.auth().currentUser;
      this.snapshotChangesSubscription = this.afs.collection('Discipline').doc('Discipline').set(
        { Discipline: value },
        { merge: true }
      )
      .then(res=>{
        resolve(res)
      }).catch(err => {
        reject(err)
      })
    })
  }
 
  // ********Get  NewDisciplineTackuse  dropdown ******************
  getDisciplineTackuseFunc(){
    return new Promise<any>((resolve,reject) => {
      let currentUser = firebase.auth().currentUser;
      this.snapshotChangesSubscription = this.afs.collection('Discipline').doc('Discipline').valueChanges().subscribe(snapshots => {
        resolve(snapshots)
      })
    });
  }

  // ********Add  NewDisciplineTackuse  dropdown ******************
  addNewDisciplineTackuseFunc(value){
    return new Promise<any>((resolve,reject)=>{
      let currentUser = firebase.auth().currentUser;
      this.snapshotChangesSubscription = this.afs.collection('Discipline').doc('Discipline').set(
        { TackUse: value },
        { merge: true }
      )
      .then(res=>{
        resolve(res)
      }).catch(err => {
        reject(err)
      })
    })
  }

  // ********Add  NewActivitytype  dropdown ******************
  getActivitytypeFunc(){
    return new Promise<any>((resolve,reject) => {
      let currentUser = firebase.auth().currentUser;
      this.snapshotChangesSubscription = this.afs.collection('ActivityList').doc('ActivityList').valueChanges().subscribe(snapshots => {
        resolve(snapshots)
      })
    });
  }

  // ********Add  NewActivitytype  dropdown ******************
  addNewActivitytypeFunc(value){
    return new Promise<any>((resolve,reject)=>{
      let currentUser = firebase.auth().currentUser;
      this.snapshotChangesSubscription = this.afs.collection('ActivityList').doc('ActivityList').set(
        { ActivityList: value },
        { merge: true }
      )
      .then(res=>{
        resolve(res)
      }).catch(err => {
        reject(err)
      })
    })
  }

  // ******** Get RugType  dropdown ******************
  getRugtypeFunc(){
    return new Promise<any>((resolve,reject) => {
      let currentUser = firebase.auth().currentUser;
      this.snapshotChangesSubscription = this.afs.collection('RugType').doc('RugType').valueChanges().subscribe(snapshots => {
        resolve(snapshots)
      })
    });
  }


  // ******** Add RugType  dropdown according to types******************
  addRugtypesFunc(value,containt){
    return new Promise<any>((resolve,reject)=>{
      let currentUser = firebase.auth().currentUser;
      console.log('addNewRugtypeFunc',value,containt)
      if(containt=='Temperature'){
         this.snapshotChangesSubscription = this.afs.collection('RugType').doc('RugType').set(
        { Temperature: value },
        { merge: true }
        )
        .then(res=>{
          resolve(res)
        }).catch(err => {
          reject(err)
        })
      }
      else if(containt=='Type'){
        this.snapshotChangesSubscription = this.afs.collection('RugType').doc('RugType').set(
       { Type: value },
       { merge: true }
       )
       .then(res=>{
        resolve(res)
      }).catch(err => {
        reject(err)
      })
        }
      else if(containt=='Weather'){
        this.snapshotChangesSubscription = this.afs.collection('RugType').doc('RugType').set(
       { Weather: value },
       { merge: true }
       )
       .then(res=>{
        resolve(res)
      }).catch(err => {
        reject(err)
      })
     }
     else if(containt=='When'){
      this.snapshotChangesSubscription = this.afs.collection('RugType').doc('RugType').set(
     { When: value },
     { merge: true }
     )
     .then(res=>{
      resolve(res)
    }).catch(err => {
      reject(err)
    })
    }
    else{
      this.toastErr('Something went wrong')
    }
     
     
    })
  }


  // ******** Get feed-Sub menu data of dropdown ******************
  getFeedFunc(data){
    return new Promise<any>((resolve,reject) => {
      let currentUser = firebase.auth().currentUser;
      this.snapshotChangesSubscription = this.afs.collection('FeedType').doc(data).valueChanges().subscribe(snapshots => {
        resolve(snapshots)
      })
    });
  }



  // ******** get data of  feedType dropdown ******************
  getFeedTypeFunc(){
   
      return  this.afs.collection('FeedType').snapshotChanges();
      
  }


  // ******** Add Sub menu of feedType dropdown ******************
  addSubFeedType(condition,docname,value){
    console.log('FEED',condition,docname,value)
    return new Promise<any>((resolve,reject)=>{
      let currentUser = firebase.auth().currentUser;
      if(condition=='Feed'){
      this.snapshotChangesSubscription = this.afs.collection('FeedType').doc(docname).set(
        { Feed: value },
        { merge: true }
      )
      .then(res=>{
        resolve(res)
      }).catch(err => {
        reject(err)
      })

      }
      else if(condition=='unit'){
        this.snapshotChangesSubscription = this.afs.collection('FeedType').doc(docname).set(
          { unit: value },
          { merge: true }
        )
        .then(res=>{
          resolve(res)
        }).catch(err => {
          reject(err)
        })
      }
      else{
        this.toastErr("Something went wrong")
      }
    
    })
  }  

   // ********Get Static Content data ******************

   getStaticContentFunc(docname){
     if(docname=='FAQ'){
      // return this.afs.collection('SubscriptionPlan').doc(docname).collection(docname).snapshotChanges();
    //   return new Promise<any>((resolve,reject)=>{
    //     let currentUser = firebase.auth().currentUser;
    //     console.log('APi hit')
    //     this.snapshotChangesSubscription = this.afs.collection('StaticContent').doc(docname).collection(docname).valueChanges()
    //   .subscribe(snapshots => { 
    //     console.log('APi hit',snapshots)     
    //     resolve(snapshots);
    //   })
    // })
     }
     else{
    return new Promise<any>((resolve,reject)=>{
      let currentUser = firebase.auth().currentUser;
      this.snapshotChangesSubscription = this.afs.collection('StaticContent').doc(docname
        ).valueChanges()
    .subscribe(snapshots => {      
      resolve(snapshots);
    })
    })
  }
  }

  UpdatestaticContent(docname,value,title,time){
    return new Promise<any>((resolve,reject)=>{
      let currentUser = firebase.auth().currentUser;
 
      this.snapshotChangesSubscription = this.afs.collection('StaticContent').doc(docname).set(
        { Description: value,Lastupdate: time,Title:title },
       
        { merge: true }
      )
      .then(res=>{
        resolve(res)
      }).catch(err => {
        reject(err)
      })

      
    })
}


getstaticFAQ(docname){
   return this.afs.collection('StaticContent').doc(docname).collection(docname).snapshotChanges();
    
}
getstaticTime(){
   
  return  this.afs.collection('StaticContent').snapshotChanges();
  
}

getfeaturelist(){
  return  this.afs.collection('FeatureListing').snapshotChanges();
}


getuserguied(){
  return  this.afs.collection('UserGuide').snapshotChanges();
}

/// Convert image to link
uploadImage(imageURI, randomId){
  return new Promise<any>((resolve, reject) => {
    let storageRef = firebase.storage().ref();
    let imageRef = storageRef.child('/feature_image').child(randomId);
    this.encodeImageUri(imageURI, function(image64){
      imageRef.putString(image64, 'data_url')
      .then(snapshot => {
        snapshot.ref.getDownloadURL()
        .then(res => resolve(res))
      }, err => {
        reject(err);
      })
    })
  })
}

  encodeImageUri(imageUri, callback) {
    var c = document.createElement('canvas');
    var ctx = c.getContext("2d");
    var img = new Image();
    img.onload = function () {
      var aux:any = this;
      c.width = aux.width;
      c.height = aux.height;
      ctx.drawImage(img, 0, 0);
      var dataURL = c.toDataURL("image/jpeg");
      callback(dataURL);
    };
    img.src = imageUri;
  };

  /// Convert image to link
  getUserProfileImageuploadVideo(imageURI, randomId){
    
    return new Promise<any>((resolve, reject) => {
      // console.log('base 64 =-=-=-=-=-=',imageURI, randomId)
      let storageRef = firebase.storage().ref();
      let imageRef = storageRef.child('/video').child(randomId);
      // this.encodeImageUri(imageURI, function(image64){
        imageRef.putString(imageURI, 'data_url')
        .then(snapshot => {
          snapshot.ref.getDownloadURL()
          .then(res => resolve(res))
        }, err => {
          reject(err);
        })
      })
    // })
   

}


  encodevideoUri(imageUri, callback) {
    var c = document.createElement('canvas');
    var ctx = c.getContext("2d");
    var img = new Image();
    img.onload = function () {
      var aux:any = this;
      c.width = aux.width;
      c.height = aux.height;
      ctx.drawImage(img, 0, 0);
      var dataURL = c.toDataURL("video/mp4");
      callback(dataURL);
    };
    img.src = imageUri;
  };



  // Spinner Show/Hide Functionality
  
  showSpinner(){
    this.spinner.show();
  }
  hideSpinner(){
    this.spinner.hide();
  }




}
