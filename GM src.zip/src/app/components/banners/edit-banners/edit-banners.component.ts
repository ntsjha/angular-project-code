import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { ServiceService } from 'src/app/service/service.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { AppComponent } from 'src/app/app.component';

declare var $: any;

@Component({
  selector: 'app-edit-banners',
  templateUrl: './edit-banners.component.html',
  styleUrls: ['./edit-banners.component.css']
})
export class EditBannersComponent implements OnInit, OnDestroy {

  editBannerForm: FormGroup;
  fileData: any = {};
  paramData: any;
  userInfo: any;
  apiResponse: any = { status: 200 };
  selectedFileName: any;
  subscription: any;
  pageName: any;

  constructor(
    private service: ServiceService,
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private spinner: NgxSpinnerService,
    private appC: AppComponent
  ) {
    this.subscription = this.service.authVerify.subscribe(val => {
      if (val == 'edit-banner') {
        this.editBanner();
        this.service.authVerify.next('false');
      }
    });
  }

  ngOnInit() {
    window.scrollTo(0, 0);
    this.form();
    this.getUserInfo();
    this.getParamData();
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  form() {
    this.editBannerForm = new FormGroup({
      bannerText: new FormControl('', [Validators.required, Validators.minLength(2), Validators.maxLength(255)])
    });
  }

  getUserInfo() {
    this.service.userInfo.subscribe(success => {
      this.userInfo = success;
    });
  }

  getParamData() {
    this.activatedRoute.params.subscribe(param => {
      this.paramData = param;
      this.managePageNameValue(this.paramData.pageName);
      this.getBannerData();
    });
  }

  managePageNameValue(val) {
    switch (val) {
      case 'aboutUs'        : this.pageName = 'About Us';
                              break;
      case 'termsCondition' : this.pageName = 'Terms & Condittion';
                              break;
      case 'privacyPolicy'  : this.pageName = 'Privacy Policy';
                              break;
      case 'homePage'       : this.pageName = 'Home Page';
                              break;
      case 'rewards'        : this.pageName = 'Rewards';
                              break;
      case 'otc'            : this.pageName = 'OTC';
                              break;
      case 'events'         : this.pageName = 'Events';
                              break;
      case 'careers'        : this.pageName = 'Careers';
                              break;
      case 'fees'           : this.pageName = 'Fees';
                              break;
    }
  }

  getBannerData() {
    this.spinner.show();
    this.service.getMethod(`static/admin/get-banner-detail?bannerId=${encodeURIComponent(this.service.encrypt(this.paramData.id))}&language=${encodeURIComponent(this.service.encrypt(this.paramData.lang))}`, 1).subscribe((success: any) => {
      this.spinner.hide();
      if (success.status === 200) {
        this.editBannerForm.patchValue({
          bannerText: success.data.text
        });
        if (success.data.bannerImage) {
          this.fileData.fileData = success.data.bannerImage;
          this.selectedFileName = success.data.bannerImage;
          this.fileData.url = success.data.bannerImage;
          this.fileData.valid = true;
        }
      }
    }, error => {
      this.spinner.hide();
    });
  }

  /** Function to verify google authentication */
  verifyGoogleAuth() {
    if (this.editBannerForm.invalid || !this.fileData.valid || !this.fileData.url) {
      return;
    }
    this.appC.google = { one: '', two: '', three: '', four: '', five: '', six: '' };
    this.appC.response = { 'message': '' };
    this.service.googleAuthCalledFrom = 'edit-banner';
    $('#google-auth-modal').modal({ keyboard: false, backdrop: 'static' });

  }

  editBanner() {
    this.spinner.show();
    if (this.editBannerForm.invalid || !this.fileData.valid || !this.fileData.url) {
      this.spinner.hide();
      return;
    }
    const apireq = JSON.stringify({
      pageName: this.paramData.pageName,
      pageNameValue: this.pageName,
      bannerImage: this.fileData.url,
      ipAddress: this.userInfo.ip,
      location: this.userInfo.city + ',' + this.userInfo.country_name,
      text: this.editBannerForm.value.bannerText
    });
    const formData = new FormData();
    formData.append('bannerDto',(this.service.encrypt(apireq)));
    formData.append('bannerId',(this.service.encrypt(this.paramData.id)));
    this.service.postMethod('static/admin/edit-banner', formData, 2).subscribe(success => {
      this.apiResponse = success;
      this.spinner.hide();
      if (success.status === 200) {
        this.router.navigate(['/manage-banners']);
      }
    }, error => {
      this.spinner.hide();
      this.apiResponse.status = error.error.status;
      this.apiResponse.message = error.error.error;
    });
  }

  getFile(event) {
    this.fileData = this.service.uploadImage(event);
    this.selectedFileName = this.fileData.fileData.name;
    if (this.fileData.error === 'formatError') {
      this.fileData.error = 'Image accept only jpg, jpeg, png format.';
    } else {
      if (this.fileData.error === 'sizeError') {
        this.fileData.error = 'Image size should be less than 5Mb.';
      }
    }
    if (this.fileData.valid) {
      this.uploadFile();
    }
  }

  uploadFile() {
    this.spinner.show();
    const formData = new FormData();
    formData.append('file', this.fileData.fileData);
    this.service.postMethod('account/uploadFile', formData, 2).subscribe(success => {
      this.spinner.hide();
      this.fileData.url = success.fileName;
    }, error => {
      this.spinner.hide();
      this.fileData.url = null;
    });
  }
}
