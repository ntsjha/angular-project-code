import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MarketMakersComponent } from './market-makers.component';

describe('MarketMakersComponent', () => {
  let component: MarketMakersComponent;
  let fixture: ComponentFixture<MarketMakersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MarketMakersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MarketMakersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
