export interface MarketPanelSideBar {
    name: string;
    icon: string;
    url: string;
    subtopic: SubTopic[];
    routing?: string;
}

export interface SubTopic {
    subTopicName: string;
    url: string;
    icon: string;
    routing: string;
}


export interface DialogDataManage {
  animal: string;
  name: string;
}
