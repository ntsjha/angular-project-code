import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';

import { MyApp } from './app.component';
import { HomePage } from '../pages/home/home';
import { ListPage } from '../pages/list/list';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { StatePipe } from '../pipes/state/state';
import { QBService } from '../providers/qb/qb';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { LoginPage } from '../pages/login/login';
import { HeaderPage } from '../pages/header/header';
import { MessagePage } from '../pages/message/message';
import { FileChooser } from '@ionic-native/file-chooser';
@NgModule({
  declarations: [
    MyApp,
    HomePage,StatePipe,
    LoginPage,HeaderPage,
    ListPage,
    MessagePage
  ],
  imports: [
    BrowserModule,FormsModule,ReactiveFormsModule,HttpClientModule,
    
    IonicModule.forRoot(MyApp),
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    LoginPage,HeaderPage,
    HomePage,
    ListPage,  MessagePage,
  ],
  providers: [
    StatusBar,
    SplashScreen,FileChooser,
    QBService,
    {provide: ErrorHandler, useClass: IonicErrorHandler},
    
  ]
})
export class AppModule {}
