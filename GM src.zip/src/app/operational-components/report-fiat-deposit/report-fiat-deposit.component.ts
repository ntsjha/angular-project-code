import { Component, OnInit } from '@angular/core';
import { ServiceService } from 'src/app/service/service.service';
import { AngularCsv } from 'angular7-csv/dist/Angular-csv';
import { IMyDpOptions, IMyDateModel } from 'mydatepicker';

@Component({
    selector: 'app-report-fiat-deposit',
    templateUrl: './report-fiat-deposit.component.html',
    styleUrls: ['./report-fiat-deposit.component.css']
})
export class ReportFiatDepositComponent implements OnInit {
    obj:any={}
    pageSize :any = 10;
    transacArr: any = []
    public fromPickerOptions: IMyDpOptions = {
        dateFormat: 'dd.mm.yyyy',
    };
    public toPickerOptions: IMyDpOptions = {
        dateFormat: 'dd.mm.yyyy',
    };
    page: any=1;
    total: number=0;
    constructor(public server:ServiceService) { }

    ngOnInit() {
        this.getFiatDeposit();
        window.scrollTo(0, 0);
    }

    // date changed event here
    onFromDateChanged(event: IMyDateModel) {
        let copy1 = this.getCopyOfOptions1();
        copy1.disableUntil = event.date
        this.toPickerOptions = copy1; 
    }

    getCopyOfOptions1(): IMyDpOptions {
        return JSON.parse(JSON.stringify(this.toPickerOptions));
    }

    getCopyOfOptions2(): IMyDpOptions {
        return JSON.parse(JSON.stringify(this.fromPickerOptions));
    }
    
    onToDateChanged(event: IMyDateModel) {
        let copy1 = this.getCopyOfOptions2();
        copy1.disableSince = event.date
        this.fromPickerOptions = copy1;
    }

    getFiatDeposit() {
        let url, data = {}
        url = 'wallet/common-permit/history/get-transaction-history-fiat';
        data['txnType'] = "USER_DEPOSIT"
        if(this.obj.fromDate && this.obj.toDate) {
            data['fromDate'] = this.obj.fromDate.epoc;
            data['toDate'] = this.obj.toDate.epoc;
        }
        data['page'] = this.page - 1;
        data['pageSize'] =  10;

        this.server.postMethod(url,data,1).subscribe((res)=>{
           this.transacArr = res.data.resultlist;
           this.total = res.totalCount; 
        }) 
    }

    managePagination(page) {
        this.page = page ;
        this.total = 0;  
        this.getFiatDeposit()
    }

    applyFilter() {
        this.transacArr = [];
        this.page =1 ;
        this.total = 0;
        if(this.obj.fromDate && this.obj.toDate) {
            this.getFiatDeposit();
        }
    }

    clearFilter() {
        this.transacArr = [];
        this.page =1 ;
        this.total = 0;
        this.obj.fromDate.epoc = '';
        this.obj.toDate.epoc = ''
        this.getFiatDeposit();
    }

     exportList() {
        let headerArr = ['Customer ID','Name', 'Date','Currency', 'Amount', 'Status']
        var options = { 
            fieldSeparator: ',',
            quoteStrings: '"',
            decimalseparator: '.',
            showLabels: true,
            showTitle: true,
            title: 'Report Fiat Deposit',
            useBom: true,
            noDownload: false,
            headers: headerArr
        };

        
        let obj = {},data = []
        this.transacArr.forEach((element,index) => {
            obj = {
                'cust_id' : '',
                'name':'',
                'date': '',
                'currency': '',
                'amount': '',
                'status': '',
            }
        });
        data.push(obj)
        new AngularCsv(data, 'Report fiat Deposit', options);
    }

}
