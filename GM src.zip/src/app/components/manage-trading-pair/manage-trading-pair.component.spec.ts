import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageTradingPairComponent } from './manage-trading-pair.component';

describe('ManageTradingPairComponent', () => {
  let component: ManageTradingPairComponent;
  let fixture: ComponentFixture<ManageTradingPairComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManageTradingPairComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageTradingPairComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
