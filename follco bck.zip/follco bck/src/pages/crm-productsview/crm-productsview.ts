import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, App } from 'ionic-angular';
import { RestProvider } from '../../providers/rest/rest';
import { SettingprivacyPage } from '../settingprivacy/settingprivacy';

/**
 * Generated class for the CrmProductsviewPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-crm-productsview',
  templateUrl: 'crm-productsview.html',
})
export class CrmProductsviewPage {
  crmProductsViewList: any=[];
  title: any;
  date1: any;
  time: any;
  image: any;
  description: any;
  unit_price: any;
  data: any;
  category: any;
  image_thumb: any;
  extraProduct: any;

  constructor(public navCtrl: NavController,  public app :App,private service: RestProvider,public navParams: NavParams) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad CrmProductsviewPage');
    this.crmproductsList();
  }
  setting(){
    this.app.getRootNav().push(SettingprivacyPage);
  }
  back(){
    this.navCtrl.pop();
  }
crmproductsList() {
  this.service.presentLoadingDefault('Loading...');
  this.service.get('products/single/'+ localStorage.getItem('product_id')+'?follco_token=' + localStorage.getItem('new_token'),0).subscribe(res =>{
      console.log(res);
      if(res) {
          this.service.dismissLoading();
          this.title = res["record"].title;
          // console.log(this.title)
          this.date1 = res["record"].created_at;
          this.unit_price=res["record"].extra.unit_price;

          this.category=(res["record"].extra.category)?(res["record"].extra.category):'N/A';
          // this.image=res["record"].image_thumb;
          // this.extraProduct=(res["record"].ExtraProduct)?(res["record"].ExtraProduct):res["record"].ExtraProduct;
          // console.log('time===',this.extraProduct);
          // this.time=res["record"].creation_time;
          this.image=(res["record"].image_thumb)?(res["record"].image_thumb):'assets/imgs/car.jpeg';
          this.description = res["record"].content;
         
      }
     
  }, err => {
      this.service.dismissLoading();
      console.log(err);
  })
}
}
