import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ContributorManagementViewComponent } from './contributor-management-view.component';

describe('ContributorManagementViewComponent', () => {
  let component: ContributorManagementViewComponent;
  let fixture: ComponentFixture<ContributorManagementViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ContributorManagementViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ContributorManagementViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
