import { Component, OnInit } from '@angular/core';
declare var $: any;
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})

export class HeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {

    this.newMethod();
  }

  private newMethod() {
    $("button.btn-toggle").click(function () {
      $("body").toggleClass("toggle-wrapper");
    });
  }
}
