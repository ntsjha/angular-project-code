import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CrMediteventPage } from './cr-meditevent';

@NgModule({
  declarations: [
    CrMediteventPage,
  ],
  imports: [
    IonicPageModule.forChild(CrMediteventPage),
  ],
})
export class CrMediteventPageModule {}
