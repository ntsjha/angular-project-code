import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';
import { ServiceServicesProvider } from '../../providers/service-services/service-services';
import { TabsPage } from '../tabs/tabs';

@IonicPage()
@Component({
  selector: 'page-add-bank',
  templateUrl: 'add-bank.html',
})
export class AddBankPage {
  addBankForm: FormGroup;
  bankList: any = [];
  bankObj: any;
  bankPicture: any;
  usdAmount: any;

  constructor(public navCtrl: NavController, public navParams: NavParams, public fb: FormBuilder, public service: ServiceServicesProvider) {
    //----------------------------------------- BUILD ADD BANK FORM & VALIDATE IT -----------------------------------------//
    this.addBankForm = fb.group({
      'bankName': [null, Validators.compose([Validators.required])],
      'branchName': [null, Validators.compose([Validators.required, Validators.pattern(/^[a-zA-Z0-9_ ]*$/)])],
      'branchCode': [null, Validators.compose([Validators.required])],
      'accountNo': [null, Validators.compose([Validators.required, Validators.pattern(/^\d+$/)])],
      'accountHolderName': [null, Validators.compose([Validators.required, Validators.pattern(/^[a-zA-Z0-9_ ]*$/)])],
      'nickName': [null, Validators.compose([Validators.required])],
    });
  }

  ionViewWillEnter() {
    this.bankListApi();
    this.getUsdAmount();
  }

  back() {
    this.navCtrl.pop();
  }

  //------------------------------ Country JSON ------------------------------//
  bankListApi() {
    this.service.getBankJson().subscribe(response => {
      this.bankList = response['banks']
      console.log(this.bankList)
    }, error => {
      this.service.presentToast('Could not fetch list of banks. Please try again later')
    })
  }

  getUsdAmount() {
    this.service.getExchangeRate(localStorage.countryCode).subscribe(
      (res: any) => {
        this.service.dismissLoading();
        if(res[`rates`]['USD'])
          this.usdAmount = res[`rates`]['USD']
        else {
          this.usdAmount = JSON.parse(localStorage.withdrawMoneyProcess).amount;
        }
      },
      err => {
        this.service.dismissLoading();
        this.usdAmount = JSON.parse(localStorage.withdrawMoneyProcess).amount;
      }
    );
  }

  bankNameChange(bankName) {
    if (bankName) {
      let bankObj = this.bankList.filter((item) => item.name == bankName);
      this.bankPicture = bankObj[0][`picture`]
    }
  }

  withdraw() {
    if (navigator.onLine) {
      let userId = localStorage.getItem('userId');
      this.service.presentLoading();
      let data = {
        "userId": localStorage.getItem('userId'),
        "amount": Number(JSON.parse(localStorage.withdrawMoneyProcess).amount),
        "usdAmount": Number(this.usdAmount),
        "transactionType": "WITHDRAW",
        "bankName": this.addBankForm.value.bankName,
        "branchName": this.addBankForm.value.branchName,
        "bankImage": this.bankPicture,
        "nickName": this.addBankForm.value.nickName,
        "holdersName": this.addBankForm.value.accountHolderName,
        "routingNumber": "110000000",
        "number": "000123456789" //this.addBankForm.value.accountNo
      }
      this.service.postApi(data, 'transaction/withdraw', 1).subscribe((response: any) => {
        this.service.dismissLoading();
        if (response.response_code == 200) {
          this.service.presentToast(response.response_message)
          this.navCtrl.setRoot(TabsPage, { selectedTab: 2 })
        } else if (response.response_code == 403 || response.response_code == 409 || response.response_code == 401) {
          this.service.presentToast(response.response_message)
          this.service.logout();
        }
        else {
          this.service.presentToast(response.response_message)
        }
      }, err => {
        this.service.dismissLoading();
        this.service.presentToast('Something went wrong')
      })
    } else
      this.service.presentToast('Your internet connection seems to be lost')
  }

}
