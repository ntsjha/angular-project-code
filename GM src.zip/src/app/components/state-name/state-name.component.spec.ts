import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StateNameComponent } from './state-name.component';

describe('StateNameComponent', () => {
  let component: StateNameComponent;
  let fixture: ComponentFixture<StateNameComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StateNameComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StateNameComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
