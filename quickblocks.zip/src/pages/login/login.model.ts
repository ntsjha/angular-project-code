export class Login {
    constructor(
        public userid: string,
        public password: string
    ) { }
}
