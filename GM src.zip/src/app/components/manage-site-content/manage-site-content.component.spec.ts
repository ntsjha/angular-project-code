import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageSiteContentComponent } from './manage-site-content.component';

describe('ManageSiteContentComponent', () => {
  let component: ManageSiteContentComponent;
  let fixture: ComponentFixture<ManageSiteContentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManageSiteContentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageSiteContentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
