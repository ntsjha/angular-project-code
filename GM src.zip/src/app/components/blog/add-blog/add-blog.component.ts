import { Router } from '@angular/router';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { ServiceService } from 'src/app/service/service.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { AppComponent } from 'src/app/app.component';

declare var $: any;

@Component({
  selector: 'app-add-blog',
  templateUrl: './add-blog.component.html',
  styleUrls: ['./add-blog.component.css']
})
export class AddBlogComponent implements OnInit, OnDestroy {

  addBlogForm: FormGroup;
  fileData: any = {};
  userInfo: any;
  apiResponse: any = { status: 620 };
  selectedFileName: any;
  subscription: any;

  constructor(
    private service: ServiceService,
    private spinner: NgxSpinnerService,
    private router: Router,
    private appC: AppComponent
  ) {
    this.subscription = this.service.authVerify.subscribe(val => {
      if (val == 'add-blog') {
        this.submitBlog();
        this.service.authVerify.next('false');
      }
    });
  }

  ngOnInit() {
    window.scrollTo(0, 0);
    this.form();
    this.getIpAddress();
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  /** Function to verify google authentication */
  verifyGoogleAuth() {
    if (this.addBlogForm.invalid || !this.fileData.valid) {
      return;
    }
    this.appC.google = { one: '', two: '', three: '', four: '', five: '', six: '' };
    this.appC.response = { 'message': '' };
    this.service.googleAuthCalledFrom = 'add-blog';
    $('#google-auth-modal').modal({ keyboard: false, backdrop: 'static' });

  }

  form() {
    this.addBlogForm = new FormGroup({
      title: new FormControl('', [Validators.required, Validators.minLength(2), Validators.maxLength(255)]),
      detail: new FormControl('', [Validators.required, Validators.minLength(2)]),
      authorBy: new FormControl('', [Validators.required, Validators.minLength(3), Validators.maxLength(255)])
    });
  }

  getIpAddress() {
    this.service.userInfo.subscribe(success => {
      this.userInfo = success;
    });
  }

  submitBlog() {
    if (this.addBlogForm.invalid || !this.fileData.valid || !this.fileData.url) {
      return;
    }
    this.spinner.show();
    const formData = new FormData();
    const regex = / /gi;
    const slugData = (this.addBlogForm.value.title).replace(regex, '_');
    const data = JSON.stringify({
      author: this.addBlogForm.value.authorBy,
      description: this.addBlogForm.value.detail,
      title: this.addBlogForm.value.title,
      slug: slugData,
      ipAddress: this.userInfo.ip,
      location: this.userInfo.city + ',' + this.userInfo.country_name,
      image: this.fileData.url
    });
    formData.append('blogDto', this.service.encrypt(data));
    this.service.postMethod('blog/admin/add-blog-details', formData, 2).subscribe(success => {
      this.spinner.hide();
      this.apiResponse = success;
      if (success.status === 620) {
        this.router.navigate(['/blog-management']);
      }
    }, error => {
      this.spinner.hide();
      this.apiResponse.status = error.error.status;
      this.apiResponse.message = error.error.error;
    });
  }

  getFile(event) {
    this.fileData = this.service.uploadImage(event);
    this.selectedFileName = this.fileData.fileData.name;
    if (this.fileData.error === 'formatError') {
      this.fileData.error = 'Image accept only jpg, jpeg, png format.';
    } else {
      if (this.fileData.error === 'sizeError') {
        this.fileData.error = 'Image size should be less than 5Mb.';
      }
    }
    if (this.fileData.valid) {
      this.uploadFile();
    }
  }

  uploadFile() {
    this.spinner.show();
    const formData = new FormData();
    formData.append('file', this.fileData.fileData);
    this.service.postMethod('account/uploadFile', formData, 2).subscribe(success => {
      this.spinner.hide();
      this.fileData.url = success.fileName;
    }, error => {
      this.spinner.hide();
      this.fileData.url = null;
    });
  }

}
