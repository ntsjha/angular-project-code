import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReplyHistoryComponent } from './reply-history.component';

describe('ReplyHistoryComponent', () => {
  let component: ReplyHistoryComponent;
  let fixture: ComponentFixture<ReplyHistoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReplyHistoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReplyHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
