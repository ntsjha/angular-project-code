import { Component, OnInit } from '@angular/core';
import { ServiceService } from 'src/app/service/service.service';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';

declare var $: any;
 
@Component({
  selector: 'app-rewards',
  templateUrl: './rewards.component.html',
  styleUrls: ['./rewards.component.css']
})
export class RewardsComponent implements OnInit {
  selectedLanguage: string;
  modeOfAction: string;
  canEdit: boolean;
  canAdd: boolean;
  canView: boolean;
  translation: boolean;
  languageName: string;
  rewardForms: FormGroup;
  rewardData: any;
  errorMsg1: any;
  imgUrls: any = {};
  showError: any = false;
  apiError: any = {show: false, msg: '', status: 500};
  rewardTypeContent: any = [];
  rewardContent: any = [];
  currentUser: any;
  image: any;
  file: any;

  constructor(private service: ServiceService, private router: Router, private activatedRoutes: ActivatedRoute, private fb: FormBuilder, private spinner: NgxSpinnerService) {
    this.rewardForms = this.fb.group({
      referFriend: [null, [Validators.required]],
      RAFShortDescription: [null, [Validators.required,  Validators.maxLength(255), Validators.minLength(2)]],
      kyc: [null, [Validators.required]],
      completeKYCShortDescription: [null, [Validators.required,  Validators.maxLength(255), Validators.minLength(2)]],
      tradingPoints: [null, [Validators.required]],
      EWTShortDescription: [null, [Validators.required,  Validators.maxLength(255), Validators.minLength(2)]],
    });
  }

  ngOnInit() {
    this.activatedRoutes.params.subscribe((data) => {
      this.modeOfAction = data.id1;
      this.languageSelection(data.id2);
    });
    this.modeSelection();
    this.getRerwardList();
    this.service.currentUserInfo.subscribe((response) => {
      this.currentUser = response;
    });
    window.scrollTo(0, 0);
  }

  languageSelection(lang) {
    if (lang === 'th') {
      this.selectedLanguage = 'th';
      this.translation = true;
      this.languageName = 'Thai';
    } else if (lang === 'ch') {
      this.selectedLanguage = 'ch';
      this.translation = true;
      this.languageName = 'Chinese';
    } else {
      this.selectedLanguage = 'en';
      this.translation = false;
      this.languageName = 'English';
    }
  }

  modeSelection() {
    if (this.modeOfAction === 'edit') {
      this.canEdit = true;
      this.canAdd = false;
      this.canView = false;
      this.getRerwardList();
    } else if (this.modeOfAction === 'add') {
      this.canEdit = false;
      this.canAdd = true;
      this.canView = false;
    } else {
      this.canEdit = false;
      this.canAdd = false;
      this.canView = true;
      this.getRerwardList();
    }
  }

  uploadImg(event, submitType, error, patchId) {
    const obj = this.service.uploadImage(event);
    if (obj.valid) {
      this.spinner.show();
      const formData = new FormData();
      formData.append('file', obj.fileData);
      this.service.postMethod('account/uploadFile', formData, 2)
        .subscribe((response) => {
          this.spinner.hide();
          this.imgUrls[submitType] = response.fileName;
          this.imgUrls[error] = false;
          this.base64API(response.fileName,'index',patchId);
        }, (error) => {
          this.spinner.hide();
          this.imgUrls[error] = true;
          this.imgUrls[submitType] = null;
          this.errorMsg1 = 'Image is not uploaded please try again.';
        });
    } else {
      this.imgUrls[error] = true;
      this.imgUrls[submitType] = null;
      if (obj.error === 'sizeError') {
        this.errorMsg1 = 'Image size should be between 1MB to 5MB ';
      } else if (obj.error === 'formatError') {
        this.errorMsg1 = 'Image format should be JPG , JPEG , PNG';
      } else {
        this.errorMsg1 = obj.error;
      }
    }
  }

  getRerwardList() {
    this.spinner.show();
    this.service.getMethod('rewards/admin/get-reward-content?languageName=' + encodeURIComponent(this.service.encrypt(this.selectedLanguage)), 1)
      .subscribe((response: any) => {
        this.spinner.hide();
        this.rewardTypeContent = response.data.rewardTypeContent;
        this.rewardContent = response.data.rewardContent;
        if (response.status === 1300 || response.status === 1301) {
          this.rewardForms.patchValue({
            referFriend                : this.rewardTypeContent.length ? this.filterData(this.rewardTypeContent, 'ReferFriendPoint', 'description') : null,
            RAFShortDescription        : this.rewardContent.length ? this.filterData(this.rewardContent, 'ReferFriendPoint', 'description') : null,
            kyc                        : this.rewardTypeContent.length ? this.filterData(this.rewardTypeContent, 'CompleteKycPoint', 'description') : null,
            completeKYCShortDescription: this.rewardContent.length ? this.filterData(this.rewardContent, 'CompleteKycPoint', 'description') : null,
            tradingPoints              : this.rewardTypeContent.length ? this.filterData(this.rewardTypeContent, 'TradingPercentage', 'description') : null,
            EWTShortDescription        : this.rewardContent.length ? this.filterData(this.rewardContent, 'TradingPercentage', 'description') : null,
          });
          this.imgUrls.RAFImage1 = this.rewardContent.length ? this.filterData(this.rewardContent, 'ReferFriendPoint', 'image') : null;
          this.imgUrls.CompleteKYCImage1 = this.rewardContent.length ? this.filterData(this.rewardContent, 'CompleteKycPoint', 'image') : null;
          this.imgUrls.EWTImage1 = this.rewardContent.length ? this.filterData(this.rewardContent, 'TradingPercentage', 'image') : null;
          this.imgUrls.RAFImage2 = this.rewardTypeContent.length ? this.filterData(this.rewardTypeContent, 'ReferFriendPoint', 'image') : null;
          this.imgUrls.CompleteKYCImage2 = this.rewardTypeContent.length ? this.filterData(this.rewardTypeContent, 'CompleteKycPoint', 'image') : null;
          this.imgUrls.EWTImage2 = this.rewardTypeContent.length ? this.filterData(this.rewardTypeContent, 'TradingPercentage', 'image') : null;
        }
        this.rewardTypeContent.forEach((element, i) => {
          this.base64API(element.image, i, 'rewardContentType');
        });
        this.rewardContent.forEach((element, i) => {
          this.base64API(element.image, i, 'rewardContent');
        });
      }, (error) => {
        this.spinner.hide();
      });
    }

  filterData(data, type, key) {
    const filteredData = data.filter(item => {
      return item.title === type;
    });
    return filteredData.length ? filteredData[0][key] : null;
  }

  base64API(imageURL, index, type) {
    if (imageURL) {
      this.service.getMethod('account/convert-image-base64?imageUrl=' + this.service.imageUrl + imageURL, 1)
      .subscribe((res: any) => {
        this.spinner.hide();
      }, error => {
        this.spinner.hide();
        if (error.error.text && index !== 'index') {
          if (type === 'rewardContentType') {
            this.rewardTypeContent[index].image = 'data:image/jpg;base64,' + error.error.text;
          } else {
            this.rewardContent[index].image = 'data:image/jpg;base64,' + error.error.text;
          }
          return 'data:image/jpg;base64,' + error.error.text;
        } else if( error.error.text && index === 'index'){
          const img = 'data:image/jpg;base64,' + error.error.text;
          $('#' + type).attr('src', img);
        }
      });
    }
  }

  updateRewardContent() {
    this.spinner.show();
    if (this.rewardForms.invalid || !this.imgUrls.RAFImage1 || !this.imgUrls.RAFImage2 || !this.imgUrls.CompleteKYCImage1 || !this.imgUrls.CompleteKYCImage2 || !this.imgUrls.EWTImage1 || !this.imgUrls.EWTImage2) {
      this.showError = true;
      this.spinner.hide();
      return;
    } else {
      this.showError = false;
    }
    let apireq1 = {
      referAFriendDescription : this.service.encrypt(this.rewardForms.value.RAFShortDescription),
      referAFriendImage : this.service.encrypt(this.imgUrls.RAFImage1),
      referAFriendTitle : this.service.encrypt('ReferFriendPoint'),
      completeYourKYCDescription : this.service.encrypt(this.rewardForms.value.completeKYCShortDescription),
      completeYourKYCImage : this.service.encrypt(this.imgUrls.CompleteKYCImage1),
      completeYourKYCTitle : this.service.encrypt('CompleteKycPoint'),
      tradingPointsDescription : this.service.encrypt(this.rewardForms.value.EWTShortDescription),
      tradingPointsImage : this.service.encrypt(this.imgUrls.EWTImage1),
      tradingPointsTitle : this.service.encrypt('TradingPercentage')
    }; 
    let apireq2 = {
      referAFriendDescription : this.service.encrypt(this.rewardForms.value.referFriend),
      referAFriendImage : this.service.encrypt(this.imgUrls.RAFImage2),
      referAFriendTitle : this.service.encrypt('ReferFriendPoint'),
      completeYourKYCDescription : this.service.encrypt(this.rewardForms.value.kyc),
      completeYourKYCImage : this.service.encrypt(this.imgUrls.CompleteKYCImage2),
      completeYourKYCTitle : this.service.encrypt('CompleteKycPoint'),
      tradingPointsDescription : this.service.encrypt(this.rewardForms.value.tradingPoints),
      tradingPointsImage : this.service.encrypt(this.imgUrls.EWTImage2),
      tradingPointsTitle : this.service.encrypt('TradingPercentage')
    };
    if (this.selectedLanguage === 'en') {
      this.apiForEn(apireq1, apireq2);
    } else {
      this.apiForOtherThanEn(apireq1, apireq2);
    }
  }

  apiForEn(apireq1, apireq2) {
    this.service.postMethod('rewards/admin/add-reward-content', apireq1, 1).subscribe(success => {
      this.apiError = {show: true, msg: success.message, status: success.status};
      if (success.status === 1307) {
        this.service.postMethod('rewards/admin/add-reward-content-type', apireq2, 1).subscribe(response => {
          this.spinner.hide();
          if (response.status === 1310) {
            this.router.navigate(['/translation/rewards']);
          }
          this.apiError = {show: true, msg: response.message, status: response.status};
        }, err => {
          this.getApiError(err);
        });
      } else {
        this.spinner.hide();
      }
    }, error => {
      this.spinner.hide();
      this.getApiError(error);
    });
  }

  apiForOtherThanEn(apireq1, apireq2) {
    apireq1['languageName'] = this.service.encrypt(this.selectedLanguage);
    apireq2['languageName'] = this.service.encrypt(this.selectedLanguage);
    this.service.postMethod('rewards/admin/edit-reward-translation', apireq1, 1).subscribe(success => {
      this.apiError = {show: true, msg: success.message, status: success.status};
      if (success.status === 1316) {
        this.service.postMethod('rewards/admin/edit-reward-content-type-translation', apireq2, 1).subscribe(response => {
          this.spinner.hide();
          if (response.status === 1313) {
            this.router.navigate(['/translation/rewards']);
          }
          this.apiError = {show: true, msg: response.message, status: response.status};
        }, err => {
          this.getApiError(err);
        });
      } else {
        this.spinner.hide();
      }
    }, error => {
      this.spinner.hide();
      this.getApiError(error);
    });
  }

  getApiError(error) {
    if (error) {
      if (error.error) {
        if (error.error.error) {
          this.apiError = {show: true, msg: error.error.error, status: 500};
        } else {
          this.apiError = {show: true, msg: 'Internal server error.', status: 500};
        }
      } else {
        this.apiError = {show: true, msg: 'Internal server error.', status: 500};
      }
    } else {
      this.apiError = {show: true, msg: 'Internal server error.', status: 500};
    }
  }

  openImg(img) {
    this.file = img;
    $('#image-modal').modal({ keyboard: false, backdrop: 'static' });
  }

}
