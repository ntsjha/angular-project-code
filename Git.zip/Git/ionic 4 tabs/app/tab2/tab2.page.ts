import { Component, OnInit } from '@angular/core';
import {Validators, FormBuilder, FormGroup, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { AlertController ,NavController } from '@ionic/angular';
import { Storage } from '@ionic/storage';

@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  styleUrls: ['tab2.page.scss']
})
export class Tab2Page  {
 
  
  
  submitted = false;
  

  Signupform = new FormGroup({
    name: new FormControl('', [Validators.required, Validators.pattern(/^[a-zA-Z ]*$/)]),
    mobileno:new FormControl ('', [Validators.required,Validators.pattern(/^\+?\d{2}[- ]?\d{3}[- ]?\d{5}$/),Validators.maxLength(10)]),
    email: new FormControl ('', [Validators.required,Validators.pattern(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/)]),
      password: new FormControl ('', [Validators.required,Validators.maxLength(16),
        Validators.pattern("^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$")])
  });
  objData: { firstname: any; objemail: any;  };


  constructor(public router: Router, public formBuilder: FormBuilder,public alertController: AlertController,
    private storage: Storage,) {

    
  }
  get f() { return this.Signupform.controls; }

  async onSignIn() {
    this.submitted = true; 
      console.log(this.Signupform.value);
      console.log(this.f.email.value);
     
      //this.router.navigateByUrl('/tab1');
      this.objData = {firstname:this.Signupform.value.name,objemail:this.Signupform.value.email}
      localStorage.setItem('information', JSON.stringify( this.objData)); 
        console.log(this.objData);

        const alert = await this.alertController.create({
          header: 'Sucessfully Registerd',
          message: 'Thank you for registration',
          buttons: ['OK']
        });
    
        await alert.present();

        this.storage.set('age', 12);

        // Or to get a key/value pair
        
     
        this.Signupform.reset();

        this.router.navigate(['/tabs/tab1']);
     
      }
  
}
