

/*======================== MIXPANEL ===========================*/


(function(e, b) {

    if (!b.__SV) {
        var a, f, i, g;
        window.mixpanel = b;
        b._i = [];
        b.init = function(a, e, d) {
            function f(b, h) {
                var a = h.split(".");
                2 == a.length && (b = b[a[0]], h = a[1]);
                b[h] = function() {
                    b.push([h].concat(Array.prototype.slice.call(arguments, 0)))
                }
            }
            var c = b;
            "undefined" !== typeof d ? c = b[d] = [] : d = "mixpanel";
            c.people = c.people || [];
            c.toString = function(b) {
                var a = "mixpanel";
                "mixpanel" !== d && (a += "." + d);
                b || (a += " (stub)");
                return a
            };
            c.people.toString = function() {
                return c.toString(1) + ".people (stub)"
            };
            i = "disable track track_pageview track_links track_forms register register_once alias unregister identify name_tag set_config people.set people.set_once people.increment people.append people.track_charge people.clear_charges people.delete_user".split(" ");
            for (g = 0; g < i.length; g++) f(c, i[g]);
            b._i.push([a, e, d])
        };

    }
})(document, window.mixpanel || []);
mixpanel.init("dbbd7bd9566da85f012f7ca5d8c6c944", {
    debug: true
});

/*======================== USER AGENT CLASS ===========================*/


function css_browser_selector(u) {
    var ua = u.toLowerCase(),
        is = function(t) {
            return ua.indexOf(t) > -1
        },pushState
    g = 'gecko',
        w = 'webkit',
        s = 'safari',
        o = 'opera',
        m = 'mobile',
        h = document.documentElement,
        b = [(!(/opera|webtv/i.test(ua)) && /msie\s(\d)/.test(ua)) ? ('ie ie' + RegExp.$1) : is('firefox/2') ? g + ' ff2' : is('firefox/3.5') ? g + ' ff3 ff3_5' : is('firefox/3.6') ? g + ' ff3 ff3_6' : is('firefox/3') ? g + ' ff3' : is('gecko/') ? g : is('opera') ? o + (/version\/(\d+)/.test(ua) ? ' ' + o + RegExp.$1 : (/opera(\s|\/)(\d+)/.test(ua) ? ' ' + o + RegExp.$2 : '')) : is('konqueror') ? 'konqueror' : is('blackberry') ? m + ' blackberry' : is('android') ? m + ' android' : is('chrome') ? w + ' chrome' : is('iron') ? w + ' iron' : is('applewebkit/') ? w + ' ' + s + (/version\/(\d+)/.test(ua) ? ' ' + s + RegExp.$1 : '') : is('mozilla/') ? g : '', is('j2me') ? m + ' j2me' : is('iphone') ? m + ' iphone' : is('ipod') ? m + ' ipod' : is('ipad') ? m + ' ipad' : is('mac') ? 'mac' : is('darwin') ? 'mac' : is('webtv') ? 'webtv' : is('win') ? 'win' + (is('windows nt 6.0') ? ' vista' : '') : is('freebsd') ? 'freebsd' : (is('x11') || is('linux')) ? 'linux' : '', 'js'];
    c = b.join(' ');
    if (h.className.indexOf(c)==-1){
        h.className += ' ' + c;
    }
    return c;
};
css_browser_selector(navigator.userAgent);


/******************************************************************/

etoro_lp.trd_party = {
    append_script: function(src, callback) {
        var script = document.createElement('script');
        script.async = true;
        script.src = src;
        document.getElementsByTagName('head')[0].appendChild(script);
        script.onload = function() {
            callback();
        };
    },
    load_sandbox: function() {
        window.etoroSB = {
            isChina:etoro_lp.settings.culture=='zh-cn' ? true : false,
            onload: function() {}
        };

        var script = document.createElement('script');
        script.async = true;
        script.src = 'sandbox.js';
        script.async = true;
        document.getElementsByTagName('head')[0].appendChild(script);
        script.onload = function() {};
    },
    load_mixpnael: function() {
        // mixpanel
        (function(e, b) {
            if (!b.__SV) {

                b.__SV = 1.2;
                a = e.createElement("script");
                a.type = "text/javascript";
                a.async = !0;
                a.src = ("https:" === e.location.protocol ? "https:" : "http:") + '//cdn.mxpnl.com/libs/mixpanel-2.2.min.js';
                f = e.getElementsByTagName("script")[0];
                f.parentNode.insertBefore(a, f)
            }
        })(document, window.mixpanel || []);
    },
    load_optimizly: function() {
        var script = document.createElement('script');
        script.async = true;
        script.src = '';
        script.async = true;
        document.getElementsByTagName('head')[0].appendChild(script);
        script.onload = function() {};
    },
    init: function() {
        var _this = this;
        if (_this.process_started) {
            return;
        }
        var page_load_settings = etoro_lp.settings.dynamic;
        var page_load_time = page_load_settings['pageLoadTime'];
        var is_human = page_load_settings['isHuman'];
        var wait_time = 5100;
        var now = Date.now();
        var gap = now - page_load_time;
        var delay = gap > wait_time ? 0 : wait_time - gap;

        if (is_human) delay = 0;
        setTimeout(function() {
            if (!_this.process_started) {
                _this.process_started = true;
                console.log('3p init');
                // load somthing
                _this.load_mixpnael();
                if (/tag_manager=false/.test(location.href) == false) {
                    _this.load_sandbox();
                }
                if (etoro_lp.settings.culture == 'en-us') {
                    //_this.load_optimizly();
                }
            }

        }, delay);

    }

}

etoro_lp.tools = {
    date_parsing: function(date) {
        var d = new Date(date);
        if (!d.getTime()) {
            return null;
        }
        return d.toLocaleString();

    },
    is_ie: function() {
        var ua = window.navigator.userAgent;
        var msie = ua.indexOf("MSIE ");
        return msie > 0 ? true : false;
    },
    array_search: function(arr, propName, propValue) {
        for (var i = 0; i < arr.length; i++)
            if (arr[i][propName] == propValue)
                return arr[i];
    },
    get_random_array_elements: function(arr, count) {
        var shuffled = arr.slice(0),
            i = arr.length,
            min = i - count,
            temp, index;
        while (i-- > min) {
            index = Math.floor((i + 1) * Math.random());
            temp = shuffled[index];
            shuffled[index] = shuffled[i];
            shuffled[i] = temp;
        }
        return shuffled.slice(min);
    },
    clone_object: function(_obj) {
        var clone = {};
        for (var i in _obj) {
            if (typeof(_obj[i]) == "object" && _obj[i] != null)
                clone[i] = cloneObject(_obj[i]);
            else
                clone[i] = _obj[i];
        }
        return clone;
    },
    strip_tags: function(input, allowed) {
        allowed = (((allowed || '') + '')
            .toLowerCase()
            .match(/<[a-z][a-z0-9]*>/g) || [])
            .join(''); // making sure the allowed arg is a string containing only tags in lowercase (<a><b><c>)
        var tags = /<\/?([a-z][a-z0-9]*)\b[^>]*>/gi,
            commentsAndPhpTags = /<!--[\s\S]*?-->|<\?(?:php)?[\s\S]*?\?>/gi;
        return input.replace(commentsAndPhpTags, '')
            .replace(tags, function($0, $1) {
                return allowed.indexOf('<' + $1.toLowerCase() + '>') > -1 ? $0 : '';
            });
    },
    getParameterByName: function(name) {
        name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
        var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
            results = regex.exec(location.search);
        return results == null ? "" : obj.tools.strip_tags(decodeURIComponent((results[1].toString()).replace(/\+/g, " ")));
    },
    extend: function(originalObj, extObj) {
        for (var i in extObj) {
            originalObj[i] = extObj[i]
        }
        return originalObj
    },
    array_sortby: function(arr, property) {
        return arr.slice(0).sort(function(a, b) {
            return (a[property] > b[property]) ? 1 : (a[property] < b[property]) ? -1 : 0;
        });
    },
    bind_click_outside: function(elem, parnets) {
        $("body").on("click", elem, function(e_c) {
            if (!etoro_lp.tools.isMobile.any()) {
                e_c.preventDefault();
            }
            var _this = this;
            $(_this).parents(parnets).toggleClass("open");
            $(document).bind('mousedown', function(e) {

                window.tt = e.target;
                window.elem = elem;
                if (($(e.target).hasClass('open') || $(e.target).parents('*').hasClass('open'))) {

                } else {

                    $(parnets).removeClass("open");
                    $(document).unbind('mousedown');
                }
            });
        });
    },
    isMobile: {
        Android: function() {
            return navigator.userAgent.match(/Android/i);
        },
        iOS: function() {
            return navigator.userAgent.match(/iPhone|iPod/i);
        },
        Opera: function() {
            return navigator.userAgent.match(/Opera Mini/i);
        },
        Windows: function() {
            return navigator.userAgent.match(/IEMobile/i);
        },
        any: function() {
            return this.Android() || this.iOS() || this.Opera() || this.Windows() ? true : false;
        }
    },
    updateQueryStringParameter:function(uri, key, value) {
        var re = new RegExp("([?|&])" + key + "=.*?(&|#|$)", "i");
        if (uri.match(re)) {
            return uri.replace(re, '$1' + key + "=" + value + '$2');
        } else {
            var hash =  '';
            if( uri.indexOf('#') !== -1 ){
                hash = uri.replace(/.*#/, '#');
                uri = uri.replace(/#.*/, '');
            }
            var separator = uri.indexOf('?') !== -1 ? "&" : "?";
            return uri + separator + key + "=" + value + hash;
        }
    },
    cookies: {
        main_cookie_name: 'hp_preferences',
        get_cookie: function(c_name) {
            var i, x, y, ARRcookies = document.cookie.split(";");
            for (i = 0; i < ARRcookies.length; i++) {
                x = ARRcookies[i].substr(0, ARRcookies[i].indexOf("="));
                y = ARRcookies[i].substr(ARRcookies[i].indexOf("=") + 1);
                x = x.replace(/^\s+|\s+$/g, "");
                if (x == c_name) {
                    return unescape(y);
                }
            }
        },
        set_cookie: function(c_name, value, exdays) {
            var exdate = new Date();
            exdate.setDate(exdate.getDate() + exdays);
            var c_value = escape(value) + ((exdays == null) ? "" : "; expires=" + exdate.toUTCString());
            document.cookie = c_name + "=" + c_value + ';path=/';
        },
        reset_cookie: function(cookie_name) {
            this.set_cookie(this.main_cookie_name, '{}', 7);
            this.update_prop('locale', etoro_lp.settings.locale);
        },
        delete_cookie: function(cookie_name) {

        },
        update_prop: function(prop, val) {
            try {
                var cookie = JSON.parse(this.get_cookie(this.main_cookie_name));
            } catch (e) {
                cookie = {};
            }
            cookie[prop] = val;
            this.set_cookie(this.main_cookie_name, JSON.stringify(cookie), 7)
        },
        get_prop: function(prop) {
            try {
                var cookie = JSON.parse(this.get_cookie(this.main_cookie_name));
            } catch (e) {
                cookie = {};
            }
            return cookie[prop]
        },
        init: function() {
            var existing_cookie = this.get_cookie(this.main_cookie_name);
            if (!existing_cookie) {
                this.reset_cookie();
            }
        }

    },
    deepExtend:function(destination, source) {
        for (var property in source) {
            if (typeof source[property] === "object") {
                destination[property] = destination[property] || {};
                this.deepExtend(destination[property], source[property]);
            } else {
                destination[property] = source[property];
            }
        }
        return destination;
    }

}

etoro_lp.tracking = {
    session_username: 'Visitor',
    page_name: etoro_lp.settings.page_name,
    get_qs_obj: function() {
        var q = {};
        try {
            location.href.split('?')[1].split('&').forEach(function(i) {
                q[i.split('=')[0]] = i.split('=')[1];
            });
        } catch (e) {}
        return q;

    },
    get_platform: function() {
        return etoro_lp.tools.isMobile.any() ? 'Mobile' : 'Desktop';
    },
    is_registered_user: function() {
        var username = '';
        try {
            username = JSON.parse(etoro_lp.tools.cookies.get_cookie('mp_dbbd7bd9566da85f012f7ca5d8c6c944_mixpanel')).distinct_id
        } catch (e) {

        }
        if (username.length > 0 && username.length < 17) {
            return true;
        } else {
            return false;
        }
    },
    pageUrlClean: function() {
        return document.URL.split("?")[0];
    },
    is_registered_user:function(){
     var username = '';
     try{
     username = JSON.parse(this.get_cookie('mp_dbbd7bd9566da85f012f7ca5d8c6c944_mixpanel')).distinct_id
     }
     catch(e){

     }
     if (typeof username  == 'number') {
         return true;
     }
     else{
         return false;
     }
     },
      get_cookie:function(c_name){
         var i, x, y, ARRcookies = document.cookie.split(";");
         for (i = 0; i < ARRcookies.length; i++) {
             x = ARRcookies[i].substr(0, ARRcookies[i].indexOf("="));
             y = ARRcookies[i].substr(ARRcookies[i].indexOf("=") + 1);
             x = x.replace(/^\s+|\s+$/g, "");
             if (x == c_name) {
                 return unescape(y);
             }
         }
     },
    get_default_obj: function() {
        var qs = {};
        try {
            location.href.split('?')[1].split('&').forEach(function(i) {
                qs['QueryString_' + i.split('=')[0]] = i.split('=')[1];
            });
        } catch (e) {}

        var _o = {
            IsRegisteredUser: this.is_registered_user(),
            Platform: this.get_platform(),
            Culture: etoro_lp.settings.locale,
            URL: document.URL,
            Webpage: this.page_name,
            currentUrlClean: this.pageUrlClean()
        };

        etoro_lp.tools.extend(_o, qs);
        return _o;

    },
    track: function(event_name, prop) {
        try {
            var e_name =  event_name;
            var e_prop = etoro_lp.tools.extend(this.get_default_obj(), prop);
            mixpanel.track(e_name, e_prop);
        } catch (e) {
            console.log('mixpanel error');
        }
    },
    track_link: function(elem, event_name, prop_obj, signle_prop_name) {
        var e_name = 'LP - ' + event_name;

        var default_prop = this.get_default_obj();

        (function() {
            if (signle_prop_name) {
                var elem_attr = $(elem).attr('data-tracking-name');
                prop_obj[signle_prop_name] = elem_attr;
            }

        }())

        try {
            mixpanel.track_links(elem, e_name, function(e) {
                if (signle_prop_name) {
                    var elem_attr = $(e).attr('data-tracking-name');
                    prop_obj[signle_prop_name] = elem_attr;
                }
                return etoro_lp.tools.extend(default_prop, prop_obj)
            });
        } catch (e) {
            console.log('mixpanel error');
        }
    }

}

etoro_lp.api = {
    getArrayList:{
        instrument:[]
    },
    localObj:{
        instrument:etoro_lp.settings.data.instruments.map(function(a) {return a.id;})
    },
    setup:{
        header: {'Ocp-Apim-Subscription-Key':'cebdcc68c17e48b1bf3b71341a5170c5'},
        instrumentArr: etoro_lp.settings.data.instruments.map(function(a) {return a.id;}),
        period: 'OneYearAgo'
    },
    httpGET: function(httpUrl,headers, callbackSuccess) {
        etoroLoggerApps.lp.http('GET', httpUrl, headers, '', null, '', function(success, _data) {
            try {
                var responce = _data.target.responseText;
            } catch (e) {
                var responce = {};
            }
            if (success) {
                try {
                    var data = JSON.parse(responce);
                    callbackSuccess(data);

                } catch (e) {
                    // log here
                    console.log('error', e);
                    etoroLoggerApps.lp.send([{
                        Level: 'warn',
                        Url: httpUrl,
                        Message: "Can't parse JSON response",
                        Exception: e
                    }]);

                }
            } else {
                console.log('error');
            }
        })

    },
    checkIfDone: function (countLength,feedType,data) {
        this.getArrayList[feedType].push(data);
        if (this.getArrayList[feedType].length == countLength){
            if (feedType === 'instrument') {
                etoro_lp.page_action.UI.createUI();
                etoro_lp.page_action.UI.createTableUI();
                if(etoro_lp.settings.explorer == "1"){
                    $('.top-append-to').slick('slickPlay');
                }
            }
        }
    },
    getCounter: function () {
        var getCount = 0;

        for (var key in etoro_lp.api.getData) {
            getCount ++;
        }
        return getCount;
    },
    calculateChange: function(_item) {
        var _this = this;
        var changeP, currentRate, changeV;

        currentRate = _item[0].Bid;

        changeP = ((_item.ClosingPriceLast / _item.ClosingPriceFirst)-1) * 100;

        changeP = parseFloat(changeP.toFixed(2));


        var price = currentRate;
        _item['changeSign'] = price > _item.ClosingPriceFirst ? 'positive' : 'negative';
        _item['price'] = price;
        _item['changeP'] = changeP;
        return _item;

    },
    M_lang:function() {
        var currentCulture = etoro_lp.settings.culture,
            M = 'M';
        switch (currentCulture) {

            case 'de-de':
                M='Mio'
                break;
            case 'nl-nl':
                M='mln'
                break;
        }
        return M;

    },
    B_lang:function() {
        var currentCulture = etoro_lp.settings.culture,
            B = 'B';
        switch (currentCulture) {
            case 'de-de':
                B='Mrd'
                break;
            case 'fr-fr':
                B='Mrd'
                break;
            case 'nl-nl':
                B= 'mld';
                break;
        }
        return B;

    },
    currencyLocation:function(price) {
        /* all cultures 'ar-ae', 'de-de', 'en-us', 'es-es', 'fr-fr', 'ru-ru', 'it-it', 'zh-cn','pl-pl','nl-nl'*/
        var currentCulture = etoro_lp.settings.culture;
        switch (currentCulture) {
            case 'fr-fr':
                price+='$'
                break;
            case 'de-de':
                price+=' USD'
                break;
            case 'pl-pl':
                price+='$'
                break;
            case 'ar-ae':
                price = 'Ø¯ÙˆÙ„Ø§Ø± ' + price
                break;
            case 'zh-cn':
            case 'zh-tw':
                price+='ç¾Žå…ƒ'
                break;
            default:
                price= '$' + price
        }
        return price;
    },
    add_class_delay: function(el, new_class, delay) {
        setTimeout(function() {
            $(el).addClass(new_class);
        }, delay)

    },
    cleanAPI:{
        objRates: function (data) {
            var ratesObj,  _api = etoro_lp.api;
            ratesObj = {};
            for (var i = 0; i < data.length; i++) {
                ratesObj[i] = {
                    instrumentId: data[i].instrumentId,
                    ask: data[i].ask,
                    bid: parseFloat(data[i].bid.toFixed(2))
                }
            }
            $.extend(true,_api.localObj.instrument,ratesObj);
            _api.checkIfDone(2,'instrument',data);
        },
        objAvatar: function (data) {

            var avatarObj,_this, _api = etoro_lp.api;
            _this = this;
            avatarObj = {};
            var instruments_list =etoro_lp.settings.data.instruments;
            var dir = etoro_lp.settings.dir == 'en'?'':'/'+etoro_lp.settings.dir;
            for (var i = 0; i < data.length; i++) {
                var current = data[i];
                var selected_avatar = current.media.filter(function (obj) {
                    return (obj.width === 50);
                })[0]['uri'];
                var selected_avatar150 = current.media.filter(function (obj) {
                    return (obj.width === 150);
                })[0]['uri'];
                avatarObj[i] = {

                    instrumentId: current.instrumentId,
                    symbolFull: current.ticker,
                    displayName: current.instrumentId == '100003'? 'By Ripple Labs' :current.name,
                    url: 'https://www.etoro.com' + dir + '/markets/' + current.ticker.toLowerCase(),
                    btn_text: etoro_lp.settings.res.CTA+' '+instruments_list[i].CTA,
                    image: selected_avatar,
                    image150: selected_avatar150,
                    decentralised:'images/'+instruments_list[i].decentralised+'.png',
                    max_suplly:current.instrumentId=='100003'?instruments_list[i].max_suplly+etoro_lp.api.B_lang():instruments_list[i].max_suplly+etoro_lp.api.M_lang(),
                    market_cap: etoro_lp.settings.culture == 'ar-ae'?etoro_lp.api.currencyLocation(instruments_list[i].market_cap)+etoro_lp.api.B_lang():etoro_lp.api.currencyLocation(instruments_list[i].market_cap+etoro_lp.api.B_lang()),
                    gain:instruments_list[i].gain

                }
            }
            $.extend(true,_api.localObj.instrument,avatarObj);
            _api.checkIfDone(2,'instrument',data);
        }
    },
    getData : {
        rates: function() {
            var _api, setup, url ,_this;
            _this = this;
            _api = etoro_lp.api;
            setup = _api.setup;
            url ='https://api.etoro.com/Live?InstrumentIds='+ setup.instrumentArr.toString();
            _api.httpGET(url, {'Ocp-Apim-Subscription-Key':'780b61969dde4f5b9d689ec7334bfbfc'}, function(data){
                _api.cleanAPI.objRates(data);

            });
        },
        avatar: function (){
            var _api, url, setup, headers;
            _api = etoro_lp.api;
            setup = _api.setup;
            headers =   {'Ocp-Apim-Subscription-Key':'cebdcc68c17e48b1bf3b71341a5170c5'};
            url ='https://api.etoro.com/Metadata/V1/Instruments?InstrumentIds=' + setup.instrumentArr.toString();
            _api.httpGET(url,headers, function(data){
                _api.cleanAPI.objAvatar(data);
            });
        }

    },
    init: function () {
        this.getData.rates();
        this.getData.avatar();

    }
}
etoro_lp.page_action = {
    api: {},
    UI:{
        flag_focus:1,
        timerId : 0,
        currdeg  : 0,
        createUI: function() {
            var data, _api;

            _api = etoro_lp.api;
            data = _api.localObj.instrument;

            var _this = this;
            var final_html = '';
            var html_tmpl ='<div class="item box{num_box}"><a target="_blank" href="{stock_url}"><div class="image" style="background-image: url({Image})"><div class="img_body" style="background-image: url({Image})"></div></div><div class="info"><div class="row name"><span class="m_name">{SymbolFull}</span> <span class="d_name cut_text">{DisplayName}</span> </div><div class="row num"><span>{current_price}</span><span class="text_title cut_text">'+ etoro_lp.settings.res.current_price_title+'</span></div><div class="row num">{market_cap}<span class="text_title cut_text">'+ etoro_lp.settings.res.market_cap_title+'</span></div></div></a></div>';
            var index=1;
            for (var key=0;key<7;key++) {
                    current = data[key];
                    var _item_html = html_tmpl;
                    _item_html = _item_html.replace(/{num_box}/g, index);
                    _item_html = _item_html.replace(/{SymbolFull}/g, current.symbolFull);
                    _item_html = _item_html.replace(/{DisplayName}/g, current.displayName);
                    _item_html = _item_html.replace(/{Image}/g, current.image150);
                    _item_html = _item_html.replace(/{stock_url}/g, current.url);
                    _item_html = _item_html.replace("{current_price}", etoro_lp.api.currencyLocation(current.bid));
                    _item_html = _item_html.replace("{market_cap}", current.market_cap);
                    final_html += _item_html;
                    index++;
                }

                if (etoro_lp.settings.explorer == "1") {
                    $('.top-append-to').append(final_html);
                    debugger;
                    _this.sliderInit();
                }
                else {
                    $('.carousel .loading').removeClass('loading')
                    $('.carousel').append(final_html);
                    _this.carouselInit();
                }


        },
        createTableUI: function () {
            var _this = this;
            var data, _api;
            _api = etoro_lp.api;
            data = _api.localObj.instrument;
            var	header_table='<tr><th></th><th></th><th>'+ etoro_lp.settings.res.gain_title+'</th><th>'+ etoro_lp.settings.res.max_supply_title+'</th><th>'+ etoro_lp.settings.res.decentralised_title+'</th><th>'+ etoro_lp.settings.res.current_price_title+'</th><th>'+ etoro_lp.settings.res.market_cap_title+'</th><th></th> </tr>'
            var final_html = '';
            var html_tmpl='<tr><td><a target="_blank" href="{stock_url}"><img src="{Image}"></a></td><td> <a target="_blank" href="{stock_url}"><span class="ints_name">{SymbolFull}</span><span class="full_name">{DisplayName}</span></a></td><td><p class="inst_num border" data-sign="{change_sign}">{gain}</p> </td><td><p class="inst_num">{max_suplly}</p></td><td><p class="decentralised"><img class="decentralised_img" src="{decentralised}"></p></td><td><p class="inst_num">{current_price}</p></td><td><p class="inst_num">{market_cap}</p></td><td><a class="cta_trade" target="_blank" href="{stock_url}">{btn_text}</a></td></tr>'
            if(window.innerWidth<768) {
                html_tmpl = '<div class="cover"><a target="_blank" href="{stock_url}"><div class="image"> <img src="{Image}"></div> <p class="ints_name">{SymbolFull}<span class="full_name">{DisplayName}</span></p> </a>   <div class="info clearfix"> <div class="fl2"> <p>'+ etoro_lp.settings.res.gain_title+': </p></div><div class="fl"> <p class="inst_num" data-sign="{change_sign}">{gain}</p> </div> <div class="clearfix"></div><div class="info clearfix"> <div class="fl2"> <p>'+ etoro_lp.settings.res.max_supply_title+': </p></div><div class="fl"> <p class="inst_num">{max_suplly}</p> </div> <div class="clearfix"></div> </div> <div class="info clearfix">  <div class="fl2"> <p>'+ etoro_lp.settings.res.decentralised_title+': </p> </div><div class="fl"> <p class="decentralised"><img class="decentralised_img" src="{decentralised}"></p> </div> <div class="clearfix"></div> </div><div class="info clearfix"> <div class="fl2"> <p>'+ etoro_lp.settings.res.current_price_title+': </p></div><div class="fl"> <p class="inst_num">{current_price}</p> </div> <div class="clearfix"></div> </div><div class="info clearfix"> <div class="fl2"> <p>'+ etoro_lp.settings.res.market_cap_title+': </p></div><div class="fl"> <p class="inst_num">{market_cap}</p> </div> <div class="clearfix"></div> </div><a class="cta_trade" target="_blank" href="{stock_url}">{btn_text}</a> </div> </div><div class="clearfix">'
            }
            for (var key in data) {
                current = data[key];
                var _item_html=html_tmpl;

                _item_html = _item_html.replace(/{SymbolFull}/g, current.symbolFull);
                _item_html = _item_html.replace(/{DisplayName}/g, current.displayName);
                _item_html = _item_html.replace(/{Image}/g, current.image);
                _item_html = _item_html.replace(/{stock_url}/g, current.url);
                _item_html = _item_html.replace(/{decentralised}/g, current.decentralised);
                _item_html = _item_html.replace("{current_price}", etoro_lp.api.currencyLocation(current.bid));
                _item_html = _item_html.replace("{max_suplly}", current.max_suplly);
                _item_html = _item_html.replace("{market_cap}", current.market_cap);
                _item_html = _item_html.replace("{gain}", current.gain);
                _item_html = _item_html.replace(/{change_sign}/g, 'positive');
                _item_html = _item_html.replace(/{btn_text}/g, current.btn_text);
                final_html += _item_html;
            }
            if(window.innerWidth>767){final_html=header_table+final_html;}

            $('.tooltip .innerHTML').find('loading')
            $('.s2 .loading').removeClass('loading')
            $('.tooltip .innerHTML').append(final_html);
        },
        sliderInit: function() {
            $('.top-append-to').slick({
                centerMode: true,
                adaptiveHeight:false,
                variableWidth:true,
                arrows: false,
                autoplay: true,
                speed: 2000,
                autoplaySpeed: 500,
                slidesToShow: 1,
                pauseOnHover:true,
                slidesToScroll:3,
                swipeToSlide:true
            });
            $('.top-append-to').css('opacity','1')
        },
        carouselInit: function() {
            var carousel = $(".carousel");
            var num = 51.42;
            function autoplay(){

                etoro_lp.page_action.UI.currdeg = etoro_lp.page_action.UI.currdeg - num;
                var currdeg = etoro_lp.page_action.UI.currdeg;
                carousel.css({"transform": "rotateY("+currdeg+"deg)"});

            }
         etoro_lp.page_action.UI.timerId = window.setInterval(function(){
                autoplay();
            },2000);
        },
        clearTimeout_carousel: function() {
            clearTimeout(etoro_lp.page_action.UI.timerId);
        },
      /*  get_instruments: {
            process_started: false,
            func: function () {
                var _this = this;
                $.when(
                etoro_lp.api.getData.rates(),
                etoro_lp.api.getData.avatar()
                ).then(
                    function () {
                        _this.createUI();
                        _this.createTableUI();
                        if (etoro_lp.settings.explorer == "1") {
                            $('.top-append-to').slick('slickPlay');
                        }

                    },
                    function () {
                        console.log('error');
                    }
                )
            }
        }*/
    }
};

/*===================== Rates  =======================*/
etoro_lp.api.init()
    var a="1";
/*======================== MENU  ===========================*/

(function() {
    var selected_lang = document.querySelectorAll('[data-culture="' + etoro_lp.settings.culture + '"]')[0].innerText;
    var selected = document.querySelectorAll('.s1 .languages .selected')[0];
    selected.classList.add(etoro_lp.settings.culture);
    document.querySelectorAll('.s1 .languages .selected .txt')[0].innerText = selected_lang;

})();


document.addEventListener("page_ready", function() {

    $(document).ready(function(e) {

        $(window).on('hashchange', function() {
            console.log(55);
            if (location.hash == '#languages') {

            } else {
                $('.s1 nav ul > li.languages').removeClass('open')
                $('.s1').attr('data-fx', 'up');
            }
        });

        /*==============CAROUSEL=======================*/

        $('.carousel').mouseenter(function(){
            etoro_lp.page_action.UI.clearTimeout_carousel();

        });
        $('.carousel').mouseleave(function(){

            etoro_lp.page_action.UI.carouselInit();
        });

        /*======================== HEADER ===========================*/


        etoro_lp.tools.bind_click_outside('.s1 nav ul > li.dd > a', '.s1 nav ul > li.dd');
        $("body").on("click", ".s1 .navbar_mobile", function(e) {
            console.log(344);
            $('.s1 .navigation').addClass('open');
            $('html').addClass("hidden_overflow");
            $(document).bind('mousedown', function(e) {
                console.log(11);
                if ($(e.target).hasClass('close')) {
                    $('.s1 .navigation.open').removeClass("open");
                    $('html').removeClass("hidden_overflow");
                } else if (($(e.target).hasClass('open') || $(e.target).parents('*').hasClass('open'))) {

                } else {
                    $('.s1 .navigation').removeClass("open");
                    $('html').removeClass("hidden_overflow");
                    $(document).unbind('mousedown');
                }
            });
            return false;

        });
        /*======================== Third Party scripts ===========================*/
        etoro_lp.trd_party.init();
        $('[data-animation]').each(function(i) {
            var $el = $(this);
            var _offset = $el.attr('data-offset');
            var _timeout = $el.attr('data-timeout');
            var element_affected = $el.attr('data-element');

            if (!_offset) _offset = '100%';
            if (!_timeout) _offset = '0';
            if (!element_affected) element_affected = $el;
            $el.waypoint(function(direction) {
                if ($('body').attr('data-mode') == 'signup') {
                    return;
                }
                if (direction === 'down') {
                    $(element_affected).attr('data-fx', 'down');
                } else if (direction === 'up') {
                    $(element_affected).attr('data-fx', 'down_timeout');
                    setTimeout(function() {
                        $(element_affected).attr('data-fx', 'up');
                    }, _timeout)

                }
            }, {
                offset: _offset
            });
        });



        $("body").on("click", '.scroll_down', function(e) {
            $('html, body').animate({
                scrollTop: $(".s2").offset().top
            }, 1000);
            e.preventDefault();

        });

        /*======================== CULTURE ===========================*/

        $("body").on("click", "nav [data-culture]", function(e) {
            var new_culture = $(this).attr('data-culture');
            var new_url = etoro_lp.tools.updateQueryStringParameter(location.href,'culture',new_culture);
            window.location.href=new_url;
            e.preventDefault();

        });
        /*======================== POPUP ===========================*/


        $("body").on("click", '.s1 .right .close', function(e) {
            $('html').removeClass('popup_active');
            if(etoro_lp.settings.explorer == "1"){
                $('.top-append-to').slick('slickPlay');
            }
            $('.s1 .left').css('width', '');
            e.preventDefault();

        });


        /*======================== LAZY LOAD  ===========================*/
        $('.pending[data-lazy]').each(function(i) {
            var $el = $(this);

            $el.waypoint(function(direction) {
                $el.removeClass('pending');
            }, {
                offset: '100%'
            });


        });

        $('[data-action]').each(function(i) {
            var $el = $(this);
            $el.waypoint(function(direction) {
                var func_obj = etoro_lp.page_action.UI[$el.attr('data-action')];
                if(func_obj){
                    if (!func_obj.process_started){
                        func_obj.process_started = true;

                        func_obj.func.call(etoro_lp.page_action.UI);
                    }
                }
            }, {
                offset: '100%'
            });
        });

        etoro_lp.tracking.track('Page View LP',{});

    });


});