import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, App } from 'ionic-angular';
import { RestProvider } from '../../providers/rest/rest';
import { SettingprivacyPage } from '../settingprivacy/settingprivacy';
import { CrmfollowersViewPage } from '../crmfollowers-view/crmfollowers-view';
import { EditleadscustomerPage } from '../editleadscustomer/editleadscustomer';

/**
 * Generated class for the CrmFollowersPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-crm-followers',
  templateUrl: 'crm-followers.html',
})
export class CrmFollowersPage {
  followersList: any=[];

  constructor(public navCtrl: NavController,private service: RestProvider, public app :App,public navParams: NavParams) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad CrmFollowersPage');
    this.getFollowers();
  }
  back(){
    this.navCtrl.pop();
  }

  doRefresh(refresher) {
    console.log('Begin async operation', refresher);
     this.getFollowers();
    setTimeout(() => {
      console.log('Async operation has ended');
      refresher.complete();
    }, 2000);
  }

  doPulling(refresher) {
    // console.log('DOPULLING', refresher.progress);
  //   console.log('Begin async operation', refresher);
  //   this.getFollowers();
  //  setTimeout(() => {
  //    console.log('Async operation has ended');
  //    refresher.complete();
  //  }, 2000);
  }
  setting(){
    this.app.getRootNav().push(SettingprivacyPage);
  }
  follwerstitle(data){
    console.log(data);
    console.log(data['extra']['customer'].id); 
    if(data['extra']['customer'].id){
      localStorage.setItem('customer_id',data['extra']['customer'].id);
      // this.navCtrl.push(EditleadscustomerPage);
      this.app.getRootNav().push(EditleadscustomerPage);
    }
    

  }
  getFollowers() {
    this.service.presentLoadingDefault('Loading...');
    this.service.get('followers/list?follco_token=' + localStorage.getItem('new_token'),0).subscribe(res =>{
        console.log(res);
        if(res) {
            this.service.dismissLoading();
            this.followersList = res['list'];
            
            // this.time = new Date (this.campaignList[0].created_at);
            // this.time1 =this.time.getDate() + '/' + (this.time.getMonth()+1) + '/' + this.time.getFullYear();
            console.log(this.followersList[0]['extra']['customer'].id); 
         
          
        }
    }, err => {
        this.service.dismissLoading();
        console.log(err);
    })
}
}
