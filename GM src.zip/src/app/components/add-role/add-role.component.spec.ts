import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { AddRoleComponent } from './add-role.component';
import { SharedModuleModule } from 'src/app/shared-module/shared-module.module';
import { MarketingSidebarComponent } from '../sidebar/sidebar.component';
import { RouterModule } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { AppComponent } from 'src/app/app.component';
import { DeviceDetectorService } from 'ngx-device-detector';
import { FormGroup, FormControl, Validators } from '@angular/forms';
declare var $: any;
describe('AddRoleComponent', () => {
  let component: AddRoleComponent;
  let fixture: ComponentFixture<AddRoleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddRoleComponent, MarketingSidebarComponent,  ],
      imports: [SharedModuleModule, RouterModule,
        RouterTestingModule,],
        providers: [AppComponent, DeviceDetectorService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddRoleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    component.addForm = new FormGroup({
      name: new FormControl('', [Validators.required, Validators.pattern(/^[a-z ,.'-]+$/i), Validators.maxLength(30), Validators.minLength(2)])
  })
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('general form invalid when empty', async(() => {
    const emptyValue = component.addFormTest('');
    expect(emptyValue).toBeFalsy();
  }));

  it('general form valid with all fields', async(() => {
    const value = component.addFormTest('admin');
    expect(value).toBeTruthy();
  }));

});
