import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ParticularFaDetailComponent } from './particular-fa-detail.component';

describe('ParticularFaDetailComponent', () => {
  let component: ParticularFaDetailComponent;
  let fixture: ComponentFixture<ParticularFaDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ParticularFaDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ParticularFaDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
