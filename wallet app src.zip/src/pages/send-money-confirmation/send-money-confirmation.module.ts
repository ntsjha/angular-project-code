import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SendMoneyConfirmationPage } from './send-money-confirmation';

@NgModule({
  declarations: [
    SendMoneyConfirmationPage,
  ],
  imports: [
    IonicPageModule.forChild(SendMoneyConfirmationPage),
  ],
})
export class SendMoneyConfirmationPageModule {}
