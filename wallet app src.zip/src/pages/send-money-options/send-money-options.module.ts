import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SendMoneyOptionsPage } from './send-money-options';

@NgModule({
  declarations: [
    SendMoneyOptionsPage,
  ],
  imports: [
    IonicPageModule.forChild(SendMoneyOptionsPage),
  ],
})
export class SendMoneyOptionsPageModule {}
