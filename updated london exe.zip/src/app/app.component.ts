import { Component } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Router, NavigationEnd } from '@angular/router';
import { Observable, Subject } from '../../node_modules/rxjs';
import { ServerService } from './service/server.service';
declare var $:any;

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.css']
})
export class AppComponent {
    title = 'app';
    exchange:any;
    private subject = new Subject<any>();
    display: any;

    constructor(private toasterService: ToastrService, private router:Router, public server: ServerService) {
        var self = this;
        $( document ).bind( "mousedown", function(e) {
            if(e.button == 0){
                self.checkSession();
            }
        });
    }

    /** Function to initWsSocket*/
    initWsSocket() {
        localStorage.getItem("token") ? this.server.initSocket(localStorage.getItem("token")) : this.server.initSocket("notLoggedIn");
    }

    fireToChild(): Observable<any> {
        return this.subject.asObservable();
    }

    ngOnInit() {
        this.initWsSocket();
        this.checkSession();
        this.router.events.subscribe(x=> {
            if(x instanceof NavigationEnd) {
                //this.subject.next({text: "url_Changed"});
                if(localStorage.getItem('token')!= null)  {
                    if((x.url == 'header/login')|| (x.url == 'header/signup')) {
                        this.router.navigate(['header']);
                    }
                    else {                    
                        localStorage.removeItem('exchange');
                        if(x.url=='/exchange') {
                            localStorage.setItem('exchange','true');
                        
                        }
                    }
                }
                /** url mgmt before login */
                else {
                    if((x.url == '/header/wallet') || (x.url == '/header/kyc') || (x.url == '/header/change') ||(x.url == '/header/withdraw') || (x.url == '/header/dashboard') ||(x.url == '/header/reset') || (x.url == '/header/edit') || (x.url == '/header/deposit') || (x.url == '/header/kyc') || (x.url == '/header/buySell') || (x.url == '/header/account')) {
                        this.router.navigate(['header'])
                    } else {                    
                        localStorage.removeItem('exchange');
                        if(x.url=='/exchange') {
                            localStorage.setItem('exchange','true');                        
                        }
                    }
                }
            }
        })
    }

    /** Function to show success toast */
    showSuccToast(msg) {
        this.toasterService.success(msg, "CryptoExchange");
    }

    /** Function to show error toast */
    showErrToast(msg) {
        this.toasterService.error(msg, "CryptoExchange");
    }

    /** Function to show warning toast */
    showWarnToast(msg) {
        this.toasterService.warning(msg, "CryptoExchange");
    }

    /** Function to show info toast */
    showInfoToast(msg) {
        this.toasterService.info(msg, "CryptoExchange");
    }

    /** Function for check session */
    checkSession() {
        if(localStorage.getItem('token') != null && localStorage.getItem('session') != null) {
            let minDiff = this.diff_minutes(parseInt(localStorage.getItem('session')), new Date().getTime());
            localStorage.setItem('session',new Date().getTime().toString());
            if(minDiff >= 10){
                this.logout();
            }
        } else
            localStorage.setItem('session',new Date().getTime().toString());
    }

    /** Function to get diffrence between timestamp */
    diff_minutes(dt2, dt1) {
        var diff = (dt2 - dt1) / 1000;
        diff /= 60;
        return Math.abs(Math.round(diff));
    }

    /** Function for logout user */
    logout() {
        let data = {
            "eventExternal": {
                "name":"request_logout",
                "key":"mykey"
            },
           "transferObjectMap": {
               "gatewayrequest": {
                   "token": localStorage.getItem("token")
                }
            }
        }
        this.server.postApi('',data,0).subscribe((res) => {
            if(res.transferObjectMap.statusCode == 200 || res.transferObjectMap.statusCode == 403) {
                let data = {
                    messageType:"userUpdated",
                    token: "notLoggedin"
                }
                this.server.wsExchange.send(JSON.stringify(data));
                localStorage.clear();
                this.subject.next({text: "sessionExpire"});
                this.router.navigate(['header']);
            } else {
                localStorage.clear();
                this.router.navigate(['header']);
            }
        }, (err) => {
        });        
    }
}





    
    
    