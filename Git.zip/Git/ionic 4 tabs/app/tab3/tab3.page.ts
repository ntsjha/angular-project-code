
import { NavController } from '@ionic/angular';
import { Router } from '@angular/router';
import {Component} from '@angular/core';
import {FormBuilder, FormGroup, Validators, FormControl} from '@angular/forms';


@Component({
  selector: 'app-tab3',
  templateUrl: 'tab3.page.html',
  styleUrls: ['tab3.page.scss']
})
export class Tab3Page {
  public forgetForm: FormGroup;

  constructor(public router: Router, public formBuilder: FormBuilder) {

      this.forgetForm = formBuilder.group({

     email: new FormControl ('', [Validators.required,Validators.pattern(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/)]),
      mobileno:new FormControl ('', [Validators.required,Validators.pattern(/^\+?\d{2}[- ]?\d{3}[- ]?\d{5}$/)] ),
      });

  }

  onforget() {
      
      console.log(this.forgetForm.value);
      //this.router.navigateByUrl('/referring-physician');
  }


}
