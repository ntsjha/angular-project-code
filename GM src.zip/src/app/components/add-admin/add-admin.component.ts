import { Component, OnInit, AfterViewInit, NgZone, OnDestroy } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ServiceService } from 'src/app/service/service.service';
import { CookieService } from 'ngx-cookie-service';
import { NgxSpinnerService } from 'ngx-spinner';
import { Router } from '@angular/router';
import { AppComponent } from 'src/app/app.component';

declare var $: any;

@Component({
    selector: 'app-add-admin',
    templateUrl: './add-admin.component.html',
    styleUrls: ['./add-admin.component.css']
})
export class AddAdminComponent implements OnInit, AfterViewInit, OnDestroy {
    addAdmin: FormGroup;
    userIp: any;
    showApiMessage: any = false;
    response: any = {};
    google: any = { one: '', two: '', three: '', four: '', five: '', six: '' };
    permissionArray: any = [];
    setPermissionArray: any = [];
    OTPPhoneValidOrNot: any = true;
    baseUrl: string;
    subscription: any;
    arr: any[];

    constructor(
        private service: ServiceService,
        private cookie: CookieService,
        private spinner: NgxSpinnerService,
        private zone: NgZone,
        private router: Router,
        private appC: AppComponent
    ) {
        this.addAdmin = new FormGroup({
            firstName: new FormControl('', [Validators.required, Validators.pattern(/^[a-zA-Z]*$/i), Validators.maxLength(255), Validators.minLength(2)]),
            lastName: new FormControl('', [Validators.required, Validators.pattern(/^[a-zA-Z]*$/i), Validators.maxLength(255), Validators.minLength(2)]),
            email: new FormControl('', [Validators.required, Validators.pattern(/^[a-zA-Z0-9_+&*-]+(?:\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,7}$/), Validators.maxLength(255)]),
            phone: new FormControl('', [Validators.required, Validators.pattern(/^[0-9]*$/), Validators.maxLength(15)]),
            gender: new FormControl('', [Validators.required]),

        });

        this.userIp = (this.cookie.get('userInfo')) ? JSON.parse(this.cookie.get('userInfo')) : this.service.initialUserInfo;
        this.subscription = this.service.authVerify.subscribe(val => {
            if (val === 'add-admin') {
                this.addAdminFunc();
                this.service.authVerify.next('false');
            }
        });
    }

    /** Function to get input data */
    get firstName(): any {
        return this.addAdmin.get('firstName');
    }

    get lastName(): any {
        return this.addAdmin.get('lastName');
    }

    get email(): any {
        return this.addAdmin.get('email');
    }

    get phone(): any {
        return this.addAdmin.get('phone');
    }

    get gender(): any {
        return this.addAdmin.get('gender');
    }

    /** Function to send value */
    addAdminTest(...val) {
        this.addAdmin.controls.firstName.setValue(val[0]);
        this.addAdmin.controls.lastName.setValue(val[1]);
        this.addAdmin.controls.email.setValue(val[2]);
        this.addAdmin.controls.phone.setValue(val[3]);
        this.addAdmin.controls.gender.setValue(val[4]);
        return this.addAdmin.valid;
    }

    ngOnInit() {
        window.scrollTo(0, 0);
    }

    ngAfterViewInit() {
        this.getCountries();
        this.getPermission();
    }


    ngOnDestroy() {
        this.subscription.unsubscribe();
    }

    getCountries() {
        this.service.currentUserInfo.subscribe(currInfo => {
            if (currInfo.country_code) {
                this.initializePhone(currInfo.country_code.toLowerCase());
            } else {
                this.initializePhone('TH');
            }
        }, error => {
            this.initializePhone('TH');
        });
    }

    createArr() {
        this.arr = [];
        this.permissionArray.forEach(element => {
            if (element.masterPermissionList.menuPermission.menuName) {
                this.arr.push(element);
            }
        });
        this.permissionArray.forEach(element => {
            if (element.masterPermissionList.menuPermission.subMenuName) {
                this.arr.forEach((menu, ind) => {
                    if (menu.masterPermissionList.masterPermissionListId == element.masterPermissionList.parentId) {
                        this.arr.splice(ind + 1, 0, element);
                    }
                });
            }
        });
    }

    getPermission() {
        this.service.postMethod('account/superAdmin/user-management/get-role-wise-role-permission?roleId=16', {}, 1)
            .subscribe((response) => {
                if (response.status == 2005) {
                    this.permissionArray = response.data;
                    this.selectAllPermission();
                    this.createArr();
                }
            });
    }


    initializePhone(data) {
        $('#phoneNum').intlTelInput({
            autoPlaceholder: true,
            autoFormat: false,
            autoHideDialCode: false,
            initialCountry: data,
            nationalMode: false,
            preferredCountries: [data],
            formatOnInit: true,
            separateDialCode: true
        });
        this.telInputFunc();
    }

    // change validation on change the country
    telInputFunc() {
        $(document).on('click', '.country', () => {
            this.phoneValidOrNot();
        });
    }

    phoneValidOrNot() {
        this.zone.run(() => {
            this.OTPPhoneValidOrNot = $('#phoneNum').intlTelInput('isValidNumber');
        });
    }

    clearAllPermission() {
        this.setPermissionArray = [];
    }

    selectAllPermission() {
        this.setPermissionArray = [];
        this.permissionArray.forEach(element => {
            const data = {
                masterPermissionList: {
                    masterPermissionListId: element.masterPermissionList.masterPermissionListId
                }
            };
            this.setPermissionArray.push(data);
        });
    }

    /** Function to verify google authentication */
    verifyGoogleAuth() {
        if (this.addAdmin.invalid) {
            return;
        }
        let count = 0;
        for (let i = 0; i < this.setPermissionArray.length; i++) {
            count = 0;
            const index = this.permissionArray.findIndex((x) => x.masterPermissionList.masterPermissionListId === this.setPermissionArray[i].masterPermissionList.masterPermissionListId)

            if (!this.permissionArray[index].masterPermissionList.isMenu) {
                const parentId = this.permissionArray[index].masterPermissionList.parentId;
                const parentExsits = this.setPermissionArray.findIndex((x) => x.masterPermissionList.masterPermissionListId == parentId);
                if (parentExsits == -1) {
                    const mx = document.getElementById('#permission' + parentId);
                    mx.style.color = 'red';
                    count++;
                }
            }
            if (count != 0) {
                window.scrollTo(0, 0);
                $('#confirmation-modal').modal('show');
                return false;
            }
        }
        this.appC.google = { one: '', two: '', three: '', four: '', five: '', six: '' };
        this.appC.response = { message: '' };
        this.service.googleAuthCalledFrom = 'add-admin';
        $('#google-auth-modal').modal({ keyboard: false, backdrop: 'static' });
    }

    checkData(id) {
        let total = 0;
        this.setPermissionArray.forEach(element => {
            if (element.masterPermissionList.masterPermissionListId === id) {
                total = 1;
            }
        });
        if (total === 1) {
            total = 0;
            return true;
        } else {
            return false;
        }
    }

    setPermission(dataObj) {
        let data = {};
        let pushData = 0;
        if (this.setPermissionArray.length > 0) {
            this.setPermissionArray.forEach((element, index) => {
                if (element.masterPermissionList.masterPermissionListId === dataObj.masterPermissionList.masterPermissionListId) {
                    this.setPermissionArray.splice(index, 1);
                    pushData++;
                }
            });
            if (pushData === 0) {
                data = {
                    masterPermissionList: {
                        masterPermissionListId: dataObj.masterPermissionList.masterPermissionListId
                    }
                };
                this.setPermissionArray.push(data);
            }

        } else {
            data = {
                masterPermissionList: {
                    masterPermissionListId: dataObj.masterPermissionList.masterPermissionListId
                }
            };
            this.setPermissionArray.push(data);
        }
        this.checkForParent(dataObj);
    }

    checkForParent(dataObj) {
        let count = 0;
        this.setPermissionArray.forEach((element) => {
            if (dataObj.masterPermissionList.isMenu) {
                if (element.masterPermissionList.masterPermissionListId === dataObj.masterPermissionList.masterPermissionListId) {
                    count++;
                }
            } else {
                if (element.masterPermissionList.masterPermissionListId === dataObj.masterPermissionList.parentId) {
                    count++;
                }
            }
        });
        const pushOrPop = this.setPermissionArray.findIndex((z) => z.masterPermissionList.masterPermissionListId === dataObj.masterPermissionList.masterPermissionListId);
        if (count) {
            if (dataObj.masterPermissionList.isMenu) {
                const mx = document.getElementById('#permission' + dataObj.masterPermissionList.masterPermissionListId);
                if (pushOrPop != -1) {
                    this.permissionArray.forEach((element) => {
                        if (element.masterPermissionList.parentId === dataObj.masterPermissionList.masterPermissionListId) {
                            const indIndex = this.setPermissionArray.findIndex((x) => x.masterPermissionList.masterPermissionListId === element.masterPermissionList.masterPermissionListId);
                            const childExsist = this.setPermissionArray.findIndex((x) => x.masterPermissionList.masterPermissionListId === element.masterPermissionList.masterPermissionListId);
                            if (childExsist === -1) {
                                const obj = {
                                    masterPermissionList: {
                                        masterPermissionListId: element.masterPermissionList.masterPermissionListId
                                    }
                                };
                                this.setPermissionArray.push(obj);
                            }
                        }
                    });
                }
                mx.style.color = 'black';
            }
        } else {
            if (!dataObj.masterPermissionList.isMenu) {
                $('#confirmation-modal').modal('show');
            } else {
                this.permissionArray.forEach((element) => {
                    if (element.masterPermissionList.parentId === dataObj.masterPermissionList.masterPermissionListId) {
                        const indIndex = this.setPermissionArray.findIndex((x) => x.masterPermissionList.masterPermissionListId === element.masterPermissionList.masterPermissionListId);
                        if (indIndex != -1) {
                            this.setPermissionArray.splice(indIndex, 1);
                        }
                    }
                });
            }
        }
    }

    /** Function to add admin */
    addAdminFunc() {
        if (!this.OTPPhoneValidOrNot || this.addAdmin.invalid || !this.setPermissionArray.length) {
            if (!this.setPermissionArray.length) {
                this.showApiMessage = true;
                this.response.message = 'Please select some permissions!';
            }
            return;
        }
        this.spinner.show();
        const countryCodeFetched = $('#phoneNum').intlTelInput('getSelectedCountryData');
        const countryCode = '+' + countryCodeFetched.dialCode;
        this.baseUrl = this.service.adminBaseUrl + '?email=' + this.addAdmin.value.email + '&';
        const data = {
            email: this.addAdmin.value.email,
            firstName: this.addAdmin.value.firstName,
            gender: this.addAdmin.value.gender,
            ipAddress: this.userIp.ip,
            lastName: this.addAdmin.value.lastName,
            location: this.userIp.city + ', ' + this.userIp.country_name,
            phoneNo: $('#phoneNum').intlTelInput('getNumber'),
            roleId: '16',
            userPermissions: this.setPermissionArray,
            webUrl: this.baseUrl,
            countryCode,
            languageName: this.service.encrypt('en')
        };
        this.service.postMethod('account/superAdmin/user-management/add-admin', data, 1).subscribe((response: any) => {
            if (response.status === 910) {
                this.showApiMessage = true;
                this.response = response;
                this.response.message = 'Admin added successfully.Please check your mailbox and verify your email.';
            } else {
                this.showApiMessage = true;
                this.response = response;
            }
            this.spinner.hide();
            window.scrollTo(0, 0);
        }, (error) => {
            window.scrollTo(0, 0);
            if (error.error) {
                this.showApiMessage = true;
                this.response = error.error;
                this.spinner.hide();
            } else {
                this.showApiMessage = true;
                this.response = 'Something went wrong!';
                this.spinner.hide();
            }
        });

    }

    /** Auto focus functionality */
    onKey(event, next, previous) {
        if (event.key === 'Backspace') {
            document.getElementById(previous).focus();
        } else {
            if (event.keyCode >= 48 && event.keyCode <= 57) {
                if (event.target.value.trim() !== '') {
                    document.getElementById(next).focus();
                } else {
                    event.target.value = '';
                }
            } else {
                event.target.value = '';
            }
        }
    }

}
