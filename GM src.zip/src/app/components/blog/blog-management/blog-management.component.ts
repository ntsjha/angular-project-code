import { FormControl, FormGroup } from '@angular/forms';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { ServiceService } from 'src/app/service/service.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { ngxCsv } from 'ngx-csv/ngx-csv';
import { AppComponent } from 'src/app/app.component';

declare var $: any;
@Component({
  selector: 'app-blog-management',
  templateUrl: './blog-management.component.html',
  styleUrls: ['./blog-management.component.css']
})
export class BlogManagementComponent implements OnInit, OnDestroy {

  modalType: any;
  paginationData: any = { limit: 10, currPage: 1, total: 0 };
  searchForm: any;
  blogList: any = [];
  selectedData: any;
  userInfo: any;
  englishShortCode: any;
  subscription: any;

  constructor(
    private service: ServiceService,
    private spinner: NgxSpinnerService,
    private appC: AppComponent
  ) {
    this.englishShortCode = this.service.englishLanguageShortCode;
    this.subscription = this.service.authVerify.subscribe(val => {
      if (val == 'blog-mgmt') {
        this.deleteBlog();
        this.service.authVerify.next('false');
      }
    });
  }

  ngOnInit() {
    window.scrollTo(0, 0);
    this.form();
    this.getIpAddress();
    this.getBlogList('reset');
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  /** Function to verify google authentication */
  verifyGoogleAuth() {
    $('#unPublishdeleteModal').modal('hide');
    this.appC.google = { one: '', two: '', three: '', four: '', five: '', six: '' };
    this.appC.response = { 'message': '' };
    this.service.googleAuthCalledFrom = 'blog-mgmt';
    $('#google-auth-modal').modal({ keyboard: false, backdrop: 'static' });

  }

  form() {
    this.searchForm = new FormGroup({
      search: new FormControl(null),
      status: new FormControl(null)
    });
  }

  getIpAddress() {
    this.service.userInfo.subscribe(success => {
      this.userInfo = success;
    });
  }

  getBlogList(event) {
    let apireq;
    this.spinner.show();
    if (event === 'reset') {
      apireq = {
        page: this.service.encrypt(this.paginationData.currPage - 1),
        pageSize: this.service.encrypt(this.paginationData.limit),
        search: null,
        status: null
      };
      this.paginationData.currPage = 1;
    } else {
      if (event === 'apply') {
        apireq = {
          page: this.service.encrypt(0),
          pageSize: this.service.encrypt(this.paginationData.limit),
          search: (this.searchForm.value.search != null) ? this.service.encrypt(this.searchForm.value.search.trim()) : null,
          status: (this.searchForm.value.status === null || this.searchForm.value.status === 'null') ? null : (this.searchForm.value.status === 'true' ? this.service.encrypt(true) : this.service.encrypt(false))
        };
      } else {
        apireq = {
          page: this.service.encrypt(this.paginationData.currPage - 1),
          pageSize: this.service.encrypt(this.paginationData.limit),
          search: (this.searchForm.value.search != null) ? this.service.encrypt(this.searchForm.value.search.trim()) : null,
          status: (this.searchForm.value.status === null || this.searchForm.value.status === 'null') ? null : (this.searchForm.value.status === 'true' ? this.service.encrypt(true) : this.service.encrypt(false))
        };
      }
    }
    this.service.postMethod('blog/admin/search-and-filter-blog-list', apireq, 1).subscribe(success => {
      this.spinner.hide();
      const decryptedData = success.data ? JSON.parse(this.service.decrypt(success.data)) : {};
      if (decryptedData.status === 634) {
        this.blogList = decryptedData.data.reasponseData;
        this.paginationData.total = decryptedData.data.size;
        this.blogList.forEach(element => {
          if(element.updatedBy == null) {
            element.updatedAt = null;
          }
        });
      } else {
        this.blogList = [];
      }
    }, error => {
      this.spinner.hide();
      this.blogList = [];
    });
  }

  changePage(event) {
    this.paginationData.currPage = event;
    this.getBlogList('apply1');
  }

  openModal(data, whichModal) {
    const type = (whichModal === 'delete') ? 'deleteBlogs' : 'publish/UnpublishBlogs';
    if (this.service.sideMenuArr.includes(type)) {
      this.modalType = whichModal;
      this.selectedData = data;
      $('#unPublishdeleteModal').modal({ backdrop: 'static', keyboard: false });
    }
  }

  yesModal() {
    if (this.modalType === 'unpublish' || this.modalType === 'publish') {
      this.publishUnpublishModal();
    } else {
      if (this.modalType === 'delete') {
        this.verifyGoogleAuth();
      }
    }
  }

  publishUnpublishModal() {
    this.spinner.show();
    this.service.postMethod(`blog/admin/publish-unpublish-blog?contentId=${encodeURIComponent(this.service.encrypt(this.selectedData.contentId))}&ipAddress=${encodeURIComponent(this.service.encrypt(this.userInfo.ip))}&location=${encodeURIComponent(this.service.encrypt(this.userInfo.country_name))}`, {}, 1).subscribe(success => {
      this.spinner.hide();
      if (success.status === 624) {
        $('#unPublishdeleteModal').modal('hide');
        this.getBlogList('apply');
      }
    }, error => {
      this.spinner.hide();
    });
  }

  deleteBlog() {
    this.spinner.show();
    this.service.postMethod(`blog/admin/delete-blog?contentId=${encodeURIComponent(this.service.encrypt(this.selectedData.contentId))}&ipAddress=${encodeURIComponent(this.service.encrypt(this.userInfo.ip))}&location=${encodeURIComponent(this.service.encrypt(this.userInfo.country_name))}`, {}, 1).subscribe(succ => {
      this.spinner.hide();
      if (succ.status === 622) {
        this.getBlogList('apply');
      }
    }, error => {
      this.spinner.hide();
    });
  }

  exportCSV() {
    const options = {
      fieldSeparator: ',',
      quoteStrings: '"',
      decimalseparator: '.',
      showLabels: true,
      showTitle: true,
      title: 'Blog Management',
      useBom: true,
      noDownload: false,
      headers: ['Blog Title', 'Created At', 'Created By', 'Updated At', 'Updated By', 'Status']
    };
    const arr = [];
    this.blogList.forEach((element, i) => {
      arr.push({ title: element.title, createdAt: (this.service.transformDate(element.createdAt)), createdBy: element.createdBy, updatedAt: (this.service.transformDate(element.updatedAt)), updatedBy: element.updatedBy, status: ((element.status) ? 'Published' : 'Un-published') });
    });
    const importArr = arr;
    new ngxCsv(importArr, 'blog', options);
  }
}
