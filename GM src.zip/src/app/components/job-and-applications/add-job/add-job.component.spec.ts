import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddJobComponent } from './add-job.component';
import { FormGroup, FormControl, Validators } from '@angular/forms';

describe('AddJobComponent', () => {
  let component: AddJobComponent;
  let fixture: ComponentFixture<AddJobComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddJobComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddJobComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    this.addJobForm = new FormGroup({
      title: new FormControl('', [Validators.required]),
      editorValue: new FormControl('', [Validators.required]),
      noOfOpenings: new FormControl('', [Validators.required])
  })
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  
  it('general form invalid when empty', async(() => {
    const emptyValue = component.addJobFormTest('','','');
    expect(emptyValue).toBeFalsy();
  }));

  it('general form valid with all fields', async(() => {
    const value = component.addJobFormTest('title','description','5');
    expect(value).toBeTruthy();
  }));
});
