import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ServiceService } from 'src/app/service/service.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { Router } from '@angular/router';
import { AppComponent } from 'src/app/app.component';
declare var $: any;

@Component({
  selector: 'app-standard-trading-fee',
  templateUrl: './standard-trading-fee.component.html',
  styleUrls: ['./standard-trading-fee.component.css']
})
export class StandardTradingFeeComponent implements OnInit {
  stdTradingFee: FormGroup;
  response: any = {'message': ''};
  subscription: any;

  constructor(
    private service: ServiceService,
    private spinner: NgxSpinnerService,
    private route: Router, private appC: AppComponent) {
    this.stdTradingFee = new FormGroup({
      takerFee: new FormControl(null, [Validators.required]),
      makerFee: new FormControl(null, [Validators.required]),
    });
    this.subscription = this.service.authVerify.subscribe(val => {
      if (val === 'std-fee') {
        this.standardTradingFee();
        this.service.authVerify.next('false');
      }
    });
  }
  ngOnInit() {
    window.scrollTo(0, 0);
    this.getStdTrading();
  }
  
  getStdTrading() {
    this.spinner.show();
    this.service.getMethod('fee/fetch-taker-maker', 1).subscribe((response: any) => {
      this.spinner.hide();
      if (response.status === 200) {
        if(response.data.length) {
          this.stdTradingFee.patchValue({
            takerFee: response.data[0].standardTakerfee ,
            makerFee: response.data[0].standardMakerFee ,
          })
        } else {
          this.stdTradingFee.patchValue({
            takerFee: response.data.standardTakerfee ,
            makerFee: response.data.standardMakerFee ,
          })
        }
      }
    }, (error) => {
      this.spinner.hide();
    });
    this.spinner.hide();
  }

  standardTradingFee() {
    this.spinner.show();
    this.service.postMethod('fee/set-minimum-and-standard-taker-maker?feeEnum=STANDARD&makerFee=' + this.stdTradingFee.value.makerFee + '&takerFee=' + this.stdTradingFee.value.takerFee, {}, 1).subscribe((response: any) => {
      this.spinner.hide();
      if (response.status === 200) {
        this.route.navigate(['/standard-trading']);
      } else {
        this.response = response;
      }
    }, (error) => {
      this.spinner.hide();
    });
  }

  open2FAmodal() {
    this.appC.google = { one: '', two: '', three: '', four: '', five: '', six: '' };
    this.appC.response = { message: '' };
    this.service.googleAuthCalledFrom = 'std-fee';
    $('#google-auth-modal').modal({ keyboard: false, backdrop: 'static' });
  }

}
