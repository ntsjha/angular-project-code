import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OtcCustomersComponent } from './otc-customers.component';

describe('OtcCustomersComponent', () => {
  let component: OtcCustomersComponent;
  let fixture: ComponentFixture<OtcCustomersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OtcCustomersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OtcCustomersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
