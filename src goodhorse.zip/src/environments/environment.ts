// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.



//Graham Credential 
export const environment ={
  production: false,
  firebase : {
    apiKey: "AIzaSyB75uP3PPpv1Hrxev03WM94yE1n_i2_0xs",
    authDomain: "mygoodhorse-25c19.firebaseapp.com",
    databaseURL: "https://mygoodhorse-25c19.firebaseio.com",
    projectId: "mygoodhorse-25c19",
    storageBucket: "mygoodhorse-25c19.appspot.com",
    messagingSenderId: "778903623071",
    appId: "1:778903623071:web:fbc407afc2509c20"
  },
};



// Aashish
//  export const environment ={
//   production: false,
//   firebase: {
//     apiKey: "AIzaSyAOJeg_8GM4bgd52qFSJuQeb7nYYwI_sc4",
//     authDomain: "goodhorseionic.firebaseapp.com",
//     databaseURL: "https://goodhorseionic.firebaseio.com",
//     projectId: "goodhorseionic",
//     storageBucket: "goodhorseionic.appspot.com",
//     messagingSenderId: "857097522588"
//   }
// };


//Vaishali
// export const environment =
// {
//   production: false,
//   firebase: {
//     apiKey: "AIzaSyB2eXBbKBuhd0zH5dhf-udubJCbWH2jvOY",
//     authDomain: "goodhorse-64dd1.firebaseapp.com",
//     databaseURL: "https://goodhorse-64dd1.firebaseio.com",
//     projectId: "goodhorse-64dd1",
//     storageBucket: "goodhorse-64dd1.appspot.com",
//     messagingSenderId: "412739625021"
//   }
// };



/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
