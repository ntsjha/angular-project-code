import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ServiceService } from 'src/app/service/service.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { ActivatedRoute, Router } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'app-minimum-withdrawl-fiat',
  templateUrl: './minimum-withdrawl-fiat.component.html',
  styleUrls: ['./minimum-withdrawl-fiat.component.css']
})
export class MinimumWithdrawlFiatComponent implements OnInit {
  minimumFiatWithdrawl: FormGroup;
  currentUser: any;
  coinName: any;
  depositeFiat: any;
  userIp: any;

  constructor(
    private service: ServiceService,
    private spinner: NgxSpinnerService,
    private activatedRoute: ActivatedRoute,
    private cookie: CookieService,
    private route: Router) {
    this.minimumFiatWithdrawl = new FormGroup({
      fixedFee: new FormControl(null, [Validators.required, Validators.maxLength(8), Validators.pattern(/^[1-9][0-9]*$/)]),
      extraFee: new FormControl(null, [Validators.required, Validators.maxLength(8), Validators.pattern(/^[1-9][0-9]*$/)]),
      forFirst: new FormControl(null, [Validators.required, Validators.maxLength(8), Validators.pattern(/^[1-9][0-9]*$/)]),
      per: new FormControl(null, [Validators.required, Validators.maxLength(8), Validators.pattern(/^[1-9][0-9]*$/)]),

    });
    this.service.currentUserInfo.subscribe((response) => {
      this.currentUser = response;
    });
    this.userIp = (this.cookie.get('userInfo')) ? JSON.parse(this.cookie.get('userInfo')) : this.service.initialUserInfo;
  }

  ngOnInit() {
    this.activatedRoute.params.subscribe(id => {
      this.coinName = id.id;
    });
    this.minDepositFiat();
    window.scrollTo(0, 0);
  }

  minDepositFiat() {
    this.spinner.show();
    this.service.getMethod('wallet/admin/fees/get-fee-details?currencyName=' + this.coinName + '&currencyType=fiat', 1).subscribe((response: any) => {
      this.spinner.hide();
      const res = JSON.parse(this.service.decrypt(response.data));
      if (res.status === 845 || res.status === 842) {
        this.depositeFiat = res.data;
        this.loadform();
      }
    }, (error) => {
      this.spinner.hide();
    });
    this.spinner.hide();

  }

  loadform() {
    this.minimumFiatWithdrawl.patchValue({
      fixedFee: this.depositeFiat.minWithdrawalFixedFee,
      extraFee: this.depositeFiat.minExtraFee,
      forFirst: this.depositeFiat.minWithdrawalFixedFeeForFirst,
      per: this.depositeFiat.minExtraFeePer
    });
  }


  depositFiat() {
    this.spinner.show();
    const data = {
      coinName: this.coinName,
      extraFee: this.minimumFiatWithdrawl.value.extraFee,
      extraFeePer: this.minimumFiatWithdrawl.value.per,
      fixedFee: this.minimumFiatWithdrawl.value.fixedFee,
      fixedFeeForFirst: this.minimumFiatWithdrawl.value.forFirst,
      ipAddress: this.userIp.ip,
      location: this.userIp.city + ',' + this.userIp.country_name
    };

    this.service.postMethod('wallet/admin/fees/set-min-fiat-withdraw-fee', data, 1).subscribe((response: any) => {
      this.spinner.hide();
      if (response.status === 842) {
        this.route.navigate(['/minimum-withdrawl']);
      }
    }, (error) => {
      this.spinner.hide();
    });
  }
}
