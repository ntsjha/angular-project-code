import { Component, OnInit, OnDestroy } from '@angular/core';
import { CookieService } from 'ngx-cookie-service';
import { ServiceService } from 'src/app/service/service.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { AppComponent } from 'src/app/app.component';

declare var $: any;

@Component({
  selector: 'app-manage-trading-pair',
  templateUrl: './manage-trading-pair.component.html',
  styleUrls: ['./manage-trading-pair.component.css']
})
export class ManageTradingPairComponent implements OnInit, OnDestroy {
  getSecReport: any;
  disable: any = true;
  editThis: any = false;
  currentId: any;
  userIp: any;
  subscription: any;
  coin: any;

  constructor(
    private cookie: CookieService,
    private service: ServiceService,
    private spinner: NgxSpinnerService,
    private appC: AppComponent
  ) {
    this.subscription = this.service.authVerify.subscribe(val => {
      if (val === 'manage-trading') {
        this.updateTradingPair();
        this.service.authVerify.next('false');
      }
    });
  }

  ngOnInit() {
    this.userIp = (this.cookie.get('userInfo')) ? JSON.parse(this.cookie.get('userInfo')) : this.service.initialUserInfo;
    this.getDailyClouserTime();
    window.scrollTo(0, 0);
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  /** Function to verify google authentication */
  verifyGoogleAuth(data) {
    this.coin = data;
    this.appC.google = { one: '', two: '', three: '', four: '', five: '', six: '' };
    this.appC.response = { message: '' };
    this.service.googleAuthCalledFrom = 'manage-trading';
    $('#google-auth-modal').modal({ keyboard: false, backdrop: 'static' });
  }


  getDailyClouserTime() {
    this.spinner.show();
    this.service.getMethod('fee/get-trading-pairs', 1).subscribe((response: any) => {
      this.spinner.hide();
      if (response.status === 558) {
        this.getSecReport = response.data;
        this.getSecReport.forEach(element => {
          if(element.updatedBy == null) {
            element.updatedAt = null;
          }
        });
      }
    }, (error) => {
      this.spinner.hide();
    });
    this.spinner.hide();
  }

  editThisRow(id) {
    this.editThis = true;
    this.getSecReport[id].enabled = false;
  }

  updateTradingPair() {
    this.spinner.show();
    const data = {
      cancleEnabled: this.getSecReport[this.currentId].isCancelEnabled,
      cryptoCoinPairId: this.getSecReport[this.currentId].coinPairId,
      ipAddress: this.userIp.ip,
      isVisible: this.getSecReport[this.currentId].visibilityStatus,
      location: this.userIp.city + ',' + this.userIp.country_name,
      tradeEnabled: this.getSecReport[this.currentId].tradeStatus,
      baseCurrency: this.coin.baseCoin,
      executableCurrency: this.coin.executableCoin,
    };
    this.service.postMethod('fee/update-trading-pairs', data, 1)
      .subscribe((response) => {
        this.spinner.hide();
        this.getDailyClouserTime();
        this.getSecReport[this.currentId].enabled = true;
      }, (error) => {
        this.spinner.hide();
      });
  }

  changeCheckBox(id, status) {
    this.currentId = id;
    this.getSecReport[id][status] = !this.getSecReport[id][status];
  }
}
