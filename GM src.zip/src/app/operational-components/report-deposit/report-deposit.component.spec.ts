import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportDepositComponent } from './report-deposit.component';

describe('ReportDepositComponent', () => {
  let component: ReportDepositComponent;
  let fixture: ComponentFixture<ReportDepositComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReportDepositComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReportDepositComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
