import { ServiceService } from 'src/app/service/service.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { Router, ActivatedRoute } from '@angular/router';
import { IMyDpOptions } from 'mydatepicker';
import { AppComponent } from 'src/app/app.component';

declare var $: any;

@Component({
  selector: 'app-edit-offer',
  templateUrl: './edit-offer.component.html',
  styleUrls: ['./edit-offer.component.css']
})
export class EditOfferComponent implements OnInit, OnDestroy {

  editofferForm: FormGroup;
  apiResponse: any = { status: 1380 };
  showResult: any = false;
  fileData: any = {};
  fileName: any;
  public fromPickerOptions: IMyDpOptions = {
    disableUntil: { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() - 1 },
    dateFormat: 'dd/mm/yyyy',
  };
  englishShortCode: any;
  public toPickerOptions: IMyDpOptions = {
    disableUntil: { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() - 1 },
    dateFormat: 'dd/mm/yyyy',
  };
  fileUrl: any = null;
  invalidfileUrl: any = true;
  paramData: any;
  subscription: any;
  offerType: any;

  constructor(
    private service: ServiceService,
    private fb: FormBuilder,
    private spinner: NgxSpinnerService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private appC: AppComponent
  ) {
    this.subscription = this.service.authVerify.subscribe(val => {
      if (val == 'edit-offer') {
        this.editOffer();
        this.service.authVerify.next('false');
      }
    });
  }

  ngOnInit() {
    this.form();
    this.getParamData();
    window.scrollTo(0, 0);
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  form() {
    this.editofferForm = this.fb.group({
      offerType: ['', [Validators.required]],
      offerName: ['', [Validators.required, Validators.pattern(/^[a-zA-Z][a-zA-Z ]*$/), Validators.minLength(2), Validators.maxLength(255)]],
      offerStartDate: ['', [Validators.required]],
      offerEndDate: ['', [Validators.required]],
      thbperPoint: ['', [Validators.required, Validators.pattern(/^[0-9]*$/), Validators.minLength(1), Validators.maxLength(255)]],
      maxPoint: ['', [Validators.required, Validators.pattern(/^[0-9]*$/), Validators.minLength(1), Validators.maxLength(255)]],
      totalRedeem: [null, [Validators.pattern(/^[0-9]*$/), Validators.minLength(1), Validators.maxLength(255)]],
      numberOfPoints: [null, [Validators.pattern(/^[0-9]*$/), Validators.minLength(1), Validators.maxLength(255)]],
    });
  }
  resetFormValue() {
    this.editofferForm.patchValue({
      thbperPoint: null,
      maxPoint: null,
      totalRedeem: null,
      numberOfPoints: null,
    });
  }
  getParamData() {
    this.activatedRoute.params.subscribe(param => {
      this.paramData = param;
      this.getOfferdata();
    });
  }

  getOfferdata() {
    this.spinner.show();
    this.service.getMethod(`rewards/get-offer-details?offerId=${this.paramData.id}`, 1).subscribe((success: any) => {
      this.spinner.hide();
      if (success.status === 1377) {
        this.editofferForm.patchValue({
          offerType: success.data.offerType.typeOfOffer,
          offerName: success.data.offerName,
          offerStartDate: {
            date: {
              year: new Date(success.data.offerStartdate).getFullYear(),
              month: new Date(success.data.offerStartdate).getMonth() + 1,
              day: new Date(success.data.offerStartdate).getDate()
            },
            epoc: (new Date(success.data.offerStartdate).getTime() / 1000)
          },
          offerEndDate: {
            date: {
              year: new Date(success.data.offerEndDate).getFullYear(),
              month: new Date(success.data.offerEndDate).getMonth() + 1,
              day: new Date(success.data.offerEndDate).getDate()
            },
            epoc: (new Date(success.data.offerEndDate).getTime() / 1000)
          },
        });
        this.offerType = success.data.offerType.typeOfOffer;
        if(this.offerType === 'COUPON') {
          this.editofferForm.patchValue({
            totalRedeem: success.data.maxNumberOfCouponRedeemable,
            numberOfPoints: success.data.pointValue,
          })
        } else {
          this.editofferForm.patchValue({
            thbperPoint: success.data.thbPerPointValue,
            maxPoint: success.data.maxPoint,
          })
        }
        this.editofferForm.get('offerType').disable();
        this.fileUrl = success.data.offerImage;
        this.fileName = success.data.offerImage;
        if (success.data.offerImage) {
          this.invalidfileUrl = false;
          this.fileData.valid = true;
        } else {
          this.invalidfileUrl = true;
        }
      }
    }, error => {
      this.spinner.hide();
    });
  }

  fromDateChanged(event) {
    if (event.epoc) {
      this.toPickerOptions = {
        disableUntil: { year: new Date(event.epoc * 1000).getFullYear(), month: new Date(event.epoc * 1000).getMonth() + 1, day: new Date(event.epoc * 1000).getDate() - 1 }
      };
    } else {
      this.toPickerOptions = {
        disableUntil: { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() - 1 }
      };
    }
  }

  toDateChanged(event) {
    if (event.epoc) {
      this.fromPickerOptions = {
        disableSince: { year: new Date(event.epoc * 1000).getFullYear(), month: new Date(event.epoc * 1000).getMonth() + 1, day: new Date(event.epoc * 1000).getDate() + 1 }
      };
    } else {
      this.fromPickerOptions = {
        disableSince: { year: 0, month: 0, day: 0 },
      };
    }
  }

  getFile(event) {
    this.fileData = this.service.uploadImage(event);
    this.fileName = this.fileData.fileData.name;
    if (this.fileData.error === 'formatError') {
      this.fileData.error = 'Image accept only jpg, jpeg, png format.';
    } else {
      if (this.fileData.error === 'sizeError') {
        this.fileData.error = 'Image size should be less than 5Mb.';
      }
    }
    if (!this.fileData.valid) {
      return;
    }
    this.uploadImage();
  }

  uploadImage() {
    const formData = new FormData();
    formData.append('file', this.fileData.fileData);
    this.service.postMethod('account/uploadFile', formData, 2).subscribe(success => {
      if (success.fileName) {
        this.fileUrl = success.fileName;
        this.invalidfileUrl = false;
      } else {
        this.invalidfileUrl = true;
      }
    }, error => {
      this.invalidfileUrl = true;
    });
  }


  /** Function to verify google authentication */
  verifyGoogleAuth() {
    console.log('UPDATED ', this.editofferForm.invalid, this.invalidfileUrl);
    if (this.editofferForm.invalid) {
      return;
    }
    if (this.invalidfileUrl) {
      return;
    }
    this.appC.google = { one: '', two: '', three: '', four: '', five: '', six: '' };
    this.appC.response = { 'message': '' };
    this.service.googleAuthCalledFrom = 'edit-offer';
    $('#google-auth-modal').modal({ keyboard: false, backdrop: 'static' });

  }

  editOffer() {
    this.spinner.show();
    if (this.editofferForm.invalid) {
      this.spinner.hide();
      return;
    }
    if (this.invalidfileUrl) {
      this.spinner.hide();
      return;
    }
    const apireq = {
      languageName: this.service.encrypt('en'),
      offerType: this.offerType,
      offerName: this.editofferForm.value.offerName,
      offerStartdate: this.editofferForm.value.offerStartDate ? (this.editofferForm.value.offerStartDate.epoc ? (this.editofferForm.value.offerStartDate.epoc * 1000) : null) : null,
      offerEndDate: this.editofferForm.value.offerEndDate ? (this.editofferForm.value.offerEndDate.epoc ? ((this.editofferForm.value.offerEndDate.epoc * 1000) + 86399999) : null) : null,
      offerImage: this.fileUrl,
      thbPerPointValue: this.editofferForm.value.thbperPoint,
      maxPoint: this.editofferForm.value.maxPoint,
      maxNumberOfCouponRedeemable: this.editofferForm.value.totalRedeem,
      pointValue: this.editofferForm.value.numberOfPoints,
      offerrId: this.paramData.id
    };
    this.spinner.hide();
    this.service.postMethod('rewards/marketing/update-offer', apireq, 1).subscribe(success => {
      this.apiResponse = success;
      this.showResult = true;
    }, error => {
      this.showResult = true;
      if (error) {
        this.spinner.hide();
        if (error.error) {
          this.apiResponse.status = error.error.status;
          this.apiResponse.message = error.error.error;
        } else {
          this.apiResponse.status = 500;
          this.apiResponse.message = 'Something went wrong';
        }
      } else {
        this.apiResponse.status = 500;
        this.apiResponse.message = 'Something went wrong';
      }
    });
  }

}
