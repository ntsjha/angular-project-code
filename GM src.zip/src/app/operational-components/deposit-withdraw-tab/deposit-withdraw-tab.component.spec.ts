import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DepositWithdrawTabComponent } from './deposit-withdraw-tab.component';

describe('DepositWithdrawTabComponent', () => {
  let component: DepositWithdrawTabComponent;
  let fixture: ComponentFixture<DepositWithdrawTabComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DepositWithdrawTabComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DepositWithdrawTabComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
