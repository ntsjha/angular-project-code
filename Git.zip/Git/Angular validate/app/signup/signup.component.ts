import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators} from '@angular/forms';
import { Router } from '@angular/router';
import { Session } from 'protractor';
@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent  {
 
  key = 1;
  submitted = false;
  orders = [
    { id: 1, name: 'Cricket' },
    { id: 2, name: 'Football' },
     ];
     
  signup = new FormGroup({
    fullName: new FormControl('',[Validators.required,Validators.minLength(2),Validators.maxLength(20)] ),
    email: new FormControl('',[Validators.required,Validators.pattern(/^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/)]), 
    password: new FormControl('',[Validators.required,
     Validators.pattern("^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$")] ),
    number: new FormControl('',[Validators.required,Validators.pattern(/^\+?\d{2}[- ]?\d{3}[- ]?\d{5}$/)] ),
    address: new FormControl('',[Validators.required,Validators.minLength(4)] ),
    gender: new FormControl('',[Validators.required]),
    hobbies : new FormControl('',[])

  });
  
  onSubmit() {
    // TODO: Use EventEmitter with form value
    this.submitted = true;
     
    localStorage.setItem('token', JSON.stringify(this.signup.value));    
    sessionStorage.setItem('token', JSON.stringify(this.signup.value));
    console.log(this.signup.value);
   
  }
  
  

}
