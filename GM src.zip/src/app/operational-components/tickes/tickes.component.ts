import { Component, OnInit } from '@angular/core';
import { ServiceService } from 'src/app/service/service.service';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Subject } from 'rxjs';
import { AngularCsv } from 'angular7-csv/dist/Angular-csv';
import { CookieService } from 'ngx-cookie-service';

declare var $: any;

@Component({
    selector: 'app-tickes',
    templateUrl: './tickes.component.html',
    styleUrls: ['./tickes.component.css']
})
export class TickesComponent implements OnInit {
    ticketList: any = [];
    changeStatusForm: FormGroup;
    assignOperatorForm: FormGroup;
    disable: boolean = false;
    page: any = 1;
    searchTerm$ = new Subject<string>();
    status: any;
    statusFilter: any = '';
    search_key: any = '';
    pageSize: any = '10';
    total: number;
    search: any = '';
    user: any;
    ticketId: any;
    constructor(public service: ServiceService, public router: Router, private cookie: CookieService) {
        // to subscribe to search
        this.service.search(this.searchTerm$).subscribe(results => {
            console.log(results)
            this.search_key = results;
        });

        this.changeStatusForm = new FormGroup({
            'select_status': new FormControl('', [Validators.required]),
            'remark': new FormControl('', [Validators.required]),
        });

        this.assignOperatorForm = new FormGroup({
            'select_operator': new FormControl('', [Validators.required])
        });

        this.user = (this.cookie.get('userInfo')) ? JSON.parse(this.cookie.get('userInfo')) : this.service.initialUserInfo;


    }

    get select_status(): any {
        return this.changeStatusForm.get('select_status');
    }
    get remark(): any {
        return this.changeStatusForm.get('remark');
    }

    ngOnInit() {
        window.scrollTo(0, 0);
        this.getTicketList();
    }
    getTicketList() {
        this.ticketList = []
        const data = {
            page: this.service.encrypt(String(0)),
            pageSize: this.service.encrypt(String(10)),
            search: (this.search != '') ? this.service.encrypt(this.search.trim()) : null,
            status: (this.statusFilter != '') ? this.service.encrypt(this.statusFilter) : null,
        };
        this.service.postMethod('support/common-permit/search-ticket-list', data, 1).subscribe((res) => {
            if (res.status === 1210) {
                this.ticketList = res.data.list;
            }
        });
    }

    // to open modal
    openModal(type,id) {
        this.ticketId = id;
        if (type == 'change_status') {
            this.changeStatusForm.reset();
            $('#myticket1').modal({ backdrop: 'static', keyboard: false });

        } else if (type == 'assign_operator') {
            this.assignOperatorForm.reset();
            $('#myticket2').modal({ backdrop: 'static', keyboard: false });
        }
        this.disable = true;
    }

    assignOperator() {
    }

    changeStatus() {
        if (this.changeStatusForm.valid) {
            let data = {
                "remark": this.service.encrypt(this.changeStatusForm.value.remark),
                "status": this.service.encrypt(this.changeStatusForm.value.select_status),
            }
            this.service.postMethod('support/common-permit/change-support-ticket-status?ticketsId=' + encodeURIComponent(this.service.encrypt(this.ticketId)) + '&ipAddress=' + encodeURIComponent(this.service.encrypt(this.user.ip)) + '&location=' + encodeURIComponent(this.service.encrypt(this.user.city)), data, 1).subscribe((res) => {
                if(res.status) {
                    this.getTicketList();
                }
            },err => {

            })
        }
    }

    closeModal() {
        this.disable = false;
        this.resetForm();
    }

    resetForm() {
        this.assignOperatorForm.reset();
        this.changeStatusForm.reset();
    }

    viewDetail(id) {
        this.router.navigate(['ticket-details', id]);
    }

    filterBySearch() {
        if (this.search_key || this.status) {
            this.ticketList = [];
            let data = {
                "page": this.page != 0 ? this.search_key != '' ? this.service.encrypt(0) : this.service.encrypt(this.page - 1) : this.service.encrypt(0),
                "pageSize": this.service.encrypt(this.pageSize),
                "search": this.service.encrypt(this.search_key),
                "status": this.service.encrypt(this.status)
            };

            if (this.search_key) {
                data['search'] = this.service.encrypt(this.search_key);
            } else {
                data['search'] = null;
            }

            if (this.status) {
                data['status'] = this.service.encrypt(this.status);
            } else {
                data['status'] = null;
            }

            this.service.postMethod('support/search-ticket-list', data, 1).subscribe((res) => {
                if (res.data.list) {
                    this.ticketList = res.data.list;
                }
                this.status = '';
            });
        }
    }

    onStatusChange(val) {
        this.status = val;
        this.statusFilter = val;
        this.getTicketList();
    }

    resetFunc() {
        this.status = '';
        this.statusFilter = '';
        this.search_key = '';
        this.search = '';
        this.getTicketList();

    }

    exportList() {
        var options = {
            fieldSeparator: ',',
            quoteStrings: '"',
            decimalseparator: '.',
            showLabels: true,
            showTitle: true,
            title: 'Ticket List :',
            useBom: true,
            noDownload: false,
            headers: ['S.No.', 'Subject', 'Request Date', 'Customer Name', 'Customer Email', 'Status']
        };

        let data = [];

        this.ticketList.forEach((element, index) => {
            let obj = {
                's.no': index + 1,
                'subject': element.subject,
                'request_date': new Date(element.createdAt),
                'customer_name': element.customerName || '---',
                'customer_email': element.customerEmail || '---',
                'status': element.status,
            };
            data.push(obj);
        });
        new AngularCsv(data, 'Tickets', options);
    }

    managePagination(page) {
        this.page = page;
        this.total = 0;
        this.filterBySearch();
    }

}
