import { Component, OnInit } from '@angular/core';
import { ServerService } from '../../../server.service';
import { AppComponent } from '../../../app.component';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { HeaderComponent } from '../../header/header/header.component';
declare var $: any;
@Component({
    selector: 'app-profile',
    templateUrl: './profile.component.html',
    styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
    profiledata: any;
    qrCode = { Code1: "" }
    secretkey: any;
    qrcodeImg: any;
    userImage: any;
    email: any;
    name: any;
    sms: boolean;
    count: number;
    obj:any={'checkToggle':'','sms':''}
    DisabledAuth = { codeGoogle: ""}
    code = (/^[1-9]{1}[0-9]*$/);
    otp = { one: "", two: "", three: "", four: "", five: "", six: ""};
    phoneNo: any;
    twoFA: string;

    constructor(private server: ServerService, public appC: AppComponent, private spinnerService: Ng4LoadingSpinnerService, private router: Router, private header: HeaderComponent) { }

    ngOnInit() {
        window.scrollTo(0,0);
        this.getprofile();
        this.header.getprofile();
    }

    // ****** google auth  ******

    changeToggle(val) {
        switch(val) {
            case 1 : 
                if (this.obj.checkToggle == true && this.twoFA == 'NONE') {
                    this.spinnerService.show();
                    this.server.getApi('account/google-auth').subscribe((res) => {
                        this.spinnerService.hide();
                        if (res.status == 200) {
                            this.qrcodeImg = res.data.qrCode
                            this.secretkey = res.data.secretKey
                            $('#googleAuthModal').modal({ backdrop: 'static', keyboard: false }); 
                        } else if(res.data.twoFaType == 'GOOGLE') {
                            this.obj.checkToggle = true;
                        } else {
                            this.obj.checkToggle = false;
                        }
                    }, (err) => {
                        this.obj.checkToggle = false;
                        this.spinnerService.hide();
                        this.appC.showErrToast(err.error.message)
                    })
                } else if(this.obj.checkToggle == true && this.twoFA == 'SMS') {
                    setTimeout(() => {
                        this.appC.showInfoToast('Please first disable SMS authentication and then enable Google authentication.');
                        this.obj.checkToggle = false;
                    }, 500);

                } else if(this.obj.checkToggle == false) {
                    $('#disableAuth').modal({ backdrop: 'static', keyboard: false });
                }
                break;
            case 2 : 
                if (this.obj.sms == true && this.twoFA == 'NONE') {
                    this.requestSmscode();
                } else if(this.obj.sms == true && this.twoFA == 'GOOGLE') {
                    setTimeout(() => {
                        this.appC.showInfoToast('Please first disable Google authentication and then enable SMS authentication.');
                        this.obj.sms = false;
                    }, 500);
                } else if(this.obj.sms == false) {
                    this.requestSmscode();
                }
                break;
                
        }
    }

    // changeTogglesms() {
    //     this.count = 1;
    //     Observable.interval(1000).takeWhile(() => this.count < 2).subscribe(i => {
    //         this.obj.sms = false
    //         this.count++ ;
    //     })
    // }

    requestSmscode() {
        this.spinnerService.show();
        this.server.getApi('account/send-sms-code').subscribe(succ =>{
            if(succ.status == 200) {
                this.spinnerService.hide();
                this.otp = { one: "", two: "", three: "", four: "", five: "", six: ""};
                $('#faOTPModal').modal({ backdrop: 'static', keyboard: false }); 
            } else {
                this.obj.sms = false
                this.spinnerService.hide();
                this.appC.showErrToast(succ.message);
            }
        },err =>{
            this.obj.sms = false
            this.spinnerService.hide();
            this.appC.showErrToast(err.error.error);
        })
    }

    requestDisabledSmscode() {
        this.spinnerService.show();
        this.server.getApi('account/send-sms-code').subscribe(succ =>{
            if(succ.status == 200) {
                this.spinnerService.hide();
                this.otp = { one: "", two: "", three: "", four: "", five: "", six: ""};
                $('#faOTPModal').modal({ backdrop: 'static', keyboard: false }); 
            } else {
                this.obj.sms = false
                this.spinnerService.hide();
                this.appC.showErrToast(succ.message);
            }
        },err =>{
            this.obj.sms = false
            this.spinnerService.hide();
            this.appC.showErrToast(err.error.error);
        })
    }

    verifySmsCode() {
        if(this.otp.one == "" || this.otp.two == "" || this.otp.three == "" || this.otp.four == ""|| this.otp.five == ""|| this.otp.six == ""){
            this.appC.showErrToast("Please Enter Code");
            return; 
        } else {
            let data = {
                "code": this.otp.one+this.otp.two+this.otp.three+this.otp.four+this.otp.five+this.otp.six,
            }
            this.spinnerService.show();
            this.server.postApi('account/verify-sms-code', data).subscribe((res) => {
                this.spinnerService.hide();
                if (res.status == 200) {
                    this.appC.showSuccToast("SMS Authentication Enabled.");
                    $('#faOTPModal').modal('hide');
                }
                else {
                    this.otp = { one: "", two: "", three: "", four: "", five: "", six: ""};
                    this.appC.showErrToast(res.message);
                }
    
            }, (err) => {
                this.otp = { one: "", two: "", three: "", four: "", five: "", six: ""};
                this.spinnerService.hide();
                this.appC.showErrToast("Something went Wrong")
            })
        }
    }

    /**Resend OTP */
    otpResend() {
        this.spinnerService.show();
        this.server.getApi('account/send-sms-code').subscribe(succ =>{
            if(succ.status == 200) {
                this.spinnerService.hide();
                this.appC.showSuccToast(succ.message);
            } else {
                this.spinnerService.hide();
                this.appC.showErrToast(succ.message);
            }
        },err =>{
            this.spinnerService.hide();
            this.appC.showErrToast(err.error.error);
        })
    }

    // verifiy google auth ******** //

    qrVerify() {
        if(this.qrCode.Code1 == ""){
            this.appC.showErrToast("Please Enter Code");
            return; 
        } 
        let data = {
            "code": this.qrCode.Code1,
            "secretKey": this.secretkey
        }
        this.spinnerService.show();
        this.server.postApi('account/verify-google-code', data).subscribe((res) => {
            this.spinnerService.hide();
            if (res.status == 200) {
                this.appC.showSuccToast("Google Authentication Enabled.");
                $('#googleAuthModal').modal('hide');
            }
            else {
                this.qrCode.Code1 = ""
                this.appC.showErrToast(res.message);
            }

        }, (err) => {
            this.qrCode.Code1 = ""
            this.spinnerService.hide();
            this.appC.showErrToast("Something went Wrong")
        })
    }



    getprofile() {
        this.spinnerService.show();
        this.server.getApi('account/my-account').subscribe((res) => {
            this.spinnerService.hide();
            if (res.status == 200) {
                this.name = res.data.firstName;
                this.email = res.data.email;
                this.phoneNo = res.data.phoneNo;
                this.userImage = res.data.imageUrl
                this.profiledata = res.data
                if(res.data.twoFaType == 'GOOGLE'){
                    this.twoFA = 'GOOGLE';
                    this.obj.checkToggle = true;
                    this.obj.sms = false;
                }
                else if(res.data.twoFaType == 'NONE'){
                    this.twoFA = 'NONE'
                    this.obj.checkToggle = false;
                    this.obj.sms = false;
                }
                else if(res.data.twoFaType == 'SMS'){
                    this.twoFA = 'SMS'
                    this.obj.checkToggle = false;
                    this.obj.sms = true;
                }
            }
            else {
                this.spinnerService.hide();
                this.appC.showErrToast(res.message);
            }

        }, (err) => {
            this.spinnerService.hide();
            this.appC.showErrToast('Something went wrong')
        })
        
    }

    /**navigate to  edit profile  page */
    editProfile() {
        this.router.navigateByUrl('edit')
    }

    /**navigate to  Kyc page */
    kycUpdate() {
        this.router.navigateByUrl('kyc')
    }

    /**navigate to  change password page */
    changePassword() {
        this.router.navigateByUrl('changepassword')
    }

    closeModal() {
        this.getprofile();
        $('#faOTPModal').modal('hide');
        $('#googleAuthModal').modal('hide');
       
    }
    disabCross() {
        this.getprofile();
        this.DisabledAuth.codeGoogle = ""
        $('#disableAuth').modal('hide');
    }

    disabledTwofaAuth(val) {
        switch(val) {
            case 'google' :
                if(this.DisabledAuth.codeGoogle == ""){
                    this.appC.showErrToast("Please Enter Code");
                    return; 
                } 
                let data = {
                    "code": this.DisabledAuth.codeGoogle,
                }
                this.spinnerService.show();
                this.server.postApi('account/twoFa-disable', data).subscribe((res) => {
                    this.spinnerService.hide();
                    if (res.status == 200) {
                        this.appC.showSuccToast("Google Authentication Disabled");
                        $('#disableAuth').modal('hide');
                        if(this.obj.sms == true) {
                            this.requestSmscode();
                        } else {
                            this.getprofile();
                        }
                        
                    } else {
                        this.DisabledAuth.codeGoogle = "";
                        this.appC.showErrToast(res.message);
                    }
        
                }, (err) => {
                    this.spinnerService.hide();
                    this.DisabledAuth.codeGoogle = "";
                    this.appC.showErrToast("Something went Wrong")
                });
                break;
            case 'sms' :
                if(this.otp.one == "" || this.otp.two == "" || this.otp.three == "" || this.otp.four == "" || this.otp.five == "" || this.otp.six == ""){
                    this.appC.showErrToast("Please Enter Code");
                    return; 
                } 
                let smsData = {
                    "code": this.otp.one+this.otp.two+this.otp.three+this.otp.four+this.otp.five+this.otp.six,
                
                }
                this.spinnerService.show();
                this.server.postApi('account/disable-sms-auth',smsData).subscribe((res) => {
                    this.spinnerService.hide();
                    if (res.status == 200) {
                        this.appC.showSuccToast("SMS Authentication Disabled");
                        $('#faOTPModal').modal('hide');
                        this.getprofile();
                    } else {
                        this.otp = { one: "", two: "", three: "", four: "", five: "", six: ""};
                        this.appC.showErrToast(res.message);
                    }
        
                }, (err) => {
                    this.spinnerService.hide();
                    this.otp = { one: "", two: "", three: "", four: "", five: "", six: ""};
                    this.appC.showErrToast("Something went Wrong")
                });
                if(this.obj.checkToggle == true && this.obj.sms == true) {
                    this.server.getApi('account/google-auth').subscribe((res) => {
                        this.spinnerService.hide();
                        if (res.status == 200) {
                            this.qrcodeImg = res.data.qrCode
                            this.secretkey = res.data.secretKey
                            $('#googleAuthModal').modal({ backdrop: 'static', keyboard: false }); 
                        } else if(res.data.twoFaType == 'GOOGLE') {
                            this.obj.checkToggle = true;
                        } else {
                            this.obj.checkToggle = false;
                        }
                    }, (err) => {
                        this.obj.checkToggle = false;
                        this.spinnerService.hide();
                        this.appC.showErrToast(err.error.message)
                    })
                }
                break;
        }
    }

    copyToClipboard(data : string) {
        this.appC.showInfoToast("Text has been copied to clipboard.");
        let selBox = document.createElement('textarea');
        selBox.style.position = 'fixed';
        selBox.style.left = '0';
        selBox.style.top = '0';
        selBox.style.opacity = '0';
        selBox.value = data;
        document.body.appendChild(selBox);
        selBox.focus();
        selBox.select();
        document.execCommand('copy');
        document.body.removeChild(selBox);
    }

    /** Auto focus functionality */
    onKey(value, type) {
        if (type == 1) {
            if (value != "") {
                $('#otp2').focus();
            }
        } else if (type == 2) {
            if (value != "") {
                $('#otp3').focus();
            }
        } else if (type == 3) {
            if (value != "") {
                $('#otp4').focus();
            }
        } else if (type == 4) {
            if (value != "") {
                $('#otp5').focus();
            }
        } else if (type == 5) {
            if (value != "") {
                $('#otp6').focus();
            }
        } else if (type == 6) {
            if (value.keyCode == 13) {
                this.verifySmsCode();
            }
        } 
    }

}
