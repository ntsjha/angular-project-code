import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { OtcdeskComponent } from './otcdesk/otcdesk.component';

@NgModule({
    imports: [
        CommonModule
    ],
    declarations: [OtcdeskComponent]
})
export class OtcdeskModule { }
