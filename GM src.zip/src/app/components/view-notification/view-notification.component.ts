import { Component, OnInit } from '@angular/core';
import { ServiceService } from 'src/app/service/service.service';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { CookieService } from 'ngx-cookie-service';
import { AppComponent } from 'src/app/app.component';

@Component({
  selector: 'app-view-notification',
  templateUrl: './view-notification.component.html',
  styleUrls: ['./view-notification.component.css']
})
export class ViewNotificationComponent implements OnInit {
  getNotification: any = [];

  constructor(
    private router: Router, 
    private service: ServiceService, 
    private spinner: NgxSpinnerService, 
    private cookie: CookieService, 
    private appC: AppComponent
    ) { }

  ngOnInit() {
    this. getNotificationData();
  }

  getNotificationData() {

    this.spinner.show();
    this.service.getMethod('notification-service/common-permit/get-notification-data', 1).subscribe((response: any) => {
        this.spinner.hide();
        if (response.status === 1618) {
            this.getNotification = response.data;
            this.getNotification.reverse();
        }
    }, (error) => {
        this.spinner.hide();
    });
    this.spinner.hide();

}

}
