import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';

import { AppComponent } from './app.component';
import { HeaderModule } from './modules/header/header.module';
import { HomeModule } from './modules/home/home.module';
import { LoginModule } from './modules/login/login.module';
import { SignupModule } from './modules/signup/signup.module';
import { ForgotpasswordModule } from './modules/forgotpassword/forgotpassword.module';
import { ToastrModule } from 'ngx-toastr';
import { Ng4LoadingSpinnerModule } from 'ng4-loading-spinner';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ServerService, httpModifierInterceptor } from './server.service';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { EmailverifyModule } from './modules/emailverify/emailverify.module';
import { ResetpasswordModule } from './modules/resetpassword/resetpassword.module';
import { ProfileModule } from './modules/profile/profile.module';
import { EditprofileModule } from './modules/editprofile/editprofile.module';
import { ChangepasswordModule } from './modules/changepassword/changepassword.module';
import { KycModule } from './modules/kyc/kyc.module';
import { QRCodeModule } from 'angularx-qrcode';
import { TermandconditionsModule } from './modules/termandconditions/termandconditions.module';
import { WalletModule } from './modules/wallet/wallet.module';
import { DeposithistoryModule } from './modules/deposithistory/deposithistory.module';
import { WithdrawhistoryModule } from './modules/withdrawhistory/withdrawhistory.module';
import { AboutusModule } from './modules/aboutus/aboutus.module';
import { NewsModule } from './modules/news/news.module';
import { ExchangeModule } from './modules/exchange/exchange.module';
import { PrivacypolicyModule } from './modules/privacypolicy/privacypolicy.module';
import { AffiliateModule } from './modules/affiliate/affiliate.module';
import { AuthGuard } from './auth.guard';
import { ExheaderModule } from './modules/exheader/exheader.module';
import {NgxPaginationModule} from 'ngx-pagination';
import * as $ from 'jquery';
import { NewsdetailModule } from './modules/newsdetail/newsdetail.module';
import { GooglePlaceModule } from "ngx-google-places-autocomplete";





@NgModule({
  declarations: [
    AppComponent,

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HeaderModule,
    HomeModule,
    LoginModule,
    SignupModule,
    ForgotpasswordModule,
    ToastrModule.forRoot(), // ToastrModule added
    Ng4LoadingSpinnerModule,
    BrowserAnimationsModule, // required animations module
    HttpClientModule,
    EmailverifyModule,
    ResetpasswordModule,
    ProfileModule,
    EditprofileModule,
    ChangepasswordModule,
    KycModule,
    QRCodeModule,
    TermandconditionsModule,
    WalletModule,
    DeposithistoryModule,
    WithdrawhistoryModule,
    AboutusModule,
    NewsModule,
    ExchangeModule,
    PrivacypolicyModule,
    AffiliateModule,
    ExheaderModule,
    NgxPaginationModule,
    NewsdetailModule,
    GooglePlaceModule,
   

  ],
  providers: [
    ServerService,
    { 
      provide: HTTP_INTERCEPTORS,
      useClass: httpModifierInterceptor,
      multi: true 
      }, AuthGuard
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
