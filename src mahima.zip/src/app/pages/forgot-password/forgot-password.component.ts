import { MainServiceService } from './../../main-service.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { Router } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';

@Component({
    selector: 'app-forgot-password',
    templateUrl: './forgot-password.component.html',
    styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {

    forgotPasswordForm: FormGroup;
    constructor(
        public service: MainServiceService,
        private spinnerService: Ng4LoadingSpinnerService,
        private router: Router,
        public cookie: CookieService,
    ) {}

    ngOnInit() {
        this.formFunc();
    }

    formFunc() {
        this.forgotPasswordForm = new FormGroup({
            email: new FormControl('', [Validators.required, Validators.pattern(/^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/i)])
        });
    }

    forgotPassword() {
        if (this.forgotPasswordForm.invalid) {
          return;
        } else {
            this.spinnerService.show();
            let apireq = {
                userId: this.forgotPasswordForm.value.email
            };
            this.service.post('user/forgotPassword', apireq, 0).subscribe(success => {
                if (success.responseCode == 200) {
                    this.spinnerService.hide();
                    this.service.showSuccess(success.responseMessage);
                    this.cookie.set('id',success.result._id);
                    this.router.navigate(['resetPassword']);
                } else {
                    this.spinnerService.hide();
                    this.service.showError(success.responseMessage);
                }
            }, error => {
                this.spinnerService.hide();
                this.service.showError('Something went wrong');
            });
        }
    }

}
