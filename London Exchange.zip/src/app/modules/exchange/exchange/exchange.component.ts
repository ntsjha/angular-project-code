import { Component, OnInit } from '@angular/core';
import { HeaderComponent } from '../../header/header/header.component';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ServerService } from '../../../service/server.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { AppComponent } from '../../../app.component';
import { ExHeaderComponent } from '../../ex-header/ex-header/ex-header.component';

declare var $: any;
declare const TradingView: any;
declare const Datafeeds: any;

var copyBuyOrderArr = [];
var copySellOrderArr = [];
var copyTradeHisArr = [];

@Component({
    selector: 'app-exchange',
    templateUrl: './exchange.component.html',
    styleUrls: ['./exchange.component.css'],
})
  
export class ExchangeComponent implements OnInit {  
    quickTab: any;
    show: string;
    flag: any;
    loginStatus: string;
    buyForm: FormGroup;
    buyForm1: FormGroup;
    sellForm: FormGroup;
    sellForm1: FormGroup;
    currTradeTab = "market";
    currTrade = "order";
    currTab = "buy";
    coinList = [] ;
    buyOrderList = [] ;
    sellOrderList = [];
    tradeHistoryList = [];
    coinPairList = [];
    openOrderList = [];
    orderHistoryList = [];
    transactionTradeHistoryList = [];
    currCoin: any = '1';
    currCoinpair: any = '2';
    value: boolean;
    marketValue: any = 500;
    marketbuytotal: number;
    limitbuytotal: number;
    marketselltotal: number;
    limitselltotal: number;
    coin: any = {selected:''}
    myValue: any = { pair: "BTC" };
    currSelectedCoinObj = {coin:"",coinID:"",coinType:""};
    currSelectedPairObj = {coin:"",coinID:""};    
    test: any;
    baseWalletBalance: any;
    exeWalletBalance: any;
    maxPrice:any;
    currentPrice: any;
    minPrice:any;
    volume:any;
    average:any;
    marketEstimateAmount: any;
    marketEstimatePrice: any;
    marketSellPrice: number;
    marketBuyTotal: number;
    marketBuyPrice: number;
    marketSellTotal: number;
    mySymbol= 'BTC/ETH';    
    lastPrice: any;
    marketPriceLbl = "";
    buttonDisableBuyLimit: any;
    buttonDisableBuyMarket: boolean;
    buttonDisableSellMarket: boolean;
    buttonDisableSellLimit: boolean;
    marketBuyButton: boolean;
    marketSellButton: boolean;
    limitBuyButton: boolean;
    limitSellButton: boolean;
    currGBPPrice = "";
    hitbtcIntervalID: any;
    hitBTCDataStatus = true;

    constructor(public header: ExHeaderComponent, private router: Router, public server: ServerService, private appC: AppComponent, private spinnerService: Ng4LoadingSpinnerService ) {
        this.header.fireToChild().subscribe(message => {
            this.quickTab = message.text;
            if (this.quickTab == "Dropdown_Value_selected")
                this.myValue.pair = localStorage.getItem("value");
        });
        this.server.fireToChild().subscribe(msg => {
            switch(msg.text) {
                case "liqConnected":
                    this.manageLiquiditySocket(2);
                    this.manageLiquiditySocket(1);
                    break;
            }
        });
        var self = this;
     
        this.server.wsExchange.addEventListener('message', function (event) {
            let data = JSON.parse(event.data); 
            // console.log("socket data -> ",data);
            /*if(data.payload.buyOrders.length) {
                let buyOrderArr = data.payload.buyOrders.filter(obj => obj.executableCurrencyCoinId == self.currSelectedPairObj.coinID && obj.baseCurrencyCoinId == self.currSelectedCoinObj.coinID);
                if(buyOrderArr.length) {
                    self.buyOrderList = [];
                    buyOrderArr.forEach((obj) => {
                        if(obj.executableCurrencyCoinId == self.currSelectedPairObj.coinID && obj.baseCurrencyCoinId == self.currSelectedCoinObj.coinID) {
                            //console.log("data found -> ",obj);
                            var index = self.buyOrderList.findIndex((x) => x.price == obj.price);
                            if(index != -1) {
                                self.buyOrderList[index].amount = (Number(self.buyOrderList[index].amount) + Number(obj.amount)).toFixed(8);
                                self.buyOrderList[index].total = (self.buyOrderList[index].price * self.buyOrderList[index].amount).toFixed(8);
                            } else {
                                self.buyOrderList.push({
                                    price: obj.price.toFixed(8),
                                    amount: obj.amount.toFixed(8),
                                    total: (obj.price * obj.amount).toFixed(8)
                                });
                            }
                        }
                    });
                }                
            } else {
                self.buyOrderList = [];
            }
            if(data.payload.sellOrders.length) {
                let sellOrderArr = data.payload.sellOrders.filter(obj => obj.executableCurrencyCoinId == self.currSelectedPairObj.coinID && obj.baseCurrencyCoinId == self.currSelectedCoinObj.coinID);
                if(sellOrderArr.length) {
                    self.sellOrderList = [];
                    sellOrderArr.forEach((obj) => {
                        if(obj.executableCurrencyCoinId == self.currSelectedPairObj.coinID && obj.baseCurrencyCoinId == self.currSelectedCoinObj.coinID) {
                            var index = self.sellOrderList.findIndex((x) => x.price == obj.price);
                            if(index != -1) {
                                self.sellOrderList[index].amount = (Number(self.sellOrderList[index].amount) + Number(obj.amount)).toFixed(8);
                                self.sellOrderList[index].total = (self.sellOrderList[index].price * self.sellOrderList[index].amount).toFixed(8);
                            } else { 
                                self.sellOrderList.push({
                                    price: obj.price.toFixed(8),
                                    amount: obj.amount.toFixed(8),
                                    total: (obj.price * obj.amount).toFixed(8)
                                });
                            }
                        }
                    });
                }                
            } else {
                self.sellOrderList = [];
            }
            if(data.payload.tradeHistory.length) {
                let tradeArr = data.payload.tradeHistory.filter((x) => x.executableCurrencyCoinId == self.currSelectedPairObj.coinID && x.baseCurrencyCoinId == self.currSelectedCoinObj.coinID);
                if(tradeArr.length) {
                    self.tradeHistoryList = [];
                    tradeArr.forEach((obj) => {
                        self.tradeHistoryList.push({
                            orderType: obj.orderType,
                            price: obj.price.toFixed(8),
                            amount: obj.amount.toFixed(8),
                            orderExecutionTime: obj.orderExecutionTime
                        });
                    });
                }                
            } else {
                self.tradeHistoryList = [];
            }*/
            if(data.payload.userSpecific) {
                if(localStorage.getItem("token")) {
                    self.getHeaderList();
                    self.getpaircoinListAfterExecution();
                    if(data.payload.userIdList.length) {
                        let ind = data.payload.userIdList.findIndex((x) => x == localStorage.getItem("userId"));
                        if(ind != -1) {
                            self.getBaseCoinBalance();
                            self.getExecutiveCoinBalance();
                            self.getOpenorder();
                            self.getOrderhistory();
                        }
                    }
                }
            }
            /*if(data.payload.marketData.length) {
                data.payload.marketData.forEach((obj) => {
                    if(obj.baseCoin && obj.executableCoin) {
                        if(obj.baseCoin.coinId == self.currSelectedCoinObj.coinID && obj.executableCoin.coinId == self.currSelectedPairObj.coinID) {
                            self.maxPrice = obj.maxValue;
                            self.currentPrice = obj.currentValue;
                            self.minPrice = obj.minValue;
                            self.volume = obj.volume;
                            //self.average = ;
                        }
                    }                    
                });
            }*/
        });
        this.server.liqWSObj.addEventListener('message', function (event) {
            let data = JSON.parse(event.data);            
            if(data.params) {
                self.hitBTCDataStatus = true;
                let multiplier = 1;
                self.currSelectedCoinObj.coin == "GBP" ? multiplier = Number(self.currGBPPrice) : multiplier = 1;
                switch(data.method) {
                    case "ticker":
                        self.currentPrice = data.params.last*multiplier;
                        self.maxPrice = data.params.high*multiplier;
                        self.minPrice = data.params.low*multiplier;
                        self.average = ((Number(data.params.high) + Number(data.params.high)) / 2)*multiplier;
                        self.volume = data.params.volume;
        
                        /** Code to set coin pair list data as per selected pair */            
                        let currPairArr = self.coinPairList.filter(obj => obj.coin_short_name == self.currSelectedPairObj.coin);
                        if(currPairArr.length) {
                            currPairArr[0].last_price = self.currentPrice;
                            currPairArr[0].volume = self.volume;
                            currPairArr[0].average = self.average;
                        }
                        break;
                    case "snapshotOrderbook":
                    case "updateOrderbook":
                        // console.log("liq socket data -> "+JSON.stringify(data));
                        if(data.params.bid.length) {
                            data.params.bid.forEach((obj) => {
                                var ind = copyBuyOrderArr.findIndex((x) => x.price == obj.price*multiplier);
                                if(ind != -1) {
                                    copyBuyOrderArr[ind].amount = (Number(copyBuyOrderArr[ind].amount) + Number(obj.size)).toFixed(4);
                                    copyBuyOrderArr[ind].total = (copyBuyOrderArr[ind].price * copyBuyOrderArr[ind].amount).toFixed(4);
                                } else {
                                    copyBuyOrderArr.push({
                                        price: Number(obj.price*multiplier).toFixed(4),
                                        amount: Number(obj.size).toFixed(4),
                                        total: ((obj.price*multiplier)*obj.size).toFixed(4)
                                    });
                                }
                            });  
                            copyBuyOrderArr = copyBuyOrderArr.slice(0,self.server.buyOrderLimit*2);
                            self.buyOrderList = self.functionToManageBuyOrder(copyBuyOrderArr); 
                        }
                        if(data.params.ask.length) {
                            data.params.ask.forEach((obj) => {
                                var ind = copySellOrderArr.findIndex((x) => x.price == obj.price*multiplier);
                                if(ind != -1) {
                                    copySellOrderArr[ind].amount = (Number(copySellOrderArr[ind].amount) + Number(obj.size)).toFixed(4);
                                    copySellOrderArr[ind].total = (copySellOrderArr[ind].price * copySellOrderArr[ind].amount).toFixed(4);
                                } else {
                                    copySellOrderArr.push({
                                        price: Number(obj.price*multiplier).toFixed(4),
                                        amount: Number(obj.size).toFixed(4),
                                        total: ((obj.price*multiplier)*obj.size).toFixed(4)
                                    });
                                }
                            });  
                            copySellOrderArr = copySellOrderArr.slice(0,self.server.sellOrderLimit*2);
                            self.sellOrderList = self.functionToManageSellOrder(copySellOrderArr); 
                        }
                        break;
                    case "snapshotTrades":
                    case "updateTrades":
                        if(data.params.data.length) {
                            data.params.data.forEach((obj) => {
                                copyTradeHisArr.push({
                                    price: Number(obj.price*multiplier).toFixed(4),
                                    amount: Number(obj.quantity).toFixed(4),
                                    // total: Number(obj.price*obj.quantity).toFixed(8),
                                    orderExecutionTime: new Date(obj.timestamp).getTime(),
                                    orderType: obj.side.toUpperCase()
                                });
                            });     
                            copyTradeHisArr = copyTradeHisArr.slice(0,self.server.tradeHisOrderLimit*2);
                            self.tradeHistoryList = self.functionToManageTradeHisOrder(copyTradeHisArr);
                        }
                        break;
                }
            }   
            if(data.error) {
                if(data.error.code == 2001) {
                    self.hitBTCDataStatus = false;
                    copyBuyOrderArr = [];
                    copySellOrderArr = [];
                    copyTradeHisArr = [];
                    self.tradeHistoryList = [];
                    self.sellOrderList = [];
                    self.buyOrderList = [];
                    /** Code to set coin pair list data as per selected pair */
                    let currPairArr = self.coinPairList.filter(obj => obj.coin_short_name == self.currSelectedPairObj.coin);
                    if(currPairArr.length) {
                        currPairArr[0].last_price = 0.000000;
                        currPairArr[0].volume = 0.000000;
                        currPairArr[0].average = 0.000000;
                    }
                }
            }                     
        });
    }
      
    ngOnInit() {
        this.startLoader();
        this.getCoinlist();
        this.getGBPPriceFromAPI();
        this.myValue.pair = 'BTC';
        this.currTrade = "buy";
        this.currTradeTab = "market";
        this.marketPriceLbl = "Market Price";
        this.check();
        window.scrollTo(0, 0);
        this.show = "true"
        this.checkInputsSell();
        this.checkInputsSell1();
        this.checkInputsBuy1();
        this.checkInputsBuy();
    }

    startLoader() {
        $(".loader_fade").show();
        setTimeout(() => {
            $(".loader_fade").hide();
        },5000);
    }

    ngOnDestroy() {
        this.manageLiquiditySocket(2);
        this.stopInterval();
    }

    /** Function to get price of GBP from api */
    getGBPPriceFromAPI() {
        this.server.getPriceOfGBP().subscribe((succ) => {
            this.currGBPPrice = succ.GBP_USD;
        }, (err) => {});
    }

    /** Function to manage buy border data */
    functionToManageBuyOrder(arr) {
        arr = arr.filter(obj => Number(obj.amount) != 0);
        arr.sort((a,b) => {
            return a.price - b.price;
        });  
        arr = arr.slice(0, this.server.buyOrderLimit);
        return arr;
    }

    /** Function to manage sell border data */
    functionToManageSellOrder(arr) {
        arr = arr.filter(obj => Number(obj.amount) != 0);
        arr.sort((a,b) => {
            return b.price - a.price;
        });  
        arr = arr.slice(0, this.server.sellOrderLimit);
        return arr;
    }

    /** Function to manage trade history data */
    functionToManageTradeHisOrder(arr) {
        arr.sort((a,b) => {
            return b.orderExecutionTime - a.orderExecutionTime;
        });  
        arr = arr.slice(0, this.server.tradeHisOrderLimit);
        return arr;
    }

    showPopover() {
        $('[data-toggle="tooltip"]').tooltip();
    }

    checkInputsBuy() {
        this.buyForm = new FormGroup({
            buyprice: new FormControl(),
            buyquantity: new FormControl('', [Validators.required, Validators.pattern(/^(\s*|[0-9])+(\.[0-9]{1,8})?$/)]),
        });
    }

    check() {
        if (localStorage.getItem("token")) {
            this.flag = false;
        } else {
            this.flag = true;
        }
    }

    //Function to get total of market buy form 
    changeBuyQuantityMarket(val) {
        this.marketbuytotal = this.marketValue * val
    }

    //Function to get total of limit buy form 
    changeBuyQuantityLimit() {
        if(this.buyForm1.value.buyprice1 == 0 || this.buyForm1.value.buyquantity1 == 0) {
            this.buttonDisableBuyLimit = true;
        } else if(this.buyForm1.value.buyprice1 != 0 && this.buyForm1.value.buyquantity1 != 0) {
            this.buttonDisableBuyLimit = false;
        }
        // alert(this.buyForm1.value.buyprice1)
        this.limitbuytotal = this.buyForm1.value.buyprice1 * this.buyForm1.value.buyquantity1;
    }

    checkBuyQuantityMarket() {
        if(this.buyForm.value.buyquantity == 0) {
            this.buttonDisableBuyMarket = true;
        } else {
            this.buttonDisableBuyMarket = false;
        }
    } 
    
    checkSellQuantityMarket() {
        // sellquantity
        if(this.sellForm.value.sellquantity == 0) {
            this.buttonDisableSellMarket = true;
        } else {
            this.buttonDisableSellMarket = false;
        }
    }

    //Function to get total of market sell form 
    changeSellQuantityMarket(val) {
        this.marketselltotal = this.marketValue * val
    }

    //Function to get total of limit sell form 
    changeSellQuantityLimit() {
        if(this.sellForm1.value.sellprice1 == 0 || this.sellForm1.value.sellquantity1 == 0) {
            this.buttonDisableSellLimit = true;
        } else if(this.sellForm1.value.sellprice1 != 0 && this.sellForm1.value.sellquantity1 != 0) {
            this.buttonDisableSellLimit = false;
        }
        this.limitselltotal = this.sellForm1.value.sellprice1 * this.sellForm1.value.sellquantity1
    }

    active(val) {
        if (val == 1) {
          //console.log("buy")
          //this.buyOrder();
          this.currTrade = "buy";
          
        } else {
          this.value = false;
          //console.log("sell")
          //this.sellOrder() ; 
          this.currTrade = "sell";
        }
    }

    dropDown() {
        //localStorage.setItem("value", this.myValue.pair)
    }

    myActive(value) {
        if (value == 1) { 
            this.buyOrderList = [];
            this.currTab = "sell";
        } else {
            this.sellOrderList = [];
            this.currTab = "buy";
        }
    }

    checkInputsBuy1() {
        this.buyForm1 = new FormGroup({
            buyprice1: new FormControl('', [Validators.required, Validators.pattern(/^(\s*|[0-9])+(\.[0-9]{1,8})?$/)]),
            buyquantity1: new FormControl('', [Validators.required, Validators.pattern(/^(\s*|[0-9])+(\.[0-9]{1,8})?$/)]),
        });
    }

    checkInputsSell() {
        this.sellForm = new FormGroup({
            sellprice: new FormControl(),
            sellquantity: new FormControl('', [Validators.required, Validators.pattern(/^(\s*|[0-9])+(\.[0-9]{1,8})?$/)]),
        });
    }

    checkInputsSell1() {
        this.sellForm1 = new FormGroup({
            sellprice1: new FormControl('', [Validators.required, Validators.pattern(/^(\s*|[0-9])+(\.[0-9]{1,8})?$/)]),
            sellquantity1: new FormControl('', [Validators.required, Validators.pattern(/^(\s*|[0-9])+(\.[0-9]{1,8})?$/)]),
        }); 
    }

    market() {
        this.currTradeTab = "market";
        this.show = "true"
    }

    openLogin() {
        this.router.navigate(['header/login']);
    }

    limit() {
        this.currTradeTab = "limit";
        this.show = "false"
    }

    get buyprice(): any {
        return this.buyForm.get('buyprice');
    }

    get buyprice1(): any {
        return this.buyForm1.get('buyprice1');
    }

    get buyquantity(): any {
        return this.buyForm.get('buyquantity');
    }

    get buyquantity1(): any {
        return this.buyForm1.get('buyquantity1');
    }

    get sellprice(): any {
        return this.sellForm.get('sellprice');
    }

    get sellprice1(): any {
        return this.sellForm1.get('sellprice1');
    }

    get sellquantity(): any {
        return this.sellForm.get('sellquantity');
    }

    get sellquantity1(): any {
        return this.sellForm1.get('sellquantity1');
    }

    /** Function to draw trading chart */
    showTradingChart() {
        new TradingView.widget({
            // debug: true, // uncomment this line to see Library errors and warnings in the console
            fullscreen: true,
            //symbol: 'BTCUSD',
            symbol: this.mySymbol,
            interval: 'D',
            container_id: "tradingview_cb72b",
            datafeed: new Datafeeds.UDFCompatibleDatafeed(this.server.chartUrl,60000),
            library_path: "assets/lib/charting_library/",
            locale: "en",
            drawings_access: { type: 'black', tools: [{ name: "Regression Trend" }] },
            disabled_features: ["use_localstorage_for_settings"],
            overrides: {
                "paneProperties.background": "#02112c",
                "paneProperties.vertGridProperties.color": "#02112c",
                "paneProperties.horzGridProperties.color": "#02112c",
                "symbolWatermarkProperties.transparency": 90,
                "scalesProperties.textColor": "#AAA"
            }
        });
    }

    /**Api to get coin list  */
    getCoinlist() {
        // let data = {
        //     "eventExternal": {
        //       "name": "request_get_coin_list",
        //       "key": "mykey"
        //     },
        //     "transferObjectMap": {
        //         "gatewayrequest": {}
        //     }
        // }
        this.spinnerService.show();
        this.server.getApi('wallet/coin/get-coin-list', 0).subscribe(  (succ) => {
            this.spinnerService.hide();
            console.log('Basecoin==>',succ.body.data)
            if(succ.body.status == 200) {    
                
                succ.body.data.forEach((obj) => {
                    if(obj.coinShortName == 'BTC' || obj.coinShortName == 'ETH' || obj.coinShortName =='USD' || obj.coinShortName == 'GBP'|| obj.coinShortName == 'EUR')  {
                        this.coinList.push({
                            coin: obj.coinShortName,
                            coinID: obj.coinId,
                            coinType: obj.coinType
                        });
                    }
                }); 
               
                this.coinList.forEach((obj) => {
                    obj.selected = false;
                });
              
                if(this.coinList.length) {
                    this.coinList[0].selected = true;
                    this.currSelectedCoinObj.coin = this.coinList[0].coin;
                    // change coin id and Passing coin name for get pair
                    this.currSelectedCoinObj.coinID = this.coinList[0].coin;
                    this.currSelectedCoinObj.coinType = this.coinList[0].coinType;
                    this.getpaircoinList();
                }
            }
        }, (err) => {
            this.spinnerService.hide();
        });
    }

    /** Function to get coin pair list */
    getpaircoinList() {
        // let data = {
        //     "eventExternal": {
        //         "name":"request_coin_pair_list",
        //         "key":"mykey"
        //     },
        //     "transferObjectMap": { 
        //         "gatewayrequest": {
        //             "baseCurrency": this.currSelectedCoinObj.coinID,
        //         }
        //     }
        // }
        this.spinnerService.show();
        this.server.getApi('wallet/coin/get-coin-pair-list?baseCoin=' +this.currSelectedCoinObj.coinID, 0).subscribe((succ) => {
            this.spinnerService.hide();
            if(succ.body.status == 200) {
                let cPairListArr = succ.body.data;
                this.coinPairList = [];
                console.log('symbol==>',this.currSelectedCoinObj.coinID, cPairListArr,  succ.body.data)
    
                           succ.body.data.forEach((obj) => {
                    if((obj.coinShortName =='BTC' || obj.coinShortName=='ETH' || obj.coinShortName=='XRP'|| obj.coinShortName=='LTC'|| obj.coinShortName=='XVG'|| obj.coinShortName=='BCH'|| obj.coinShortName=='NEO'|| obj.coinShortName=='XLM'|| obj.coinShortName=='USDT'|| obj.coinShortName=='DASH' || obj.coinShortName=='LCX' ) && obj.coinType=='crypto') {
                        if(this.currSelectedCoinObj.coinType == "crypto") {
                            this.coinPairList.push({
                                coin_short_name: obj.coinShortName,
                                coin_id: obj.coinId,
                                volume: obj.volume,
                                max_price: obj.max_price,
                                min_price: obj.min_price,
                                average: obj.average,
                                selected: false
                            });
                           
                        }
                        if(this.currSelectedCoinObj.coinType == "fiat") {
                            this.coinPairList.push({
                                coin_short_name: obj.coinShortName,
                                coin_id: obj.coinId,
                                volume: obj.volume,
                                max_price: obj.max_price,
                                min_price: obj.min_price,
                                average: obj.average,
                                selected: false
                            });
                        }                        
                    }
                });
                this.coinPairList.forEach((obj) => {
                    obj.last_price = cPairListArr.filter((x) => x.COIN_SHORT_NAME == obj.coinShortName)[0].LAST_PRICE;
                });
                if(this.coinPairList.length) {
                    this.coinPairList[0].selected = true;
                    this.currSelectedPairObj.coinID = this.coinPairList[0].coin_id;
                    this.currSelectedPairObj.coin = this.coinPairList[0].coin_short_name;
                    this.mySymbol= this.currSelectedPairObj.coin + "/" + this.currSelectedCoinObj.coin;
                    console.log('symbol==>',   this.mySymbol)
                    this.manageLiquiditySocket(1);
                    this.getHeaderList();
                    this.buyOrder() ;
                    this.sellOrder() ;
                    this.tradeHistory();
                    this.showTradingChart();
                    this.getLiveDataFromHitBTCForCoinPair(this.getCoinSymbol(this.coinPairList));
                    //this.getLastPrice();
                    if(localStorage.getItem('token')) {
                        this.getBaseCoinBalance();
                        this.getExecutiveCoinBalance();
                        this.getOrderhistory() ;
                        this.getOpenorder();
                        //this.transactionTradinghistory();
                    }
                }
            } else {
                // this.appC.showErrToast(succ.body.message);
            }
        }, (err) => {
            this.spinnerService.hide();
        });
    }

    /** Function to fetch coin symbol */
    getCoinSymbol(arr) {
        let symbolArr = [];
        arr.forEach((obj) => {
            if(!obj.selected) {
                symbolArr.push(obj.coin_short_name+this.currSelectedCoinObj.coin);
            }
        });
        return symbolArr;
    }

    /** Function to get buy order from api */
    buyOrder() {
        this.buyOrderList = [];
        // let data = {
        //     "eventExternal": {
        //         "name":"request_get_order",
        //         "key":"mykey"
        //     },
        //     "transferObjectMap": {
        //         "type":"buy",
        //         "baseCurrency": this.currSelectedCoinObj.coinID,
        //         "executableCurrency": this.currSelectedPairObj.coinID
        //     }
        // }
        this.spinnerService.show();
        this.server.getApi('order/my-active-orders?baseCoin='+this.currSelectedCoinObj.coin,localStorage.getItem('token')).subscribe(succ => {
            this.spinnerService.hide();
            if(succ.body.status == 200) {
                succ.body.data.forEach((obj) => {
                    var ind = this.buyOrderList.findIndex((x) => x.price == obj.price);
                    if(ind != -1) {
                        this.buyOrderList[ind].amount = (Number(this.buyOrderList[ind].amount) + Number(obj.amount)).toFixed(4);
                        this.buyOrderList[ind].total = (this.buyOrderList[ind].price * this.buyOrderList[ind].amount).toFixed(4)
                    } else {
                        this.buyOrderList.push({
                            price: obj.price.toFixed(4),
                            amount: obj.amount.toFixed(4),
                            total: (obj.price * obj.amount).toFixed(4),
                        });
                    }
                });
                this.buyOrderList = this.functionToManageBuyOrder(this.buyOrderList);
                copyBuyOrderArr = this.buyOrderList; 
            } else {
                // this.appC.showErrToast(succ.body.message);
            }
        }, (err) => {
            this.spinnerService.hide();
        });
    }

    /** Function to get sell order from api */
    sellOrder() {
        this.sellOrderList = [];
        // let data = {
        //     "eventExternal": {
        //         "name":"request_get_order",
        //         "key":"mykey"
        //     },
        //     "transferObjectMap": {
        //         "type":"sell",
        //         "baseCurrency": this.currSelectedCoinObj.coinID,
        //         "executableCurrency": this.currSelectedPairObj.coinID
        //     }
        // }
        this.spinnerService.show();
        this.server.getApi('order/my-active-orders?symbol='+this.currSelectedCoinObj.coin+"_"+  
        this.currSelectedPairObj.coin,localStorage.getItem('token')).subscribe(succ => {
            this.spinnerService.hide();
            if(succ.body.status == 200) {
                succ.body.data.forEach((obj) => {
                    var ind = this.sellOrderList.findIndex((x) => x.price == obj.price);
                    if(ind != -1) {
                        this.sellOrderList[ind].amount = (Number(this.sellOrderList[ind].amount) + Number(obj.amount)).toFixed(4);
                        this.sellOrderList[ind].total = (this.sellOrderList[ind].price * this.sellOrderList[ind].amount).toFixed(4)
                    } else {
                        this.sellOrderList.push({
                            price: obj.price.toFixed(4),
                            amount: obj.amount.toFixed(4),
                            total: (obj.price * obj.amount).toFixed(4)
                        });
                    }
                });
                this.sellOrderList = this.functionToManageSellOrder(this.sellOrderList);
                copySellOrderArr = this.sellOrderList;
            } else {
                this.appC.showErrToast(succ.body.message);
            }
        }, (err) => {
            this.spinnerService.hide();
        });
    }

    /** Function to get coin */
    selectCoin(coin) {
        this.coinList.forEach((obj) => {
            obj.selected = false;
        });
        coin.selected = true;
        this.currSelectedCoinObj.coin = coin.coin;
        this.currSelectedCoinObj.coinID = coin.coinID;
        this.currSelectedCoinObj.coinType = coin.coinType;
        this.manageLiquiditySocket(2);
        this.mySymbol=  this.currSelectedPairObj.coin + "/" + this.currSelectedCoinObj.coin; 
        copyBuyOrderArr = [];
        copySellOrderArr = [];
        copyTradeHisArr = [];
        this.stopInterval();  
        this.getpaircoinList();
    }

    /** Function to get pair coin list */
    selectCoinId(coin) {
        console.log('selected pair',coin)
        coin.selected = true;
        
        this.coinPairList.forEach((obj) => {
            if(coin.coin_id != obj.coin_id)
                obj.selected = false;
        });
        this.currSelectedPairObj.coin = coin.coin_short_name;
        this.currSelectedPairObj.coinID = coin.coin_id;
        this.manageLiquiditySocket(2);
        this.mySymbol=  this.currSelectedPairObj.coin + "/" + this.currSelectedCoinObj.coin;
        this.manageLiquiditySocket(1);
        this.buyOrderList = [];
        this.sellOrderList = [];
        this.tradeHistoryList = [];
        copyBuyOrderArr = [];
        copySellOrderArr = [];
        copyTradeHisArr = [];
        // this.getHeaderList();
        if(this.currSelectedCoinObj.coin != "USD" && (coin.coin_short_name == "LCX" || coin.coin_short_name == "USDT")) 
            this.resetHeaderValue();
        this.buyOrder();
        this.sellOrder();
        this.tradeHistory();
        this.showTradingChart();
        this.stopInterval();
        this.getLiveDataFromHitBTCForCoinPair(this.getCoinSymbol(this.coinPairList));
        //this.getLastPrice();
        if(localStorage.getItem('token')) {
            this.getBaseCoinBalance();
            this.getExecutiveCoinBalance();
            this.getOrderhistory();
            this.getOpenorder();
            //this.transactionTradinghistory();        
        }
    }

    /** Function to get trade history from api */
    tradeHistory() {
        this.tradeHistoryList = [];
        let data =  {
            "eventExternal": {
                "name":"request_get_order",
                "key":"mykey"
            },
            "transferObjectMap": {
                "type":"tradeHistory",
                "baseCurrency": this.currSelectedCoinObj.coinID,
                "executableCurrency": this.currSelectedPairObj.coinID
            }
        }
        this.spinnerService.show();
        this.server.post('',data).subscribe((succ) => {
            this.spinnerService.hide();
            if(succ.transferObjectMap.statusCode == 200) {
                succ.transferObjectMap.tradeHistoryList.forEach((obj) => {
                    this.tradeHistoryList.push({
                        orderType: obj.orderType,
                        price: obj.price.toFixed(4),
                        amount: obj.amount.toFixed(4),
                        orderExecutionTime: obj.orderExecutionTime
                    });
                });
                copyTradeHisArr = this.tradeHistoryList;
            } else {
                this.appC.showErrToast(succ.body.message);
            }
        }, (err) => {
            this.spinnerService.hide();
        });
    }

    /** Function to get order history of user */
    transactionTradinghistory() {
        let data = {
            "eventExternal": {
                "name":"request_transaction__trading_history",
                "key":"mykey"
            },
            "transferObjectMap":  {
                "gatewayrequest": {
                    "baseCurrency": this.currSelectedCoinObj.coinID,
                    "executableCurrency": this.currSelectedPairObj.coinID,
                    "loginToken": localStorage.getItem('token')
                }
            }
        }
        this.spinnerService.show();
        this.server.post('',data).subscribe((succ) => {
            this.spinnerService.hide();
            if(succ.body.status == 200) {
                //this.appC.showSuccToast(succ.transferObjectMap.message);
                this.transactionTradeHistoryList = succ.transferObjectMap.transactionTradeHistoryList;
            } else if(succ.transferObjectMap.statusCode == 403){
                //this.appC.showErrToast(succ.transferObjectMap.message); 
                this.header.tokenExpire()
            } else {
                this.appC.showErrToast(succ.body.message);
            }
        }, (err) => {
            this.spinnerService.hide();
        });
    }

    /** Function to cancel order */
    cancelOrder(order) {
        order.click = true;
        // let data = {
        //     "eventExternal": {
        //         "name":"request_cancel_order",
        //         "key":"mykey"
        //     },
        //     "transferObjectMap": {
        //         "gatewayrequest": {
        //             "loginToken": localStorage.getItem("token"),
        //             "orderList":[order.orderId]
        //         }
        //     }
        // }
        let data = {
            "orderId": order.orderId,
            // "symbol":this.baseCoin+'_'+this.exeCoin
            "symbol":this.currSelectedCoinObj.coin+'_'+this.currSelectedPairObj.coin
             }
        this.spinnerService.show();
        this.server.postApi("order-service-btc_eth/cancel-order",data, localStorage.getItem('token')).subscribe((succ) => {
            this.spinnerService.hide();
            if(succ.body.status == 200) {
                this.appC.showInfoToast(succ.body.message);
                this.getOpenorder();
                this.getBaseCoinBalance();
                this.getExecutiveCoinBalance();
            }  else if(succ.body.status == 403)  {
                //this.appC.showErrToast(succ.body.message); 
                this.header.tokenExpire();
            } else {
                this.appC.showErrToast(succ.body.message);
                order.click = false;
            }
        }, (err) => {
            this.spinnerService.hide();
        });
    }

    /** Function to get user open order from api */
    getOpenorder() {
        // let data = {
        //     "eventExternal":  {
        //         "name":"request_open_order",
        //         "key":"mykey"
        //     },
        //     "transferObjectMap":  {
        //         "gatewayrequest": {
        //             "baseCurrency": this.currSelectedCoinObj.coinID,
        //             "executableCurrency": this.currSelectedPairObj.coinID,
        //             "loginToken": localStorage.getItem('token')
        //         }
        //     }
        // }
        // this.spinnerService.show();
        // this.server.post('',data).subscribe((succ) => {
        //     this.spinnerService.hide();
        //     if(succ.transferObjectMap.statusCode == 200) {
        //         this.openOrderList = succ.transferObjectMap.openOrderList;
        //         this.openOrderList.forEach((obj) => {
        //             obj.click = false;
        //         });
        //     } else if(succ.transferObjectMap.statusCode == 403){ 
        //         this.header.tokenExpire()
        //     } else {
        //         this.appC.showErrToast(succ.transferObjectMap.message);
        //     }
        // }, (err) => {
        //     this.spinnerService.hide();
        // });



        this.openOrderList=[];
        if(localStorage.getItem('token')){
    
        //    console.log('OPENHISTROY==>',this.baseCoin+'_'+this.exeCoin)
            this.spinnerService.show();
            this.server.getApi("order-service/my-active-orders?symbol="+this.currSelectedCoinObj.coin+"_"+  
            this.currSelectedPairObj.coin,localStorage.getItem('token')).subscribe(response => {
                this.spinnerService.hide();
                if (response.status == 200) {
                     
                    response.body.data.forEach((element) => {
                        if(element.orderStatus == 'PARTIALLY_EXECUTED') {
                            this.openOrderList.push({
                                total : (element.avgExecutionPrice*element.currentQuantity).toFixed(8),
                                creationTime : element.creationTime,
                                instrument : element.instrument,
                                orderSide : element.orderSide,
                                limitPrice : element.avgExecutionPrice.toFixed(8),
                                quantity : element.currentQuantity.toFixed(8),
                                orderStatus : element.orderStatus,
                                orderId: element.orderId,
                                orderType: element.orderType,
                                filled: (((element.quantity-element.currentQuantity)/element.quantity)*100).toFixed(8),
                                click : false
            
                            }) ;
                        }  
                        else if(element.orderStatus == 'QUEUED') {
                           
                            this.openOrderList.push({
                                total : (element.limitPrice*element.currentQuantity),
                                creationTime : element.creationTime,
                                instrument : element.instrument,
                                orderSide : element.orderSide,
                                limitPrice : element.limitPrice,
                                quantity : element.currentQuantity,
                                orderStatus : element.orderStatus,
                                orderId: element.orderId,
                                orderType: element.orderType,
                                filled: (((element.quantity-element.currentQuantity)/element.quantity)*100).toFixed(8),
                                click : false
            
                            }) ;
                          
                         }
                });
                // console.log("Response--->",this.openOrderArr)
            } else if(response.statusCode == 403) {
                    this.header.logOut();
                } else {
                    this.appC.showErrToast(response.body.message);
                }
            }, error => {
                this.spinnerService.hide()
                this.appC.showErrToast(error.error.error);
            });
        }
    }

    /** Function to get order history of user */
    getOrderhistory() {
        // let data = {
        //     "eventExternal": {
        //         "name":"request_order__history",
        //         "key":"mykey"
        //     },
        //     "transferObjectMap":  {
        //         "gatewayrequest": {
        //               "baseCurrency": this.currSelectedCoinObj.coinID,
        //               "executableCurrency": this.currSelectedPairObj.coinID,
        //               "loginToken": localStorage.getItem('token')
        //         }
        //     }
        // }        
        this.orderHistoryList=[];
        this.spinnerService.show();
        this.server.getApi("order/my-order-history?symbol="+this.currSelectedCoinObj.coin+"_"+  
        this.currSelectedPairObj.coin,localStorage.getItem('token')).subscribe(succ => {
            this.spinnerService.hide();
            if(succ.body.status == 200) {
                this.orderHistoryList = succ.body.data;
                this.orderHistoryList.forEach((obj) => {
                    switch(obj.orderStatus) {
                        case 'COMPLETED':
                            obj.amount = (obj.tradeHistoryAmount - obj.quantity).toFixed(8);
                            obj.total = (obj.quantity * obj.limitPrice).toFixed(8);
                             break;
                        case 'QUEUED':
                            obj.amount = obj.tradeHistoryAmount.toFixed(8);
                            obj.total = (obj.quantity * obj.limitPrice).toFixed(8);
                            break;
                         case 'CREATED':
                            obj.amount = obj.tradeHistoryAmount.toFixed(8);
                            obj.total = (obj.quantity * obj.limitPrice).toFixed(8);
                            break;
                        case 'CANCELLED':
                            obj.amount = obj.amount;
                            obj.total = (obj.quantity * obj.limitPrice).toFixed(8);
                            break;
                    }
                });
                console.log('order Histroy==>', this.orderHistoryList)
            } else if(succ.body.status == 403){ 
                this.header.tokenExpire()
            } else {
                this.appC.showErrToast(succ.body.message);
            }
        }, (err) => {
            this.spinnerService.hide();
        });
    }

    /** Function to get header value */
    getHeaderList() {
        // let data = {
        //     "eventExternal":{
        //         "name":"request_get_header_data",
        //         "key":"mykey"
        //     },
        //     "transferObjectMap":{
        //         "gatewayrequest": {  
        //             "baseCurrency": this.currSelectedCoinObj.coinID,
        //             "executableCurrency": this.currSelectedPairObj.coinID,
        //         }
        //     }
        // }
        // this.spinnerService.show();
        // this.server.post('',data).subscribe((succ) => {
        //     this.spinnerService.hide();
        //     if(succ.transferObjectMap.statusCode == 200) {
        //         this.maxPrice = succ.transferObjectMap.maxPrice.toFixed(8);
        //         this.minPrice = succ.transferObjectMap.minPrice.toFixed(8);
        //         this.volume = succ.transferObjectMap.volume.toFixed(8);
        //         this.average = succ.transferObjectMap.average.toFixed(8);
        //         this.currentPrice = succ.transferObjectMap.lastPrice.toFixed(8);
        //     } else {
        //         this.appC.showErrToast(succ.transferObjectMap.message);
        //     }
        // }, (err) => {
        //     this.spinnerService.hide();
        // });     
    }

    /** Function to get base coin balance */
    getBaseCoinBalance() {
        // let data = {
        //     "eventExternal":{
        //         "name":"request_get_wallet_balance",
        //         "key":"mykey"
        //     },
        //     "transferObjectMap": {                        
        //         "coinId": this.currSelectedCoinObj.coinID,
        //         "loginToken": localStorage.getItem("token") 
        //     }
        // }      
        this.spinnerService.show();
        this.server.getApi("wallet/wallet/get-balance?coinName=BTC",localStorage.getItem('token')).subscribe((succ) => {
            this.spinnerService.hide();
            if(succ.body.status == 200) {
                this.baseWalletBalance = succ.body.data.walletBalance;
            } else if(succ.body.status == 403){
                //this.appC.showErrToast(succ.body.message); 
                this.header.tokenExpire()
            } else {
                this.appC.showErrToast(succ.body.message);
            }
        }, (err) => {
            this.spinnerService.hide();
        });
    }

    /** Function to get executive coin balance */
    getExecutiveCoinBalance() {
        // let data = {
        //     "eventExternal":{
        //         "name":"request_get_wallet_balance",
        //         "key":"mykey"
        //     },
        //     "transferObjectMap": {                        
        //         "coinId": this.currSelectedPairObj.coinID,
        //         "loginToken":localStorage.getItem("token") 
        //     }
        // }
        this.spinnerService.show();
        this.server.getApi("wallet/wallet/get-balance?coinName=ETH",localStorage.getItem('token')).subscribe((succ) => {
            this.spinnerService.hide();
            if(succ.body.statusCode == 200) {
                this.exeWalletBalance = succ.body.data.walletBalance;                
            } else if(succ.body.statusCode == 403){
                //this.appC.showErrToast(succ.body.message); 
                this.header.tokenExpire();
            } else {
                this.appC.showInfoToast(succ.body.message);
            }
        }, (err) => {
            this.spinnerService.hide();
        });
    }

    /**function to save buy order */
    saveBuyOrder() {
        this.limitBuyButton = true;
        if(this.limitbuytotal > this.baseWalletBalance)  {
            this.limitBuyButton = false;
            this.appC.showErrToast("Insufficient Funds...");
            this.buyForm1.reset();
            this.limitbuytotal = null;
        } else {
            // let data =  {
            //     "eventExternal":  {
            //         "name":"request_buy_add_order",
            //         "key":"mykey"
            //     },
            //     "transferObjectMap": {
            //         "tradingType":"LIMIT",
            //         "orderType": "BUY", 
            //         "amount": this.buyForm1.value.buyquantity1,
            //         "price":this.buyForm1.value.buyprice1,
            //         "total":this.limitbuytotal,
            //         "baseCurrency": this.currSelectedCoinObj.coinID,
            //         "executableCurrency": this.currSelectedPairObj.coinID, 
            //         "tradeStop": 0.0,
            //         "tradeLimit": 0.0,
            //         "loginToken": localStorage.getItem('token')
            //     } 
            // }
            let data = {
                "limitPrice":Number(this.buyForm1.value.buyprice1),
                 "orderSide": "BUY",
                 "orderType": "LIMIT",
                 "quantity": Number(this.buyForm1.value.buyquantity1),
                //  "symbol": this.baseCoin+'_'+this.exeCoin
                "symbol":this.currSelectedCoinObj.coin+"_"+this.currSelectedPairObj.coin
         }
            this.spinnerService.show();
            this.server.postApi("order-service-btc_eth/place-order",data,localStorage.getItem("token")).subscribe((succ) => {
                this.spinnerService.hide();
                if(succ.body.status == 200) {
                    this.limitBuyButton = false;
                    this.appC.showInfoToast(succ.body.message);            
                    this.getBaseCoinBalance();
                    this.getExecutiveCoinBalance();
                    this.getOrderhistory();
                    this.getOpenorder();
                    this.buyForm1.reset();
                    this.limitbuytotal=null
                    if(succ.transferObjectMap.isTradeExecuted) {
                        //this.getLastPrice();
                        this.getHeaderList();
                        this.getpaircoinListAfterExecution();
                    }
                } else if(succ.body.status == 403){
                    this.limitBuyButton = false;
                    //this.appC.showErrToast(succ.body.message); 
                    this.header.tokenExpire()
                } else {
                    this.limitBuyButton = false;
                    this.appC.showInfoToast(succ.body.message);
                    this.buyForm1.reset();
                    this.limitbuytotal=null
                }
            }, (err) => {
                this.limitBuyButton = false;
                this.spinnerService.hide();
            })
        }        
    }

    /**function to save sell order */
    saveSellOrder() {
        this.limitSellButton = true;
        if(this.sellForm1.value.sellquantity1 > this.exeWalletBalance)  {
            this.limitSellButton = false;
            this.appC.showErrToast("Insufficient Funds...")
            this.sellForm1.reset();
            this.limitselltotal = null;
        } else {
            // let data =  {
            //     "eventExternal":  {
            //         "name":"request_sell_add_order",
            //         "key":"mykey"
            //     },
            //     "transferObjectMap": {
            //         "tradingType":"LIMIT",
            //         "orderType": "SELL", 
            //         "amount": this.sellForm1.value.sellquantity1,
            //         "price": this.sellForm1.value.sellprice1,
            //         "total": this.limitselltotal,
            //         "baseCurrency": this.currSelectedCoinObj.coinID,
            //         "executableCurrency":this.currSelectedPairObj.coinID, 
            //         "tradeStop": 0.0,
            //         "tradeLimit": 0.0,
            //         "loginToken": localStorage.getItem('token')
            //     }
            // }
            let data = {
                "limitPrice":Number(this.sellForm1.value.sellprice1),
                 "orderSide": "SELL",
                 "orderType": "LIMIT",
                 "quantity": Number(this.sellForm1.value.sellquantity1),
                 "symbol":this.currSelectedCoinObj.coin+"_"+this.currSelectedPairObj.coin
         }

            this.spinnerService.show();
            this.server.postApi("order-service-btc_eth/place-order",data,localStorage.getItem("token")).subscribe((succ) => {
                this.spinnerService.hide();
                if(succ.body.status == 200) {
                    this.limitSellButton = false;
                    this.appC.showInfoToast(succ.body.message);              
                    this.getBaseCoinBalance();
                    this.getExecutiveCoinBalance();
                    this.getOrderhistory();
                    this.getOpenorder();
                    this.sellForm1.reset();
                    this.limitselltotal=null
                    if(succ.body.isTradeExecuted) {
                        //this.getLastPrice();
                        this.getHeaderList();
                        this.getpaircoinListAfterExecution();
                    }
                } else if(succ.body.statusCode == 403){
                    this.limitSellButton = false;
                    //this.appC.showErrToast(succ.body.message); 
                    this.header.tokenExpire();
                } else {
                    this.limitSellButton = false;
                    this.appC.showErrToast(succ.body.message);
                    this.sellForm1.reset();
                }
              }, (err) => {
                this.limitSellButton = false;
                this.spinnerService.hide();
            })
        }
    }

    /**function to calculate market buy estimate */
    marketBuyEstimate() {
        if(this.hitBTCDataStatus) {
            console.log("hit api for hitbtc");
            this.marketBuyButton = true;
            // let data= {
            //     "eventExternal": {
            //         "name":"request_buy_add_order",
            //         "key":"mykey"
            //     },
            //     "transferObjectMap":  {
            //         "tradingType":"MARKET",                
            //         "orderType": "BUY", 
            //         "amount": this.buyForm.value.buyquantity,
            //         "price": this.currentPrice,
            //         "baseCurrency": this.currSelectedCoinObj.coinID,
            //         "executableCurrency":this.currSelectedPairObj.coinID,
            //         "tradeStop": 0.0,
            //         "tradeLimit": 0.0,                                         
            //         "loginToken": localStorage.getItem('token')
            //     }
            // }
            let data = {
               
                "orderSide": "BUY",
                "orderType": "MARKET",
                "quantity": Number(this.buyForm.value.buyquantity),
                 "symbol": this.currSelectedCoinObj.coin+"_"+this.currSelectedPairObj.coin
             
              }
            this.server.postApi("order-service-btc_eth/place-order",data,localStorage.getItem("token")).subscribe((succ1) => {
                this.spinnerService.hide();
                if(succ1.transferObjectMap.statusCode == 200) {
                    this.marketBuyButton = false;
                    this.appC.showInfoToast(succ1.transferObjectMap.message);
                    this.buyForm.reset();
                    this.getBaseCoinBalance();
                    this.getExecutiveCoinBalance();
                    this.getOrderhistory();
                    this.getOpenorder();
                    if(succ1.transferObjectMap.isTradeExecuted) {
                        //this.getLastPrice();
                        // this.getHeaderList();
                        this.getpaircoinListAfterExecution();
                    }
                } else if(succ1.transferObjectMap.statusCode == 403){
                    this.marketBuyButton = false;
                    this.header.tokenExpire();
                }  else {
                    this.marketBuyButton = false;
                    this.appC.showInfoToast(succ1.body.message);
                    this.buyForm.reset();
                }
            }, (err) => {
                this.marketBuyButton = false;
                this.spinnerService.hide();
            });
        } else {
            console.log("hit api for own data");
            this.marketBuyButton = true;
            let data = {
                "eventExternal":  {
                    "name":"request_estimate_buy_order",
                    "key":"mykey"
                },
                "transferObjectMap": {
                    "amount": this.buyForm.value.buyquantity,
                    "baseCurrency": this.currSelectedCoinObj.coinID,
                    "executableCurrency": this.currSelectedPairObj.coinID, 
                    "orderType":"BUY",
                    "loginToken": localStorage.getItem('token')              
                }
            }
            this.spinnerService.show();
            this.server.post('',data).subscribe((succ) => {
                if(succ.transferObjectMap.statusCode == 200) {
                    if(succ.transferObjectMap.orderContains) {
                        let price = (succ.transferObjectMap.estimatePrice / succ.transferObjectMap.estimateAmount);
                        let amount = succ.transferObjectMap.estimateAmount;
                        let total = (amount * price);
                        console.log("total -> "+total);
                        console.log("baseWalletBalance -> "+this.baseWalletBalance);
                        if(Number(total) <= Number(this.baseWalletBalance)) {
                            // let data= {
                            //     "eventExternal": {
                            //         "name":"request_buy_add_order",
                            //         "key":"mykey"
                            //     },
                            //     "transferObjectMap":  {
                            //         "tradingType":"MARKET",                
                            //         "orderType": "BUY", 
                            //         "amount": amount,
                            //         "price": price,
                            //         "total": total,
                            //         "baseCurrency": this.currSelectedCoinObj.coinID,
                            //         "executableCurrency":this.currSelectedPairObj.coinID,
                            //         "tradeStop": 0.0,
                            //         "tradeLimit": 0.0,                                         
                            //         "loginToken": localStorage.getItem('token')
                            //     }
                            // }
                            let data = {
               
                                "orderSide": "BUY",
                                "orderType": "MARKET",
                                "quantity": Number(amount),
                                "symbol":this.currSelectedCoinObj.coin+"_"+this.currSelectedPairObj.coin
                             
                              }
                              this.server.postApi("order-service-btc_eth/place-order",data,localStorage.getItem("token")).subscribe((succ1) => {
                                this.spinnerService.hide();
                                if(succ1.body.status == 200) {
                                    this.marketBuyButton = false;
                                    this.appC.showInfoToast(succ1.body.message);
                                    this.buyForm.reset();
                                    this.getBaseCoinBalance();
                                    this.getExecutiveCoinBalance();
                                    this.getOrderhistory();
                                    this.getOpenorder();
                                    if(succ1.body.isTradeExecuted) {
                                        //this.getLastPrice();
                                        this.getHeaderList();
                                        this.getpaircoinListAfterExecution();
                                    }
                                } else if(succ1.body.status == 403){
                                    this.marketBuyButton = false;
                                    this.header.tokenExpire();
                                }  else {
                                    this.marketBuyButton = false;
                                    this.appC.showInfoToast(succ1.body.message);
                                    this.buyForm.reset();
                                }
                            }, (err) => {
                                this.marketBuyButton = false;
                                this.spinnerService.hide();
                            });
                        } else {
                            this.marketBuyButton = false;
                            this.spinnerService.hide();
                            this.buyForm.reset();    
                            this.appC.showErrToast("You can't execute the market order because you don't have enough amount to your wallet balance.");
                        }
                    } else {
                        this.marketBuyButton = false;
                        this.spinnerService.hide();
                        this.buyForm.reset();
                        this.appC.showErrToast("Don't have enough order.");
                    }
                } else if(succ.body.status == 403){
                    this.marketBuyButton = false;
                    this.spinnerService.hide(); 
                    this.header.tokenExpire()
                }  else {
                    this.marketBuyButton = false;
                    this.spinnerService.hide();
                    this.appC.showInfoToast(succ.body.message);
                    this.buyForm.reset();
                }
            }, (err) => {
                this.marketBuyButton = false;
                this.spinnerService.hide();
            });
        }        
    }

    /**function to calculate market buy estimate */
    marketSellEstimate() {
        if(Number(this.sellForm.value.sellquantity) > Number(this.exeWalletBalance)) {
            this.appC.showErrToast("You can't sell coins more than your wallet amount.");
            return;
        } else {
            if(this.hitBTCDataStatus) {
                console.log("hit api for hitbtc");
                this.marketSellButton = true;
                // let data = {
                //     "eventExternal":  {
                //         "name":"request_sell_add_order",
                //         "key":"mykey"
                //     },
                //     "transferObjectMap": {
                //         "tradingType":"Market",
                //         "orderType": "SELL", 
                //         "amount": this.sellForm.value.sellquantity,
                //         "price":  this.currentPrice,
                //         "baseCurrency": this.currSelectedCoinObj.coinID,
                //         "executableCurrency":this.currSelectedPairObj.coinID, 
                //         "tradeStop": 0.0,
                //         "tradeLimit": 0.0,
                //         "loginToken": localStorage.getItem('token')
                //     }
                // }
                let data = {
               
                    "orderSide": "SELL",
                    "orderType": "MARKET",
                    "quantity": Number(this.sellForm.value.sellquantity),
                    "symbol":this.currSelectedCoinObj.coin+"_"+this.currSelectedPairObj.coin
                 
                  }
                  this.server.postApi("order-service-btc_eth/place-order",data,localStorage.getItem("token")).subscribe((succ1) => {
                    this.spinnerService.hide();
                    if(succ1.body.statusCode == 200) {
                        this.marketSellButton = false;
                        this.appC.showInfoToast(succ1.body.message);
                        this.sellForm.reset();
                        this.getBaseCoinBalance();
                        this.getExecutiveCoinBalance();
                        this.getOrderhistory();
                        this.getOpenorder();
                        if(succ1.body.isTradeExecuted) {
                            // this.getLastPrice();
                            // this.getHeaderList();
                            this.getpaircoinListAfterExecution();
                        }
                    } else if(succ1.body.statusCode == 403){
                        this.marketSellButton = false;
                        this.header.tokenExpire();
                    } else {
                        this.marketSellButton = false;
                        this.appC.showInfoToast(succ1.body.message);
                        this.sellForm.reset();
                    }
                }, (err) => {
                    this.marketSellButton = false;
                    this.spinnerService.hide();
                });
            } else {
                console.log("hit api for own data");
                this.marketSellButton = true;
                let data = {
                    "eventExternal": {
                        "name": "request_estimate_sell_order",
                        "key": "mykey"
                    },
                    "transferObjectMap": {
                        "amount": this.sellForm.value.sellquantity,
                        "baseCurrency": this.currSelectedCoinObj.coinID,
                        "executableCurrency": this.currSelectedPairObj.coinID, 
                        "orderType": "SELL",
                        "loginToken": localStorage.getItem('token')
                    }
                }
                this.spinnerService.show();
                this.server.post('',data).subscribe((succ) => {
                    if(succ.transferObjectMap.statusCode == 200) {
                        if(succ.transferObjectMap.orderContains) {
                            let price = (succ.transferObjectMap.estimatePrice / succ.transferObjectMap.estimateAmount);
                            let amount = succ.transferObjectMap.estimateAmount;
                            let total = (amount * price);
                            console.log("amount -> "+amount);
                            console.log("exeWalletBalance -> "+this.exeWalletBalance);
                            if(Number(amount) <= Number(this.exeWalletBalance)) {
                                // let data = {
                                //     "eventExternal":  {
                                //         "name":"request_sell_add_order",
                                //         "key":"mykey"
                                //     },
                                //     "transferObjectMap": {
                                //         "tradingType":"Market",
                                //         "orderType": "SELL", 
                                //         "amount": amount,
                                //         "price":  price,
                                //         "total": total,
                                //         "baseCurrency": this.currSelectedCoinObj.coinID,
                                //         "executableCurrency":this.currSelectedPairObj.coinID, 
                                //         "tradeStop": 0.0,
                                //         "tradeLimit": 0.0,
                                //         "loginToken": localStorage.getItem('token')
                                //     }
                                // }
                                let data = {
               
                                    "orderSide": "SELL",
                                    "orderType": "MARKET",
                                    "quantity": Number(amount),
                                    "symbol":this.currSelectedCoinObj.coin+"_"+this.currSelectedPairObj.coin
                                 
                                  }
                                  this.server.postApi("order-service-btc_eth/place-order",data,localStorage.getItem("token")).subscribe((succ1) => {
                                    this.spinnerService.hide();
                                    if(succ1.body.status == 200) {
                                        this.marketSellButton = false;
                                        this.appC.showInfoToast(succ1.body.message);
                                        this.sellForm.reset();
                                        this.getBaseCoinBalance();
                                        this.getExecutiveCoinBalance();
                                        this.getOrderhistory();
                                        this.getOpenorder();
                                        if(succ1.body.isTradeExecuted) {
                                            // this.getLastPrice();
                                            this.getHeaderList();
                                            this.getpaircoinListAfterExecution();
                                        }
                                    } else if(succ1.body.statusCode == 403){
                                        this.marketSellButton = false;
                                        this.header.tokenExpire()
                                    } else {
                                        this.marketSellButton = false;
                                        this.appC.showInfoToast(succ1.body.message);
                                        this.sellForm.reset();
                                    }
                                }, (err) => {
                                    this.marketSellButton = false;
                                    this.spinnerService.hide();
                                });
                            } else {
                                this.marketSellButton = false;
                                this.spinnerService.hide();
                                this.sellForm.reset();
                                this.appC.showErrToast("You can't execute the market order because you don't have enough amount to your wallet balance.");
                            }
                        } else {
                            this.marketSellButton = false;
                            this.spinnerService.hide();
                            this.sellForm.reset();
                            this.appC.showErrToast("Don't have enough order.");
                        }
                    } else if(succ.body.status == 403) {
                        this.marketSellButton = false;
                        this.spinnerService.hide(); 
                        this.header.tokenExpire();
                    }  else {
                        this.marketSellButton = false;
                        this.spinnerService.hide();
                        this.appC.showErrToast(succ.body.message);
                        this.sellForm.reset();
                    }
                }, (err) => {
                    this.marketSellButton = false;
                    this.spinnerService.hide();
                });
            }
        }        
    }

    /** Function to get last price */
    getLastPrice() {
        let data = {
            "eventExternal":{
                "name":"request_get_last_price",
                "key":"mykey"
            },
            "transferObjectMap":{
                "gatewayrequest":{
                    "baseCurrency":this.currSelectedCoinObj.coinID,
                    "executableCurrency":this.currSelectedPairObj.coinID
                }
            }
        }
        this.spinnerService.show();
        this.server.post('',data).subscribe((succ) => {
            this.spinnerService.hide();
            if(succ.transferObjectMap.statusCode == 200) {
                this.lastPrice = succ.transferObjectMap.lastPrice;
            } else {}
        }, (err) => {
              this.spinnerService.hide();
        });
    }

    /**function to get coin pair list after execution */
    getpaircoinListAfterExecution() {
         let data = {
        //     "eventExternal": {
        //         "name":"request_coin_pair_list",
        //         "key":"mykey"
        //     },
        //     "transferObjectMap": {
        //         "gatewayrequest": {
        //             "baseCurrency": this.currSelectedCoinObj.coinID
        //         }
        //     }
     }
        this.server.postApi("",data,0).subscribe((succ) => {
            if(succ.transferObjectMap.statusCode == 200) {
                let pairList = succ.transferObjectMap.coinPairList;
                let lastPairList = succ.transferObjectMap.coinLastPairList;
                pairList.forEach((obj) => {
                    let ind = this.coinPairList.findIndex((x) => x.coinID == obj.coin_id);
                    if(ind != -1) {
                        this.coinPairList[ind].volume = obj.volume;
                        this.coinPairList[ind].average = obj.average;
                    }
                });
                lastPairList.forEach((obj) => {
                    let ind = this.coinPairList.findIndex((x) => x.coin_short_name == obj.COIN_SHORT_NAME);
                    if(ind != -1) {
                        this.coinPairList[ind].last_price = obj.LAST_PRICE;
                    }
                });
            }
        }, (err) => {
        });
    }

    /** Function for select user's open/order history data from api */
    getUserOrder(type) {
        if(localStorage.getItem("token")) {
            switch(type) {
                case 1: 
                    this.getOpenorder();
                    break;
                case 2: 
                    this.getOrderhistory();
                    break;
            }
        }
    }

    /** Function for manage liquidit socket event */
    manageLiquiditySocket(type) {
        let data = {
            "method": "",
            "params": {
                "symbol": this.mySymbol.replace("/","").replace("GBP","USD"),
                "limit": ""
            },
            "id": "LCX"
        }
        let skdata = {
            messageType:'SUBSCRIBE_TICKER',
            params: {
                symbol: this.currSelectedCoinObj.coin+"_"+this.currSelectedPairObj.coin .replace("GBP","USD")
            }
        }
       
        this.server.wsExchange.send(JSON.stringify(skdata));
       
        console.log('Symobol==>',this.server.liqWSObj.readyState,type,this.mySymbol)
        switch(type) {
            case 1:
                if(this.server.liqWSObj.readyState) {
                    data.method = "subscribeTicker";
                    this.server.liqWSObj.send(JSON.stringify(data));

                    /** Subscribe for order book data */
                    data.method = "subscribeOrderbook";
                    this.server.liqWSObj.send(JSON.stringify(data));

                    /** Subscribe for trade history data */
                    data.method = "subscribeTrades";
                    data.params.limit = "50";
                    this.server.liqWSObj.send(JSON.stringify(data));
                }          
                break;
            case 2:
                if(this.server.liqWSObj.readyState) {
                    data.method = "unsubscribeTicker";
                    this.server.liqWSObj.send(JSON.stringify(data));

                    /** Unsubscribe order book data */
                    data.method = "unsubscribeOrderbook";
                    this.server.liqWSObj.send(JSON.stringify(data));

                    /** Unsubscribe trade history data */
                    data.method = "unsubscribeTrades";
                    this.server.liqWSObj.send(JSON.stringify(data));
                }                
                break;
        }
    }

    /** Function to get live data for other pair */
    getLiveDataFromHitBTCForCoinPair(symArr) {
        console.log('hitBTC==>',symArr)
        if(symArr.length) {
            // let data = {
            //     "eventExternal": {
            //         "name": "request_get_live_data_for_symbols",
            //         "key": ""
            //     },
            //     "transferObjectMap": {
            //         "gatewayrequest": {
            //             "url": "https://api.hitbtc.com/api/2/public/ticker",
            //             "symbols": symArr
            //         }
            //     }
            // }
            let data = {
                "url": "https://api.hitbtc.com/api/2/public/ticker",
                "symbols": symArr
            }
            this.server.postApi("wallet/coin/get-live-market-data",data, localStorage.getItem('token')).subscribe((succ) => {
                if(succ.body.status == 200) {
                    this.coinPairList.forEach((obj) => {
                        var ind = succ.body.data.findIndex((data) => data.symbol.substr(0, (data.symbol.length-3)) == obj.coin_short_name);
                        if(ind != -1) {
                            obj.last_price = succ.body.data[ind].last;
                            obj.volume = succ.body.data[ind].volume;
                            obj.average = (Number(succ.body.data[ind].low) + Number(succ.body.data[ind].high))/2;
                        }
                    });
                    this.startInterval(symArr);
                }
            }, (err) => {
            });            
        }        
    }

    /** Function to start interval for getting latest value for pair */
    startInterval(symbolArr) {
        console.log('hitBTC==>',symbolArr)
        this.hitbtcIntervalID = setInterval((obj) => {
            // let data = {
            //     "eventExternal": {
            //         "name": "request_get_live_data_for_symbols",
            //         "key": ""
            //     },
            //     "transferObjectMap": {
            //         "gatewayrequest": {
            //             "url": "https://api.hitbtc.com/api/2/public/ticker",
            //             "symbols": symbolArr
            //         }
            //     }
            // }
            let data = {
                "url": "https://api.hitbtc.com/api/2/public/ticker",
                "symbols": symbolArr
            }
            this.server.postApi("wallet/coin/get-live-market-data",data, localStorage.getItem('token')).subscribe((succ) => {
                if(succ.body.statusCode == 200) {
                    this.coinPairList.forEach((obj) => {
                        var ind = succ.body.data.findIndex((data) => data.symbol.substr(0, (data.symbol.length-3)) == obj.coin_short_name);
                        if(ind != -1) {
                            obj.last_price = succ.body.data[ind].last;
                            obj.volume = succ.body.data[ind].volume;
                            obj.average = (Number(succ.body.data[ind].low) + Number(succ.transferObjectMap.data[ind].high))/2;
                        }
                    });
                }
            }, (err) => {
            });
        }, 10000);
    }

    /** Function to stop interval for getting latest value for pair */
    stopInterval() {
        clearInterval(this.hitbtcIntervalID);
    }

    /** Set the zero value to header obj */
    resetHeaderValue() {
        setTimeout(() => {
            this.maxPrice = "0.0000000";
            this.minPrice = "0.0000000";
            this.volume = "0.0000000";
            this.average = "0.0000000";
            this.currentPrice = "0.0000000";
        },1000);        
    }
}
