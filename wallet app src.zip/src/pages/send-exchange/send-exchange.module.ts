import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SendExchangePage } from './send-exchange';

@NgModule({
  declarations: [
    SendExchangePage,
  ],
  imports: [
    IonicPageModule.forChild(SendExchangePage),
  ],
})
export class SendExchangePageModule {}
