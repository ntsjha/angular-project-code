import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { ServiceService } from 'src/app/service/service.service';
import { CookieService } from 'ngx-cookie-service';
import { NgxSpinnerService } from 'ngx-spinner';
import { Router } from '@angular/router';
import { AppComponent } from 'src/app/app.component';


declare var $: any;

@Component({
    selector: 'app-add-role',
    templateUrl: './add-role.component.html',
    styleUrls: ['./add-role.component.css']
})
export class AddRoleComponent implements OnInit, OnDestroy {
    addForm: FormGroup;
    response: any = {};
    userIp: any;
    showApiMessage: any = false;
    subscription: any;
    google: any = { one: '', two: '', three: '', four: '', five: '', six: '' };

    constructor(private service: ServiceService, private spinner: NgxSpinnerService, private cookie: CookieService, private router: Router, private appC: AppComponent) {
        this.addForm = new FormGroup({
            name: new FormControl('', [Validators.required, Validators.pattern(/^[a-z ,.'-]*$/i), Validators.maxLength(255), Validators.minLength(2)])
        });
        this.subscription = this.service.authVerify.subscribe(val => {
            if (val == 'add-role') {
                this.addRole();
                this.service.authVerify.next('false');
            }
        });
    }

    /** Function to get data values */
    get name(): any {
        return this.addForm.get('name');
    }

    /** Function to send value */
    addFormTest(...val) {
        this.addForm.controls.name.setValue(val[0]);
        return this.addForm.valid;
    }

    ngOnInit() {
        window.scrollTo(0, 0);
        this.userIp = (this.cookie.get('userInfo')) ? JSON.parse(this.cookie.get('userInfo')) : this.service.initialUserInfo;
    }

    ngOnDestroy() {
        this.subscription.unsubscribe();
    }

    /** Function to verify google authentication */
    verifyGoogleAuth() {
        this.appC.google = { one: '', two: '', three: '', four: '', five: '', six: '' };
        this.appC.response = { message: '' };
        this.service.googleAuthCalledFrom = 'add-role';
        $('#google-auth-modal').modal({ keyboard: false, backdrop: 'static' });

    }

    /** Function to add role */
    addRole() {
        if (this.addForm.valid) {
            this.spinner.show();
            const data = {
                ipAddress: this.service.encrypt(this.userIp.ip),
                location: this.service.encrypt(this.userIp.city + ',' + this.userIp.country_name),
                role: this.service.encrypt(this.addForm.value.name),
            };
            this.service.postMethod('account/superAdmin/user-management/add-role', data, 1).subscribe((response: any) => {
                this.showApiMessage = true;
                this.response = response;
                if (response.status === 900) {
                    this.response.message = 'Role added Successfully';
                    this.router.navigate(['/manage-roles']);
                } else {
                    this.response.message = 'Something went wrong. Please try again after sometime.';
                }
                this.spinner.hide();
            }, (error) => {
                this.showApiMessage = true;
                this.response = error.error;
                this.spinner.hide();
            });
        }
    }

    /** Auto focus functionality */
    onKey(event, next, previous) {
        if (event.key === 'Backspace') {
            document.getElementById(previous).focus();
        } else {
            if (event.keyCode >= 48 && event.keyCode <= 57) {
                if (event.target.value.trim() !== '') {
                    document.getElementById(next).focus();
                } else {
                    event.target.value = '';
                }
            } else {
                event.target.value = '';
            }
        }
    }


}
