import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
    selector: 'app-otcdesk',
    templateUrl: './otcdesk.component.html',
    styleUrls: ['./otcdesk.component.css']
})
export class OtcdeskComponent implements OnInit {

    constructor(public router: Router) { }

    ngOnInit() {
        window.scrollTo(0,0);
    }

    requestOtcQuote() {
        this.router.navigateByUrl('header/reqOtcQuote');
    }

}
