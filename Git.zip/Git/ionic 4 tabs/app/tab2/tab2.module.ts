import { IonicModule } from '@ionic/angular';
import { RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Tab2Page } from './tab2.page';
import { ReactiveFormsModule, } from '@angular/forms';
import { IonicStorageModule } from '@ionic/storage';
@NgModule({
  imports: [
    IonicModule,
    CommonModule,
    ReactiveFormsModule,
    IonicStorageModule.forRoot({
      name: '__mydb',
driverOrder: ['indexeddb', 'sqlite', 'websql']
    }),
    FormsModule,
    RouterModule.forChild([{ path: '', component: Tab2Page },])
  ],
  declarations: [Tab2Page]
})
export class Tab2PageModule {}
