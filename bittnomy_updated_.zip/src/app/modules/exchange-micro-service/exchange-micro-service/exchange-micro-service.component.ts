import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AppComponent } from '../../../app.component';
import { ServerService } from '../../../service/server.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { HeaderComponent } from '../../header/header/header.component';

declare var $: any;
declare const TradingView: any;
declare const Datafeeds: any;
declare const AmCharts: any;


@Component({
    selector: 'app-exchange-micro-service',
    templateUrl: './exchange-micro-service.component.html',
    styleUrls: ['./exchange-micro-service.component.css']
})
export class ExchangeMicroServiceComponent implements OnInit {
    webNamesArr = [{
        "websiteName": "Poloniex",
        "status": "2",
        "active": "false"
      },
      {
        "websiteName": "Binance",
        "status": "1",
        "active": "false"
      },
      {
        "websiteName": "HitBTC",
        "status": "3",
        "active": "false"
      }
  ]
  loginStatus = false;
  hitbtcIntervalID: any;
  headerPriceObj = {currPrice:"", highest:"", average:"", lowest:"", volume:""};
  currentCoinObj = {coinShort:"", coinFullName:"", coinId:""};    
  currentPairCoinObj = {coinShort:"", coinFullName:"", coinId:""};
  searchText = "";
  currTab = "BUY";
  buyOrderType = "LIMIT";
  sellOrderType = "LIMIT";
  coinListArr = [];
  coinPairListArr = [];
  tradeViewPair =  "BTC/ETH";
  openOrderArr = [];
  orderHistoryArr = [];
  tradeHistoryArr = [];
  sellOrderArr = [];
  buyOrderArr = [];
  userData = {baseCoinBal:"",pairCoinBal:""};
  limitBuyObj = {price:"", amount:"", total:""};
  limitSellObj = {price:"", amount:"", total:""};
  marketBuyObj = {amount:""};
  marketSellObj = {amount:""};
  sLimitBuyObj = {stop:"", price:"", amount:"", total:""};
  sLimitSellObj = {stop:"", price:"", amount:"", total:""};
  regexForEightChar = (/^(\d+)?([.]?\d{0,8})?$/);
  currentTab: any = 'BID';
  SocketDataStatus :any = false;
  count: number=0;
  poloniexTradePair: any;
  PoloArr: any=[];
  polo_id: any;
  const: any;
  HitBTCPair = "BTCETH";
  symbolArr: any = [];
  feeList: any[];
  takerFee: any = '0.00';
  makerFee: any = '0.00';
  feeListApi = false;
  kyc: any;
  checkyc: any = "";
  kycMessage: string;
  tradingChart: any;
    baseCoin: any;
    exeCoin: any;
    clearInt: any;
    binanceSocket: any;
    arr: any;
    datacoin: any=[];
    volume: any;
    coinPairListdata: any;
    
    orderHisArr: any[];
    tradeHisArr:any=[];
    coin: any;

    // clearInt: NodeJS.Timer;
    // binanceSocket: NodeJS.Timer;
    constructor(private activatedRoutes: ActivatedRoute, private router: Router, private appC: AppComponent, private server: ServerService, private spinnerService: Ng4LoadingSpinnerService, public header: HeaderComponent) {
        // this.server.initSocket();
        console.log('hello');
        
    } 

    ngOnInit() {
        // this.openConfirmationModal();
       
        // let data1 = {
        //     messageType:'SUBSCRIBE_TICKER',
        //     params: {
        //         symbol:'ETH_BTC'
        //     }
        // }
        // this.server.wsExchange.send(JSON.stringify(data1));
        this.baseCoin = this.activatedRoutes.snapshot.params.base;
        this.exeCoin = this.activatedRoutes.snapshot.params.exe;
        window.scrollTo(0,0);
       
        this.getCoinListExchange();
       
       
        this.currTab = "BUY";
        if (localStorage.getItem("token")) {
            this.loginStatus = true;
        } else {
            this.loginStatus = false;
        }
        // let data = {
        //     "messageType": "",
        //     "params": {
        //     "symbol": ""
        //     }
        //     }
        //     data.messageType = "SUBSCRIBE_TICKER";
        //     data.params.symbol = "LTC_BTC";
        //     this.server.wsExchange.send(JSON.stringify(data));

        //testing
        // this.markethistroy()
        // this.getUserOpenOrder()
        // this.getTradeHistory()
        // this.getUserOrderHistory()
        this.getSellOrder()
       
    }

  openConfirmationModal() {
            $('#confirmationModal').modal({backdrop: 'static', keyboard: false});
        }
    /** Function to get coin list from api */
    getCoinListExchange() {
        this.spinnerService.show();
        this.server.getApi('wallet/coin/get-coin-list', 0).subscribe( (succ) => {
            this.spinnerService.hide();
            if (succ.body.status == 200) {
                
                let data = succ.body.data;
                this.coinListArr = data.filter((x) => x.coinType=="crypto" && (x.coinShortName == 'IPR' ||x.coinShortName == 'BTC' || x.coinShortName == 'ETH' || x.coinShortName == 'USDT'));
               let ind= this.coinListArr.findIndex((x)=>x.coinShortName==this.baseCoin)

                if(ind>-1){
                this.currentCoinObj.coinId = this.coinListArr[ind].coinId;
                this.currentCoinObj.coinShort = this.baseCoin;
                this.currentCoinObj.coinFullName = this.coinListArr[ind].coinFullName;
                }
                    
                this.clearInt = setTimeout(() =>{
                    // this.connectSocket();

                },2000)
                 
                // this.getCoinPairOnCoinChange();
                 this.getCoinPair(this.baseCoin)
            } else {
                this.appC.showErrToast(succ.body.message);
            }
        }, (err) => {
            this.spinnerService.hide();
        });
        
    }

// *******************  SOCKET *****************************
 


    /** Function to get coin pair list from api*/
    getCoinPair(coinShortName) {
        console.log('getCoinPair===>')
        this.coinPairListArr = [];
        this.spinnerService.show();
        this.server.getApi('wallet/coin/get-coin-pair-list?baseCoin=' + coinShortName, 0).subscribe((succ) => {
            this.spinnerService.hide();
            if (succ.body.status == 200) {
                let data = [];
                this.coinPairListArr = [];
                succ.body.data.forEach(obj => {
                    if (obj.coinShortName == 'BTC' || obj.coinShortName == 'ETH' || obj.coinShortName == 'XRP' || obj.coinShortName == 'BCH' || obj.coinShortName == 'XLM' || obj.coinShortName == 'LTC' || obj.coinShortName == 'IOTA' || obj.coinShortName == 'USDT' || obj.coinShortName == 'XVG' || obj.coinShortName == 'IPR' || obj.coinShortName == 'ECH') {
                       data.push(obj);
                    }
                });
             
                data.forEach(obj => {
                    this.coinPairListArr.push({
                        coinID: obj.coinId,
                        coin: obj.coinShortName,
                        coinFullName: obj.coinFullName,
                        volume:this.volume,
                        average: obj.average,
                        last_price: ''
                    });
                    this.subsribeCoinPairList(obj.coinShortName);
                });
                console.log('coinpairlist==>',data,this.coinPairListArr)
                
            //     for(let i=0;i< this.coinListArr.length;i++){
            //         if (this.coinListArr[i].coinShortName ==  this.baseCoin || this.coinListArr[i].coinShortName == this.coinhit ) {
            //            this.coinPairListArr=this.coinListArr[i].pairList
            
            //     }
            // }
                this.getTradeHistory();
                // let cPairListArr = succ.transferObjectMap.coinLastPairList;
                this.getCoinSymbol(this.coinPairListArr);
                // this.getCoinSymbol(this.coinPairListArr);
                // this.coinPairListArr.forEach((obj) => {
                //     obj.last_price = cPairListArr.filter((x) => x.COIN_SHORT_NAME == obj.coin)[0].LAST_PRICE;
                //     obj.selected = false;
                // });
                if(this.coinPairListArr.length) {
                    let ind = this.coinPairListArr.findIndex(x => x.coin == this.currentPairCoinObj.coinShort);
                    if(ind > -1) {
                        this.coinPairListArr[ind].selected = true;
                        this.currentPairCoinObj.coinId = this.coinPairListArr[ind].coinID;
                        this.currentPairCoinObj.coinFullName = this.coinPairListArr[ind].coinFullName;
                    }
                    
                    // this.currentPairCoinObj.coinShort = this.coinPairListArr[0].coin;
                    // this.currentPairCoinObj.coinId = this.coinPairListArr[0].coinID;
                    // this.currentPairCoinObj.coinFullName = this.coinPairListArr[0].coinFullName;
                    this.tradeViewPair = this.currentCoinObj.coinShort+"/"+this.exeCoin;
                    this.HitBTCPair = this.currentPairCoinObj.coinShort+this.currentCoinObj.coinShort;
                    if(this.feeListApi) {
                        let ind = this.feeList.findIndex(x => x.coinShortName == this.currentPairCoinObj.coinShort);
                        this.takerFee = this.feeList[ind].takerFee;
                        this.makerFee = this.feeList[ind].makerFee;
                    }
                    
                    /** for binance socket */
                    if(this.server.activatedSocket == "Binance") {
                        
                        this.server.pair = this.currentPairCoinObj.coinShort + this.currentCoinObj.coinShort
                        this.server.pair = this.server.pair.toLowerCase();
                        this.server.thirdPartySocket();   
                        this.callCoinListWithSocket(this.server.activatedSocket,1);
                    } else if(this.server.activatedSocket == "Poloniex") {
                        this.poloniexTradePair = this.currentCoinObj.coinShort+"_"+this.currentPairCoinObj.coinShort;
                        this.server.thirdPartySocket();
                        //this.callCoinListWithSocket(this.server.activatedSocket,1);
                    } else if(this.server.activatedSocket == "HitBTC") {
                        this.server.thirdPartySocket();
                        // this.getLiveDataFromHitBTCForCoinPair();
                        //this.callCoinListWithSocket(this.server.activatedSocket,1);
                    }
                    
                    this.getTradeHistory();
                    this.getSellOrder();
                    this.getBuyOrder();
                    this.getLiquidityData();
                    this.drawTradingChart();
                    this.getHeaderPrice();
                    if(localStorage.getItem("token")) {
                        this.getUserBaseCoinBalance();
                        this.getUserPairCoinBalance();
                        this.getUserOpenOrder();
                        this.getUserOrderHistory();
                        this.getUserBaseCoinBalance()
                        this.getUserPairCoinBalance()
                    }
                }
            } else {
                this.coinPairListArr = [];
                this.appC.showErrToast(succ.transferObjectMap.message);
            }
        }, (err) => {
            this.spinnerService.hide();
        });
    }

    subsribeCoinPairList(coin) {
        var self = this;
      self.coin = coin;
    //   console.log('coin',self.coin)
       
    let data = {
        messageType:'SUBSCRIBE_TICKER',
        params: {
            symbol: coin+'_'+self.baseCoin
        }
    }
   
    this.server.wsExchange.send(JSON.stringify(data));
    // console.log('exchange', JSON.parse(data));

    this.server.wsExchange.addEventListener('message', function (event) {
        var data = JSON.parse(event.data);
     
                if(data.messageType == 'TICKER_UPDATE') {
                        var exe = data.symbol.split('_')[0];
                        console.log('anshul this.exeCoin', self.coinPairListArr);
                        console.log('anshul this.exe', exe);
                        
                        let ind = self.coinPairListArr.findIndex((x) => x.coin == exe);
                        console.log('anshul index', ind)
                        if(ind != -1) {
                            self.coinPairListArr[ind]['volume'] = data.data.totalVolume;
                            self.coinPairListArr[ind]['average'] = data.data.volume24Hour;
                            self.coinPairListArr[ind]['last_price'] = data.data.lastPrice;
                        }
                   
        // this.coinPairListArr.push(event.data)
         }
       
    });
    
    // console.log('exchange', self.coinPairListArr);
}

    connectSocket() {
        if (this.coinListArr.length == 4) {
            this.getCoinSymbol(this.coinListArr);
            if (this.server.activatedSocket == "Binance") {
                this.callCoinListWithSocket(this.server.activatedSocket, 1);
                this.getLiquidityData();
                console.log('Binance')
            } else if (this.server.activatedSocket == "Poloniex") {
                // this.server.thirdPartySocket();
                this.getPoloniexTickerData();
                console.log('Polonix')
            } else if (this.server.activatedSocket == "HitBTC") {
                this.server.thirdPartySocket();
                this.startInterval(this.symbolArr)
                // this.getLiveDataFromHitBTCForCoinPair();
                console.log('hitbtc')
            }
        }
    }

    closeSocketFunc() {
        if (this.server.activatedSocket == "Binance") {
            this.server.liquidityWSTicker.forEach((element, i) => {
                this.server.liquidityWSTicker[i].close();
            });
            setInterval((x)=>{
                this.callCoinListWithSocket(this.server.activatedSocket, 1);
                this.getLiquidityData();
            },1000000)
        }

    }

    /** to get liquidity data */
    getLiquidityData() {
        console.log('index-->', this.baseCoin,this.exeCoin)
                       
        var self = this;
        this.server.fireToChild().subscribe(message => {

            if (message.text == "liquidity") {
                let len = this.server.liquidityWSTicker.length;
              
                for (let i = 0; i < len; i++) {
                    this.server.liquidityWSTicker[i].addEventListener('message', function (event) {
                        self.SocketDataStatus = true;
                        let data = JSON.parse(event.data);

                          console.log('anshul binance', event.data);
                        let str = data.s.replace(self.baseCoin, '');
                     
                        let indPair = self.coinPairListArr.findIndex(obj => obj.coin == str);
                       
                        if (indPair != -1) {
                            self.coinPairListArr[indPair].last_price = Number(data.o).toFixed(5);
                            self.coinPairListArr[indPair].volume = Number(data.v? data.v:data.totalVolume).toFixed(5);
                            self.coinPairListArr[indPair].max_price = Number(data.h).toFixed(5);
                            self.coinPairListArr[indPair].min_price = Number(data.l).toFixed(5);
                            self.coinPairListArr[indPair].average = ((Number(data.h) + Number(data.l)) / 2).toString();
                           
                        }
                        if (data.error) {
                            console.log('data error==>',data.error)
                            if (data.error.code == 2001) {
    
                                this.server.wsExchange.addEventListener('message', function (event) {
                                    console.log('exchange', JSON.parse(event.data));
                                });
    
                                self.SocketDataStatus = false;
                                /** Code to set coin pair list data as per selected pair */
                                let currPairArr = self.coinPairListArr.filter(obj => obj.coin == str);
                              
                                if (currPairArr.length) {
                                    self.coinPairListArr[indPair].last_price = 0.000000;
                                    self.coinPairListArr[indPair].volume = 0.000000;
                                    self.coinPairListArr[indPair].average = 0.000000;
                                }
                            }
                        }
                       
                       
                        // let indPair1 = self.coinListArr[1].findIndex(obj => obj.coinShortName == str);
                        // if (indPair1 != -1) {
                        //     self.coinListArr[indPair1].last_price = Number(data.o).toFixed(5);
                        //     self.coinListArr[indPair1].volume = Number(data.v).toFixed(5);
                        //     self.coinListArr[indPair].max_price = Number(data.h).toFixed(5);
                        //     self.coinListArr[indPair].min_price = Number(data.l).toFixed(5);
                        //     self.coinListArr[indPair1].average = ((Number(data.h) + Number(data.l)) / 2).toString();
                        // }
                        // let indPair2 = self.coinListArr[2].findIndex(obj => obj.coinShortName == str);
                        // if (indPair2 != -1) {
                        //     self.coinListArr[indPair2].last_price = Number(data.o).toFixed(5);
                        //     self.coinListArr[2].pairList[indPair2].volume = Number(data.v).toFixed(5);
                        //     self.coinListArr[0].max_price = Number(data.h).toFixed(5);
                        //     self.coinListArr[0].min_price = Number(data.l).toFixed(5);
                        //     self.coinListArr[2].pairList[indPair2].average = ((Number(data.h) + Number(data.l)) / 2).toString();
                        // }
                        // let indPair3 = self.coinListArr[3].findIndex(obj => obj.coinShortName == str);
                        // if (indPair3 != -1) {
                        //     self.coinListArr[indPair3].last_price = Number(data.o).toFixed(5);
                        //     self.coinListArr[indPair3].volume = Number(data.v).toFixed(5);
                        //     self.coinListArr[0].pairList[indPair].max_price = Number(data.h).toFixed(5);
                        //     self.coinListArr[0].pairList[indPair].min_price = Number(data.l).toFixed(5);
                        //     self.coinListArr[indPair3].average = ((Number(data.h) + Number(data.l)) / 2).toString();
                        // }
                    });
                    
                }
                this.server.liquidityWSTrade.addEventListener('message', function (event) {
                    self.SocketDataStatus = true;
                    let data = JSON.parse(event.data);
                     console.log('SEll==>',event.data)
                    if(data.m == true) {
                        data.m = 'BUY'
                    } else {
                        data.m = 'SELL'
                    }
                    self.tradeHistoryArr.push({
                        price: data.p,
                        amount: data.q,
                        total: (data.p*data.q),
                        time: data.T,
                        type: data.m
                    });
                    //self.tradeHistoryArr = self.functionToManageTradeHisOrder(self.tradeHistoryArr);
                    self.tradeHistoryArr = self.tradeHistoryArr.slice(0,50);
                });
                this.server.liquidityWSDepth.addEventListener('message', function (event) {
                    self.SocketDataStatus = true;
                    let data = JSON.parse(event.data);
                    data.bids.forEach(element => {
                        self.buyOrderArr.push({
                            price: element[0],
                            amount: element[1],
                            total: element[0]*element[1]
                        });
                        // self.buyOrderArr = self.functionToManageTradeHisOrder(self.buyOrderArr);
                        self.buyOrderArr = self.buyOrderArr.slice(0,50);
                    });
                    data.asks.forEach(element => {
                        self.sellOrderArr.push({
                            price: element[0],
                            amount: element[1],
                            total: element[0]*element[1]
                        });
                        // self.sellOrderArr = self.functionToManageTradeHisOrder(self.sellOrderArr);
                        self.sellOrderArr = self.sellOrderArr.slice(0,50);
                    });
                });
                console.log('SOCKET DATa==>',self.coinPairListArr)
                this.binanceSocket = setInterval((obj)=> { 
                    this.closeSocketFunc();
                },80000)
            } else if (message.text == "Poloniex") {
                let symbolArray = [];
                self.PoloArr.forEach(obj => {
                    this.symbolArr.forEach(element => {
                        if (element.coin == obj.pair) {
                            symbolArray.push({
                                pair: element,
                                id: obj.id
                            })
                        }
                    });
                });
                //this.callPolyneixSocket(1);
                this.server.liquidityWSPoloneix.addEventListener('message', function (event) {
                    self.SocketDataStatus = true;
                    let data = JSON.parse(event.data);
                    if (data.error == "Invalid channel") {
                        //self.callPolyneixSocket(2)
                        self.SocketDataStatus = false;
                    }
                    if (data.length > 2 && data[0] == 1002) {
                        let tickerArr = data[2];
                        symbolArray.forEach(obj => {
                            if (obj.id == tickerArr[0]) {
                                let arr = data[2];
                                let currPairArr = self.coinListArr.filter(ob => ob.coin == obj.pair.split('_')[1]);
                                currPairArr[0].pairList.last_price = arr[1];
                                currPairArr[0].pairList.volume = arr[5];
                                currPairArr[0].pairList.average = ((Number(arr[8]) + Number(arr[9])) / 2).toString();
                            }
                        });

                    }
                    if (data[0] == 1010) {
                        self.SocketDataStatus = false;
                    }
                })
            } else if (message.text == "HitBTC") {
                this.updateLiquiditySocket(1);
                this.server.liquidityWSHitBTC.addEventListener('message', function (event) {
                    let data = JSON.parse(event.data);
                    if (data.params) {
                        self.SocketDataStatus = true;
                        switch (data.method) {
                            case "ticker":
                                /** Code to set coin pair list data as per selected pair */
                                let currPairArr = self.coinPairListArr.filter(obj => obj.coin == self.currentPairCoinObj.coinShort);
                                if (currPairArr.length) {
                                    currPairArr[0].pairList.last_price = data.params.last;
                                    currPairArr[0].pairList.volume = data.params.volume;
                                    currPairArr[0].pairList.average = ((Number(data.params.high) + Number(data.params.high)) / 2).toString();
                                }

                                break;
                        }
                    }
                    if (data.error) {
                        console.log('data error==>',data.error)
                        if (data.error.code == 2001) {

                            this.server.wsExchange.addEventListener('message', function (event) {
                                console.log('exchange', JSON.parse(event.data));
                            });

                            self.SocketDataStatus = false;
                            /** Code to set coin pair list data as per selected pair */
                            let currPairArr = self.coinPairListArr.filter(obj => obj.coin == self.currentPairCoinObj.coinShort);
                          
                            if (currPairArr.length) {
                                currPairArr[0].last_price = 0.000000;
                                currPairArr[0].volume = 0.000000;
                                currPairArr[0].average = 0.000000;
                            }
                        }
                    }
                    
                });
            }
          
        });
    }

    toUpperCaseFunc(str) {
        return str.toUpperCase();
    }

    goToMarket(base, exe) {
        this.router.navigateByUrl('header/exchange/' + base + '/' + exe);
    }

    poloTradeHistory() {
        if(this.server.activatedSocket == "Poloniex") {
            this.const = setTimeout(()=>{
                this.tradeHistoryArr = [];
                this.server.thirdpartyGetApi('https://poloniex.com/public?command=returnTradeHistory&currencyPair='+this.poloniexTradePair).subscribe((res) => {
                    if(!res.error) {
                        res.forEach(element => {
                            let obj = {
                                price: element.rate,
                                amount: element.amount,
                                total: (element.rate*element.amount),
                                time: element.date,
                                type: element.type
                            }
                            this.tradeHistoryArr.push(obj)
                        });
                    } else{
                        clearTimeout(this.const)
                        this.tradeHistoryArr =[]
                    }
                })
            this.poloTradeHistory()
            },50000)
        }
       
    }

    

    /** Function to fetch coin symbol */
    getCoinSymbol(arr) {
        console.log('arr==>',arr)
        console.log('activesocket--------->',this.server.activatedSocket)
        this.arr = arr;
        this.symbolArr = [];
        if (this.server.activatedSocket == "Poloniex") {
            arr.forEach((obj) => {
            
            
                    this.symbolArr.push(obj.coin + '_' + (obj.coin == 'ECH' ? "ETC" : obj.coin));
               
            });
            return this.symbolArr;
        } else if (this.server.activatedSocket == "Binance") {
            arr.forEach((obj) => {
            
                    this.symbolArr.push((obj.coin == 'ECH' ? "ETC" : obj.coin) + this.baseCoin);
               
                
            });
           
            return this.symbolArr;
        } else {
            arr.forEach((obj) => {
            
                    if (obj.coin == "USD") {
                        if (obj.coin == "XRP") {
                            this.symbolArr.push('symbolArr',obj.coin + "USDT");
                        } else {
                            this.symbolArr.push('symbolArr',obj.coin + obj.coin);
                        }
                    } else {
                        this.symbolArr.push(obj.coin + obj.coin);
                    }
                });
           
                console.log('coinsymbol====>>>',this.symbolArr)
            return this.symbolArr;
        }
      
    }

    /** for polyneix socket */
    callPolyneixSocket(type) {
        let data = {
            "command": "",
            "channel": 1002
        }
        switch (type) {
            case 1:
                data.command = "subscribe";
                this.server.liquidityWSPoloneix.send(JSON.stringify(data));
                break;
            case 2:
                data.command = "unsubscribe";
                this.server.liquidityWSPoloneix.send(JSON.stringify(data));
                break;
        }
    }
  /** for poloneix ticker */
  callPoloTrade(type) {
    let data = {
        "command": "",
        "channel": this.poloniexTradePair
    }
    switch(type) {
        case 1: 
            data.command = "subscribe"
            this.server.liquidityWSPoloneix.send(JSON.stringify(data));
            break;
        case 2:
            data.command = "unsubscribe"
            this.server.liquidityWSPoloneix.send(JSON.stringify(data));
            break;
    }
}
    

    /** Function for socket subscribe/unsubcribe */
    updateLiquiditySocket(type) {
        let data = {
            "method": "",
            "params": {
                "symbol": this.HitBTCPair,
                "limit": ""
            },
            "id": ""
        }
        switch (type) {
            case 1:
                if (this.server.liquidityWSHitBTC.readyState) {
                    data.method = "subscribeTicker";
                    this.server.liquidityWSHitBTC.send(JSON.stringify(data));
                }

                break;
            case 2:
                if (this.server.liquidityWSHitBTC.readyState) {
                    data.method = "unsubscribeTicker";
                    this.server.liquidityWSHitBTC.send(JSON.stringify(data));
                }
                break;
        }
    }

    callCoinListWithSocket(msg, type) {
        console.log('callcoinsocketwork==>',msg, type)
        switch(msg) {
            case 'Binance' : 
                switch(type) {
                    case 1 :
                        let i = 0;
                        console.log('callcoinsocketwork==>', this.symbolArr)
                        this.symbolArr.forEach(element => {
                            element = element.toLowerCase();
                            this.server.binanceTickerFunc(element,i);
                            i++;
                        }); 
                        break;
                    case 2: 
                        this.server.liquidityWSTicker.close();
                        break;
                }
                break;
            case 'Poloniex' : 
                let data = {
                    "command": "",
                    "channel": 1002
                }
                switch(type) {
                    case 1 :
                        data.command = "subscribe"
                        this.server.liquidityWSPoloneix.send(JSON.stringify(data));
                        break;
                    case 2: 
                        data.command = "unsubscribe"
                        this.server.liquidityWSPoloneix.send(JSON.stringify(data));
                        break;
                }
                break;
            case 'HitBTC' : 
                this.symbolArr.forEach(element => {
                    let data1 = {
                        "method": "",
                        "params": {
                            "symbol": element,
                            "limit": ""
                        },
                        "id": ""
                    }
                    switch(type) {
                        case 1 :
                            if(this.server.liquidityWSHitBTC.readyState) {
                                data1.method = "subscribeTicker";
                                this.server.liquidityWSHitBTC.send(JSON.stringify(data));
                            }  
                            break;
                        case 2: 
                            if(this.server.liquidityWSHitBTC.readyState) {                    
                                data1.method = "unsubscribeTicker";
                                this.server.liquidityWSHitBTC.send(JSON.stringify(data));                   
                            }       
                            break;
                    }
                });
                break;
        }
        console.log('callcoinsocketwork==>', this.symbolArr)

    }

    /** Function to get live data for other pair */
    getLiveDataFromHitBTCForCoinPair() {
        this.server.getHitBTCTickerDataJson().subscribe((res) => {
            // console.log(res);
        })
        this.startInterval(this.symbolArr)
    }

    /** Function to start interval for getting latest value for pair */
    startInterval(symbolArr) {
        this.hitbtcIntervalID = setInterval((obj) => {
            let data = {
                "url": "https://api.hitbtc.com/api/2/public/ticker",
                "symbols": symbolArr
            }
           
            this.server.postApi("wallet/coin/get-live-market-data",data, localStorage.getItem('token')).subscribe((succ) => {
                 if(succ.status == 200) {
                    // this.coinListArr.forEach((obj) => {
                    //     var ind = succ.body.data.findIndex((data) => data.symbol.substring(0,3) == obj.coinShortName);
                    //     if(ind != -1) {
                    //         obj.last_price = succ.body.data[ind].last;
                    //         obj.volume = succ.body.data[ind].volume;
                    //         obj.average = (Number(succ.body.data[ind].low) + Number(succ.body.data[ind].high))/2;
                    //     }
                    // });
                } else {
                    this.appC.showErrToast(succ.message);
                }
            }, (err) => {
                this.appC.showErrToast(err.error.message);
            });
        }, 10000);
    }

    /** Function to stop interval for getting latest value for pair */
    stopInterval() {
        clearInterval(this.hitbtcIntervalID);
    } 
    /**to call on destroy */
    ngOnDestroy() {
        if (this.server.activatedSocket == "Binance") {
            // this.server.liquidityWSTicker.forEach((element, i) => {
            //     this.server.liquidityWSTicker[i].close();
            // });
            this.server.liquidityWS.close();
            this.server.liquidityWSTrade.close();
            this.server.liquidityWSDepth.close();

        }
    else if(this.server.activatedSocket == "Poloniex") {
        clearTimeout(this.const);
    } else if(this.server.activatedSocket == "HitBTC") {
        clearInterval(this.hitbtcIntervalID);
    }
        clearInterval(this.clearInt);
        clearInterval(this.binanceSocket);
    }

    /**Function to get poloniex ticker data */
    getPoloniexTickerData() {
        this.server.getPoloniexTickerDataJson().subscribe((res) => {
            this.coinListArr.forEach(element => {
                element.pairList.forEach(obj => {
                    for(var key in res) {
                        if(key == element.coinShortName+'_'+obj.coinShortName) {
                            obj.last_price = Number(res[key].last).toFixed(5);
                            obj.volume = Number(res[key].quoteVolume).toFixed(5);
                            obj.max_price = Number(res[key].high24hr).toFixed(5);
                            obj.min_price = Number(res[key].low24hr).toFixed(5);
                            obj.average = ((Number(res[key].high24hr) + Number(res[key].low24hr)) / 2).toString();
                        }
                    }
                });
            });
        });
        // console.log('coinpair--->',this.coinListArr)
    }

/** Function for coin change */
coinChangeFunc(value) {
    if(value!= this.exeCoin)
    {
        
    this.baseCoin=value
    this.router.navigateByUrl('header/exchange/'+value+'/'+this.exeCoin)
    this.getCoinPair(value);
   
    // this.getCoinListExchange()
    this.clearMarketBuyObj();
    this.clearMarketSellObj();
    this.clearLimitBuyObj();
    this.clearLimitSellObj();
    if (this.server.activatedSocket == "Binance") {
        this.server.liquidityWS.close();
        this.server.liquidityWSTrade.close();
        this.server.liquidityWSDepth.close();
        this.SocketDataStatus = false;
      
    }
    if (this.server.activatedSocket == "Poloniex") {
        this.callPolyneixSocket(2)
        this.callPoloTrade(2)
    }
    if (this.server.activatedSocket == 'HitBTC') {
        this.updateLiquiditySocket(2);
        this.stopInterval();
        // this.getLiveDataFromHitBTCForCoinPair();
    }
    this.searchText = "";
    this.currentCoinObj.coinId = this.coinListArr.filter((x) => x.coinShortName == this.baseCoin)[0].coinId;
    this.currentCoinObj.coinShort = this.coinListArr.filter((x) => x.coinShortName == this.baseCoin)[0].coinShortName;
    this.currentCoinObj.coinFullName = this.coinListArr.filter((x) => x.coinShortName == this.baseCoin)[0].coinFullName;
    this.coinPairListArr = [];
//  console.log('COIN DATA==>',this.currentCoinObj, this.coinListArr)
    // this.updateLiquiditySocket(2);
    this.getCoinPairOnCoinChange();
}
else{
    this.appC.showErrToast("Please select corect pair");
   
}
}

  /** Function to get coin pair list from api*/
  getCoinPairOnCoinChange() {

    this.coinPairListArr = [];
 
    // this.spinnerService.show();
    // this.server.getApi('wallet/coin/get-coin-pair-list?baseCoin=' + this.baseCoin, 0).subscribe((succ) => {
    //     this.spinnerService.hide();
    //     if(succ.status == 200) {
    //         this.coinPairListArr = [];
    //         // let data = succ.transferObjectMap.coinPairList;
    //         let data = [];
    //         succ.body.data.forEach(obj => {
    //             if(obj.coinShortName == 'BTC'|| obj.coinShortName == 'ETH'|| obj.coinShortName == 'XRP'|| obj.coinShortName == 'BCH'|| obj.coinShortName == 'XLM'|| obj.coinShortName == 'LTC'|| obj.coinShortName == 'IOTA' || obj.coinShortName == 'USDT' || obj.coinShortName == 'XVG'|| obj.coinShortName == 'IPR' || obj.coinShortName == 'ECH') {
    //                 data.push(obj);
    //             }
    //         });
    //         data.forEach(obj => {
    //             this.coinPairListArr.push({
    //                 coinID: obj.coinId,
    //                 coin: obj.coinShortName,
    //                 coinFullName: obj.coinFullName,
    //                 volume: obj.volume,
    //                 average: obj.average,
    //                 last_price: ''
    //             });
    //         });
    //         // let cPairListArr = succ.transferObjectMap.coinLastPairList;
    //         this.symbolArr = this.getCoinSymbol(this.coinPairListArr);
    //         // this.coinPairListArr.forEach((obj) => {
    //         //     obj.last_price = cPairListArr.filter((x) => x.coinShortName == obj.coin)[0].LAST_PRICE;
    //         //     obj.selected = false;
    //         // });
    //         if(this.coinPairListArr.length) {
    //             this.currentPairCoinObj.coinShort = this.coinPairListArr[0].coin;
    //             this.currentPairCoinObj.coinId = this.coinPairListArr[0].coinID;
    //             this.currentPairCoinObj.coinFullName = this.coinPairListArr[0].coinFullName;
    //             this.coinPairListArr[0].selected = true;
    //             this.tradeViewPair = this.currentCoinObj.coinShort+"/"+this.currentPairCoinObj.coinShort;
    //             this.HitBTCPair = this.currentPairCoinObj.coinShort+this.currentCoinObj.coinShort;
    //             if(this.feeListApi) {
    //                 let ind = this.feeList.findIndex(x => x.coinShortName == this.currentPairCoinObj.coinShort);
    //                 this.takerFee = this.feeList[ind].takerFee;
    //                 this.makerFee = this.feeList[ind].makerFee;
    //             }
                
    //             /** for binance socket */
    //             if(this.server.activatedSocket == "Binance") {
    //                 this.server.pair = this.currentPairCoinObj.coinShort + this.currentCoinObj.coinShort
    //                 this.server.pair = this.server.pair.toLowerCase();
    //                 this.server.thirdPartySocket();   
    //                 this.callCoinListWithSocket(this.server.activatedSocket,1);
    //             } else if(this.server.activatedSocket == "Poloniex") {
    //                 this.poloniexTradePair = this.currentCoinObj.coinShort+"_"+this.currentPairCoinObj.coinShort;
    //                 this.server.thirdPartySocket();
    //                 //this.callCoinListWithSocket(this.server.activatedSocket,1);
    //             } else if(this.server.activatedSocket == "HitBTC") {
    //                 this.server.thirdPartySocket();
    //                 this.getLiveDataFromHitBTCForCoinPair();
    //                 //this.callCoinListWithSocket(this.server.activatedSocket,1);
    //             }
                
    //             this.getTradeHistory();
    //             this.getSellOrder();
    //             this.getBuyOrder();
    //             this.drawTradingChart();
    //             this.getHeaderPrice();
    //             if(localStorage.getItem("token")) {
    //                 this.getUserBaseCoinBalance();
    //                 this.getUserPairCoinBalance();
    //                 this.getUserOpenOrder();
    //                 this.getUserOrderHistory();
    //             }
              
    //         }
    //     } else {
    //         this.coinPairListArr = [];
    //         this.appC.showErrToast(succ.message);
    //     }
    // }, (err) => {
    //     this.spinnerService.hide();
    // });
    
}



/** Function for select coin pair */
selectPair(data) {
    this.exeCoin=data.coin
    this.router.navigateByUrl('header/exchange/'+this.baseCoin+'/'+ this.exeCoin)
    this.clearMarketBuyObj();
    this.clearMarketSellObj();
    this.clearLimitBuyObj();
    this.clearLimitSellObj();
    if(this.server.activatedSocket == "Binance") {
        this.SocketDataStatus = false;
    }
    data.selected = true;
    this.currentPairCoinObj.coinId = data.coinID;
    this.currentPairCoinObj.coinShort = data.coin;
    this.currentPairCoinObj.coinFullName = data.coinFullName;
    if(this.feeListApi) {
        let ind = this.feeList.findIndex(x => x.coinShortName == this.currentPairCoinObj.coinShort);
        this.takerFee = this.feeList[ind].takerFee;
        this.makerFee = this.feeList[ind].makerFee;
    }
    this.tradeViewPair = this.currentCoinObj.coinShort+"/"+this.exeCoin;
    if(this.server.activatedSocket == "Binance") {
        this.server.liquidityWS.close();
        this.server.liquidityWSTrade.close();
        this.server.liquidityWSDepth.close();
        this.server.pair = this.currentPairCoinObj.coinShort + this.currentCoinObj.coinShort;
        this.server.pair = this.server.pair.toLowerCase();   
        this.server.thirdPartySocket()
    } else if(this.server.activatedSocket == "Poloniex") {
        //this.callPolyneixSocket(2)
        //this.callPoloTrade(2);
        this.poloniexTradePair = this.currentCoinObj.coinShort+"_"+this.currentPairCoinObj.coinShort;
        this.server.thirdPartySocket();
    } else if(this.server.activatedSocket == "HitBTC") {
        //this.updateLiquiditySocket(2);
        this.HitBTCPair = this.currentPairCoinObj.coinShort+this.currentCoinObj.coinShort;
        this.server.thirdPartySocket();
        // this.stopInterval();
        // this.getLiveDataFromHitBTCForCoinPair(this.getCoinSymbol(this.coinPairListArr));
    }
    this.coinPairListArr.forEach((obj) => {
        if(data.coinID != obj.coinID) {
            obj.selected = false;
        }
    });
    if(this.feeListApi) {
        let ind = this.feeList.findIndex(x => x.coinShortName == this.currentPairCoinObj.coinShort);
        this.takerFee = this.feeList[ind].takerFee;
        this.makerFee = this.feeList[ind].makerFee;
    }
    this.getTradeHistory();
    this.getSellOrder();
    this.getBuyOrder();
    this.drawTradingChart();
    this.getHeaderPrice();
    if(localStorage.getItem("token")) {
        this.getUserPairCoinBalance();
        this.getUserOpenOrder();
        this.getUserOrderHistory();
    }
}


/** Function to get trade/Market history */
getTradeHistory() {
    this.tradeHistoryArr = [];
   
    this.spinnerService.show();
    this.server.getApi('order-service-eth_btc/trade-history?size='+1+'&symbol='+this.baseCoin+'_'+this.exeCoin,localStorage.getItem('token')).subscribe((succ) => {
        this.spinnerService.hide();
        if(succ.status == 200) {
            succ.body.data.forEach((obj) => {
                this.tradeHistoryArr.push({
                    price: obj.price.toFixed(8),
                    amount: obj.amount.toFixed(8),
                    total: (obj.price*obj.amount).toFixed(8),
                    time: obj.time,
                    side: obj.side
                });
            });
        } else {
            this.appC.showErrToast(succ.message);
        }
    }, (err) => {
        this.spinnerService.hide();
    });
}


 /** Function for modify coin pair list after trade execute */
 getCoinPairAfterExecution() {
    let data = {
                      "baseCurrency": this.currentCoinObj.coinId
          
         }
         this.server.getApi('wallet/coin/get-coin-pair-list?baseCoin=' + this.baseCoin, 0).subscribe((succ) => {

        // if(succ.status == 200) {
        //     let data = succ.transferObjectMap.coinPairList;
        //     let cPairListArr = succ.transferObjectMap.coinLastPairList;
        //     data.forEach((obj) => {
        //         let ind = this.coinPairListArr.findIndex((x) => x.coinID == obj.coin_id);
        //         if(ind != -1) {
        //             this.coinPairListArr[ind].volume = obj.volume;
        //             this.coinPairListArr[ind].average = obj.average;
        //         }
        //     });
        //     cPairListArr.forEach((obj) => {
        //         let ind = this.coinPairListArr.findIndex((x) => x.coin == obj.COIN_SHORT_NAME);
        //         if(ind != -1) {
        //             this.coinPairListArr[ind].last_price = obj.LAST_PRICE;
        //         }
        //     });
        // }
    }, (err) => {
    });
}


 /** Function for buy/sell tab click */
 tabClick(type) {
    this.currTab = type;
}

getUserBaseCoinBalance() {
  
    this.server.getApi("wallet/wallet/get-balance?coinName="+this.baseCoin,localStorage.getItem('token')).subscribe((succ) => {
        if(succ.status == 200) {
            this.userData.baseCoinBal = succ.body.data.walletBalance;
        } else if(succ.status == 403) {
            this.header.logOut();
        } else {
            this.appC.showErrToast(succ.message);
        }
    }, (err) => {
    });
}

  /** Function for getting user balance of selected coin */
  getUserPairCoinBalance() {
   
    this.server.getApi("wallet/wallet/get-balance?coinName="+this.exeCoin,localStorage.getItem('token')).subscribe((succ) => {
        if(succ.status == 200) {
            this.userData.pairCoinBal = succ.body.data.walletBalance;
        } else if(succ.statusCode == 403) {
            this.header.logOut();
        } else {
            this.appC.showErrToast(succ.message);
        }
    }, (err) => {
    });
}


/** Function to restrict space */
restrictSpace(event) {
    var k = event.charCode;
    if (k === 32) return false;
}

/** Function to restrict character */
restrictChar(event) {
    var k = event.charCode;
    if (event.key === 'Backspace')
        k = 8;
    if (k >= 48 && k <= 57 || k == 8 || k == 46)
        return true;
    else
        return false;    
}

/** Function to restrict length after dot */
restrictLength(type) {
    switch(type) {
        case 'lbp':
            if(this.limitBuyObj.price.includes(".")) {
                if (!this.regexForEightChar.test(this.limitBuyObj.price)) {
                    let tempVal = this.limitBuyObj.price.split('.');
                    this.limitBuyObj.price = tempVal[0] + '.' + tempVal[1].slice(0, 8);
                }
            }
            break;
        case 'lba':
            if(this.limitBuyObj.amount.includes(".")) {
                if (!this.regexForEightChar.test(this.limitBuyObj.amount)) {
                    let tempVal = this.limitBuyObj.amount.split('.');
                    this.limitBuyObj.amount = tempVal[0] + '.' + tempVal[1].slice(0, 8);
                }
            }
            break;
        case 'lsp':
            if(this.limitSellObj.price.includes(".")) {
                if (!this.regexForEightChar.test(this.limitSellObj.price)) {
                    let tempVal = this.limitSellObj.price.split('.');
                    this.limitSellObj.price = tempVal[0] + '.' + tempVal[1].slice(0, 8);
                }
            }
            break;
        case 'lsa':
            if(this.limitSellObj.amount.includes(".")) {
                if (!this.regexForEightChar.test(this.limitSellObj.amount)) {
                    let tempVal = this.limitSellObj.amount.split('.');
                    this.limitSellObj.amount = tempVal[0] + '.' + tempVal[1].slice(0, 8);
                }
            }
            break;
        case 'mba':
            if(this.marketBuyObj.amount.includes(".")) {
                if (!this.regexForEightChar.test(this.marketBuyObj.amount)) {
                    let tempVal = this.marketBuyObj.amount.split('.');
                    this.marketBuyObj.amount = tempVal[0] + '.' + tempVal[1].slice(0, 8);
                }
            }
            break;
        case 'msa':
            if(this.marketSellObj.amount.includes(".")) {
                if (!this.regexForEightChar.test(this.marketSellObj.amount)) {
                    let tempVal = this.marketSellObj.amount.split('.');
                    this.marketSellObj.amount = tempVal[0] + '.' + tempVal[1].slice(0, 8);
                }
            }
            break;
        case 'sbs':
            if(this.sLimitBuyObj.stop.includes(".")) {
                if (!this.regexForEightChar.test(this.sLimitBuyObj.stop)) {
                    let tempVal = this.sLimitBuyObj.stop.split('.');
                    this.sLimitBuyObj.stop = tempVal[0] + '.' + tempVal[1].slice(0, 8);
                }
            }
            break;
        case 'sbp':
            if(this.sLimitBuyObj.price.includes(".")) {
                if (!this.regexForEightChar.test(this.sLimitBuyObj.price)) {
                    let tempVal = this.sLimitBuyObj.price.split('.');
                    this.sLimitBuyObj.price = tempVal[0] + '.' + tempVal[1].slice(0, 8);
                }
            }
            break;
        case 'sba':
            if(this.sLimitBuyObj.amount.includes(".")) {
                if (!this.regexForEightChar.test(this.sLimitBuyObj.amount)) {
                    let tempVal = this.sLimitBuyObj.amount.split('.');
                    this.sLimitBuyObj.amount = tempVal[0] + '.' + tempVal[1].slice(0, 8);
                }
            }
            break;
        case 'sss':
            if(this.sLimitSellObj.stop.includes(".")) {
                if (!this.regexForEightChar.test(this.sLimitSellObj.stop)) {
                    let tempVal = this.sLimitSellObj.stop.split('.');
                    this.sLimitSellObj.stop = tempVal[0] + '.' + tempVal[1].slice(0, 8);
                }
            }
            break;
        case 'ssp':
            if(this.sLimitSellObj.price.includes(".")) {
                if (!this.regexForEightChar.test(this.sLimitSellObj.price)) {
                    let tempVal = this.sLimitSellObj.price.split('.');
                    this.sLimitSellObj.price = tempVal[0] + '.' + tempVal[1].slice(0, 8);
                }
            }
            break;
        case 'ssa':
            if(this.sLimitSellObj.amount.includes(".")) {
                if (!this.regexForEightChar.test(this.sLimitSellObj.amount)) {
                    let tempVal = this.sLimitSellObj.amount.split('.');
                    this.sLimitSellObj.amount = tempVal[0] + '.' + tempVal[1].slice(0, 8);
                }
            }
            break;
    }
}

/** Function to calculate total amount */
valueChangeFunc(type) {
    if(type == "LBP" || type == "LBA") {
        if(this.limitBuyObj.amount && this.limitBuyObj.price && Number(this.limitBuyObj.amount) >= 0 && Number(this.limitBuyObj.price) >= 0) {
            this.limitBuyObj.total = (Number(this.limitBuyObj.amount) * Number(this.limitBuyObj.price)).toFixed(8);
        } else {
            this.limitBuyObj.total = "";
        }
    }
    if(type == "SBP" || type == "SBA") {
        if(this.sLimitBuyObj.price && this.sLimitBuyObj.amount && Number(this.sLimitBuyObj.price) >= 0 && Number(this.sLimitBuyObj.amount) >= 0) {
            this.sLimitBuyObj.total = (Number(this.sLimitBuyObj.price) * Number(this.sLimitBuyObj.amount)).toFixed(8);
        } else {
            this.sLimitBuyObj.total = "";
        }
    }
    if(type == "LSP" || type == "LSA") {
        if(this.limitSellObj.amount && this.limitSellObj.price && Number(this.limitSellObj.amount) >= 0 && Number(this.limitSellObj.price) >= 0) {
            this.limitSellObj.total = (Number(this.limitSellObj.amount) * Number(this.limitSellObj.price)).toFixed(8);
        } else {
            this.limitSellObj.total = "";
        }
    }        
    if(type == "SSP" || type == "SSA") {
        if(this.sLimitSellObj.price && this.sLimitSellObj.amount && Number(this.sLimitSellObj.price) >= 0 && Number(this.sLimitSellObj.amount) >= 0) {
            this.sLimitSellObj.total = (Number(this.sLimitSellObj.price) * Number(this.sLimitSellObj.amount)).toFixed(8);
        } else {
            this.sLimitSellObj.total = "";
        }
    }
}

checkKycStatus(val) {
if(val == 1) {
 switch(this.buyOrderType) {
    case 'LIMIT':
    if(this.limitBuyObj.price == "") {
        this.appC.showErrToast("Enter price value.");
        return;
    } else if(this.limitBuyObj.price == ".") {
        this.appC.showErrToast("Enter valid price value.");
        return;
    } else if(Number(this.limitBuyObj.price) <= 0) {
        this.appC.showErrToast("Enter valid price value.");
        return;
    } else if(this.limitBuyObj.amount == "") {
        this.appC.showErrToast("Enter amount value.");
        return;
    } else if(this.limitBuyObj.amount == ".") {
        this.appC.showErrToast("Enter valid amount value.");
        return;
    } else if(Number(this.limitBuyObj.amount) <= 0) {
        this.appC.showErrToast("Enter valid amount value.");
        return;
    } else if(Number(this.limitBuyObj.total) > Number(this.userData.baseCoinBal)){
        this.appC.showErrToast("You can't buy coins more than your wallet amount.");
        return;    
   
                   
            } else {
            
    
                this.kyc = [];
                let kycDetails = {
        
                    "token": localStorage.getItem('token')
                }
        
                this.spinnerService.show();
                this.server.getApi('account/get-kyc-details', localStorage.getItem('token')).subscribe(response => {
                    this.spinnerService.hide();
                    if (response.body.status == 200) {
                      
                        // console.log('KYC-->', response.body)
                        this.kyc = response.body.data
                        if (response.body.document == "undefined") {
                            this.appC.showInfoToast("To get the functionalities of the Bittnomy exchange you need to get your kyc done");
                        } else if (this.kyc.kycStatus == 'ACCEPTED' ) {
                            // console.log("KYC Done-->")
                            this.checkyc = true;
                            this.buyFunc();
                        }
                        else if (this.kyc.kycStatus == null){
                            this.appC.showInfoToast('KYC verification is required to withdraw amount.');
                        }
        
                    } else {
                        this.appC.showErrToast(response.body.message);
                    }
                }, error => {
                    this.appC.showErrToast(error.error.message);
                    this.spinnerService.hide();
                });

             
           

        }
         break;
                case 'MARKET':
                    if(this.marketBuyObj.amount == "") {
                        this.appC.showErrToast("Enter amount value.");
                        return;
                    } else if(this.marketBuyObj.amount == ".") {
                        this.appC.showErrToast("Enter valid amount value.");
                        return;
                    } else if(Number(this.marketBuyObj.amount) <= 0) {
                        this.appC.showErrToast("Enter valid amount value.");
                        return;
                    } else {
                        this.kyc = [];
                let kycDetails = {
        
                    "token": localStorage.getItem('token')
                }
        
                this.spinnerService.show();
                this.server.getApi('account/get-kyc-details', localStorage.getItem('token')).subscribe(response => {
                    this.spinnerService.hide();
                    if (response.body.status == 200) {
                      
                        // console.log('KYC-->', response.body)
                        this.kyc = response.body.data
                        if (response.body.document == "undefined") {
                            this.appC.showInfoToast("To get the functionalities of the Bittnomy exchange you need to get your kyc done");
                        } else if (this.kyc.kycStatus == 'ACCEPTED' ) {
                            // console.log("KYC Done-->")
                            this.checkyc = true;
                            this.buyFunc();
                        }
                        else if (this.kyc.kycStatus == null){
                            this.appC.showInfoToast('KYC verification is required to withdraw amount.');
                        }
        
                    } else {
                        this.appC.showErrToast(response.body.message);
                    }
                }, error => {
                    this.appC.showErrToast(error.error.message);
                    this.spinnerService.hide();
                });

                        } 
                    break;
                  case 'STOPLIMIT':
                    if(this.sLimitBuyObj.stop == "") {
                        this.appC.showErrToast("Enter stop value.");
                        return;
                    } else if(this.sLimitBuyObj.stop == ".") {
                        this.appC.showErrToast("Enter valid stop value.");
                        return;
                    } else if(Number(this.sLimitBuyObj.stop) <= 0) {
                        this.appC.showErrToast("Enter valid stop value.");
                        return;
                    } else if(this.sLimitBuyObj.price == "") {
                        this.appC.showErrToast("Enter limit value.");
                        return;
                    } else if(this.sLimitBuyObj.price == ".") {
                        this.appC.showErrToast("Enter valid limit value.");
                        return;
                    } else if(Number(this.sLimitBuyObj.price) <= 0) {
                        this.appC.showErrToast("Enter valid limit value.");
                        return;
                    } else if(this.sLimitBuyObj.amount == "") {
                        this.appC.showErrToast("Enter amount value.");
                        return;
                    } else if(this.sLimitBuyObj.amount == ".") {
                        this.appC.showErrToast("Enter valid amount value.");
                        return;
                    } else if(Number(this.sLimitBuyObj.amount) <= 0) {
                        this.appC.showErrToast("Enter valid amount value.");
                        return;
                    } else if(Number(this.sLimitBuyObj.total) > Number(this.userData.baseCoinBal)){
                        this.appC.showErrToast("You can't buy coins more than your wallet amount.");
                        return;
                    } else {
                      this.kyc = [];
                  let kycDetails = {
        
                    "token": localStorage.getItem('token')
                   }
        
                this.spinnerService.show();
                this.server.getApi('account/get-kyc-details', localStorage.getItem('token')).subscribe(response => {
                    this.spinnerService.hide();
                    if (response.body.status == 200) {
                      
                        // console.log('KYC-->', response.body)
                        this.kyc = response.body.data
                        if (response.body.document == "undefined") {
                            this.appC.showInfoToast("To get the functionalities of the Bittnomy exchange you need to get your kyc done");
                        } else if (this.kyc.kycStatus == 'ACCEPTED' ) {
                            // console.log("KYC Done-->")
                            this.checkyc = true;
                            this.buyFunc();
                        }
                        else if (this.kyc.kycStatus == null){
                            this.appC.showInfoToast('KYC verification is required to withdraw amount.');
                        }
        
                    } else {
                        this.appC.showErrToast(response.body.message);
                    }
                }, error => {
                    this.appC.showErrToast(error.error.message);
                    this.spinnerService.hide();
                });
                } 
             break;

    } 
} 
else if(val == 2) {
            switch(this.sellOrderType) {
                case 'LIMIT':
                    if(this.limitSellObj.price == "") {
                        this.appC.showErrToast("Enter price value.");
                        return;
                    } else if(this.limitSellObj.price == ".") {
                        this.appC.showErrToast("Enter valid price value.");
                        return;
                    } else if(Number(this.limitSellObj.price) <= 0) {
                        this.appC.showErrToast("Enter valid price value.");
                        return;
                    } else if(this.limitSellObj.amount == "") {
                        this.appC.showErrToast("Enter amount value.");
                        return;
                    } else if(this.limitSellObj.amount == ".") {
                        this.appC.showErrToast("Enter valid amount value.");
                        return;
                    } else if(Number(this.limitSellObj.amount) <= 0) {
                        this.appC.showErrToast("Enter valid amount value.");
                        return;
                    } else if(Number(this.limitSellObj.amount) > Number(this.userData.pairCoinBal)){
                        this.appC.showErrToast("You can't sell coins more than your wallet amount.");
                        return;
                    } else {
                         this.kyc = [];
                let kycDetails = {
        
                    "token": localStorage.getItem('token')
                }
        
                this.spinnerService.show();
                this.server.getApi('account/get-kyc-details', localStorage.getItem('token')).subscribe(response => {
                    this.spinnerService.hide();
                    if (response.body.status == 200) {
                      
                        // console.log('KYC-->', response.body)
                        this.kyc = response.body.data
                        if (response.body.document == "undefined") {
                            this.appC.showInfoToast("To get the functionalities of the Bittnomy exchange you need to get your kyc done");
                        } else if (this.kyc.kycStatus == 'ACCEPTED' ) {
                            // console.log("KYC Done-->")
                            this.checkyc = true;
                            this.sellFunc();
                        }
                        else if (this.kyc.kycStatus == null){
                            this.appC.showInfoToast('KYC verification is required to withdraw amount.');
                        }
        
                    } else {
                        this.appC.showErrToast(response.body.message);
                    }
                }, error => {
                    this.appC.showErrToast(error.error.message);
                    this.spinnerService.hide();
                });
                    }
                        break;
                case 'MARKET':
                    if(this.marketSellObj.amount == "") {
                        this.appC.showErrToast("Enter amount value.");
                        return;
                    } else if(this.marketSellObj.amount == ".") {
                        this.appC.showErrToast("Enter valid amount value.");
                        return;
                    } else if(Number(this.marketSellObj.amount) <= 0) {
                        this.appC.showErrToast("Enter valid amount value.");
                        return;
                    } else if(Number(this.marketSellObj.amount) > Number(this.userData.pairCoinBal)) {
                        this.appC.showErrToast("You can't sell coins more than your wallet amount.");
                        return;
                    } else {
                         this.kyc = [];
                let kycDetails = {
        
                    "token": localStorage.getItem('token')
                }
        
                this.spinnerService.show();
                this.server.getApi('account/get-kyc-details', localStorage.getItem('token')).subscribe(response => {
                    this.spinnerService.hide();
                    if (response.body.status == 200) {
                      
                        // console.log('KYC-->', response.body)
                        this.kyc = response.body.data
                        if (response.body.document == "undefined") {
                            this.appC.showInfoToast("To get the functionalities of the Bittnomy exchange you need to get your kyc done");
                        } else if (this.kyc.kycStatus == 'ACCEPTED' ) {
                            // console.log("KYC Done-->")
                            this.checkyc = true;
                            this.sellFunc();
                        }
                        else if (this.kyc.kycStatus == null){
                            this.appC.showInfoToast('KYC verification is required to withdraw amount.');
                        }
        
                    } else {
                        this.appC.showErrToast(response.body.message);
                    }
                }, error => {
                    this.appC.showErrToast(error.error.message);
                    this.spinnerService.hide();
                });

                    } 
                    break;
                case 'STOPLIMIT':
                    if(this.sLimitSellObj.stop == "") {
                        this.appC.showErrToast("Enter stop value.");
                        return;
                    } else if(this.sLimitSellObj.stop == ".") {
                        this.appC.showErrToast("Enter valid stop value.");
                        return;
                    } else if(Number(this.sLimitSellObj.stop) <= 0) {
                        this.appC.showErrToast("Enter valid stop value.");
                        return;
                    } else if(this.sLimitSellObj.price == "") {
                        this.appC.showErrToast("Enter limit value.");
                        return;
                    } else if(this.sLimitSellObj.price == ".") {
                        this.appC.showErrToast("Enter valid limit value.");
                        return;
                    } else if(Number(this.sLimitSellObj.price) <= 0) {
                        this.appC.showErrToast("Enter valid limit value.");
                        return;
                    } else if(this.sLimitSellObj.amount == "") {
                        this.appC.showErrToast("Enter amount value.");
                        return;
                    } else if(this.sLimitSellObj.amount == ".") {
                        this.appC.showErrToast("Enter valid amount value.");
                        return;
                    } else if(Number(this.sLimitSellObj.amount) <= 0) {
                        this.appC.showErrToast("Enter valid amount value.");
                        return;
                    } else if(Number(this.sLimitSellObj.amount) > Number(this.userData.pairCoinBal)){
                        this.appC.showErrToast("You can't sell coins more than your wallet amount.");
                        return;
                    } else {
                         this.kyc = [];
                let kycDetails = {
        
                    "token": localStorage.getItem('token')
                }
        
                this.spinnerService.show();
                this.server.getApi('account/get-kyc-details', localStorage.getItem('token')).subscribe(response => {
                    this.spinnerService.hide();
                    if (response.body.status == 200) {
                      
                        // console.log('KYC-->', response.body)
                        this.kyc = response.body.data
                        if (response.body.document == "undefined") {
                            this.appC.showInfoToast("To get the functionalities of the Bittnomy exchange you need to get your kyc done");
                        } else if (this.kyc.kycStatus == 'ACCEPTED' ) {
                            // console.log("KYC Done-->")
                            this.checkyc = true;
                            this.sellFunc();
                        }
                        else if (this.kyc.kycStatus == null){
                            this.appC.showInfoToast('KYC verification is required to withdraw amount.');
                        }
        
                    } else {
                        this.appC.showErrToast(response.body.message);
                    }
                }, error => {
                    this.appC.showErrToast(error.error.message);
                    this.spinnerService.hide();
                });

                    } 
              break;
            }
     }  
  

}


/** Function for buy order */
buyFunc() {
    // console.log('ordertype',this.buyOrderType)
    switch(this.buyOrderType) {
        case 'LIMIT':
            this.limitBuyFunc();
            // this.openConfirmationModal()
            break;
        case 'MARKET':
            this.marketBuyFunc();
            
            break;
        case 'STOPLIMIT':
            this.stopBuyFunc();
           
            break;
    }
}


   /** Function for limit buy */
   limitBuyFunc() {
    // console.log('limitBuyFunc')
        let data = {
               "limitPrice":Number(this.limitBuyObj.price),
                "orderSide": "BUY",
                "orderType": "LIMIT",
                "quantity": Number(this.limitBuyObj.amount),
                "symbol": this.baseCoin+'_'+this.exeCoin
        }

        this.spinnerService.show();
        this.server.postApi("order-service-eth_btc/place-order",data,localStorage.getItem("token")).subscribe((succ) => {
            this.spinnerService.hide();
            if(succ.status == 200) {
                this.appC.showSuccToast(succ.message);
                this.clearLimitBuyObj();
                this.getUserBaseCoinBalance();
                this.getUserPairCoinBalance();
                // console.log('limit by')
                if(localStorage.getItem("token")) {
                    this.getUserOpenOrder();
                    this.getUserOrderHistory();
                }
                if(succ.transferObjectMap.isTradeExecuted) {
                    // this.getHeaderPrice();
                    this.getCoinPairAfterExecution();
                }
            } else if(succ.transferObjectMap.statusCode == 403) {
                this.header.logOut();
            } else {
                this.appC.showErrToast(succ.transferObjectMap.message);
            }
        }, (err) => {
            this.spinnerService.hide();
        });
    }

 /** Function for market buy */
    marketBuyFunc() {
        // console.log('marketBuyFunc')
        if(this.marketBuyObj.amount == "") {
            this.appC.showErrToast("Enter amount value.");
            return;
        } else if(this.marketBuyObj.amount == ".") {
            this.appC.showErrToast("Enter valid amount value.");
            return;
        } else if(Number(this.marketBuyObj.amount) <= 0) {
            this.appC.showErrToast("Enter valid amount value.");
            return;
        } else {

            let data = {
               
                 "orderSide": "BUY",
                 "orderType": "MARKET",
                 "quantity": Number(this.marketBuyObj.amount),
                 "symbol": this.baseCoin+'_'+this.exeCoin
              
               }
            this.spinnerService.show();
            this.server.postApi("order-service-eth_btc/place-order",data,localStorage.getItem("token")).subscribe((succ) => {
                this.spinnerService.hide();
                if(succ.status == 200) {
                    this.appC.showSuccToast(succ.message);
                    this.clearLimitBuyObj();
                    this.getUserBaseCoinBalance();
                    this.getUserPairCoinBalance();
                   
                    if(localStorage.getItem("token")) {
                        this.getUserOpenOrder();
                        this.getUserOrderHistory();
                    }
                    if(succ.transferObjectMap.isTradeExecuted) {
                        // this.getHeaderPrice();
                        this.getCoinPairAfterExecution();
                    }
                } else if(succ.transferObjectMap.statusCode == 403) {
                    this.header.logOut();
                } else {
                    this.appC.showErrToast(succ.transferObjectMap.message);
                }
            }, (err) => {
                this.spinnerService.hide();
            });
        }
    }

      /** Function for stop limit buy */
     stopBuyFunc() {
        // console.log('stopBuyFunc')
        if(this.sLimitBuyObj.stop == "") {
            this.appC.showErrToast("Enter stop value.");
            return;
        } else if(this.sLimitBuyObj.stop == ".") {
            this.appC.showErrToast("Enter valid stop value.");
            return;
        } else if(Number(this.sLimitBuyObj.stop) <= 0) {
            this.appC.showErrToast("Enter valid stop value.");
            return;
        } else if(this.sLimitBuyObj.price == "") {
            this.appC.showErrToast("Enter limit value.");
            return;
        } else if(this.sLimitBuyObj.price == ".") {
            this.appC.showErrToast("Enter valid limit value.");
            return;
        } else if(Number(this.sLimitBuyObj.price) <= 0) {
            this.appC.showErrToast("Enter valid limit value.");
            return;
        } else if(this.sLimitBuyObj.amount == "") {
            this.appC.showErrToast("Enter amount value.");
            return;
        } else if(this.sLimitBuyObj.amount == ".") {
            this.appC.showErrToast("Enter valid amount value.");
            return;
        } else if(Number(this.sLimitBuyObj.amount) <= 0) {
            this.appC.showErrToast("Enter valid amount value.");
            return;
        } else if(Number(this.sLimitBuyObj.total) > Number(this.userData.baseCoinBal)){
            this.appC.showErrToast("You can't buy coins more than your wallet amount.");
            return;
        } else {
            let data = {
                        "limitPrice":Number(this.sLimitBuyObj.price),
                        "orderSide": "BUY",
                        "orderType": "STOP_LIMIT",
                        "quantity": Number(this.sLimitBuyObj.amount),
                        "stopPrice": Number(this.sLimitBuyObj.stop),
                        "symbol": this.baseCoin+'_'+this.exeCoin
                                             
                    }
               
                    this.spinnerService.show();
                    this.server.postApi("order-service-eth_btc/place-order",data,localStorage.getItem("token")).subscribe((succ) => {
                        this.spinnerService.hide();
                        if(succ.status == 200) {
                            this.appC.showSuccToast(succ.message);
                            this.clearLimitBuyObj();
                            this.getUserBaseCoinBalance();
                            this.getUserPairCoinBalance();
                            // console.log('Stop by')
                            if(localStorage.getItem("token")) {
                                this.getUserOpenOrder();
                                this.getUserOrderHistory();
                            }
                            if(succ.transferObjectMap.isTradeExecuted) {
                                // this.getHeaderPrice();
                                this.getCoinPairAfterExecution();
                            }
                        } else if(succ.transferObjectMap.statusCode == 403) {
                            this.header.logOut();
                        } else {
                            this.appC.showErrToast(succ.transferObjectMap.message);
                        }
                    }, (err) => {
                        this.spinnerService.hide();
                    });
        }
    }


    /** Function for sell order*/ 
    sellFunc() {
        switch(this.sellOrderType) {
            case 'LIMIT':
                this.limitSellFunc();
                break;
            case 'MARKET':
                this.marketSellFunc();
                break;
            case 'STOPLIMIT':
                this.stopSellFunc();
                break;
        }
    }

/** Function for limit sell */
limitSellFunc() {
    if(this.limitSellObj.price == "") {
        this.appC.showErrToast("Enter price value.");
        return;
    } else if(this.limitSellObj.price == ".") {
        this.appC.showErrToast("Enter valid price value.");
        return;
    } else if(Number(this.limitSellObj.price) <= 0) {
        this.appC.showErrToast("Enter valid price value.");
        return;
    } else if(this.limitSellObj.amount == "") {
        this.appC.showErrToast("Enter amount value.");
        return;
    } else if(this.limitSellObj.amount == ".") {
        this.appC.showErrToast("Enter valid amount value.");
        return;
    } else if(Number(this.limitSellObj.amount) <= 0) {
        this.appC.showErrToast("Enter valid amount value.");
        return;
    } else if(Number(this.limitSellObj.amount) > Number(this.userData.pairCoinBal)){
        this.appC.showErrToast("You can't sell coins more than your wallet amount.");
        return;
    } else {
        let data = {
            "limitPrice":Number(this.limitSellObj.price),
             "orderSide": "SELL",
             "orderType": "LIMIT",
             "quantity": Number(this.limitSellObj.amount),
             "symbol": this.baseCoin+'_'+this.exeCoin
     }
        
     this.spinnerService.show();
     this.server.postApi("order-service-eth_btc/place-order",data,localStorage.getItem("token")).subscribe((succ) => {
         this.spinnerService.hide();
         if(succ.status == 200) {
             this.appC.showSuccToast(succ.message);
             this.clearLimitBuyObj();
             this.getUserBaseCoinBalance();
             this.getUserPairCoinBalance();
            //  console.log('limit by')
             if(localStorage.getItem("token")) {
                 this.getUserOpenOrder();
                 this.getUserOrderHistory();
             }
             if(succ.transferObjectMap.isTradeExecuted) {
                 // this.getHeaderPrice();
                 this.getCoinPairAfterExecution();
             }
         } else if(succ.transferObjectMap.statusCode == 403) {
             this.header.logOut();
         } else {
             this.appC.showErrToast(succ.transferObjectMap.message);
         }
     }, (err) => {
         this.spinnerService.hide();
     });
    }
}

marketSellFunc() {
    // console.log('marketsellfun')
    if(this.marketSellObj.amount == "") {
        this.appC.showErrToast("Enter amount value.");
        return;
    } else if(this.marketSellObj.amount == ".") {
        this.appC.showErrToast("Enter valid amount value.");
        return;
    } else if(Number(this.marketSellObj.amount) <= 0) {
        this.appC.showErrToast("Enter valid amount value.");
        return;
    } else if(Number(this.marketSellObj.amount) > Number(this.userData.pairCoinBal)) {
        this.appC.showErrToast("You can't sell coins more than your wallet amount.");
        return;
    } else { 
        let data = {
               
            "orderSide": "SELL",
            "orderType": "MARKET",
            "quantity": Number(this.marketSellObj.amount),
            "symbol": this.baseCoin+'_'+this.exeCoin
         
          }
       this.spinnerService.show();
       this.server.postApi("order-service-eth_btc/place-order",data,localStorage.getItem("token")).subscribe((succ) => {
           this.spinnerService.hide();
           if(succ.status == 200) {
               this.appC.showSuccToast(succ.message);
               this.clearLimitBuyObj();
               this.getUserBaseCoinBalance();
               this.getUserPairCoinBalance();
              
               if(localStorage.getItem("token")) {
                   this.getUserOpenOrder();
                   this.getUserOrderHistory();
               }
               if(succ.transferObjectMap.isTradeExecuted) {
                   // this.getHeaderPrice();
                   this.getCoinPairAfterExecution();
               }
           } else if(succ.transferObjectMap.statusCode == 403) {
               this.header.logOut();
           } else {
               this.appC.showErrToast(succ.transferObjectMap.message);
           }
       }, (err) => {
           this.spinnerService.hide();
       });
   }

}

stopSellFunc() {
    if(this.sLimitSellObj.stop == "") {
        this.appC.showErrToast("Enter stop value.");
        return;
    } else if(this.sLimitSellObj.stop == ".") {
        this.appC.showErrToast("Enter valid stop value.");
        return;
    } else if(Number(this.sLimitSellObj.stop) <= 0) {
        this.appC.showErrToast("Enter valid stop value.");
        return;
    } else if(this.sLimitSellObj.price == "") {
        this.appC.showErrToast("Enter limit value.");
        return;
    } else if(this.sLimitSellObj.price == ".") {
        this.appC.showErrToast("Enter valid limit value.");
        return;
    } else if(Number(this.sLimitSellObj.price) <= 0) {
        this.appC.showErrToast("Enter valid limit value.");
        return;
    } else if(this.sLimitSellObj.amount == "") {
        this.appC.showErrToast("Enter amount value.");
        return;
    } else if(this.sLimitSellObj.amount == ".") {
        this.appC.showErrToast("Enter valid amount value.");
        return;
    } else if(Number(this.sLimitSellObj.amount) <= 0) {
        this.appC.showErrToast("Enter valid amount value.");
        return;
    } else if(Number(this.sLimitSellObj.amount) > Number(this.userData.pairCoinBal)){
        this.appC.showErrToast("You can't sell coins more than your wallet amount.");
        return;
    } else {
        let data = {
            "limitPrice":Number(this.sLimitSellObj.price),
            "orderSide": "SELL",
            "orderType": "STOP_LIMIT",
            "quantity": Number(this.sLimitSellObj.amount),
            "stopPrice": Number(this.sLimitSellObj.stop),
            "symbol": this.baseCoin+'_'+this.exeCoin
                                 
        }
   
        this.spinnerService.show();
        this.server.postApi("order-service-eth_btc/place-order",data,localStorage.getItem("token")).subscribe((succ) => {
            this.spinnerService.hide();
            if(succ.status == 200) {
                this.appC.showSuccToast(succ.message);
                this.clearLimitBuyObj();
                this.getUserBaseCoinBalance();
                this.getUserPairCoinBalance();
                // console.log('Stop by')
                if(localStorage.getItem("token")) {
                    this.getUserOpenOrder();
                    this.getUserOrderHistory();
                }
                if(succ.transferObjectMap.isTradeExecuted) {
                    // this.getHeaderPrice();
                    this.getCoinPairAfterExecution();
                }
            } else if(succ.transferObjectMap.statusCode == 403) {
                this.header.logOut();
            } else {
                this.appC.showErrToast(succ.transferObjectMap.message);
            }
        }, (err) => {
            this.spinnerService.hide();
        });
    }
}

  


    
    /** Function to clear limit buy obj */
    clearLimitBuyObj() {
        this.limitBuyObj.amount = "";
        this.limitBuyObj.price = "";
        this.limitBuyObj.total = "";
    }

    /** Function to clear market buy obj */
    clearMarketBuyObj() {
        this.marketBuyObj.amount = "";
    }

    /** Function to clear stop limit buy obj */
    clearStopLimitBuyObj() {
        this.sLimitBuyObj.amount = "";
        this.sLimitBuyObj.price = "";
        this.sLimitBuyObj.stop = "";
        this.sLimitBuyObj.total = "";
    }

    /** Function to clear limit sell obj */
    clearLimitSellObj() {
        this.limitSellObj.amount = "";
        this.limitSellObj.price = "";
        this.limitSellObj.total = "";
    }

    /** Function to clear market sell obj */
    clearMarketSellObj() {
        this.marketSellObj.amount = "";
    }

    /** Function to clear stop limit sell obj */
    clearStopLimitSellObj() {
        this.sLimitSellObj.amount = "";
        this.sLimitSellObj.price = "";
        this.sLimitSellObj.stop = "";
        this.sLimitSellObj.total = "";
    }


 /** Function to fetch buy order from api */
 getBuyOrder() {
    this.buyOrderArr = [];
    
    this.server.getApi('order/my-active-orders?baseCoin='+this.baseCoin,localStorage.getItem('token')).subscribe(succ => {
        if(succ.status == 200) {
        //  console.log('ACTIVEORDER===>',succ.body)
         succ.body.data.forEach((obj) => {
                var ind = this.buyOrderArr.findIndex((x) => x.price == obj.price);
                if(ind != -1) {
                    this.buyOrderArr[ind].amount = (Number(this.buyOrderArr[ind].amount) + Number(obj.amount)).toFixed(8);
                    this.buyOrderArr[ind].total = (this.buyOrderArr[ind].price * this.buyOrderArr[ind].amount).toFixed(8);
                } else {
                    this.buyOrderArr.push({
                        price: obj.price.toFixed(8),
                        amount: obj.amount.toFixed(8),
                        total: (obj.price*obj.amount).toFixed(8),
                    });
                }
            });
        }
    }, (err) => {
    });
}

 /** Function to fetch sell order from api */
 getSellOrder() {
    this.sellOrderArr = [];
  
    this.server.getApi('order-service-eth_btc/my-active-orders?symbol='+this.baseCoin+'_'+this.exeCoin,localStorage.getItem('token')).subscribe(succ => {
      if(succ.status == 200) {
        console.log("getSellORder==>",succ.body)
     
            succ.body.data.forEach((obj) => {
                console.log("getSellORder2==>",this.sellOrderArr)
                var ind = this.sellOrderArr.findIndex((x) => x.price == obj.price);
                if(ind != -1) {
                    this.sellOrderArr[ind].amount = (Number(this.sellOrderArr[ind].amount) + Number(obj.amount)).toFixed(8);
                    this.sellOrderArr[ind].total = (this.sellOrderArr[ind].price * this.sellOrderArr[ind].amount).toFixed(8);
                } else {
                    this.sellOrderArr.push({
                        price: (obj.price) ? obj.price.toFixed(8):'',
                        amount: (obj.amount) ? obj.amount.toFixed(8):'',
                        total: (obj.amount) ? (obj.price*obj.amount).toFixed(8):''
                    });
                }
            });
        }
    }, (err) => {
    });
}



 

getUserOpenOrder(){
    if(localStorage.getItem('token')){
    //    console.log('OPENHISTROY==>',this.baseCoin+'_'+this.exeCoin)
        this.spinnerService.show();
        this.server.getApi('order-service-eth_btc/my-active-orders?symbol='+this.baseCoin+'_'+this.exeCoin,localStorage.getItem('token')).subscribe(response => {
            this.spinnerService.hide();
            if (response.status == 200) {
                
                // this.openOrderArr = response.body.data;
               
                response.body.data.forEach((element) => {
                    if(element.orderStatus == 'PARTIALLY_EXECUTED') {
                        this.openOrderArr.push({
                            total : (element.avgExecutionPrice*element.currentQuantity).toFixed(8),
                            creationTime : element.creationTime,
                            instrument : element.instrument,
                            orderSide : element.orderSide,
                            limitPrice : element.avgExecutionPrice.toFixed(8),
                            quantity : element.currentQuantity.toFixed(8),
                            orderStatus : element.orderStatus,
                            orderId: element.orderId,
                            orderType: element.orderType,
                            filled: (((element.quantity-element.currentQuantity)/element.quantity)*100).toFixed(8),
                            click : false
        
                        }) ;
                    }  
                    else if(element.orderStatus == 'CREATED') {
                       
                        this.openOrderArr.push({
                            total : (element.limitPrice*element.currentQuantity),
                            creationTime : element.creationTime,
                            instrument : element.instrument,
                            orderSide : element.orderSide,
                            limitPrice : element.limitPrice,
                            quantity : element.currentQuantity,
                            orderStatus : element.orderStatus,
                            orderId: element.orderId,
                            orderType: element.orderType,
                            filled: (((element.quantity-element.currentQuantity)/element.quantity)*100).toFixed(8),
                            click : false
        
                        }) ;
                      
                     } 
            });
            // console.log("Response--->",this.openOrderArr)
        } else if(response.statusCode == 403) {
                this.header.logOut();
            } else {
                this.appC.showErrToast(response.message);
            }
        }, error => {
            this.spinnerService.hide()
            this.appC.showErrToast(error.error.message);
        });
    }
}
 



getUserOrderHistory(){
    this.orderHistoryArr = [];
    if(localStorage.getItem('token')){
    //    console.log('header=',this.exeCoin)
        this.spinnerService.show();
        this.server.getApi('order/my-order-history?symbol='+this.baseCoin+'_'+this.exeCoin,localStorage.getItem('token')).subscribe(response => {
            this.spinnerService.hide();
            if (response.status == 200) {
                
                 this.orderHistoryArr = response.body.data;
                 this.orderHistoryArr.forEach((obj) => {
                   
                    switch(obj.orderStatus) {
                        case 'COMPLETED':
                            obj.amount = (obj.tradeHistoryAmount - obj.quantity).toFixed(8);
                            obj.total = (obj.quantity * obj.limitPrice).toFixed(8);
                             break;
                        case 'QUEUED':
                            obj.amount = obj.tradeHistoryAmount.toFixed(8);
                            obj.total = (obj.quantity * obj.limitPrice).toFixed(8);
                            break;
                         case 'CREATED':
                            obj.amount = obj.tradeHistoryAmount.toFixed(8);
                            obj.total = (obj.quantity * obj.limitPrice).toFixed(8);
                            break;
                        case 'CANCELLED':
                            obj.amount = obj.amount;
                            obj.total = (obj.quantity * obj.limitPrice).toFixed(8);
                            break;
                    }
                });
                
                 this.orderHistoryArr.forEach((obj) => {
                    this.tradeHisArr.forEach(element => {
                        if(obj.userId == element.userId && obj.orderId == element.orderId) {
                            obj.fee  = element.commissionFee;
                            obj.grandTotal = Number(obj.total) - Number(element.commissionFee);
                            obj.filled= (((obj.quantity-obj.currentQuantity)/obj.quantity)*100).toFixed(8);
                          
                        }
                    }); 
                });
                // console.log('GETUSer Order Histroy=>',   this.orderHistoryArr)
                // this.appC.showSuccToast('Order history working')
            } else if(response.status == 403) {
                this.header.logOut();
            } else {
                 this.orderHistoryArr = [];
                this.appC.showErrToast(response.message);
            }
        }, error => {
            this.spinnerService.hide()
            this.appC.showErrToast(error.error.message);
        });
    }
}

manageExponential(num) {
    //if the number is in scientific notation remove it
    if (/\d+\.?\d*e[\+\-]*\d+/i.test(num)) {
        var zero = '0',
        parts = String(num).toLowerCase().split('e'), //split into coeff and exponent
        es = Number(parts.pop()), //store the exponential part
        l = Math.abs(es), //get the number of zeros
        sign = es / l,
        coeff_array = parts[0].split('.');
        if (sign === -1) {
            num = zero + '.' + new Array(l).join(zero) + coeff_array.join('');
        } else {
            var dec = coeff_array[1];
            if (dec) l = l - dec.length;
            num = coeff_array.join('') + new Array(l + 1).join(zero);
        }
        return num;
    } else {
        return num;
    }
};

cancelOrder(order) {
    order.click = true;
    let data = {
           "orderId": order.orderId,
           "symbol":this.baseCoin+'_'+this.exeCoin
            }
    //   console.log('delete data===>',data)
    this.spinnerService.show();
    this.server.postApi("order-service-eth_btc/cancel-order",data, localStorage.getItem('token')).subscribe((succ) => {
        
        this.spinnerService.hide();
        if(succ.status == 200) {
            this.appC.showInfoToast(succ.message);
            if(localStorage.getItem("token")) {
                this.getUserOpenOrder();
                this.getUserOrderHistory();
            }
            this.getUserBaseCoinBalance();
            this.getUserPairCoinBalance();                
        }  else if(succ.status == 403)  { 
            this.header.logOut();
        } else {
            this.appC.showErrToast(succ.message);
            order.click = false;
        }
    }, (err) => {
        this.spinnerService.hide();
    });
}


goToLogin() {
    this.router.navigateByUrl('header/login');
}

/** Function to get selected chart tab */
selectChartTab(chart) {
    switch(chart) {
        case 'OHLC':
            this.drawTradingChart();
            break;
        case 'DepthChart':
            this.drawDepthChart();
            break;
    }
}



  /** Function to draw trading chart */ 
  drawTradingChart() {
    let currVal = this.tradeViewPair.split("/")[0];
    let exeVal = this.tradeViewPair.split("/")[1];
    console.log('pair====>',currVal,exeVal)
    if(exeVal == 'ECH') {
        exeVal = 'ETC';
    }
    this.tradingChart = setTimeout(() => {
        if($('body').hasClass('nightmode')) {
            new TradingView.widget({
                fullscreen: true,
                symbol: exeVal+"/"+currVal,
                interval: 'D',
                container_id: "tradingChart",
                //datafeed: new Datafeeds.UDFCompatibleDatafeed("http://172.16.21.20:8083/bitnomyChart/exchange-feed",60000),
                datafeed: new Datafeeds.UDFCompatibleDatafeed("http://172.16.2.4:8765/order/exchange-feed",60000),
                library_path: "assets/lib/charting_library_night/",
                locale: "en",
                drawings_access: { type: 'black', tools: [{ name: "Regression Trend" }] },
                disabled_features: ["use_localstorage_for_settings"],
                overrides: {
                    "paneProperties.background": "#000",
                    "paneProperties.vertGridProperties.color": "#454545",
                    "paneProperties.horzGridProperties.color": "#454545",
                    "symbolWatermarkProperties.transparency": 90,
                    "scalesProperties.textColor": "#AAA"
                }
            });
        } else {
            new TradingView.widget({
                fullscreen: true,
                symbol: exeVal+"/"+currVal,
                interval: 'D',
                container_id: "tradingChart",
                //datafeed: new Datafeeds.UDFCompatibleDatafeed("http://172.16.21.20:8083/bitnomyChart/exchange-feed",60000),
                datafeed: new Datafeeds.UDFCompatibleDatafeed("http://172.16.2.4:8765/order/exchange-feed/config",60000),
                library_path: "assets/lib/charting_library/",
                locale: "en",
                drawings_access: { type: 'black', tools: [{ name: "Regression Trend" }] },
                disabled_features: ["use_localstorage_for_settings"]
            });
        }
    },500);
}

 /**to draw depth chart */
 drawDepthChart() {
   
    let currVal = this.tradeViewPair.split("/")[0];
    let exeVal = this.tradeViewPair.split("/")[1];

    console.log('pair2====>',currVal,exeVal)
    AmCharts.makeChart("depthChartID", {
        "type": "serial",
        "theme": "light",
        "dataLoader": {
            "url": 'http://172.16.2.4:8765/order/exchange-feed/depth-chart?currency='+this.baseCoin+'&exchangeCurrency='+this.exeCoin,
            "format": "json",
            "reload": 30,
            "postProcess": function(data) {
                var response = JSON.stringify(data);
                var parsedData = JSON.parse(response);
                var asks = parsedData.data.asks;
                var bids = parsedData.data.bids;
                // console.log('chartdata==>',parsedData)
                // Function to process (sort and calculate cummulative volume)
                function processData(list, type, desc) {
                    // Convert to data points
                    for(var i = 0; i < list.length; i++) {
                        list[i] = {
                            value: Number(list[i][0]),
                            volume: Number(list[i][1]),
                        }
                    }                 
                    // Sort list just in case
                    list.sort(function(a, b) {
                        if (a.value > b.value) {
                            return 1;
                        }
                        else if (a.value < b.value) {
                            return -1;
                        }
                        else {
                            return 0;
                        }
                    });                  
                    // Calculate cummulative volume
                    if (desc) {
                        for(var i = list.length - 1; i >= 0; i--) {
                            if (i < (list.length - 1)) {
                                list[i].totalvolume = list[i+1].totalvolume + list[i].volume;
                            }
                            else {
                                list[i].totalvolume = list[i].volume;
                            }
                            var dp = {};
                            dp["value"] = list[i].value;
                            dp[type + "volume"] = list[i].volume;
                            dp[type + "totalvolume"] = list[i].totalvolume;
                            res.unshift(dp);
                        }
                    } else {
                        for(var i = 0; i < list.length; i++) {
                            if (i > 0) {
                                list[i].totalvolume = list[i-1].totalvolume + list[i].volume;
                            }
                            else {
                                list[i].totalvolume = list[i].volume;
                            }
                            var dp = {};
                            dp["value"] = list[i].value;
                            dp[type + "volume"] = list[i].volume;
                            dp[type + "totalvolume"] = list[i].totalvolume;
                            res.push(dp);
                        }
                    }                 
                }
                
                var res = [];
                processData(bids, "bids", true);
                processData(asks, "asks", false);
                return res;
            }
        },
        "graphs": [{
            "id": "bids",
            "fillAlphas": 0.1,
            "lineAlpha": 1,
            "lineThickness": 2,
            "lineColor": "#0f0",
            "type": "step",
            "valueField": "bidstotalvolume",
            "balloonFunction": balloon
        }, {
            "id": "asks",
            "fillAlphas": 0.1,
            "lineAlpha": 1,
            "lineThickness": 2,
            "lineColor": "#f00",
            "type": "step",
            "valueField": "askstotalvolume",
            "balloonFunction": balloon
        }, {
            "lineAlpha": 0,
            "fillAlphas": 0.2,
            "lineColor": "#000",
            "type": "column",
            "clustered": false,
            "valueField": "bidsvolume",
            "showBalloon": false
        }, {
            "lineAlpha": 0,
            "fillAlphas": 0.2,
            "lineColor": "#000",
            "type": "column",
            "clustered": false,
            "valueField": "asksvolume",
            "showBalloon": false
        }],
        "categoryField": "value",
        "chartCursor": {},
        "balloon": {
            "textAlign": "left"
        },
        "categoryAxis": {
            "minHorizontalGap": 100,
            "startOnAxis": true,
            "showFirstLabel": false,
            "showLastLabel": false
        },
        "export": {
            "enabled": false
        }
    });
      
    function balloon(item, graph) {
        var txt;
        if (graph.id == "asks") {
            txt = "Ask: <strong>" + formatNumber(item.dataContext.value, graph.chart, 8) + "</strong><br />"
            + "Total volume: <strong>" + formatNumber(item.dataContext.askstotalvolume, graph.chart, 8) + "</strong><br />"
            + "Volume: <strong>" + formatNumber(item.dataContext.asksvolume, graph.chart, 8) + "</strong>";
        }
        else {
            txt = "Bid: <strong>" + formatNumber(item.dataContext.value, graph.chart, 8) + "</strong><br />"
            + "Total volume: <strong>" + formatNumber(item.dataContext.bidstotalvolume, graph.chart, 8) + "</strong><br />"
            + "Volume: <strong>" + formatNumber(item.dataContext.bidsvolume, graph.chart, 8) + "</strong>";
        }
        return txt;
    }
    
    function formatNumber(val, chart, precision) {
        return AmCharts.formatNumber(val, {
            precision: precision ? precision : chart.precision, 
            decimalSeparator: chart.decimalSeparator,
            thousandsSeparator: chart.thousandsSeparator
        });
    }
}

/** Function for get header price for selected pair coin */
getHeaderPrice() {
    let data = {
        "eventExternal": {
            "name":"request_get_header_data",
            "key":"mykey"
        },
        "transferObjectMap": {
            "gatewayrequest": {
                "baseCurrency": this.currentCoinObj.coinId,
                "executableCurrency": this.currentPairCoinObj.coinId
            }
       }            
    }
    this.server.postApi("",data,0).subscribe((succ) => {
        if(succ.transferObjectMap.statusCode == 200) {
            this.headerPriceObj.average = succ.transferObjectMap.average;
            this.headerPriceObj.currPrice = succ.transferObjectMap.lastPrice;
            this.headerPriceObj.highest = succ.transferObjectMap.maxPrice;
            this.headerPriceObj.lowest = succ.transferObjectMap.minPrice;
            this.headerPriceObj.volume = succ.transferObjectMap.volume;

            let currPairArr = this.coinPairListArr.filter(obj => obj.coin == this.currentPairCoinObj.coinShort);
            if(currPairArr.length) {
                currPairArr[0].last_price = this.headerPriceObj.currPrice;
                currPairArr[0].volume = this.headerPriceObj.volume;
                currPairArr[0].average = this.headerPriceObj.average;
            }
        } else {
            this.headerPriceObj.average = "";
            this.headerPriceObj.currPrice = "";
            this.headerPriceObj.highest = "";
            this.headerPriceObj.lowest = "";
            this.headerPriceObj.volume = "";
        }
    }, (err) => {
    });
}

 
selectBID(data) {
    this.limitBuyObj.price = data.price;
    this.limitBuyObj.amount = data.amount;
    this.valueChangeFunc('LBP');
    this.marketBuyObj.amount = data.amount;
    this.limitSellObj.price = data.price;
    this.limitSellObj.amount = data.amount;
    this.valueChangeFunc('LSP');
    this.marketSellObj.amount = data.amount;
}


} 

 





//class end
