import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TradeactionComponent } from './tradeaction/tradeaction.component';

@NgModule({
    imports: [
        CommonModule
    ],
    declarations: [TradeactionComponent]
})
export class TradeactionModule { }
