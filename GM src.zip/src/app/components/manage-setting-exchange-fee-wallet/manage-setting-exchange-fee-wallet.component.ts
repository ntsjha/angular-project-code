import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ServiceService } from 'src/app/service/service.service';
import { CookieService } from 'ngx-cookie-service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { AppComponent } from 'src/app/app.component';

declare var $: any;

@Component({
  selector: 'app-manage-setting-exchange-fee-wallet',
  templateUrl: './manage-setting-exchange-fee-wallet.component.html',
  styleUrls: ['./manage-setting-exchange-fee-wallet.component.css']
})
export class ManageSettingExchangeFeeWalletComponent implements OnInit, OnDestroy {
  coinName: any;
  id2: any;
  exchangeFeeWalletDetail: any;
  walletFunction: FormGroup;
  watchAddress: any[];
  subscription: any;
  userIp: any;

  constructor(
    private cookie: CookieService,
    private service: ServiceService,
    private spinner: NgxSpinnerService,
    private activatedRoute: ActivatedRoute,
    private route: Router,
    private appC: AppComponent
  ) {
    this.walletFunction = new FormGroup({
      transferAddress: new FormControl(null, Validators.required),
      hour: new FormControl(null, [Validators.required, Validators.pattern(/^(10|11|12|[1-9])$/)]),
      miniute: new FormControl(null, [Validators.required, Validators.pattern(/\b([0-5][0-9])\b/)]),
    });
    this.subscription = this.service.authVerify.subscribe(val => {
      if (val == 'manage-setting') {
        this.updateWalletDetails();
        this.service.authVerify.next('false');
      }
    });
    this.userIp = (this.cookie.get('userInfo')) ? JSON.parse(this.cookie.get('userInfo')) : this.service.initialUserInfo;
  }

  ngOnInit() {
    this.activatedRoute.params.subscribe(id => {
      this.coinName = id.id;
      this.id2 = id.id2;
    });
    this.getExchangeWalletFeeDetail();
    window.scrollTo(0, 0);
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  goToCancel() {
    if (this.service.sideMenuArr.includes('updateSettings')) {
      this.route.navigate(['/manage-exchange-fee-wallet']);
    }
  }

  getExchangeWalletFeeDetail() {
    this.spinner.show();
    this.service.getMethod('wallet/admin/exchange-fee-wallet/get-exchange-wallet-details?exchangeWalletId=' + this.id2, 1).subscribe((response: any) => {
      this.spinner.hide();
      if (response.status === 842) {
        this.exchangeFeeWalletDetail = response.data;
        this.walletFunction.patchValue({
          transferAddress: this.exchangeFeeWalletDetail.hotWalletAddress,
          hour: this.exchangeFeeWalletDetail.scheduledHours,
          minute: this.exchangeFeeWalletDetail.scheduledMinutes,
        });
        this.watchAddress = this.exchangeFeeWalletDetail.watchAddresses;
      }
      this.spinner.hide();
    });
    this.spinner.hide();

  }

  /** Function to verify google authentication */
  verifyGoogleAuth() {
    this.appC.google = { one: '', two: '', three: '', four: '', five: '', six: '' };
    this.appC.response = { 'message': '' };
    this.service.googleAuthCalledFrom = 'manage-setting';
    $('#google-auth-modal').modal({ keyboard: false, backdrop: 'static' });

  }


  updateWalletDetails() {
    const data = {
      coinName: this.coinName,
      cryptoAddress: this.walletFunction.value.transferAddress,
      hours: this.walletFunction.value.hour,
      minutes: this.walletFunction.value.minute,
      watchAddresses: this.watchAddress,
      ipAddress: this.userIp.ip,
      location: this.userIp.city + ',' + this.userIp.country_name
    };
    this.service.postMethod('wallet/admin/exchange-fee-wallet/update-exchange-wallet', data, 1)
      .subscribe((response) => {
        this.spinner.hide();
        if (response.status === 842) {
          this.route.navigate(['/manage-exchange-fee-wallet']);
        }
      }, (error) => {
        this.spinner.hide();
      });
  }
}
