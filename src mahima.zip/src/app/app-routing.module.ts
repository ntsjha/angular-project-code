import { BuySubscriptionComponent } from './pages/buy-subscription/buy-subscription.component';
import { HeaderComponent } from './pages/header/header.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './pages/login/login.component';
import { SignUpComponent } from './pages/sign-up/sign-up.component';
import { ForgotPasswordComponent } from './pages/forgot-password/forgot-password.component';
import { ResetPasswordComponent } from './pages/reset-password/reset-password.component';
import { EmailVerifyComponent } from './pages/email-verify/email-verify.component';
import { SmsVerifyComponent } from './pages/sms-verify/sms-verify.component';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { AddPetrolComponent } from './pages/add-petrol/add-petrol.component';
import { MyProfileComponent } from './pages/my-profile/my-profile.component';
import { EditProfileComponent } from './pages/edit-profile/edit-profile.component';
import { UserManagementComponent } from './pages/user-management/user-management.component';
import { MachineReadingComponent } from './pages/machine-reading/machine-reading.component';
import { PaymentScreenComponent } from './pages/payment-screen/payment-screen.component';


const routes: Routes = [
  { path : '', redirectTo : 'login', pathMatch : 'full'},
  { path : 'login', component: LoginComponent},
  { path : 'signUp', component: SignUpComponent},
  { path : 'buySubscriptionPlan', component: BuySubscriptionComponent},
  { path : 'forgotPassowrd', component: ForgotPasswordComponent},
  { path : 'resetPassword', component: ResetPasswordComponent},
  { path : 'emailVerify', component: EmailVerifyComponent},
  { path : 'phoneVerify', component: SmsVerifyComponent},
  { path : 'header', component : HeaderComponent,
    children: [
      { path : 'dashboard', component: DashboardComponent},
      { path : 'welcome', component: AddPetrolComponent},
      { path : 'profile', component: MyProfileComponent},
      { path : 'edit-profile', component: EditProfileComponent},
      { path : 'user-managment', component: UserManagementComponent},
      { path : 'machine-reading', component: MachineReadingComponent},
          
    ]},
    { path : 'petrolPumpMain', component: AddPetrolComponent},
    { path : 'payment' , component: PaymentScreenComponent},
  { path : '**', redirectTo : 'login'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
