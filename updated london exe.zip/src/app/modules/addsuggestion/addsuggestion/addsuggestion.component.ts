import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AppComponent } from '../../../app.component';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { HeaderComponent } from '../../header/header/header.component';
import { ServerService } from '../../../service/server.service';

@Component({
    selector: 'app-addsuggestion',
    templateUrl: './addsuggestion.component.html',
    styleUrls: ['./addsuggestion.component.css']
})
export class AddsuggestionComponent implements OnInit {
    addSuggestionForm: FormGroup;
    authObj:any={};
    fileName: any;
    jpeg: boolean;
    fileData: any = '';

    constructor(private router: Router,private server: ServerService, private appC: AppComponent, private spinnerService: Ng4LoadingSpinnerService, public header: HeaderComponent) { }

    ngOnInit() {
        this.checkInput();
        window.scrollTo(0,0);
      }
  
    /** Function for edit from validation */
    checkInput() {
    this.addSuggestionForm = new FormGroup({
        name: new FormControl('', [Validators.required, Validators.minLength(2)]),
        suggestion: new FormControl('', [Validators.required]),
        description: new FormControl(''),
        email: new FormControl('', [Validators.required, Validators.pattern(/^[A-Z0-9_-]+([\.][A-Z0-9_-]+)*@[A-Z0-9-]+(\.[a-zA-Z]{2,5})+$/i)])
    });
    }

    get name(): any {
    return this.addSuggestionForm.get('name');
    }
    get suggestion(): any {
    return this.addSuggestionForm.get('suggestion');
    }
    get description(): any {
    return this.addSuggestionForm.get('description');
    }
    get email(): any {
    return this.addSuggestionForm.get('email');
    }

    /** Function to upload picture */
    profilePhotoSelect(event) {
    var self = this;
    if(event.target.files && event.target.files[0]){
        var type = event.target.files[0].type;
        if(type === 'image/png' || type === 'image/jpg' || type === 'image/jpeg') {
            self.authObj.docFile = event.target.files[0].name;
            self.fileName = event.target.files[0].name;
            var reader = new FileReader()
            reader.onload = (e) =>  {
                self.fileData = e.target['result'];
            }
            reader.readAsDataURL(event.target.files[0]);
            if(type == 'image/jpeg') {
                this.jpeg = true; 
                } else {
                this.jpeg = false;
                }
        } else {
            self.appC.showErrToast("Select only png, jpg and jpeg file.");
            self.authObj.docFile = "";
            self.fileData = "";
            self.fileName = "";
        }
    }
    }

    /** Function to save suggestion details */
    post() {
    if(this.fileData) {
        if(this.jpeg == true) {
        this.fileData = this.fileData.substr(23);
        } else {
        this.fileData = this.fileData.substr(22);
        }
    }
    let data = {
        "eventExternal": {
            "name":"request_save_suggestion_details",
            "key":"mykey"
        },
        "transferObjectMap": {
            "gatewayrequest": {
            "title": this.addSuggestionForm.value.suggestion,
            "description": this.addSuggestionForm.value.description,
            //"imageBase64": this.fileData,
            "name": this.addSuggestionForm.value.name,
            "email": this.addSuggestionForm.value.email
            }
        }
    }
    this.spinnerService.show();
    this.server.postApi('',data,0).subscribe((res) => {
        this.spinnerService.hide();
        if(res.transferObjectMap.statusCode == 200) {
        this.appC.showSuccToast(res.transferObjectMap.message);
        this.router.navigate(['/header/suggestion']);
        } else {
        this.appC.showErrToast(res.transferObjectMap.message);
        }
    }, (err) => {
        this.spinnerService.hide();
        this.appC.showErrToast('We are facing some technical issues, please try after sometime.');
    })
    }

    backToSuggestion()  {
    this.router.navigateByUrl('header/suggestion') ;
    }

}
