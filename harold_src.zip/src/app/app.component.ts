import { Component } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Router, NavigationEnd } from '@angular/router';
import { ServerService } from './server.service';
import { Observable, Subject } from 'rxjs';
declare var $: any;

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.css']
})
export class AppComponent {
    title = 'app';
    private subject= new Subject<any>()


    constructor(private toasterService: ToastrService, private router: Router, public server: ServerService, ) {
        var self = this;
        $( document ).bind( "mousedown", function(event) {
            if(event.button == 0){
                self.checkSession();
            }
        });
    }
  
    ngOnInit() {
        this.initWsSocket();
        this.checkSession();
        // this.router.events.subscribe(x => {
        //     if(x instanceof NavigationEnd) { 
        //         if(x.url != '/exchange') {
        //             if(this.server.currSelectedCoinObj.coin != '') {
        //                 let data1 = {
        //                     messageType:'UNSUBSCRIBE_TICKER',
        //                     params: {
        //                         symbol:this.server.currSelectedPairObj.coin+'_'+this.server.currSelectedCoinObj.coin
        //                     }
        //                 }
        //                 this.server.wsExchange.send(JSON.stringify(data1));
        //                 let data2 = {
        //                     messageType:'UNSUBSCRIBE_ORDER_BOOK',
        //                     params: {
        //                         symbol:this.server.currSelectedPairObj.coin+'_'+this.server.currSelectedCoinObj.coin
        //                     }
        //                 }
        //                 this.server.wsExchange.send(JSON.stringify(data2));
        //                 let data3 = {
        //                     messageType:'UNSUBSCRIBE_TRADE_HISTORY',
        //                     params: {
        //                         symbol:this.server.currSelectedPairObj.coin+'_'+this.server.currSelectedCoinObj.coin
        //                     }
        //                 }
        //                 this.server.wsExchange.send(JSON.stringify(data3));
        //             }
        //         }
        //     }
        // })
    }

    /** Function for fired to child component */
    fireToChild(): Observable<any> {
        return this.subject.asObservable();
    }

    /** Function to init ws */
    initWsSocket() {
        this.server.initSocket();
    }

    /** Function to show success toast */
    showSuccToast(msg) {
        this.toasterService.success(msg, "Currency Exchange");
    }

    /** Function to show error toast */
    showErrToast(msg) {
        this.toasterService.error(msg, "Currency Exchange");
    }

    /** Function to show warning toast */
    showWarnToast(msg) {
        this.toasterService.warning(msg, "Currency Exchange");
    }


    /** Function to show info toast */
    showInfoToast(msg) {
        this.toasterService.info(msg, "Currency Exchange");
    }

    /** Function for check session */
    checkSession() {
        if(localStorage.getItem('token') != null && localStorage.getItem('session') != null) {
            let minDiff = this.diff_minutes(parseInt(localStorage.getItem('session')), new Date().getTime());
            localStorage.setItem('session',new Date().getTime().toString());
            if(minDiff >= 15) {
                this.logout();
            } 
        } else
            localStorage.setItem('session',new Date().getTime().toString());
    }

    /** Function to get diffrence between timestamp */
    diff_minutes(dt2, dt1) {
        var diff = (dt2 - dt1) / 1000;
        diff /= 60;
        return Math.abs(Math.round(diff));
    }

    /** Function for logout user */
    logout() {
        localStorage.clear();
        this.subject.next({ text: "logout" });
        this.showErrToast('Session Expired.');
        this.router.navigate(['']);
            
    }
}
