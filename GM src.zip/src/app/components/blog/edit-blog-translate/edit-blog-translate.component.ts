import { NgxSpinnerService } from 'ngx-spinner';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { ServiceService } from 'src/app/service/service.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-edit-blog-translate',
  templateUrl: './edit-blog-translate.component.html',
  styleUrls: ['./edit-blog-translate.component.css']
})
export class EditBlogTranslateComponent implements OnInit {

  editBlogTranslateForm: FormGroup;
  apiResponse: any = { status: 632 };
  fileData: any = {};
  paramData: any;
  userInfo: any;
  selectedFileName: any;

  constructor(
    private service: ServiceService,
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private spinner: NgxSpinnerService
  ) { }

  ngOnInit() {
    window.scrollTo(0, 0);
    this.form();
    this.getParamData();
    this.getUserInfo();
  }

  form() {
    this.editBlogTranslateForm = new FormGroup({
      title: new FormControl('', [Validators.required, Validators.minLength(2), Validators.maxLength(255)]),
      detail: new FormControl('', [Validators.required, Validators.minLength(2)]),
      authorBy: new FormControl('', [Validators.required, Validators.minLength(2), Validators.maxLength(255)])
    });
  }

  getUserInfo() {
    this.service.userInfo.subscribe(userData => {
      this.userInfo = userData;
    });
  }

  getParamData() {
    this.activatedRoute.params.subscribe(param => {
      this.paramData = param;
      this.getBlogData();
    });
  }

  getBlogData() {
    this.service.postMethod(`blog/admin/get-blog-detail?contentId=${encodeURIComponent(this.service.encrypt(this.paramData.id))}&language=${encodeURIComponent(this.service.encrypt(this.paramData.lang))}`, {}, 1).subscribe(success => {
      if (success.status === 628) {
        if (success.data.description) {
          this.editBlogTranslateForm.patchValue({
            title: success.data.title,
            detail: success.data.description,
            authorBy: success.data.author
          });
        }
        if (success.data.image) {
          this.fileData.fileData = success.data.image;
          this.selectedFileName = success.data.image;
          this.fileData.valid = true;
          this.fileData.url = success.data.image;
        }
      }
    }, error => {
    });
  }

  editTranslateBlog() {
    this.spinner.show();
    if (this.editBlogTranslateForm.invalid || !this.fileData.valid || !this.fileData.url) {
      this.spinner.hide();
      return;
    }
    const formData = new FormData();
    const apireq = JSON.stringify({
        author: this.editBlogTranslateForm.value.authorBy,
        contentId: this.paramData.id,
        description: this.editBlogTranslateForm.value.detail,
        image: this.fileData.url,
        ipAddress: this.userInfo.ip,
        location: this.userInfo.city + ',' + this.userInfo.country_name,
        title: this.editBlogTranslateForm.value.title
    });
    formData.append('blogDto', this.service.encrypt(apireq));
    this.service.postMethod('blog/admin/edit-blog-translation', formData, 2).subscribe(success => {
      this.spinner.hide();
      if (success.status === 632) {
        this.router.navigate(['/blog-translate-list/' + this.paramData.slug]);
      }
    }, error => {
      this.spinner.hide();
    });

  }

  getFile(event) {
    this.fileData = this.service.uploadImage(event);
    this.selectedFileName = this.fileData.fileData.name;
    if (this.fileData.error === 'formatError') {
      this.fileData.error = 'Image accept only jpg, jpeg, png format.';
    } else {
      if (this.fileData.error === 'sizeError') {
        this.fileData.error = 'Image size should be less than 5Mb.';
      }
    }
    if (this.fileData.valid) {
      this.uploadFile();
    }
  }

  uploadFile() {
    this.spinner.show();
    const formData = new FormData();
    formData.append('file', this.fileData.fileData);
    this.service.postMethod('account/uploadFile', formData, 2).subscribe(success => {
      this.spinner.hide();
      this.fileData.url = success.fileName;
    }, error => {
      this.spinner.hide();
      this.fileData.url = null;
    });
  }

}
