import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-student-map',
  templateUrl: './student-map.component.html',
  styleUrls: ['./student-map.component.css']
})
export class StudentMapComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
