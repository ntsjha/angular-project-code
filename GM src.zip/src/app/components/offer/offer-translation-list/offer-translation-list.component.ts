import { ServiceService } from './../../../service/service.service';
import { ActivatedRoute } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-offer-translation-list',
  templateUrl: './offer-translation-list.component.html',
  styleUrls: ['./offer-translation-list.component.css']
})
export class OfferTranslationListComponent implements OnInit {

  translationList: any = [];
  paramData: any;
  languageArr: any = [];

  constructor(
    private activatedRoute: ActivatedRoute,
    private service: ServiceService,
    private spinner: NgxSpinnerService
  ) { }

  ngOnInit() {
    this.getParamData();
    window.scrollTo(0, 0);
  }

  getParamData() {
    this.activatedRoute.params.subscribe(param => {
      this.paramData = param;
      this.getTranslationList();
    });
  }

  getTranslationList() {
    this.service.getMethod(`rewards/get-translation-list?offerContentId=${this.paramData.id}`, 1).subscribe((success: any) => {
      if (success.status === 1368) {
        this.translationList = success.data.Translation;
        this.translationList.forEach(element => {
          if(element.updatedBy == null) {
            element.updatedAt = null;
          }
        });
        this.languageArr = success.data.languageList.data;
      } else {
        this.translationList = [];
      }
    }, error => {
      this.translationList = [];
    });
  }

  getLanguage(data) {
    let lang;
    this.languageArr.forEach((element, i) => {
      if (data.languageId === element.languageId) {
        lang = element.languageShortName;
      }
    });
    return lang;
  }

}
