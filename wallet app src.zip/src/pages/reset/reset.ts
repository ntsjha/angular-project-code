import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { FormGroup, FormControl } from "@angular/forms";
import { Validators } from "@angular/forms";
import { ServiceServicesProvider } from "../../providers/service-services/service-services";
import { LoginPage } from "../login/login";

@IonicPage()
@Component({
  selector: 'page-reset',
  templateUrl: 'reset.html',
})
export class ResetPage {
  form: FormGroup
  result: any;
  constructor(public navCtrl: NavController, public navParams: NavParams, private server: ServiceServicesProvider) {
  }

  ngOnInit() {
    this.form = new FormGroup({

      newPass: new FormControl('', [Validators.required, Validators.pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})/i)]),
      confirmPass: new FormControl('', [Validators.required])
    }, passwordMatchValidator)

    /** Function for password match and mismatch */
    function passwordMatchValidator(g: FormGroup) {
      let pass = g.get('newPass').value;
      let confPass = g.get('confirmPass').value;
      if (pass != confPass) {
        g.get('confirmPass').setErrors({ mismatch: true });
      } else {
        g.get('confirmPass').setErrors(null)
        return null
      }
    }
  }


  get newPass(): any {
    return this.form.get('newPass')
  }

  get confirmPass(): any {
    return this.form.get('confirmPass')
  }

  back() {
    this.navCtrl.pop()
  }

  submit() {
    if (navigator.onLine) {
      this.server.presentLoading();
      let data = {
        "userId": localStorage.getItem('userId'),
        "password": this.form.value.newPass
      }
      this.server.postApi(data, 'user/resetPassword', 0).subscribe((response: any) => {
        this.server.dismissLoading();
        if (response.response_code == 200) {
          this.navCtrl.setRoot(LoginPage)
          this.server.presentToast(response.response_message)
        } else if (response.response_code == 403 || response.response_code == 409 || response.response_code == 401) {
          this.server.presentToast(response.response_message)
          this.server.logout();
        }
        else
          this.server.presentToast(response.response_message)
      }, err => {
        this.server.dismissLoading();
        this.server.presentToast('Something went wrong')
      })
    } else
      this.server.presentToast('Your internet connection seems to be lost')
  }

  signin() {
    this.navCtrl.setRoot(LoginPage)
  }

}
