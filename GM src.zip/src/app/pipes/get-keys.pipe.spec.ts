import { GetKeysPipe } from './get-keys.pipe';

describe('GetKeysPipe', () => {
  it('create an instance', () => {
    const pipe = new GetKeysPipe();
    expect(pipe).toBeTruthy();
  });
});
