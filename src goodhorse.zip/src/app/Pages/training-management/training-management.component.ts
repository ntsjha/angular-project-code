import { Component, OnInit } from '@angular/core';
import { ServiceService } from 'src/app/Shared/service.service';
import { Router } from '@angular/router';
import { AngularFirestore } from '@angular/fire/firestore';
declare var $:any;

@Component({
  selector: 'app-training-management',
  templateUrl: './training-management.component.html',
  styleUrls: ['./training-management.component.css']
})
export class TrainingManagementComponent implements OnInit {
  templateList:any=[];
  pageNo:number = 1;
  searchText: any;
  templateId: any;
  constructor(public service:ServiceService,public route:Router,public firestore:  AngularFirestore) { }

  ngOnInit() {
    this.getTrainingTemplate();
  }

  // Get Training Template List 
  getTrainingTemplate(){
    this.searchText='';
    this.service.showSpinner();
    this.service.getAdminTrainingTemplate().subscribe(res=>{
     this.templateList = res.map(item => {        
        return {
          id: item.payload.doc.id,
          ...item.payload.doc.data()
        };
    })
    console.log('templateList====>', JSON.stringify(this.templateList));
    this.service.hideSpinner();
  })
}

// Search Functionality
search(){
  console.log('template Search-->>',this.searchText)
  var searchData = this.templateList.filter(x=>(x.templateName == this.searchText));
  this.templateList = searchData;
}

deleteFuction(templateId){
this.templateId = templateId;
console.log('template--->>>',this.templateId)
$('#delete').modal('show');
}

onDelete(){
  this.firestore.collection('adminTrainingTemplate').doc(this.templateId).delete();
  this.service.showSuccess('Template has been deleted successfully.');
}


}
