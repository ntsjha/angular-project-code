import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageBankRegistrationComponent } from './manage-bank-registration.component';

describe('ManageBankRegistrationComponent', () => {
  let component: ManageBankRegistrationComponent;
  let fixture: ComponentFixture<ManageBankRegistrationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManageBankRegistrationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageBankRegistrationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
