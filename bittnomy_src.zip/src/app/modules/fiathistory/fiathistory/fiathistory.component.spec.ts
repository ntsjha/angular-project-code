import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FiathistoryComponent } from './fiathistory.component';

describe('FiathistoryComponent', () => {
  let component: FiathistoryComponent;
  let fixture: ComponentFixture<FiathistoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FiathistoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FiathistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
