import { ActivatedRoute } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { ServiceService } from 'src/app/service/service.service';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-job-translate-list',
  templateUrl: './job-translate-list.component.html',
  styleUrls: ['./job-translate-list.component.css']
})
export class JobTranslateListComponent implements OnInit {

  paramData: any;
  translationList: any = [];
  decryptedData: any;
  languageArr: any = [];

  constructor(
    private activatedRoute: ActivatedRoute,
    private service: ServiceService,
    private spinner: NgxSpinnerService
  ) { }

  ngOnInit() {
    window.scrollTo(0, 0);
    this.getParamData();
  }

  getParamData() {
    this.activatedRoute.params.subscribe(success => {
      this.paramData = success;
      this.getTranslationList();
    });
  }

  getTranslationList() {
    this.spinner.show();
    this.service.getMethod(`career/admin/get-job-translation-list?contentId=${encodeURIComponent(this.service.encrypt(this.paramData.id))}`, 1).subscribe((success: any) => {
      this.spinner.hide();
      this.decryptedData = success.data ? JSON.parse(this.service.decrypt(success.data)) : {};
      console.log(this.decryptedData)
      if (this.decryptedData.status === 755) {
        this.languageArr = this.decryptedData.data.languageList.data;
        this.decryptedData.data.jobTranslationList.forEach(element => {
          if (element.updatedBy) {
            this.translationList.push({
              translationId: element.translationId,
              title: element.title,
              description: element.description,
              createdAt: element.createdAt,
              updatedAt: (element.updatedBy == null) ? null : element.updatedAt,
              createdBy: element.createdBy,
              updatedBy: element.updatedBy,
              file: element.file,
              noOfOpening: element.noOfOpening,
              slug: element.slug,
              fkLanguageId: element.fkLanguageId,
            });
          } else {
            this.translationList.push({
              translationId: element.translationId,
              title:  null,
              description:  null,
              createdAt:  null,
              updatedAt:  null,
              createdBy:  null,
              updatedBy:  null,
              file:  null,
              noOfOpening:  null,
              slug:  null,
              fkLanguageId: element.fkLanguageId,
            });
          }
        });
      } else {
        this.translationList = [];
      }
    }, error => {
      this.spinner.hide();
      this.translationList = [];
    });
  }

  getLanguage(data) {
    let lang;
    this.languageArr.forEach((element, i) => {
      if (data.fkLanguageId === element.languageId) {
        lang = element.languageShortName;
      }
    });
    return lang;
  }

}
