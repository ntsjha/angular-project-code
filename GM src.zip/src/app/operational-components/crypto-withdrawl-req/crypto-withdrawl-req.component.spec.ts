import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CryptoWithdrawlReqComponent } from './crypto-withdrawl-req.component';

describe('CryptoWithdrawlReqComponent', () => {
  let component: CryptoWithdrawlReqComponent;
  let fixture: ComponentFixture<CryptoWithdrawlReqComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CryptoWithdrawlReqComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CryptoWithdrawlReqComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
