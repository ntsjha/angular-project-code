import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { SignupComponent } from './signup/signup.component';

import { Tab1Page } from './tab1/tab1.page';
import { ProfileComponent } from './profile/profile.component';
import { ViewComponent } from './profile/view/view.component';
const routes: Routes = [
  { path: '', loadChildren: './tabs/tabs.module#TabsPageModule' },
  
  {path :'signup', component: SignupComponent },
  {path :'home', component: HomeComponent },
  {path: 'work', loadChildren: './work/work.module#WorkPageModule' },
  {path :'profile', component: ProfileComponent },
  {path :'view', component: ViewComponent },
  
  
 


];
@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule {}
