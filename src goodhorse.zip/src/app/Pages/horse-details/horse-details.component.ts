import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AngularFirestore } from '@angular/fire/firestore';
import { HorseHealth } from 'src/app/Shared/horseHealth.model';
import { HorseHealthRugs } from 'src/app/Shared/horseHealthRugs.model';
import { HorseHealthService } from 'src/app/Shared/horseHealthService.model';
import { ServiceService } from 'src/app/Shared/service.service';
import { HorseTack } from 'src/app/Shared/horseTack.model';
import { HorseTraining } from 'src/app/Shared/horseTraining.model';
import { HorseEvents } from 'src/app/Shared/horseEvents.model';
import { HorseContacts } from 'src/app/Shared/horseContacts.model';
import { Employee } from 'src/app/Shared/employee.model';
import { isNgTemplate } from '@angular/compiler';
import { database } from 'firebase';
import { HorseList } from 'src/app/Shared/horseList.model';
// declare var $: any;

@Component({
  selector: 'app-horse-details',
  templateUrl: './horse-details.component.html',
  styleUrls: ['./horse-details.component.css']
})

export class HorseDetailsComponent implements OnInit {
  horseData;
  ownerData;

  horseHealth: HorseHealth[]
  horseHealthRugs: HorseHealthRugs[]
  horseHealthService: HorseHealthService[]
  p: number = 1;
  pageSize = 5;
  total = 0
  totalRugs = 0
  totalService = 0
  searchText: string = "";
  horseTack: HorseTack[]
  horseTackLength: number;
  horseTraining: HorseTraining[]
  horseTrainingLength: number;
  horseEvents = [];
  horseContacts: HorseContacts[]
  horseEventsLength: number;
  horseContacLength: number;
  employeeData
  horseId: any;
  userId: any;
  tab: any;
  UserDetails: any = [];
  horseEventss: any[];
  horseImage: any;
  HorseImage: any;
  constructor(private route: ActivatedRoute, private router: Router, private afb: AngularFirestore, private service: ServiceService) {
    window.scroll(0, 0)

  }

  async ngOnInit() {
    this.route.params.subscribe(params => {
      var data = params['id'].split('-');
      this.horseId = data[2];
      this.userId = data[0];
      this.tab = data[1]
      // console.log("details id ===>>",data)
    });
    await this.getUserDetailsFunc();
    await this.getHorseDetailFunc();
    await this.getHorseHealth();
    await this.getHorseHealthRugs();
    await this.getHorseService();
    // this.getHorseTack();
    await this.getHorseContacts();
    await this.getHorseTraining();
    await this.getHorseEvents();
  }

  // Get UserDetails
  getUserDetailsFunc() {
    this.service.showSpinner();
    this.service.getEmployeeDetails().subscribe(userArr => {
      var userDetail = userArr.map(x => {
        return {
          id: x.payload.doc.id,
          ...x.payload.doc.data()
        }
      })
      // console.log('Horsedata--->>',JSON.stringify(userDetail))
      this.UserDetails = userDetail.filter(x => (x.id == this.userId));
      console.log('UserDetails--->>', JSON.stringify(this.UserDetails))
      this.service.hideSpinner();
    }, err => {
      this.service.hideSpinner();
      // console.log(err)
    })
  }

  // Get Horse Details
  getHorseDetailFunc() {
    this.service.showSpinner()
    this.service.getHorseList(this.userId).subscribe(actionArray => {
      console.log('=========>', actionArray)
      var horseList = actionArray.map(item => {
        // console.log('Items====>', item)
        return {
          id: item.payload.doc.id,
          ...item.payload.doc.data()

        }
      })
   
      console.log('Horsedata--->>', JSON.stringify(horseList))
      this.horseData = horseList.filter(x => (x.id == this.horseId));
      this.HorseImage=  this.horseData[0].horseImage? this.horseData[0].horseImage:'../../../assets/img/profile-img.jpg'
      console.log('horseData--->>', JSON.stringify(this.horseData))
      this.service.hideSpinner();
    });
  }

  // Tab Navigation 
  tabNav(tabName) {
    var navData = this.userId + '-' + tabName + '-' + this.horseId;
    this.router.navigate(['/userManagement/userManagementView/horseDetails', navData]);
  }

  // Get Horse Health 
  getHorseHealth() {
    var horseHealth = []
    this.service.showSpinner();
    this.service.getHorseHealth().subscribe(actionArray => {
      horseHealth = actionArray.map(item => {
        return {
          id: item.payload.doc.id,
          ...item.payload.doc.data()

        } as HorseHealth;
      })
      this.horseHealth = horseHealth.filter(x => x.horseID === this.horseId)
      this.service.hideSpinner();
      this.total = this.horseHealth.length
      console.log('health====>', this.horseHealth)
    });
  }

  // Get HorseHealth Rugs
  getHorseHealthRugs() {
    var horseHealthRugs = [];
    this.service.showSpinner();
    this.service.getHorserHealthRugs().subscribe(res => {
     horseHealthRugs = res.map(item => {
        console.log(item)
        return {
          id: item.payload.doc.id,
          ...item.payload.doc.data()
        } as HorseHealthRugs
      })
      this.horseHealthRugs = horseHealthRugs.filter(x => x.horseID === this.horseId)
      this.service.hideSpinner();
      this.totalRugs = this.horseHealthRugs.length
      console.log('Rug====>', this.horseHealthRugs)
    })
  }

  // Get Horse Services
  getHorseService() {
    var horseHealthService = []
    this.service.showSpinner();
    this.service.getHorseHealthService().subscribe(res => {
      horseHealthService = res.map(item => {
        return {
          id: item.payload.doc.id,
          ...item.payload.doc.data()
        } as HorseHealthService
      })
      this.horseHealthService = horseHealthService.filter(x => x.horseID === this.horseId)
      this.service.hideSpinner();
      this.totalService = this.horseHealthService.length
      console.log('Service====>', this.horseHealthService)
    })
  }

  // Get Horse Tack
  getHorseTack() {
    this.service.showSpinner();
    this.service.getGlobalTack().subscribe(res => {
      this.horseTack = res.map(item => {
        return {
          id: item.payload.doc.id,
          ...item.payload.doc.data()
        } as HorseTack
      })
      this.service.hideSpinner();
      this.horseTackLength = this.horseTack.length;
    })
  }

  // Get Horse Training
  getHorseTraining() {
    var horseTraining = [];
    this.service.showSpinner();
    this.service.getHorseTraining().subscribe(res => {
      horseTraining = res.map(item => {
        return {
          id: item.payload.doc.id,
          ...item.payload.doc.data()
        } as HorseTraining
      })
      this.horseTraining = horseTraining.filter(x => (x.horseID === this.horseId));
      console.log('GlobalhorseTraining ==>', this.horseTraining, this.horseId)
      this.service.hideSpinner();
      this.horseTrainingLength = this.horseTraining.length

      console.log('Trainng===>', this.horseTraining)
    })
  }

  // Get Horse  Contacts
  getHorseContacts() {
    var horseContacts = [];
    this.service.showSpinner();
    this.service.getHorseContact().subscribe(res => {
      horseContacts = res.map(item => {
        return {
          id: item.payload.doc.id,
          ...item.payload.doc.data()
        } as HorseContacts
      })
      this.horseContacts = horseContacts.filter(x => (x.horseID === this.horseId));
      console.log('GlobalContacts ==>', this.horseContacts, this.horseId)
      this.service.hideSpinner();
      this.horseContacLength = this.horseContacts.length
    })
  }

  // Get Horse Events
  getHorseEvents() {
    var horseEvents = [];
    this.service.showSpinner();
    this.service.getHorseEvents().subscribe(res => {
      horseEvents = res.map(item => {
        return {
          id: item.payload.doc.id,
          ...item.payload.doc.data()
        } as HorseEvents
      })
      // console.log('GlobalEvents ==>',horseEvents,this.horseId)
      this.horseEvents = horseEvents.filter(x => (x.horseID === this.horseId));
      console.log('GlobalEvents ==>', this.horseEvents, this.horseId)
      this.service.hideSpinner();
      this.horseEventsLength = this.horseEvents.length
    });
  }


  viewOwner() {
    this.router.navigate(['/userManagement/userManagementView/', this.userId])
  }
  page(event) {
    // console.log(event);
    this.p = event
  }


}