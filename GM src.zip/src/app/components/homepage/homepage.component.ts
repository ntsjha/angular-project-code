import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormArray, FormControl, Validators } from '@angular/forms';
import { ServiceService } from 'src/app/service/service.service';
import { ActivatedRoute, Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
declare var $: any;

@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css']
})
export class HomepageComponent implements OnInit {
  homepageForm: FormGroup;
  homepageEditForm: FormGroup;
  modeOfAction: string;
  selectedLanguage: string;
  currentUser: any;
  canEdit: boolean;
  canView: boolean;
  translation: boolean;
  langName: string;
  homepageContent: any;
  flashMessageContent: any;
  whyChooseUsContent: any;
  startGuideData: any;
  editWhyChooseUs = '';
  indexRemove: any;
  deleteContent: any;
  startQuick: FormArray;
  homepageArray: FormArray;
  canAdd: boolean;
  showApiMessage: boolean;
  response: any;
  flashMessageUpdated = false;
  startQuickGuideUpdated = false;
  whyChooseUpdatedUpdated = false;
  featureContentUpdated = false;
  featureContentErrorArray = [];
  startQuickErrorArray = [];

  constructor(private service: ServiceService, private activatedRoutes: ActivatedRoute, private fb: FormBuilder, private spinner: NgxSpinnerService, private router: Router) { }

  ngOnInit() {
    window.scrollTo(0, 0);
    this.activatedRoutes.params.subscribe((data) => {
      this.modeOfAction = data.id1;
      this.languageSelection(data.id2);
    });
    this.modeSelection();
    this.service.currentUserInfo.subscribe((response) => {
      this.currentUser = response;
    });
    this.homepageEditForm = this.fb.group({
      whychooseUs: new FormControl('', [Validators.required, Validators.maxLength(255), Validators.minLength(3)]),
      flashMessage: new FormControl('', [Validators.required, Validators.maxLength(255), Validators.minLength(3)]),
      startQuick: this.fb.array([]),
      homepageArray: this.fb.array([]),
    });


    if (this.translation) {
      this.getHomepageTranslation();
    } else {
      this.getHomepageContent();
      this.getFlashMessage();
      this.getStartGuide();
      this.getWhyChooseUs();
    }
  }

  openModal(id, mode) {
    this.indexRemove = id;
    this.deleteContent = mode;
    $('#deleteModal').modal('show');
  }

  updateImage(updatedForm, index, event) {
    const obj = this.service.uploadImage(event);
    if (obj.valid) {
      const formData = new FormData();
      formData.append('file', obj.fileData);
      this.spinner.show();
      this.service.postMethod('account/uploadFile', formData, 2)
        .subscribe((response) => {
          if (updatedForm === 'startQuick') {
            this.startQuick.at(index).patchValue({
              image: response.fileName
            });
            this.startQuickErrorArray[index].error = false;
            const id = 'startquick' + index;
            this.loadImageOnView(response.fileName, id);
          } else {
            this.homepageArray.at(index).patchValue({
              image: response.fileName
            });
            this.featureContentErrorArray[index].error = false;
            const id = 'featureContent' + index;
            this.loadImageOnView(response.fileName, id);
          }
        }, (error) => {
          this.spinner.hide();
          if (updatedForm === 'startQuick') {
            this.startQuickErrorArray[index].error = true;
            this.startQuickErrorArray[index].errorMsg = 'Something went wrong please try again after sometime.';
          } else {
            this.featureContentErrorArray[index].error = true;
            this.featureContentErrorArray[index].errorMsg = 'Something went wrong please try again after sometime.';
          }
        });
    } else {
      if (updatedForm === 'startQuick') {
        this.startQuickErrorArray[index].error = true;
        if (obj.error === 'formatError') {
          this.startQuickErrorArray[index].errorMsg = 'Image format should be in JPEG, PNG & JPG.';
        } else {
          this.startQuickErrorArray[index].errorMsg = 'Image size be should be less than 5MB';
        }
      } else {
        this.featureContentErrorArray[index].error = true;
        if (obj.error === 'formatError') {
          this.featureContentErrorArray[index].errorMsg = 'Image format should be in JPEG, PNG & JPG.';
        } else {
          this.featureContentErrorArray[index].errorMsg = 'Image size be should be less than 5MB';
        }
      }
    }
  }

  getHomepageTranslation() {
    this.service.postMethod('static/admin/get-homepage-translation?language=' + encodeURIComponent(this.service.encrypt(this.selectedLanguage)), {}, 1)
      .subscribe((response) => {
        this.spinner.hide();
        if (response.status === 1092) {
          this.whyChooseUsContent = response.data.whyChooseUsTranslation[0];
          this.editWhyChooseUs = response.data.whyChooseUsTranslation[0].description;
          this.homepageEditForm.patchValue({
            whychooseUs: response.data.whyChooseUsTranslation[0].description,
          });
          this.flashMessageContent = response.data.flashMessageTranslation[0];
          this.homepageEditForm.patchValue({
            flashMessage: response.data.flashMessageTranslation[0].flashMessage,
          });
          this.startGuideData = response.data.startQuickTranslation;
          this.loadStartQuick();
          this.homepageContent = response.data.featureTranslation;
          this.loadHomepageContent();
        }
      }, (error) => {
        this.apiErrorResponse(error);
      });
  }

  removeContent() {
    this.spinner.show();
    if (this.deleteContent === 'startQuick') {
      const currID = this.homepageEditForm.value.startQuick[this.indexRemove].startGuideId;
      this.service.postMethod('static/admin/delete-start-guide-data?ipAddress=' + encodeURIComponent(this.service.encrypt(this.currentUser.ip)) + '&location=' + encodeURIComponent(this.service.encrypt(this.currentUser.city + ',' + this.currentUser.country_name)) + '&startGuideId=' + encodeURIComponent(this.service.encrypt(currID)), {}, 1)
        .subscribe((response) => {
          this.spinner.hide();
          this.startQuick.removeAt(this.indexRemove);
          this.startQuickErrorArray.splice(this.indexRemove, 1);
          $('#deleteModal').modal('hide');
          this.deleteContent = '';
          this.indexRemove = '';
        }, (error) => {
          this.spinner.hide();
        });
    } else {
      const currID = this.homepageEditForm.value.homepageArray[this.indexRemove].featureContentId;
      this.service.postMethod('static/admin/delete-features-content?ipAddress=' + encodeURIComponent(this.service.encrypt(this.currentUser.ip)) + '&location=' + encodeURIComponent(this.service.encrypt(this.currentUser.city + ',' + this.currentUser.country_name)) + '&featureContentId=' + encodeURIComponent(this.service.encrypt(currID)), {}, 1)
        .subscribe((response) => {
          this.spinner.hide();
          this.homepageArray.removeAt(this.indexRemove);
          this.featureContentErrorArray.splice(this.indexRemove, 1);
          this.deleteContent = '';
          this.indexRemove = '';
          $('#deleteModal').modal('hide');
        }, (error) => {
          this.spinner.hide();
        });
    }
  }

  loadStartQuick() {
    if (this.translation) {
      this.startGuideData.forEach((item, i) => {
        this.startQuick = this.homepageEditForm.get('startQuick') as FormArray;
        this.startQuick.push(this.addStartQuick(item.title, item.description, item.image, item.translationId));
        this.loadImageOnView(item.image, 'startquick' + i);
        this.startQuickErrorArray.push({
          error: false,
          errorMsg: '',
        });
      });
    } else {
      this.startGuideData.forEach((item, i) => {
        this.startQuick = this.homepageEditForm.get('startQuick') as FormArray;
        this.startQuick.push(this.addStartQuick(item.title, item.description, item.image, item.startGuideId));
        this.loadImageOnView(item.image, 'startquick' + i);
        this.startQuickErrorArray.push({
          error: false,
          errorMsg: '',
        });
      });
    }
  }

  addStartQuick(title, description, image, startQuickId): FormGroup {
    return this.fb.group({
      title: new FormControl(title, [Validators.required, Validators.maxLength(255), Validators.minLength(2)]),
      description: new FormControl(description, [Validators.required, Validators.minLength(3), Validators.maxLength(255)]),
      image: new FormControl(image),
      startGuideId: new FormControl(startQuickId),
    });
  }



  addMoreStartQuick() {
    this.startQuick = this.homepageEditForm.get('startQuick') as FormArray;
    this.startQuick.push(this.addStartQuick(null, null, null, ''));
    this.startQuickErrorArray.push({
      error: false,
      errorMsg: '',
    });
  }

  loadHomepageContent() {
    if (this.translation) {
      this.homepageContent.forEach((item, i) => {
        this.homepageArray = this.homepageEditForm.get('homepageArray') as FormArray;
        this.homepageArray.push(this.addHomePage(item.description, item.translationId, item.image, item.title));
        this.loadImageOnView(item.image, 'featureContent' + i);
        this.featureContentErrorArray.push({
          error: false,
          errorMsg: '',
        });
      });
    } else {
      this.homepageContent.forEach((item, i) => {
        this.homepageArray = this.homepageEditForm.get('homepageArray') as FormArray;
        this.homepageArray.push(this.addHomePage(item.description, item.featureContentId, item.image, item.title));
        this.loadImageOnView(item.image, 'featureContent' + i);
        this.featureContentErrorArray.push({
          error: false,
          errorMsg: '',
        });
      });
    }
  }

  addHomePage(description, featureContentId, image, title) {
    return this.fb.group({
      description: new FormControl(description, [Validators.required, Validators.maxLength(255), Validators.minLength(3)]),
      featureContentId: new FormControl(featureContentId),
      image: new FormControl(image),
      title: new FormControl(title, [Validators.required, Validators.maxLength(30), Validators.minLength(3)]),
    });
  }

  addMoreHomePage() {
    this.homepageArray = this.homepageEditForm.get('homepageArray') as FormArray;
    this.homepageArray.push(this.addHomePage(null, '', null, null));
  }

  languageSelection(lang) {
    if (lang === 'th') {
      this.selectedLanguage = 'th';
      this.langName = 'Thai';
      this.translation = true;
    } else if (lang === 'ch') {
      this.selectedLanguage = 'ch';
      this.langName = 'Chinese';
      this.translation = true;
    } else {
      this.selectedLanguage = 'en';
      this.langName = 'English';
      this.translation = false;
    }
  }

  modeSelection() {
    if (this.modeOfAction === 'edit' || this.modeOfAction === 'add') {
      this.modeOfAction = 'edit';
      this.canEdit = true;
      this.canView = false;
      this.canAdd = false;
    } else {
      this.canEdit = false;
      this.canAdd = false;
      this.canView = true;
    }
  }

  getHomepageContent() {
    this.service.postMethod('static/admin/get-home-page-feature-content/?languageShortName=' + encodeURIComponent(this.service.encrypt(this.selectedLanguage)), {}, 1)
      .subscribe((response) => {
        if ((this.modeOfAction === 'edit') || (this.modeOfAction === 'view')) {
          this.homepageContent = response.data;
          this.loadHomepageContent();
        }
      });
  }

  loadImageOnView(imageUrl, id) {
    if (imageUrl) {
      this.service.getMethod('account/convert-image-base64?imageUrl=' + this.service.imageUrl + imageUrl, 1)
        .subscribe((res: any) => {
          this.spinner.hide();
        }, error => {
          this.spinner.hide();
          if (error.error.text) {
            const image = 'data:image/jpg;base64,' + error.error.text;
            $('#' + id).attr('src', image);
            return image;
          }
        });
    }
  }

  getFlashMessage() {
    this.service.postMethod('static/admin/get-flash-message-content/?languageShortName=' + encodeURIComponent(this.service.encrypt(this.selectedLanguage)), {}, 1)
      .subscribe((response) => {
        if ((this.modeOfAction === 'edit') || (this.modeOfAction === 'view')) {
          this.flashMessageContent = response.data[0];
          this.homepageEditForm.patchValue({
            flashMessage: response.data[0].flashMessage,
          });
        }
      });
  }

  getStartGuide() {
    this.service.postMethod('static/admin/get-start-guide-data/?languageShortName=' + encodeURIComponent(this.service.encrypt(this.selectedLanguage)), {}, 1)
      .subscribe((response) => {
        if ((this.modeOfAction === 'edit') || (this.modeOfAction === 'view')) {
          this.startGuideData = response.data;
          this.loadStartQuick();
        }
      });
  }

  getWhyChooseUs() {
    this.service.postMethod('static/admin/get-why-choose-us/?languageShortName=' + encodeURIComponent(this.service.encrypt(this.selectedLanguage)), {}, 1)
      .subscribe((response) => {
        if ((this.modeOfAction === 'edit') || (this.modeOfAction === 'view')) {
          this.whyChooseUsContent = response.data[0];
          this.editWhyChooseUs = response.data[0].description;
          this.homepageEditForm.patchValue({
            whychooseUs: response.data[0].description
          });
        }
      });
  }

  submitHomepage() {
    if (this.homepageEditForm.invalid) {
      return;
    }
    const startImgError = this.startQuickErrorArray.findIndex((x) => x.error === true);
    if (startImgError !== -1) {
      return;
    }
    const homepageImgError = this.featureContentErrorArray.findIndex((x) => x.error === true);
    if (homepageImgError !== -1) {
      return;
    }
    if (this.translation) {
      this.submitTranslation();
    } else {
      this.submitEnglishLang();
    }
  }

  submitEnglishLang() {
    const flash = {
      flashContentId: this.service.encrypt(this.flashMessageContent.flashContentId),
      flashMessage: this.service.encrypt(this.homepageEditForm.value.flashMessage),
      ipAddress: this.service.encrypt(this.currentUser.ip),
      location: this.service.encrypt(this.currentUser.city + ',' + this.currentUser.country_name)
    };
    this.service.postMethod('static/admin/update-flash-message-content', flash, 1)
      .subscribe((response) => {
        if (response.status === 680) {
          this.flashMessageUpdated = true;
          this.showApiMessage = true;
          this.response = response;
          this.response.status = 200;
          this.changeDir();
        }
      }, (error) => {
        this.apiErrorResponse(error);
      });

    const why = {
      whyChooseUsId: this.service.encrypt(this.whyChooseUsContent.whyChooseUsId),
      description: this.service.encrypt(this.homepageEditForm.value.whychooseUs),
      ipAddress: this.service.encrypt(this.currentUser.ip),
      location: this.service.encrypt(this.currentUser.city + ',' + this.currentUser.country_name),
    };
    this.service.postMethod('static/admin/update-why-choose-us-data', why, 1)
      .subscribe((response) => {
        if (response.status === 684) {
          this.whyChooseUpdatedUpdated = true;
          // this.apiSuccessResponse(response);
          this.changeDir();
        }
      }, (error) => {
        this.apiErrorResponse(error);
      });
    const feature = {
      featuresContentDto: this.homepageEditForm.value.homepageArray,
      ipAddress: this.currentUser.ip,
      location: this.currentUser.city + ',' + this.currentUser.country_name
    };
    this.service.postMethod('static/admin/add-features-content?fetureContentDto=' + encodeURIComponent(this.service.encrypt(JSON.stringify(feature))), {}, 1)
      .subscribe(res => {
        if (res.status === 192) {
          this.featureContentUpdated = true;
          // this.apiSuccessResponse(res);
          this.changeDir();
        } else {
          this.showApiMessage = true;
          this.response = res;
        }
      }, (error) => {
        this.apiErrorResponse(error);
      });

    const startQ = {
      addStartGuideDto: this.homepageEditForm.value.startQuick,
      ipAddress: this.currentUser.ip,
      location: this.currentUser.city + ',' + this.currentUser.country_name,
    };
    this.service.postMethod('static/admin/add-start-guide?startDto=' + encodeURIComponent(this.service.encrypt(JSON.stringify(startQ))), {}, 1)
      .subscribe(resp => {
        if (resp.status === 188) {
          this.startQuickGuideUpdated = true;
          // this.apiSuccessResponse(resp);
          this.changeDir();
        } else {
          this.showApiMessage = true;
          this.response = resp;
        }
      }, (error) => {
        this.apiErrorResponse(error);
      });

  }

  submitTranslation() {
    this.spinner.show();
    const flash = {
      translationId: this.service.encrypt(this.flashMessageContent.flashContentId),
      flashMessage: this.service.encrypt(this.homepageEditForm.value.flashMessage),
      ipAddress: this.service.encrypt(this.currentUser.ip),
      location: this.service.encrypt(this.currentUser.city + ',' + this.currentUser.country_name),
      languageShortName: this.service.encrypt('hardcoded'),
    };
    this.service.postMethod('static/admin/update-flash-message-translation-content', flash, 1)
      .subscribe((response) => {
        this.spinner.hide();
        if (response.status === 682) {
          this.flashMessageUpdated = true;
          this.showApiMessage = true;
          this.response = response;
          this.response.status = 200;
          // this.apiSuccessResponse(response);
          this.changeDir();
        } else {
          this.showApiMessage = true;
          this.response = response;
        }
      }, (error) => {
        this.apiErrorResponse(error);
      });
    const why = {
      translationId: this.service.encrypt(this.whyChooseUsContent.translationId),
      description: this.service.encrypt(this.homepageEditForm.value.whychooseUs),
      ipAddress: this.service.encrypt(this.currentUser.ip),
      location: this.service.encrypt(this.currentUser.city + ',' + this.currentUser.country_name),
    };
    this.service.postMethod('static/admin/update-why-choose-us-translation-data', why, 1)
      .subscribe((response) => {
        this.spinner.hide();
        if (response.status === 686) {
          this.whyChooseUpdatedUpdated = true;
          // this.apiSuccessResponse(response);
          this.changeDir();
        } else {
          this.showApiMessage = true;
          this.response = response;
        }
      }, (error) => {
        this.apiErrorResponse(error);
      });

    const startQ = {
      addStartGuideDto: this.homepageEditForm.value.startQuick,
      ipAddress: this.currentUser.ip,
      location: this.currentUser.city + ',' + this.currentUser.country_name,
    };
    this.service.postMethod('static/admin/update-start-guide-translation?startDto=' + encodeURIComponent(this.service.encrypt(JSON.stringify(startQ))), {}, 1)
      .subscribe(respo => {
        this.spinner.hide();
        if (respo.status === 690) {
          this.startQuickGuideUpdated = true;
          // this.apiSuccessResponse(respo);
          this.changeDir();
        } else {
          this.showApiMessage = true;
          this.response = respo;
        }
      }, (error) => {
        this.apiErrorResponse(error);
      });

    const feature = {
      featuresContentDto: this.homepageEditForm.value.homepageArray,
      ipAddress: this.currentUser.ip,
      location: this.currentUser.city + ',' + this.currentUser.country_name
    };
    this.service.postMethod('static/admin/update-features-content-translation?featureContentDto=' + encodeURIComponent(this.service.encrypt(JSON.stringify(feature))), {}, 1)
      .subscribe(respon => {
        this.spinner.hide();
        if (respon.status === 694) {
          this.featureContentUpdated = true;
          // this.apiSuccessResponse(respon);
          this.changeDir();
        } else {
          this.showApiMessage = true;
          this.response = respon;
        }
      }, (error) => {
        this.apiErrorResponse(error);
      });
  }

  apiSuccessResponse(response) {
    this.showApiMessage = true;
    this.response = response;
    this.response.status = 200;
    this.changeDir();
  }

  changeDir() {
    if (this.whyChooseUpdatedUpdated && this.flashMessageUpdated && this.startQuickGuideUpdated && this.featureContentUpdated) {
      this.router.navigate(['/translation/homepage']);
    }
  }

  apiErrorResponse(error) {
    if (error.error) {
      this.showApiMessage = true;
      this.response = error.error;
      this.spinner.hide();
    } else {
      this.showApiMessage = true;
      this.response = 'Something went wrong!';
      this.spinner.hide();
    }
  }
}
