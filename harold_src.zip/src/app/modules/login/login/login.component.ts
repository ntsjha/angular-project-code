import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { ServerService } from '../../../server.service';
import { AppComponent } from '../../../app.component';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { HeaderComponent } from '../../header/header/header.component';
declare var $: any;

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  pramtoken: any;
  page: string;
  authToken: any;
  loginForm: FormGroup;
  qrCode = { Code1: "" };
  otp = { one: "", two: "", three: "", four: "", five: "", six: ""};
  constructor(public router: Router, public header: HeaderComponent, private server: ServerService, private appC: AppComponent, private spinnerService: Ng4LoadingSpinnerService, public route:ActivatedRoute) { }

  ngOnInit() {
    window.scrollTo(0,0);
    this.checkInputs();
    this.pramtoken = this.route.queryParams['_value'].token;
    this.verifyuser();
    
  }

  checkInputs() {
    this.loginForm = new FormGroup({
      email: new FormControl('', [Validators.required, Validators.pattern(/^[A-Z0-9_]+([\.-][A-Z0-9_]+)*@[A-Z0-9-]+(\.[a-zA-Z]{2,5})+$/i)]),
      password: new FormControl('', [Validators.required]),
    });
    // this.loginForm = new FormGroup({
    //   email: new FormControl('pq-ramsahay@mobiloitte.com', [Validators.required, Validators.pattern(/^[A-Z0-9_]+([\.-][A-Z0-9_]+)*@[A-Z0-9-]+(\.[a-zA-Z]{2,5})+$/i)]),
    //   password: new FormControl('qQ@123456', [Validators.required]),
    // });
  }


  /** to get the value of field  */
  get email(): any {
    return this.loginForm.get('email');
  }
  get password(): any {
    return this.loginForm.get('password');
  }

  /**For navigate to forget password page */
  forgotPassword() {
    this.router.navigateByUrl('forgetpassword');
  }

  signup() {
    this.router.navigateByUrl('signup/newUser');
}

  // ***** verify user api ****** // 

  verifyuser() {
    if(this.pramtoken != undefined) {
      this.spinnerService.show();
      this.server.getApi('account/verify-user?token='+this.pramtoken).subscribe((res) => {
          this.spinnerService.hide();
          if (res.status == 200) {
              this.appC.showSuccToast("User verified successfully.");
          } else {
            this.spinnerService.hide();
            this.appC.showErrToast(res.message);
          }
      }, (err) => {
          this.spinnerService.hide();
          this.appC.showErrToast(err.error.error)
      })
    }

 
  }



  login() {
    if (this.loginForm.value.email == "" ||  this.loginForm.value.password == "") {
      this.appC.showErrToast("Please Enter Details");
      return;
    } 
    localStorage.setItem('email', this.loginForm.value.email);
    let data = {
      "email": this.loginForm.value.email,
      "password": this.loginForm.value.password
    }
    this.spinnerService.show();
    this.server.postApi('auth', data).subscribe((res) => {
      this.spinnerService.hide();
      if (res.status == 200) {
        if (res.data.TwoFa == 'NONE') {
          localStorage.setItem('token', res.data.token);
          this.router.navigate(['exchange']);
          this.header.check()
          this.appC.showSuccToast('User loggedIn Successfully.');
        } else if(res.data.TwoFa == 'GOOGLE') {
          localStorage.setItem('token', res.data.token);
          $('#googleAuthModal').modal({ backdrop: 'static', keyboard: false });
        } else if(res.data.TwoFa == 'SMS') {
          localStorage.setItem('token', res.data.token);
          this.spinnerService.show();
      this.server.getApi('auth/send-sms').subscribe(succ =>{
          if(succ.status == 200) {
              this.spinnerService.hide();
              $('#faOTPModal').modal({ backdrop: 'static', keyboard: false });
          } else {
              this.spinnerService.hide();
              this.appC.showErrToast(succ.message);
          }
      },err =>{
          this.spinnerService.hide();
          this.appC.showErrToast(err.error.error);
      })
         
        } else {
          localStorage.setItem('token', res.data.token);
        }
      }
      else {
        this.appC.showErrToast(res.message);
      }

    }, (err) => {
        this.spinnerService.hide();
        if(err.error.status == 203){
          this.appC.showErrToast(err.error.message);
          this.router.navigate(['emailverify/login']);
      } else if(err.error.status == 401){
          this.appC.showErrToast('Enter valid credentials.')
      } else {
          this.appC.showErrToast(err.error.message);
          this.spinnerService.hide();
      }
    })
  }


  // **** google verify **** //


  qrVerify() {
    let data = this.qrCode.Code1
    this.spinnerService.show();
    this.server.postApi('auth/verify-google', data).subscribe((res) => {
      this.spinnerService.hide();
      if (res.status == 200) {
        localStorage.removeItem('authToken')
        localStorage.setItem('token', res.data);
        this.appC.showSuccToast("User loggedIn Successfully.");
        $('#googleAuthModal').modal('hide');
        this.router.navigate(['exchange']);
        this.header.check()
        this.header.getprofile();
        this.qrCode.Code1 = ""
      }
      else {
        this.qrCode.Code1 = "";
        this.appC.showErrToast("Enter valid QR Code");
      }

    }, (err) => {
      this.qrCode.Code1 = "";
      this.spinnerService.hide();
      this.appC.showErrToast("Enter valid QR Code")
    })
  }

  verifySmsCode() {
    if(this.otp.one == "" || this.otp.two == "" || this.otp.three == "" || this.otp.four == "" || this.otp.five == "" || this.otp.six == ""){
        this.appC.showErrToast("Please Enter Code");
        return; 
    } 
    let data = {
        "code": this.otp.one+this.otp.two+this.otp.three+this.otp.four+this.otp.five+this.otp.six,
    }
    this.spinnerService.show();
    this.server.postApi('auth/verify-sms', data).subscribe((res) => {
        this.spinnerService.hide();
        if (res.status == 200) {
          localStorage.removeItem('authToken')
          localStorage.setItem('token', res.data);
          this.appC.showSuccToast("User loggedIn Successfully.");
          $('#faOTPModal').modal('hide');
          this.router.navigate(['exchange']);
          this.header.check()
          this.header.getprofile();
        }
        else {
            this.otp = { one: "", two: "", three: "", four: "", five: "", six: ""};
            this.appC.showErrToast(res.message);
        }

    }, (err) => {
        this.otp = { one: "", two: "", three: "", four: "", five: "", six: ""};
        this.spinnerService.hide();
        this.appC.showErrToast("Something went Wrong")
    })
  }

  /**Resend OTP */
  otpResend() {
      this.spinnerService.show();
      this.server.getApi('auth/send-sms').subscribe(succ =>{
          if(succ.status == 200) {
              this.spinnerService.hide();
              this.appC.showErrToast(succ.message);
          } else {
              this.spinnerService.hide();
              this.appC.showErrToast(succ.message);
          }
      },err =>{
          this.spinnerService.hide();
          this.appC.showErrToast(err.error.error);
      })
  }

  /** Auto focus functionality */
  onKey(value, type) {
    if (type == 1) {
        if (value != "") {
            $('#otp2').focus();
        }
    } else if (type == 2) {
        if (value != "") {
            $('#otp3').focus();
        }
    } else if (type == 3) {
        if (value != "") {
            $('#otp4').focus();
        }
    } else if (type == 4) {
      if (value != "") {
          $('#otp5').focus();
      }
    } else if (type == 5) {
      if (value != "") {
          $('#otp6').focus();
      }
    } else if (type == 6) {
          if (value.keyCode == 13) {
              this.verifySmsCode();
          }
      } 
  }
}
