import { Component, OnInit, OnDestroy } from '@angular/core';
import { ServiceService } from 'src/app/service/service.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { IMyDpOptions, IMyDateModel } from 'mydatepicker';
import { Router, ActivatedRoute } from '@angular/router';
import { AppComponent } from 'src/app/app.component';
import { NgxSpinnerService } from 'ngx-spinner';
import { CookieService } from 'ngx-cookie-service';

declare var $: any;
@Component({
    selector: 'app-particular-fa-detail',
    templateUrl: './particular-fa-detail.component.html',
    styleUrls: ['./particular-fa-detail.component.css']
})
export class ParticularFaDetailComponent implements OnInit, OnDestroy {
    id: string;
    faDetailObj: any = {};
    changeStatusForm: any;
    status: any;
    faStatus: any;
    custDetails: any = {};
    userDetails: any = {};
    reseFaObj: any = {};
    fileData: any;
    profileImage: string | ArrayBuffer;
    error = false;
    message: string;
    selectedTab: any = 'wallet';
    tabArr: any[];
    totalItems: number;
    page: any = 1;
    pageSize: any = 10;
    obj: any = {};
    selectedExeCoin: any = 'ETH';
    sideBuy: any;
    side = ['BUY', 'SELL'];
    baseCoin = [
        { coin: "BTC", coinID: "", coinType: "" },
        { coin: "THB", coinID: "", coinType: "" }
    ];


    public fromPickerOptions: IMyDpOptions = {
        dateFormat: 'dd.mm.yyyy',
    };
    public toPickerOptions: IMyDpOptions = {
        dateFormat: 'dd.mm.yyyy',
    };
    internalTab: any;
    selectedCoin: any = 'BTC';
    coinList: any[];
    subscription: any;
    reason: any;
    name: any;
    resetId: any;
    exeCoin: any = [];
    userIp: any;


    constructor(public server: ServiceService, public router: Router, private appC: AppComponent, private spinner: NgxSpinnerService, private activatedRoute: ActivatedRoute, private cookie: CookieService) {
        this.subscription = this.server.authVerify.subscribe((res) => {
            if (res === 'fa-detail') {
                this.approveOrReject();
                this.server.authVerify.next('false');
            }
        });

        this.changeStatusForm = new FormGroup({
            remark: new FormControl('', [Validators.required]),
        });
    }


    get remark(): any {
        return this.changeStatusForm.get('remark');
    }

    ngOnInit() {
        window.scrollTo(0, 0);
        this.callByUrl();
        this.getCoinList();
        this.getCoinDetail();
        this.selectTab('wallet');
        this.userIp = (this.cookie.get('userInfo')) ? JSON.parse(this.cookie.get('userInfo')) : this.server.initialUserInfo;
    }

    ngOnDestroy() {
        this.subscription.unsubscribe();
    }

    getCoinList() {
        this.spinner.show();
        this.server.getMethod('wallet/currency/get-all-currency-list', 1)
            .subscribe((response: any) => {
                this.spinner.hide();
                let responseData = this.server.decrypt(response.data);
                responseData = JSON.parse(responseData);
                if (responseData.status === 830) {
                    this.getCoinList = responseData.data;
                }
            }, (error) => {
                this.spinner.hide();
            });
    }

    getCoinDetail() {
        this.server.getMethod('fee/coin/coin-pair-symbol?baseCoin=' + this.baseCoin[0].coin, 1)
            .subscribe((response: any) => {
                this.spinner.hide();
                if (response.status === 200) {
                    this.exeCoin = response.data;
                }
            }, (err) => {
                this.spinner.hide();
            });
    }

    onFromDateChanged(event: IMyDateModel) {
        const copy1 = this.getCopyOfOptions1();
        copy1.disableUntil = event.date;
        this.toPickerOptions = copy1;
    }

    getCopyOfOptions1(): IMyDpOptions {
        return JSON.parse(JSON.stringify(this.toPickerOptions));
    }

    getCopyOfOptions2(): IMyDpOptions {
        return JSON.parse(JSON.stringify(this.fromPickerOptions));
    }

    onToDateChanged(event: IMyDateModel) {
        const copy1 = this.getCopyOfOptions2();
        copy1.disableSince = event.date;
        this.fromPickerOptions = copy1;
    }

    callByUrl() {
        const url = window.location.href;
        const arr = url.split('/');
        this.id = arr[arr.length - 1];
        this.activatedRoute.params.subscribe(x => {
            this.id = x.id;
            this.resetId = x.resetId;
        })
        this.getFaDetail();
    }

    getFaDetail() {
        const data = {
            userId: this.server.encrypt(this.id),
            resetTwoFaDetailId: this.server.encrypt(this.resetId),
        };
        this.server.postMethod('account/operation/get-twoFa-request', data, 1).subscribe((res) => {
            const response = JSON.parse(this.server.decrypt(res.data));
            console.log(response)
            if (response.status == 554) {
                this.faDetailObj = response.data;
                this.faStatus = this.faDetailObj.resetTwoFaRequestDetails.status;
                this.custDetails = response.data.userDetails.custDetails;
                this.userDetails = response.data.userDetails;
                this.reseFaObj = response.data.resetTwoFaRequestDetails;
                this.reason = response.data.reason;
                if (this.reseFaObj.selfieImageUrl) {
                    this.getBase64Func(this.reseFaObj.selfieImageUrl, '2');
                }
                if (response.data.userDetails.kyc.length) {
                    this.name = response.data.userDetails.kyc[response.data.userDetails.kyc.length - 1].kycBasicDetails.englishFirstName ? response.data.userDetails.kyc[response.data.userDetails.kyc.length - 1].kycBasicDetails.englishFirstName + ' ' + response.data.userDetails.kyc[response.data.userDetails.kyc.length - 1].kycBasicDetails.englishLastName : '';
                }
            }
        });
    }

    getBase64Func(img, type) {
        this.reseFaObj.selfieImageUrl = '';
        if (img!= null || img !="") {
            this.server.getMethod('account/convert-image-base64?imageUrl=' + this.server.imageUrl + img, 1).subscribe((res: any) => {
                this.spinner.hide();
            }, error => {
                if (error && error.error.text) {
                    this.reseFaObj.selfieImageUrl = 'data:image/jpg;base64,' + error.error.text;
                }

            });
        }
    }

    approveOrReject() {
        const data: any = {
            userId: this.server.encrypt(this.id),
            status: this.server.encrypt(this.status),
            ipAddress: this.server.encrypt(this.userIp.ip),
            location: this.server.encrypt(this.userIp.city + ',' + this.userIp.country_name),
        };
        if (this.status === 'REJECTED') {
            data.reason = this.changeStatusForm.value.remark;
        }
        if (this.profileImage) {
            data.selfieImageUrl = this.profileImage;
        }
        this.server.postMethod('account/operation/approve-or-reject-twoFa-request', data, 1).subscribe((res) => {
            const decryptData = res.data ? JSON.parse(this.server.decrypt(res.data)) : {}
            $('#myticket1').modal('hide');
            if (decryptData) {
                this.getFaDetail();
            }
            this.spinner.hide();
        });
    }
    openModal(status) {
        this.status = status;
        if (status === 'ACCEPTED') {
            this.server.googleAuthCalledFrom = 'fa-detail';
            this.appC.google = { one: '', two: '', three: '', four: '', five: '', six: '' };
            this.appC.response = { 'message': '' };
            $('#google-auth-modal').modal({ backdrop: 'static', keyboard: false });
        } else if (status === 'REJECTED') {
            $('#myticket1').modal({ backdrop: 'static', keyboard: false });
        }

    }

    open2FA() {
        this.server.googleAuthCalledFrom = 'fa-detail';
        this.appC.google = { one: '', two: '', three: '', four: '', five: '', six: '' };
        this.appC.response = { 'message': '' };
        $('#google-auth-modal').modal({ backdrop: 'static', keyboard: false });
    }

    handleFileInput(event) {
        this.error = false;
        const self = this;
        if (event.target.files && event.target.files[0]) {
            const type = event.target.files[0].type;
            if (type === 'image/png' || type === 'image/jpg' || type === 'image/jpeg') {
                this.fileData = event.target.files[0];
                this.uploadSelfiImage();
                const reader = new FileReader();
                reader.onload = (e: any) => {
                    self.profileImage = e.target.result;
                };
            } else {
                this.message = 'Select only jpg,jpeg and png file.';
                this.error = true;
                self.profileImage = '';
                self.fileData = '';
            }
        }
    }

    uploadSelfiImage() {
        this.spinner.show();
        const formdata = new FormData();
        formdata.append('file', this.fileData);
        if (navigator.onLine) {
            this.server.uploadMethod('account/uploadFile', formdata).subscribe((succ) => {
                if (succ.fileName) {
                    this.profileImage = succ.fileName;
                    this.getBase64Func(this.profileImage, '1');
                    this.spinner.hide();
                }
            }, error => {
                this.spinner.hide();
            });
        }
    }

    selectTab(tab) {
        this.selectedTab = tab;
        this.page = 1;
        this.totalItems = 0;
        this.obj.fromDate = '';
        this.obj.toDate = '';
        this.getTabDetails();
    }

    getTabDetails() {
        this.tabArr = [];
        this.totalItems = 0;
        let url = {};
        const data: any = {};
        if (this.selectedTab === 'wallet') {
            data.userId = this.id;
            url = 'wallet/common-permit/customer/get-customer-wallets?userId=' + this.id;
        } else if (this.selectedTab === 'tradeHistory') {
            data.baseCoin = this.selectedCoin
            data.exeCoin = this.selectedExeCoin
            data.side = this.sideBuy
            data.fromDate = this.obj.fromDate.epoc * 1000;
            data.toDate = this.obj.toDate.epoc * 1000 + (86400000 - 1);
            url = 'order-service/common-permit/get-trade-history?userData=' + this.id;
        } else if (this.selectedTab === 'openOrders') {
            data.baseCoin = this.selectedCoin
            data.exeCoin = this.selectedExeCoin
            data.side = this.sideBuy
            data.fromDate = this.obj.fromDate.epoc * 1000;
            data.toDate = this.obj.toDate.epoc * 1000 + (86400000 - 1);
            url = 'order-service/common-permit/get-Open-order-history?userData=' + this.id;
        } else if (this.selectedTab === 'withdrawHistory') {
            data.txnType = 'WITHDRAW';
            if (this.obj.fromDate && this.obj.toDate) {
                data.fromDate = this.obj.fromDate.epoc * 1000;
                data.toDate = this.obj.toDate.epoc * 1000 + (86400000 - 1);
            } else {
                data.fromDate = null;
                data.toDate = null;
            }
            data.page = this.page - 1;
            data.pageSize = this.pageSize;
            if (this.selectedCoin) {
                data.coinName = this.selectedCoin;
            } else {
                data.coinName = null;
            }

            if (this.internalTab) {
                data.status = this.internalTab;
                data.page = this.page - 1;
            }
            url = `wallet/common-permit/history/get-transfer-history-per-user?userId=${this.id}`;
        } else if (this.selectedTab === 'depositHistory') {

            url = `wallet/common-permit/history/get-transfer-history-per-user?userId=${this.id}`;
            // if (this.obj.fromDate && this.obj.toDate) {
            //   data.fromDate = this.obj.fromDate.epoc;
            //   data.toDate = this.obj.toDate.epoc;
            //   data.page = this.page - 1;
            //   data.pageSize = this.pageSize;
            //   data.coinName = this.selectedCoin;
            // }
            data.txnType = 'USER_DEPOSIT';
            if (this.obj.fromDate && this.obj.toDate) {
                data.fromDate = this.obj.fromDate.epoc * 1000;
                data.toDate = (this.obj.toDate.epoc * 1000 + (86400000 - 1));
            } else {
                data.fromDate = null;
                data.toDate = null;
            }
            data.page = this.page - 1;
            data.pageSize = this.pageSize;
            if (this.selectedCoin) {
                data.coinName = this.selectedCoin;
            } else {
                data.coinName = null;
            }
            if (this.internalTab) {
                data.status = this.internalTab;
                data.page = this.page - 1;
            }
        } else if (this.selectedTab === 'rewardHistory') {
            data.page = this.page - 1;
            data.pageSize = this.pageSize;
            data.userId = this.id;
            if (this.obj.fromDate && this.obj.toDate) {
                data.fromDate = (this.obj.fromDate.epoc) * 1000;
                data.toDate = ((this.obj.toDate.epoc) * 1000 + (86400000 - 1));
            }
            url = 'rewards/common-permit/search-and-filter-reward-transaction-history';
        } else if (this.selectedTab === 'activity') {
            if (this.obj.fromDate && this.obj.toDate) {
                url = 'account/common-permit/customer-activity-logs?customerUserId=' + (this.id) + '&fromDate=' + (this.obj.fromDate.epoc * 1000) + '&toDate=' + ((this.obj.toDate.epoc * 1000) + (86400000 - 1)) + '&page=' + (this.page - 1) + '&pageSize=10';
            } else {
                url = 'account/common-permit/customer-activity-logs?customerUserId=' + (this.id) + '&page=' + (this.page - 1) + '&pageSize=10';
            }
        } else if (this.selectedTab === 'sessionManagement') {
            url = `account/common-permit/customer-current-login-detail?customerUserId=${this.id}`;
        }
        if (this.selectedTab !== 'wallet') {
            this.server.postMethod(url, data, 1).subscribe((res) => {
                if (this.selectedTab === 'wallet') {
                    const arr = res.data;
                    this.tabArr = res.data;
                    this.totalItems = this.tabArr.length;
                    arr.forEach(element => {
                        element.showFullAddress = false;
                    });
                } else if (this.selectedTab === 'openOrders') {
                    const arr = res.data;
                    arr.forEach(element => {
                        let historyArr = [];
                        historyArr = [...element.history];
                        historyArr.forEach(obj => {
                            this.tabArr.push(obj);
                        });

                    });
                    this.totalItems = this.tabArr.length;
                } else if (this.selectedTab === 'tradeHistory') {
                    const arr = res.data;
                    arr.forEach(element => {
                        this.tabArr.push(element.orderHistory);
                    });
                    this.totalItems = this.tabArr.length;
                } else if (this.selectedTab === 'withdrawHistory' || this.selectedTab === 'depositHistory') {
                    this.tabArr = res.data.resultlist;
                    this.totalItems = res.data.totalCount;
                } else if (this.selectedTab === 'sessionManagement') {
                    const response = JSON.parse(this.server.decrypt(res.data));
                    this.tabArr = response.data;
                    if (response.status === 364) {
                        this.tabArr = [];
                    }
                    this.totalItems = response.data.length;
                } else if (this.selectedTab === 'rewardHistory') {
                    this.tabArr = res.data.list;
                    this.totalItems = res.data.size;
                } else if (this.selectedTab === 'activity') {
                    const response = JSON.parse(this.server.decrypt(res.data));
                    this.tabArr = response.data.list;
                    this.totalItems = response.data.size;
                }
            });
        } else {
            this.server.getMethod(url, 1).subscribe((res: any) => {
                this.tabArr = res.data;
            });
        }

    }

    resetData() {
        this.tabArr = [];
        this.page = 1;
        this.obj.fromDate = '';
        this.obj.toDate = '';
        this.totalItems = 0;
        this.fromPickerOptions = {
            disableSince: { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() + 1 },
            disableUntil: { year: 0, month: 0, day: 0 }
        };
        this.toPickerOptions = {
            disableSince: { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() + 1 },
            disableUntil: { year: 0, month: 0, day: 0 }
        };
        this.getTabDetails();
    }

    exportData() {
        const options: any = {
            fieldSeparator: ',',
            quoteStrings: '"',
            decimalseparator: '.',
            showLabels: true,
            showTitle: true,
            useBom: true,
            noDownload: false,
        };
        const data: any = [];
        if (this.selectedTab === 'wallet') {
            options.title = 'Wallet';
            options.headers = ['Currency', 'Name', 'Total', 'Available', 'In Order', 'Value(THB)', 'Value(BTC)', 'Address'];
            this.tabArr.forEach((element1) => {
                const obj = {
                    Currency: element1.currencyShortName || '---',
                    Name: element1.currencyFullName || '---',
                    Total: element1.availableBalance || '---',
                    Available: element1.walletBalance || '---',
                    InOrder: element1.blockedBalance || '---',
                    'Value(THB)': element1.priceInTHB || '---',
                    'Value(BTC)': element1.priceInBTC || '---',
                    Address: element1.addressList[0].address || '---'
                };
                data.push(obj);
            });
            console.log('ggggg', this.tabArr)
        }
        if (this.selectedTab === 'tradeHistory') {
            options.title = 'Trade History';
            options.headers = ['Date', 'Pair', 'Type', 'Price', 'Filled', 'Total'];
            this.tabArr.forEach((element2) => {
                const obj: any = {
                    Date: new Date(element2.creationTime) || '---',
                    Pair: element2.instrument || '---',
                    Type: element2.orderType || '---',
                    Price: element2.avgExecutionPrice || '---',
                };
                if (element2.currentQuantity === element2.quantity) {
                    obj.Filled = 0;
                } else {
                    obj.Filled = element2.avgExecutionPrice * element2.quantity;
                }

                obj.Total = element2.avgExecutionPrice * element2.quantity;
                data.push(obj);
            });
        }
        if (this.selectedTab === 'openOrders') {
            options.title = 'Open Orders';
            options.headers = ['Date', 'Pair', 'Type', 'Side', 'Price', 'Amount', 'Filled', 'Total', 'Trigger Conditions'];
            this.tabArr.forEach((element3) => {
                const obj: any = {
                    Date: new Date(element3.creationTime) || '---',
                    Pair: element3.instrument || '---',
                    Type: element3.orderType || '---',
                    Side: element3.orderSide || '---',
                };
                if (element3.orderStatus !== 'COMPLETED') {
                    data.Price = element3.limitPrice || '---';
                } else {
                    data.Price = element3.avgExecutionPrice || '---';
                }
                data.Amount = element3.quantity || '---';
                if (element3.currentQuantity === element3.quantity) {
                    data.Filled = 0;
                } else {
                    data.Filled = element3.currentQuantity / element3.quantity;
                }

                if (element3.orderStatus !== 'COMPLETED') {
                    data.Total = element3.avgExecutionPrice * element3.quantity;
                } else {
                    data.Total = element3.price * element3.quantity;
                }

                if (element3.triggerCondition) {
                    data.Trigger_Conditions = element3.triggerCondition || '---';
                }
                data.push(obj);
            });
        }
        if (this.selectedTab === 'withdrawHistory') {
            options.title = 'Wallet';
            options.headers = ['Date', 'Currency', 'To Address', 'Amount', 'Fee', 'Transaction ID', 'Status', 'IP', 'Location'];
            this.tabArr.forEach((element4) => {
                const obj = {
                    Date: new Date(element4.transactionTime),
                    Currency: element4.currencyFullName || '---',
                    To_Address: element4.toAddress || '---',
                    Amount: element4.amount || '---',
                    Fee: element4.fees || '---',
                    'Transaction ID': element4.coinDepositWithdrawalId,
                    Status: element4.status || '---',
                    IP: element4.ipAddress || '---',
                    Location: element4.location || '---'
                };
                data.push(obj);
            });
        }
        if (this.selectedTab === 'depositHistory') {
            this.server.getMethod('wallet/common-permit/reports/generate-all-deposit-records', 1)
                .subscribe((response) => {
                }, (error) => {
                });
            options.title = 'Deposit History';
            options.headers = ['Date', 'Currency', 'To Address', 'Amount', 'Transaction ID', 'Status'];
            this.tabArr.forEach((element5) => {
                const obj = {
                    Date: new Date(element5.transactionTime),
                    Currency: element5.currencyFullName || '---',
                    To_Address: element5.toAddress || '---',
                    Amount: element5.amount || '---',
                    'Transaction ID': element5.coinDepositWithdrawalId,
                    Status: element5.status || '---',
                };
                data.push(obj);
            });
        }
        if (this.selectedTab === 'activity') {
            options.title = 'Activity List';
            options.headers = ['Date', 'Activity', 'Location'];
            this.tabArr.forEach((element6) => {
                const obj = {
                    Date: new Date(element6.customerId),
                    Activity: element6.logType + '-' + element6.entityType,
                    Location: element6.location || '---',

                };
                data.push(obj);
            });
        }
        if (this.selectedTab === 'rewardHistory') {
            options.title = 'Reward history';
            options.headers = ['Date', 'Credit/Debit', 'Activity', 'Points'];
            this.tabArr.forEach((element7) => {
                const obj = {
                    Date: new Date(element7.createdAt),

                    Activity: element7.email,
                    Points: element7.phoneNo || '---',

                };
                if (element7.isDebited) {
                    obj['Credit/Debit'] = 'Debit';
                } else {
                    obj['Credit/Debit'] = 'Credit';
                }

                data.Activity = element7.activity;
                data.Points = element7.remainingPoints;
                data.push(obj);
            });
        }
        if (this.selectedTab === 'sessionManagement') {
            options.title = 'Session List';
            options.headers = ['Device', 'IP Address', 'Location'];
            this.tabArr.forEach((element8) => {
                const obj = {
                    Device: element8.device || '---',
                    IP_Address: element8.ipAddress || '---',
                    Location: element8.location || '---',
                };
                data.push(obj);
            });
        }
        this.server.exportAsExcelFile(data, options.title);
    }

    changePage(page) {
        this.page = page;
        this.totalItems = 0;
        if (this.selectedTab === 'activity') {
            this.getTabDetails();
        }
    }

    selectInternalTabStatus(tab) {
        this.internalTab = tab;
    }

    cancelSession(index, id) {
        this.server.postMethod('account/operation/remove-customer-login-session?loginId=' + encodeURIComponent(this.server.encrypt(id)), {}, 1).subscribe((res) => {
            if (res.status === 361) {
                this.tabArr.splice(index, 1);
            }
        });
    }

    closeModal() {
        this.changeStatusForm.reset();
    }

    viewAddress(index) {
        this.tabArr[index].showFullAddress = !this.tabArr[index].showFullAddress;
    }



}
