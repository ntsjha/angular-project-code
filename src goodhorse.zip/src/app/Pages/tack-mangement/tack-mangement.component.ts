import { Component, OnInit } from '@angular/core';
import { ServiceService } from 'src/app/Shared/service.service';
import { HorseTack } from 'src/app/Shared/horseTack.model';

@Component({
  selector: 'app-tack-mangement',
  templateUrl: './tack-mangement.component.html',
  styleUrls: ['./tack-mangement.component.css']
})
export class TackMangementComponent implements OnInit {
  horseTack: any = [];
  horseTackLength: any;
  p: number = 1;
  pageSize = 5;
  total = 0
  constructor(public service: ServiceService) { }

  ngOnInit() {
    this.getHorseTack();
  }


  // Get Horse Tack
  getHorseTack() {
    this.service.showSpinner();
    this.service.getGlobalTack().subscribe(res => {
      this.horseTack = res.map(item => {
        return {
          id: item.payload.doc.id,
          ...item.payload.doc.data()
        } as HorseTack
      })
      this.service.hideSpinner();

var data=this.horseTack.reduce((accumulator, currentValue) =>  currentValue.horseTackBrand === "Zilco")
console.log('Reduce==>',data)

      this.horseTackLength = this.horseTack.length;
    })
  }

  page(event) {
    // console.log(event);
    this.p = event
  }
}
