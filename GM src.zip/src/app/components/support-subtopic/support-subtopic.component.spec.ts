import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SupportSubtopicComponent } from './support-subtopic.component';

describe('SupportSubtopicComponent', () => {
  let component: SupportSubtopicComponent;
  let fixture: ComponentFixture<SupportSubtopicComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SupportSubtopicComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SupportSubtopicComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
