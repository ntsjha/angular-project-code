import { NgxSpinnerService } from 'ngx-spinner';
import { ActivatedRoute, Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ServiceService } from 'src/app/service/service.service';
import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'app-add-job-translation',
  templateUrl: './add-job-translation.component.html',
  styleUrls: ['./add-job-translation.component.css']
})
export class AddJobTranslationComponent implements OnInit {

  addTranslateJobForm: FormGroup;
  paramData: any;
  saveApiResponse: any = { status: 817 };
  userIp: any;

  constructor(
    private activatedRoute: ActivatedRoute,
    private service: ServiceService,
    private router: Router,
    private spinner: NgxSpinnerService,
    private cookie: CookieService
  ) {
    this.userIp = (this.cookie.get('userInfo')) ? JSON.parse(this.cookie.get('userInfo')) : this.service.initialUserInfo;
   }

  ngOnInit() {
    window.scrollTo(0, 0);
    this.form();
    this.getParamData();
  }

  form() {
    this.addTranslateJobForm = new FormGroup({
      title: new FormControl('', [Validators.required]),
      editorValue: new FormControl('', [Validators.required]),
      noOfOpenings: new FormControl('', [Validators.required, Validators.pattern(/^[0-9]*$/)])
    });
  }

  getParamData() {
    this.activatedRoute.params.subscribe(param => {
      this.paramData = param;
      this.getJobData();
    });
  }

  getJobData() {
    this.spinner.show();
    this.service.getMethod(`career/admin/get-job-translation-by-lg-and-content-id?language=${encodeURIComponent(this.service.encrypt(this.paramData.lang))}&contentId=${this.paramData.id}`, 1).subscribe((success: any) => {
      this.spinner.hide();
      const decryptedData = success.data ? JSON.parse(this.service.decrypt(success.data)) : {};
      if (decryptedData.status === 808) {
        this.addTranslateJobForm.patchValue({
          title: decryptedData.data.title ? decryptedData.data.title : '',
          editorValue: decryptedData.data.description!=null && decryptedData.data.description ? decryptedData.data.description : '',
          noOfOpenings: decryptedData.data.noOfOpening ? decryptedData.data.noOfOpening : 0,
        });
      }
      
    }, error => {
      this.spinner.hide();
    });
  }

  addJobTranslation() {
    if (this.addTranslateJobForm.invalid) {
      return;
    }
    this.spinner.show();
    const apireq = {
      description: this.service.encrypt(this.addTranslateJobForm.value.editorValue),
      id: this.service.encrypt(this.paramData.translateId),
      languageShortName: this.service.encrypt(this.paramData.lang),
      noOfOpening: this.service.encrypt(this.addTranslateJobForm.value.noOfOpenings),
      title: this.service.encrypt(this.addTranslateJobForm.value.title),
      slug: this.service.encrypt(this.addTranslateJobForm.value.title.replace(' ', '_')),
      location: this.service.encrypt(this.userIp.city + ',' + this.userIp.country_name),
      ipAddress: this.service.encrypt(this.userIp.ip),
    };
    this.service.postMethod('career/admin/save-translation-job', apireq, 1).subscribe((success: any) => {
      this.spinner.hide();
      const decryptedData = success.data ? JSON.parse(this.service.decrypt(success.data)) : {};
      this.saveApiResponse = decryptedData;
      if (decryptedData.status === 817) {
        this.router.navigate(['/translate-job/' + this.paramData.id]);
      }
    }, error => {
      this.spinner.hide();
    });
  }

}
