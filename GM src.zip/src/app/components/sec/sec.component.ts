import { Component, OnInit } from '@angular/core';
import { ServiceService } from 'src/app/service/service.service';
import { DatePipe } from '@angular/common';
import { NgxSpinnerService } from 'ngx-spinner';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'app-sec',
  templateUrl: './sec.component.html',
  styleUrls: ['./sec.component.css']
})
export class SecComponent implements OnInit {
  secData: any[];
  secReportForm: FormGroup;
  userIp: any;
  checkboxArray = [];
  hours = [];
  minutes = [];

  constructor(private service: ServiceService,
    public datepipe: DatePipe,
    private spinner: NgxSpinnerService,
    private fb: FormBuilder,
    private cookie: CookieService,
  ) { }

  ngOnInit() {
    // this.getSecReport();
    this.userIp = (this.cookie.get('userInfo')) ? JSON.parse(this.cookie.get('userInfo')) : this.service.initialUserInfo;
    this.secReportForm = this.fb.group({
      secHours: ['', [Validators.required]],
      secMinutes: ['', [Validators.required]],
      secEmail: ['', [Validators.required]],
      secEmailCC: ['', [Validators.required]],
      secDigitalAssests: [''],
      secCompany: [''],
      secCustomer: [''],
      secOrder: [''],
      secTransaction: [''],
    });
    window.scrollTo(0, 0);
  }

  getSecReport() {
    this.spinner.show();
    this.service.getMethod('setting-service/admin/get-sec-report', 1).subscribe((response: any) => {
      let responseData = this.service.decrypt(response.data);
      responseData = JSON.parse(responseData);
      this.spinner.hide();
      if (responseData.status === 1509) {
        this.secData = responseData.data;
      }
    }, (error) => {
      this.spinner.hide();
    });
    this.spinner.hide();
  }

  checkboxUpdate(val) {
    let found = 0;
    let indexAt = 0;
    if (this.checkboxArray.length) {
      this.checkboxArray.forEach((element, index) => {
        if (element === val) {
          found++;
          indexAt = index;
        }
      });
      if (found != 0) {
        this.checkboxArray.splice(indexAt, 1);
      } else {
        this.checkboxArray.push(val);
      }
    } else {
      this.checkboxArray.push(val);
    }
  }

  submitSecReport() {
    if (this.secReportForm.invalid) {
      return;
    }
    this.spinner.show();
    const data = {
      hours: this.secReportForm.value.secHours,
      minutes: this.secReportForm.value.secMinutes,
      toEmail: this.secReportForm.value.secEmail,
      ccEmail: this.secReportForm.value.secEmailCC,
      reports: this.checkboxArray,
      ipAddress: this.userIp.ip,
      location: this.userIp.city + ', ' + this.userIp.country_name,

    };
    this.service.postMethod('setting/admin/set-sec-report', data, 1)
      .subscribe((response) => {
      }, (error) => {
      });
  }
}
