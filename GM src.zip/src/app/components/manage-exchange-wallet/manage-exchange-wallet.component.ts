import { Component, OnInit } from '@angular/core';
import { ServiceService } from 'src/app/service/service.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { Router } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'app-manage-exchange-wallet',
  templateUrl: './manage-exchange-wallet.component.html',
  styleUrls: ['./manage-exchange-wallet.component.css']
})
export class ManageExchangeWalletComponent implements OnInit {
  exchangeWalletList: any = [];
  p: any;
  page: number;
  total: any = 0;
  userIp: any;
  constructor(
    private service: ServiceService,
    private spinner: NgxSpinnerService,
    private router: Router,
    private cookie: CookieService
  ) { }

  ngOnInit() {
    window.scrollTo(0,0);
    this.userIp = (this.cookie.get('userInfo')) ? JSON.parse(this.cookie.get('userInfo')) : this.service.initialUserInfo;
    this.getCheckAndCreate();
  }

  getCheckAndCreate() {
    this.spinner.show();
    this.service.getMethod('wallet/admin/exchange-wallet/check-and-create?ipAddress=' + this.userIp.ip + '&location=' + this.userIp.city + ',' + this.userIp.country_name, 1)
      .subscribe((response: any) => {
        this.spinner.hide();
        if (response.status === 842) {
          this.getAllWalletData();
        }
      }, (error) => {
        this.spinner.hide();
      });
  }

  getAllWalletData() {
    this.service.getMethod('wallet/admin/exchange-wallet/get-all', 1)
      .subscribe((response: any) => {
        this.spinner.hide();
        if (response.status === 842) {
          this.exchangeWalletList = response.data;
        }
      }, (error) => {
        this.spinner.hide();
      });
  }

  goTotransfer(id) {
    if (this.service.sideMenuArr.includes('updateSettings')) {
      this.router.navigate(['/manage-transfer-exchange-wallet/' + id]);
    }
  }

  changePage(page) {
    this.p = page;
    this.page = page - 1;
    this.getAllWalletData();
  }
}

