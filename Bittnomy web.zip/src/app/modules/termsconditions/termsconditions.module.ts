import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TermsconditionsComponent } from './termsconditions/termsconditions.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [TermsconditionsComponent]
})
export class TermsconditionsModule { }
