export class HorseHealthRugs{
    id: string
    sl_no: string
    type: string
    neck: string
    when: string
    weather: string
}