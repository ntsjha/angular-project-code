import { Component, OnInit} from '@angular/core';
import { MainServiceService } from 'src/app/main-service.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { Router } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import { FormGroup, FormControl, Validators } from '@angular/forms';

declare var $ : any;

export interface PeriodicElement {
    name: string;
    sno: number;
    contact: number;
    email: string;
    role: string;
    shift: string;
    pump: string;
    status: string;
}


@Component({
  selector: 'app-user-managment',
  templateUrl: './user-managment.component.html',
  styleUrls: ['./user-managment.component.css']
})
export class UserManagmentComponent implements OnInit {

  p: number = 1;
  ELEMENT_DATA: PeriodicElement[] ;
  displayedColumns: string[];
  dataSource: any = [];
  user = {'searchField':'','userRole':''}
  addUser: FormGroup;
  totalPages: any;
  currPage: any;
  paginationArr: any = [];
  id: any;
  userInfo = {"email": "",
  "phoneNumber": "",
  "address": "",
  "userRole": "",
  "shift": "",
  "name": "",
  "petrolPumpName": ""};

  constructor(private service: MainServiceService,public spinnerService: Ng4LoadingSpinnerService,private router: Router,public cookie: CookieService) {
      this.addUser = new FormGroup({
          name: new FormControl('',[Validators.required, Validators.pattern(/^[a-zA-Z]*$/i)]),
          email: new FormControl('',[Validators.required, Validators.pattern(/^[A-Z0-9_-]+([\.][A-Z0-9_-]+)*@[A-Z0-9-]+(\.[a-zA-Z]{2,3})+$/i)]),
          contactNumber: new FormControl('',[Validators.required, Validators.pattern(/^[1-9]{1}[0-9]*$/),Validators.minLength(7), Validators.maxLength(10)]),
          role: new FormControl('',[Validators.required]),
          shift: new FormControl('',[Validators.required]),
          petrolPump: new FormControl('',[Validators.required]),
          password: new FormControl('',[Validators.required, Validators.pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})/i)]),
          address: new FormControl('',[Validators.required]),
          confirmPassword: new FormControl('',[Validators.required])
      }, passwordMatchValidator);

      /** Function for password match and mismatch */
      function passwordMatchValidator(g: FormGroup) {
          let pass = g.get('password').value;
          let confPass = g.get('confirmPassword').value;
          if (pass != confPass) {
              g.get('confirmPassword').setErrors({ mismatch: true });
          } else {
              g.get('confirmPassword').setErrors(null)
              return null
          }
      }
  }

  /**Function to get input data */
  get name() : any {
     return this.addUser.get('name');
  }
  get email() : any {
     return this.addUser.get('email');
  }
  get contactNumber() : any {
     return this.addUser.get('contactNumber');
  }
  get role() : any {
     return this.addUser.get('role');
  }
  get shift() : any {
     return this.addUser.get('shift');
  }
  get petrolPump() : any {
     return this.addUser.get('petrolPump');
  }
  get password() : any {
     return this.addUser.get('password');
  }
  get confirmPassword() : any {
     return this.addUser.get('confirmPassword');
  }
  get address() : any {
     return this.addUser.get('address');
  }


  ngOnInit() {
      this.getUserList();
  }

  importToCSVFunc() {
      // new Angular5Csv(data, 'User Detail');
  }

  /**Function to get user list */
  getUserList() {
      let data = {
          "search": this.user.searchField,
          "userRole": this.user.userRole,
      }
      this.service.post('user/getUser', data, 1).subscribe(success => {
          if (success.responseCode == 200) {
              this.spinnerService.hide();
              this.displayedColumns= ['sno', 'name', 'email', 'userRole','phoneNumber', 'shift', 'petrolPumpName', '_id'];
              const data = [];
              this.totalPages = success.result.success.pages;
              this.currPage = success.result.success.page;
              success.result.success.docs.forEach((element,ind) => {
                  data.push({
                      'sno' : ind+1,
                      'name' : element.name,
                      'email' : element.email,
                      'userRole' : element.userRole,
                      'phoneNumber' : element.phoneNumber,
                      'shift' : element.shift,
                      'petrolPumpName' : element.petrolPumpName,
                      '_id' : element._id,
                  })
              });
              this.dataSource = data;
              console.log('data--->',this.dataSource)
              // this.paginationFunc();
          } else {
              this.spinnerService.hide();
              this.service.showError(success.responseMessage);
          }
      }, error => {
          this.service.showError('Something went wrong');
          this.spinnerService.hide();
      });
  }

  /**Function to manage pagination */
  paginationFunc() {
      for(var i = 1; i<= this.totalPages; i++) {
          this.paginationArr.push({
              'number': i,
          });
      }
  }

  /**Function for pagination */
  getUserListBasedOnPageNo(val) {
      let data = {
          "search": this.user.searchField,
          "userRole": this.user.userRole,
          "pageNumber" : val
      }
      this.service.post('user/getUser', data, 1).subscribe(success => {
          if (success.responseCode == 200) {
              this.spinnerService.hide();
              this.displayedColumns= ['sno', 'name', 'email', 'userRole','phoneNumber', 'shift', 'petrolPumpName', '_id'];
              const data = [];
              success.result.success.docs.forEach((element,ind) => {
                  data.push({
                      'sno' : ind+1,
                      'name' : element.name,
                      'email' : element.email,
                      'userRole' : element.userRole,
                      'phoneNumber' : element.phoneNumber,
                      'shift' : element.shift,
                      'petrolPumpName' : element.petrolPumpName,
                      '_id' : element._id,
                  })
              });
              this.dataSource = data;
          } else {
              this.spinnerService.hide();
              this.service.showError(success.responseMessage);
          }
      }, error => {
          this.service.showError('Something went wrong');
          this.spinnerService.hide();
      });
  }

  /**Function to open add user modal */
  openAddUserModal() {
      this.addUser.reset();
      this.addUser.patchValue({
          role: '',
          shift: '',
          petrolPump: '',
      })
      $('#addUser').modal({backdrop: 'static', keyboard: false});
  }

  /**Function to add user */
  addUserFunc() {
      let data = {
          "name" : this.addUser.value.name,
          "email": this.addUser.value.email,
          "phoneNumber": '+91' + this.addUser.value.contactNumber,
          "userRole": this.addUser.value.role,
          "shift": this.addUser.value.shift,
          "petrolPumpName": this.addUser.value.petrolPump,
          "password": this.addUser.value.password,
          "address": this.addUser.value.address,
      }
      
      this.service.post('user/addUser', data, 1).subscribe(success => {
          if (success.responseCode == 200) {
              this.spinnerService.hide();
              this.service.showSuccess(success.responseMessage);
              $('#addUser').modal('hide');
          } else {
              this.spinnerService.hide();
              this.service.showError(success.responseMessage);
          }
      }, error => {
          this.service.showError('Something went wrong');
          this.spinnerService.hide();
      });
  }

  openDeleteModal(id) {
      this.id = id;
      $('#deleteUser').modal({keyboard: false, backdrop: 'static'});
  }


  /**Function to delete user */
  deleteUser() {
      let data = {
          "userId" : this.id
      }
      this.service.post('user/deleteUser', data, 1).subscribe(success => {
          if (success.responseCode == 200) {
              this.spinnerService.hide();
              this.service.showSuccess(success.responseMessage);
              $('#deleteUser').modal('hide');
          } else {
              this.spinnerService.hide();
              this.service.showError(success.responseMessage);
              $('#deleteUser').modal('hide');
          }
      }, error => {
          this.service.showError('Something went wrong');
          this.spinnerService.hide();
      });
  }


  /**Function to view user */
  viewUser(id) {
      let data = {
          "userId" : id
      }
      this.service.post('user/viewUser', data, 1).subscribe(success => {
          if (success.responseCode == 200) {
              this.spinnerService.hide();
              this.service.showSuccess(success.responseMessage);
              this.userInfo.email = success.result.email;
              this.userInfo.name = success.result.name;
              this.userInfo.phoneNumber = success.result.phoneNumber;
              this.userInfo.address = success.result.address;
              this.userInfo.userRole = success.result.userRole;
              this.userInfo.shift = success.result.shift;
              this.userInfo.petrolPumpName = success.result.petrolPumpName;
              $('#viewUser').modal({keyboard: false, backdrop: 'static'});
          } else {
              this.spinnerService.hide();
              this.service.showError(success.responseMessage);
              $('#deleteUser').modal('hide');
          }
      }, error => {
          this.service.showError('Something went wrong');
          this.spinnerService.hide();
      });
  }

}
