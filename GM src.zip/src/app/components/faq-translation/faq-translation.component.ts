import { Component, OnInit } from '@angular/core';
import { ServiceService } from 'src/app/service/service.service';
import { ActivatedRoute, Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-faq-translation',
  templateUrl: './faq-translation.component.html',
  styleUrls: ['./faq-translation.component.css']
})
export class FaqTranslationComponent implements OnInit {
  thaiLangId: any;
  chaiLangId: any;
  enLangId: any;
  currentId: any;
  translateThai: any;
  translateChai: any;

  constructor(private service: ServiceService, private activatedRoutes: ActivatedRoute, private router: Router, private spinner: NgxSpinnerService) { }

  ngOnInit() {
    window.scrollTo(0, 0);
    this.activatedRoutes.params.subscribe((id) => {
      this.currentId = id.id;
      this.getFAQTranslation(id.id);
    }); 
  }

  editPage(lang,id) {
    console.log('Id Found ', lang , id);
    this.router.navigate(['add-edit-faq/Edit',lang,id]);
    // this.router.navigate(['add-edit-faq/Edit/' + lang + '/' + this.currentId]);
  }
  addPage(lang) {
    this.router.navigate(['add-edit-faq/Add/' + lang + '/' + this.currentId]);
  }

  getFAQTranslation(id) {
    this.spinner.show();
    this.service.postMethod('static/admin/get-faq-content-translation?faqContentId=' + encodeURIComponent(this.service.encrypt(id)), {}, 1)
      .subscribe((response) => {
        this.spinner.hide();
        this.getThaiAndChaiTranslation(response);
      }, (error) => {
        this.spinner.hide();
      });
  }

  getThaiAndChaiTranslation(response) {
    const langList = response.data.languageList.data;
    langList.forEach(element => {
      if (element.languageShortName === 'th') {
        this.thaiLangId = element.languageId;
      } else if (element.languageShortName === 'ch') {
        this.chaiLangId = element.languageId;
      } else {
        this.enLangId = element.languageId;
      }
    });
    const translationData = response.data.translationList;
    translationData.forEach(element => {
      if (element.fkLanguageId === this.thaiLangId) {
        this.translateThai = element;
        if(this.translateThai.updatedBy == null) {
          this.translateThai.updateTime = null;
        }
      }
      if (element.fkLanguageId === this.chaiLangId) {
        this.translateChai = element;
        if(this.translateChai.updatedBy == null) {
          this.translateChai.updateTime = null;
        }
      }
    });
  }
}
