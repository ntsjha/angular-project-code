export class HorseTraining{
    id:string
    s_no:string
    template_Name:string
    start_Date:string
    end_Date:string
    non_Traning_Days:string
    rest_Days:string
    warm_Up:string
    warm_Down:string
    
}