import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageExchangeFeeWalletComponent } from './manage-exchange-fee-wallet.component';

describe('ManageExchangeFeeWalletComponent', () => {
  let component: ManageExchangeFeeWalletComponent;
  let fixture: ComponentFixture<ManageExchangeFeeWalletComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManageExchangeFeeWalletComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageExchangeFeeWalletComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
