import { Component, OnInit } from '@angular/core';
import { ServiceService } from 'src/app/service/service.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-support-topic-translation',
  templateUrl: './support-topic-translation.component.html',
  styleUrls: ['./support-topic-translation.component.css']
})
export class SupportTopicTranslationComponent implements OnInit {
  translateThai: any = {};
  translateChai: any = {};
  engLangObj: any = {};
  thaiLangId: any;
  chaiLangId: any;
  enLangId: any;
  modeOfAction: any;
  currentTopicId: any;
  constructor(private service: ServiceService, private activatedRoutes: ActivatedRoute, private router: Router, ) { }

  ngOnInit() {
    window.scrollTo(0, 0);
    this.activatedRoutes.params.subscribe((data) => {
      this.currentTopicId = data.id;
    });
    this.getSupportTopicTranslation();
  }

  getSupportTopicTranslation() {
    this.service.getMethod('support/admin/get-support-topic-translation-list?topicId=' + encodeURIComponent(this.service.encrypt(this.currentTopicId)), 1)
      .subscribe((response) => {
        this.getThaiAndChaiTranslation(response);
      }, (error) => {
      });
  }

  getThaiAndChaiTranslation(response) {
    const langList = response.data.languageList.data;
    langList.forEach(element => {
      if (element.languageShortName === 'th') {
        this.thaiLangId = element.languageId;
      } else if (element.languageShortName === 'ch') {
        this.chaiLangId = element.languageId;
      } else {
        this.enLangId = element.languageId;
      }
    });
    const translationData = response.data.translationList;
    translationData.forEach(element => {
      if (element.fkLanguageId === this.thaiLangId) {
        this.translateThai = element;
        if(this.translateThai.updatedByName == null) {
          this.translateThai.updatedAt = null;
        }
      }
      if (element.fkLanguageId === this.chaiLangId) {
        this.translateChai = element;
        if(this.translateChai.updatedByName == null) {
          this.translateChai.updatedAt = null;
        }
      }
      if (element.fkLanguageId === this.enLangId) {
        this.engLangObj = element;
      }
    });
  }

  editPage(lang, id) {
    this.router.navigate(['/add-support-topic/Edit/' + lang + '/' + id]);
  }

}
