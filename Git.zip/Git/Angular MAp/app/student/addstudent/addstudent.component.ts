import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators ,FormArray, FormControl } from '@angular/forms';
import { ServeService } from 'src/app/serve.service';
import { Address } from 'ngx-google-places-autocomplete/objects/address';

@Component({
  selector: 'app-addstudent',
  templateUrl: './addstudent.component.html',
  styleUrls: ['./addstudent.component.css']
})
export class AddstudentComponent implements OnInit {
  
  public myForm: FormGroup;
  st: any[]=new Array;
  objData: {};
  address = [];
  latitude = [];
  longitude = [];
  studentlatlng: { 'lat': any; 'lng': any; };
  studentName: any;
  dummy:{};
  firstname: any;
  dataArray= [];
  add:any[];
  
  
  constructor(public _fb: FormBuilder,public serve: ServeService) { }
  
 
  ngOnInit() {
    this.myForm = this._fb.group({
      
     Student: this._fb.array([this.initlanguage()])
      });
  }

  initlanguage() {
    return this._fb.group({
    name: ['',Validators.required],
    email: [''],
    password: [''],
    address: [''],
    });
    }
    
    
    addLanguage() {
      const control = <FormArray>this.myForm.controls['Student'];
      control.push(this.initlanguage());
    
      }

      removeLanguage(i: number) {
      const control = <FormArray>this.myForm.controls['Student'];
      control.removeAt(i);
      }

      handle(address: Address)
     {
      //  console.log(address)
     this.address.push(address.formatted_address);
     this.latitude.push(address.geometry.location.lat());
     this.longitude.push(address.geometry.location.lng());
    //  console.log(`address`, this.address, `latitude`, this.latitude, `longitude`, this.longitude);
  }

 

      save( ) {
        let control = <FormArray>this.myForm.controls['Student'].value;
        
        //console.log(control)
        for(var i = 0; i < control.length; i++){
          control[i].address = this.address[i];
          control[i].latitude = this.latitude[i];
          control[i].longitude = this.longitude[i];        
        }
        console.log(`control`, control)
        this.serve.student=(control)
        localStorage.setItem('Student', JSON.stringify(control));  
        
        //console.log(this.dataArray)
  
       // this.dataArray.push( this.objData);
       // console.log(this.dataArray);
        // this.st.push(this.address,this.myForm.value,)
        // console.log(this.objData)
       // console.log(this.myForm.value)
      //  this.objData = this.myForm.value
      //  this.st.push(this.objData)
      //  this.serve.student=(this.st)
     // localStorage.setItem('Student', JSON.stringify( this.objData));  



      }

      
      

    }
  