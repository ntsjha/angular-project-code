import { GetBaseSixtyFourPipe } from './get-base-sixty-four.pipe';

describe('GetBaseSixtyFourPipe', () => {
  it('create an instance', () => {
    const pipe = new GetBaseSixtyFourPipe();
    expect(pipe).toBeTruthy();
  });
});
