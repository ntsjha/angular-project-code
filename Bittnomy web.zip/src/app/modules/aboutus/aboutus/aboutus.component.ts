import { Component, OnInit } from '@angular/core';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { AppComponent } from '../../../app.component';
import { HeaderComponent } from '../../header/header/header.component';
import { ServerService } from '../../../service/server.service';

@Component({
    selector: 'app-aboutus',
    templateUrl: './aboutus.component.html',
    styleUrls: ['./aboutus.component.css']
})
export class AboutusComponent implements OnInit {
    pageData: any=[];

    constructor( private spinnerService: Ng4LoadingSpinnerService,private server: ServerService, private appC: AppComponent, public header: HeaderComponent) { }

    ngOnInit() {
        window.scrollTo(0,0);
        this.getUserAgreement();
    }

    getUserAgreement() {
        this.pageData = [];
        this.spinnerService.show();
        this.server.getApi('static/get-static-content?pageKey=Aboutus',0).subscribe((succ) => {
            this.spinnerService.hide();
            if(succ.body.status == 200) {
                this.pageData = succ.body.data.pageData;
            } else if(succ.status == 201) {
                this.appC.showErrToast(succ.message);
            } else if(succ.status == 403) {
                this.header.tokenExpire();
            }
        }, (err) => {
                this.spinnerService.hide();
        });
    }

}
