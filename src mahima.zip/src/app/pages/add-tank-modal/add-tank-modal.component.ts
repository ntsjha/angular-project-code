import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { MainServiceService } from 'src/app/main-service.service';
import { Router } from '@angular/router';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';

@Component({
  selector: 'app-add-tank-modal',
  templateUrl: './add-tank-modal.component.html',
  styleUrls: ['./add-tank-modal.component.css']
})
export class AddTankModalComponent implements OnInit {
  addTankForm: FormGroup;

  constructor(public service: MainServiceService, public router: Router, private spinnerService: Ng4LoadingSpinnerService) { }

  ngOnInit() {
    this.addTankFormMethod();
  }

  addTankFormMethod() {
    this.addTankForm = new FormGroup({
      tankName: new FormControl('', [Validators.required]),
      fuelType: new FormControl('', [Validators.required]),
      vendorName: new FormControl('', [Validators.required]),
      tankBrandName: new FormControl('', [Validators.required]),
      tankNumber: new FormControl('', [Validators.required]),
    })
  }

  get tankName(): any {
    return this.addTankForm.get('tankName');
  }
  get fuelType(): any {
    return this.addTankForm.get('fuelType');
  }
  get vendorName(): any {
    return this.addTankForm.get('vendorName');
  }
  get tankBrandName(): any {
    return this.addTankForm.get('tankBrandName');
  }
  get tankNumber(): any {
    return this.addTankForm.get('tankNumber');
  }

  addTank() {
    console.log(this.addTankForm.value);
    let tankData =
    {
      "tankName": this.addTankForm.value.tankName,
      "tankNumber": this.addTankForm.value.tankNumber,
      "fuelType": this.addTankForm.value.fuelType,
      "brand": this.addTankForm.value.tankBrandName,
      "vendorName": this.addTankForm.value.vendorName,
    }
    this.spinnerService.show();
    this.service.post('user/addTank', tankData, 1).subscribe(res => {

      if (res['responseCode'] == 200) {
        this.service.showSuccess(res['responseMessage'])
        this.addTankForm.reset();

      } else {

      }
      this.spinnerService.hide();
      console.log(res)
    }, error => {
      console.log(error)
    })

  }

}
