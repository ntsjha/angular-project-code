import { Component, OnInit } from '@angular/core';
import { ServiceService } from 'src/app/service/service.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { Router } from '@angular/router';

@Component({
  selector: 'app-minimum-trading',
  templateUrl: './minimum-trading.component.html',
  styleUrls: ['./minimum-trading.component.css']
})
export class MinimumTradingComponent implements OnInit {
  minTrading: any;

  constructor(
    private service: ServiceService,
    private spinner: NgxSpinnerService,
    private route: Router) { }

  ngOnInit() {
    this.getMinTrading();
    window.scrollTo(0, 0);
  }
  goToMinTradingFee() {
    this.route.navigate(['/minimum-trading-fee']);
  }

  getMinTrading() {
    this.spinner.show();
    this.service.getMethod('fee/fetch-taker-maker', 1).subscribe((response: any) => {
      this.spinner.hide();
      if (response.status === 200) {
        if (response.data.length) {
          this.minTrading = response.data[0];
        } else {
          this.minTrading = response.data;
        }
        this.minTrading.forEach(element => {
          if (element.updatedBy == null) {
            element.updatedAt = null;
          }
        });
      }
    }, (error) => {
      this.spinner.hide();
    });
    this.spinner.hide();
  }

}
