import { Component, Renderer2 } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Router, NavigationEnd } from '@angular/router';
import { Observable, Subject } from '../../node_modules/rxjs';
import { ServerService } from './service/server.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { ExchangeComponent } from './modules/exchange/exchange/exchange.component';
import { ExchangepairComponent } from './modules/exchangepair/exchangepair/exchangepair.component';

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.css']
})
export class AppComponent {
    title = 'app';
    display=false;
    
    private subject= new Subject<any>()

    constructor(private toasterService: ToastrService, private router:Router, public server: ServerService, private spinnerService: Ng4LoadingSpinnerService,private renderer: Renderer2) {
        var self = this;
        $( document ).bind( "mousedown", function(e) {
            if(e.button == 0){
                self.checkSession();
            }
        });
    }
    
    ngOnInit() {
        this.initWsSocket();
        this.checkSession();
        if(localStorage.getItem('cookieToken') == null) {
            this.display = true;
        }
        this.router.events.subscribe(x=> {
            if(x instanceof NavigationEnd) {
                //this.subject.next({text: "url_Changed"});
                if(x.url.includes('/header/exchange')) {
                    this.renderer.addClass(document.body, 'nightmode');
                    this.subject.next({ text: "modeChange" });
                } else {
                    this.renderer.removeClass(document.body, 'nightmode');
                    this.subject.next({ text: "modeChange" });
                    if(this.server.activatedSocket == "Binance") {
                        this.server.liquidityWS.close();
                        this.server.liquidityWSTrade.close();
                        this.server.liquidityWSDepth.close();
                    } 
                }
                // if(localStorage.getItem('token')!= null)  {
                //     if((x.url == '/header/login')|| (x.url == '/header/signup') || (x.url == '/header/forgotpassword')) {
                //         this.router.navigate(['']);
                //     }
                // }
                // /** url mgmt before login */
                // else {
                //     if((x.url == '/header/wallet') || (x.url == '/header/profile')|| (x.url == '/header/transactionDetail')|| (x.url == '/header/deposit')|| (x.url == '/header/withdraw')|| (x.url == '/header/fiathistory')|| (x.url == '/header/order')) {
                //         this.router.navigate([''])
                //     }
                // }        
            } 
        });
    }

    /** Function for fired to child component */
    fireToChild(): Observable<any> {
        return this.subject.asObservable();
    }

    // /** Function to init ws */
    initWsSocket() {
        localStorage.getItem("token") ? this.server.initSocket() : this.server.initSocket();
    }

    /** Function to show success toast */
    showSuccToast(msg) {        
        this.toasterService.success(msg, "BITTNOMY");
    }

    /** Function to show error toast */
    showErrToast(msg) {
        this.toasterService.error(msg, "BITTNOMY");
    }

    /** Function to show warning toast */
    showWarnToast(msg) {
        this.toasterService.warning(msg, "BITTNOMY");
    }

    /** Function to show info toast */
    showInfoToast(msg) {
        this.toasterService.info(msg, "BITTNOMY");
    }

    /** Function for handle cookies popup */
    cookie() {
        this.display = false;
        localStorage.setItem("cookieToken",'true');
    }

    /** Function to navigate privacy policy screen */
    privacy() {
        this.router.navigateByUrl('header/privacyPolicy');
    }

    /** Function for check session */
    checkSession() {
        if(localStorage.getItem('token') != null && localStorage.getItem('session') != null) {
            let minDiff = this.diff_minutes(parseInt(localStorage.getItem('session')), new Date().getTime());
            localStorage.setItem('session',new Date().getTime().toString());
            if(minDiff >= 15){
               // this.logout();
            } 
        } else
            localStorage.setItem('session',new Date().getTime().toString());
    }

    /** Function to get diffrence between timestamp */
    diff_minutes(dt2, dt1) {
        var diff = (dt2 - dt1) / 1000;
        diff /= 60;
        return Math.abs(Math.round(diff));
    }

    /** Function for logout user */
    // logout() {
    //     let data = {            
    //         "eventExternal": {
    //             "name":"request_logout",
    //             "key":"mykey"
    //         },
    //         "transferObjectMap": { 
    //             "gatewayrequest": {
    //                 "token": localStorage.getItem('token')
    //             }
    //         }
    //     }
    //     this.server.postApi('', data,0).subscribe(response => {
    //         if (response.transferObjectMap.statusCode == 200 || response.transferObjectMap.statusCode == 403) {
    //             localStorage.clear();
    //             this.subject.next({ text: "sessionExpire" });
    //             this.router.navigate(['header']);
    //         } 
    //     }, error => {
    //     });
    // }
}
