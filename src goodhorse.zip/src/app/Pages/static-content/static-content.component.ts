import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ServiceService } from 'src/app/Shared/service.service';
import { AngularFirestore } from '@angular/fire/firestore';
import { StaticContent } from 'src/app/Shared/feed-type';

@Component({
  selector: 'app-static-content',
  templateUrl: './static-content.component.html',
  styleUrls: ['./static-content.component.css']
})
export class StaticContentComponent implements OnInit {

  p: number = 1;
  staticContent: { docname: string; lastupdate: string; dopdownname: string; }[];
  resdata: any = [];
  constructor(public router: Router, private afs: AngularFirestore, public route: ActivatedRoute, private firebaseServ: ServiceService) { }

  ngOnInit() {

    this.staticContent = [
      { docname: 'Aboutus', lastupdate: '', dopdownname: 'About Us' },
      { docname: 'Authorsay', lastupdate: '', dopdownname: 'Author say' },
      { docname: 'Terms&condition', lastupdate: '', dopdownname: 'Terms and Conditions' },
      { docname: 'PrivacyPolicy', lastupdate: '', dopdownname: 'Privacy Policy' },
      { docname: 'FAQ', lastupdate: '', dopdownname: 'FAQ' },
    ]
    this.getstaticContent()
  }

  async getstaticContent() {
    this.firebaseServ.showSpinner();
    this.firebaseServ.getstaticTime().subscribe(actionArray => {
      // console.log('=========>', actionArray)
      this.firebaseServ.hideSpinner();
      var userList = actionArray.map(item => {
        // console.log('Items====>', item)
        return {
          id: item.payload.doc.id,
          ...item.payload.doc.data()

        } as StaticContent;

      })
      console.log("user Count--->>>", userList)
      
      userList.forEach(element => {
        // console.log('ind', element)
        var ind = this.staticContent.findIndex((data) => data.docname == element.id)
        if (ind != -1) {
        
          this.firebaseServ.hideSpinner();
          console.log("user Count--->>>", element)
          this.staticContent[ind].lastupdate = element.Lastupdate
          this.staticContent[ind].dopdownname =element.Title
        }
      });

    });
    // console.log("user Count--->>>", this.staticContent)
  }

  gotoviewSetting(section, dropdown) {

    this.router.navigate(['/static-content/view-static-content/id'], {
      queryParams: { value:dropdown, docname:section }
    })

  }

  gotoeditSetting(section, dropdown) {

    this.router.navigate(['/static-content/edit-static-content/id'], {
      queryParams: { value:dropdown, docname:section }
    })

  }



}
