import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FiatWithdrawlReqComponent } from './fiat-withdrawl-req.component';

describe('FiatWithdrawlReqComponent', () => {
  let component: FiatWithdrawlReqComponent;
  let fixture: ComponentFixture<FiatWithdrawlReqComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FiatWithdrawlReqComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FiatWithdrawlReqComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
