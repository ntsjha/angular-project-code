import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { AlertController ,NavController, LoadingController } from '@ionic/angular';
import { Storage } from '@ionic/storage';
import { MenuController } from '@ionic/angular';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  
  slideOpts = {
    effect: 'flip'
  };
 
  userinfo: any;
  local;
  @ViewChild('map') mapElemet:ElementRef;

  mapElement: any;

  constructor(public alertController: AlertController,public loadingController: LoadingController,private storage: Storage,private menu: MenuController) {
   }



  async ngOnInit() {
    const loading = await this.loadingController.create({
      message: 'Please Wait',
      duration: 2000
    });
    await loading.present();

    this.userinfo= JSON.parse(localStorage.getItem('information'));

    this.storage.get('age').then((val) => { console.log('Your age is', val);
    this.local=val;
   
  });
   
 
  }
  call(){
    console.log(this.local);
    console.log(this.userinfo);
  }
  openFirst() {
    this.menu.enable(true, 'first');
    this.menu.open('first');
  }

  openEnd() {
    this.menu.open('end');
  }

  openCustom() {
    this.menu.enable(true, 'custom');
    this.menu.open('custom');
  }
}
