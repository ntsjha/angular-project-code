import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SelectpetrolpumpComponent } from './selectpetrolpump.component';

describe('SelectpetrolpumpComponent', () => {
  let component: SelectpetrolpumpComponent;
  let fixture: ComponentFixture<SelectpetrolpumpComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SelectpetrolpumpComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SelectpetrolpumpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
