import { Component, OnInit } from '@angular/core';
import { AngularCsv } from 'angular7-csv/dist/Angular-csv';
import { FormGroup } from '@angular/forms';
import { Subject } from 'rxjs';
import { ServiceService } from 'src/app/service/service.service';
import { Router } from '@angular/router';


@Component({
    selector: 'app-market-makers',
    templateUrl: './market-makers.component.html',
    styleUrls: ['./market-makers.component.css']
})
export class MarketMakersComponent implements OnInit {
    marketList: any = [];
    changeStatusForm: FormGroup;
    assignOperatorForm: FormGroup;
    disable: boolean = false;
    page: any = 1;
    searchTerm$ = new Subject<string>();
    status: any;
    search_key: any = '';
    pageSize: any = '10';
    constructor(public service: ServiceService, public router: Router) {
        this.service.search(this.searchTerm$).subscribe(results => {
            this.search_key = results;
        });
    }

    ngOnInit() {
        window.scrollTo(0, 0);
        this.getTicketList();
    }
    getTicketList() {
        this.service.postMethod('', {}, 1).subscribe((res) => {
            if (res.data) {
                this.marketList = res.data;
            }
        });
    }
    closeModal() {
        this.disable = false;
        this.resetForm();
    }

    resetForm() {
        this.assignOperatorForm.reset();
        this.changeStatusForm.reset();
    }

    viewDetail(id) {
        this.router.navigate(['ticket-details', id]);
    }

    filterBySearch() {
        if (this.search_key || this.status) {
            this.marketList = [];
            let data = {
                "page": this.service.encrypt(this.page),
                "pageSize": this.service.encrypt(this.pageSize),
                "search": this.service.encrypt(this.search_key),
                "status": this.service.encrypt(this.status)
            };

            if (this.search_key) {
                data['search'] = this.service.encrypt(this.search_key);
            } else {
                data['search'] = null;
            }

            if (this.status) {
                data['status'] = this.service.encrypt(this.status);
            } else {
                data['status'] = null;
            }

            this.service.postMethod('support/search-ticket-list', data, 1).subscribe((res) => {
                if (res.data.list) {
                    this.marketList = res.data.list;
                }
                this.status = '';
            });
        }
    }

    onStatusChange(val) {
        this.status = val;
    }

    exportList() {
        var options = {
            fieldSeparator: ',',
            quoteStrings: '"',
            decimalseparator: '.',
            showLabels: true,
            showTitle: true,
            title: 'Market List :',
            useBom: true,
            noDownload: false,
            headers: ['Cust Id', 'Cust Name', 'Cust Email', 'Cust Phone', 'Type Of Customer']
        };

        let data = [];

        this.marketList.forEach((element, index) => {
            let obj = {
                'cust_id': index + 1,
                'cust_name': element.subject,
                'cust_email': element.date,
                'cust_phone': element.customerName || '---',
                'cust_type': element.customerEmail || '---',
            };
            data.push(obj);
        });
        new AngularCsv(data, 'Tickets', options);
    }
}
