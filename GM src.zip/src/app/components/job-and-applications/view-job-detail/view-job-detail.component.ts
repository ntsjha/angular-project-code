import { NgxSpinnerService } from 'ngx-spinner';
import { ActivatedRoute } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { ServiceService } from 'src/app/service/service.service';

@Component({
  selector: 'app-view-job-detail',
  templateUrl: './view-job-detail.component.html',
  styleUrls: ['./view-job-detail.component.css']
})
export class ViewJobDetailComponent implements OnInit {

  paramData: any;
  jobDetail: any;

  constructor(
    private activatedRoute: ActivatedRoute,
    private service: ServiceService,
    private spinner: NgxSpinnerService
  ) { }

  ngOnInit() {
    this.getParamData();
    window.scrollTo(0, 0);
  }

  getParamData() {
    this.activatedRoute.params.subscribe(param => {
        this.paramData = param;
        this.getJobData();
    });
  }

  getJobData() {
    this.spinner.show();
    this.service.getMethod(`career/admin/get-job-slug-name?language=${encodeURIComponent(this.service.encrypt(this.paramData.lang))}&contentId=${encodeURIComponent(this.service.encrypt(this.paramData.id))}` , 1).subscribe((success: any) => {
        this.spinner.hide();
        const decryptedData = success.data ? JSON.parse(this.service.decrypt(success.data)) : {};
        if (decryptedData.status === 805) {
            this.jobDetail = decryptedData.data;
        }
    }, error => {
      this.spinner.hide();
    });
  }

}
