import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppComponent } from '../../../app.component';
import { ServerService } from '../../../service/server.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { HeaderComponent } from '../../header/header/header.component';
import { Angular5Csv } from 'angular5-csv/Angular5-csv';
import { DatePipe } from '@angular/common';

@Component({
    selector: 'app-order',
    templateUrl: './order.component.html',
    styleUrls: ['./order.component.css']
})
export class OrderComponent implements OnInit {
    activeTab = "";
    openOrderArr = [];
    orderHisArr = [];
    tradeHisArr = [];
    coinListArr: any;
    currentCoinObj = {coinShort:"BTC", coinFullName:"", coinId:""};    
    currentPairCoinObj = {coinShort:"", coinFullName:"", coinId:""};
    analyticData: any = {averageBuy:"0.00000000", totalBuy:"0.00000000", averageSell:"0.00000000",totalSell:"0.00000000"};exeCoin: any;
    baseCoin: any;
    orderHistoryArr: any;
    data: any=[];
    analysdata: any;
    selladd: number;
    coinpairdata: any=[];
;
    coinPairListArr: any[];

    constructor(private router: Router, private appC: AppComponent, private server: ServerService, private spinnerService: Ng4LoadingSpinnerService, public header: HeaderComponent, public datepipe: DatePipe) { }

    ngOnInit() {
        window.scrollTo(0, 0);
        this.activeTab = 'order';
        // this.openOrderAPI();
        this.getCoinList();
        
    }

    /** Function for tab click */
    tabClick(val) {
        this.activeTab = val;
        switch(val) {
            case "order":
                this.openOrderAPI();

                break;
            case "history":
                // this.tradeHistoryAPI();
               this.orderHistoryAPI();
                  //this.getCoinList();
                break;
            case "trade":
                break;
        }
    }


    getCoinList() {
        this.spinnerService.show();
        this.server.getApi('wallet/coin/get-coin-list', 0).subscribe((succ) => {
            this.spinnerService.hide();
            if (succ.body.status == 200) {
                let data = succ.body.data;
                this.coinListArr = data.filter((x) => x.coinType=="crypto" && (x.coinShortName == 'IPR' ||x.coinShortName == 'BTC' || x.coinShortName == 'ETH' || x.coinShortName == 'USDT'));
               
                this.getCoinPair(this.coinListArr[0].coinShortName)
                this.getCoinPairdata(this.coinListArr[0].coinShortName)
                this.currentCoinObj.coinId = this.coinListArr[0].coinId;
                this.baseCoin = this.coinListArr[0].coinShortName;
                this.currentCoinObj.coinFullName = this.coinListArr[0].coinFullName;
               
            } else {
                this.appC.showErrToast(succ.body.message);
            }
        }, (err) => {
            this.spinnerService.hide();
        });
        
    }
    onclickbasecoin(value){
      
        this.baseCoin=value
        if(this.baseCoin!= this.exeCoin || this.exeCoin!='undefined'){
           
            this.getCoinPair(this.baseCoin) 
           }
           else{
            this.appC.showErrToast('Please select correct coinpair')
           }
    }
    clickgetCoinPair(value){
       this.exeCoin =value
       console.log('exe',this.exeCoin)
      
        this.openOrderAPI() 
        this.orderHistoryAPI()
        // this.getAnalysisFunc();
    }


    getCoinPair(coinShortName) {
        // console.log('data==>',coinShortName)
        this.coinPairListArr = [];
        this.spinnerService.show();
        this.server.getApi('wallet/coin/get-coin-pair-list?baseCoin=' + coinShortName, 0).subscribe((succ) => {
            this.spinnerService.hide();
            if (succ.body.status == 200) {
               this.data = [];
                this.coinPairListArr = [];
                succ.body.data.forEach(obj => {
                    if (obj.coinShortName == 'BTC' || obj.coinShortName == 'ETH' || obj.coinShortName == 'XRP' || obj.coinShortName == 'BCH' || obj.coinShortName == 'XLM' || obj.coinShortName == 'LTC' || obj.coinShortName == 'IOTA' || obj.coinShortName == 'USDT' || obj.coinShortName == 'XVG' || obj.coinShortName == 'IPR' || obj.coinShortName == 'ECH') {
                        this.data.push(obj);
                      
                    }
                });
                // let ind = this.coinListArr.findIndex((x) => x.coinShortName == coinShortName);
                // if (ind > -1) {
                //     this.coinListArr[ind].pairList = data;
                //     this.coinListArr[ind].pairList.forEach((obj) => {
                //         obj.last_price = '0.0';
                //     });
                // }

                // console.log('data--->',this.data)
                // console.log('coinshorname--->',coinShortName)
                // this.getAnalysisFunc();
               
            } else {
                this.coinPairListArr = [];
                this.appC.showErrToast(succ.transferObjectMap.message);
            }
        }, (err) => {
            this.spinnerService.hide();
        });
    }

    



    /** Function to get all open order of user's */
    openOrderAPI(){
       this.openOrderArr=[];
        if(localStorage.getItem('token')){
            //    console.log('OPENHISTROY==>',this.baseCoin+'_'+this.exeCoin)
                this.spinnerService.show();
                this.server.getApi('order-service-eth_btc/my-active-orders?symbol='+this.baseCoin+'_'+this.exeCoin,localStorage.getItem('token')).subscribe(response => {
                    this.spinnerService.hide();
                    if (response.status == 200) {
                        
                        // this.openOrderArr = response.body.data;
                       
                        response.body.data.forEach((element) => {
                            if(element.orderStatus == 'PARTIALLY_EXECUTED') {
                                this.openOrderArr.push({
                                    total : (element.avgExecutionPrice*element.currentQuantity).toFixed(8),
                                    creationTime : element.creationTime,
                                    instrument : element.instrument,
                                    orderSide : element.orderSide,
                                    limitPrice : element.avgExecutionPrice.toFixed(8),
                                    quantity : element.currentQuantity.toFixed(8),
                                    orderStatus : element.orderStatus,
                                    orderId: element.orderId,
                                    orderType: element.orderType,
                                    filled: (((element.quantity-element.currentQuantity)/element.quantity)*100).toFixed(8),
                                    click : false
                
                                }) ;
                            }  
                            else if(element.orderStatus == 'QUEUED') {
                               
                                this.openOrderArr.push({
                                    total : (element.limitPrice*element.currentQuantity),
                                    creationTime : element.creationTime,
                                    instrument : element.instrument,
                                    orderSide : element.orderSide,
                                    limitPrice : element.limitPrice,
                                    quantity : element.currentQuantity,
                                    orderStatus : element.orderStatus,
                                    orderId: element.orderId,
                                    orderType: element.orderType,
                                    filled: (((element.quantity-element.currentQuantity)/element.quantity)*100).toFixed(8),
                                    click : false
                
                                }) ;
                              
                             } 
                    });
                   
                    // console.log("Response--->",this.openOrderArr)
                } else if(response.statusCode == 403) {
                        this.header.logOut();
                    } else {
                        this.appC.showErrToast(response.message);
                    }
                }, error => {
                    this.spinnerService.hide()
                   
                    this.appC.showErrToast(error.error.error);
                });
            }
    }

    /** Function to get all order history data of user's */
    orderHistoryAPI(){
        this.orderHistoryArr=[]
        if(localStorage.getItem('token')){
         let add='0'
       
            this.spinnerService.show();
            this.server.getApi('order/my-order-history?symbol='+this.baseCoin+'_'+this.exeCoin,localStorage.getItem('token')).subscribe(response => {
                this.spinnerService.hide();
                if (response.status == 200) {
                    let add=0;
                     this.orderHistoryArr = response.body.data;
                     this.orderHistoryArr.forEach((obj) => {
                       
                        switch(obj.orderStatus) {
                            case 'COMPLETED':
                           
                            // add +=Number(obj.quantity)
                            // console.log('total==>',add )
                                obj.amount = (obj.tradeHistoryAmount - obj.quantity).toFixed(8);
                                obj.total = (obj.quantity * obj.limitPrice).toFixed(8);
                                obj.filled= (((obj.quantity-obj.currentQuantity)/obj.quantity)*100).toFixed(8);
                          
                                 break;
                            case 'QUEUED':
                                obj.amount = obj.tradeHistoryAmount.toFixed(8);
                                obj.total = (obj.quantity * obj.limitPrice).toFixed(8);
                                obj.filled= (((obj.quantity-obj.currentQuantity)/obj.quantity)*100).toFixed(8);
                          
                                break;
                             case 'CREATED':
                                obj.amount = obj.tradeHistoryAmount.toFixed(8);
                                obj.total = (obj.quantity * obj.limitPrice).toFixed(8);
                                obj.filled= (((obj.quantity-obj.currentQuantity)/obj.quantity)*100).toFixed(8);
                          
                                break;
                            case 'CANCELLED':
                                obj.amount = obj.amount;
                                obj.total = (obj.quantity * obj.limitPrice).toFixed(8);
                                obj.filled= (((obj.quantity-obj.currentQuantity)/obj.quantity)*100).toFixed(8);
                                break;
                        }
                    });
                    
                     this.orderHistoryArr.forEach((obj) => {
                        this.tradeHisArr.forEach(element => {
                            if(obj.userId == element.userId && obj.orderId == element.orderId) {
                                obj.fee  = element.commissionFee;
                                obj.grandTotal = Number(obj.total) - Number(element.commissionFee);
                                obj.filled= (((obj.quantity-obj.currentQuantity)/obj.quantity)*100).toFixed(8);
                                
                            }
                        }); 
                    });
                    console.log('histroy==>',this.orderHistoryArr)
                    // this.getAnalysisFunc();
                } else if(response.status == 403) {
                    this.header.logOut();
                } else {
                    this.orderHisArr = [];
                    this.appC.showErrToast(response.message);
                }
            }, error => {
                this.spinnerService.hide()
                this.appC.showErrToast(error.error.error);
            });
        }
    }

  

    cancelOrder(order) {
        order.click = true;
        let data = {
               "orderId": order.orderId,
               "symbol":order.instrument
                }
        //   console.log('delete data===>',data)
        this.spinnerService.show();
        this.server.postApi("order-service-eth_btc/cancel-order",data, localStorage.getItem('token')).subscribe((succ) => {
            
            this.spinnerService.hide();
            if(succ.status == 200) {
                this.appC.showInfoToast(succ.body.message);
                if(localStorage.getItem("token")) {
                    this.openOrderAPI();
                    this.orderHistoryAPI()
                   
                }
                         
            }  else if(succ.status == 403)  { 
                this.header.logOut();
            } else {
                this.appC.showErrToast(succ.message);
                order.click = false;
            }
        }, (err) => {
            this.spinnerService.hide();
            this.appC.showErrToast(err.error.error)
        });
    }

    /** Function for export data */
    exportData() {
        if(this.activeTab == 'history') {
        let data = [];
        data.push({
            date: "Date",
            pair: "Pair",
            type: "Type",
            price: "Price",
            amount: "Amount",
            filled: "Filled",
            total: "Total",
            status: "Status"
        });
        console.log('open==>',this.orderHistoryArr)
        this.orderHistoryArr.forEach((obj) => {
            data.push({
                date: this.convertFormat(obj.creationTime),
                pair: obj.instrument,
                type: obj.orderType,
                price: obj.limitPrice?obj.limitPrice:0.00000,
                amount: obj.quantity,
                filled: obj.orderStatus=="INACTIVE" ? "100" :(((obj.quantity-obj.currentQuantity)/obj.quantity)*100).toFixed(8),
                total: obj.total? obj.total:obj.quantity,
                status: obj.orderStatus,
            });
        });
        new Angular5Csv(data, 'Bittnomy Order History Report');

        // } else if(this.activeTab == 'trade') {
        //     let data = [];
        //     data.push({
        //         date: "Date",
        //         pair: "Pair",
        //         Ttype: "Trading Type",
        //         Otype: "Order Type",
        //         volume: "Volume",
        //         fee: "Fee",
                
        //     });
        //     this.tradeHisArr.forEach((obj) => {
        //         data.push({
        //             date: this.convertFormat(obj.orderTime),
        //             pair: obj.toCoin+'/'+obj.fromCoin,
        //             Ttype: obj.tradingType,
        //             Otype: obj.orderType,
        //             volume: obj.totalVolume,
        //             fee: obj.feeVolume,
                    
        //         });
        //     });
        //     new Angular5Csv(data, 'Bittnomy Trade History Report');
         }
    }

    /** Function to convert date format */
    convertFormat(time) {
        return this.datepipe.transform(time, 'MM/dd/yyy, hh:mm a');
    }

    /** Function to manage exponential data */
    manageExponential(num) {
        //if the number is in scientific notation remove it
        if(num != 'NaN') {
            if (/\d+\.?\d*e[\+\-]*\d+/i.test(num)) {
                var zero = '0',
                parts = String(num).toLowerCase().split('e'), //split into coeff and exponent
                es = Number(parts.pop()), //store the exponential part
                l = Math.abs(es), //get the number of zeros
                sign = es / l,
                coeff_array = parts[0].split('.');
                if (sign === -1) {
                    num = zero + '.' + new Array(l).join(zero) + coeff_array.join('');
                } else {
                    var dec = coeff_array[1];
                    if (dec) l = l - dec.length;
                    num = coeff_array.join('') + new Array(l + 1).join(zero);
                }
                return num;
            } else {
                return num;
            }
        } else {
            return 0.00000000;
        }
        
    };


    

    /** Function for coin change */
    coinChangeFunc() {
        this.currentPairCoinObj.coinShort = '';
        this.currentCoinObj.coinId = this.coinListArr.filter((x) => x.coinShortName == this.currentCoinObj.coinShort)[0].coinId;
        // this.getCoinPair();
        // console.log('',this.currentCoinObj.coinShort,this.currentPairCoinObj.coinShort)
        this.getCoinPairdata(this.currentCoinObj.coinShort);
        console.log('pairr',this.currentCoinObj.coinShort)
    }
    getCoinPairdata(data){
        this.coinPairListArr = [];
        this.spinnerService.show();
        this.server.getApi('wallet/coin/get-coin-pair-list?baseCoin=' + data, 0).subscribe((succ) => {
            this.spinnerService.hide();
            if (succ.body.status == 200) {
               this.coinpairdata = [];
                this.coinPairListArr = [];
                succ.body.data.forEach(obj => {
                    if (obj.coinShortName == 'BTC' || obj.coinShortName == 'ETH' || obj.coinShortName == 'XRP' || obj.coinShortName == 'BCH' || obj.coinShortName == 'XLM' || obj.coinShortName == 'LTC' || obj.coinShortName == 'IOTA' || obj.coinShortName == 'USDT' || obj.coinShortName == 'XVG' || obj.coinShortName == 'IPR' || obj.coinShortName == 'ECH') {
                        this.coinpairdata.push(obj);
                      
                    }
                });
              
            } else {
                this.coinPairListArr = [];
                this.appC.showErrToast(succ.transferObjectMap.message);
            }
        }, (err) => {
            this.spinnerService.hide();
        });


    }
    getanalyspair(data){
        this.currentPairCoinObj.coinShort=data
        console.log('analys',this.currentPairCoinObj.coinShort)
     
    }

    getAnalysisFunc() {
      
        this.analyticData.selladd  = 0;
        this.analyticData.buyadd = 0;
        if(localStorage.getItem('token')){
            let countbuy=0
            let countsell=0
               this.spinnerService.show();
               this.server.getApi('order/my-order-history?symbol='+this.currentCoinObj.coinShort+'_'+this.currentPairCoinObj.coinShort,localStorage.getItem('token')).subscribe(response => {
                   this.spinnerService.hide();
                   if (response.status == 200) {
                    
                    this.analysdata = response.body.data;
                    this.analysdata.forEach((obj) => {
                       
                       if(obj.orderSide=='SELL' && obj.orderStatus=='COMPLETED' ) {
                          
                        countsell++
                        this.analyticData.selladd += Number(obj.quantity)
                        this.analyticData.averageSell  =this.analyticData.selladd /countsell
                        
                       }
                         else if(obj.orderSide=='BUY'  && obj.orderStatus=='COMPLETED')  
                         {     
                             countbuy++
                           
                            this.analyticData.buyadd += Number(obj.quantity)
                            this.analyticData.averageBuy  = this.analyticData.buyadd /countbuy
                           
                              
                            }
                        });
                        // console.log('totaladd==>',this.analyticData.selladd , this.analyticData.averageSell)
                        // console.log('totalbuy==>',  this.analyticData.buyadd, this.analyticData.averageBuy)
                    }
    
                });             
            }
        // this.spinnerService.show();
        // this.server.postApi('',data,0).subscribe((succ) => {
        //     this.spinnerService.hide();
        //     if(succ.transferObjectMap.statusCode == 200) {
        //         this.analyticData = succ.transferObjectMap.buySellDetails;
        //     } else {
        //         this.appC.showErrToast(succ.transferObjectMap.message);
        //     }
        // }, (err) => {
        //     this.spinnerService.hide();
        // });
    }

  /** Function to get all trade history data of user's */
  tradeHistoryAPI(){
    if(localStorage.getItem('token')){
        let data = {
            "eventExternal": {
                "name": "request_get_user_commission",
                "key": "mykey"
            },
            "transferObjectMap": {
                "gatewayrequest": {
                    "token": localStorage.getItem("token")
              }
            }
        }  
        this.spinnerService.show();
        this.server.getApi('order/order-history?userId='+localStorage.getItem('token'),localStorage.getItem('token')).subscribe(response => {
            this.spinnerService.hide();
            if (response.status == 200) {
                // this.tradeHisArr = response.result;
                // this.tradeHisArr.forEach(obj => {
                //     obj.userShare = obj.totalVolume - obj.feeVolume
                // });
                this.appC.showSuccToast('trade history Working') 
                 this.orderHistoryAPI();
                
            } else if(response.status == 403) {
                this.header.logOut();
            } else {
                this.tradeHisArr = [];
                this.appC.showErrToast(response.transferObjectMap.message);
            }
        }, error => {
            this.spinnerService.hide()
            this.appC.showErrToast(error.error.error);
        });
    }
}


    /** Function to get coin list from api */
    // getCoinList() {
    //     let data = {
    //         "eventExternal":  {
    //             "name":"request_get_coin_list",
    //             "key":"mykey"
    //         },
    //         "transferObjectMap":{}
    //     }
    //     this.spinnerService.show();
    //     this.server.postApi('',data,0).subscribe((succ) => {
    //         this.spinnerService.hide();
    //         if(succ.transferObjectMap.statusCode == 200) {
    //             let data = succ.transferObjectMap.coinList;
    //             this.coinListArr = data.filter((x) => x.coinType=="crypto" && (x.coinShortName == 'IPR' ||x.coinShortName == 'BTC' || x.coinShortName == 'ETH' || x.coinShortName == 'USDT'));
    //             this.currentCoinObj.coinId = this.coinListArr[0].coinId;
    //             this.currentCoinObj.coinShort = this.coinListArr[0].coinShortName;
    //             this.getCoinPair();
    //         } else {
    //             this.appC.showErrToast(succ.transferObjectMap.message);
    //         }
    //     }, (err) => {
    //         this.spinnerService.hide();
    //     });
    // }

    /** Function to get coin pair list from api*/
    // getCoinPair() {
    //     this.coinPairListArr = [];
    //     let data = {
    //         "eventExternal": {
    //             "name": "request_coin_pair_list",
    //             "key": "mykey"
    //         },
    //         "transferObjectMap": {
    //             "gatewayrequest": {
    //                 "baseCurrency":this.currentCoinObj.coinId
    //             }
    //         }
    //     }
    //     this.spinnerService.show();
    //     this.server.postApi('',data,0).subscribe((succ) => {
    //         this.spinnerService.hide();
    //         if(succ.transferObjectMap.statusCode == 200) {
    //             // let data = succ.transferObjectMap.coinPairList;
    //             let data = [];
    //             succ.transferObjectMap.coinPairList.forEach(obj => {
    //                 if(obj.coin_short_name == 'BTC'|| obj.coin_short_name == 'ETH'|| obj.coin_short_name == 'XRP'|| obj.coin_short_name == 'BCH'|| obj.coin_short_name == 'XLM'|| obj.coin_short_name == 'LTC'|| obj.coin_short_name == 'IOTA' || obj.coin_short_name == 'USDT' || obj.coin_short_name == 'XVG' || obj.coin_short_name == 'IPR') {
    //                     data.push(obj);
    //                 }
    //             });
    //             // let cPairListArr = succ.transferObjectMap.coinLastPairList;
    //             data.forEach((obj) => {
    //                 this.coinPairListArr.push({
    //                     coinID: obj.coin_id,
    //                     coin: obj.coin_short_name,
    //                     coinFullName: obj.coin_full_name,
    //                     volume: obj.volume,
    //                     average: obj.average
    //                 });
    //             });
    //                 // if(this.currentCoinObj.coinShort == 'USDT') {
    //                 //     data.forEach((obj) => {
    //                 //         if(obj.coin_short_name == 'BTC'|| obj.coin_short_name == 'ETH'|| obj.coin_short_name == 'XRP'|| obj.coin_short_name == 'BCH'|| obj.coin_short_name == 'XLM'|| obj.coin_short_name == 'LTC'|| obj.coin_short_name == 'IOTA') {
    //                 //             this.coinPairListArr.push({
    //                 //                 coinID: obj.coin_id,
    //                 //                 coin: obj.coin_short_name,
    //                 //                 coinFullName: obj.coin_full_name,
    //                 //                 volume: obj.volume,
    //                 //                 average: obj.average
    //                 //             });
    //                 //         } 
    //                 //     });
    //                 // } else if(this.currentCoinObj.coinShort == 'IPR') {
    //                 //     data.forEach((obj) => {
    //                 //         if(obj.coin_short_name == 'XRP'|| obj.coin_short_name == 'XLM'|| obj.coin_short_name == 'LTC'|| obj.coin_short_name == 'IOTA') {
    //                 //             this.coinPairListArr.push({
    //                 //                 coinID: obj.coin_id,
    //                 //                 coin: obj.coin_short_name,
    //                 //                 coinFullName: obj.coin_full_name,
    //                 //                 volume: obj.volume,
    //                 //                 average: obj.average
    //                 //             });
    //                 //         } 
    //                 //     });

    //                 // } else {
    //                 //     data.forEach((obj) => {
    //                 //         if(obj.coinType == 'crypto' && obj.coin_id > this.currentCoinObj.coinId) {
    //                 //             this.coinPairListArr.push({
    //                 //                 coinID: obj.coin_id,
    //                 //                 coin: obj.coin_short_name,
    //                 //                 coinFullName: obj.coin_full_name,
    //                 //                 volume: obj.volume,
    //                 //                 average: obj.average
    //                 //             });
    //                 //         } 
    //                 //     });
    //                 // }
    //                 this.currentPairCoinObj.coinShort = this.coinPairListArr[0].coin;
    //                 this.getAnalysisFunc();
    //         } else {
    //             this.coinPairListArr = [];
    //         }
    //     }, (err) => {
    //         this.spinnerService.hide();
    //     });
    // }


}


