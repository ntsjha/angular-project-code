import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddSupportTopicComponent } from './add-support-topic.component';

describe('AddSupportTopicComponent', () => {
  let component: AddSupportTopicComponent;
  let fixture: ComponentFixture<AddSupportTopicComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddSupportTopicComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddSupportTopicComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
