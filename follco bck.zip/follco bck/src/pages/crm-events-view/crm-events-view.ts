import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, App } from 'ionic-angular';
import { SettingprivacyPage } from '../settingprivacy/settingprivacy';
import { RestProvider } from '../../providers/rest/rest';
import { CrMcreateeventPage } from '../cr-mcreateevent/cr-mcreateevent';
import { CrMediteventPage } from '../cr-meditevent/cr-meditevent';

/**
 * Generated class for the CrmEventsViewPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-crm-events-view',
  templateUrl: 'crm-events-view.html',
})
export class CrmEventsViewPage {
  eventsList: any=[];

  constructor(public navCtrl: NavController,  private service: RestProvider, public app :App,public navParams: NavParams) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad CrmEventsViewPage');
    this.getEvents();
  }
  back(){
    this.navCtrl.pop();
  }
  // addleads(){
  //   this.app.getRootNav().push(CreateleadsPage);
  // }
  setting(){
    this.app.getRootNav().push(SettingprivacyPage);
  }
  doRefresh(refresher) {
    console.log('Begin async operation', refresher);
     this.getEvents();
    setTimeout(() => {
      console.log('Async operation has ended');
      refresher.complete();
    }, 2000);
  }
  
  doPulling(refresher) {
    // console.log('DOPULLING', refresher.progress);
  //   console.log('Begin async operation', refresher);
  //   this.getFollowers();
  //  setTimeout(() => {
  //    console.log('Async operation has ended');
  //    refresher.complete();
  //  }, 2000);
  }
  getEvents() {
    this.service.presentLoadingDefault('Loading...');
    this.service.get('events/list?follco_token=' + localStorage.getItem('new_token'),0).subscribe(res =>{
        console.log(res);
        if(res) {
            this.service.dismissLoading();
            this.eventsList = res['list'];
            // this.time = new Date (this.campaignList[0].created_at);
            // this.time1 =this.time.getDate() + '/' + (this.time.getMonth()+1) + '/' + this.time.getFullYear();
            // console.log(this.time1); 
         
          
        }
    }, err => {
        this.service.dismissLoading();
        console.log(err);
    })
  }
  eventstitle(ID){
    console.log(ID);
    localStorage.setItem('event_id',ID);
    this.navCtrl.push(CrMediteventPage);
  
  }
  
  addevents(){
    this.app.getRootNav().push(CrMcreateeventPage);
  }
}
