import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ServiceService } from 'src/app/service/service.service';
import { ActivatedRoute, Router } from '@angular/router';
import { AppComponent } from 'src/app/app.component';
import { NgxSpinnerService } from 'ngx-spinner';
declare var $: any;

@Component({
  selector: 'app-add-edit-support-topic',
  templateUrl: './add-edit-support-topic.component.html',
  styleUrls: ['./add-edit-support-topic.component.css']
})
export class AddEditSupportTopicComponent implements OnInit {
  topicEditAddForm: FormGroup;
  modeOfAction: string;
  selectedLanguage: string;
  currentTopicId: any;
  currentUser: any;
  success: any;
  showApiMessage = false;
  translate: boolean;
  subscription: any;

  constructor(private service: ServiceService, private activatedRoutes: ActivatedRoute, private fb: FormBuilder, private router: Router, private appC: AppComponent, private spinner: NgxSpinnerService) {
    this.topicEditAddForm = this.fb.group({
      topicName: ['', [Validators.required, Validators.maxLength(100), Validators.minLength(2)]],
    });
    this.subscription = this.service.authVerify.subscribe(val => {
      if (val === 'add-edit-subtopic') {
        this.submit();
        this.service.authVerify.next('false');
      }
    });
  }

  ngOnInit() {
    window.scrollTo(0, 0);
    this.activatedRoutes.params.subscribe((data) => {
      this.modeOfAction = data.id1;
      this.languageSelection(data.id2);
      this.currentTopicId = data.id3;
    });
    this.modeSelection();
    this.service.currentUserInfo.subscribe((response) => {
      this.currentUser = response;
    });
  }

  modeSelection() {
    if (this.modeOfAction === 'Edit') {
      this.loadForm();
    } else {
      this.modeOfAction = 'Add';
    }
  }

  loadForm() {
      this.service.getMethod('support/admin/get-support-sub-topic-detail?languageShortName=' + encodeURIComponent(this.service.encrypt(this.selectedLanguage)) + '&subTopicId=' + encodeURIComponent(this.service.encrypt(this.currentTopicId)), 1)
        .subscribe((data: any) => {
          this.topicEditAddForm.patchValue({
            topicName: data.data.subTopicName,
          });
        }, (error) => {
        } );
    }

  languageSelection(lang) {
    if (lang === 'en') {
      this.selectedLanguage = 'en';
      this.translate = false;
    } else {
      this.selectedLanguage = (lang === 'ch') ? 'ch' : ((lang === 'th') ? 'th' : null);
      this.translate = true;
    }
  }
  
  verifyGoogleAuth() {
    this.appC.google = { one: '', two: '', three: '', four: '', five: '', six: '' };
    this.appC.response = { message: '' };
    this.service.googleAuthCalledFrom = 'add-edit-subtopic';
    $('#google-auth-modal').modal({ keyboard: false, backdrop: 'static' });

  }


  submit() {
    if(this.translate) {
      this.translationSubmit();
    } else {
      this.engLangSubmit();
    }
  }
   engLangSubmit() {
     if(this.modeOfAction === 'Add') {
       const obj = {
         topicName: this.service.encrypt(this.topicEditAddForm.value.topicName),
         ipAddress: this.service.encrypt(this.currentUser.ip),
         location: this.service.encrypt(this.currentUser.city + ', ' + this.currentUser.country_name),
         topicId: this.service.encrypt(this.currentTopicId),
       };
       this.service.postMethod('support/admin/add-sub-topic', obj, 1)
         .subscribe((response) => {
           this.spinner.hide();
           this.success = response;
           if( response.status === 143 ) {
             this.success.message = 'This topic already exists';
             this.showApiMessage = true;
           } else {
             this.router.navigate(['/support-subtopic/' + this.currentTopicId]);
           }
         });
     } else {
      const obj = {
        topicName: this.service.encrypt(this.topicEditAddForm.value.topicName),
        ipAddress: this.service.encrypt(this.currentUser.ip),
        location: this.service.encrypt(this.currentUser.city + ', ' + this.currentUser.country_name),
        topicId : this.service.encrypt(this.currentTopicId) ,
      };
      this.service.postMethod('support/admin/update-sub-topic', obj, 1)
        .subscribe((response) => {
          this.spinner.hide();
          this.success = response;
          if( response.status === 143 ) {
            this.success.message = 'This topic already exists';
            this.showApiMessage = true;
          } else {
            this.router.navigate(['/support-topics/edit/en']);
          }
        });
     }

   }

   translationSubmit() {
    const obj = {
      topicName: this.service.encrypt(this.topicEditAddForm.value.topicName),
      ipAddress: this.service.encrypt(this.currentUser.ip),
      location: this.service.encrypt(this.currentUser.city + ', ' + this.currentUser.country_name),
      topicId : this.service.encrypt(this.currentTopicId) ,
    };
    this.service.postMethod('support/admin/update-sub-topic-translation', obj, 1)
      .subscribe((response) => {
        this.success = response;
        if( response.status === 143 ) {
          this.success.message = 'This topic already exists';
          this.showApiMessage = true;
        } else {
          this.router.navigate(['/support-topics/edit/en']);
        }
      });
   }

   cancelEdit() {
    this.router.navigate(['/support-subtopic/' + this.currentTopicId]);
    this.router.navigate(['/support-topics/edit/en']);
   }

}
