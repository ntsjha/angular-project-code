import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ServerService } from '../../../server.service';
import { AppComponent } from '../../../app.component';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';

@Component({
    selector: 'app-deposithistory',
    templateUrl: './deposithistory.component.html',
    styleUrls: ['./deposithistory.component.css']
})
export class DeposithistoryComponent implements OnInit {
    depositArr: any = [];
    coin: string;
    coinList: any = [];
    p = 1;
    explorerName: string;

    constructor(private router: Router, private server: ServerService, private spinnerService: Ng4LoadingSpinnerService, private appC: AppComponent) { }

    ngOnInit() {
        window.scrollTo(0,0);
        this.getCoinList();
    }

    /**Function to get coin list */
    getCoinList() {
        this.spinnerService.show();
        this.server.getApi("wallet/coin/get-coin-list").subscribe((succ) => {
            this.coinList = succ.data;
            this.coin = succ.data[0].coinShortName;
            this.selectCoin(this.coin);
        }, (err) => {
            this.spinnerService.hide();
        }); 
    }

    getDepositList() {
        this.depositArr = [];
        if(this.coin == 'XRP' || this.coin == 'HGG' || this.coin == 'ETH') {
            this.spinnerService.show();
            this.server.getApi("wallet/wallet-type2/get-deposits?coinName="+this.coin).subscribe((succ) => {
                this.spinnerService.hide();
                if(succ.data == undefined){
                    this.depositArr = [];
                } else
                    this.depositArr = succ.data; 
            }, (err) => {
                this.spinnerService.hide();
            }); 
        } else {
            this.spinnerService.show();
            this.server.getApi("wallet/wallet/get-deposits?coinName="+this.coin).subscribe((succ) => {
                this.spinnerService.hide();
                if(succ.data == undefined){
                    this.depositArr = [];
                } else
                    this.depositArr = succ.data; 
            }, (err) => {
                this.spinnerService.hide();
            }); 
        }
    }

    /**Function for HGG Token */
    hitAsyncTransfer() {
        this.server.getApi("wallet/wallet-type2/get-async-transfer?coinName=HGG").subscribe((succ) => {
        }, (err) => {
            this.spinnerService.hide();
        }); 
    }

    selectCoin(coin) {
        this.coin = coin;
        switch(this.coin) {
            case 'BTC' : 
                this.explorerName = 'https://live.blockcypher.com/btc/tx/';
                break;
            case 'LTC' : 
                this.explorerName = 'https://live.blockcypher.com/ltc/tx/';
                break;
            case 'ETH' : 
                this.explorerName = 'https://etherscan.io/tx/';
                break;
            case 'XRP' : 
                this.explorerName = 'https://bithomp.com/explorer/';
                break;
            case 'USDT' : 
                this.explorerName = 'ttps://omniexplorer.info/tx/';
                break;
        }
        this.getDepositList();
    }

    back() {
        this.router.navigateByUrl('wallet');
    }

}
