import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { SignupComponent } from './signup/signup.component';
import { AddressComponent } from './address/address.component';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { StudentComponent } from './student/student.component';
import { StudentlistComponent } from './student/studentlist/studentlist.component';
import { StudentMapComponent } from './student/student-map/student-map.component';
import { AddstudentComponent } from './student/addstudent/addstudent.component';
import { ProfileComponent } from './profile/profile.component';
import { ActiveGuard } from './active.guard';

const routes: Routes = [
  {path : '' ,redirectTo :'login', pathMatch : 'full'},
  {path : 'login', component: LoginComponent},
  {path :'signup', component: SignupComponent },
  {path :'address', component: AddressComponent },
  {path :'dashboard', component: DashboardComponent ,canActivate:[ActiveGuard]},
  {path :'student', component: StudentComponent },
  {path :'studentlist', component: StudentlistComponent },
  {path :'studentmap', component: StudentMapComponent },
  {path :'addstudent', component: AddstudentComponent },
  {path :'profile', component: ProfileComponent },
  
  
  ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
