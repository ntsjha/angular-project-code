// function headerbg(){
// 	var scroll = $(window).scrollTop();  
//     if (scroll >= 40) {
//         $("header").addClass("header-bg");
//     } else {
//     	$("header").removeClass("header-bg");
//     }
// }

// $(window).scroll(function() {    
//     headerbg();
// });





$(window).resize(function() {
    if ($(window).width() <= 1024) {
        $(".top-dropdown .dropdown-toggle").removeAttr("data-toggle");
    } else {
        $(".top-dropdown .dropdown-toggle").attr("data-toggle", "dropdown");
    }
});

if ($(window).width() <= 1024) {
    $(".top-dropdown .dropdown-toggle").removeAttr("data-toggle");
} else {
    $(".top-dropdown .dropdown-toggle").attr("data-toggle", "dropdown");
}

$("#showUser").on('click', function(e) {
    $('.chat-user-box').toggle();
    $(this).children('i.fas').toggleClass('fa-users fa-times')
});

$("#showSearch").on('click', function(e) {
    $('.header-search').toggle();
});

$(".security-input").keyup(function() {
    if (this.value.length == this.maxLength) {
        $(this).next('.security-input').focus();
    } else {
        $(this).prev('.security-input').focus();
    }
});

$(document).ready(function() {
    $('[data-toggle="tooltip"]').tooltip();
});

/* =====Increase Descrese========== */
$(".inc-btn").click(function() {
    var get_val = parseInt($(this).parent().prev("input.form-control").val());
    get_val = get_val + 1;
    $(this).parent().prev("input.form-control").val(get_val)
});

$(".dec-btn").click(function() {
    var dec_val = parseInt($(this).parent().next("input.form-control").val());
    if (dec_val <= 0) {
        return false;
    } else {
        dec_val = dec_val - 1;
        $(this).parent().next("input.form-control").val(dec_val)
    }
});
/* =====Increase Descrese End========== */

$(".otpField").keyup(function() {
    if (this.value.length == this.maxLength) {
        $(this).next('.otpField').focus();
    }
    if (this.value.length < this.maxLength) {
        $(this).prev('.otpField').focus();
    }
});


$(document).ready(function() {
    /* Toggle Header User info Drop Down */
    $(document).on("click", ".user_top_box ", function() {
        $(".user_top_box .dropdown-menu").toggleClass("show");
    });

    $(document).click(function(e) {
        if (!$(e.target).is(".head-drop-down, .head-drop-down *, .user_top_box, .user_top_box *")) {
            $(".user_top_box .dropdown-menu").removeClass('show');
        }
    });
});