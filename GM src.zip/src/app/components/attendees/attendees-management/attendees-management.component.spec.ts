import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AttendeesManagementComponent } from './attendees-management.component';

describe('AttendeesManagementComponent', () => {
  let component: AttendeesManagementComponent;
  let fixture: ComponentFixture<AttendeesManagementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AttendeesManagementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AttendeesManagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
