import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StandardDepositFiatComponent } from './standard-deposit-fiat.component';

describe('StandardDepositFiatComponent', () => {
  let component: StandardDepositFiatComponent;
  let fixture: ComponentFixture<StandardDepositFiatComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StandardDepositFiatComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StandardDepositFiatComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
