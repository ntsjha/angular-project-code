import { Component, OnInit } from '@angular/core';
import { ServiceService } from 'src/app/Shared/service.service';
import { Router } from '@angular/router';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { AngularFirestore } from '@angular/fire/firestore';

@Component({
  selector: 'app-add-template',
  templateUrl: './add-template.component.html',
  styleUrls: ['./add-template.component.css']
})
export class AddTemplateComponent implements OnInit {
  templateForm: FormGroup;
  selectWeekArr:any=['1','2','3','4','5','6','7','8','9','10','11','12','13','All'];
  weekArr:any=[];
  dayArr:any=[];
  constructor(public service: ServiceService,public routes: Router, public firestore: AngularFirestore) {
    this.templateForm = new FormGroup({
      'templateName':new FormControl('',[Validators.required,Validators.pattern('')]),
      'totalWeek': new FormControl('',Validators.required)
    })
   }

  ngOnInit() {
  }
  
  createWeekarr(val){
   if(!this.weekArr.includes(val))
     this.weekArr.push(val)
     else{
       var index = this.weekArr.indexOf(val);
       this.weekArr.splice(index,1);
     }
     console.log('WeekArr-->>',this.weekArr);
  }

  createDayArr(val){
    if(!this.dayArr.includes(val))
    this.dayArr.push(val)
    else{
      var index = this.dayArr.indexOf(val);
      this.dayArr.splice(index,1);
    }
    console.log('dayArr-->>',this.dayArr);
  }

  addTemplateFunc(){

  }
}
