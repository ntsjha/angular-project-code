import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { IMyDpOptions, IMyDateModel } from 'mydatepicker';
import { DatePipe } from '@angular/common';
import { NgxSpinnerService } from 'ngx-spinner';
import { ServiceService } from 'src/app/service/service.service';

@Component({
    selector: 'app-transfer-history',
    templateUrl: './transfer-history.component.html',
    styleUrls: ['./transfer-history.component.css']
})
export class TransferHistoryComponent implements OnInit {
    getAdmins: any = [];
    total: any;
    page: any = 0;
    p: any = 1;
    filterFunction: FormGroup;
    toDateInTimestamp: any = 0;
    fromDateInTimestamp: any = 0;

    public fromPickerOptions: IMyDpOptions = {
        disableSince: { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() },
        dateFormat: 'dd/mm/yyyy',
    };

    public toPickerOptions: IMyDpOptions = {
        disableSince: { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() },
        dateFormat: 'dd/mm/yyyy',
    };
    constructor(
        private service: ServiceService,
        private spinner: NgxSpinnerService,
        public datepipe: DatePipe,
    ) {
        this.filterFunction = new FormGroup({
            search: new FormControl(null),
            fromDate: new FormControl(null),
            toDate: new FormControl(null),

        });

    }

    ngOnInit() {
        this.getAdminList();
        window.scrollTo(0, 0);
    }
    get search(): any {
        return this.filterFunction.get('search');
    }

    get fromDate(): any {
        return this.filterFunction.get('fromDate');
    }

    get toDate(): any {
        return this.filterFunction.get('toDate');
    }

    getAdminList() {
        this.getAdmins = [];
        this.total = 0;
        this.spinner.show();
        const data = {
            page: this.page,
            pageSize: '10',
            search: (this.filterFunction.value.search != null) ? this.filterFunction.value.search.trim() : null,
            fromDate: (this.fromDateInTimestamp !== 0) ? (this.fromDateInTimestamp * 1000 ) : null,
            toDate: (this.toDateInTimestamp !== 0) ? (this.toDateInTimestamp * 1000 ) : null,
        };
        this.service.postMethod('wallet/common-permit/history/get-transfer-history', data, 1).subscribe((response: any) => {
            this.spinner.hide();
            if (response.status === 853) {
                this.getAdmins = response.data.resultlist;
                this.total = response.data.totalCount;
            }
        }, (error) => {
            this.spinner.hide();
        });
    }

    resetFunc() {
        this.filterFunction.reset();
        this.fromDateInTimestamp = 0;
        this.toDateInTimestamp = 0;
        this.p = 1;
        this.page = 0;
        this.fromPickerOptions = {
            disableSince: { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() + 1 },
            disableUntil: { year: 0, month: 0, day: 0}
        };
        this.toPickerOptions = {
            disableSince: { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() + 1 },
            disableUntil: { year: 0, month: 0, day: 0}
        };
        this.getAdminList();
    }

    setDate() {
        const date = new Date();
        this.filterFunction.patchValue({
            toDate: {
                date: {
                    year: date.getFullYear(),
                    month: date.getMonth() + 1,
                    day: date.getDate()
                }
            }
        });
        this.filterFunction.patchValue({
            fromDate: {
                date: {
                    year: date.getFullYear(),
                    month: date.getMonth() + 1,
                    day: date.getDate()
                }
            }
        });
    }

    changePage(page) {
        this.p = page;
        this.page = page - 1;
        this.getAdminList();
    }


    toDateChanged(event: IMyDateModel) {
        this.toDateInTimestamp = event.epoc;
        if (event.epoc === 0) {
            const date = new Date();
            this.filterFunction.patchValue({
                toDate: {
                    date: {
                        year: date.getFullYear(),
                        month: date.getMonth() + 1,
                        day: date.getDate()
                    }
                }
            });
            this.fromPickerOptions = {
                disableSince: {
                    year: date.getFullYear(),
                    month: date.getMonth() + 1,
                    day: date.getDate()
                }
            };
        } else {
            this.filterFunction.patchValue({
                toDate: event.date
            });
            this.fromPickerOptions = {
                disableSince: event.date
            };

        }

    }

    fromDateChanged(event: IMyDateModel) {
        this.fromDateInTimestamp = event.epoc;
        if (event.epoc === 0) {
            const date = new Date();
            this.filterFunction.patchValue({
                fromDate: {
                    date: {
                        year: date.getFullYear(),
                        month: date.getMonth() + 1,
                        day: date.getDate()
                    }
                }
            });
            this.toPickerOptions = {
                disableUntil: event.date
            };
        } else {
            this.filterFunction.patchValue({
                fromDate: event.date
            });
            this.toPickerOptions = {
                disableUntil: event.date
            };
        }
    }

    /** Function to convert date format */
    convertFormat(time) {
        if (time != null) {
            return this.datepipe.transform(time, 'MM/dd/yyy, hh:mm a');
        }
    }


}
