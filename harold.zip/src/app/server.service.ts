import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpInterceptor, HttpHandler, HttpEvent, HttpRequest, HttpErrorResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

@Injectable()
export class ServerService {
  token:any;
  wsExchange: any;

  chartUrl = 'http://52.221.120.247:8765/order/exchange-feed';
  baseUrl = 'http://52.221.120.247:8765/';
  socketUrl = 'ws://52.221.120.247:9100/socket';

  refURL = "http://18.136.131.175:1479/signup/";
  websiteURL = "http://18.136.131.175:1479";


  httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' }),
    "Access-Control-Allow-Origin": "*"
  };
  constructor(private http: HttpClient) { }

  /** method declaration */
  getApi(url): Observable<any> {
    return this.http.get(this.baseUrl + url);
  }
  /** method declaration */
  get(url): Observable<any> {
    return this.http.get(url);
  }
  /** Function for post method */
  postApi(url, data): Observable<any> {
    return this.http.post(this.baseUrl + url, data);
  }


  /** Function for socket event */
  initSocket() {
    var self = this;
    this.wsExchange = new WebSocket(this.socketUrl);
    this.wsExchange.addEventListener('open', function (event) {
        console.log('ws connected for exchange');
    });
    this.wsExchange.addEventListener('close', function (event) {
        console.log('ws disconnected for exchange');
        if(localStorage.getItem('baseCoin') && localStorage.getItem('exeCoin')) {
          self.reConnectSocket();
        }
        
    });
  }

  /** Function for reconnect socket */
  reConnectSocket() {
    this.wsExchange = new WebSocket(this.socketUrl);
    this.wsExchange.addEventListener('open', function (event) {
        console.log('ws connected for exchange');
    });
    setTimeout(function() {
      let data1 = {
        messageType:'SUBSCRIBE_TICKER',
        params: {
            symbol:localStorage.getItem('exeCoin')+'_'+localStorage.getItem('baseCoin')
        }
      }
      this.wsExchange.send(JSON.stringify(data1));
      let data2 = {
          messageType:'SUBSCRIBE_ORDER_BOOK',
          params: {
              symbol:localStorage.getItem('exeCoin')+'_'+localStorage.getItem('baseCoin')
          }
      }
      this.wsExchange.send(JSON.stringify(data2));
      let data3 = {
          messageType:'SUBSCRIBE_TRADE_HISTORY',
          params: {
              symbol:localStorage.getItem('exeCoin')+'_'+localStorage.getItem('baseCoin')
          }
      }
      this.wsExchange.send(JSON.stringify(data3));
    }, 50000);
    
  }
}
  /*********************************** INTERCEPTOR *****************************************/

  @Injectable()
  export class httpModifierInterceptor implements HttpInterceptor {
  constructor(public route: Router, private toasterService: ToastrService,  ) { }
  intercept(request: HttpRequest <any>, next: HttpHandler): Observable < HttpEvent < any >> {
    if(request.url.includes('https://min-api.cryptocompare.com')) {
    } else {
      if(localStorage.getItem('token')) {
        request = request.clone({
          setHeaders: {
            Authorization: `Bearer ${localStorage.getItem('token')}`
          }
        });
      } else {
        request = request.clone({
          setHeaders: {
            Authorization: `Bearer ${localStorage.getItem('authToken')}`
          }
        });
      }
    }
    return next.handle(request);
  }}
