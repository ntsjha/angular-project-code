import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { ServiceServicesProvider } from '../../providers/service-services/service-services';

/**
 * Generated class for the TermsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-terms',
  templateUrl: 'terms.html',
})
export class TermsPage {
  description: any
  constructor(public navCtrl: NavController, public navParams: NavParams, private server: ServiceServicesProvider) {
  }

  ngOnInit() {
    this.getTerms();
  }

  getTerms() {
    if (navigator.onLine) {
      this.server.presentLoading();
      this.server.getApi('staticContent/getStaticContent/term_condition', 0).subscribe((response: any) => {
        this.server.dismissLoading();
        if (response.response_code == 200)
          this.description = response.result.description
        else if (response.response_code == 403 || response.response_code == 409 || response.response_code == 401) {
          this.server.presentToast(response.response_message)
          this.server.logout();
        }
        else
          this.server.presentToast(response.response_message)
      }, err => {
        this.server.dismissLoading();
        this.server.presentToast('Something went wrong')
      })
    }
    else {
      this.server.presentToast('Your internet connection seems to be lost')
    }
  }

  back() {
    this.navCtrl.pop()
  }
}
