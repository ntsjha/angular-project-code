import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ExchangepairComponent } from './exchangepair/exchangepair.component';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [ExchangepairComponent],
  imports: [
    CommonModule,
    FormsModule,
    
  ]
})
export class ExchangepairModule { }
