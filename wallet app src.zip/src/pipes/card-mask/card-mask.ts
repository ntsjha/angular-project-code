import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'cardMask',
})
export class CardMaskPipe implements PipeTransform {
  /**
   * Takes a card number and applies a masking to it
   */
  transform(value: string, ...args) {
    let mask = value.substr(value.length - 4)
    let card = value.slice(0, value.length - 4)
    let result = card.replace(/[0-9]/g, 'X') + mask
    return result;
  }
}
