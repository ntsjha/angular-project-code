import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { ServiceServicesProvider } from "../../providers/service-services/service-services";
import { SendMoneyOptionsPage } from "../send-money-options/send-money-options";

@IonicPage()
@Component({
  selector: 'page-send-exchange',
  templateUrl: 'send-exchange.html',
})
export class SendExchangePage {
  
  receiver: any = {};
  sender: any = {};
  conversionFee: any = 0;
  transactionFee: any = 0;
  message: any;
  receiveAmount: any;
  sendAmount: any;
  countryListJson: any=[];

  constructor(public navCtrl: NavController, public navParams: NavParams, private service: ServiceServicesProvider) {
  }

  ionViewWillEnter() {
    this.sender.country = this.navParams.get('sender');
    this.receiver.country = this.navParams.get('receiver');
    // console.log('anshul receiver', this.receiver);
    console.log("sender===>>",this.sender)
 //console.log(this.receiver.country)
    this.getCurrencies();
    this.getTransactionFees();
    // this.getConversionFees();
    this.sendAmount = Number(0).toFixed(0)
    this.receiveAmount = Number(this.receiveAmount)
  }

  sendAmountChange() {
    this.sendAmount = Number(this.sendAmount)
    this.receiveAmount = this.sendAmount.toFixed(2) * (this.sender.exchangeRate).toFixed(2);
    console.log("recieve===>> ",this.receiveAmount)
  }

  receiveAmountChange() {
    this.receiveAmount = Number(this.receiveAmount).toFixed(2);
    this.sendAmount = (this.receiveAmount).toFixed(2) / (this.sender.exchangeRate).toFixed(2);
    console.log("send---->>  ",this.receiveAmount)
  }

  getSenderFlag() {
    return new Promise(resolve => {
      this.service.getCurrencyAndFlag(this.sender.country, 1).subscribe(res => {
        console.log(res)
        this.sender.flag = res[0].flag;
        this.sender.currency = res[0].currencies[0].symbol;
        this.sender.currencyCode = res[0].currencies[0].code;
        resolve(true);
      });
    });
  }

  getReceiverFlag() {
    return new Promise(resolve => {
      this.service.getCurrencyAndFlag(this.receiver.country, 1).subscribe(res => {
        this.receiver.flag = res[0].flag;
        this.receiver.currency = res[0].currencies[0].symbol;
        this.receiver.currencyCode = res[0].currencies[0].code;
        resolve(true);
      });
    });
  }

  async getCurrencies() {
    if (navigator.onLine) {
      this.service.presentLoading();
      await this.getSenderFlag();
      await this.getReceiverFlag();
      if(this.sender.country == this.receiver.country) {
        this.service.dismissLoading();
        this.sender.exchangeRate = 1;
        this.receiveAmount = (this.sendAmount * this.sender.exchangeRate).toFixed(3);
      }
      else {
        this.service.getExchangeRate(this.sender.currencyCode).subscribe(
          (res: any) => {
            this.service.dismissLoading();
            if(res[`rates`][this.receiver.currencyCode]) {
              this.sender.exchangeRate = res[`rates`][this.receiver.currencyCode]
              this.receiveAmount = (this.sendAmount * this.sender.exchangeRate).toFixed(3);
            }
            else {
              this.sender.exchangeRate = 1;
              this.receiveAmount = (this.sendAmount * this.sender.exchangeRate).toFixed(3);
              this.service.presentToast('Could not fetch exact exchange rate')
            }
                
          },
          err => {
            console.log(err)
            this.service.dismissLoading();
            this.sender.exchangeRate = 1;
            this.receiveAmount = (this.sendAmount * this.sender.exchangeRate).toFixed(3);
            this.service.presentToast(err.error.error)
          }
        );
        this.getConversionFees();
      }
      return true;
    }
    else {
      this.service.presentToast('Your internet connection seems to be lost')
    }

  }

  getConversionFees() {
    if (navigator.onLine) {
      this.service.getApi('transaction/conTransFee', 1).subscribe((response: any) => {
        if (response.response_code == 200) {
          this.conversionFee = response.data.conversionFee;
          console.log('Conversion Fee-->>',this.conversionFee)
        } else if (response.response_code == 403 || response.response_code == 409 || response.response_code == 401) {
          this.service.presentToast(response.response_message)
          this.service.logout();
        }
        else {
          this.conversionFee = 0;
          this.service.presentToast(response.response_message)
        }
      }, err => {
        this.service.presentToast('Something went wrong')
      })
    } else
      this.service.presentToast('Your internet connection seems to be lost')
  }

    
  getTransactionFees() {
    if (navigator.onLine) {
      this.service.getApi('transaction/conTransFee', 1).subscribe((response: any) => {
        if (response.response_code == 200) {
          this.transactionFee = response.data.transactionFee;
          console.log('Transaction Fee--->>',this.transactionFee);
        } else if (response.response_code == 403 || response.response_code == 409 || response.response_code == 401) {
          this.service.presentToast(response.response_message)
          this.service.logout();
        }
        else {
          this.transactionFee = 0;
          this.service.presentToast(response.response_message)
        }
      }, err => {
        this.service.presentToast('Something went wrong')
      })
    } else
      this.service.presentToast('Your internet connection seems to be lost')
  }

  back() {
    this.navCtrl.pop();
  }

  sendMoney() {
    this.getCurrencies();
    let data = JSON.parse(localStorage.sendMoneyProcess)
    data.sender = this.sender;
    data.receiver = this.receiver;
    data.amount = this.sendAmount;
    data.message = this.message;
    localStorage.sendMoneyProcess = JSON.stringify(data);
    this.navCtrl.push(SendMoneyOptionsPage);
  }
}
