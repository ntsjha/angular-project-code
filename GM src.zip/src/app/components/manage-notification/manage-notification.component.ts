import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ServiceService } from 'src/app/service/service.service';

@Component({
  selector: 'app-manage-notification',
  templateUrl: './manage-notification.component.html',
  styleUrls: ['./manage-notification.component.css']
})
export class ManageNotificationComponent implements OnInit {

  getNotificationData: any;
  total: any;
  page: any = 0;
  p: any = 1;
  constructor(
    private service: ServiceService,
    private spinner: NgxSpinnerService,
    private route: Router
  ) { }

  ngOnInit() {
    this.getNotification();
    window.scrollTo(0, 0);
  }

  goToManageText(activityType, contentId) {
    this.route.navigate(['/manage-update-notification/' + encodeURIComponent(activityType) + '/' + contentId]);
  }

  getNotification() {
    this.spinner.show();
    this.service.getMethod('notification-service/admin/manage-notification-list', 1).subscribe((response: any) => {
      this.spinner.hide();
      if (response.status === 1200) {
        this.getNotificationData = response.data;
      }
    }, (error) => {
        this.spinner.hide();
    });
    this.spinner.hide();
  }


  changePage(page) {
    this.p = page;
    this.page = page - 1;
    this.getNotification();
  }
}
