import { Component, OnInit } from '@angular/core';
import { ServiceService } from 'src/app/service/service.service';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-manage-site-content',
  templateUrl: './manage-site-content.component.html',
  styleUrls: ['./manage-site-content.component.css']
})
export class ManageSiteContentComponent implements OnInit {
  pageArr: any = [];
  pageToNavigate = '';
  constructor(private service: ServiceService, private router: Router, private spinner: NgxSpinnerService ) {
    this.getSiteContent();
  }

  ngOnInit() {
    this.getSiteContent();
    window.scrollTo(0, 0);
  }

  getSiteContent() {
    this.spinner.show();
    const data = {};
    this.service.postMethod('static/admin/getSiteContentType', data, 1)
      .subscribe((response) => {
        this.spinner.hide();
        this.pageArr = response.data;
      }, (error) => {
        this.spinner.hide();
      });
  }


  openPage(page) {
    this.selectedPageToNavigate(page);
    if (this.pageToNavigate === 'add-edit-faq') {
      this.router.navigate(['/faq/view/no']);
    } else {
    this.router.navigate(['/' + this.pageToNavigate + '/view/no']);
    }
  }

  selectedPageToNavigate(pageTitle) {
    const pageToGo = pageTitle.toLowerCase();
    switch (pageToGo) {
      case 'about us':
        this.pageToNavigate = 'about-us';
        this.router.navigate(['/translation/' + this.pageToNavigate]);
        break;
      case 'terms and condition':
        this.pageToNavigate = 'terms-and-content';
        this.router.navigate(['/translation/' + this.pageToNavigate]);
        break;
      case 'privacy policy':
        this.pageToNavigate = 'privacy-policy';
        this.router.navigate(['/translation/' + this.pageToNavigate]);
        break;
      case 'otc':
        this.pageToNavigate = 'otc';
        break;
      case 'social media links':
        this.pageToNavigate = 'social-media-link';
        this.router.navigate(['/' + this.pageToNavigate + '/edit/en']);
        break;
      case 'rewards':
        this.pageToNavigate = 'rewards';
        this.router.navigate(['/translation/' + this.pageToNavigate]);
        break;
      case 'home page':
        this.pageToNavigate = 'homepage';
        this.router.navigate(['/translation/' + this.pageToNavigate]);
        break;
      case 'faq':
        this.pageToNavigate = 'add-edit-faq';
        this.router.navigate(['/faq/view/no']);
        break;
      case 'contact info':
        this.pageToNavigate = 'contact-info';
        this.router.navigate(['/translation/' + this.pageToNavigate]);
        break;
      case 'support topics':
        this.pageToNavigate = 'support-topics';
        this.router.navigate(['/' + this.pageToNavigate + '/edit/en']);
        break;
      case 'countries list':
        this.pageToNavigate = 'countries-list';
        this.router.navigate(['/' + this.pageToNavigate + '/edit/en']);
        break;
      case 'bank list':
        this.pageToNavigate = 'bank-list';
        this.router.navigate(['/' + this.pageToNavigate + '/edit/en']);
        break;
    }
  }

}
