import { Component, OnInit,  } from '@angular/core';
import { HeaderComponent } from '../../header/header/header.component';
import { Router } from '@angular/router';
import { ServerService } from '../../../server.service';
import { AppComponent } from '../../../app.component';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
    loginStatus: boolean;
    quickTab: any;
    coinList: any = [];
    coinPairList: any = [];
    coinID: any;
  
    constructor(public router: Router, public header:HeaderComponent, private server : ServerService, private appC: AppComponent) { 
        var self = this;
        this.server.wsExchange.addEventListener('message', function (event) {
            var data = JSON.parse(event.data);
            if(data.messageType == 'TICKER_UPDATE') {
                let ind = self.coinPairList.findIndex((x) => x.baseCoin == data.symbol.split('_')[1] && x.executableCoin == data.symbol.split('_')[0]);
                self.coinPairList[ind].lastPrice = data.data.lastPrice;
            }
        });

        this.header.fireToChild().subscribe(message => {
            this.quickTab = message.text;
            if(this.quickTab== "logout")
            this.check();
        });
        this.appC.fireToChild().subscribe(message => {
            this.quickTab = message.text;
            if(this.quickTab == 'logout')
            this.check();
            this.header.check();
        });
        
    }

    ngOnInit() {
        window.scrollTo(0,0);
        this.check();
        this.header.getprofile();
        this.getCoinList();
        this.getCoinPairList();
    }

    /** To open login page */
    login() {
        this.router.navigateByUrl('login')
    }

    /** To open signup page */
    signup() {
        this.router.navigateByUrl('signup/newUser')
    }

    /** To check whether user is logged in or not */
    check() {
        if(localStorage.getItem("token")) {
            this.loginStatus = true;
        } else {
            this.loginStatus = false;
        }
        
    }

    /**Function to get coinpair list */
    getCoinPairList() {
        this.server.getApi("wallet/coin/get-symbol-list").subscribe((succ) => {
            succ.data.forEach(element => {
                this.coinPairList.push({
                    "coinPairId": element.coinPairId,
                    "baseCoin": element.baseCoin,
                    "executableCoin": element.executableCoin,
                    "lastPrice": ''
                });
                let data = {
                    messageType : 'SUBSCRIBE_TICKER',
                    params: {
                        symbol:element.executableCoin + '_' + element.baseCoin
                    }
                }
                this.server.wsExchange.send(JSON.stringify(data));

            });
        }, (err) => {
        }); 
    }

    /**Function to get coin list*/
    getCoinList() {
        this.coinList = [];
        this.server.getApi("wallet/coin/get-coin-list").subscribe((succ) => {
            succ.data.forEach(element => {
                this.coinList.push({
                    "coinFullName": element.coinFullName,
                    "coinImage": element.coinImage,
                    "coinShortName":element.coinShortName,
                    "marketPrice":'',
                    "price":'',
                    "volume24":'',
                    "change24":'',
                });if(element.coinShortName != 'HGG') {
                    this.server.get("https://min-api.cryptocompare.com/data/pricemultifull?fsyms="+element.coinShortName+"&tsyms=USD").subscribe((succ) => {
                        let ind = this.coinList.findIndex((x) => x.coinShortName == element.coinShortName);
                        this.coinList[ind].marketPrice = succ.DISPLAY[element.coinShortName].USD.MKTCAP;
                        this.coinList[ind].price = succ.DISPLAY[element.coinShortName].USD.PRICE;
                        this.coinList[ind].volume24 = succ.DISPLAY[element.coinShortName].USD.VOLUME24HOUR;
                        this.coinList[ind].change24 = succ.DISPLAY[element.coinShortName].USD.CHANGE24HOUR;
                    }, (err) => {
                    });
                }
            });
        }, (err) => {
        });
        this.getHomeData();
    }


    /**Function to get coin list & data from cryptoCompare site */
    getHomeData() {
        this.coinID = setInterval((data) => {
            for(let i = 0; i < this.coinList.length;i++) {
                if(this.coinList[i].coinShortName != 'HGG') {
                    this.server.get("https://min-api.cryptocompare.com/data/pricemultifull?fsyms="+this.coinList[i].coinShortName+"&tsyms=USD").subscribe((succ) => {
                        let ind = this.coinList.findIndex((x) => x.coinShortName == this.coinList[i].coinShortName);
                        this.coinList[ind].marketPrice = succ.DISPLAY[this.coinList[i].coinShortName].USD.MKTCAP;
                        this.coinList[ind].price = succ.DISPLAY[this.coinList[i].coinShortName].USD.PRICE;
                        this.coinList[ind].volume24 = succ.DISPLAY[this.coinList[i].coinShortName].USD.VOLUME24HOUR;
                        this.coinList[ind].change24 = succ.DISPLAY[this.coinList[i].coinShortName].USD.CHANGE24HOUR;
                    }, (err) => {
                    });
                }
            }
        },60000);
    }

    ngOnDestroy() {
        if (this.coinID) {
            clearInterval(this.coinID);
        }
    }


}
