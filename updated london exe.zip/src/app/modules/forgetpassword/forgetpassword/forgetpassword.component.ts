import { Component, OnInit } from '@angular/core';
import { ServerService } from '../../../service/server.service';
import { AppComponent } from '../../../app.component';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { Router } from '@angular/router';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-forgetpassword',
  templateUrl: './forgetpassword.component.html',
  styleUrls: ['./forgetpassword.component.css']
})
export class ForgetpasswordComponent implements OnInit {
        forgetForm: FormGroup;
        
        constructor(private router: Router , private server: ServerService , private appC: AppComponent, private spinnerService: Ng4LoadingSpinnerService) { }

        ngOnInit() {
            this.checkInputs();
        }
        /** Function to validate form inputs */
        checkInputs() {
            this.forgetForm = new FormGroup({
                email: new FormControl('', [Validators.required, Validators.pattern(/^[A-Z0-9_]+([\.-][A-Z0-9_]+)*@[A-Z0-9-]+(\.[a-zA-Z]{2,5})+$/i)]),
            })
        }
        /** Function for forget */
        submit() {
            // let forgetData = {
            //     "eventExternal": {
            //         "name": "request_forgetpassword",
            //         "key": "mykey"
            //     },
            //     "transferObjectMap": {
            //         "gatewayrequest": {
            //             "email": this.forgetForm.value.email,
            //             "url": this.server.webiteUrl + "reset"
            //         }
            //     }
            // } 

            /**  get API call */
            this.spinnerService.show();
            this.server.getApi('account/forget-password?email='+this.forgetForm.value.email+'&webUrl='+this.server.webiteUrl+'reset',0).subscribe(response => {
                this.spinnerService.hide();
                if (response.body.status == 200) {
                    this.appC.showSuccToast('Password reset link has been sent to your email id.');
                    this.router.navigateByUrl('header/login') 
                } else {
                this.appC.showInfoToast(response.body.message)
                }
            }, error => {
                this.spinnerService.hide();
                this.appC.showErrToast(error.body.error);  
            })       
        }
        /** to get the value of field  */

        get email(): any {
        return this.forgetForm.get('email');
        }
}
