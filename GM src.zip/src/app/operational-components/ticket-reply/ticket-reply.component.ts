import { Component, OnInit } from '@angular/core';
import { ServiceService } from 'src/app/service/service.service';
import { CookieService } from 'ngx-cookie-service';

declare var $: any;
@Component({
    selector: 'app-ticket-reply',
    templateUrl: './ticket-reply.component.html',
    styleUrls: ['./ticket-reply.component.css']
})
export class TicketReplyComponent implements OnInit {
    id: string;
    obj: any = {};
    myUserId: any;
    error: boolean = false;
    fileImage: any;
    message: string;
    fileData: any;
    fileName: any;
    userName: any;
    timeOut: any;
    chatArr: any;

    constructor(public server: ServiceService, private cookie: CookieService) { }

    ngOnInit() {
        this.callByUrl();
        window.scrollTo(0, 0);
    }
    callByUrl() {
        let url = window.location.href;
        let arr = url.split('/');
        this.id = arr[arr.length - 1];
        this.getChatHistory();
        this.checkLoginStatus();
    }

    getChatHistory() {
        this.timeOut = setInterval(() => {
            if (this.cookie.get('token')) {
                const token = this.cookie.get('token');
                const base64Url = token.split('.')[1];
                const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
                const jsonPayload = decodeURIComponent(atob(base64).split('').map((c) => {
                    return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
                }).join(''));
                const obj = JSON.parse(jsonPayload);
                this.myUserId = obj.userId;
                this.userName = obj.username;
            }
            this.server.postMethod('support/common-permit/get-chat-history?ticketsId=' + encodeURIComponent(this.server.encrypt(this.id)), {}, 1).subscribe((res) => {
                this.chatArr = res;
                let arr = [];
                arr = res;
                this.server.chatArr.concat(arr);
            });
        }, 2000);
    }

    sendMessage() {
        const fileData = new FormData();
        if (!!this.fileData) {
          fileData.append('file', this.fileData);
        } else {
          fileData.append('file', null);
        }
        const apireq = {
          ticketsId: this.id,
          message: this.obj.chat.trim() ? (String(this.obj.chat.trim())) : null,

        };
        fileData.append('ticketReplyDto', this.server.encrypt(JSON.stringify(apireq)));
        this.server.postMethodMultipart(`support/send-reply-to-ticket`, fileData).subscribe(success => {
          if (success.status === 119) {
            this.message = '';
            this.obj.chat = '';
            this.getChatHistory();
          }
          this.fileData = '';
        }, error => {
          this.fileData = '';
        });
      }

    checkLoginStatus() {
    }

    sendChat() {
        if (this.obj.chat) {
            let data = {
                "fromuserId": this.myUserId,
                "toUserId": this.id,
                "userName": this.userName
            };

            if (this.fileImage) {
                data['message'] = this.fileImage;
                data['messageFormat'] = 'IMAGE';
            } else {
                data['message'] = this.message;
                data['messageFormat'] = 'TEXT';
            }

            this.server.wsChat.send(JSON.stringify(data));
            this.server.chatArr.push(data);
            this.obj.chat = '';
            this.fileImage = '';
            this.scrollToBottom();
        }
    }

    handleFileInput(event) {
        this.fileImage = '';
        this.message = '';
        this.error = false;
        var self = this;
        if (event.target.files && event.target.files[0]) {
            var type = event.target.files[0].type;
            if (type === 'image/png' || type === 'image/jpg' || type === 'image/jpeg') {
                this.fileData = event.target.files[0];
                this.fileName = event.target.files[0].name;
                this.uploadSelfiImage();

                var reader = new FileReader();
                reader.onload = (e) => {
                    self.fileImage = e.target['result'];
                };
            } else {
                this.message = "Select only jpg,jpeg and png file.";
                this.error = true;
                self.fileImage = '';
                self.fileData = "";
                self.fileName = "";
            }
        }
    }

    uploadSelfiImage() {
        let formdata = new FormData();
        formdata.append('file', this.fileData);
        if (navigator.onLine) {
            this.server.uploadMethod('account/uploadFile', formdata).subscribe((succ) => {
                if (succ.fileName) {
                    this.fileImage = succ.fileName;
                }
            }, error => {

            });
        }
    }
    scrollToBottom() {
        $(document).ready(function () {
            $('#messagewindow').animate({
                scrollTop: $('#messagewindow')[0].scrollHeight
            }, 2000);
        });
    }

    ngOnDestroy() {
        clearInterval(this.timeOut);
    }


}
