import { ExchangeMicroServiceModule } from './modules/exchange-micro-service/exchange-micro-service.module';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { EmailverifyModule } from './modules/emailverify/emailverify.module';
import { LoginModule } from './modules/login/login.module';
import { SignupModule } from './modules/signup/signup.module';
import { ForgetpasswordModule } from './modules/forgetpassword/forgetpassword.module';
import { HeaderModule } from './modules/header/header.module';
import { PagenotfoundModule } from './modules/pagenotfound/pagenotfound.module';
import { ProfileModule } from './modules/profile/profile.module';
import { TwofaModule } from './modules/twofa/twofa.module';
import { WalletModule } from './modules/wallet/wallet.module';
import { HomeModule } from './modules/home/home.module';
import { ToastrModule } from 'ngx-toastr';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ServerService } from './service/server.service';
import { HttpClientModule } from '@angular/common/http';
import { Ng4LoadingSpinnerModule } from 'ng4-loading-spinner';
import { SmsauthModule } from './modules/smsauth/smsauth.module';
import { GooglePlaceModule } from 'ngx-google-places-autocomplete';
import { AboutusModule } from './modules/aboutus/aboutus.module';
import { FaqModule } from './modules/faq/faq.module';
import { PrivacypolicyModule } from './modules/privacypolicy/privacypolicy.module';
import { TermsconditionsModule } from './modules/termsconditions/termsconditions.module';
import { QRCodeModule } from 'angularx-qrcode';
import { TransactionDetailModule } from './modules/transaction-detail/transaction-detail.module';
import {NgxPaginationModule} from 'ngx-pagination';
import { RecaptchaModule } from 'ng-recaptcha';
import { ExchangeModule } from './modules/exchange/exchange.module';
import { ResetModule } from './modules/reset/reset.module';
import { DepositModule } from './modules/deposit/deposit.module';
import { WithdrawModule } from './modules/withdraw/withdraw.module';
import { FiathistoryModule } from './modules/fiathistory/fiathistory.module';
import { OrderModule } from './modules/order/order.module';
import { DatePipe } from '@angular/common';
import { NewipdetectModule } from './modules/newipdetect/newipdetect.module';
import { DashboardModule } from './modules/dashboard/dashboard.module';
import { PosttrdeModule } from './modules/posttrde/posttrde.module';
import { TraddetailModule } from './modules/traddetail/traddetail.module';
import { TradeactionModule } from './modules/tradeaction/tradeaction.module';
import { TradelistModule } from './modules/tradelist/tradelist.module';
import { WithdrawverifyModule } from './modules/withdrawverify/withdrawverify.module';
import { UsdtransactionModule } from './modules/usdtransaction/usdtransaction.module';
import { ExchangepairModule } from './modules/exchangepair/exchangepair.module';
import { GuardsGuard } from './modules/guards.guard';


@NgModule({
    declarations: [
        AppComponent,
        
        
    ],
    imports: [
        BrowserModule,
        AppRoutingModule,
        EmailverifyModule,
        LoginModule,
        SignupModule,
        ForgetpasswordModule,
        HeaderModule,
        PagenotfoundModule,
        ProfileModule,
        TwofaModule,
        WalletModule,
        HomeModule,
        BrowserAnimationsModule, // required animations module
        ToastrModule.forRoot({
            timeOut: 10000,
            // positionClass: 'toast-bottom-right',
            preventDuplicates: true,
          }), 
        HttpClientModule,
        Ng4LoadingSpinnerModule.forRoot(),
        SmsauthModule,
        GooglePlaceModule,
        AboutusModule,
        FaqModule,
        PrivacypolicyModule,
        TermsconditionsModule,
        WalletModule,
        QRCodeModule,
        TransactionDetailModule,
        NgxPaginationModule,
        RecaptchaModule.forRoot(),
        ExchangeModule,
        ResetModule,
        DepositModule,
        WithdrawModule,
        FiathistoryModule,
        OrderModule,
        NewipdetectModule,
        DashboardModule,
        PosttrdeModule,
        TraddetailModule,
        TradeactionModule,
        TradelistModule,
        WithdrawverifyModule,
        UsdtransactionModule,
        ExchangepairModule,
        ExchangeMicroServiceModule
    ],
    providers: [
        ServerService,
        DatePipe,
        GuardsGuard
    ],
    bootstrap: [AppComponent]
})
export class AppModule { }
