import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class StoreService {
  emp:any[];
  constructor() { 

    this.emp = [
    { empcode:'01',name:'Nitesh Jha'  },
    { empcode:'02',name:'Deepak Jha'  },
    { empcode:'03',name:'Sanjeev Jha'  },
  ];
  
  }

  
  
}

