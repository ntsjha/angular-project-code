import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CrmInvoicesViewPage } from './crm-invoices-view';

@NgModule({
  declarations: [
    CrmInvoicesViewPage,
  ],
  imports: [
    IonicPageModule.forChild(CrmInvoicesViewPage),
  ],
})
export class CrmInvoicesViewPageModule {}
