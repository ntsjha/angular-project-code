import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FiathistoryComponent } from './fiathistory/fiathistory.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [FiathistoryComponent]
})
export class FiathistoryModule { }
