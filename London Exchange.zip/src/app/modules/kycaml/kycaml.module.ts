import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { KycamlComponent } from './kycaml/kycaml.component';

@NgModule({
    imports: [
        CommonModule
    ],
    declarations: [KycamlComponent]
})
export class KycamlModule { }
