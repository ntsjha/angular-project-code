import { Component, OnInit } from '@angular/core';
import { Employee } from 'src/app/Shared/employee.model';
import { ServiceService } from 'src/app/Shared/service.service';
import { AngularFirestore } from '@angular/fire/firestore';
import { HorseList } from 'src/app/Shared/horseList.model';
import { Router, ActivatedRoute } from '@angular/router';
import { isNgTemplate } from '@angular/compiler';

@Component({
  selector: 'app-user-management-view',
  templateUrl: './user-management-view.component.html',
  styleUrls: ['./user-management-view.component.css']
})
export class UserManagementViewComponent implements OnInit {
  id
  Name:any;
  Position:any;
  Mobile:any;
  UserDetails: any;
  userName : any;
  position : any;
  email: any;
  eaNumber: any;
  plan: any;
  image: any;
  horseList:HorseList[];
  p: number = 1;
  pageSize = 5;
  total = 0
  searchText: string = "";
  horseID
  userprofile: any;
  userprofileImage: any;
  constructor(private service: ServiceService,
    private afs: AngularFirestore, private router: Router,private route :ActivatedRoute) {
             }

  ngOnInit() {
    this.route.params.subscribe(params => {
      this.id = params['id'];
      // console.log("details id ===>>",this.id)
    });
   this.getUserDetailsFunc();
   this.service.showSpinner()
    this.service.getHorseList(this.id).subscribe(actionArray => {
       this.horseList = actionArray.map(item => {       
        return {
          id: item.payload.doc.id,
          ...item.payload.doc.data()

        } as HorseList;
      })
      this.service.hideSpinner();
      this.total = this.horseList.length
      console.log('this.horseList====>',JSON.stringify(this.horseList));
    });

    this.afs.collection('employees').doc(this.id).ref.get().then(function(doc) {
      // console.log("Document data:", doc.data());
  })
  }

  getUserDetailsFunc(){
    this.service.showSpinner();
    this.service.getEmployeeDetails().subscribe(userArr =>{
      var userDetail = userArr.map(x=>{
        return {
          id: x.payload.doc.id,
          ...x.payload.doc.data()
        }
      })
      console.log('data--->>',JSON.stringify(userDetail))
      this.UserDetails = userDetail.filter(x=>(x.id == this.id));
      this.userprofileImage=this.UserDetails[0].userImage?this.UserDetails[0].userImage:'../../../assets/img/profile-img.jpg'
      console.log('UserDetails--->>',JSON.stringify(this.UserDetails),  this.userprofileImage)
      this.service.hideSpinner();
    },err =>{
      this.service.hideSpinner();
      // console.log(err)
    })
  }
 

  horseDetails(item){
    this.horseID = item.id;
    var data = this.id+'-health-'+this.horseID
    this.router.navigate(['/userManagement/userManagementView/horseDetails',data])
  }
  deleteFunction(item){
    this.horseID=item.id
    console.log(item.id)
  }
  onDelete(){
    this.afs.doc('horseList/' + this.horseID).delete();
    
  }
}
