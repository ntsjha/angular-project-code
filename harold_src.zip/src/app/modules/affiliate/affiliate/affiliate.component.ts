import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ServerService } from '../../../server.service';
import { AppComponent } from '../../../app.component';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { HeaderComponent } from '../../header/header/header.component';

@Component({
    selector: 'app-affiliate',
    templateUrl: './affiliate.component.html',
    styleUrls: ['./affiliate.component.css']
})
export class AffiliateComponent implements OnInit {

    user = {refLink:"", refCode:""};
    refListArr = [];
    
    constructor(public router: Router, private server: ServerService, public appC: AppComponent, private loader: Ng4LoadingSpinnerService, public header: HeaderComponent) { }

    ngOnInit() {   
        this.getBountyRecordData();     
        this.getUserReferenceData();
        
    }

    /** Function for clip to copyboard for ref link and code */
    clipToCopyboard(text) {
        this.appC.showInfoToast("Text has been copied to clipboard.");
        let selBox = document.createElement('textarea');
        selBox.style.position = 'fixed';
        selBox.style.left = '0';
        selBox.style.top = '0';
        selBox.style.opacity = '0';
        selBox.value = text;
        document.body.appendChild(selBox);
        selBox.focus();
        selBox.select();
        document.execCommand('copy');
        document.body.removeChild(selBox);
    }

    /** Function for get user's reference data */
    getUserReferenceData() {
        this.loader.show();
        let data = {
            "referrerCode"  : '',
            "userId"        : localStorage.getItem('userId')
        }
        
        this.server.postApi('reference-service/reference-code',data).subscribe((succ) => {
            if (succ.status == 200) {
                this.user.refCode = succ.data;
                this.user.refLink = this.server.refURL+succ.data;
            } else {
                this.appC.showErrToast(succ.message);
            }
        }, (err) => {
            this.loader.hide();
            this.appC.showErrToast(err.error.message);
        });
    }

    /** Function for get user's reference data */
    getBountyRecordData() {
        this.loader.show();
        let data = {
            "userId"  : localStorage.getItem('userId')
        }
        this.server.postApi('reference-service/bounty-record',data).subscribe((succ) => {
            
            if (succ.status == 200) {
                this.refListArr = succ.data;
            } else {
                this.appC.showErrToast(succ.message);
            }
            this.loader.hide();
        }, (err) => {
            this.loader.hide();
            this.appC.showErrToast(err.error.message);
        });
    }

}
