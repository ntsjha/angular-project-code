import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, App } from 'ionic-angular';
import { QBService } from '../../providers/qb/qb';

declare var QB: any;
import { qbEndpoints, qbAccount } from '../core/qb.config';
import * as $ from 'jquery';
import { LoginPage } from '../login/login';
import { MessagePage } from '../message/message';

import { FileChooser } from '@ionic-native/file-chooser';

/**
 * Generated class for the HomePage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-home',
  templateUrl: 'home.html',
})
export class HomePage {

  contacts: {};
  chatData: Array<any>;
  message: String;
  selectedUser: any;
  session: any;
  dialogId: Number;
  userDetails: any;
  messageObj: any;

  MessagesFromUsers = (userId, msg) => {
    this.messageObj = {
      from: userId,
      body: msg.body
    };
    this.qbService._notificationObj.emit(this.messageObj);
  }

  constructor(private fileChooser: FileChooser,public _app:App,public navCtrl: NavController,private qbService: QBService) { }



  /**
   * On message send
   *
   * @param userId: To UserId
   * @param message: composed message
   */
  onEnter(userId, message) {
    QB.chat.send(userId, {
      type: 'chat',
      body: message,
      extension: { save_to_history: 1 }
    });
    this.chatData.push({ 'message': message, 'sender_id': this.session.user_id });
    this.message = '';
  }
  Attach(userId, message) {
   
    QB.chat.send(userId, { 
      type: 'any',
      body: message,
      extension: { save_to_history: 1 }
    });
    this.chatData.push({ 'message': message, 'sender_id': this.session.user_id });
    this.message = '';
  }

  /**
   * Retrive Chat History
   *
   */
  retriveMessage() {
    this.qbService.retriveMessage(this.session.token, this.dialogId)
      .subscribe((res: any) => {
        this.chatData = res.items;
      });
  }

  /**
   * Chat user selection
   *
   * @param user: selected user details
   */
  onUserSelect(user) {
    //this.navCtrl.push(MessagePage);
    this.selectedUser = user;
    console.log('user==', this.selectedUser);
    this.qbService.createDialog(this.session.token, this.selectedUser.id)
      .subscribe((data: any) => {
        this.qbService.data=data

        console.log('Dialog response', this.qbService.data);
        this.dialogId = data._id;
        this.qbService.data_id=this.dialogId;
        console.log('Dialog response', this.qbService.data_id);
        this.retriveMessage();
        setTimeout(function() { $('.messages-list').scrollTop($('.messages-list')[0].scrollHeight); }
        , 1000);
      });
  }

  /**
   * Component onInit
   */
  ngOnInit() {
    this.session = JSON.parse(sessionStorage.getItem('session'));
    this.qbService.getProfileDetails(sessionStorage.getItem('uname'), this.session.token)
      .subscribe((data: any) => {
        this.userDetails = data;
      
      });
    this.qbService.getUsers(this.session.token, this.session.user_id)
      .subscribe((data: any) => {
        this.contacts = data.items;
        //console.log('datta==>',this.contacts )
        QB.init(qbAccount.appId, qbAccount.authKey, qbAccount.authSecret, qbEndpoints);
        QB.chat.connect({ userId: this.session.user_id, password: sessionStorage.getItem('pass') }, (err, roster) => {
          if (err) {
            console.log(err);
          } else {
            QB.chat.onMessageListener = this.MessagesFromUsers;
          }
        });
      });

    this.qbService._notificationObj
      .subscribe((data) => {
        if (data.from ===  this.selectedUser.id) {
          this.chatData.push({ recipient_id: data.from, message : data.body});
        }
      });
  }
  async  filechoose(){
    this.fileChooser.open()
    
  .then(uri =>  this.chatData.push({ 'message': uri, 'sender_id': this.session.user_id }))
  .catch(e => console.log(e));
  }

  home(){
    this.navCtrl.push(MessagePage);
  }
  logout(){
    this._app.getRootNav().setRoot(LoginPage);
  }
}
