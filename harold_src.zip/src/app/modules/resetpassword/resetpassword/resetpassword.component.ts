import { Component, OnInit } from '@angular/core';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { Router } from '@angular/router';
import { HeaderComponent } from '../../header/header/header.component';
import { AppComponent } from '../../../app.component';
import { ServerService } from '../../../server.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-resetpassword',
  templateUrl: './resetpassword.component.html',
  styleUrls: ['./resetpassword.component.css']
})
export class ResetpasswordComponent implements OnInit {
  resetForm: FormGroup;

  constructor(private appC:AppComponent,private spinnerService: Ng4LoadingSpinnerService, private router: Router, private header: HeaderComponent, private server: ServerService) { }

  ngOnInit() {
    window.scrollTo(0,0);
    this.checkInputs();
  }
  
  checkInputs() {
    this.resetForm = new FormGroup({
      newpassword: new FormControl('', [Validators.required, Validators.pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})/i)]),
      confrmpassword: new FormControl('', [Validators.required]),
    }, passwordMatchValidator);
    /** Function for password match and mismatch */
    function passwordMatchValidator(g: FormGroup) {
      let pass = g.get('newpassword').value;
      let confPass = g.get('confrmpassword').value;
      if (pass != confPass) {
        g.get('confrmpassword').setErrors({ mismatch: true });
      } else {
        g.get('confrmpassword').setErrors(null)
        return null
      }
    }
  }

  /**Functions to get input data */
  get newpassword(): any {
    return this.resetForm.get('newpassword');
  }

  get confrmpassword(): any {
    return this.resetForm.get('confrmpassword');
  }

  resetPassword() {
    if (this.resetForm.value.newpassword == "" ||  this.resetForm.value.confrmpassword == "") {
      this.appC.showErrToast("Please Enter Details.");
      return;
    } 

    let url = window.location.href.split('=')
    let page = url[url.length - 1]
    let data = {
      "password": this.resetForm.value.newpassword,
      "token": page
    }
    this.spinnerService.show();
    this.server.postApi('account/reset-password', data).subscribe((res) => {
      this.spinnerService.hide();
      if (res.status == 200) {
        this.appC.showSuccToast("Password changed successfully");
        this.router.navigateByUrl('login');
        
      }
      else {
        this.appC.showErrToast(res.message);
      }

    }, (err) => {
      this.spinnerService.hide();
      this.appC.showErrToast('Something went wrong')
    })
  }



}
