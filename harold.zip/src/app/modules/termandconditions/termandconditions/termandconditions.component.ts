import { Component, OnInit } from '@angular/core';
import { ServerService } from '../../../server.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';

@Component({
    selector: 'app-termandconditions',
    templateUrl: './termandconditions.component.html',
    styleUrls: ['./termandconditions.component.css']
})
export class TermandconditionsComponent implements OnInit {

    pageData: any = [];

    constructor(private server: ServerService, private spinnerService: Ng4LoadingSpinnerService) { }

    ngOnInit() {
        window.scrollTo(0,0);
        this.getPageData();
    }

    getPageData() {
        this.spinnerService.show();
        this.server.getApi('static/static-content/TermsAndCondition').subscribe((succ) => {
            this.pageData = succ.data.pageData;
            this.spinnerService.hide();
        },err =>{
            this.spinnerService.hide();
            this.pageData = 'No Data Found.' ;
        });
    }
    

}
