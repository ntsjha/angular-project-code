import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WithdrawverifyComponent } from './withdrawverify/withdrawverify.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [WithdrawverifyComponent]
})
export class WithdrawverifyModule { }
