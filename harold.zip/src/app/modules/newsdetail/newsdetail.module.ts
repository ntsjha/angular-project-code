import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NewsdetailComponent } from './newsdetail/newsdetail.component';
import { FormsModule } from '@angular/forms';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
  ],
  declarations: [NewsdetailComponent]
})
export class NewsdetailModule { }
