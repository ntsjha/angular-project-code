import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppComponent } from '../../../app.component';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { HeaderComponent } from '../../header/header/header.component';
import { ServerService } from '../../../service/server.service';

@Component({
    selector: 'app-suggestion',
    templateUrl: './suggestion.component.html',
    styleUrls: ['./suggestion.component.css']
})
export class SuggestionComponent implements OnInit {
    option: any = 'ALL';
    suggestionListArr: any = [];
    voteListArr: any = [];
    subFilter: any;
    status: any = 'ALL';

    constructor(private router: Router,private server: ServerService, private appC: AppComponent, private spinnerService: Ng4LoadingSpinnerService, public header: HeaderComponent) { }

    ngOnInit() {
        this.option = 'ALL'
        window.scrollTo(0,0);
        this.getSuggestionList();
    }

    add() {
        this.router.navigate(['/header/addsuggestion']);
    }
    
    /** Function to get suggestion list */
    getSuggestionList() {
        this.suggestionListArr = [];
        let data = {
            "eventExternal": {
                "name":"request_get_suggestion_details",
                "key":"mykey"
            },
            "transferObjectMap": {
                "gatewayrequest": {
                "filterType": this.option,
                "subFilterType": this.subFilter
                }
            }
        }
        this.spinnerService.show();
        this.server.postApi('',data,0).subscribe((res) => {
            this.spinnerService.hide();
            if(res.transferObjectMap.statusCode == 200) {
            if(res.transferObjectMap.result.length !=0) {
                res.transferObjectMap.result.forEach(obj => {
                    this.suggestionListArr.push({
                        title: obj.title,
                        description: obj.description,
                        status: obj.status,
                        suggestionCreationTime: obj.suggestionCreationTime,
                        suggestionId: obj.suggestionId,
                        image: obj.image
                    });
                });
            }  
            } else if(res.transferObjectMap.statusCode == 403) {
                this.header.tokenExpire();
            } else {
                this.spinnerService.hide();
                this.appC.showErrToast('Something went wrong');
            }      
        }, (err) => {
            this.spinnerService.hide();
        })
    }

    onClick(val)  {
        this.option = val;
        this.getSuggestionList();
    }

    onTabClick(val)  {
        this.subFilter = val;
        this.getSuggestionList();
    }

    /** Function to get vote count */
    getVoteCount(id) {
        let data = {
            "eventExternal":{
                "name":"request_get_vote_counts",
                "key":"mykey"
            },
            "transferObjectMap":{
                "gatewayrequest": {
                    "suggestionId": id
                }
            }  
        }
        this.spinnerService.show();
        this.server.postApi('',data,0).subscribe((res) => {
            this.spinnerService.hide();
            if(res.transferObjectMap.statusCode == 200) {
            var ind = this.suggestionListArr.findIndex((x) => x.suggestionId == id);
            if(ind != -1) {
                this.suggestionListArr[ind].vote = res.transferObjectMap.result; 
            } 
            } else if(res.transferObjectMap.statusCode == 403) {
                this.header.tokenExpire();
            } else {
                this.spinnerService.hide();
                this.appC.showErrToast('Something went wrong');
            }      
        }, (err) => {
            this.spinnerService.hide();
        })
    }

    /** Function for voting */
    functionToVote(id)  {
        let vote = {
            "eventExternal":{
                "name":"request_save_suggestion_vote",
                "key":"mykey"
            },
            "transferObjectMap":{
                "gatewayrequest":{
                    "suggestionId": id
                }
            }
        }
        this.spinnerService.show();
        this.server.postApi('',vote,0).subscribe((res) => {
            this.spinnerService.hide();
            if(res.transferObjectMap.statusCode == 200) {
                this.appC.showSuccToast(res.transferObjectMap.message);
               // this.getVoteCount(id);
            } else if(res.transferObjectMap.statusCode == 403) {
                this.header.tokenExpire();
            } else {
                this.spinnerService.hide();
                this.appC.showErrToast('Next voting can be done after 24 hrs .');
            }      
        }, (err) => {
            this.spinnerService.hide();
            this.appC.showErrToast('Voting lines are closed now...');
        })
    }

}
