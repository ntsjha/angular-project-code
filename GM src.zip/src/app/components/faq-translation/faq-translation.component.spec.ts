import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FaqTranslationComponent } from './faq-translation.component';

describe('FaqTranslationComponent', () => {
  let component: FaqTranslationComponent;
  let fixture: ComponentFixture<FaqTranslationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FaqTranslationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FaqTranslationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
