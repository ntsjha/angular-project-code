import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ServerService } from '../../../service/server.service';
import { Observable, Subject } from 'rxjs';
import { AppComponent } from '../../../app.component';
import { PlatformLocation } from '@angular/common'
import { Ng4LoadingSpinnerService } from '../../../../../node_modules/ng4-loading-spinner';
declare var $: any;

@Component({
    selector: 'app-header',
    templateUrl: './header.component.html',
    styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

    loginStatus: any;
    userName = "";
    private subject = new Subject<any>();
    flag: any;
    name: any;
    footer: boolean;
    userImage: string;
    securityType: any;
    
    constructor(private router: Router, public myService: ServerService, private server: ServerService, public appC: AppComponent, public location: PlatformLocation, private spinnerService: Ng4LoadingSpinnerService) {
        this.appC.fireToChild().subscribe((msg) => {
            msg.text == "sessionExpire" ? this.checkLogin() : "";
        });
        location.onPopState(() => {
            let url = window.location.href.split('/')
            let page = url[url.length - 1]
            if (page == "exchange") {
                localStorage.setItem("exchange", "true")
                this.flag = localStorage.getItem('exchange')
            }
            else {
                this.flag = ""
            }
        });
    }

    /** Function for call event in child component */
    fireToChild(): Observable<any> {
        return this.subject.asObservable();
    }

    ngOnInit() {
        this.getprofile(); 
        this.checkLogin();        
        // this.menu();
    }

    menu() {       
        $('#menubox').toggleClass('menu-slide');    
    }
    
    /** Function to test user is login or not */
    checkLogin() {
        if (localStorage.getItem("token") || (localStorage.getItem('header'))) {
            this.loginStatus = true;
            this.myService.loginStatus = this.loginStatus;            
        } else {
            this.loginStatus = false;
            this.myService.loginStatus = this.loginStatus;
        }
    }

    /** Function for go to page */
    goToPage(type) {
        switch (type) {
            case 0:
                this.router.navigate(['header']);
                break;
            case 1:
                this.router.navigate(['/header/login']);
                break;
            case 2:
                this.router.navigate(['/header/signup']);
                break;
            case 3:
                if($('#menubox').hasClass("menu-slide")) {
                    $('#menubox').toggleClass('menu-slide');
                }
                this.router.navigate(['/header/wallet']);
                break;
            case 4:
                this.router.navigate(['/header/privacy']);
                break;
            case 5:
                this.router.navigate(['/header/twofa']);
                break;
            case 6:
                this.router.navigate(['/header/terms']);
                break;
            case 7:
                this.router.navigate(['/header/support']);
                break;
            case 8:
                this.router.navigate(['/header/aboutus']);
                break;
            case 9:
                if($('#menubox').hasClass("menu-slide")) {
                    $('#menubox').toggleClass('menu-slide');
                }
                this.router.navigate(['/header/dashboard']);
                break;
            case 10:
                if($('#menubox').hasClass("menu-slide")) {
                    $('#menubox').toggleClass('menu-slide');
                }
                this.router.navigate(['exHeader']);
                break;
            case 11:
                if($('#menubox').hasClass("menu-slide")) {
                    $('#menubox').toggleClass('menu-slide');
                }
                this.router.navigate(['/header/kyc']);
                break;
            case 12:
                if($('#menubox').hasClass("menu-slide")) {
                    $('#menubox').toggleClass('menu-slide');
                }
                this.router.navigate(['/header/deposit']);
                break;
            case 13:
                if($('#menubox').hasClass("menu-slide")) {
                    $('#menubox').toggleClass('menu-slide');
                }
                this.router.navigate(['/header/withdraw']);
                break;
            case 14:
                if($('#menubox').hasClass("menu-slide")) {
                    $('#menubox').toggleClass('menu-slide');
                }
                this.router.navigate(['/header/account']);
                break;
            case 15:
                this.router.navigate(['/header/faq']);
                break;
            case 16:
                this.router.navigate(['/header/fees']);
                break;
            case 17:
                this.router.navigate(['header/legal']);
                break;
            case 18:
                this.router.navigate(['/header/contact']);
                break;
            case 19:
                if($('#menubox').hasClass("menu-slide")) {
                    $('#menubox').toggleClass('menu-slide');
                }
                this.router.navigate(['/header/fiathistory']);
                break;
            case 20:
                this.router.navigate(['/header/buySell']);
                break;
            case 21:
                this.router.navigate(['/header/kycAml']);
                break;
            case 22:
                if(!this.loginStatus) {
                    this.router.navigate(['/header/login']);
                } else {
                    this.router.navigate(['exHeader']);
                }
                break;
            case 23:
                this.router.navigate(['/header/howitworks']);
                break;
            case 24:                
                if($('#menubox').hasClass("menu-slide")) {
                    $('#menubox').toggleClass('menu-slide');
                }
                this.router.navigate(['/header/airdrop']);
                break;
            case 26:
                if($('#menubox').hasClass("menu-slide")) {
                    $('#menubox').toggleClass('menu-slide');
                }
                this.router.navigate(['/header/otcdesk']);
                break;
            case 27:
                this.router.navigate(['/header/suggestion']);
                break;
            case 28:
                this.router.navigate(['/header/signup']);
                break;
        }
    }

    logOut() {
        localStorage.clear();
        $('#logoutModal').modal('hide');
        this.router.navigate(['/header/home']);
        this.checkLogin();
        this.subject.next({ text: "logout" });   
        let data = {
                        messageType:"userUpdated",
                        token: "notLoggedIn"
                    }
                    this.server.wsExchange.send(JSON.stringify(data)); 
        // this.router.navigate(['header']);
        // let data = {            
        //     "eventExternal": {
        //         "name":"request_logout",
        //         "key":"mykey"
        //     },
        //     "transferObjectMap": { 
        //         "gatewayrequest": {
        //             "token": localStorage.getItem('token')
        //         }
        //     }
        // }
        // this.spinnerService.show();
        // this.server.postApi('', data,0).subscribe(response => {
        //     this.spinnerService.hide();
        //     if (response.transferObjectMap.statusCode == 200) {
        //         this.spinnerService.hide();
        //         this.appC.showInfoToast(response.transferObjectMap.message);
        //         localStorage.clear();
        //         //localStorage.removeItem('token');
        //         this.checkLogin();
        //         //localStorage.removeItem('exchange');
        //         //this.check();
        //         this.subject.next({ text: "logout" });                
        //         this.router.navigate(['header']);
        //         let data = {
        //             messageType:"userUpdated",
        //             token: "notLoggedIn"
        //         }
        //         this.server.wsExchange.send(JSON.stringify(data));
        //     } else if(response.transferObjectMap.statusCode == 403){
        //         this.tokenExpire();
        //     }
        //     else {
        //         this.appC.showErrToast(response.transferObjectMap.message);
        //     }
            
        // }, error => {
        //     this.spinnerService.hide();
        //     this.appC.showErrToast('Something went wrong');
        // });        
    }

    logoutNo() {
       
        $('#logoutModal').modal("hide");
       
    }

    openLogout() {
        if($('#menubox').hasClass("menu-slide")) {
            $('#menubox').toggleClass('menu-slide');
        }
        $('#logoutModal').modal("show");
    }

    goTo() {
        this.appC.showWarnToast('Work in progress....');
    }

    getprofile() {
        if(localStorage.getItem('token')) {
            //this.spinnerService.show();
            this.server.getApi("account/my-account",localStorage.getItem('token')).subscribe((succ) => {
                //this.spinnerService.hide();
                this.name = succ.body.data.firstName;  
                if(succ.body.data.imageUrl==null || succ.body.data.imageUrl=='')
                   this.userImage = 'assets/images/user.png';
                else
                   this.userImage = succ.body.data.imageUrl; 
                if(succ.body.data.twoFaType == "GOOGLE") {
                    this.securityType = "GA";
                } else if(succ.body.data.twoFaType == "SMS") {
                    this.securityType = "SMS";
                } else {
                    this.securityType = "";
                }
            }, (err) => {
                //this.spinnerService.hide();
            });
        }
    }

    /**Function for token expire */
    tokenExpire()  {

        //localStorage.removeItem('token');
        localStorage.clear();
        this.checkLogin();
        //localStorage.removeItem('exchange');
        //this.check();
        this.subject.next({ text: "logout" });
        this.router.navigate(['header']);
        let data = {
            messageType:"userUpdated",
            token: "notLoggedIn"
        }
        this.server.wsExchange.send(JSON.stringify(data));
        
    }

    /** to make it mobile responsive */
    menuClick() {
        $('#menubox').toggleClass('menu-slide');
    }
}
