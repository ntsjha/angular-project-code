import { Component, OnInit, OnDestroy } from '@angular/core';
import { ServiceService } from 'src/app/service/service.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';
import { AppComponent } from 'src/app/app.component';
import { ActivatedRoute } from '@angular/router';
declare var $: any;

@Component({
    selector: 'app-basic-detail',
    templateUrl: './basic-detail.component.html',
    styleUrls: ['./basic-detail.component.css']
})
export class BasicDetailComponent implements OnInit, OnDestroy {
    id: any;
    dataObj: any = {};
    rejectionModalForm: FormGroup;
    status: any;
    message: string;
    error = false;
    profileImage: string | ArrayBuffer;
    fileData: any;
    msgType: any;
    fileName: string;
    reasonArr: any = [];
    subscription: any;
    kycId: any;
    file: any;

    constructor(private server: ServiceService, private spinner: NgxSpinnerService, private appC: AppComponent, private activatedRoute: ActivatedRoute ) {

        this.subscription = this.server.authVerify.subscribe((res) => {
            if (res === 'basic-detail') {
                $('#google-auth-modal').modal('hide');
                this.actiononKYC();
                this.server.authVerify.next('false');
            }
        });

        this.rejectionModalForm = new FormGroup({
            select_reason: new FormControl('', [Validators.required]),
            remark: new FormControl(''),
        });
    }
    ngOnInit() {
        this.callByUrl();
        this.getReasonsList();
        window.scrollTo(0, 0);
        
    }

    callLoader() {
        setTimeout(() =>{
            this.spinner.hide();
        },10000)
    }

    ngOnDestroy() {
        this.subscription.unsubscribe();
    }

    getReasonsList() {
        this.reasonArr = [];
        this.server.postMethod('account/operation/get-kyc-rejection-reason', {}, 1).subscribe((res) => {
            if (res.data) {
                const response = JSON.parse(this.server.decrypt(res.data));
                if (response.hasOwnProperty('data')) {
                    response.data.forEach(element => {
                        if(element.reason) {
                            this.reasonArr.push(element)
                        }
                    });
                }
            }
        });
    }
    get select_reason(): any {
        return this.rejectionModalForm.get('select_reason');
    }
    get remark(): any {
        return this.rejectionModalForm.get('remark');
    }

    callByUrl() {
        // const url = window.location.href;
        // const arr = url.split('/');
        // this.id = arr[arr.length - 1];
        this.activatedRoute.params.subscribe((params)=>{
            this.id = params.id;
            this.kycId = params.kycId;
            console.log(params)
        })
        this.getKycDetails();
    }

    getKycDetails() {
        this.spinner.show();
        this.server.postMethod('account/operation/get-customer-kyc-profile?userIdDataBase=' + encodeURIComponent(this.server.encrypt(this.id)) + '&kycId=' + encodeURIComponent(this.server.encrypt(this.kycId)), {}, 1).subscribe((res) => {
            if (res.data) {
                const response = JSON.parse(this.server.decrypt(res.data));
                console.log(response)
                this.dataObj = response.data;
                if (this.dataObj.frontImageUrl) {
                    this.getBase64Func(this.dataObj.frontImageUrl,'front');
                }
                if (this.dataObj.backImageUrl) {
                    this.getBase64Func(this.dataObj.backImageUrl,'back');
                }
                if (this.dataObj.selfieImageUrl) {
                    this.getBase64Func(this.dataObj.selfieImageUrl,'selfie');
                }
                if (this.dataObj.taxCertificateUrl) {
                    this.getBase64Func(this.dataObj.taxCertificateUrl,'tax');
                }
                if (this.dataObj.dbd) {
                    this.getBase64Func(this.dataObj.dbd,'dbd');
                }
            } else {
                this.spinner.hide();
            }
        }, (error) => {
            this.spinner.hide();
        });
    }

    getBase64Func(img,type) {
        this.callLoader();
        if (img) {
            this.server.getMethod('account/convert-image-base64?imageUrl=' + this.server.imageUrl + img, 1).subscribe((res: any) => {
                this.spinner.hide();
            }, error => {
                if (error && error.error.text) {
                    this.spinner.hide();
                    if(type == 'front') {
                        this.dataObj.frontImageUrl = 'data:image/jpg;base64,' + error.error.text;
                    } else if(type == 'back') {
                        this.dataObj.backImageUrl = 'data:image/jpg;base64,' + error.error.text;
                    } else if(type == 'selfie') {
                        this.dataObj.selfieImageUrl = 'data:image/jpg;base64,' + error.error.text;
                    } else if(type == 'tax') {
                        this.dataObj.taxCertificateUrl = 'data:image/jpg;base64,' + error.error.text;
                    } else if(type == 'dbd') {
                        this.dataObj.dbd = 'data:image/jpg;base64,' + error.error.text;
                    } 
                }

            });
        }
    }

    checkUpload() {
        if (!(this.dataObj.selfieImageUrl || this.profileImage)) {
            $('#uploadModal').modal({ backdrop: 'static', keyboard: false });
        } else {
            this.open2FA('ACCEPTED');
        }
    }

    openModal() {
        $('#myticket1').modal({ backdrop: 'static', keyboard: false });
    }

    open2FA(status) {
        $('#uploadModal').modal('hide');
        this.status = status;
        this.appC.google = { one: '', two: '', three: '', four: '', five: '', six: '' };
        this.appC.response = { 'message': '' };
        this.server.googleAuthCalledFrom = 'basic-detail';
        $('#google-auth-modal').modal({ backdrop: 'static', keyboard: false });

    }

    actiononKYC() {
        const reasonObj = this.reasonArr.findIndex(x => x.reason === this.rejectionModalForm.value.select_reason);
        const data = {
            kycStatus: this.status,
            userId: this.id,
            location: this.server.initialUserInfo.city + ',' + this.server.initialUserInfo.country_name,
            ipAddress:this.server.initialUserInfo.ip,
            kycId: this.dataObj.kycId,
            reasonId: this.rejectionModalForm.value.select_reason,
            languageCode: this.server.encrypt(this.server.currLang)
        };

        if (this.rejectionModalForm.value.select_reason) {
            data['remark'] = reasonObj.kycRejectionReasonId;
        }
        if (this.rejectionModalForm.value.remark) {
            data['remark'] = this.rejectionModalForm.value.remark;
        }

        this.server.postMethod('account/operation/action-approve-reject-kyc', data, 1).subscribe((res) => {
            window.scrollTo(0,0);
            $('#myticket1').modal('hide');
            this.spinner.hide();
            if (res.status === 553) {
                this.dataObj.kycStatus = this.status;
                this.getKycDetails();
            }
        },err => {
            this.spinner.hide();
        });
    }

    // to close modal
    closeModal() {
        this.rejectionModalForm.reset();
        this.fileName = '';
        $('#uploadModal').modal('hide');
    }

    handleFileInput(event, msg) {
        this.profileImage = '';
        this.message = '';
        this.error = false;
        this.msgType = msg;
        var self = this;
        if (event.target.files && event.target.files[0]) {
            var type = event.target.files[0].type;
            if (type === 'image/png' || type === 'image/jpg' || type === 'image/jpeg') {
                this.fileData = event.target.files[0];
                this.fileName = event.target.files[0].name;
                this.uploadSelfiImage();

                var reader = new FileReader();
                reader.onload = (e) => {
                    self.profileImage = e.target['result'];
                };
            } else {
                this.message = 'Select only jpg,jpeg and png file.';
                this.error = true;
                self.profileImage = '';
                self.fileData = '';
                self.fileName = '';
            }
        }
    }
    uploadSelfiImage() {
        const formdata = new FormData();
        formdata.append('file', this.fileData);
        if (navigator.onLine) {
            this.server.uploadMethod('account/uploadFile', formdata).subscribe((succ) => {
                if (succ.fileName) {
                    this.profileImage = succ.fileName;
                    this.uploadSelfieUrl();
                }
            }, error => {

            });
        }
    }

    openImgModal(file) {
        $('#image-modal').modal('show');
        this.file = file;
    }

    uploadSelfieUrl() {
        let url;
        if (!this.dataObj.selfieImageUrl) {
            url = 'account/operation/save-kyc-selfie-url?kycId=' + this.dataObj.kycId + '&selfieUrl=' + this.profileImage;
        } else {
            url = 'account/operation/save-kyc-selfie-url?kycId=' + this.dataObj.kycId;
        }
        this.server.postMethod(url, {}, 1).subscribe((res) => {
        });
    }


}