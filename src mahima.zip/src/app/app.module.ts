import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { ReactiveFormsModule,FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { Ng4LoadingSpinnerModule } from 'ng4-loading-spinner';
import { CookieService } from 'ngx-cookie-service';
import { ToastrModule } from 'ngx-toastr';

/**************************** Material ************************/

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatInputModule } from '@angular/material/input';
import {MatGridListModule} from '@angular/material/grid-list';
import {MatButtonModule} from '@angular/material/button';
import {MatChipsModule} from '@angular/material/chips';
import {MatCardModule, MatTableModule, MatOptionModule, MatSelectModule, MatPaginatorModule} from '@angular/material';
import {MatDialogModule} from '@angular/material';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatCheckboxModule} from '@angular/material/checkbox';
import {MatSidenavModule} from '@angular/material/sidenav';
import {MatIconModule} from '@angular/material/icon';
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatListModule} from '@angular/material/list';

import {MatSlideToggleModule} from '@angular/material/slide-toggle';
/***************************** Components **********************/

import { AppComponent } from './app.component';
import { LoginComponent } from '../app/pages/login/login.component';
import { SignUpComponent } from './pages/sign-up/sign-up.component';
import { ForgotPasswordComponent } from './pages/forgot-password/forgot-password.component';
import { ResetPasswordComponent } from './pages/reset-password/reset-password.component';
import { TermsComponent } from './pages/terms/terms.component';
import { AboutUsComponent } from './pages/about-us/about-us.component';
import { ContactUsComponent } from './pages/contact-us/contact-us.component';
import { PrivacyPolicyComponent } from './pages/privacy-policy/privacy-policy.component';
import { SmsVerifyComponent } from './pages/sms-verify/sms-verify.component';
import { EmailVerifyComponent } from './pages/email-verify/email-verify.component';
import { HeaderComponent } from './pages/header/header.component';
import { FooterComponent } from './pages/footer/footer.component';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { AddPetrolComponent } from './pages/add-petrol/add-petrol.component';
import { MyProfileComponent } from './pages/my-profile/my-profile.component';
import { EditProfileComponent } from './pages/edit-profile/edit-profile.component';
import { UserManagementComponent } from './pages/user-management/user-management.component';
import { MachineReadingComponent } from './pages/machine-reading/machine-reading.component';
import {NgxPaginationModule} from 'ngx-pagination'; 
import { BuySubscriptionComponent } from './pages/buy-subscription/buy-subscription.component';
import { PaymentScreenComponent } from './pages/payment-screen/payment-screen.component';
import { AddPetrolPumpModal } from './pages/modals/add-petrol-pump-modal.component';
import { AddTankModalComponent } from './pages/add-tank-modal/add-tank-modal.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    SignUpComponent,
    ForgotPasswordComponent,
    ResetPasswordComponent,
    TermsComponent,
    AboutUsComponent,
    ContactUsComponent,
    PrivacyPolicyComponent,
    SmsVerifyComponent,
    EmailVerifyComponent,
    HeaderComponent,
    FooterComponent,
    DashboardComponent,
    AddPetrolComponent,
    MyProfileComponent,
    EditProfileComponent,
    UserManagementComponent,
    MachineReadingComponent,
    AddPetrolPumpModal,
    BuySubscriptionComponent,
    PaymentScreenComponent,
    AddTankModalComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule,
    Ng4LoadingSpinnerModule.forRoot(),
    NgxPaginationModule,MatSlideToggleModule,
    ToastrModule.forRoot({maxOpened:2, positionClass: 'toast-top-center'}),

    /////////////////////// Material
    BrowserAnimationsModule,
    MatInputModule,
    MatButtonModule,
    MatChipsModule,
    MatCardModule,
    MatFormFieldModule,
    MatCheckboxModule,
    MatSidenavModule,
    MatIconModule,
    MatDialogModule,
    MatToolbarModule,
    MatListModule,
    MatGridListModule,
    MatTableModule,
    MatSelectModule,
    MatOptionModule,
    MatPaginatorModule,
  ],
  entryComponents: [AddPetrolPumpModal, AddTankModalComponent],
  providers: [CookieService],
  bootstrap: [AppComponent]
})
export class AppModule { }
