export class HorseHealth{
    id: string
    sl_no:string
    feed:string
    type: string
    unit: string
    image: string
}