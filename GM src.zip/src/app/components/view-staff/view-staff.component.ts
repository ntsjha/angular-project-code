import { Component, OnInit, OnDestroy } from '@angular/core';
import { ServiceService } from 'src/app/service/service.service';
import { CookieService } from 'ngx-cookie-service';
import { NgxSpinnerService } from 'ngx-spinner';
import { ActivatedRoute, Router } from '@angular/router';
import { AppComponent } from 'src/app/app.component';

declare var $: any;

@Component({
    selector: 'app-view-staff',
    templateUrl: './view-staff.component.html',
    styleUrls: ['./view-staff.component.css']
})
export class ViewStaffComponent implements OnInit, OnDestroy {
    staffDetails: any = {};
    userData: any = {};
    google: any = { one: '', two: '', three: '', four: '', five: '', six: '' };
    userID: any;
    userPermission: any;
    norecordFound = false;
    loginDetail: any;
    userIp: any;
    subscription: any;
    arr: any[];
    constructor(private service: ServiceService,
        private cookie: CookieService,
        private spinner: NgxSpinnerService,
        private activatedRoute: ActivatedRoute,
        private appC: AppComponent,
        private router: Router) { }

    ngOnInit() {
        this.activatedRoute.params.subscribe(id => {
            this.userID = id.id;
            this.viewStaffProfile(id.id);
        });
        this.userIp = (this.cookie.get('userInfo')) ? JSON.parse(this.cookie.get('userInfo')) : this.service.initialUserInfo;
        this.subscription = this.service.authVerify.subscribe(val => {
            if (val === 'view-staff') {
                this.resetTwoFa();
                this.service.authVerify.next('false');
            }
            if (val === 'change-status') {
                this.enableDisableAccount();
                this.service.authVerify.next('false');
            }
        });
        window.scrollTo(0, 0);
    }

    ngOnDestroy() {
        this.subscription.unsubscribe();
    }

    editProfile() {
        this.router.navigateByUrl('edit-staff/' + this.userID);
    }

    // Function to view admin profile
    viewStaffProfile(id) {
        this.spinner.show();
        this.service.postMethod('account/admin/get-staff-user-profile?staffId=' + encodeURIComponent(this.service.encrypt(String(id))), {}, 1).subscribe((response: any) => {
            let responseData = this.service.decrypt(response.data);
            responseData = JSON.parse(responseData);
            this.staffDetails = responseData;
            this.spinner.hide();
            if (responseData.status === 916 || responseData.status === 585 || responseData.status === 562) {
                this.userData = responseData.data.staffData;
                this.userPermission = responseData.data.userPermissions;
                this.createArr();
                this.getLastLoginHistory(this.userID);
            }
        }, (error) => {
            this.spinner.hide();
        });
    }

    createArr() {
        this.arr = [];
        this.userPermission.forEach(element => {
            if (element.masterPermissionList.menuPermission.menuName) {
                this.arr.push(element);
            }
        });
        this.userPermission.forEach(element => {
            if (element.masterPermissionList.menuPermission.subMenuName) {
                this.arr.forEach((menu, ind) => {
                    if (menu.masterPermissionList.masterPermissionListId == element.masterPermissionList.parentId) {
                        this.arr.splice(ind + 1, 0, element);
                    }
                });
            }
        });
    }

    getLastLoginHistory(id) {
        this.spinner.show();
        this.service.postMethod('account/admin/customer-last-login-detail?userIdDataBase=' + encodeURIComponent(this.service.encrypt(String(id))), {}, 1).subscribe((response: any) => {
            let responseData = this.service.decrypt(response.data);
            responseData = JSON.parse(responseData);
            this.spinner.hide();
            this.loginDetail = responseData.data;
            if (responseData.message === 'no data found') {
                this.norecordFound = true;
            }
        }, (error) => {
            this.spinner.hide();
        });
    }

    /** Auto focus functionality */
    onKey(event, next, previous) {
        if (event.key === 'Backspace') {
            document.getElementById(previous).focus();
        } else {
            if (event.keyCode >= 48 && event.keyCode <= 57) {
                if (event.target.value.trim() !== '') {
                    document.getElementById(next).focus();
                } else {
                    event.target.value = '';
                }
            } else {
                event.target.value = '';
            }
        }
    }

    reset2FA() {
        if (this.service.sideMenuArr.includes('reset2Fa')) {
            this.appC.google = { one: '', two: '', three: '', four: '', five: '', six: '' };
            this.appC.response = { message: '' };
            this.service.googleAuthCalledFrom = 'view-staff';
            $('#google-auth-modal').modal({ keyboard: false, backdrop: 'static' });
        }
    }

    resetTwoFa() {
        $('#reset2FAforAccount').modal('hide');
        this.service.postMethod('account/common-permit/reset-two-fa?email=' + encodeURIComponent(this.service.encrypt(this.userData.email)) + '&ipAddress=' + encodeURIComponent(this.service.encrypt(this.userIp.ip)) + '&location=' + encodeURIComponent(this.service.encrypt(this.userIp.city)), {}, 1)
            .subscribe((response) => {
                this.spinner.hide();
            }, (error) => {
                this.spinner.hide();
            });
        $('#google-auth-modal').modal('hide');
    }

    enableAccount() {
        if (this.service.sideMenuArr.includes('enable/DisableStaffProfile')) {
            this.appC.google = { one: '', two: '', three: '', four: '', five: '', six: '' };
            this.appC.response = { message: '' };
            this.service.googleAuthCalledFrom = 'change-status';
            $('#google-auth-modal').modal({ keyboard: false, backdrop: 'static' });
        }
    }

    enableDisableAccount() {
        const data = {
            adminStatus: (this.staffDetails.data.staffData.staffStatus === 'ACTIVE') ? this.service.encrypt('BLOCK') : this.service.encrypt('ACTIVE'),
            ipAddress: this.service.encrypt(this.userIp.ipAddress),
            location: this.service.encrypt(this.userIp.city + ',' + this.userIp.country_name),
            userId: this.service.encrypt(this.userID),
        };
        this.service.postMethod('account/common-permit/enable-disable-account', data, 1).subscribe((response: any) => {
            this.spinner.hide();
            if (this.staffDetails.data.staffData.staffStatus === 'ACTIVE') {
                this.destroySession(this.staffDetails.data.staffData.email);
            } else if (response.status == 917) {
                this.viewStaffProfile(this.userID);
            }
        }, (error) => {
            this.spinner.hide();
        });
    }

    destroySession(email) {
        this.service.getMethod('account/destroy-session?email=' + encodeURIComponent(this.service.encrypt(email)), 1).subscribe((success: any) => {
            this.spinner.hide();
            this.viewStaffProfile(this.userID);
        }, error => {
        });
    }
}
