import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, App } from 'ionic-angular';
import { RestProvider } from '../../providers/rest/rest';
import { CrmInvoicesViewPage } from '../crm-invoices-view/crm-invoices-view';
import { SettingprivacyPage } from '../settingprivacy/settingprivacy';

/**
 * Generated class for the CrmInvoicesPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-crm-invoices',
  templateUrl: 'crm-invoices.html',
})
export class CrmInvoicesPage {
  invoicesList: any = [];
  constructor(public navCtrl: NavController,private service: RestProvider,  public app :App,public navParams: NavParams) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad CrmInvoicesPage');
    this.getInvoices();
  }
  setting(){
    this.app.getRootNav().push(SettingprivacyPage);
  }
  back(){
    this.navCtrl.pop();
  }
  doRefresh(refresher) {
    console.log('Begin async operation', refresher);
     this.getInvoices();
    setTimeout(() => {
      console.log('Async operation has ended');
      refresher.complete();
    }, 2000);
  }

  doPulling(refresher) {
    // console.log('DOPULLING', refresher.progress);
  //   console.log('Begin async operation', refresher);
  //   this.getFollowers();
  //  setTimeout(() => {
  //    console.log('Async operation has ended');
  //    refresher.complete();
  //  }, 2000);
  }
  getInvoices() {
    this.service.presentLoadingDefault('Loading...');
    this.service.get('invoices/list?follco_token=' + localStorage.getItem('new_token'),0).subscribe(res =>{
        console.log(res);
        if(res) {
            this.service.dismissLoading();
            this.invoicesList = res['list'];
            // this.time = new Date (this.campaignList[0].created_at);
            // this.time1 =this.time.getDate() + '/' + (this.time.getMonth()+1) + '/' + this.time.getFullYear();
            // console.log(this.time1); 
         
          
        }
    }, err => {
        this.service.dismissLoading();
        console.log(err);
    })
}
invoicestitle(id){
  localStorage.setItem('invoicesID',id);
  this.navCtrl.push(CrmInvoicesViewPage);
}
}
