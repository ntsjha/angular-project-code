import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SupportTopicTranslationComponent } from './support-topic-translation.component';

describe('SupportTopicTranslationComponent', () => {
  let component: SupportTopicTranslationComponent;
  let fixture: ComponentFixture<SupportTopicTranslationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SupportTopicTranslationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SupportTopicTranslationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
