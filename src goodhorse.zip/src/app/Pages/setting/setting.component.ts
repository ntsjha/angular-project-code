import { Component, OnInit } from '@angular/core';
import { ServiceService } from 'src/app/Shared/service.service';
import Swal from 'sweetalert2';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-setting',
  templateUrl: './setting.component.html',
  styleUrls: ['./setting.component.css']
})
export class SettingComponent implements OnInit {
  breed    : any = '';
  color    : any = '';
  service  : any = '';
  brand    : any = '';
  type     : any = '';
  use      : any = '';
  BreedTypeArr    : any = [];
  ColorTypeArr    : any = [];
  serviceTypeArr  : any = [];
  tackTypeArr     : any = [];
  tackBrandArr    : any = [];
  tackUseArr      : any = [];
  dropdown: any=[];
  p: number = 1;
  pageSize = 10;
  total = 0
  constructor(public router: Router,public route: ActivatedRoute,private firebaseServ : ServiceService) { }

  ngOnInit() {
    console.log('Settings_Page_Called')
    // await this.getBreedTypes();
    // await this.getColorTypes();
    // await this.getServiceTypeFunc();
    // await this.getTackTypeList();  
    // await this.getTackBrandList();  
    // await this.getTackUseList();

    this.dropdown=[
    {section:'Physical',   dopdownname:'Breed'},
    {section:'Physical',   dopdownname:'Colour'},
    {section:'Tack',       dopdownname:'Brand'},
    {section:'Tack',       dopdownname:'Type'},
    {section:'Tack',       dopdownname:'Use'},
    {section:'Service',    dopdownname:'Service'},
    {section:'Discipline', dopdownname:'Discipline'},
    {section:'Discipline', dopdownname:'TackUse'},
    {section:'Activity',   dopdownname:'ActivityType'},
    {section:'RugType',    dopdownname:'Temperature'},
    {section:'RugType',    dopdownname:'RugType'},
    {section:'RugType',    dopdownname:'Weather'},
    {section:'RugType',    dopdownname:'When'},
    {section:'Feed',       dopdownname:'FeedType'},
   
  ]
  
  }


  gotoviewSetting(section,dropdown){
    console.log('data',section,dropdown)
      
      this.router.navigate(['/setting/viewsetting/id'],{
        queryParams:{value:dropdown,section:section}})
    
    }

  getBreedTypes(){
    this.firebaseServ.getBreedTypeFunc().then(res => {
      console.log('BreedType_Succ',res)
      this.BreedTypeArr = res[0].BreedType;
    }).catch(err => {
      console.log(err)
    })
  }

  getColorTypes(){
    this.firebaseServ.getColorTypeFunc().then(res => {
      console.log('ColorType_Succ',res)
      this.ColorTypeArr = res[0].ColorType;    
    }).catch(err => {
      console.log(err)
    })
  }

  getTackTypeList(){
    this.firebaseServ.getTackTypeListFunc().then(res => {
      console.log('TackTypes =======>',res)
      this.tackTypeArr = res.TackType;  
    }).catch(err => {
      console.log(err)
    })
  }

  getTackBrandList(){
    this.firebaseServ.getTackBrandListFunc().then(res => {
      console.log('TackBrands =======>',res)
      this.tackBrandArr = res.TackBrand;
    }).catch(err => {
      console.log(err)
    })
  }

  getTackUseList(){
    this.firebaseServ.getTackUseListFunc().then(res => {
      console.log('TackUses =======>',res)
      this.tackUseArr = res.TackUse;      
    }).catch(err => {
      console.log(err)
    })
  }


  getServiceTypeFunc(){
    this.firebaseServ.getServiceTypeFunc().then(res => {
      console.log('SelectServiceType'+JSON.stringify(res))
      this.serviceTypeArr = res[0].ServiceType            
    }).catch(err => {
      console.log(err)
    })
  }



  AddNewBreedFunc(){  
    Swal.fire({
      title: 'Are you sure?',
      text: "You want to add this brand.",
      type: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes'
    }).then((result) => {
      if (result.value) {
            this.firebaseServ.showSpinner();
              if(this.BreedTypeArr.includes(this.breed)){
                console.log('BreeedExists====>',this.BreedTypeArr.includes(this.breed))
              }else{
                console.log('BreeedDontExists====>',this.BreedTypeArr.includes(this.breed))
                  if(this.breed != ''){
                    this.BreedTypeArr.push(this.breed)
                    console.log('NewBreedTypeArr',this.BreedTypeArr)
                    this.updateBreedArrFunc(this.BreedTypeArr)
                  }
              }
      }
    })
  }

  updateBreedArrFunc(newArr){
    this.firebaseServ.addNewBreedFunc(newArr).then(res => {
      console.log('AddBreed_Succ',res)
      this.firebaseServ.hideSpinner();
      Swal.fire(
        'Success!',
        'Your changes are updated successfully.',
        'success'
      )
      this.breed = '';
    }).catch(err => {
      console.log('AddBreed_Err',err)
    })
  }

  AddNewColorFunc(){
    Swal.fire({
      title: 'Are you sure?',
      text: "You want to add this color.",
      type: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes'
    }).then((result) => {
      if (result.value) {
        this.firebaseServ.showSpinner();
        if(this.ColorTypeArr.includes(this.color)){
          console.log('ColourExists====>',this.ColorTypeArr.includes(this.color))
        }else{
          console.log('ColourDontExists====>',this.ColorTypeArr.includes(this.color))
          if(this.color != ''){
            this.ColorTypeArr.push(this.color)
            console.log('NewColorTypeArr',this.ColorTypeArr)
            this.updateColourArrFunc(this.ColorTypeArr)
          }
        }
      }
    })
  }

  updateColourArrFunc(newArr){
    this.firebaseServ.addNewColourFunc(newArr).then(res => {
      console.log('AddColour_Succ',res)
      this.firebaseServ.hideSpinner();
      Swal.fire(
        'Success!',
        'Your changes are updated successfully.',
        'success'
      )
      this.color = '';
    }).catch(err => {
      console.log('AddColour_Err',err)
    })
  }


  AddNewServiceTypeFunction(){
    Swal.fire({
      title: 'Are you sure?',
      text: "You want to add this service.",
      type: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes'
    }).then((result) => {
      if (result.value) {
        this.firebaseServ.showSpinner();
        if(this.serviceTypeArr.includes(this.service)){
          console.log('Present',this.service)    
          var data = [...this.serviceTypeArr];  
        }else{
          var data = [...this.serviceTypeArr];
          data.push(
            this.service
          )
          console.log('NewArr'+JSON.stringify(data))
          console.log('NotPresent',this.service)
          this.updateServiceArrFunc(data)
        } 
      }
    })    
  }

  updateServiceArrFunc(newArr){
    this.firebaseServ.addNewServiceTypeFunc(newArr).then(res => {
      console.log(res)
      this.firebaseServ.hideSpinner();
      Swal.fire(
        'Success!',
        'Your changes are updated successfully.',
        'success'
      )
      this.service = '';
    }).catch(err => {
      console.log(err)
    })
  }

  addnewTackBrandFunc(){
    Swal.fire({
      title: 'Are you sure?',
      text: "You want to add this Brand.",
      type: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes'
    }).then((result) => {
      if (result.value) {
        this.firebaseServ.showSpinner();
          if(this.tackBrandArr.includes(this.brand)){
            console.log('Present',this.brand)    
            var data = [...this.tackBrandArr];  
          }else{
            var data = [...this.tackBrandArr];
            data.push(
              this.brand
            )
            console.log('NewArr'+JSON.stringify(data))
            console.log('NotPresent',this.brand)
            this.updateTackBrandArrFunc(data)
          } 
      }
    })    
  }

  updateTackBrandArrFunc(newArr){
    this.firebaseServ.addNewTackBrandFunc(newArr).then(res => {
      console.log(res)
      this.firebaseServ.hideSpinner();
      Swal.fire(
        'Success!',
        'Your changes are updated successfully.',
        'success'
      )
      this.brand = '';
    }).catch(err => {
      console.log(err)
    })
  }

  addNewTackTypeFunction(){
    Swal.fire({
      title: 'Are you sure?',
      text: "You want to add this type.",
      type: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes'
    }).then((result) => {
      if (result.value) {
        this.firebaseServ.showSpinner();
        if(this.tackTypeArr.includes(this.type)){
          console.log('Present',this.type)    
          var data = [...this.tackTypeArr];  
        }else{
          var data = [...this.tackTypeArr];
          data.push(
            this.type
          )
          console.log('NewArr'+JSON.stringify(data))
          console.log('NotPresent',this.type)
          this.updateTackTypeFunc(data)
        } 
      }
    })
  }

  updateTackTypeFunc(newArr){
    this.firebaseServ.addNewTackTypeFunc(newArr).then(res => {
      console.log(res)
      this.firebaseServ.hideSpinner();
      Swal.fire(
        'Success!',
        'Your changes are updated successfully.',
        'success'
      )
      this.type = '';
    }).catch(err => {
      console.log(err)
    })
  }

  addNewTackUseFunc(){
    Swal.fire({
      title: 'Are you sure?',
      text: "You want to add this use.",
      type: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes'
    }).then((result) => {
      if (result.value) {
        this.firebaseServ.showSpinner();
        if(this.tackUseArr.includes(this.use)){
          console.log('Present',this.use)    
          var data = [...this.tackUseArr];  
        }else{
          var data = [...this.tackUseArr];
          data.push(
            this.use
          )
          console.log('NewArr'+JSON.stringify(data))
          console.log('NotPresent',this.use)
          this.updateTackUseFunc(data)
        } 
      }
    })
  }

  updateTackUseFunc(newArr){
    this.firebaseServ.addNewTackUseFunc(newArr).then(res => {
      console.log(res)
      this.firebaseServ.hideSpinner();
      Swal.fire(
        'Success!',
        'Your changes are updated successfully.',
        'success'
      )
      this.use = '';
    }).catch(err => {
      console.log(err)
    })
  }

  showAlertFunc(){
    Swal.fire({
      title: 'Are you sure?',
      text: "You want to add this brand.",
      type: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes'
    }).then((result) => {
      if (result.value) {
        Swal.fire(
          'Success!',
          'Your changes are updated successfully.',
          'success'
        )
      }
    })
  }

}
