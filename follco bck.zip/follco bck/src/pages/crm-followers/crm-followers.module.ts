import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CrmFollowersPage } from './crm-followers';

@NgModule({
  declarations: [
    CrmFollowersPage,
  ],
  imports: [
    IonicPageModule.forChild(CrmFollowersPage),
  ],
})
export class CrmFollowersPageModule {}
