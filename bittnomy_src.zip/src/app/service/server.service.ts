import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Subject } from 'rxjs';

@Injectable()
export class ServerService {
    private subject = new Subject<any>();
    wsExchange: any;
    twoFAPage = "";
    baseUrl="http://172.16.2.4:8765/";
    // baseUrl="http://172.16.1.114:8765/";
    // websiteURL = "http://mean.mobiloitte.com:1485/";
    // 
    websiteURL = "http://172.16.6.53:4200/";
    liquidityWS: any;
    socketStatus = false;
    activatedSocket: string = 'Poloniex';
    liquidityWSTrade: any;
    liquidityWSDepth: any;
    tradeHisOrderLimit = 50;
    liquidityWSPoloneix: WebSocket;
    liquidityWSHitBTC: any;
    liquidityWSTicker: any = [];
    pair:any;
    
    constructor(private http:HttpClient) {}

    /** Function for call event in child component */
    fireToChild(): Observable<any> {
        return this.subject.asObservable();
    }

    /** method declaration */
    getApi(url,header): Observable<any> {
        let httpOptions;  
        if(header==0){
            httpOptions = {
                headers: new HttpHeaders({
                  'Content-Type': 'application/json',       
                }),
                observe: 'response'
              }
          
        }else if(header==1) {
            httpOptions = {
                observe: 'response'
              }
        }
        else {
            httpOptions = {
                headers: new HttpHeaders({
                  'Content-Type': 'application/json',
                  'Authorization':'Bearer'+' '+header      
                }),
                observe: 'response'
              }
        }
        return this.http.get(this.baseUrl + url,httpOptions);
    }

    /** Function for post method */
    postApi(url, data,header): Observable<any> {
        let httpOptions;  
        if(header==0){
            httpOptions = {
                headers: new HttpHeaders({
                  'Content-Type': 'application/json',       
                }),
                observe: 'response'
              }
        }else if(header==1){
            httpOptions = {
                observe: 'response'
              }
        }
        else {
            httpOptions = {
                headers: new HttpHeaders({
                  'Content-Type': 'application/json',
                  'Authorization':'Bearer'+' '+header      
                }),
                observe: 'response'
              }
          
        }
        return this.http.post(this.baseUrl + url, data,httpOptions);
    }

    /**method declaration for third party */
    thirdpartyGetApi(url):Observable<any> {
        return this.http.get(url)
    }
    /** to get currency pair list */
    getCurrency_PairJson(): Observable<any> {
		return this.http.get(`assets/poloneix.json`)
    }

    /** to get poloniex ticker data */
    getPoloniexTickerDataJson(): Observable<any> {
        return this.http.get(`https://poloniex.com/public?command=returnTicker`);
    }

    /** to get HitBTC ticker data */
    getHitBTCTickerDataJson(): Observable<any> {
        return this.http.get(`https://api.hitbtc.com/api/2/public/ticker`);
    }

    /** Function for socket event */
    initSocket() {
        console.log("Check for connection")
        this.wsExchange = new WebSocket("ws://172.16.2.4:9100/socket");
        var self=this;
        this.wsExchange.addEventListener('open', function (event) {
            self.socketStatus = true;
            console.log('ws connected for exchange');
        });
        this.wsExchange.addEventListener('close', function (event) {
            self.socketStatus = false;
            console.log('ws disconnected for exchange');
            self.reConnectSocket();
        });
    }

    /** Function for socket event */
    thirdPartySocket() {
         /** Socket code For liquidity-Binance*/
        if(this.activatedSocket == "Binance") {
            this.liquidityWS =  new WebSocket("wss://stream.binance.com:9443/ws/" + this.pair + "@miniTicker");
            var self=this;
            /**socket connection for ticker */
            this.liquidityWS.addEventListener('open', function(event) {
                self.socketStatus = true;
                //console.log('ws connected for Binance- ticker liquidity');
                let url = window.location.href.split('/');
                let pageUrl = url[url.length - 3];
                let exchangeUrl = url[url.length - 1];
                if(pageUrl.includes('exchange')) {
                    self.subject.next({ text: 'liquidity'});
                }
                if(exchangeUrl == 'exchange-pair') {
                    self.subject.next({ text: 'liquidity'});
                }
            });
            this.liquidityWS.addEventListener('close' , function(event) {
                self.socketStatus = false;
                //console.log('ws disconnected for  Binance- ticker liquidity');
            })


            /**socket connection for trade */
            this.liquidityWSTrade =  new WebSocket("wss://stream.binance.com:9443/ws/" + this.pair + "@trade");
            this.liquidityWSTrade.addEventListener('open', function(event) {
                self.socketStatus = true;
                //console.log('ws connected for Binance -trade liquidity');
            });
            this.liquidityWSTrade.addEventListener('close' , function(event) {
                self.socketStatus = false;
                //console.log('ws disconnected for Binance-depth liquidity');
            })


            /**socket connection for ask and bid */
            this.liquidityWSDepth =  new WebSocket("wss://stream.binance.com:9443/ws/" + this.pair + "@depth20");
            this.liquidityWSDepth.addEventListener('open', function(event) {
                self.socketStatus = true;
                //console.log('ws connected for Binance-Depth liquidity');
            });
            this.liquidityWSDepth.addEventListener('close' , function(event) {
                self.socketStatus = false;
                //console.log('ws disconnected for Binance-Depth liquidity');
            })
        }

        /**Socket code for Liquidity - Poloniex */
        if(this.activatedSocket == "Poloniex") {
            /** Socket code For liquidity-Poloniex*/
            this.liquidityWSPoloneix =  new WebSocket("wss://api2.poloniex.com");
            var self=this;
            this.liquidityWSPoloneix.addEventListener('open', function(event) {
                self.socketStatus = true;
                let url = window.location.href.split('/');
                let pageUrl = url[url.length - 3];
                let exchangeUrl = url[url.length - 1];
                if(pageUrl.includes('exchange')) {
                    self.subject.next({ text: 'poloniex'});
                }
                if(exchangeUrl == 'exchange-pair') {
                    self.subject.next({ text: 'poloniex'});
                }
            });
            this.liquidityWSPoloneix.addEventListener('close' , function(event) {
                self.socketStatus = false;
                console.log('ws disconnected for poloniex liquidity');
            })
        }

        /** Socket code for Liquidity - HitBTC */
        if(this.activatedSocket == "HitBTC") {
            /** Socket code For liquidity-Poloniex*/
            this.liquidityWSHitBTC =  new WebSocket("wss://api.hitbtc.com/api/2/ws");
            var self=this;
            this.liquidityWSHitBTC.addEventListener('open', function(event) {
                self.socketStatus = true;
                console.log('ws connected for HitBTC liquidity');
                let url = window.location.href.split('/');
                let pageUrl = url[url.length - 3];
                let exchangeUrl = url[url.length - 1];
                if(pageUrl.includes('exchange')) {
                    self.subject.next({ text: 'HitBTC'});
                }
                if(exchangeUrl == 'exchange-pair') {
                    self.subject.next({ text: 'HitBTC'});
                }
            });
            this.liquidityWSHitBTC.addEventListener('close' , function(event) {
                self.socketStatus = false;
                console.log('ws disconnected for HitBTC liquidity.');
            })
        } 
    }

    /** method declaration */
    get(url): Observable<any> {
        return this.http.get(url);
    }

    binanceTickerFunc(pair,ind) {
        if(this.activatedSocket == "Binance") {
            this.liquidityWSTicker[ind] =  new WebSocket("wss://stream.binance.com:9443/ws/" + pair + "@miniTicker");
            var self=this;
            /**socket connection for ticker */
            this.liquidityWSTicker[ind].addEventListener('open', function(event) {
                self.socketStatus = true;
                let url = window.location.href.split('/');
                let pageUrl = url[url.length - 3];
                let exchangeUrl = url[url.length - 1];
                if(pageUrl.includes('exchange')) {
                    self.subject.next({ text: 'liquidity'});
                }
                if(exchangeUrl == 'exchange-pair') {
                    self.subject.next({ text: 'liquidity'});
                }
            });
            this.liquidityWSTicker[ind].addEventListener('close' , function(event) {
                self.socketStatus = false;
            })
        }
    }

    /** Function for reconnect socket */
    reConnectSocket() {
        let val;
        localStorage.getItem("token") ? val = localStorage.getItem("token") : val = "notLoggedIn";
        this.wsExchange = new WebSocket("ws://172.16.2.4:9100/socket");
        var self = this;
        this.wsExchange.addEventListener('open', function (event) {
            self.socketStatus = true;
            console.log('again ws connected for exchange');
        });
    }
}
