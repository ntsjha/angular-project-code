import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FeesFeatureComponent } from './fees-feature.component';

describe('FeesFeatureComponent', () => {
  let component: FeesFeatureComponent;
  let fixture: ComponentFixture<FeesFeatureComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FeesFeatureComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FeesFeatureComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
