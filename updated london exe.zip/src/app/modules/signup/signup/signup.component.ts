import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators,} from '@angular/forms';
import { Router } from '@angular/router';
import { ServerService } from '../../../service/server.service';
import { AppComponent } from '../../../app.component';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
declare var $ : any;
@Component({
    selector: 'app-signup',
    templateUrl: './signup.component.html',
    styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
    signupForm: FormGroup ;
    myCode: any = '';
    countryData: any;
    websiteUrl = this.server.webiteUrl+'terms';

    constructor(private router: Router, private server: ServerService, private appC: AppComponent, private spinnerService: Ng4LoadingSpinnerService, public myService: ServerService) { }

    ngOnInit() {
        $("#phoneNum").intlTelInput({
            autoPlaceholder: true,
            autoFormat: false,
            autoHideDialCode: false,
            initialCountry: 'in',
            nationalMode: false,
            onlyCountries: [],
            preferredCountries: ["us"],
            formatOnInit: true,
            separateDialCode: true
        });
        window.scrollTo(0, 0);
        this.checkInputs();
    }
    
    /** Function to validate form inputs */
    checkInputs() {
        this.signupForm = new FormGroup ({
            semail: new FormControl(this.myService.email, [Validators.required, Validators.pattern(/^[A-Z0-9_]+([\.-][A-Z0-9_]+)*@[A-Z0-9-]+(\.[a-zA-Z]{2,5})+$/i)]),
            password: new FormControl(this.myService.password, [Validators.required, Validators.pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,32})/i)]),
            name: new FormControl(this.myService.name, [Validators.required, Validators.minLength(2), Validators.pattern(/^[a-zA-Z ]*$/i)]),
            agree: new FormControl('', [Validators.required]),
            phone: new FormControl(this.myService.phone, [Validators.required, Validators.pattern(/^[1-9]{1}[0-9]*$/), Validators.minLength(7)]),
            confirmPassword: new FormControl(this.myService.confirmpass, [Validators.required]),
        }, passwordMatchValidator);
        /** Function for password match and mismatch */
        function passwordMatchValidator(g: FormGroup) {
            let pass = g.get('password').value;
            let confPass = g.get('confirmPassword').value;
            if (pass != confPass) {
                g.get('confirmPassword').setErrors({ mismatch: true });
            } else {
                g.get('confirmPassword').setErrors(null)
                return null
            }
        }
    }

    /** to get the value of field  */
    get semail(): any {
        return this.signupForm.get('semail');
    }
    get password(): any {
        return this.signupForm.get('password');
    }
    get confirmPassword(): any {
        return this.signupForm.get('confirmPassword');
    }
    get name(): any {
        return this.signupForm.get('name');
    }
    get phone(): any {
        return this.signupForm.get('phone');
    }
    

    /** for term and privacy  */
    terms() {
        this.myService.email = this.signupForm.value.semail;
        this.myService.password = this.signupForm.value.password;
        this.myService.confirmpass = this.signupForm.value.confirmPassword;
        this.myService.name = this.signupForm.value.name;
        this.myService.phone = this.signupForm.value.phone;
        this.router.navigateByUrl('header/terms')
    }

    /** for signup functionality */
    twofa() {
        this.countryData = $("#phoneNum").intlTelInput("getSelectedCountryData");
        this.myCode = this.countryData.dialCode;
        let signupData = {
           
                    "firstName": this.signupForm.value.name,
                    "lastName": "la",
                    // "phoneCountryCode": this.myCode,
                    "phoneNo":this.myCode+this.signupForm.value.phone,
                    "email": this.signupForm.value.semail,
                    "password": this.signupForm.value.password,
                    "webUrl": this.server.webiteUrl + 'login',
                    "roleStatus": "USER",
                }
           
        this.spinnerService.show();
        this.server.postApi('account/signup', signupData,0).subscribe(response => {
            this.spinnerService.hide();
            if (response.status == 200) {
                this.appC.showSuccToast('User created successfully.')
                localStorage.setItem('email',this.signupForm.value.semail);
                //localStorage.setItem('signupToken',response.transferObjectMap.loginToken);
                this.router.navigateByUrl('header/verify/signup');
            } else {
                this.appC.showErrToast(response.message);
            }
        }, error => {
            this.spinnerService.hide();
            this.appC.showErrToast('Something went wrong');
        });


    }

    login() {
        this.router.navigateByUrl('header/login');
    }
}
