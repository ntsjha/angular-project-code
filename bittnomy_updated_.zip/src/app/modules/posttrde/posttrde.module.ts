import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PosttrdeComponent } from './posttrde/posttrde.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { GooglePlaceModule } from "ngx-google-places-autocomplete";

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        GooglePlaceModule
    ],
    declarations: [PosttrdeComponent]
})
export class PosttrdeModule { }
