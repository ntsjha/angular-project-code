import { Component, OnInit } from '@angular/core';
import { ServiceService } from 'src/app/service/service.service';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-manage-banners',
  templateUrl: './manage-banners.component.html',
  styleUrls: ['./manage-banners.component.css']
})
export class ManageBannersComponent implements OnInit {

  bannerList: any = [];
  englishShortCode: any;

  constructor(
    private service: ServiceService,
    private spinner: NgxSpinnerService
  ) { }

  ngOnInit() {
    window.scrollTo(0, 0);
    this.englishShortCode = this.service.englishLanguageShortCode;
    this.getBannerList();
  }

  getBannerList() {
    this.spinner.show();
    this.service.getMethod('static/admin/get-banner-list', 1).subscribe((success: any) => {
      this.spinner.hide();
      if (success.status === 200) {
        this.bannerList = success.data;
        this.bannerList.forEach(element => {
          if(element.updatedBy == null) {
            element.updatedAt = null;
          }
        });
      } else {
        this.bannerList = [];
      }
    }, error => {
      this.bannerList = [];
    });
  }

}
