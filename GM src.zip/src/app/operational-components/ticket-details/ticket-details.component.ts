import { Component, OnInit } from '@angular/core';
import { ServiceService } from 'src/app/service/service.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
declare var $:any;
// Ip address and location work need to be done
@Component({
  selector: 'app-ticket-details',
  templateUrl: './ticket-details.component.html',
  styleUrls: ['./ticket-details.component.css']
})
export class TicketDetailsComponent implements OnInit {
  ticketObj:any = {};
  changeStatusForm: FormGroup;
  assignOperatorForm: FormGroup;
  disable: boolean=false;
  id:any;
  subTopic: any={};
  ticketTopic: any={};
  type: any;
  
  
  constructor(public server:ServiceService,public router:Router) { 
    this.changeStatusForm = new FormGroup({
      'select_status': new FormControl('',[Validators.required]),
      'remark': new FormControl(''),
    });

    this.assignOperatorForm = new FormGroup({
        'select_operator': new FormControl('',[Validators.required])
    });

 
  }

   get select_status(): any {
    return this.changeStatusForm.get('select_status');
  }
  get remark(): any {
      return this.changeStatusForm.get('remark');
  }

  ngOnInit() {
    this.callByUrl();
    window.scrollTo(0, 0);
  }

  callByUrl() {
    let url= window.location.href;
    let arr= url.split('/');
    this.id = arr[arr.length - 1];
    this.getTicketDetails(this.id);
  }

  getTicketDetails(id) {
    let data = {
      'ticketId':this.server.encrypt(id)
    };
    this.server.postMethod(`support/common-permit/get-support-ticket-details`,data, 1).subscribe((res)=>{
      if(res.data) {
        this.ticketObj = res.data;
        this.subTopic = res.data.subTopic;
        this.ticketTopic = res.data.ticketTopic;
        if(this.ticketObj.file) {
          this.type = this.ticketObj.file.split('.')[1];
          if (this.ticketObj.file.split('/').length > 1) {
            this.ticketObj.file = this.ticketObj.file.split('/')[this.ticketObj.file.split('/').length - 1];
          }
          this.getBase64Func(this.ticketObj.file);
        }
      }
    });
  }

  openModal(type) {
    if(type == 'change_status') {
        this.changeStatusForm.patchValue({
          'select_status': this.ticketObj.status
        });
        $('#myticket1').modal({ backdrop: 'static', keyboard: false });
    }else if(type == 'assign_operator'  )  {
        $('#myticket2').modal({ backdrop: 'static', keyboard: false });
    }
    this.disable = true;
  }

  assignOperator() {
  }

  changeStatus() {
      if(this.changeStatusForm.valid) {
        let data = {
          'status': this.changeStatusForm.value.select_status
        };
        this.server.postMethod(`support/change-support-ticket-status?ipAddress=${this.server.initialUserInfo.ip}&&location=${this.server.initialUserInfo.timezone}`,data,1).subscribe((res)=>{
        });
      }
  }

  navigateChat() {
    this.router.navigate(['ticket-reply',this.id]);
  }

  closeModal() {
    this.disable = false;
    this.resetForm();
  }

  resetForm() {
    this.assignOperatorForm.reset();
    this.changeStatusForm.reset();
  }

  getBase64Func(img) {
    this.ticketObj.file = '';
    if (img) {
      this.server.getMethod('account/convert-image-base64?imageUrl=' + this.server.imageUrl + img, 1).subscribe((res: any) => {
      }, error => {
        if (error.error) {
          this.ticketObj.file = 'data:image/jpg;base64,' + error.error.text;
        }
      });
    }
  }

  clickToDownload() {
    var url = this.ticketObj.file.replace(/^data:image\/[^;]+/, 'data:application/octet-stream');
    window.open(url);
  }


}
