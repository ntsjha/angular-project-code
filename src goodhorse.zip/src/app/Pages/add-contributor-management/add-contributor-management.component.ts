import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { AngularFirestore } from '@angular/fire/firestore';
import { ServiceService } from 'src/app/Shared/service.service';

@Component({
  selector: 'app-add-contributor-management',
  templateUrl: './add-contributor-management.component.html',
  styleUrls: ['./add-contributor-management.component.css']
})
export class AddContributorManagementComponent implements OnInit {
  contributorForm: FormGroup;
  constructor(private router: Router, private afb: AngularFirestore,public globalSer : ServiceService) { }

  ngOnInit() {
    this.contributorForm = new FormGroup({
      userName: new FormControl('', [Validators.pattern("^[a-zA-Z ]{1,41}$"), Validators.required]),
      email: new FormControl('', [Validators.pattern(/^([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,3})$/), Validators.required]),
      password: new FormControl('', [Validators.pattern("^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{8,16}$"), Validators.required]),
      confirmPassword: new FormControl('', [Validators.required]),
    }, passwordMatchValidator);

    function passwordMatchValidator(g: FormGroup) {
      let pass = g.get('password').value;
      let confPass = g.get('confirmPassword').value;
      if (pass != confPass) {
        g.get('confirmPassword').setErrors({ mismatch: true });
      } else {
        g.get('confirmPassword').setErrors(null)
        return null
      }
    }
  }



   doRegisterFunc(){
     let data = {
      email     :   this.contributorForm.value.email,
      password  :   this.contributorForm.value.password
     }
     this.globalSer.showSpinner();
     this.globalSer.doRegister(data).then(res => {
      console.log('ContributorRegistration =>',res)
      if(res.user.uid){
        this.globalSer.hideSpinner();
        this.AddUsersInfo(res.user.uid);
      }
     }).catch(err => {
       this.globalSer.hideSpinner();
       console.log('ContributorRegistration_Err =>',err)
       this.globalSer.toastErr(err.message)
     })

   }


  AddUsersInfo(userID){
    console.log('LookUID ==>',userID)
    this.globalSer.showSpinner();
    return new Promise<any>((resolve, reject) => {      
      this.afb.collection('people').doc(userID).set({
        userName  : this.contributorForm.value.userName,
        Mobile    : '',
        email     : this.contributorForm.value.email,
        WarmDown  : '',
        userImage : '',
        type      : 'Contributor'
      })
      .then(res =>{
        this.globalSer.showSuccess('Contributor has been added successfully.');
        console.log("res--->",JSON.stringify(res));        
        this.contributorForm.reset();
        this.globalSer.hideSpinner();
        this.router.navigate(['/contributorManagement'])
      }      
      ).catch(err => {
        this.globalSer.hideSpinner();
        console.log("error-->>",JSON.stringify(err));
      })
    })
  }
  preventSpace(event){
    if(event.charCode==32 && !event.target.value){
    event.preventDefault()
    } else{
    console.log(event)
    }
    console.log('event',event.charCode)
    }


}
