import { ActivatedRoute } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { ServiceService } from 'src/app/service/service.service';

@Component({
  selector: 'app-translate-banners',
  templateUrl: './translate-banners.component.html',
  styleUrls: ['./translate-banners.component.css']
})
export class TranslateBannersComponent implements OnInit {

  paramData: any;
  bannerList: any = [];
  languageArr: any = [];

  constructor(
    private activatedRoute: ActivatedRoute,
    private service: ServiceService
  ) { }

  ngOnInit() {
    window.scrollTo(0, 0);
    this.getParamData();
  }

  getParamData() {
    this.activatedRoute.params.subscribe(success => {
      this.paramData = success;
      this.getBannerData();
    });
  }

  getBannerData() {
    this.service.getMethod(`static/admin/get-banner-translation?bannerId=${encodeURIComponent(this.service.encrypt(this.paramData.id))}`, 1).subscribe((success: any) => {
      if (success.status === 200) {
        this.bannerList = success.data.translationList;
        this.bannerList.forEach(element => {
          if(element.updatedBy == null) {
            element.updatedAt = null;
          }
        });
        this.languageArr = success.data.languageList.data;
      } else {
        this.bannerList = [];
      }
    }, error => {
      this.bannerList = [];
    });
  }

  getLanguage(data) {
    let lang;
    this.languageArr.forEach((element, i) => {
      if (data.fkLanguageId === element.languageId) {
        lang = element.languageShortName;
      }
    });
    return lang;
  }
}
