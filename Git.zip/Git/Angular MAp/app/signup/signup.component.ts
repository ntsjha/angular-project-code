import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { google } from '@agm/core/services/google-maps-types';

import {Http, Response } from '@angular/http';
import { Observable } from 'rxjs';
import { format } from 'util';
import { Address } from 'ngx-google-places-autocomplete/objects/address';
import { ServeService } from '../serve.service';

//import 'rxjs/add/operator/map';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css'],
  providers: []
})
export class SignupComponent implements OnInit {
  
  key = 1;
  submitted = false;
  signup: FormGroup;
  address: any;
  dataArray= [];
  firstname: any;
  lastname: any;
  email: any;
  mobile: any;
  password: any;
  gender: any;
  
  autocompleteInput: string;
  objData: { firstname: any; objemail: any; objmobile: any; objpassword: any; objaddress: any; objgender: any; teacherlatlng:{ 'lat': any; 'lng': any; }};
  teacherlatlng: { 'lat': any; 'lng': any; };
  
  constructor(private router: Router, public serve: ServeService, http :Http ) { }
     ngOnInit() {
     
  this.signup = new FormGroup({
    fullName: new FormControl('',[Validators.required,Validators.minLength(2),Validators.maxLength(20)] ),
    email: new FormControl('',[Validators.required,Validators.pattern(/^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/)]), 
    password: new FormControl('',[Validators.required,
     Validators.pattern("^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$")] ),
    number: new FormControl('',[Validators.required,Validators.pattern(/^\+?\d{2}[- ]?\d{3}[- ]?\d{5}$/)] ),
    address: new FormControl('',[Validators.required,Validators.minLength(1),] ),
    gender: new FormControl('',[Validators.required]),

    

  });
}
get f() { return this.signup.controls; }


handle(address: Address)
{
this.address=address.formatted_address;
this.teacherlatlng={
  'lat': address.geometry.location.lat(),
  'lng': address.geometry.location.lng(),
}

}
  onSubmit() {
    // console.log(this.address);
    // console.log(this.teacherlatlng)
        
    this.submitted = true;
   
    this.signup.value.address;
    this.firstname =this.signup.value.fullName;
    this.email=this.signup.value.email;
    this.mobile=this.signup.value.number;
    this.password=this.signup.value.password;
  
    this.gender=this.signup.value.gender;
    this.objData = {firstname:this.firstname,objemail:this.email,objmobile:this.mobile,
    objpassword:this.password,objaddress:this.address,objgender:this.gender,teacherlatlng:this.teacherlatlng}
    this.dataArray.push( this.objData);
    
    localStorage.setItem('teacher', JSON.stringify( this.dataArray));    
    // sessionStorage.setItem('token', JSON.stringify(this.objData));
   
   // this.router.navigate(['/address']); 
   
   this.serve.teacher=(this.dataArray);
    
    

    
  }

  onreset() {
    this.signup.patchValue({
      email:"n@nn.com",
      number:"2323232323",
      fullName: 'Nitesh Jha',
      password: 'asAS!@12',
      address: 'Delhi',
      gender:'male'

    
    })
  
  }
}








  


