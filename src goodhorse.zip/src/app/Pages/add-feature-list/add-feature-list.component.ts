import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AngularFirestore, AngularFirestoreModule } from '@angular/fire/firestore';
import { ServiceService } from 'src/app/Shared/service.service';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { Upload } from 'src/app/Shared/common-class';
import { formatDate } from '@angular/common';
@Component({
  selector: 'app-add-feature-list',
  templateUrl: './add-feature-list.component.html',
  styleUrls: ['./add-feature-list.component.css']
})
export class AddFeatureListComponent implements OnInit {

  addfeatureForm: FormGroup;
  fileName1: any = '';


  selectedFiles: FileList;
  currentUpload: Upload;
  ref: any;
  task: any;
  uploadProgress: any;
  downloadURL: any;
  userProfileImg: any;
  randomId: string;
  image: any;
  constructor(private afStorage: AngularFirestoreModule, private router: Router, private afb: AngularFirestore, public firebaseServ: ServiceService) { }

  ngOnInit() {

    this.addfeatureForm = new FormGroup({
      title: new FormControl('', [Validators.required, Validators.pattern(/^[a-z\d\-_\s]+$/i)]),
      description: new FormControl('', [Validators.required, Validators.pattern(/^[a-z\d\-$=%();:_?@.'",*&?\s]+$/i)]),
      image: new FormControl('', [Validators.required]),

    })


  }



  /**Function To Validated Image */
  handleFileInputFront(event) {

    var self = this;
    if (event.target.files && event.target.files[0]) {
      var type = event.target.files[0].type;
      var size = event.target.files[0].size;
      let count = 0;
      if (size < 5000000) {
        if (type === 'image/png' || type === 'image/jpg') {
          this.fileName1 = event.target.files[0];
          this.addfeatureForm.patchValue({
            image: this.fileName1.name
          })
          console.log('image', this.addfeatureForm.value)
          count++;
        } else if (type === 'image/jpeg') {
          this.fileName1 = event.target.files[0];
          this.addfeatureForm.patchValue({
            image: this.fileName1.name
          })
          console.log('image', this.addfeatureForm.value)
          count++;
        } else {
          this.firebaseServ.toastErr('Select only  jpg, jpeg and png file.')

        }
      } else {
        this.firebaseServ.toastErr('Image size should be less than 5 MB.')


      }
      console.log('File', this.fileName1)
    }
  }



  // Uploading Images Functionality
  onUpload(evt: any) {
    const file = this.fileName1
    if (file) {
      const reader = new FileReader();
      reader.onload = this.handleReaderLoadedCustom.bind(this);
      reader.readAsBinaryString(file);
    }
  }

  handleReaderLoadedCustom(e) {
    this.uploadImageToFirebase('data:image/png;base64,' + btoa(e.target.result))
  }
  uploadImageToFirebase(image) {

    this.firebaseServ.showSpinner()

    let randomId = Math.random().toString(36).substr(2, 5);

    this.firebaseServ.uploadImage(image, randomId)
      .then(photoURL => {

        this.image = photoURL;
        this.firebaseServ.hideSpinner()
        console.log('URL', this.image)
        var time = formatDate(new Date(), 'yyyy/MM/dd h:mm:ss', 'en');


        let data = {
          Title: this.addfeatureForm.value.title,
          Description: this.addfeatureForm.value.description,
          Image: this.image,
          LastUpdate: time,
        }
        console.log('INFO==>', data)
        this.afb.collection('FeatureListing').add(data);
        this.firebaseServ.showSuccess('Feature has been added successfully.');
        this.firebaseServ.hideSpinner();
        this.addfeatureForm.reset();
        this.router.navigate(['/feature-list']);
        // this.firebaseServ.showSuccess('Image upload successfully.')
        //  this.createImageArr(this.image);
      }).catch(err => {
        console.log(err)
        this.firebaseServ.hideSpinner()
      })

  }


  numberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;

  }
  preventSpace(event) {
    if (event.charCode == 32 && !event.target.value) {
      event.preventDefault()
    } else {
      // console.log(event)
    }
    // console.log('event',event.charCode)
  }




}


