import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CrmCutomersPage } from './crm-cutomers';

@NgModule({
  declarations: [
    CrmCutomersPage,
  ],
  imports: [
    IonicPageModule.forChild(CrmCutomersPage),
  ],
})
export class CrmCutomersPageModule {}
