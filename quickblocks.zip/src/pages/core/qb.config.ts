export const qbEndpoints = {
    'api_endpoint': 'https://api.quickblox.com',
    'chat_endpoint': 'chat.quickblox.com',
    'turnserver_endpoint': 'turnserver.quickblox.com'
};

export const qbAccount = {
    appId: 76532,
    authKey: 'skK3B8abZtZsAy4',
    authSecret: 'OJdytYVmnvKrut5'
};
