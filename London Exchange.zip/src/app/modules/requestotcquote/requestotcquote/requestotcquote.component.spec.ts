import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RequestotcquoteComponent } from './requestotcquote.component';

describe('RequestotcquoteComponent', () => {
  let component: RequestotcquoteComponent;
  let fixture: ComponentFixture<RequestotcquoteComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RequestotcquoteComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RequestotcquoteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
