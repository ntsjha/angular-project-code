import { Component, OnInit } from '@angular/core';
import { ServerService } from '../../../server.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';

@Component({
    selector: 'app-privacypolicy',
    templateUrl: './privacypolicy.component.html',
    styleUrls: ['./privacypolicy.component.css']
})
export class PrivacypolicyComponent implements OnInit {

    pageData: any = [];

    constructor(private server : ServerService, private spinnerService: Ng4LoadingSpinnerService) { }

    ngOnInit() {
        window.scrollTo(0,0);
        this.getPageData();
    }

    getPageData() {
        this.spinnerService.show();
        this.server.getApi('static/static-content/PrivacyPolicy').subscribe((succ) => {
            this.spinnerService.hide();
            this.pageData = succ.data.pageData;
        },err =>{
            this.spinnerService.hide();
            this.pageData = 'No Data Found.' ;
        });
    }

}
