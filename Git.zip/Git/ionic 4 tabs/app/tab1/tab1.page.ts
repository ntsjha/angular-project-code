import { Component } from '@angular/core';
import {Validators, FormBuilder, FormGroup , FormControl} from '@angular/forms';
import { Router } from '@angular/router';
import { NavController, AlertController } from '@ionic/angular';
@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss']
})
export class Tab1Page {


  submitted = false;
  
  loginForm = new FormGroup({
    email: new FormControl ('', [Validators.required,Validators.pattern(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/)]),
      password: new FormControl ('', [Validators.required,Validators.maxLength(16),
        Validators.pattern("^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$")])
  });
  

  constructor(public router: Router, public formBuilder: FormBuilder, private nav: NavController,public alertController: AlertController,
    ) {

    
  }
  get f() { return this.loginForm.controls; }

  async onSignIn() {
    this.submitted = true; 
      console.log(this.loginForm.value);
      console.log(this.f.email.value);


      const alert = await this.alertController.create({
        header: 'Sucessfully Login',
        message: 'Welcome  <b>'+this.f.email.value,
        buttons: ['OK']
      });
      await alert.present();
      this.router.navigate(['/home']);
  }
}
