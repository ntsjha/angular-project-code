import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ServiceService } from 'src/app/service/service.service';

@Component({
    selector: 'app-settingall',
    templateUrl: './settingall.component.html',
    styleUrls: ['./settingall.component.css']
})
export class SettingallComponent implements OnInit {

    constructor(private route: Router, private service: ServiceService) { }

    ngOnInit() {
        window.scrollTo(0,0);
    }

    goToTransaction(data, routing) {
        if (this.service.sideMenuArr.includes(data)) {
            this.route.navigate([routing]);
        }
    }

}
