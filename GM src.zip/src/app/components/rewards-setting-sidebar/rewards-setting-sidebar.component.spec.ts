import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RewardsSettingSidebarComponent } from './rewards-setting-sidebar.component';

describe('RewardsSettingSidebarComponent', () => {
  let component: RewardsSettingSidebarComponent;
  let fixture: ComponentFixture<RewardsSettingSidebarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RewardsSettingSidebarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RewardsSettingSidebarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
