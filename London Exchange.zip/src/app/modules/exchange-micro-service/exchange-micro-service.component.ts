import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-exchange-micro-service',
  templateUrl: './exchange-micro-service.component.html',
  styleUrls: ['./exchange-micro-service.component.css']
})
export class ExchangeMicroServiceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
