import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditNotificationTranslationComponent } from './edit-notification-translation.component';

describe('EditNotificationTranslationComponent', () => {
  let component: EditNotificationTranslationComponent;
  let fixture: ComponentFixture<EditNotificationTranslationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditNotificationTranslationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditNotificationTranslationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
