import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppComponent } from '../../../app.component';
import { ServerService } from '../../../service/server.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { HeaderComponent } from '../../header/header/header.component';
declare var google: any;

@Component({
    selector: 'app-posttrde',
    templateUrl: './posttrde.component.html',
    styleUrls: ['./posttrde.component.css']
})
export class PosttrdeComponent implements OnInit {
    tradeObj = {tradeType:"", coin:"", location:"", country:"", payment_method:"", currency:"", trade_price:"", min_limit:"", max_limit:"", trade_terms:""};
    coinListArr = [];
    fiatCurrencyArr = [];
    paymentArr = [{name:"Cash",value:"cash"},{name:"Bank",value:"bank"},{name:"PayPal",value:"paypal"}];
    regexForEightChar = (/^(\d+)?([.]?\d{0,8})?$/);

    constructor(private router: Router, private appC: AppComponent, private server: ServerService, private loader: Ng4LoadingSpinnerService, public header: HeaderComponent) { }

    ngOnInit() {
        window.scrollTo(0, 0);
        this.tradeObj.payment_method = this.paymentArr[0].value;
        this.getCoinList();
    }

    /** Function to get coin list from api */
    getCoinList() {
        let data = {
            "eventExternal": {
                "name":"request_get_coin_list",
                "key":"mykey"
            },
            "transferObjectMap": {     
            }
        }
        this.loader.show();
        this.server.postApi("",data,0).subscribe((succ) => {
            this.loader.hide();
            if(succ.transferObjectMap.statusCode == 200) {
                let data = succ.transferObjectMap.coinList;
                this.coinListArr = data.filter((x) => x.coinType=="crypto");
                this.fiatCurrencyArr = data.filter((x) => x.coinType=="fiat");
                if(this.coinListArr.length) {
                    this.tradeObj.coin = this.coinListArr[0].coinId;
                }
                if(this.fiatCurrencyArr.length) {
                    this.tradeObj.currency = this.fiatCurrencyArr[0].coinId;
                }
            } else {
            }
        }, (err) => {
            this.loader.hide();
        });
    }

    /** Function to mansge location change */
    handleAddressChange(e) {
        this.tradeObj.location = e.formatted_address;
        this.getCountryFromAddress(e.formatted_address);
    }

    /** Function to get country from address */
    getCountryFromAddress(address) {
        var geocoder = new google.maps.Geocoder();
        var country;
        var self = this;
        geocoder.geocode({
            "address": address
        },function(results){
            //find country name
            for (var i=0; i < results[0].address_components.length; i++) {
                for (var j=0; j < results[0].address_components[i].types.length; j++) {
                    if (results[0].address_components[i].types[j] == "country") {
                        country = results[0].address_components[i];
                        self.tradeObj.country = country.short_name;
                    }
                }
            }
        });
    }

    /** Function to clear location when edit on location */
    clearLocation() {
        this.tradeObj.location = "";
        this.tradeObj.country = "";
    }

    /** Function to restrict space */
    restrictSpace(event) {
        var k = event.charCode;
        if (k === 32) return false;
    }

    /** Function to restrict character */
    restrictChar(event) {
        var k = event.charCode;
        if (event.key === 'Backspace')
            k = 8;
        if (k >= 48 && k <= 57 || k == 8 || k == 46)
            return true;
        else
            return false;    
    }

    /** Function to restrict length after dot */
    restrictLength(type) {
        switch(type) {
            case 'price':
                if(this.tradeObj.trade_price.includes(".")) {
                    if (!this.regexForEightChar.test(this.tradeObj.trade_price)) {
                        let tempVal = this.tradeObj.trade_price.split('.');
                        this.tradeObj.trade_price = tempVal[0] + '.' + tempVal[1].slice(0, 8);
                    }
                }
                break;
            case 'min':
                if(this.tradeObj.min_limit.includes(".")) {
                    if (!this.regexForEightChar.test(this.tradeObj.min_limit)) {
                        let tempVal = this.tradeObj.min_limit.split('.');
                        this.tradeObj.min_limit = tempVal[0] + '.' + tempVal[1].slice(0, 8);
                    }
                }
                break;
            case 'max':
                if(this.tradeObj.max_limit.includes(".")) {
                    if (!this.regexForEightChar.test(this.tradeObj.max_limit)) {
                        let tempVal = this.tradeObj.max_limit.split('.');
                        this.tradeObj.max_limit = tempVal[0] + '.' + tempVal[1].slice(0, 8);
                    }
                }
                break;
        }
    }

    /** Function for publish advertiesment function */
    publishAdFunc() {
        if(this.tradeObj.tradeType == "") {
            this.appC.showErrToast("Select trade type.");
            return;
        } else if(this.tradeObj.location == "") {
            this.appC.showErrToast("Enter your location.");
            return;
        } else if(this.tradeObj.trade_price == "") {
            this.appC.showErrToast("Enter trade price.");
            return;
        } else if(Number(this.tradeObj.trade_price) == 0) {
            this.appC.showErrToast("Price should not be zero.");
            return;
        } else if(this.tradeObj.min_limit == "") {
            this.appC.showErrToast("Enter minimum limit for transaction.");
            return;
        } else if(Number(this.tradeObj.min_limit) == 0) {
            this.appC.showErrToast("Minimum limit should not be zero.");
            return;
        } else if(this.tradeObj.max_limit == "") {
            this.appC.showErrToast("Enter maximum limit for transaction.");
            return;
        } else if(Number(this.tradeObj.max_limit) == 0) {
            this.appC.showErrToast("Maximum limit should not be zero.");
            return;
        } else if(Number(this.tradeObj.min_limit) >= Number(this.tradeObj.max_limit)) {
            this.appC.showErrToast("Maximum transaction limit should be greater than minimum transaction limit.");
            return;
        } else {
            let data = {
                "eventExternal": {
                    "name": "",
                    "key": "mykey"
                },
                "transferObjectMap": {
                    "tradingType": "OTC",
                    "orderType": "", 
                    "price": this.tradeObj.trade_price,
                    "baseCurrency": this.tradeObj.coin,
                    "executableCurrency" : this.tradeObj.currency, 
                    "tradeStop": this.tradeObj.min_limit,
                    "tradeLimit": this.tradeObj.max_limit,
                    "loginToken": localStorage.getItem("token"),
                    "location": this.tradeObj.location,
                    "paymentMethod": this.tradeObj.payment_method,
                    "terms": this.tradeObj.trade_terms
                }
            }
            if(this.tradeObj.tradeType == "BUY") {
                data.eventExternal.name = "request_buy_add_order";
                data.transferObjectMap.orderType = "BUY";
            } else {
                data.eventExternal.name = "request_sell_add_order";
                data.transferObjectMap.orderType = "SELL";
            }
            /*this.loader.show();
            this.server.postApi("",data).subscribe((succ) => {
                this.loader.hide();
                if(succ.transferObjectMap.statusCode == 200) {
                    this.appC.showSuccToast("Advertiesment posted successfully.");
                    this.router.navigateByUrl('dashboard');
                } else if(succ.transferObjectMap.statusCode == 403) {
                    this.header.logOut();
                } else {
                    this.appC.showErrToast(succ.transferObjectMap.message);
                }
            }, (err) => {
                this.loader.hide();
                console.log("err -> "+JSON.stringify(err));
            });*/ 
        }
    }
}   
