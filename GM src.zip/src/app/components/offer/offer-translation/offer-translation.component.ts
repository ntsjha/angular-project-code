import { ServiceService } from 'src/app/service/service.service';
import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { IMyDpOptions } from 'mydatepicker';
import { ActivatedRoute, Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'app-offer-translation',
  templateUrl: './offer-translation.component.html',
  styleUrls: ['./offer-translation.component.css']
})
export class OfferTranslationComponent implements OnInit {

  editofferForm: FormGroup;
  apiResponse: any = { status: 1372 };
  fileData: any = {};
  fileName: any;
  public fromPickerOptions: IMyDpOptions = {
    disableUntil: { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() - 1 },
    dateFormat: 'dd/mm/yyyy',
  };
  englishShortCode: any;
  public toPickerOptions: IMyDpOptions = {
    disableUntil: { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() - 1 },
    dateFormat: 'dd/mm/yyyy',
  };
  fileUrl: any = null;
  paramData: any;
  invalidfileUrl: any = true;
  showResult: any = false;
  formType : string;
  responseObj: any;
  userIp: any;

  constructor(
    private service: ServiceService,
    private fb: FormBuilder,
    private spinner: NgxSpinnerService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private cookie: CookieService
  ) { }

  ngOnInit() {
    this.form();
    this.getParamData();
    window.scrollTo(0, 0);
    this.userIp = (this.cookie.get('userInfo')) ? JSON.parse(this.cookie.get('userInfo')) : this.service.initialUserInfo;
  }

  form() {
    this.editofferForm = this.fb.group({
      offerType: ['', [Validators.required]],
      offerName: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(255)]],
      offerStartDate: ['', [Validators.required]],
      offerEndDate: ['', [Validators.required]],
      thbperPoint: ['', [ Validators.pattern(/^[0-9]*$/), Validators.minLength(1), Validators.maxLength(255)]],
      maxPoint: ['', [ Validators.pattern(/^[0-9]*$/), Validators.minLength(1), Validators.maxLength(255)]],
      totalRedeem: ['', [Validators.pattern(/^[0-9]*$/), Validators.minLength(1), Validators.maxLength(255)]],
      numberOfPoints: ['', [Validators.pattern(/^[0-9]*$/), Validators.minLength(1), Validators.maxLength(255)]],
    });
  }

  getParamData() {
    this.activatedRoute.params.subscribe(param => {
      this.paramData = param;
      console.log('Param Data', this.paramData);
      this.getOfferdata();
    });    
  }

  getOfferdata() {
    this.service.getMethod(`rewards/get-offer-details-data?translationContentId=${encodeURIComponent(this.service.encrypt(this.paramData.translationId))}`, 1).subscribe((success: any) => {
      if (success.status === 1381) {
        this.responseObj = success.data
        this.editofferForm.patchValue({
          offerType: success.data.offerType ? success.data.offerType.typeOfOffer : null,
          offerName: success.data.offerName,
        });
        if(success.data.offerType.typeOfOffer === 'COUPON') {
          this.editofferForm.patchValue({
            totalRedeem: success.data.maxNumberOfCouponRedeemable,
            numberOfPoints: success.data.pointValue,
          });
        } else {
          this.editofferForm.patchValue({
            thbperPoint: success.data.thbPerPointValue,
            maxPoint: success.data.maxPointRedeemable,
          });
        }
        this.formType = success.data.offerType.typeOfOffer;
        if (success.data.offerStartdate) {
          this.editofferForm.patchValue({
            offerStartDate: {
              date: {
                year: new Date(success.data.offerStartdate).getFullYear(),
                month: new Date(success.data.offerStartdate).getMonth() + 1,
                day: new Date(success.data.offerStartdate).getDate()
              },
              epoc: (new Date(success.data.offerStartdate).getTime() / 1000)
            }
          });
        }
        if (success.data.offerEnddate) {
          this.editofferForm.patchValue({
            offerEndDate: {
              date: {
                year: new Date(success.data.offerEnddate).getFullYear(),
                month: new Date(success.data.offerEnddate).getMonth() + 1,
                day: new Date(success.data.offerEnddate).getDate()
              },
              epoc: (new Date(success.data.offerEnddate).getTime() / 1000)
            }
          });
        }
        this.editofferForm.get('offerType').disable();
        this.editofferForm.get('offerStartDate').disable();
        this.editofferForm.get('offerEndDate').disable();
        this.editofferForm.get('thbperPoint').disable();
        this.editofferForm.get('maxPoint').disable();
        this.editofferForm.get('totalRedeem').disable();
        this.editofferForm.get('numberOfPoints').disable();
        this.fileUrl = success.data.offerImage;
        this.fileName = success.data.offerImage;
        if (success.data.offerImage) {
          this.fileData.valid = true;
          this.invalidfileUrl = false;
        } else {
          this.fileData.valid = false;
          this.invalidfileUrl = true;
        }
      }
    }, error => {
    });
  }

  fromDateChanged(event) {
    if (event.epoc) {
      this.toPickerOptions = {
        disableUntil: { year: new Date(event.epoc * 1000).getFullYear(), month: new Date(event.epoc * 1000).getMonth() + 1, day: new Date(event.epoc * 1000).getDate() - 1 }
      };
    } else {
      this.toPickerOptions = {
        disableUntil: { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() - 1 }
      };
    }
  }

  toDateChanged(event) {
    if (event.epoc) {
      this.fromPickerOptions = {
        disableSince: { year: new Date(event.epoc * 1000).getFullYear(), month: new Date(event.epoc * 1000).getMonth() + 1, day: new Date(event.epoc * 1000).getDate() + 1 }
      };
    } else {
      this.fromPickerOptions = {
        disableSince: { year: 0, month: 0, day: 0 },
      };
    }
  }

  getFile(event) {
    this.fileData = this.service.uploadImage(event);
    this.fileName = this.fileData.fileData.name;
    if (this.fileData.error === 'formatError') {
      this.fileData.error = 'Image accept only jpg, jpeg, png format.';
    } else {
      if (this.fileData.error === 'sizeError') {
        this.fileData.error = 'Image size should be less than 5Mb.';
      }
    }
    if (!this.fileData.valid) {
      return;
    }
    this.uploadImage();
  }

  uploadImage() {
    const formData = new FormData();
    formData.append('file', this.fileData.fileData);
    this.service.postMethod('account/uploadFile', formData, 2).subscribe(success => {
      if (success.fileName) {
        this.fileUrl = success.fileName;
        this.invalidfileUrl = false;
      } else {
        this.invalidfileUrl = true;
      }
    }, error => {
      this.invalidfileUrl = true;
    });
  }

  editOffer() {
    this.spinner.show();
    if (this.editofferForm.invalid) {
      this.spinner.hide();
      return;
    }
    if (this.invalidfileUrl) {
      this.spinner.hide();
      return;
    }
    const apireq = {
      languageName: this.service.encrypt(this.paramData.lang),
      offerType: this.responseObj.offerType.typeOfOffer,
      offerName: this.editofferForm.value.offerName,
      offerStartdate: this.responseObj.offerStartdate,
      offerEndDate: this.responseObj.offerEnddate,
      offerImage: this.fileUrl,
      thbPerPointValue: this.responseObj.thbPerPointValue,
      maxPoint: this.responseObj.maxPointRedeemable,
      maxNumberOfCouponRedeemable: this.responseObj.maxNumberOfCouponRedeemable,
      pointValue: this.responseObj.pointValue,
      offerrId: this.paramData.translationId,
      ipAddress: this.userIp.ip,
      location: this.userIp.city + ',' + this.userIp.country_name,
    };
    this.service.postMethod('rewards/marketing/update-offer', apireq, 1).subscribe(success => {
      this.spinner.hide();
      this.apiResponse = success;
      this.showResult = true;
      this.router.navigate(['/offer-translationList',this.paramData.id]);
    }, error => {
      this.showResult = true;
      if (error) {
        this.spinner.hide();
        if (error.error) {
          this.apiResponse.status = error.error.status;
          this.apiResponse.message = error.error.error;
        } else {
          this.apiResponse.status = 500;
          this.apiResponse.message = 'Something went wrong';
        }
      } else {
        this.apiResponse.status = 500;
        this.apiResponse.message = 'Something went wrong';
      }
    });
  }

}
