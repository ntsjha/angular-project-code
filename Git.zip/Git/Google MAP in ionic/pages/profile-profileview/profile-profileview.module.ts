import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ProfileProfileviewPage } from './profile-profileview';

@NgModule({
  declarations: [
    ProfileProfileviewPage,
  ],
  imports: [
    IonicPageModule.forChild(ProfileProfileviewPage),
  ],
})
export class ProfileProfileviewPageModule {}
