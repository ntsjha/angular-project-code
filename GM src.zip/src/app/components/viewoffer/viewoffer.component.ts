import { Component, OnInit } from '@angular/core';
import { ServiceService } from 'src/app/service/service.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { ActivatedRoute } from '@angular/router';

@Component({
    selector: 'app-viewoffer',
    templateUrl: './viewoffer.component.html',
    styleUrls: ['./viewoffer.component.css']
})
export class ViewofferComponent implements OnInit {

    rewardData: any;

    constructor(
        private service: ServiceService,
        private spinner: NgxSpinnerService,
        private activatedRoute: ActivatedRoute
    ) {
        this.activatedRoute.params.subscribe((id) => {
            this.getMaintenanceData(id.id);
        });
    }

    ngOnInit() {
    }

    /** Function to get maintenance data */
    getMaintenanceData(id) {
        this.spinner.show();
        this.service.getMethod('rewards/common-permit/get-offer-details?offerId=' + id, 1).subscribe((response: any) => {
            this.spinner.hide();
            if(response.status == 1377) {
                this.rewardData = response.data;
                if(this.rewardData.offerImage) {
                    this.getBase64Func(this.rewardData.offerImage)
                }
            }
        }, (error) => {
            this.spinner.hide();
        });
    }

    getBase64Func(img) {
        this.rewardData.offerImage = '';
        if (img) {
          this.service.getMethod('account/convert-image-base64?imageUrl=' + this.service.imageUrl + img, 1).subscribe((res: any) => {
            this.spinner.hide();
          }, error => {
            if (error.error) {
              this.rewardData.offerImage = 'data:image/jpg;base64,' + error.error.text;
            }
          });
        }
      }

}
