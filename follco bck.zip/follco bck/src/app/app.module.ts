import { NgModule, ErrorHandler } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { IonicApp, IonicModule, IonicErrorHandler, LoadingController } from 'ionic-angular';
import { MyApp } from './app.component';
import { Camera, CameraOptions } from '@ionic-native/camera';
import { AboutPage } from '../pages/about/about';
import { ContactPage } from '../pages/contact/contact';
import { HomePage } from '../pages/home/home';
import { TabsPage } from '../pages/tabs/tabs';
import { Network } from '@ionic-native/network';

import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { LoginPage } from '../pages/login/login';
import { ForgotPage } from '../pages/forgot/forgot';
import { SignupPage } from '../pages/signup/signup';
import { PrivacyPage } from '../pages/privacy/privacy';
import { RestProvider } from '../providers/rest/rest';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { SpinnerDialog } from '@ionic-native/spinner-dialog/ngx';
import { Toast } from '@ionic-native/toast/ngx';
import { ChangepassPage } from '../pages/changepass/changepass';
import { ProfileonePage } from '../pages/profileone/profileone';
import { CustomerprofilePage } from '../pages/customerprofile/customerprofile';
import { SettingPage } from '../pages/setting 3/setting';
import { EmailCampaingsPage } from '../pages/email-campaings/email-campaings';
import { ViewEmailCampaingPage } from '../pages/view-email-campaing/view-email-campaing';
import { SmsCampaignPage } from '../pages/sms-campaign/sms-campaign';
import { SmsCampaignListPage } from '../pages/sms-campaign-list/sms-campaign-list';
import { DashboardPage } from '../pages/dashboard/dashboard';
import { FollowingPage } from '../pages/following/following';
import { FollowingproPage } from '../pages/followingpro/followingpro';
import { BusinessHomePage } from '../pages/business-home/business-home';
import { TimelinePostViewPage } from '../pages/timeline-post-view/timeline-post-view';
import { TimelinePostPage } from '../pages/timeline-post/timeline-post';
import { TabsScreensPage } from '../pages/tabs-screens/tabs-screens';
import { DiscoverMapPage } from '../pages/discover-map/discover-map';
import { PipesModule } from '../pipes/pipes.module';
import { CrmCutomersPage } from '../pages/crm-cutomers/crm-cutomers';
import { CrmFollowersPage } from '../pages/crm-followers/crm-followers';
import { CrmInvoicesPage } from '../pages/crm-invoices/crm-invoices';
import { CrmLeadsPage } from '../pages/crm-leads/crm-leads';
import { CrmProductsPage } from '../pages/crm-products/crm-products';
import { CrmInvoicesViewPage } from '../pages/crm-invoices-view/crm-invoices-view';
import { CrmProductsviewPage } from '../pages/crm-productsview/crm-productsview';
import { MySettingsPage } from '../pages/my-settings/my-settings';
import { LeadPage } from '../pages/lead/lead';
import { SettingprivacyPage } from '../pages/settingprivacy/settingprivacy';
import { CrmPage } from '../pages/crm/crm';
import { DiscoverPage } from '../pages/discover/discover';
import { CreateleadsPage } from '../pages/createleads/createleads';
import { EditleadscustomerPage } from '../pages/editleadscustomer/editleadscustomer';
import { Geolocation } from '@ionic-native/geolocation';
import { CrmfollowersViewPage } from '../pages/crmfollowers-view/crmfollowers-view';
import { SelectSearchableModule } from 'ionic-select-searchable';
import { AutoCompleteModule } from 'ionic2-auto-complete';
import { CrMcreateeventPage } from '../pages/cr-mcreateevent/cr-mcreateevent';
import { CrMediteventPage } from '../pages/cr-meditevent/cr-meditevent';
import { CrmEventsViewPage } from '../pages/crm-events-view/crm-events-view';
import { CusttabPage } from '../pages/custtab/custtab';
import { CallNumber } from '@ionic-native/call-number';
import { CustomerLeadsSingleViewPage } from '../pages/customer-leads-single-view/customer-leads-single-view';
import { DashboardcustPage } from '../pages/dashboardcust/dashboardcust';
import { MarketingsectionPage } from '../pages/marketingsection/marketingsection';
import { ViewPage } from '../pages/view/view';
import { NewPage } from '../pages/new/new';
import { ImagePicker } from '@ionic-native/image-picker';
import { EditadvancedpostsPage } from '../pages/editadvancedposts/editadvancedposts';
import { HairstylePage } from '../pages/hairstyle/hairstyle';

import { KSSwiperModule } from 'angular2-swiper';
import { ViewslidepostsPage } from '../pages/viewslideposts/viewslideposts';

import {TimeAgoPipe} from 'time-ago-pipe';
import { ModalPage } from '../pages/modal/modal';
// import { IsValuePipe } from '../pipes/is-value/is-value';

import { InAppBrowser } from '@ionic-native/in-app-browser';


@NgModule({
  declarations: [MyApp, 
    AboutPage, 
    ContactPage, 
    HomePage, 
    ViewPage,
    TimeAgoPipe,
    ModalPage,
    NewPage,
    MarketingsectionPage,
    CusttabPage,
    EditleadscustomerPage,
    BusinessHomePage,
    TabsPage, 
    CustomerLeadsSingleViewPage,
    LoginPage, 
    CustomerprofilePage,
    CrMcreateeventPage,
    ForgotPage, 
    CrmfollowersViewPage,
    CrmLeadsPage,
    SignupPage, 
    CrmFollowersPage,
    CrmInvoicesPage,
    SettingPage,
    EmailCampaingsPage,
    ViewEmailCampaingPage,
    MySettingsPage,
    PrivacyPage, 
    FollowingPage,
    ChangepassPage,
    EditadvancedpostsPage,
    SmsCampaignPage,
    SmsCampaignListPage,
    ViewslidepostsPage,
    CrmCutomersPage,
    TimelinePostPage,
    FollowingproPage,
    DashboardcustPage,
    LeadPage,
    CreateleadsPage,
    CrmPage,
    SettingprivacyPage,
    DashboardPage,
    TabsScreensPage,
    DiscoverPage,
    TimelinePostViewPage,
    CrMediteventPage,
    DiscoverMapPage,
    CrmInvoicesViewPage,
    CrmEventsViewPage,
    CrmProductsPage,
    CrmProductsviewPage,
    HairstylePage,
    ProfileonePage], 
   imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    PipesModule,
    SelectSearchableModule,
    AutoCompleteModule,
    KSSwiperModule,
    IonicModule.forRoot(MyApp),
    // IsValuePipe
  ],
  bootstrap: [IonicApp],
  entryComponents: [MyApp, 
    AboutPage, 
    CrmProductsPage,
    ContactPage, 
    CrmPage,
    DiscoverPage,
    CrMediteventPage,
    CrMcreateeventPage,
    CreateleadsPage,
    HairstylePage,
    SettingprivacyPage,
    HomePage, 
    CrmProductsviewPage,
    ModalPage,
    TabsPage,
    CusttabPage, 
    SmsCampaignListPage,
    EditadvancedpostsPage,
    TabsScreensPage,
    CrmInvoicesViewPage,
    LoginPage, 
    ViewslidepostsPage,
    LeadPage,
    EditleadscustomerPage,
    CrmLeadsPage,
    CrmEventsViewPage,
    MySettingsPage,
    TimelinePostPage,
    MarketingsectionPage,
    DiscoverMapPage,
    ViewPage,
    SmsCampaignPage,
    DashboardPage,
    DashboardcustPage,
    FollowingproPage,
    FollowingPage,
    ViewEmailCampaingPage,
    ForgotPage, 
    CrmInvoicesPage,
    SignupPage, 
    CustomerprofilePage,
    TimelinePostViewPage,
    SettingPage,
    NewPage,
    CustomerLeadsSingleViewPage,
    PrivacyPage, 
    EmailCampaingsPage,
    BusinessHomePage,
    ProfileonePage,
    CrmCutomersPage,
    CrmfollowersViewPage,
    CrmFollowersPage,
    ChangepassPage], 
  providers: [
    StatusBar,
    SplashScreen,
    SpinnerDialog,
    Toast,
    Camera,
    CallNumber,    
    Network,
    ImagePicker,
    InAppBrowser,
    Geolocation,
    LoadingController,
    {provide: ErrorHandler, useClass: IonicErrorHandler},
    RestProvider
  ]
})
export class AppModule {}
