import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TraddetailComponent } from './traddetail/traddetail.component';

@NgModule({
    imports: [
        CommonModule
    ],
    declarations: [TraddetailComponent]
})
export class TraddetailModule { }
