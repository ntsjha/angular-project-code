import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, Validators, FormControl, FormBuilder, FormArray } from '@angular/forms';
import { Component, OnInit, AfterViewInit, NgZone, OnDestroy } from '@angular/core';
import { ServiceService } from 'src/app/service/service.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { AppComponent } from 'src/app/app.component';

declare var $: any;

@Component({
  selector: 'app-add-participant',
  templateUrl: './add-participant.component.html',
  styleUrls: ['./add-participant.component.css']
})
export class AddParticipantComponent implements OnInit, AfterViewInit, OnDestroy {

  addParticipantForm: FormGroup;
  addMoreParticipantForm: FormGroup;
  items: any;
  apiResponse: any = { status: 1042 };
  OTPPhoneValidOrNot: any = false;
  show: any = false;
  showMobileError: any = false;
  phoneNumberValidationArray: any = [];
  paramData: any;
  userData: any;
  subscription: any;

  constructor(
    private formBuilder: FormBuilder,
    private zone: NgZone,
    private activatedRoute: ActivatedRoute,
    private service: ServiceService,
    private router: Router,
    private spinner: NgxSpinnerService,
    private appC: AppComponent
  ) {
    this.subscription = this.service.authVerify.subscribe(val => {
      if (val === 'add-participant') {
        this.submit();
        this.service.authVerify.next('false');
      }
    });
  }

  ngOnInit() {
    window.scrollTo(0, 0);
    this.form();
    this.getParamData();
    this.getUserData();
  }

  ngAfterViewInit() {
    this.filterCountry('TH');
    this.telInputFunc();
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  form() {
    this.addParticipantForm = new FormGroup({
      customerType: new FormControl('newCustomers', [Validators.required]),
      firstName: new FormControl('', [Validators.pattern(/^[a-zA-Z]*$/), Validators.minLength(2), Validators.maxLength(255)]),
      lastName: new FormControl('', [Validators.pattern(/^[a-zA-Z]*$/), Validators.minLength(2), Validators.maxLength(255)]),
      email: new FormControl('', [Validators.required, Validators.pattern(/^[a-zA-Z0-9_+&*-]+(?:\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,7}$/)]),
      phone: new FormControl('', []),
    });
    this.addMoreParticipantForm = this.formBuilder.group({
      items: this.formBuilder.array([])
    });
  }

  getParamData() {
    this.activatedRoute.params.subscribe(param => {
      this.paramData = param;
    });
  }

  getUserData() {
    this.service.userInfo.subscribe(success => {
      this.userData = success;
    });
  }

  createItem(): FormGroup {
    return this.formBuilder.group({
      firstName: new FormControl('', [Validators.required, Validators.pattern(/^[a-zA-Z]*$/), Validators.minLength(2), Validators.maxLength(255)]),
      lastName: new FormControl('', [Validators.required, Validators.pattern(/^[a-zA-Z]*$/), Validators.minLength(2), Validators.maxLength(255)]),
      email: new FormControl('', [Validators.required, Validators.pattern(/^[a-zA-Z0-9_+&*-]+(?:\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,7}$/)]),
      phone: new FormControl('', [Validators.required]),
    });
  }

  addItem(): void {
    if (this.formValidOrNot()) {
      return;
    } else {
      this.show = false;
    }
    this.items = this.addMoreParticipantForm.get('items') as FormArray;
    this.items.push(this.createItem());
    this.setCountry('phNumber' + (this.items.length - 1), 'TH');
  }

  // set country on phone number
  setCountry(id, country) {
    setTimeout(() => {
      $('#' + id).intlTelInput({
        separateDialCode: true,
        initialCountry: country,
        nationalMode: true,
        autoFormat: false,
        utilsScript: '/assets/vendors/custom/intl-tel-input/js/utils.js',
        geoIpLookup: (callback) => {
          callback('MY');
        }
      });
      this.phoneNumberValidOrNot(this.items.length - 1);
    }, 500);
  }

  // check country wise validation on phone number
  phoneNumberValidOrNot(index) {
    this.zone.run(() => {
      this.phoneNumberValidationArray[index] = $('#phNumber' + index).intlTelInput('isValidNumber');
    });
  }

  removeItem(): void {
    if (!this.addMoreParticipantForm.value.items.length) {
      return;
    }
    this.items.removeAt(this.addMoreParticipantForm.value.items.length - 1);
    this.phoneNumberValidationArray.pop();
  }

  filterCountry(data) {
    setTimeout(() => {
      $('#phoneNum').intlTelInput({
        autoPlaceholder: true,
        autoFormat: false,
        autoHideDialCode: false,
        initialCountry: data,
        nationalMode: false,
        preferredCountries: [data],
        formatOnInit: true,
        separateDialCode: true
      });
    }, 500);
  }

  // change validation on change the country
  telInputFunc() {
    $(document).on('click', '.country', () => {
      this.phoneValidOrNot();
    });
  }

  phoneValidOrNot() {
    this.zone.run(() => {
      this.OTPPhoneValidOrNot = $('#phoneNum').intlTelInput('isValidNumber');
      this.showMobileError = true;
    });
  }

  /** Function to verify google authentication */
  verifyGoogleAuth() {
    this.appC.google = { one: '', two: '', three: '', four: '', five: '', six: '' };
    this.appC.response = { message: '' };
    this.service.googleAuthCalledFrom = 'add-participant';
    $('#google-auth-modal').modal({ keyboard: false, backdrop: 'static' });

  }

  submit() {
    this.spinner.show();
    if (this.formValidOrNot()) {
      this.show = true;
      this.spinner.hide();
      return;
    }
    this.addMoreParticipantForm.value.items.forEach((element, i) => {
      element.phone = $('#phNumber' + i).intlTelInput('getNumber');
    });
    if (this.addParticipantForm.value.customerType === 'existingCustomers') {
      const apireq = JSON.stringify({
        contentId: this.paramData.eventId,
        userEmail: this.addParticipantForm.value.email,
        eventsParticipants: this.addMoreParticipantForm.value.items,
        ipAddress: this.userData.ip,
        location: this.userData.city + ',' + this.userData.country_name,
        noOfTickets: this.addMoreParticipantForm.value.items.length + 1
      });
      this.apiForExistingUser(apireq);
    } else {
      const apireq = JSON.stringify({
        contentId: this.paramData.eventId,
        // eventsRegister: {
          eventRegistration: {
          email: this.addParticipantForm.value.email,
          firstName: this.addParticipantForm.value.firstName,
          lastName: this.addParticipantForm.value.lastName,
          phone: $('#phoneNum').intlTelInput('getNumber'),
        },
        eventsParticipants: this.addMoreParticipantForm.value.items,
        ipAddress: this.userData.ip,
        location: this.userData.city + ',' + this.userData.country_name,
        noOfTickets: this.addMoreParticipantForm.value.items.length + 1
      });
      this.apiForNewUser(apireq);
    }
  }

  apiForExistingUser(apireq) {
    this.service.postMethod('event/admin/add-participants-details?languageCode=' + encodeURIComponent(this.service.encrypt('en')) + '&webUrl=' + this.service.eventBaseUrl , { kycDto: this.service.encrypt(apireq) }, 1).subscribe(success => {
      this.spinner.hide();
      this.apiResponse = success;
      if (success.status === 1042) {
        this.router.navigate(['/attendees-management/' + this.paramData.eventId]);
      }
    }, error => {
      this.spinner.hide();
      this.apiResponse.status = error.error.status;
      this.apiResponse.message = error.error.error;
    });
  }

  apiForNewUser(apireq) {
    this.service.postMethod('event/admin/add-new-participant-details?languageCode=' + encodeURIComponent(this.service.encrypt('en'))  + '&webUrl=' + this.service.eventBaseUrl , { kycDto: this.service.encrypt(apireq) }, 1).subscribe(succ => {
      this.spinner.hide();
      this.apiResponse = succ;
      if (succ.status === 1050) {
        this.router.navigate(['/attendees-management/' + this.paramData.eventId]);
      }
    }, err => {
      this.spinner.hide();
      this.apiResponse.status = err.error.status;
      this.apiResponse.message = err.error.error;
    });
  }

  formValidOrNot() {
    let validOrNot = false;
    if (this.addParticipantForm.value.customerType === 'newCustomers') {
      if (this.addParticipantForm.value.firstName === '' || this.addParticipantForm.value.lastName === '' || this.addParticipantForm.value.phone === '' || !this.OTPPhoneValidOrNot) {
        validOrNot = true;
      }
    }
    if (this.addParticipantForm.invalid) {
      validOrNot = true;
    }
    if (this.addMoreParticipantForm.invalid) {
      validOrNot = true;
    }
    this.phoneNumberValidationArray.forEach(element => {
      if (element === false) {
        validOrNot = true;
      }
    });
    return validOrNot;
  }

  customerType() {
    if (this.addParticipantForm.value.customerType === 'newCustomers') {
      this.filterCountry('TH');
      this.telInputFunc();
    }
  }

}
