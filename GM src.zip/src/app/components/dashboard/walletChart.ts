
declare var CanvasJS: any;
// declare var angular: any;

export class walletChart {
  chart: any;
  viewChart = [];
  coldWalletDataPoints = [];
  hotWalletDataPoints = [];
  chartData = [
    {
      hotWalletAmount: 481.999784,
      coldWalletAmount: 1,
      totalAmount: 482.999784,
      coinName: 'XRP'
    },
    {
      hotWalletAmount: 10070,
      coldWalletAmount: 0,
      totalAmount: 10070,
      coinName: 'XLM'
    },
    {
      hotWalletAmount: 0.606899,
      coldWalletAmount: 0,
      totalAmount: 0.606899,
      coinName: 'BTC'
    },
    {
      hotWalletAmount: 7.898988,
      coldWalletAmount: 7.8989884,
      totalAmount: 15.7979764,
      coinName: 'LTC'
    },
    {
      hotWalletAmount: 12.797422,
      coldWalletAmount: 1,
      totalAmount: 13.797422,
      coinName: 'ETH'
    },
    {
      hotWalletAmount: 998.813297,
      coldWalletAmount: 0,
      totalAmount: 998.813297,
      coinName: 'BCH'
    },
    {
      hotWalletAmount: 2245.2295,
      coldWalletAmount: 0,
      totalAmount: 2245.2295,
      coinName: 'EOS'
    },
    {
      hotWalletAmount: 19990,
      coldWalletAmount: 1,
      totalAmount: 19991,
      coinName: 'TRX'
    },
    {
      hotWalletAmount: 131.09233,
      coldWalletAmount: 0,
      totalAmount: 131.09233,
      coinName: 'DASH'
    },
    {
      hotWalletAmount: 0,
      coldWalletAmount: 0,
      totalAmount: 0,
      coinName: 'THB'
    },
    {
      hotWalletAmount: 0,
      coldWalletAmount: 0,
      totalAmount: 0,
      coinName: 'XEM'
    },
    {
      hotWalletAmount: 0,
      coldWalletAmount: 0,
      totalAmount: 0,
      coinName: 'USDT'
    },
    {
      hotWalletAmount: 0,
      coldWalletAmount: 2,
      totalAmount: 2,
      coinName: 'OMG'
    },
    {
      hotWalletAmount: 3.94,
      coldWalletAmount: 0,
      totalAmount: 3.94,
      coinName: 'USDC'
    }
  ];
  async walletData(data, chartId) {
    // if ( !angular.element('#' + chartId).length ) {
    //     return;
    // }
    this.viewChart = [] ;
    this.coldWalletDataPoints = [];
    this.hotWalletDataPoints = [];
    return await this.setChart(data, chartId);
  }

  setChart(chartData, chartId) {
    // if(this.chartPlotted) {
    //   this.chart.destroy();
    // }
    this.viewChart = [];
    this.chartData = chartData;
    if (this.chartData.length) {
      this.chartData.forEach((element) => {
        const hotWallet = {
          label: element.coinName,
          y: this.convertPercentage(element, 'hot'),
        };
        this.hotWalletDataPoints.push(hotWallet);
        const coldWallet = {
          label: element.coinName,
          y: this.convertPercentage(element, 'cold'),
        };
        this.coldWalletDataPoints.push(coldWallet);
      });
    } else {
      const hotWallet = {
        label: '',
        y: this.convertPercentage(0, 0),
      };
      this.hotWalletDataPoints.push(hotWallet);
      const coldWallet = {
        label: '',
        y: this.convertPercentage(0, 0),
      };
      this.coldWalletDataPoints.push(coldWallet);
    }
    this.viewChart = [
      {
        type: 'stackedColumn100',
        name: 'Hot Wallet',
        showInLegend: true,
        yValueFormatString: '#,##0"%"',
        dataPoints: this.hotWalletDataPoints
      } ,
      {
        type: 'stackedColumn100',
        name: 'Cold Wallet',
        showInLegend: true,
        yValueFormatString: '#,##0"%"',
        dataPoints: this.coldWalletDataPoints
      }
    ];
    const colorSet = [
       '#B08BEB' ,
       '#F5A52A' ,
    ];
    CanvasJS.addColorSet('customColorSet1', colorSet);
    this.chart = new CanvasJS.Chart(chartId, {
      exportEnabled: true,
      zoomEnabled: true,
      animationEnabled: true,
      axisX: {
        interval: 1,
      },
      axisY: {
          suffix: '%'
      },
      legend: {
        cursor: 'pointer',
        fontSize: 16,
      },
      toolTip: {
        shared: true
      },
      colorSet:  'customColorSet1',
      data: this.viewChart
    });
    return this.chart.render();
  }

  convertPercentage(element, type) {
    const hotWallet = (Math.sign(element.hotWalletAmount) == -1 ) ? 0 : element.hotWalletAmount;
    const coldWallet = (Math.sign(element.coldWalletAmount) == -1 ) ? 0 : element.coldWalletAmount;
    const totalAmount = hotWallet + coldWallet;
    const numerator = (type === 'hot') ? hotWallet : coldWallet;
    const per = ((numerator / totalAmount) * 100);
    return (isNaN(per) === true) ? 0 : per;
  }
}
