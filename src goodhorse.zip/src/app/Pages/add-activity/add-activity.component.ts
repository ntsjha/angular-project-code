import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, FormArray, Validators } from '@angular/forms';
import { ServiceService } from 'src/app/Shared/service.service';
import { firestore } from 'firebase';
import { AngularFirestore } from '@angular/fire/firestore';
import { Router } from '@angular/router';
import { IMyDpOptions, IMyDateModel } from 'mydatepicker';

@Component({
  selector: 'app-add-activity',
  templateUrl: './add-activity.component.html',
  styleUrls: ['./add-activity.component.css']
})
export class AddActivityComponent implements OnInit {
  activityArr = ['Flatwork','Cavelli','Jumps','Trot poles','Lungeing','Trail ride','Trot','Canter']
restDayArr =  ['Monday','Tuseday','Wednesday','Thursday','Friday','Saturday','Sunday'];
weekArrOne =  ['1','2','3','4','5','6','7']; 
weekArrTwo = ['8','9','10','11','12','13','All'];
weekArray:any=[];
  activityForm: FormGroup;
  templateForm: FormGroup;
  selectWeekArr:any=['1','2','3','4','5','6','7','8','9','10','11','12','13','All'];
  weekArr:any=[];
  dayArr:any=[];
  beDisable: boolean=true;
  days: string[];
constructor(public fb:FormBuilder, public service:ServiceService,public firestore:AngularFirestore, public route:Router) { 
  this.templateForm = new FormGroup({
    'templateName':new FormControl('',[Validators.required]),
    'totalWeek': new FormControl('',Validators.required),
    // 'warmup': new FormControl('',[Validators.required,Validators.pattern(/^(0|[1-9][0-9]*)$/)]),
    // 'warmdown': new FormControl('',[Validators.required,Validators.pattern(/^(0|[1-9][0-9]*)$/)]),
    // 'startDate': new FormControl('',Validators.required),
    // 'endDate': new FormControl('',Validators.required)
  })
    this.activityForm =  this.fb.group({
      activityData: this.fb.array([])
    });
  }

  ngOnInit() {
    this.onDateChanged();
    this.onActivityData();
  }

    /**************** Date managing***************/
    public myDatePickerOptions: IMyDpOptions = {
      dateFormat: 'yyyy-mm-dd',
      editableDateField: false,
      openSelectorOnInputClick: false,
      disableSince: { year: 0, month: 0, day: 0 }
    };
    public toDate: IMyDpOptions = {
      dateFormat: 'yyyy-mm-dd',
      editableDateField: false,
      openSelectorOnInputClick: false,
      disableUntil: { year: 0, month: 0, day: 0 }
    };
  
    onDateChanged() {
      let d = new Date();
      let copy1 = this.getCopyOfOptions();
      copy1.disableUntil = {
        year: d.getFullYear(),
        month: d.getMonth() + 1,
        day: d.getDate()
      };
      this.myDatePickerOptions = copy1;
    }
    //Returns copy of myDatePickerOptions
    getCopyOfOptions(): IMyDpOptions {
      return JSON.parse(JSON.stringify(this.myDatePickerOptions));
    }
  
    public onChange(event: IMyDateModel) {
      if (event.formatted) {
        this.beDisable = false
        let d: Date = new Date(event.jsdate.getTime());
        d.setDate(d.getDate() - 1);
        let copy: IMyDpOptions = this.getCopyOfToDateOpt();
        copy.disableUntil = {
          year: d.getFullYear(),
          month: d.getMonth() + 1,
          day: d.getDate()
        };
        this.toDate = copy;
      } else {
        this.beDisable = true
      }
  
    }
    getCopyOfToDateOpt(): IMyDpOptions {
      return JSON.parse(JSON.stringify(this.toDate));
    }
    /*******************Date managing Ends Here**************/

    getWeeks(event){
      var data = 1
      this.weekArrOne = [];
      this.weekArrTwo=[];
  var totalWeek = event;
  for(var i= 1; i<=totalWeek;i++){
    this.weekArr.push(String(i));
  }
  console.log('weekArr===>>',this.weekArr);
  if(totalWeek > 7)
  {
    for(var i=1;i<=7;i++){
      this.weekArrOne.push(''+i);
    }
    for(var j=8;j<=totalWeek;j++){
      this.weekArrTwo.push(''+j);
    }
  }
  else{
    for(var i=1;i<=totalWeek;i++){
      this.weekArrOne.push(''+i);
    }
  }
  console.log('WeekOne===>>',this.weekArrOne);
  console.log('WeekTwo--->',this.weekArrTwo)
     }

  onActivityData() {
    const control = new FormGroup({
      'activityType': new FormControl('',[Validators.required]),
      'activityDuration': new FormControl('',[Validators.required]),
      'activityRestDaysArr': new FormControl([]),
      'activityRestWeekArr':new FormControl([])
    });
    (<FormArray>this.activityForm.get('activityData')).push(control);
  }

  createWeekarr(val){
    if(!this.weekArr.includes(val))
      this.weekArr.push(val)
      else{
        var index = this.weekArr.indexOf(val);
        this.weekArr.splice(index,1);
      }
      console.log('WeekArr-->>',this.weekArr);
   }
 
   createDayArr(val){
    

     if(!this.dayArr.includes(val)){
      if(this.restDayArr.length != 1){
      this.dayArr.push(val)
      const index = this.restDayArr.findIndex(x => x == val);
      this.restDayArr.splice(index,1);
  
      console.log('dayArr-->>',this.dayArr,);
    }else{
      this.service.toastErr('Please do not select all the rest days')
    }
  }

  else{
       var index = this.dayArr.indexOf(val);
       const addDay = this.dayArr[index];
       this.dayArr.splice(index,1);

       this.restDayArr.splice(index, 0, addDay);
       console.log('dayArr-->>',this.dayArr,);

    
     }
    }

   removeNozzle(index) {

    let control = <FormArray>this.activityForm.controls.activityData;
    control.removeAt(index)

  }
  
  save() {
    this.service.showSpinner();
    console.log(this.activityForm.value)


    console.log('template--->>',this.templateForm.value)
    var templateDetails = {
      'templateName': this.templateForm.value.templateName,
      'trainingWeeks': this.templateForm.value.totalWeek,
      'restDaysArray': this.dayArr,
      'restWeekArray': this.weekArr,
      'startDate':'' ,//new Date(this.templateForm.value.startDate.jsdate).toISOString(),
      'enddate':'', //new Date(this.templateForm.value.endDate.jsdate).toISOString(),
      'warmUpTime':  '',//this.templateForm.value.warmup,
      'warmDownTime':'',     //this.templateForm.value.warmdown,
      'trainingActivity':this.activityForm.value.activityData,
      'ownerID':localStorage.getItem('key'),
      'horseID'                    :   '',
      'horseTitle'                  :   '',
      'horseImage'                  :   '',
      'nonTrainingDay'              :   '',
      'templateNotes' : ''
    }
    this.firestore.collection('adminTrainingTemplate').add(templateDetails);
    this.service.hideSpinner();
    this.service.showSuccess('Template has been added successfully.');
    this.route.navigate(['/trainingMagement']);
    console.log('Detail--->>',templateDetails);
 
  }

  selectedDay(day, i) {
    if(this.activityForm.value.activityData[i].activityRestDaysArr.includes(day))
      this.activityForm.value.activityData[i].activityRestDaysArr.splice(this.activityForm.value.activityData[i].activityRestDaysArr.indexOf(day), 1 );
    else
      this.activityForm.value.activityData[i].activityRestDaysArr.push(day);
      console.log('day==>', this.activityForm.value)
  }

  selectedWeek(week, i) {
    console.log('Week==>')
    if(week == 'All') {
      this.activityForm.value.activityData[i].activityRestWeekArr=[];
      this.activityForm.value.activityData[i].activityRestWeekArr.push('All');
    }
    else {
      if(this.activityForm.value.activityData[i].activityRestWeekArr.includes('All'))
        this.activityForm.value.activityData[i].activityRestWeekArr=[];
      if(this.activityForm.value.activityData[i].activityRestWeekArr.includes(week))
        this.activityForm.value.activityData[i].activityRestWeekArr.splice(this.activityForm.value.activityData[i].activityRestWeekArr.indexOf(week), 1 );
      else{
          this.activityForm.value.activityData[i].activityRestWeekArr.push(week);
      }
    }
    console.log('Week', this.activityForm.value.activityData)
  }

  numberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;

  }
  preventSpace(event){
    if(event.charCode==32 && !event.target.value){
    event.preventDefault()
    } else{
    // console.log(event)
    }
    // console.log('event',event.charCode)
    }

}
