import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MachineReadingComponent } from './machine-reading.component';

describe('MachineReadingComponent', () => {
  let component: MachineReadingComponent;
  let fixture: ComponentFixture<MachineReadingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MachineReadingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MachineReadingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
