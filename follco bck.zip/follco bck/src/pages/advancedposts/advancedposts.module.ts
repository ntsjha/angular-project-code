import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdvancedpostsPage } from './advancedposts';

@NgModule({
  declarations: [
    AdvancedpostsPage,
  ],
  imports: [
    IonicPageModule.forChild(AdvancedpostsPage),
  ],
})
export class AdvancedpostsPageModule {}
