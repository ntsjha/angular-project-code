import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CreateleadsPage } from './createleads';

@NgModule({
  declarations: [
    CreateleadsPage,
  ],
  imports: [
    IonicPageModule.forChild(CreateleadsPage),
  ],
})
export class CreateleadsPageModule {}
