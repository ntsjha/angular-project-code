import { Component, OnInit, OnDestroy } from '@angular/core';
import { ServiceService } from 'src/app/service/service.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormBuilder, FormArray } from '@angular/forms';
import { CookieService } from 'ngx-cookie-service';
import { AppComponent } from 'src/app/app.component';
declare var $: any;
@Component({
  selector: 'app-manage-transfer-exchange-wallet',
  templateUrl: './manage-transfer-exchange-wallet.component.html',
  styleUrls: ['./manage-transfer-exchange-wallet.component.css']
})
export class ManageTransferExchangeWalletComponent implements OnInit, OnDestroy {
  walletDetails: any;
  walletForm: FormGroup;
  baseValues: any = [];
  address: any = [];
  watchAddresses: FormArray;
  subscription: any;
  showApiMessage = false;
  response: any;
  totalAddress: any;
  google: any = { one: '', two: '', three: '', four: '', five: '', six: '' };
  currentId: any;
  userIp: any;

  constructor(
    private service: ServiceService,
    private cookie: CookieService,
    private spinner: NgxSpinnerService,
    private router: Router,
    private activatedRoutes: ActivatedRoute,
    private fb: FormBuilder,
    private appC: AppComponent
  ) {
    this.walletForm = this.fb.group({
      baseThreshold: [''],
      cryptoAddress: [''],
      isAutoTransfer: [''],
      threshold: [''],
      watchAddresses: this.fb.array([
      ])
    });
    for (let i = 0; i <= 100; i++) {
      this.baseValues.push(i);
    }
    this.subscription = this.service.authVerify.subscribe(val => {
      if (val === 'manage-transfer-exchange') {
        this.updateWalletDetails();
        this.service.authVerify.next('false');
      }
    });
    this.userIp = (this.cookie.get('userInfo')) ? JSON.parse(this.cookie.get('userInfo')) : this.service.initialUserInfo;
  }

  ngOnInit() {
    this.activatedRoutes.params.subscribe(id => {
      this.getDetails(id.id);
      window.scrollTo(0, 0);
    });
  }
  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  createWatchAddress(id): FormGroup {
    return this.fb.group({
      watchAddress: id,
    });
  }

  addMore() {
    if (this.service.sideMenuArr.includes('updateSettings')) {
      this.watchAddresses = this.walletForm.get('watchAddresses') as FormArray;
      this.watchAddresses.push(this.createWatchAddress(null));
    }
  }

  loadWatchAddress() {
    this.watchAddresses = this.walletForm.get('watchAddresses') as FormArray;
    this.address.forEach(element => {
      this.watchAddresses.push(this.createWatchAddress(element));
    });
    this.totalAddress =  (this.watchAddresses.length - 1);
  }

  getDetails(id) {
    this.spinner.show();
    this.service.getMethod('wallet/admin/exchange-wallet/get-exchange-wallet-details?exchangeWalletId=' + id, 1)
      .subscribe((response: any) => {
        this.spinner.hide();
        if (response.status === 842) {
          this.walletDetails = response.data;
          this.walletForm.patchValue({
            baseThreshold: this.walletDetails.baseThreshold,
            cryptoAddress: this.walletDetails.coldWalletAddress,
            isAutoTransfer: this.walletDetails.isAutoTransfer,
            threshold: this.walletDetails.threshold,
          });
          this.address = response.data.watchAddresses;
          this.loadWatchAddress();
        }
      }, (error) => {
        this.spinner.hide();
      });
  }

  openModal(id) {
    $('#deleteAddress').modal('show');
    this.currentId = id;
}
  remove() {
    $('#deleteAddress').modal('hide');
    if (this.currentId > this.totalAddress) {
      this.watchAddresses.removeAt(this.currentId);
    } else {
      const address = this.watchAddresses.controls[this.currentId].value.watchAddress;
      this.spinner.show();
      this.service.deleteMethod('wallet/admin/exchange-wallet/remove-watch-address?watchAddress=' + address + '&ipAddress=' + this.userIp.ip + '&location=' + this.userIp.city + ',' + this.userIp.country_name, 1)
      .subscribe((response) => {
        this.spinner.hide();
        if (response.status === 842 ) {
          this.watchAddresses.removeAt(this.currentId);
        }
      }, (error) => {
        this.spinner.hide();
      });
    }
  }

  /** Function to verify google authentication */
  verifyGoogleAuth() {
    if (this.service.sideMenuArr.includes('updateSettings')) {
      this.appC.google = { one: '', two: '', three: '', four: '', five: '', six: '' };
      this.appC.response = { message : '' };
      this.service.googleAuthCalledFrom = 'manage-transfer-exchange';
      $('#google-auth-modal').modal({ keyboard: false, backdrop: 'static' });
    }

  }

  updateWalletDetails() {
    this.spinner.show();
    const walletAddress = [];
    this.walletForm.value.watchAddresses.forEach(element => {
      walletAddress.push(element.watchAddress);
    });
    const data = {
      baseThreshold: this.walletForm.value.baseThreshold,
      coinName: this.walletDetails.currencyName,
      cryptoAddress: this.walletForm.value.cryptoAddress,
      hours: 0,
      isAutoTransfer: this.walletForm.value.isAutoTransfer,
      minutes: 0,
      threshold: this.walletForm.value.threshold,
      watchAddresses: walletAddress,
      ipAddress: this.userIp.ip,
      location: this.userIp.city + ',' + this.userIp.country_name
    };
    this.service.postMethod('wallet/admin/exchange-wallet/update-exchange-wallet', data, 1)
      .subscribe((response) => {
        this.spinner.hide();
        if (response.status === 842) {
          this.goToCancel();
        } else if (response.status === 876) {
          this.response = response;
          this.showApiMessage = true;
          this.response.message = 'Threshold should not be less than base threshold value.';
        }
      }, (error) => {
        this.spinner.hide();
      });
  }

  goToCancel() {
    this.router.navigate(['/manage-exchange-wallet']);
  }

  newHotWallet() {
    this.spinner.show();
    this.service.getMethod('wallet/admin/exchange-wallet/generate-new-hot-address?coinName=' + this.walletDetails.currencyName + '&ipAddress=' + this.userIp.ip + '&location=' + this.userIp.city + ',' + this.userIp.country_name, 1)
      .subscribe((response: any) => {
        this.spinner.hide();
        if (response.status === 842) {
          this.getDetails(this.walletDetails.exchangeWalletId);
        }
      }, (error) => {
        this.spinner.hide();
      });
  }

  /** Auto focus functionality */
  onKey(event, next, previous) {
    if (event.key === 'Backspace') {
      document.getElementById(previous).focus();
    } else {
      if (event.keyCode >= 48 && event.keyCode <= 57) {
        if (event.target.value.trim() !== '') {
          document.getElementById(next).focus();
        } else {
          event.target.value = '';
        }
      } else {
        event.target.value = '';
      }
    }
  }


}
