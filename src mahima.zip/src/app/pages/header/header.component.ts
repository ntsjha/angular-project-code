import { MediaMatcher } from '@angular/cdk/layout';
import { Component, OnInit, ChangeDetectorRef, ViewChild } from '@angular/core';
import { MatSidenav } from '@angular/material';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  
  userName="Mr. Stark";
  petrolPumpName="petrol pump 1";
 data=[{name:'Dashboard'},
 {name:'Daily Basic Report'},
 {name:'Daily Input'},
 {name:'Stock'},
 {name:'Sales'},
 {name:'Credit Customer'},
 {name:'Full Report'},
 {name:'Machine Reading'},
 {name:'Accounting'}
]
@ViewChild('sidenav') sidenav: MatSidenav;

  mobileQuery: MediaQueryList;

  fillerNav = Array.from({length: 9}, (_, i) => `${this.data[i].name}`);


  private _mobileQueryListener: () => void;

  constructor(public changeDetectorRef: ChangeDetectorRef, public media: MediaMatcher) {
    this.mobileQuery = media.matchMedia('(max-width: 2000px)');
    // this._mobileQueryListener = () => changeDetectorRef.detectChanges();
    this.mobileQuery.addListener(this._mobileQueryListener);
  }


  ngOnInit() {
   
  }

  ngOnDestroy(): void {
    this.mobileQuery.removeListener(this._mobileQueryListener);
  }


}
