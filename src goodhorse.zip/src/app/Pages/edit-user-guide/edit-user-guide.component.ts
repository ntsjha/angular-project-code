import { Component, OnInit } from '@angular/core';
import { AngularFirestore, AngularFirestoreModule } from '@angular/fire/firestore';
import { ServiceService } from 'src/app/Shared/service.service';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { Upload } from 'src/app/Shared/common-class';
import * as firebase from 'firebase';
import { Router, ActivatedRoute } from '@angular/router';
import {  UserGuide } from 'src/app/Shared/feed-type';
import { formatDate } from '@angular/common';

@Component({
  selector: 'app-edit-user-guide',
  templateUrl: './edit-user-guide.component.html',
  styleUrls: ['./edit-user-guide.component.css']
})
export class EditUserGuideComponent implements OnInit {

  edituserguideForm: FormGroup;
  fileName1: any;

  
  selectedFiles: FileList;
  currentUpload: Upload;
  ref: any;
  task: any;
  uploadProgress: any;
  downloadURL: any;
  userProfileImg: any;
  randomId: string;
  image: any;
  contentId: any;
  userguidelist: any[];
  userguidelistLength: any[];
  videourl: any;
  size: string;
  vidourl: any;
  constructor(public route: ActivatedRoute,private afStorage: AngularFirestoreModule,private router: Router, private afb: AngularFirestore,public firebaseServ : ServiceService) { }

  ngOnInit() {
    this.route.params.subscribe((res)=>{
      console.log('params--->>> ',res.id);
      this.contentId = res.id

    })

    this.edituserguideForm = new FormGroup({
      title: new FormControl('', [ Validators.required,Validators.pattern(/^[a-z\d\-_?@.;:,&\s]+$/i)]),
      video: new FormControl('',[])
         
  })

  this.getfeaturelist()
 
}

 /**Function To upload front side of pic */
 handleFileInputFront(event) {

  var self = this;
  if (event.target.files && event.target.files[0]) {
    var type = event.target.files[0].type;
    var size = event.target.files[0].size;
    let count = 0;
    if (size < 100000000) {
      if (type === 'video/mp4' || type === 'video/mov' || type === 'video/wmv' || type === 'video/mpeg' || type === 'video/3gp' || type === 'video/avi' || type === 'video/flv' || type === 'video/mkv') {
        this.size = event.target.files[0].size / 1024 / 1024 + "MB"
        this.fileName1 = event.target.files[0];
        this.edituserguideForm.patchValue({
          video: this.fileName1.name
        })
        count++;
      } else if (type === 'video/mp4') {
        this.size = event.target.files[0].size / 1024 / 1024 + "MB"
        this.fileName1 = event.target.files[0];

        this.edituserguideForm.patchValue({
          video: this.fileName1.name

        })
        count++;

      } else {
        this.firebaseServ.toastErr('Select only  mp4,wmv,mpeg,3gp,avi,flv and mkv file.')

      }
    } else {
      this.firebaseServ.toastErr('Video size should be less than 100 MB.')


    }

    console.log('File', this.fileName1)
  }
}


async getfeaturelist(){
  var userguidelist=[];
  this.firebaseServ.showSpinner();
  this.firebaseServ.getuserguied().subscribe(res => {
      userguidelist = res.map(item => {
      return {
        id: item.payload.doc.id,
        ...item.payload.doc.data()
        // Declare model at FeedType for resuable
      } as UserGuide 

      })
      this.firebaseServ.hideSpinner();
      console.log('info',userguidelist)
      this.userguidelistLength = userguidelist.filter(x=>(x.id == this.contentId))
      
      this.edituserguideForm.patchValue({
      'title'  :this.userguidelistLength[0].Title?this.userguidelistLength[0].Title:'',
   
})
setTimeout(()=>{
  this.videourl=this.userguidelistLength[0].VideoUrl
},2000)

console.log(this.videourl)
this.firebaseServ.hideSpinner();
});
 
}




  // Uploading Images Functionality
  onUpload() {  
    console.log('File')  
    this.firebaseServ.showSpinner()
    const file = this.fileName1;  
    
   
    if (file) {
      console.log('File')  
      const reader = new FileReader();
      reader.onload = this.handleReaderLoadedCustom.bind(this);
      reader.readAsBinaryString(file);
    }
    else{
      this.UpdatedUserguide()
        } 
  }


handleReaderLoadedCustom(e) {
    this.uploadvideoToFirebase('data:video/mp4;base64,' + btoa(e.target.result))
  }
  uploadvideoToFirebase(image){
   
    let randomId = Math.random().toString(36).substr(2, 5);
    this.firebaseServ.getUserProfileImageuploadVideo(image, randomId)
      .then(videoURL => {

        this.vidourl = videoURL;
       
        // console.log('URL', this.image)
        var time = formatDate(new Date(), 'yyyy/MM/dd h:mm:ss', 'en');

        let data = {
          Title: this.edituserguideForm.value.title,
          VideoUrl: this.vidourl,
          LastUpdate: time,
        }
        
        this.afb.collection('UserGuide').doc(this.contentId).update(data);
        this.firebaseServ.showSuccess('User guide has been added successfully.');
        this.firebaseServ.hideSpinner();
        this.edituserguideForm.reset();
        this.router.navigate(['/user-guide']);


      }).catch(err => {
        console.log(err)
        this.firebaseServ.hideSpinner()
      })
  
  }



  UpdatedUserguide() {
    var time = formatDate(new Date(), 'yyyy/MM/dd h:mm:ss', 'en');
    console.log(this.edituserguideForm.value)
    this.afb.collection('UserGuide').doc(this.contentId).update({
    Title       :   this.edituserguideForm.value.title,
    VideoUrl       :  this.videourl,
    LastUpdate  :  time,
   
  });
  this.firebaseServ.showSuccess('User guide has been updated successfully.');
  this.router.navigate(['/user-guide']);
}

 

   numberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;

  }
  preventSpace(event){
    if(event.charCode==32 && !event.target.value){
    event.preventDefault()
    } else{
    // console.log(event)
    }
    // console.log('event',event.charCode)
    }





}
