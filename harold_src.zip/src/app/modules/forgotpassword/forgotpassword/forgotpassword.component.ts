import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ServerService } from '../../../server.service';
import { AppComponent } from '../../../app.component';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { Router } from '@angular/router';

@Component({
    selector: 'app-forgotpassword',
    templateUrl: './forgotpassword.component.html',
    styleUrls: ['./forgotpassword.component.css']
})
export class ForgotpasswordComponent implements OnInit {

    forgetForm: FormGroup;
    constructor(private server: ServerService, public appC: AppComponent, private spinnerService: Ng4LoadingSpinnerService, private router: Router) { }

    ngOnInit() {
        window.scrollTo(0,0);
        this.checkInputs();
    }
    /** Function to validate form inputs */
    checkInputs() {
        this.forgetForm = new FormGroup({
            email: new FormControl('', [Validators.required, Validators.pattern(/^[A-Z0-9_]+([\.-][A-Z0-9_]+)*@[A-Z0-9-]+(\.[a-zA-Z]{2,5})+$/i)]),
        });
    }

    /** to get the valuen of field */
    get email(): any {
        return this.forgetForm.get('email');
    }

    /** Function for forget */
    submit() {
        if(this.forgetForm.value.email == '') {
            this.appC.showErrToast("Please enter your email address")
            return;
        }
        this.spinnerService.show();
        this.server.getApi('account/forget-password?email='+this.forgetForm.value.email+'&webUrl='+this.server.websiteURL+"/resetpassword").subscribe((res) => {
            this.spinnerService.hide();
            if (res.status == 200) {
                this.appC.showSuccToast("Password reset link has been sent to registered email id");
                this.router.navigate(['login']);
            }
            else {
                this.spinnerService.hide();
                this.appC.showErrToast(res.message);
            }

        }, (err) => {
            this.spinnerService.hide();
            this.appC.showErrToast(err.error.message)
        })
    }


}
