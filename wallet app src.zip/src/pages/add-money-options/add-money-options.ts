import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { MyCardsPage } from "../my-cards/my-cards";
import { TabsPage } from "../tabs/tabs";
import { ServiceServicesProvider } from "../../providers/service-services/service-services";
import { VendorsListPage } from '../vendors-list/vendors-list';

@IonicPage()
@Component({
  selector: 'page-add-money-options',
  templateUrl: 'add-money-options.html',
})
export class AddMoneyOptionsPage {
  howTo: any;

  constructor(public navCtrl: NavController, public navParams: NavParams, public service: ServiceServicesProvider) {
  }

  back() {
    this.navCtrl.setRoot(TabsPage, { selectedTab: 0 })
  }

  next() {
    if (navigator.onLine) {
      let data = JSON.parse(localStorage.addMoneyProcess);
      data.howTo = this.howTo
      localStorage.addMoneyProcess = JSON.stringify(data)
      if(this.howTo == 'creditCard')
        this.navCtrl.push(MyCardsPage)
      else
        this.navCtrl.push(VendorsListPage, {process: 'ADD'} )
    } else
      this.service.presentToast('Your internet connection seems to be lost')
  }
}
