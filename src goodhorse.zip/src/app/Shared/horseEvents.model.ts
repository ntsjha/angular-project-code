export class HorseEvents{
    id:string
    s_no:string
    type:string
    name:string
    start_Date:string
    end_Date:string
    start_Time: string
    end_Time:string
    venue:string
    address:string
    city_Town:string
    country:string
}