import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MinimumWithdrawlFiatComponent } from './minimum-withdrawl-fiat.component';

describe('MinimumWithdrawlFiatComponent', () => {
  let component: MinimumWithdrawlFiatComponent;
  let fixture: ComponentFixture<MinimumWithdrawlFiatComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MinimumWithdrawlFiatComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MinimumWithdrawlFiatComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
