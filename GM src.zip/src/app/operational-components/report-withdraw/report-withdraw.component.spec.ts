import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportWithdrawComponent } from './report-withdraw.component';

describe('ReportWithdrawComponent', () => {
  let component: ReportWithdrawComponent;
  let fixture: ComponentFixture<ReportWithdrawComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReportWithdrawComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReportWithdrawComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
