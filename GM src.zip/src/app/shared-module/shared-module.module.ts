import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RecaptchaModule } from 'ng-recaptcha';
import { HttpClientModule } from '@angular/common/http';
import { CookieService } from 'ngx-cookie-service';
import { NgxSpinnerModule } from 'ngx-spinner';
import { NgxPaginationModule } from 'ngx-pagination';
import { MyDatePickerModule } from 'mydatepicker';


@NgModule({
    declarations: [],
    imports: [],
    exports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        RecaptchaModule,
        HttpClientModule, 
        NgxSpinnerModule,
        NgxPaginationModule,
        MyDatePickerModule,
    ], providers: [CookieService]
})
export class SharedModuleModule { }
