import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SettingNewPage } from './setting-new';

@NgModule({
  declarations: [
    SettingNewPage,
  ],
  imports: [
    IonicPageModule.forChild(SettingNewPage),
  ],
})
export class SettingNewPageModule {}
