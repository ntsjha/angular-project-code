import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-tradeaction',
    templateUrl: './tradeaction.component.html',
    styleUrls: ['./tradeaction.component.css']
})
export class TradeactionComponent implements OnInit {

    constructor() { }

    ngOnInit() {
        window.scrollTo(0, 0);
    }

}
