import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { LoginComponent } from './Pages/login/login.component';
import { AppRoutingModule } from './app-routing.module';


// ************ Module**************
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { environment } from '../environments/environment';
import { AngularFireModule } from "@angular/fire";
import { AngularFirestoreModule } from "@angular/fire/firestore";
import { ServiceService } from './Shared/service.service';
import { AngularFireDatabaseModule } from 'angularfire2/database';
import { AngularFireAuthModule } from 'angularfire2/auth';
import { AuthGuard } from './Shared/auth.guard';
import { HttpClientModule } from '@angular/common/http';
import {NgxPaginationModule} from 'ngx-pagination';
import { NgxSpinnerModule } from 'ngx-spinner';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ToastrModule } from 'ngx-toastr';
import { MyDatePickerModule } from 'mydatepicker';
import { CKEditorModule } from 'ngx-ckeditor';
import {CalendarModule} from 'primeng/calendar';
import { SweetAlert2Module } from '@sweetalert2/ngx-sweetalert2';
import { FirestoreSettingsToken} from '@angular/fire/firestore';
import { FilterPipeModule } from 'ngx-filter-pipe';

// ************ Component **************
import { ViewSettingsComponent } from './Pages/view-settings/view-settings.component';
import { SubscriptionPlanComponent } from './Pages/subscription-plan/subscription-plan.component';
import { AddSettingComponent } from './Pages/add-setting/add-setting.component';
import { AddSubscriptionplanComponent } from './Pages/add-subscriptionplan/add-subscriptionplan.component';
import { EditSubscriptionPlanComponent } from './Pages/edit-subscription-plan/edit-subscription-plan.component';
import { ViewFeedTypeComponent } from './Pages/view-feed-type/view-feed-type.component';
import { DashboardComponent } from './Pages/dashboard/dashboard.component';
import { UserManagementComponent } from './Pages/user-management/user-management.component';
import { ContributorManagementComponent } from './Pages/contributor-management/contributor-management.component';
import { TrainingManagementComponent } from './Pages/training-management/training-management.component';
import { SettingComponent } from './Pages/setting/setting.component';
import { SidebarComponent } from './Pages/sidebar/sidebar.component';
import { HeaderComponent } from './Pages/header/header.component';
import { FooterComponent } from './Pages/footer/footer.component';
import { UserManagementViewComponent } from './Pages/user-management-view/user-management-view.component';
import { ContributorManagementViewComponent } from './Pages/contributor-management-view/contributor-management-view.component';
import { AddContributorManagementComponent } from './Pages/add-contributor-management/add-contributor-management.component';
import { EditContributorManagementComponent } from './Pages/edit-contributor-management/edit-contributor-management.component';
import { AddTemplateComponent } from './Pages/add-template/add-template.component';
import { AddActivityComponent } from './Pages/add-activity/add-activity.component';
import { EditTemplateComponent } from './Pages/edit-template/edit-template.component';
import { HorseDetailsComponent } from './Pages/horse-details/horse-details.component';
import { EditActivityComponent } from './Pages/edit-activity/edit-activity.component';
import { TemplateDetailsComponent } from './Pages/template-details/template-details.component';
import { ViewActivityComponent } from './Pages/view-activity/view-activity.component';
import { TrainingDetailsComponent } from './Pages/training-details/training-details.component';
import { StaticContentComponent } from './Pages/static-content/static-content.component';
import { ViewStaticContentComponent } from './Pages/view-static-content/view-static-content.component';
import { EditStaticContentComponent } from './Pages/edit-static-content/edit-static-content.component';
import { AddFAQsComponent } from './Pages/add-faqs/add-faqs.component';
import { EditStaticFAQComponent } from './Pages/edit-static-faq/edit-static-faq.component';
import { FeatureListComponent } from './Pages/feature-list/feature-list.component';
import { AddFeatureListComponent } from './Pages/add-feature-list/add-feature-list.component';
import { EditFeatureListComponent } from './Pages/edit-feature-list/edit-feature-list.component';
import { PageNotFoundComponent } from './Pages/page-not-found/page-not-found.component';
import { UserGuideComponent } from './Pages/user-guide/user-guide.component';
import { AddUserGuideComponent } from './Pages/add-user-guide/add-user-guide.component';
import { EditUserGuideComponent } from './Pages/edit-user-guide/edit-user-guide.component';
import { TackMangementComponent } from './Pages/tack-mangement/tack-mangement.component';

@NgModule({
  declarations: [
    
    AppComponent,
    LoginComponent,
    DashboardComponent,
    UserManagementComponent,
    ContributorManagementComponent,
    TrainingManagementComponent,
    SettingComponent,
    SidebarComponent,
    HeaderComponent,
    FooterComponent,
    UserManagementViewComponent,
    ContributorManagementViewComponent,
    AddContributorManagementComponent,
    EditContributorManagementComponent,
    AddTemplateComponent,
    AddActivityComponent,
    EditTemplateComponent,
    HorseDetailsComponent,
    EditActivityComponent,
    TemplateDetailsComponent,
    ViewActivityComponent,
    TrainingDetailsComponent,
    ViewSettingsComponent,
    SubscriptionPlanComponent,
    AddSettingComponent,
    AddSubscriptionplanComponent,
    EditSubscriptionPlanComponent,
    ViewFeedTypeComponent,
    StaticContentComponent,
    ViewStaticContentComponent,
    EditStaticContentComponent,
    AddFAQsComponent,
    EditStaticFAQComponent,
    FeatureListComponent,
    AddFeatureListComponent,
    EditFeatureListComponent,
    PageNotFoundComponent,
    UserGuideComponent,
    AddUserGuideComponent,
    EditUserGuideComponent,
    TackMangementComponent,
    
    
    
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    NgxPaginationModule,
    FormsModule,
    ReactiveFormsModule,
    AngularFirestoreModule,
    AngularFireAuthModule,
    NgxSpinnerModule,
    HttpClientModule,    
    AngularFireDatabaseModule,
    MyDatePickerModule,
    CalendarModule,
    SweetAlert2Module.forRoot({
      buttonsStyling: false,
      customClass: 'modal-content',
      confirmButtonClass: 'btn btn-primary',
      cancelButtonClass: 'btn'
  }),
    ToastrModule.forRoot({preventDuplicates: true,
      timeOut: 3000,
      progressAnimation:'decreasing',
      progressBar:true,
      closeButton:true,
      maxOpened:1}),
      CKEditorModule,
    AngularFireModule.initializeApp(environment.firebase),
    FilterPipeModule
  ],
  
  providers: [{provide: FirestoreSettingsToken, useValue: {}},ServiceService,AuthGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
