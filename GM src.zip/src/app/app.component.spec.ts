import { TestBed, async } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppComponent } from './app.component';
import { DeviceDetectorModule } from 'ngx-device-detector';
import { NgxSpinnerModule } from 'ngx-spinner';
import { NgxPaginationModule } from 'ngx-pagination';
import { MyDatePickerModule } from 'mydatepicker';
import { SharedModuleModule } from './shared-module/shared-module.module';
import { ServiceService, HttpModifierInterceptor } from './service/service.service';
import { CookieService } from 'ngx-cookie-service';
import { DatePipe } from '@angular/common';
import { HTTP_INTERCEPTORS } from '@angular/common/http';

declare var $: any;

describe('AppComponent', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        DeviceDetectorModule.forRoot(),
        NgxSpinnerModule,
        NgxPaginationModule,
        MyDatePickerModule,
        SharedModuleModule,
      ],
      declarations: [
        AppComponent,
      ],
      providers: [ServiceService, CookieService, DatePipe,
        {
            provide: HTTP_INTERCEPTORS,
            useClass: HttpModifierInterceptor,
            multi: true
        },
    ],
    }).compileComponents();
  }));

  it('should create the app', () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  });


});
