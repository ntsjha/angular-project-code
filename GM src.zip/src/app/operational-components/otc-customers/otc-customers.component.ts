import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Subject } from 'rxjs';
import { ServiceService } from 'src/app/service/service.service';
import { Router } from '@angular/router';
import { AngularCsv } from 'angular7-csv/dist/Angular-csv';

@Component({
    selector: 'app-otc-customers',
    templateUrl: './otc-customers.component.html',
    styleUrls: ['./otc-customers.component.css']
})
export class OtcCustomersComponent implements OnInit {
    otcList: any = [];
    disable: boolean = false;
    page: any = 1;
    searchTerm$ = new Subject<string>();
    status: any;
    search_key: any = '';
    pageSize: any = '10';
    marketList: any = [];
    constructor(public service: ServiceService, public router: Router) {
        this.service.search(this.searchTerm$).subscribe(results => {
            this.search_key = results;
        });
    }

    ngOnInit() {
        window.scrollTo(0, 0);
        this.getTicketList();
    }

    getTicketList() {
        this.service.postMethod('', {}, 1).subscribe((res) => {
            if (res.data) {
                this.otcList = res.data;
            }
        });
    }

    closeModal() {
        this.disable = false;
    }

    viewDetail(id) {
    }

    filterBySearch() {
        if (this.search_key || this.status) {
            this.otcList = [];
            let data = {
                "page": this.service.encrypt(this.page),
                "pageSize": this.service.encrypt(this.pageSize),
                "search": this.service.encrypt(this.search_key),
                "status": this.service.encrypt(this.status)
            };

            if (this.search_key) {
                data['search'] = this.service.encrypt(this.search_key);
            } else {
                data['search'] = null;
            }

            if (this.status) {
                data['status'] = this.service.encrypt(this.status);
            } else {
                data['status'] = null;
            }

            this.service.postMethod('', data, 1).subscribe((res) => {
                if (res.data.list) {
                    this.otcList = res.data.list;
                }
                this.status = '';
            });
        }
    }

    onStatusChange(val) {
        this.status = val;
    }

    exportList() {
        var options = {
            fieldSeparator: ',',
            quoteStrings: '"',
            decimalseparator: '.',
            showLabels: true,
            showTitle: true,
            title: 'Market List :',
            useBom: true,
            noDownload: false,
            headers: ['Customer Id', 'Customer Name', 'Customer Email', 'Customer Phone', 'Type Of Customer']
        };

        let data = [];

        this.otcList.forEach((element, index) => {
            let obj = {
                'cust_id': index + 1,
                'cust_name': element.subject,
                'cust_email': element.date,
                'cust_phone': element.customerName || '---',
                'cust_type': element.customerEmail || '---',
            };
            data.push(obj);
        });
        new AngularCsv(data, 'Tickets', options);
    }

}
