import { Component, OnInit } from '@angular/core';
import { ServiceService } from 'src/app/Shared/service.service';
import { Employee } from 'src/app/Shared/employee.model';
import { Contributor } from 'src/app/Shared/Contributor.model';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  val: any
  userCount: number;
  countributorCount: number;
  totalTrainingTemplate: any;
  constructor(private service : ServiceService) {   }

  ngOnInit() {
    // this.val = this.cookieService.get('username')
    // console.log(this.val);
    // this.service.showSuccess('Successfully Login');
    this.getUserCount();
    this.getCountributorCount();
    this.getTemplateCount();
  }


  // Get User Count Functionality
  getUserCount(){
    this.service.showSpinner();
    this.service.getEmployees().subscribe(actionArray => {
      // console.log('=========>', actionArray)
      var userList = actionArray.map(item => {
        // console.log('Items====>', item)
        return {
          id: item.payload.doc.id,
          ...item.payload.doc.data()

        } as Employee;

      })
      this.service.hideSpinner();
      this.userCount = userList.length;
      console.log("user Count--->>>",this.userCount)
    });
  }

  // Get Contributor Count 
  getCountributorCount(){
    this.service.showSpinner() ;   
    this.service.getContributor().subscribe(res =>{
      // console.log(res)
      var countributorList = res.map(item => {
      //  console.log('Items====>', item)
       return {
         id: item.payload.doc.id,
         ...item.payload.doc.data()
       } as Contributor;
     })
     this.service.hideSpinner();
      this.countributorCount = countributorList.length
      console.log("countributor Count--->>>",this.countributorCount)
     });
  }

   // Get Template Count
    getTemplateCount(){
      this.service.showSpinner();
      this.service.getAdminTrainingTemplate().subscribe(res=>{
        var trainingList = res.map(item => {        
          return {
            id: item.payload.doc.id,
            ...item.payload.doc.data()
          };
        })
        this.totalTrainingTemplate = trainingList.length;
      })
    }

}
