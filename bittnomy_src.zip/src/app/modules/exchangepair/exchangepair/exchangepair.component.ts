import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { AppComponent } from '../../../app.component';
import { ServerService } from '../../../service/server.service';
import { HeaderComponent } from '../../header/header/header.component';

@Component({
    selector: 'app-exchangepair',
    templateUrl: './exchangepair.component.html',
    styleUrls: ['./exchangepair.component.css']
})
export class ExchangepairComponent implements OnInit {
    webNamesArr = [{
        "websiteName": "Poloniex",
        "status": "2",
        "active": "false"
    },
    {
        "websiteName": "Binance",
        "status": "1",
        "active": "false"
    },
    {
        "websiteName": "HitBTC",
        "status": "3",
        "active": "false"
    }
    ]
    coinListArr: any = [];
    coinPairListArr: any = [];
    currentCoinObj = { coinShort: "", coinFullName: "", coinId: "" };
    searchText = "";
    symbolArr: any = [];
    PoloArr: any = [];
    poloniexTradePair: any;
    SocketDataStatus: any = false;
    currentPairCoinObj = { coinShort: "", coinFullName: "", coinId: "" };
    polo_id: any;
    HitBTCPair: any;
    hitbtcIntervalID: any;
    arr: any;
    clearInt: any;
    binanceSocket: any;
    getPoloniexIntervalID: any;

    constructor(private router: Router, private appC: AppComponent, private server: ServerService, private spinnerService: Ng4LoadingSpinnerService, private header: HeaderComponent) {
    }

    ngOnInit() {
        window.scrollTo(0, 0);
        this.header.getprofile();
        // this.getLiquidityWebsite();
        this.getCoinList();
    }

    /** Function to get coin list from api */
    getCoinList() {
        this.spinnerService.show();
        this.server.getApi('wallet/coin/get-coin-list', 0).subscribe((succ) => {
            this.spinnerService.hide();
            if (succ.body.status == 200) {
                let data = succ.body.data;
                this.coinListArr = data.filter((x) => x.coinType=="crypto" && (x.coinShortName == 'IPR' ||x.coinShortName == 'BTC' || x.coinShortName == 'ETH' || x.coinShortName == 'USDT'));
                this.coinListArr.filter((x) => this.getCoinPair(x.coinShortName))
                this.currentCoinObj.coinId = this.coinListArr[0].coinId;
                this.currentCoinObj.coinShort = this.coinListArr[0].coinShortName;
                this.currentCoinObj.coinFullName = this.coinListArr[0].coinFullName;
                this.clearInt = setTimeout(() =>{
                    this.connectSocket();
                },3000)
            } else {
                this.appC.showErrToast(succ.body.message);
            }
        }, (err) => {
            this.spinnerService.hide();
        });
        
    }

    /** Function to get coin pair list from api*/
    getCoinPair(coinShortName) {
        this.coinPairListArr = [];
        this.spinnerService.show();
        this.server.getApi('wallet/coin/get-coin-pair-list?baseCoin=' + coinShortName, 0).subscribe((succ) => {
            this.spinnerService.hide();
            if (succ.body.status == 200) {
                let data = [];
                this.coinPairListArr = [];
                succ.body.data.forEach(obj => {
                    if (obj.coinShortName == 'BTC' || obj.coinShortName == 'ETH' || obj.coinShortName == 'XRP' || obj.coinShortName == 'BCH' || obj.coinShortName == 'XLM' || obj.coinShortName == 'LTC' || obj.coinShortName == 'IOTA' || obj.coinShortName == 'USDT' || obj.coinShortName == 'XVG' || obj.coinShortName == 'IPR' || obj.coinShortName == 'ECH') {
                        data.push(obj);
                    }
                });
                let ind = this.coinListArr.findIndex((x) => x.coinShortName == coinShortName);
                if (ind > -1) {
                    this.coinListArr[ind].pairList = data;
                    this.coinListArr[ind].pairList.forEach((obj) => {
                        obj.last_price = '0.0';
                    });
                }

                console.log('data--->',data)
                console.log('coinshorname--->',coinShortName)
            } else {
                this.coinPairListArr = [];
                this.appC.showErrToast(succ.transferObjectMap.message);
            }
        }, (err) => {
            this.spinnerService.hide();
        });
    }

    connectSocket() {
    
        if (this.coinListArr.length == 4) {
            this.getCoinSymbol(this.coinListArr);
            if (this.server.activatedSocket == "Binance") {
               
                this.callCoinListWithSocket(this.server.activatedSocket, 1);
                this.getLiquidityData();
                console.log('Binance')
                
            } else if (this.server.activatedSocket == "Poloniex") {
                // this.server.thirdPartySocket();
                this.getPoloniexTickerData();
                console.log('Polinix')
            } else if (this.server.activatedSocket == "HitBTC") {
                this.server.thirdPartySocket();
                this.getLiveDataFromHitBTCForCoinPair();
                console.log('Hitbc')
            }
        }
       
    }

    closeSocketFunc() {
        if (this.server.activatedSocket == "Binance") {
            this.server.liquidityWSTicker.forEach((element, i) => {
                this.server.liquidityWSTicker[i].close();
            });
            setInterval((x)=>{
                this.callCoinListWithSocket(this.server.activatedSocket, 1);
                this.getLiquidityData();
            },1000000)
        }

    }

    /** to get liquidity data */
    getLiquidityData() {
        var self = this;
        this.server.fireToChild().subscribe(message => {
            if (message.text == "liquidity") {
                let len = this.server.liquidityWSTicker.length;
                for (let i = 0; i < len; i++) {
                    this.server.liquidityWSTicker[i].addEventListener('message', function (event) {
                        self.SocketDataStatus = true;
                        let data = JSON.parse(event.data);
                        let str = data.s.replace(self.coinListArr[0].coinShortName, '');
                        let indPair = self.coinListArr[0].pairList.findIndex(obj => obj.coinShortName == str);
                        if (indPair != -1) {
                            self.coinListArr[0].pairList[indPair].last_price = Number(data.o).toFixed(5);
                            self.coinListArr[0].pairList[indPair].volume = Number(data.v).toFixed(5);
                            self.coinListArr[0].pairList[indPair].max_price = Number(data.h).toFixed(5);
                            self.coinListArr[0].pairList[indPair].min_price = Number(data.l).toFixed(5);
                            self.coinListArr[0].pairList[indPair].average = ((Number(data.h) + Number(data.l)) / 2).toString();

                        }
                        let indPair1 = self.coinListArr[1].pairList.findIndex(obj => obj.coinShortName == str);
                        if (indPair1 != -1) {
                            self.coinListArr[1].pairList[indPair1].last_price = Number(data.o).toFixed(5);
                            self.coinListArr[1].pairList[indPair1].volume = Number(data.v).toFixed(5);
                            self.coinListArr[0].pairList[indPair].max_price = Number(data.h).toFixed(5);
                            self.coinListArr[0].pairList[indPair].min_price = Number(data.l).toFixed(5);
                            self.coinListArr[1].pairList[indPair1].average = ((Number(data.h) + Number(data.l)) / 2).toString();
                        }
                        let indPair2 = self.coinListArr[2].pairList.findIndex(obj => obj.coinShortName == str);
                        if (indPair2 != -1) {
                            self.coinListArr[2].pairList[indPair2].last_price = Number(data.o).toFixed(5);
                            self.coinListArr[2].pairList[indPair2].volume = Number(data.v).toFixed(5);
                            self.coinListArr[0].pairList[indPair].max_price = Number(data.h).toFixed(5);
                            self.coinListArr[0].pairList[indPair].min_price = Number(data.l).toFixed(5);
                            self.coinListArr[2].pairList[indPair2].average = ((Number(data.h) + Number(data.l)) / 2).toString();
                        }
                        let indPair3 = self.coinListArr[3].pairList.findIndex(obj => obj.coinShortName == str);
                        if (indPair3 != -1) {
                            self.coinListArr[3].pairList[indPair3].last_price = Number(data.o).toFixed(5);
                            self.coinListArr[3].pairList[indPair3].volume = Number(data.v).toFixed(5);
                            self.coinListArr[0].pairList[indPair].max_price = Number(data.h).toFixed(5);
                            self.coinListArr[0].pairList[indPair].min_price = Number(data.l).toFixed(5);
                            self.coinListArr[3].pairList[indPair3].average = ((Number(data.h) + Number(data.l)) / 2).toString();
                        }
                    });
                }
                this.binanceSocket = setInterval((obj)=> { 
                    this.closeSocketFunc();
                },90000)
            } else if (message.text == "Poloniex") {
                let symbolArray = [];
                self.PoloArr.forEach(obj => {
                    this.symbolArr.forEach(element => {
                        if (element == obj.pair) {
                            symbolArray.push({
                                pair: element,
                                id: obj.id
                            })
                        }
                    });
                });
                //this.callPolyneixSocket(1);
                this.server.liquidityWSPoloneix.addEventListener('message', function (event) {
                    self.SocketDataStatus = true;
                    let data = JSON.parse(event.data);
                    if (data.error == "Invalid channel") {
                        //self.callPolyneixSocket(2)
                        self.SocketDataStatus = false;
                    }
                    if (data.length > 2 && data[0] == 1002) {
                        let tickerArr = data[2];
                        symbolArray.forEach(obj => {
                            if (obj.id == tickerArr[0]) {
                                let arr = data[2];
                                let currPairArr = self.coinListArr.filter(ob => ob.coin == obj.pair.split('_')[1]);
                                currPairArr[0].pairList.last_price = arr[1];
                                currPairArr[0].pairList.volume = arr[5];
                                currPairArr[0].pairList.average = ((Number(arr[8]) + Number(arr[9])) / 2).toString();
                            }
                        });

                    }
                    if (data[0] == 1010) {
                        self.SocketDataStatus = false;
                    }
                })
            } else if (message.text == "HitBTC") {
                this.updateLiquiditySocket(1);
                this.server.liquidityWSHitBTC.addEventListener('message', function (event) {
                    let data = JSON.parse(event.data);
                    if (data.params) {
                        self.SocketDataStatus = true;
                        switch (data.method) {
                            case "ticker":
                                /** Code to set coin pair list data as per selected pair */
                                let currPairArr = self.coinPairListArr.filter(obj => obj.coin == self.currentPairCoinObj.coinShort);
                                if (currPairArr.length) {
                                    currPairArr[0].pairList.last_price = data.params.last;
                                    currPairArr[0].pairList.volume = data.params.volume;
                                    currPairArr[0].pairList.average = ((Number(data.params.high) + Number(data.params.high)) / 2).toString();
                                }

                                break;
                        }
                    }
                    if (data.error) {
                        if (data.error.code == 2001) {
                            self.SocketDataStatus = false;
                            /** Code to set coin pair list data as per selected pair */
                            let currPairArr = self.coinPairListArr.filter(obj => obj.coin == self.currentPairCoinObj.coinShort);
                            if (currPairArr.length) {
                                currPairArr[0].last_price = 0.000000;
                                currPairArr[0].volume = 0.000000;
                                currPairArr[0].average = 0.000000;
                            }
                        }
                    }
                });
            }
        });
    }

    toUpperCaseFunc(str) {
        return str.toUpperCase();
    }

    goToMarket(base, exe) {
        this.router.navigateByUrl('header/exchange/' + base + '/' + exe);
    }

    /** to get liquidity website */
    getLiquidityWebsite() {
        let data = {
            "eventExternal": {
                "name": "request_get_liquidity-website",
                "key": "mykey"
            },
            "transferObjectMap": {
                "gatewayrequest": {}
            }
        }
        this.spinnerService.show();
        this.server.postApi('', data, 0).subscribe(succ => {
            this.spinnerService.hide();
            if (succ.transferObjectMap.statusCode == 200) {
                let status = succ.transferObjectMap.Liquidity_status;
                let index = this.webNamesArr.findIndex(x => x.status == status)
                this.server.activatedSocket = this.webNamesArr[index].websiteName;
            }
        }, error => {
            this.spinnerService.hide();
            this.appC.showErrToast('Something went wrong');
        })
    }

    /** Function to fetch coin symbol */
    getCoinSymbol(arr) {
        this.arr = arr;
        this.symbolArr = [];
        if (this.server.activatedSocket == "Poloniex") {
            arr.forEach((obj) => {
                obj.pairList.forEach(element => {
                    this.symbolArr.push(obj.coinShortName + '_' + (element.coinShortName == 'ECH' ? "ETC" : element.coinShortName));
                });
            });
            return this.symbolArr;
        } else if (this.server.activatedSocket == "Binance") {
            arr.forEach((obj) => {
                obj.pairList.forEach(element => {
                    this.symbolArr.push((element.coinShortName == 'ECH' ? "ETC" : element.coinShortName) + obj.coinShortName);
                });
            });

            return this.symbolArr;
        } else {
            arr.forEach((obj) => {
                obj.pairList.forEach(element => {
                    if (obj.coinShortName == "USD") {
                        if (element.coinShortName == "XRP") {
                            this.symbolArr.push('symbolArr',element.coinShortName + "USDT");
                        } else {
                            this.symbolArr.push('symbolArr',element.coinShortName + obj.coinShortName);
                        }
                    } else {
                        this.symbolArr.push(element.coinShortName + obj.coinShortName);
                    }
                });
            });
            return this.symbolArr;
        }
    }

    /** for polyneix socket */
    callPolyneixSocket(type) {
        let data = {
            "command": "",
            "channel": 1002
        }
        switch (type) {
            case 1:
                data.command = "subscribe";
                this.server.liquidityWSPoloneix.send(JSON.stringify(data));
                break;
            case 2:
                data.command = "unsubscribe";
                this.server.liquidityWSPoloneix.send(JSON.stringify(data));
                break;
        }
    }

    /** Function for socket subscribe/unsubcribe */
    updateLiquiditySocket(type) {
        let data = {
            "method": "",
            "params": {
                "symbol": this.HitBTCPair,
                "limit": ""
            },
            "id": ""
        }
        switch (type) {
            case 1:
                if (this.server.liquidityWSHitBTC.readyState) {
                    data.method = "subscribeTicker";
                    this.server.liquidityWSHitBTC.send(JSON.stringify(data));
                }

                break;
            case 2:
                if (this.server.liquidityWSHitBTC.readyState) {
                    data.method = "unsubscribeTicker";
                    this.server.liquidityWSHitBTC.send(JSON.stringify(data));
                }
                break;
        }
    }

    callCoinListWithSocket(msg, type) {
        switch (msg) {
            case 'Binance':
                switch (type) {
                    case 1:
                        let i = 0;
                        this.symbolArr.forEach(element => {
                            element = element.toLowerCase();
                            this.server.binanceTickerFunc(element, i);
                            i++;
                        });
                        break;
                    case 2:
                        this.server.liquidityWSTicker.close();
                        break;
                }
                break;
        }
    }

    /** Function to get live data for other pair */
    getLiveDataFromHitBTCForCoinPair() {
        this.server.getHitBTCTickerDataJson().subscribe((res) => {
            console.log(res);
        })
    }

    /** Function to start interval for getting latest value for pair */
    startInterval(symbolArr) {
        this.hitbtcIntervalID = setInterval((obj) => {
            let data = {
                "url": "https://api.hitbtc.com/api/2/public/ticker",
                "symbols": symbolArr
            }
            this.server.postApi("/wallet/coin/get-live-market-data",data, localStorage.getItem('token')).subscribe((succ) => {
                if(succ.status == 200) {
                    this.coinListArr.forEach((obj) => {
                        var ind = succ.data.findIndex((data) => data.symbol.substring(0,3) == obj.coin);
                        if(ind != -1) {
                            obj.last_price = succ.data[ind].last;
                            obj.volume = succ.data[ind].volume;
                            obj.average = (Number(succ.data[ind].low) + Number(succ.data[ind].high))/2;
                        }
                    });
                } else {
                    this.appC.showErrToast(succ.message);
                }
            }, (err) => {
                this.appC.showErrToast(err.error.message);
            });
        },10000);
    }

    /** Function to stop interval for getting latest value for pair */
    stopInterval() {
        clearInterval(this.hitbtcIntervalID);
    } 
    /**to call on destroy */
    ngOnDestroy() {
        if (this.server.activatedSocket == "Binance") {
            this.server.liquidityWSTicker.forEach((element, i) => {
                this.server.liquidityWSTicker[i].close();
            });


        }
        clearInterval(this.clearInt);
        clearInterval(this.binanceSocket);
        clearInterval(this.getPoloniexIntervalID);
    }

    /**Function to get poloniex ticker data */
    getPoloniexTickerData() {
        this.getPoloniexIntervalID = setInterval((obj) => {
        this.server.getPoloniexTickerDataJson().subscribe((res) => {
            this.coinListArr.forEach(element => {
                element.pairList.forEach(obj => {
                    for(var key in res) {
                        if(key == element.coinShortName+'_'+obj.coinShortName) {
                            obj.last_price = Number(res[key].last).toFixed(8);
                            obj.volume = Number(res[key].quoteVolume).toFixed(8);
                            obj.max_price = Number(res[key].high24hr).toFixed(8);
                            obj.min_price = Number(res[key].low24hr).toFixed(8);
                            obj.average = ((Number(res[key].high24hr) + Number(res[key].low24hr)) / 2).toString();
                        }
                    }
                });
            });
        } );
    },1000);
    }

}
