import { Component, OnInit } from '@angular/core';
import { ServiceService } from 'src/app/service/service.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { Router } from '@angular/router';

@Component({
  selector: 'app-minimum-deposit',
  templateUrl: './minimum-deposit.component.html',
  styleUrls: ['./minimum-deposit.component.css']
})
export class MinimumDepositComponent implements OnInit {
  depositeFiat: any [];
  depositeCrypto: any [];

  constructor(
    private service: ServiceService, 
    private spinner: NgxSpinnerService,
    private route: Router
  ) { }

  ngOnInit() {
    this.getDepositCrypto();
    window.scrollTo(0, 0);
  }

  goToMinDepositCrypto(coinName) {
  this.route.navigate(['/minimum-deposit-crypto/' + coinName]);
  }

  goToMinDepositeFiat(id, coinName) {
    this.route.navigate(['/minimum-deposit-fiat/' + id + '/' + coinName]);
  }

  getDepositFiat() {
    this.spinner.show();
    this.service.getMethod('wallet/admin/fees/get-withdraw-fee-details?currencyType=fiat', 1).subscribe((response: any) => {
        this.spinner.hide();
        if (response.status === 845 || response.status === 842) {
          this.depositeFiat = response.data;
        }
        this.depositeFiat = JSON.parse(this.service.decrypt(response.data)).data;
      }, (error) => {
        this.spinner.hide();
    });
    this.spinner.hide();
  }

  getDepositCrypto() {
    this.spinner.show();
    this.service.getMethod('wallet/admin/fees/get-withdraw-fee-details?currencyType=crypto', 1).subscribe((response: any) => {
        this.spinner.hide();
        if (response.status === 845 || response.status === 842) {
          this.depositeCrypto = response.data;
        }
        this.depositeCrypto = JSON.parse(this.service.decrypt(response.data)).data;
        this.depositeCrypto.forEach(element => {
          if(element.updatedByName == null) {
            element.updatedAt = null;
          }
        });
        
    }, (error) => {
        this.spinner.hide();
    });
    this.spinner.hide();
  }
}
