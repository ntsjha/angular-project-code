import { Component, OnInit, OnDestroy } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { ServiceService } from 'src/app/service/service.service';
import { FormGroup, FormBuilder } from '@angular/forms';

@Component({
    selector: 'app-logs',
    templateUrl: './logs.component.html',
    styleUrls: ['./logs.component.css']
})
export class LogsComponent implements OnInit, OnDestroy {
    getLogs: any = [];
    page: any = 0;
    p: any = 1;
    total: any;
    filterFunction: FormGroup;

    constructor(private spinner: NgxSpinnerService, private service: ServiceService, private fb: FormBuilder) {
        this.filterFunction = this.fb.group({
            search: [null],
        });
    }

    ngOnInit() {
        this.getActivityLogs();
        window.scrollTo(0, 0);
    }

    ngOnDestroy() {
        this.service.email = null;
    }

    search() {
        this.p = 1;
        this.page = 0;
        this.getActivityLogs();
    }

    /** Function to get activity logs */
    getActivityLogs() {
        this.spinner.show();
        this.getLogs = [];
        this.total = 0;
        const data = {
            page: this.service.encrypt(this.page),
            pageSize: this.service.encrypt(String('10')),
            search: (this.filterFunction.value.search == null) ? ((this.service.email != null) ? this.service.encrypt(this.service.email) : null) : this.service.encrypt(this.filterFunction.value.search.trim()),
        };
        this.service.postMethod('account/superAdmin/user-management/search-and-filter-admins-and-staffs-activity-logs', data, 1)
            .subscribe((response: any) => {
                let responseData = this.service.decrypt(response.data);
                responseData = JSON.parse(responseData);
                this.p  = this.page + 1;
                if (responseData.status === 928) {
                    if (responseData.data.list) {
                        this.getLogs = responseData.data.list;
                        this.total = responseData.data.size;
                    }
                    this.spinner.hide();
                } else {
                    this.spinner.hide();
                }
            }, (error) => {
                this.spinner.hide();
            });
    }

    changePage(page) {
        this.p = page;
        this.page = page - 1;
        this.getActivityLogs();
    }


    resetFunc() {
        this.filterFunction.patchValue({
            search: null
        });
        this.p = 1;
        this.page = 0;
        this.getActivityLogs();
    }

}
