import { Component, OnInit, AfterViewInit, NgZone, OnDestroy } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ServiceService } from 'src/app/service/service.service';
import { CookieService } from 'ngx-cookie-service';
import { NgxSpinnerService } from 'ngx-spinner';
import { ActivatedRoute, Router } from '@angular/router';
import { AppComponent } from 'src/app/app.component';

declare var $: any;

@Component({
    selector: 'app-edit-staff',
    templateUrl: './edit-staff.component.html',
    styleUrls: ['./edit-staff.component.css']
})
export class EditStaffComponent implements OnInit, OnDestroy {
    editStaff: FormGroup;
    userIp: any;
    showApiMessage: any = false;
    response: any = {};
    google: any = { one: '', two: '', three: '', four: '', five: '', six: '' };
    OTPPhoneValidOrNot: any = true;
    setPermissionArray = [];
    staffDetails: any;
    originalPermission = [];
    subscription: any;
    arr: any[];
    countryList: any;

    constructor(
        private service: ServiceService,
        private cookie: CookieService,
        private spinner: NgxSpinnerService,
        private activatedRoute: ActivatedRoute,
        private zone: NgZone,
        private appC: AppComponent,
        private router: Router,
    ) {
        this.editStaff = new FormGroup({
            firstName: new FormControl('', [Validators.required, Validators.pattern(/^[a-z ,.'-]+$/i), Validators.maxLength(255), Validators.minLength(2)]),
            lastName: new FormControl('', [Validators.required, Validators.pattern(/^[a-z ,.'-]+$/i), Validators.maxLength(255), Validators.minLength(2)]),
            email: new FormControl('', [Validators.required, Validators.pattern(/^[a-zA-Z0-9_+&*-]+(?:\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,7}$/), Validators.maxLength(256)]),
            phone: new FormControl('', [Validators.required, Validators.pattern(/^[0-9]*$/), Validators.maxLength(15)]),
            gender: new FormControl('', [Validators.required]),

        });
        this.userIp = (this.cookie.get('userInfo')) ? JSON.parse(this.cookie.get('userInfo')) : this.service.initialUserInfo;
        this.subscription = this.service.authVerify.subscribe(val => {
            if (val === 'edit-staff') {
                this.editStaffFunc();
                this.service.authVerify.next('false');
            }
        });
        this.service.getCountryList()
            .subscribe((data) => {
                this.countryList = data;
            }, (error) => {
            });
    }

    /** Function to get input data */
    get firstName(): any {
        return this.editStaff.get('firstName');
    }

    get lastName(): any {
        return this.editStaff.get('lastName');
    }

    get email(): any {
        return this.editStaff.get('email');
    }

    get phone(): any {
        return this.editStaff.get('phone');
    }

    get gender(): any {
        return this.editStaff.get('gender');
    }

    /** Function to send value */
    editAdminTest(...val) {
        this.editStaff.controls.firstName.setValue(val[0]);
        this.editStaff.controls.lastName.setValue(val[1]);
        this.editStaff.controls.email.setValue(val[2]);
        this.editStaff.controls.phone.setValue(val[3]);
        this.editStaff.controls.gender.setValue(val[4]);
        return this.editStaff.valid;
    }

    /** Function to verify google authentication */
    verifyGoogleAuth() {
        if (this.editStaff.invalid) {
            return;
        }
        let count = 0;
        for (let i = 0; i < this.setPermissionArray.length; i++) {
            count = 0;
            const index = this.originalPermission.findIndex((x) => x.masterPermissionList.masterPermissionListId === this.setPermissionArray[i].masterPermissionList.masterPermissionListId)
            if (!this.originalPermission[index].masterPermissionList.isMenu) {
                const parentId = this.originalPermission[index].masterPermissionList.parentId;
                const parentExsits = this.setPermissionArray.findIndex((x) => x.masterPermissionList.masterPermissionListId == parentId);
                if (parentExsits == -1) {
                    const mx = document.getElementById('#permission' + parentId);
                    mx.style.color = 'red';
                    count++;
                }
            }
            if (count != 0) {
                window.scrollTo(0, 0);
                $('#confirmation-modal').modal('show');
                return false;
            }
        }
        this.appC.google = { one: '', two: '', three: '', four: '', five: '', six: '' };
        this.appC.response = { message: '' };
        this.service.googleAuthCalledFrom = 'edit-staff';
        $('#google-auth-modal').modal({ keyboard: false, backdrop: 'static' });

    }

    ngOnInit() {
        window.scrollTo(0, 0);
        this.activatedRoute.params.subscribe(id => {
            this.viewStaffProfile(id.id);
        });
    }

    ngOnDestroy() {
        this.subscription.unsubscribe();
    }

    getCountries() {
        this.service.currentUserInfo.subscribe(currInfo => {
            if (currInfo.country_code) {
                setTimeout(() => {
                    this.initializePhone(currInfo.country_code);
                }, 1500);
            }
        }, error => {
            setTimeout(() => {
                this.initializePhone('TH');
            }, 1500);
        });
    }

    initializePhone(data) {
        $('#phoneNum').intlTelInput({
            autoPlaceholder: true,
            autoFormat: false,
            autoHideDialCode: false,
            initialCountry: data,
            nationalMode: false,
            preferredCountries: [data],
            formatOnInit: true,
            separateDialCode: true
        });
        this.telInputFunc();
    }

    getCountryList(country_code) {
        const ind = this.countryList.findIndex((x) => x.dial_code == country_code);
        if (ind !== -1) {
            this.initializePhone(this.countryList[ind].code);
        } else {
            this.initializePhone('TH');
        }
    }

    // change validation on change the country

    telInputFunc() {
        $(document).on('click', '.country', () => {
            this.phoneValidOrNot();
        });
    }

    phoneValidOrNot() {
        this.zone.run(() => {
            this.OTPPhoneValidOrNot = $('#phoneNum').intlTelInput('isValidNumber');
        });
    }

    /** Function to view admin profile */
    viewStaffProfile(id) {
        this.spinner.show();
        this.service.postMethod('account/admin/get-staff-user-profile/?staffId=' + encodeURIComponent(this.service.encrypt(String(id))), {}, 1).subscribe((response: any) => {
            let responseData = this.service.decrypt(response.data);
            responseData = JSON.parse(responseData);
            this.staffDetails = responseData;
            this.spinner.hide();
            if (responseData.status === 562) {
                this.editStaff.patchValue({
                    firstName: responseData.data.staffData.firstName,
                    lastName: responseData.data.staffData.lastName,
                    email: responseData.data.staffData.email,
                    phone: (responseData.data.staffData.countryCode && responseData.data.staffData.phoneNo) ? responseData.data.staffData.phoneNo.split(responseData.data.staffData.countryCode)[1]:responseData.data.staffData.phoneNo,
                    gender: responseData.data.staffData.gender ? responseData.data.staffData.gender.toLowerCase() : responseData.data.staffData.gender,
                });
                this.updatedsetPermissionArray(responseData.data.userPermissions);
                this.getCountryList(responseData.data.staffData.countryCode);
                this.getPermission();
            }
        }, (error) => {
            this.spinner.hide();
        });
    }

    /** Function to add admin */
    editStaffFunc() {
        if (this.editStaff.valid && this.service.sideMenuArr.includes('updateStaffProfile') && this.OTPPhoneValidOrNot) {
            const countryCodeFetched = '+' + $('#phoneNum').intlTelInput('getSelectedCountryData').dialCode;
            this.spinner.show();
            const data = {
                email: this.editStaff.value.email,
                firstName: this.editStaff.value.firstName,
                gender: this.editStaff.value.gender,
                ipAddress: this.userIp.ip,
                lastName: this.editStaff.value.lastName,
                location: this.userIp.city + ', ' + this.userIp.country_name,
                phoneNo: $('#phoneNum').intlTelInput('getNumber'),
                userPermissions: this.setPermissionArray,
                roleId: this.staffDetails.data.staffData.roleId,
                userId: this.staffDetails.data.staffData.userId,
                countryCode: countryCodeFetched,
            };
            this.service.postMethod('account/admin/edit-staff', data, 1).subscribe((response: any) => {
                window.scrollTo(0, 0);
                this.spinner.hide();
                const resData = JSON.parse(this.service.decrypt(response.data));
                if (resData.status === 910) {
                    this.router.navigate(['/manage-staff']);
                } else {
                    this.showApiMessage = true;
                    this.response = response;
                    this.spinner.hide();
                }
            }, (error) => {
                window.scrollTo(0, 0);
                if (error.error) {
                    this.showApiMessage = true;
                    this.response = error.error;
                    this.spinner.hide();
                } else {
                    this.showApiMessage = true;
                    this.response = 'Something went wrong!';
                    this.spinner.hide();
                }
            });
        }
    }

    setPermission(dataObj) {
        let data = {};
        let found = 0;
        if (this.setPermissionArray.length > 0) {
            this.setPermissionArray.forEach((element, index) => {
                if (element.masterPermissionList.masterPermissionListId === dataObj.masterPermissionList.masterPermissionListId) {
                    this.setPermissionArray.splice(index, 1);
                    found = 1;
                }
            });
            if (found === 0) {
                data = {
                    masterPermissionList: {
                        masterPermissionListId: dataObj.masterPermissionList.masterPermissionListId
                    }
                };
                this.setPermissionArray.push(data);
            }
        } else {
            data = {
                masterPermissionList: {
                    masterPermissionListId: dataObj.masterPermissionList.masterPermissionListId
                }
            };
            this.setPermissionArray.push(data);
        }
        this.checkForParent(dataObj)
    }

    checkForParent(dataObj) {
        let count = 0;
        this.setPermissionArray.forEach((element) => {
            if (dataObj.masterPermissionList.isMenu) {
                if (element.masterPermissionList.masterPermissionListId === dataObj.masterPermissionList.masterPermissionListId) {
                    count++;
                }
            } else {
                if (element.masterPermissionList.masterPermissionListId === dataObj.masterPermissionList.parentId) {
                    count++;
                }
            }
        });
        const pushOrPop = this.setPermissionArray.findIndex((z) => z.masterPermissionList.masterPermissionListId === dataObj.masterPermissionList.masterPermissionListId);
        if (count) {
            if (dataObj.masterPermissionList.isMenu) {
                const mx = document.getElementById('#permission' + dataObj.masterPermissionList.masterPermissionListId);
                if (pushOrPop != -1) {
                    this.originalPermission.forEach((element) => {
                        if (element.masterPermissionList.parentId === dataObj.masterPermissionList.masterPermissionListId) {
                            const indIndex = this.setPermissionArray.findIndex((x) => x.masterPermissionList.masterPermissionListId === element.masterPermissionList.masterPermissionListId);
                            const childExsist = this.setPermissionArray.findIndex((x) => x.masterPermissionList.masterPermissionListId === element.masterPermissionList.masterPermissionListId);
                            if (childExsist === -1) {
                                const obj = {
                                    masterPermissionList: {
                                        masterPermissionListId: element.masterPermissionList.masterPermissionListId
                                    }
                                };
                                this.setPermissionArray.push(obj);
                            }
                        }
                    });
                }
                mx.style.color = 'black';
            }
        } else {
            if (!dataObj.masterPermissionList.isMenu) {
                const mx = document.getElementById('#permission' + dataObj.masterPermissionList.parentId);
                $('#confirmation-modal').modal('show');
            } else {
                this.originalPermission.forEach((element) => {
                    if (element.masterPermissionList.parentId === dataObj.masterPermissionList.masterPermissionListId) {
                        const indIndex = this.setPermissionArray.findIndex((x) => x.masterPermissionList.masterPermissionListId === element.masterPermissionList.masterPermissionListId);
                        if (indIndex != -1) {
                            this.setPermissionArray.splice(indIndex, 1);
                        }
                    }
                });
            }
        }
    }

    getPermission() {
        this.service.postMethod('account/superAdmin/user-management/get-role-wise-role-permission/?roleId=' + this.staffDetails.data.staffData.roleId, {}, 1)
            .subscribe((response) => {
                if (response.status == 2005) {
                    this.originalPermission = response.data;
                    this.createArr();
                }


            });
    }

    createArr() {
        this.arr = [];
        if (this.originalPermission.length) {
            this.originalPermission.forEach(element => {
                if (element.masterPermissionList.menuPermission.menuName) {
                    this.arr.push(element);
                }
            });
            this.originalPermission.forEach(element => {
                if (element.masterPermissionList.menuPermission.subMenuName) {
                    this.arr.forEach((menu, ind) => {
                        if (menu.masterPermissionList.masterPermissionListId == element.masterPermissionList.parentId) {
                            this.arr.splice(ind + 1, 0, element);
                        }
                    });
                }
            });
        }



    }

    checkData(id) {
        let total = 0;
        this.setPermissionArray.forEach(element => {
            if (element.masterPermissionList.masterPermissionListId === id) {
                total = 1;
            }
        });
        if (total === 1) {
            total = 0;
            return true;
        } else {
            return false;
        }
    }

    updatedsetPermissionArray(userPermission) {
        userPermission.forEach(ele => {
            const data = {
                masterPermissionList: {
                    masterPermissionListId: ele.masterPermissionList.masterPermissionListId
                }
            };
            this.setPermissionArray.push(data);
        });
    }

    /** Auto focus functionality */
    onKey(event, next, previous) {
        if (event.key === 'Backspace') {
            document.getElementById(previous).focus();
        } else {
            if (event.keyCode >= 48 && event.keyCode <= 57) {
                if (event.target.value.trim() !== '') {
                    document.getElementById(next).focus();
                } else {
                    event.target.value = '';
                }
            } else {
                event.target.value = '';
            }
        }
    }

}
