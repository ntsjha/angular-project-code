import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Subject } from 'rxjs';
import { ServiceService } from 'src/app/service/service.service';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
    selector: 'app-fa-reset-detail',
    templateUrl: './fa-reset-detail.component.html',
    styleUrls: ['./fa-reset-detail.component.css']
})
export class FaResetDetailComponent implements OnInit {
    faRequestList: any = [];
    changeStatusForm: FormGroup;
    assignOperatorForm: FormGroup;
    disable = false;
    page: any = 1;
    searchTerm$ = new Subject<string>();
    status: any = '';
    search_key: any = '';
    pageSize: any = 10;
    constructor(public service: ServiceService, public router: Router, private spinner: NgxSpinnerService) {
    }

    ngOnInit() {
        window.scrollTo(0, 0);
        this.getRequestList();
    }

    getRequestList() {
        this.faRequestList = [];
        const data = {
            page: this.page != 0 ? this.service.encrypt(this.page - 1) : this.service.encrypt('0'),
            pageSize: this.service.encrypt(this.pageSize),
            search: null,
            status: null
        };
        if (this.status) {
            data.status = this.service.encrypt(this.status);
        }
        if (this.search_key) {
            data['search_key'] = this.service.encrypt(this.search_key.trim());
        }

        this.service.postMethod(`account/operation/search-and-filter-two-fa-request`, data, 1).subscribe((res) => {
            const response = JSON.parse(this.service.decrypt(res.data));
            if (response.status == 563) {
                this.faRequestList = response.data.list;
                this.faRequestList.forEach(element => {
                    if (element.updatedByName == null) {
                        element.updatedAt = null;
                    }
                });
            }

        }, (error) => {
        });
    }

    closeModal() {
        this.disable = false;
        this.resetForm();
    }

    resetForm() {
        this.assignOperatorForm.reset();
        this.changeStatusForm.reset();
    }

    viewDetail(id, resetId) {
        this.router.navigate(['particular-fa-detail/' + id + '/' + resetId]);
    }

    filterBySearch() {
        this.faRequestList = [];
        const data = {
            page: this.page != 0 ? this.service.encrypt(this.page - 1) : this.service.encrypt('0'),
            pageSize: this.service.encrypt(this.pageSize),
            search: this.search_key ? this.service.encrypt(this.search_key.trim()) : null,
            status: this.status ? this.service.encrypt(this.status) : null
        };

        if (this.search_key) {
            data.search = this.service.encrypt(this.search_key.trim());
        } else {
            data.search = null;
        }

        this.service.postMethod('account/operation/search-and-filter-two-fa-request', data, 1).subscribe((res) => {
            if (res.data) {
                const response = JSON.parse(this.service.decrypt(res.data));
                if (response.hasOwnProperty('data')) {
                    this.faRequestList = response.data.list;
                    this.faRequestList.forEach(element => {
                        if (element.updatedByName == null) {
                            element.updatedAt = null;
                        }
                    });
                }
            }
        });
    }

    onStatusChange(val) {
        this.status = val;
    }

    exportList() {
        let options = {
            fieldSeparator: ',',
            quoteStrings: '"',
            decimalseparator: '.',
            showLabels: true,
            showTitle: true,
            title: 'FA Request List',
            useBom: true,
            noDownload: false,
            headers: ['Cust Id', 'Cust Name', 'Cust Email', 'Cust Phone', 'Request Date', 'Approve/Reject By', 'Approve/Reject Date', 'Status']
        };

        const data = [];

        this.faRequestList.forEach((element) => {
            const obj = {
                'Customer ID': element.customerId,
                'Customer Name': element.name,
                'Customer Email': element.email,
                'Customer Phone': element.phoneNo || '---',
                'Request Date': new Date(element.createdAt),
                'Approve/Reject By': element.updatedBy,
                'Approve/Reject Date': new Date(element.updatedAt),
                'Status': element.status
            };
            data.push(obj);
        });

        this.service.exportAsExcelFile(data, 'FA-Reset Details');
    }

    exportData() {
        this.spinner.show();
        this.service.getMethod('account/common-permit/export-list-for-search-and-filter-two-fa-request', 1).subscribe((response: any) => {
            const data = [];
            var responseData = response.data ? JSON.parse(this.service.decrypt(response.data)) : '';
            if (responseData.status === 563) {
                responseData.data.list.forEach((element) => {
                    data.push({
                        'Customer ID': element.customerId,
                        'Customer Name': element.name,
                        'Customer Email': element.email,
                        'Customer Phone': element.phoneNo,
                        'Request Date': new Date(element.createdAt),
                        'Approve/Reject By': element.updatedByName,
                        'Approve/Reject Date': (element.updatedByName == null) ? null : new Date(element.updatedAt),
                        'Status': element.status
                    });
                });
                this.service.exportAsExcelFile(data, 'FA-Reset Details');
            }
            this.spinner.hide();
        }, (error) => {
            this.spinner.hide();
        });
    }

    reset() {
        this.status = '';
        this.search_key = '';
        this.getRequestList();
        this.page = 0;
    }

    managePagination(page) {
        this.page = page;
        this.faRequestList = [];
        this.filterBySearch();
    }
}
