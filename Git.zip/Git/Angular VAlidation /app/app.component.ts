import { Component } from '@angular/core';
import { FormGroup, FormControl, Validators} from '@angular/forms';
import { Router, NavigationEnd } from '@angular/router';
import { MainComponent } from './main/main.component';
import { TestComponent } from './test/test.component';
import { Location } from '@angular/common';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'my Project';
  //lc= window.location.pathname;
  show: boolean = false;
  currentUrl: string;
  route : string;
  event: string;
  

  constructor(private router: Router,location: Location,data: Router) {

    
    router.events.subscribe( (event) => {
     // console.log(event);
      if (event instanceof NavigationEnd ) {
        this.currentUrl = event.url;
        console.log(this.currentUrl);
      }
      if (this.currentUrl === '/login'|| this.currentUrl === '/signup') {
      this.show = false;
      }
      else{
        this.show = true;
      }
    
    });
      
   
  }

    






  onSubmit() {
       this.router.navigate(['main']);
    
  }
  

  
}