import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators} from '@angular/forms';
import { Router } from '@angular/router';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  submitted = false;
  item:any
  match;

  ngOnInit(){
    this.item = JSON.parse(localStorage.getItem('teacher'));

    if(sessionStorage.getItem('userID')){
      this.router.navigate(['/dashboard'])
   }
  }
  
  profileForm = new FormGroup({ 
   email: new FormControl('',[Validators.required,Validators.maxLength(25),Validators.pattern(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/)]),
    password: new FormControl('',[Validators.required, Validators.maxLength(16),
      Validators.pattern("^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$")] ),     
    });
  message: string;
  
    constructor(private router: Router) {}
    
    get f() { return this.profileForm.controls; }

  onSubmit() {
    
    this.submitted = true; 
      //console.log(this.f.email.value);
      for(let i=0;i<this.item.length;i++)
      {
        console.log(this.item[i].objemail); 
        if(this.f.email.value==this.item[i].objemail)
        {
          this.match=this.item[i].objemail;
        }
         
      }
     
      if(this.f.email.value == this.match){
        sessionStorage.setItem('userID',JSON.stringify(this.f.email.value));
        alert("Login successful");
       
        this.router.navigate(['dashboard']);    
  
         }
      else{
        alert("Please check your userid and password");
      }

  
  
    // console.warn(this.profileForm.value);   
  }
}
