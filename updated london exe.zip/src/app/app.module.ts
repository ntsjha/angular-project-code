import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';

import { AppComponent } from './app.component';
import { HeaderModule } from './modules/header/header.module';
import { HomeModule } from './modules/home/home.module';
import { LoginModule } from './modules/login/login.module';
import { SignupModule } from './modules/signup/signup.module';
import { ForgetpasswordModule } from './modules/forgetpassword/forgetpassword.module';
import { Ng4LoadingSpinnerModule } from 'ng4-loading-spinner';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { QRCodeModule } from 'angularx-qrcode';
import { NgxPaginationModule } from 'ngx-pagination';
import { ToastrModule } from 'ngx-toastr';
import { ServerService } from './service/server.service';
import { HttpClientModule } from '@angular/common/http';
import { WalletModule } from './modules/wallet/wallet.module';
import { TermsModule } from './modules/terms/terms.module';
import { TwofaModule } from './modules/twofa/twofa.module';
import { PrivacypolicyModule } from './modules/privacypolicy/privacypolicy.module';
import { SupportModule } from './modules/support/support.module';
import { AboutusModule } from './modules/aboutus/aboutus.module';
import { ProfileModule } from './modules/profile/profile.module';
import { ExchangeModule } from './modules/exchange/exchange.module';
import { DashboardModule } from './modules/dashboard/dashboard.module';
import * as $ from 'jquery';
import { EditprofileModule } from './modules/editprofile/editprofile.module';
import { ResetpasswordModule } from './modules/resetpassword/resetpassword.module';
import { DeposithistoryModule } from './modules/deposithistory/deposithistory.module';
import { EmailverifyModule } from './modules/emailverify/emailverify.module';
import { WithdrawhistoryModule } from './modules/withdrawhistory/withdrawhistory.module';
import { ChangepasswordModule } from './modules/changepassword/changepassword.module';
import { GooglePlaceModule } from "ngx-google-places-autocomplete";
import { FaqModule } from './modules/faq/faq.module';
import { FeesFeatureModule } from './modules/fees-feature/fees-feature.module';
import { LegalComplianceModule } from './modules/legal-compliance/legal-compliance.module';
import { ContactUsModule } from './modules/contact-us/contact-us.module';
import { ExHeaderModule } from './modules/ex-header/ex-header.module';
import { PagenotfoundModule } from './modules/pagenotfound/pagenotfound.module';
import { KycModule } from './modules/kyc/kyc.module';
import { AccountModule } from './modules/account/account.module';
import { FiathistoryModule } from './modules/fiathistory/fiathistory.module';
import { BuysellModule } from './modules/buysell/buysell.module';
import { KycamlModule } from './modules/kycaml/kycaml.module';
import { WithdrawverifyModule } from './modules/withdrawverify/withdrawverify.module';
import { HowitworksModule } from './modules/howitworks/howitworks.module';
import { AirdropModule } from './modules/airdrop/airdrop.module';
import { OtcdeskModule } from './modules/otcdesk/otcdesk.module';
import { RequestotcquoteModule } from './modules/requestotcquote/requestotcquote.module';
import { SuggestionModule } from './modules/suggestion/suggestion.module';
import { AddsuggestionModule } from './modules/addsuggestion/addsuggestion.module';
import { ExchangeMicroServiceComponent } from './modules/exchange-micro-service/exchange-micro-service.component';

@NgModule({
    declarations: [
        AppComponent,
        ExchangeMicroServiceComponent
    ],
    imports: [
        BrowserModule,
        AppRoutingModule,
        HeaderModule,
        HomeModule,
        LoginModule,
        SignupModule,
        ForgetpasswordModule,
        Ng4LoadingSpinnerModule.forRoot(),
        BrowserAnimationsModule, // required animations module
        ToastrModule.forRoot({
            timeOut: 10000,
         positionClass: 'toast-top-right',
            preventDuplicates: true,
          }),  
        HttpClientModule,
        WalletModule,
        QRCodeModule,
        NgxPaginationModule,
        TermsModule,
        TwofaModule,
        PrivacypolicyModule,
        SupportModule,
        AboutusModule,
        ProfileModule,
        ExchangeModule,
        DashboardModule,
        EditprofileModule,
        ResetpasswordModule,
        DeposithistoryModule,
        EmailverifyModule,
        WithdrawhistoryModule,
        ChangepasswordModule,
        GooglePlaceModule,
        FaqModule,
        FeesFeatureModule,
        LegalComplianceModule,
        ContactUsModule,
        ExHeaderModule,
        PagenotfoundModule,
        KycModule,
        AccountModule,
        FiathistoryModule,
        BuysellModule,
        KycamlModule,
        WithdrawverifyModule,
        HowitworksModule,
        AirdropModule,
        OtcdeskModule,
        RequestotcquoteModule,
        SuggestionModule,
        AddsuggestionModule
    ],
    providers: [
        ServerService
    ],
    bootstrap: [AppComponent]
})
export class AppModule { }
