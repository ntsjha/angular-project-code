import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageUpdateNotificationComponent } from './manage-update-notification.component';

describe('ManageUpdateNotificationComponent', () => {
  let component: ManageUpdateNotificationComponent;
  let fixture: ComponentFixture<ManageUpdateNotificationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManageUpdateNotificationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageUpdateNotificationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
