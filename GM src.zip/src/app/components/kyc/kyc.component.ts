import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { CookieService } from 'ngx-cookie-service';
import { ServiceService } from 'src/app/service/service.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-kyc',
  templateUrl: './kyc.component.html',
  styleUrls: ['./kyc.component.css']
})
export class KycComponent implements OnInit {
  getDays: any;
  kycFunction: FormGroup;
  userIp: any;

  constructor(private cookie: CookieService,
    private service: ServiceService,
    private spinner: NgxSpinnerService,
    private activatedRoute: ActivatedRoute,
    private route: Router) {

    this.kycFunction = new FormGroup({
      kycDay: new FormControl(null, [Validators.required, Validators.pattern(/^[0-9]*$/)]),
    });
  }

  ngOnInit() {
    this.getKycDays();
    window.scrollTo(0, 0);
    this.userIp = (this.cookie.get('userInfo')) ? JSON.parse(this.cookie.get('userInfo')) : this.service.initialUserInfo;
  }
  loadForm() {
    this.kycFunction.patchValue({
      kycDay: this.getDays.maxNoOfDays
    })
  }

  getKycDays() {
    this.spinner.show();
    this.service.postMethod('account/admin/get-max-days-to-complete-kyc', {}, 1).subscribe((response: any) => {
      var responseData = this.service.decrypt(response.data);
      responseData = JSON.parse(responseData);
      this.spinner.hide();
      if (responseData.status === 586) {
        this.getDays = responseData.data;
        this.loadForm();
      }
    }, (error) => {
      this.spinner.hide();
    });
    this.spinner.hide();

  }
  // admin/add-kyc-setting-max-days-tocomplete
  postKycDays() {
    this.spinner.show();
    this.service.postMethod('account/admin/update-max-days-to-complete-kyc/?maxDays=' + this.kycFunction.value.kycDay + '&ipAddress=' + this.userIp.ip + '&location=' + this.userIp.city + ',' + this.userIp.country_name, {}, 1).subscribe((response: any) => {
      let responseData = this.service.decrypt(response.data);
      responseData = JSON.parse(responseData);
      this.spinner.hide();
      if (responseData.status === 700 || responseData.status === 588) {
        this.route.navigateByUrl('settingall');
      }
    }, (error) => {
      this.spinner.hide();
    });
  }
}
