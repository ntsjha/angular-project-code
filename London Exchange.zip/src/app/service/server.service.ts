import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs';
import { webSocket } from 'rxjs/observable/dom/webSocket';

@Injectable()
export class ServerService {
    // baseUrl = 'http://172.16.16.247:9090/GatewayService/rest/gateway';
    // baseUrl = 'http://172.16.16.225:8080/GatewayService/rest/gateway';
    // baseUrl= 'http://172.16.2.4:8080/GatewayService/rest/gateway';
    // baseUrl= 'http://172.16.16.161:8080/GatewayService/rest/gateway';
    // baseUrl= 'http://182.76.185.46:8082/LondonCrypto/rest/gateway';
    // baseUrl= 'http://35.178.242.39:8080/LondonCrypto/rest/gateway';
    // baseUrl= 'http://172.16.21.20:8082/LondonCrypto/rest/gateway';
   
   
    // baseUrl = 'https://londonex.io:8443/LondonCrypto/rest/gateway';
    //baseUrl='http://172.16.16.141:8765/'
      baseUrl='http://172.16.21.84:8765/'
    // webiteUrl = 'https://www.londonex.io/header/';
    //   webiteUrl = 'http://172.16.6.53:4200/header/';
    
      webiteUrl="http://ec2-35-176-66-190.eu-west-2.compute.amazonaws.com:1619/"
      // webiteUrl = 'http://172.16.6.84:4300/header/';
    // webiteUrl = 'http://162.222.32.20:1474/header/'

    // chartUrl = 'http://172.16.16.225:8081/LCXChart/exchange-feed';
    // chartUrl = 'https://londonex.io:8443/LCXChart/exchange-feed';
    chartUrl = "http://172.16.21.84:8765/order/exchange-feed"
    // chartUrl = 'http://172.16.16.251:8080/tradingview/exchange-feed';

    // websocketUrl = "wss://londonex.io:8443/LondonCrypto/socket/";
    websocketUrl="ws://172.16.21.84:9100/socket"
    // websocketUrl = "ws://172.16.16.247:9090/GatewayService/socket/";
    // websocketUrl = "ws://172.16.16.225:8080/GatewayService/socket/";
    // websocketUrl = "ws://172.16.2.4:8080/GatewayService/socket/";
    // websocketUrl = "ws://172.16.16.161:8080/GatewayService/socket/";
    // websocketUrl = "ws://172.16.16.161:8080/GatewayService/socket/";

    private subject = new Subject<any>();
    email: string = "";
    password: string = "";
    name: string = "";
    phone: string = "";
    confirmpass: string = "";
    citizenNo: string = "";
    loginStatus: any;
    twoFAPage = "";
    httpOptions = {
        headers: new HttpHeaders({ 'Content-Type': 'application/json' }),
        "Access-Control-Allow-Origin": "*"
    };
    wsExchange: any;
    url: any;
    socketStatus = false;

    liqWSObj: any;
    buyOrderLimit = 50;
    sellOrderLimit = 50;
    tradeHisOrderLimit = 50;

    constructor(private http: HttpClient) { }

    ngOnInit() {
    }
    
    /** Function for call event in child component */
    fireToChild(): Observable<any> {
        return this.subject.asObservable();
    }

    /** method declaration */
    // getApi(url): Observable<any> {
    //     return this.http.get(this.baseUrl + url);
    // }
    getApi(url,header): Observable<any> {
        let httpOptions;  
        if(header==0){
            httpOptions = {
                headers: new HttpHeaders({
                  'Content-Type': 'application/json',       
                }),
                observe: 'response'
              }
          
        }else if(header==1) {
            httpOptions = {
                observe: 'response'
              }
        }
        else {
            httpOptions = {
                headers: new HttpHeaders({
                  'Content-Type': 'application/json',
                  'Authorization':'Bearer'+' '+header      
                }),
                observe: 'response'
              }
        }
        return this.http.get(this.baseUrl + url,httpOptions);
    }

    /** Function for post method */
    // postApi(url, data): Observable<any> {
    //     return this.http.post(this.baseUrl + url, data);
    // }
    postApi(url, data,header): Observable<any> {
        let httpOptions;  
        if(header==0){
            httpOptions = {
                headers: new HttpHeaders({
                  'Content-Type': 'application/json',       
                }),
                observe: 'response'
              }
        }else if(header==1){
            httpOptions = {
                observe: 'response'
              }
        }
        else {
            httpOptions = {
                headers: new HttpHeaders({
                  'Content-Type': 'application/json',
                  'Authorization':'Bearer'+' '+header      
                }),
                observe: 'response'
              }
          
        }
        return this.http.post(this.baseUrl + url, data,httpOptions);
    }

    /** Function for exchange page  method */
    post(url, data): Observable<any> {
        return this.http.post(this.baseUrl + url, data);
    }

    initSocket(val) {
        this.wsExchange = new WebSocket(this.websocketUrl);
        var self = this;
        this.wsExchange.addEventListener('open', function (event) {
            self.socketStatus = true;
            console.log('ws connected for exchange OWN');
        });
        this.wsExchange.addEventListener('close', function (event) {
            self.socketStatus = false;
            console.log('ws disconnected for exchange OWN');
            self.reConnectSocket();
        });

        /** Socket code for liquidity */
        this.liqWSObj = new WebSocket("wss://api.hitbtc.com/api/2/ws");
        this.liqWSObj.addEventListener('open', function (event) {
            self.socketStatus = true;
            console.log('ws connected for liquidity');
            let url = window.location.href.split('/');
            let pageName = url[url.length - 1];
            if(pageName == "exchange") {
                self.subject.next({ text: "liqConnected" });
            }
        });
        this.liqWSObj.addEventListener('close', function (event) {
            self.socketStatus = false;
            console.log('ws disconnected for liquidity');
        });
    }

    /** Function for reconnect socket */
    reConnectSocket() {
        let val;
        localStorage.getItem("token") ? val = localStorage.getItem("token") : val = "notLoggedIn";
        this.wsExchange = new WebSocket(this.websocketUrl);
        var self = this;
        this.wsExchange.addEventListener('open', function (event) {
            self.socketStatus = true;
            console.log('again ws connected for exchange');
        });
    }

    /** Function to call third party from CMC */
    callListForCMC(): Observable<any> {
        return this.http.get("https://api.coinmarketcap.com/v1/ticker/?limit=0");
    }

    /** Function to get price of GBP in terms of USD */
    getPriceOfGBP(): Observable<any> {
        return this.http.get("https://free.currencyconverterapi.com/api/v6/convert?q=GBP_USD&compact=ultra");
    }
}
