import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateOTCSettingComponent } from './update-otc-setting.component';

describe('UpdateOTCSettingComponent', () => {
  let component: UpdateOTCSettingComponent;
  let fixture: ComponentFixture<UpdateOTCSettingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdateOTCSettingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateOTCSettingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
