import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddsuggestionComponent } from './addsuggestion.component';

describe('AddsuggestionComponent', () => {
  let component: AddsuggestionComponent;
  let fixture: ComponentFixture<AddsuggestionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddsuggestionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddsuggestionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
