import { Component, OnInit } from '@angular/core';
import { ServiceService } from 'src/app/service/service.service';
import { Router } from '@angular/router';
import { IMyDpOptions, IMyDateModel } from 'mydatepicker';
import { NgxSpinnerService } from 'ngx-spinner';
import { DatePipe } from '@angular/common';
declare var $: any;

@Component({
    selector: 'app-customers-kyc',
    templateUrl: './customers-kyc.component.html',
    styleUrls: ['./customers-kyc.component.css']
})
export class CustomersKycComponent implements OnInit {
    kycList: any = [];
    disable = false;
    page: any = 1;
    status: any = '';
    search_key: any = '';
    pageSize: any = 10;
    total: number;
    obj: any = {};

    public fromPickerOptions: IMyDpOptions = {
        disableSince: { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() + 1 },
        dateFormat: 'dd/mm/yyyy',
    };
    englishShortCode: any;
    public toPickerOptions: IMyDpOptions = {
        disableSince: { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() + 1 },
        dateFormat: 'dd/mm/yyyy',
    };

    constructor(public service: ServiceService, public router: Router, private spinner: NgxSpinnerService, private datepipe: DatePipe) {
    }

    ngOnInit() {
        window.scrollTo(0, 0);
        this.getCustomerKycList();
    }

    onFromDateChanged(event: IMyDateModel) {
        let copy1 = this.getCopyOfOptions1();
        copy1.disableUntil = event.date;
        this.toPickerOptions = copy1;
    }

    getCopyOfOptions1(): IMyDpOptions {
        return JSON.parse(JSON.stringify(this.toPickerOptions));
    }

    getCopyOfOptions2(): IMyDpOptions {
        return JSON.parse(JSON.stringify(this.fromPickerOptions));
    }
    fromDateChanged(event) {
        if (event.epoc) {
            this.toPickerOptions = {
                disableUntil: { year: new Date(event.epoc * 1000).getFullYear(), month: new Date(event.epoc * 1000).getMonth() + 1, day: new Date(event.epoc * 1000).getDate() - 1 }
            };
        } else {
            this.toPickerOptions = {
                disableUntil: { year: 0, month: 0, day: 0 },
                disableSince: { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() + 1 }
            };
        }
    }

    toDateChanged(event) {
        if (event.epoc) {
            this.fromPickerOptions = {
                disableSince: { year: new Date(event.epoc * 1000).getFullYear(), month: new Date(event.epoc * 1000).getMonth() + 1, day: new Date(event.epoc * 1000).getDate() + 1 }
            };
        } else {
            this.fromPickerOptions = {
                disableSince: { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() + 1 },
            };
        }
    }

    getCustomerKycList() {
        this.spinner.show();
        this.kycList = [];
        let data = {
            "page": this.page != 0 ? this.service.encrypt(this.page - 1) : this.service.encrypt(this.page),
            "pageSize": this.service.encrypt(this.pageSize),
            "fromDate": this.obj.fromDate ? (this.obj.fromDate.epoc ? this.service.encrypt(this.obj.fromDate.epoc * 1000) : null) : null,
            "toDate": this.obj.toDate ? (this.obj.toDate.epoc ? this.service.encrypt((this.obj.toDate.epoc * 1000) + (86400000 - 1)) : null) : null,
            "search": this.search_key ? this.service.encrypt(this.search_key.trim()) : null,
            "status": this.status ? this.service.encrypt(this.status) : null
        };

        this.service.postMethod('account/operation/search-and-filter-customer-kyc', data, 1).subscribe((res) => {
            this.spinner.hide();
            if (res.data) {
                let response = JSON.parse(this.service.decrypt(res.data));
                if (response.hasOwnProperty('data')) {
                    this.kycList = response.data.list;
                    this.kycList.forEach(element => {
                        if (element.updatedBy == null) {
                            element.updatedAt = null;
                        }
                    });
                    this.total = response.data.size;
                }
            }
        }, (error) => {
            this.spinner.hide();
        });
    }
    viewDetail(id, kycId) {
        this.router.navigateByUrl('cust-kyc-detail/' + id + '/' + kycId);
    }

    applyFilter() {
        this.page = 1;
        this.total = 0;
        this.getCustomerKycList();
    }

    onStatusChange(val) {
        this.status = val;
    }

    resetFilter() {
        if (this.obj.fromDate) {
            this.obj.fromDate.epoc = 0;
        }
        if (this.obj.toDate) {
            this.obj.toDate.epoc = 0;
        }
        this.search_key = '';
        this.page = 1;
        this.total = 0;
        this.kycList = [];
        this.status = '';
        this.fromPickerOptions = {
            disableSince: { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() + 1 },
            disableUntil: { year: 0, month: 0, day: 0 }
        };
        this.toPickerOptions = {
            disableSince: { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() + 1 },
            disableUntil: { year: 0, month: 0, day: 0 }
        };
        this.getCustomerKycList();
    }
    exportList() {
        // var options = {
        //     fieldSeparator: ',',
        //     quoteStrings: '"',
        //     decimalseparator: '.',
        //     showLabels: true,
        //     showTitle: true,
        //     title: 'Customers Kyc List :',
        //     useBom: true,
        //     noDownload: false,
        //     headers: ['Cust ID', 'Name', 'Email', 'Phone', 'Submitted At', 'Submitted By', 'Approve/Reject By', 'Approve/Reject Date', 'Status']
        // };
        // let data = [];
        // this.kycList.forEach((element) => {
        //     let obj = {
        //         cust_id: element.customerId,
        //         name: element.englistFirstName,
        //         email: element.email,
        //         phone: element.phoneNo || '---',
        //         submitted_at: new Date(element.createdAt) || '---',
        //         submitted_by: element.createdByName,
        //         approve_reject_by: element.updatedByName || '---',
        //         approve_reject_date: new Date(element.updatedAt) || '---',
        //         status: element.kycStatus
        //     };
        //     data.push(obj);
        // });
        this.spinner.show();
        this.service.getMethod('account/common-permit/export-customer-data-list?findBy=USER', 1).subscribe((response: any) => {
            const data = [];
            if (response.status === 2500) {
                response.data.forEach((ele) => {
                    data.push({
                        'Customer ID': ele.customerId,
                        'First Name': ele.firstName,
                        'Middle Name': ele.middleName,
                        'Last Name': ele.lastName,
                        'First Name (Thai)': ele.firstNameThai,
                        'Last Name (Thai)': ele.lastNameThai,
                        'Middle Name (Thai)': ele.middleNameThai,
                        'Phone Number': ele.phoneNumber,
                        'Postal Code': ele.postalCode,
                        'Email': ele.email,
                        'User Type': ele.userType,
                        'Address 1': ele.address1,
                        'Address 2': ele.address2,
                        'city': ele.city,
                        'state': ele.state,
                        'country': ele.country,
                        'Company Name': ele.companyName,
                        'Company Phone No': ele.companyPhoneNo,
                        'Company Website': ele.companyWebsite,
                        'KYC Status': ele.kycStatus,
                        'Nationality': ele.nationality,
                        'National ID': ele.nationalId,
                        'Passport Number': ele.passportNumber,
                        'Laser Code': ele.laserCode,
                        'Date of Birth': (ele.DOB != null) ? this.convertFormat(ele.DOB) : '',
                        'Creation Date': (ele.createdAt != null) ? this.convertFormat(ele.createdAt) : '',

                    });
                });
                this.spinner.hide();
                this.service.exportAsExcelFile(data, 'Customer KYC List');
            }
        }, (error) => {
            this.spinner.hide();
        });
    }

    convertFormat(time) {
        if (time != null) {
            return this.datepipe.transform(time, 'MM/dd/yyy, hh:mm a');
        }
    }

    managePagination(page) {
        this.page = page;
        this.total = 0;
        this.getCustomerKycList();
    }

    uploadKyc() {
        this.router.navigateByUrl('operation-kyc');
    }


}