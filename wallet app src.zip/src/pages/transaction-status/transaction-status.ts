import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { TabsPage } from "../tabs/tabs";
import { InAppBrowser } from '@ionic-native/in-app-browser';

@IonicPage()
@Component({
  selector: 'page-transaction-status',
  templateUrl: 'transaction-status.html',
})
export class TransactionStatusPage {
  process: any;
  details: string;
  transactionDetail: any;

  constructor(public navCtrl: NavController, public navParams: NavParams, private iab: InAppBrowser) {
    this.process = this.navParams.get('type');
    if(this.process == 'addMoneyProcess') {
      this.details = localStorage.getItem('addMoneyProcess')
    }
    else if(this.process == 'sendMoneyProcess'){
      this.details = localStorage.getItem('sendMoneyProcess')
    }
    this.transactionDetail = this.navParams.get('transactionDetail')
  }

  done() {
    this.navCtrl.setRoot(TabsPage, { selectedTab: 2 })
  }

  addMoney() {
    this.navCtrl.setRoot(TabsPage, { selectedTab: 0 })
  }

  sendMoney() {
    this.navCtrl.setRoot(TabsPage, { selectedTab: 1 })
  }

  ionViewWillLeave() {
    if(this.process == 'addMoneyProcess') {
      localStorage.removeItem('addMoneyProcess')
    }
    else if(this.process == 'sendMoneyProcess'){
      localStorage.removeItem('sendMoneyProcess')
    }
  }

  open(url) {
    const browser = this.iab.create(url);
  }

}
