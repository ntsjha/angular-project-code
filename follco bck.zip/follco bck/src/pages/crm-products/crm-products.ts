import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, App } from 'ionic-angular';
import { RestProvider } from '../../providers/rest/rest';
import { CrmProductsviewPage } from '../crm-productsview/crm-productsview';
import { SettingprivacyPage } from '../settingprivacy/settingprivacy';

/**
 * Generated class for the CrmProductsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-crm-products',
  templateUrl: 'crm-products.html',
})
export class CrmProductsPage {
  productList: any=[];

  constructor(public navCtrl: NavController,  public app :App,public navParams: NavParams,private service: RestProvider) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad CrmProductsPage');
    this.getProducts();
  }
  back(){
    this.navCtrl.pop();
  }
  setting(){
    this.app.getRootNav().push(SettingprivacyPage);
  }
  doRefresh(refresher) {
    console.log('Begin async operation', refresher);
     this.getProducts();
    setTimeout(() => {
      console.log('Async operation has ended');
      refresher.complete();
    }, 2000);
  }

  doPulling(refresher) {
    // console.log('DOPULLING', refresher.progress);
  //   console.log('Begin async operation', refresher);
  //   this.getFollowers();
  //  setTimeout(() => {
  //    console.log('Async operation has ended');
  //    refresher.complete();
  //  }, 2000);
  }
  getProducts() {
    this.service.presentLoadingDefault('Loading...');
    this.service.get('products/list?follco_token=' + localStorage.getItem('new_token'),0).subscribe(res =>{
        console.log(res);
        if(res) {
            this.service.dismissLoading();
            this.productList = res['list'];
            // this.time = new Date (this.campaignList[0].created_at);
            // this.time1 =this.time.getDate() + '/' + (this.time.getMonth()+1) + '/' + this.time.getFullYear();
            // console.log(this.time1); 
         
          
        }
    }, err => {
        this.service.dismissLoading();
        console.log(err);
    })
}
productitle(id){
  localStorage.setItem('product_id',id);
  this.navCtrl.push(CrmProductsviewPage);
}
}
