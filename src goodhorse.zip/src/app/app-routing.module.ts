import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './Pages/login/login.component';
import { DashboardComponent } from './Pages/dashboard/dashboard.component';
import { ContributorManagementComponent } from './Pages/contributor-management/contributor-management.component';
import { TrainingManagementComponent } from './Pages/training-management/training-management.component';
import { SettingComponent } from './Pages/setting/setting.component';
import { UserManagementComponent } from './Pages/user-management/user-management.component';
import { UserManagementViewComponent } from './Pages/user-management-view/user-management-view.component';
import { AddContributorManagementComponent } from './Pages/add-contributor-management/add-contributor-management.component';
import { EditContributorManagementComponent } from './Pages/edit-contributor-management/edit-contributor-management.component';
import { ContributorManagementViewComponent } from './Pages/contributor-management-view/contributor-management-view.component';
import { AddTemplateComponent } from './Pages/add-template/add-template.component';
import { EditTemplateComponent } from './Pages/edit-template/edit-template.component';
import { AddActivityComponent } from './Pages/add-activity/add-activity.component';
import { HorseDetailsComponent } from './Pages/horse-details/horse-details.component';
import { EditActivityComponent } from './Pages/edit-activity/edit-activity.component';
import { TemplateDetailsComponent } from './Pages/template-details/template-details.component';
import { ViewActivityComponent } from './Pages/view-activity/view-activity.component';
import { TrainingDetailsComponent } from './Pages/training-details/training-details.component';
import { AuthGuard } from './Shared/auth.guard';
import { ViewSettingsComponent } from './Pages/view-settings/view-settings.component';
import { SubscriptionPlanComponent } from './Pages/subscription-plan/subscription-plan.component';
import { AddSettingComponent } from './Pages/add-setting/add-setting.component';
import { AddSubscriptionplanComponent } from './Pages/add-subscriptionplan/add-subscriptionplan.component';
import { EditSubscriptionPlanComponent } from './Pages/edit-subscription-plan/edit-subscription-plan.component';
import { ViewFeedTypeComponent } from './Pages/view-feed-type/view-feed-type.component';
import { StaticContentComponent } from './Pages/static-content/static-content.component';
import { ViewStaticContentComponent } from './Pages/view-static-content/view-static-content.component';
import { EditStaticContentComponent } from './Pages/edit-static-content/edit-static-content.component';
import { AddFAQsComponent } from './Pages/add-faqs/add-faqs.component';
import { EditStaticFAQComponent } from './Pages/edit-static-faq/edit-static-faq.component';
import { FeatureListComponent } from './Pages/feature-list/feature-list.component';
import { AddFeatureListComponent } from './Pages/add-feature-list/add-feature-list.component';
import { EditFeatureListComponent } from './Pages/edit-feature-list/edit-feature-list.component';
import { PageNotFoundComponent } from './Pages/page-not-found/page-not-found.component';
import { UserGuideComponent } from './Pages/user-guide/user-guide.component';
import { EditUserGuideComponent } from './Pages/edit-user-guide/edit-user-guide.component';
import { AddUserGuideComponent } from './Pages/add-user-guide/add-user-guide.component';
import { HeaderComponent } from './Pages/header/header.component';
import { TackMangementComponent } from './Pages/tack-mangement/tack-mangement.component';


const router: Routes = [
  { path: "", redirectTo: "/login", pathMatch: "full" },
  { path: 'login', component: LoginComponent },
  { path: 'header', component: HeaderComponent , canActivate: [AuthGuard]},
  { path: 'dash', component: DashboardComponent , canActivate: [AuthGuard]},
  { path: 'userManagement', component: UserManagementComponent,canActivate: [AuthGuard] },
  { path: 'userManagement/userManagementView/:id', component: UserManagementViewComponent ,canActivate: [AuthGuard]},
  { path: 'userManagement/userManagementView/horseDetails/:id', component: HorseDetailsComponent,canActivate: [AuthGuard] },
  { path: 'userManagement/userManagementView/horseDetails/training/trainingDetails', component: TrainingDetailsComponent ,canActivate: [AuthGuard]},
  { path: 'contributorManagement', component: ContributorManagementComponent ,canActivate: [AuthGuard]},
  { path: 'contributorManagement/addContributorMangement', component: AddContributorManagementComponent ,canActivate: [AuthGuard]},
  { path: 'contributorManagement/editContributorMangement/:id', component: EditContributorManagementComponent ,canActivate: [AuthGuard]},
  { path: 'contributorManagement/viewContributorMangement/:id', component: ContributorManagementViewComponent ,canActivate: [AuthGuard]},
  { path: 'trainingMagement', component: TrainingManagementComponent ,canActivate: [AuthGuard]},
  { path: 'addTemplate', component: AddTemplateComponent ,canActivate: [AuthGuard]},
  { path: 'editTemplate', component: EditTemplateComponent ,canActivate: [AuthGuard]},
  { path: 'addActivity', component: AddActivityComponent ,canActivate: [AuthGuard]},
  { path: 'editActivity/:id', component: EditActivityComponent ,canActivate: [AuthGuard]},
  { path: 'templateDetails', component: TemplateDetailsComponent ,canActivate: [AuthGuard]},
  { path: 'viewActivity', component: ViewActivityComponent ,canActivate: [AuthGuard]},
  { path: 'setting', component: SettingComponent ,canActivate: [AuthGuard]},
  { path: 'setting/viewsetting/:id', component: ViewSettingsComponent ,canActivate: [AuthGuard]},
  { path: 'setting/view-feed-setting/:id', component: ViewFeedTypeComponent ,canActivate: [AuthGuard]},
  { path: 'setting/add-setting/:id', component:AddSettingComponent,canActivate: [AuthGuard]}, 
  { path: 'setting', component: SettingComponent ,canActivate: [AuthGuard]},
  { path: 'subscription', component:SubscriptionPlanComponent,canActivate: [AuthGuard]},
  { path: 'subscription/addsubscription', component:AddSubscriptionplanComponent,canActivate: [AuthGuard]},
  { path: 'subscription/editsubscription/:id', component:EditSubscriptionPlanComponent,canActivate: [AuthGuard]},
  { path: 'static-content', component:StaticContentComponent,canActivate: [AuthGuard]},
  { path: 'static-content/view-static-content/:id', component:ViewStaticContentComponent,canActivate: [AuthGuard]},
  { path: 'static-content/edit-static-content/:id', component:EditStaticContentComponent,canActivate: [AuthGuard]},
  { path: 'static-content/add-faq/:id', component:AddFAQsComponent,canActivate: [AuthGuard]},
  { path: 'static-content/edit-faq/:id', component:EditStaticFAQComponent,canActivate: [AuthGuard]},
  { path: 'feature-list', component:FeatureListComponent,canActivate: [AuthGuard]},
  { path: 'feature-list/add-feature-list', component:AddFeatureListComponent,canActivate: [AuthGuard]},
  { path: 'feature-list/edit-feature-list/:id', component:EditFeatureListComponent,canActivate: [AuthGuard]},
  { path: 'user-guide',   component:UserGuideComponent,canActivate: [AuthGuard]},
  { path: 'user-guide/edit-user-guide/:id', component:EditUserGuideComponent,canActivate: [AuthGuard]},
  { path: 'user-guide/add-user-guide', component:AddUserGuideComponent,canActivate: [AuthGuard]},
  { path: 'Tack', component:TackMangementComponent,canActivate: [AuthGuard]},
  // {path: '**', component: PageNotFoundComponent},

  {
   
    path: "**",
    redirectTo: "dash"
    }

]

@NgModule({
  imports: [RouterModule.forRoot(router)],
  exports: [RouterModule],
  declarations: []
})
export class AppRoutingModule { }
