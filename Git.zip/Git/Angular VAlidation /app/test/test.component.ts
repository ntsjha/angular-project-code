import { Component, OnInit } from '@angular/core';
import { StoreService } from '../store.service';
@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css']
})
export class TestComponent implements OnInit {
  months = ["January", "Feburary", "March", "April", "May", 
  "June", "July", "August", "September",
  "October", "November", "December"];
heroes = ['Tornado'];

 
  constructor() { }

  ngOnInit() {
      var retrievedObject = localStorage.getItem('token');
    console.log('retrievedObject: ', JSON.parse(retrievedObject)); 
   // alert(retrievedObject);
  }
  
  addHero(newHero: string) {
    if (newHero) {
      this.heroes.push(newHero);

      
    }
  }

  

  


}
