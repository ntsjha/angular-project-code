import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DailyClouserComponent } from './daily-clouser.component';

describe('DailyClouserComponent', () => {
  let component: DailyClouserComponent;
  let fixture: ComponentFixture<DailyClouserComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DailyClouserComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DailyClouserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
