declare var CanvasJS: any;
declare var $: any;
// declare var angular: any;

export class totalApplicationService {
    chart: any;
    chartData: any;
    title: string;
    jobChart: any = [];
    totalJobsData(data, chartId) {
        this.jobChart = [];
        // if ( !angular.element('#' + chartId).length ) {
        //     return;
        // }
        this.chartData = data;
        if (this.chartData.length) {
            this.title = '';
            let len = (this.chartData.length - 1);
            let i = 0;
            this.chartData.forEach((element) => {
                if (i < len) {
                    const obj = {
                        label: (element.month),
                        y: element.JobList[0],
                    };
                    this.jobChart.push(obj);
                    i++;
                }
            });
        } else {
            this.title = 'No data found';
            this.jobChart = [
                {
                    label: 'Jan',
                    y: 0,
                },
                {
                    label: 'Feb',
                    y: 0,
                },
                {
                    label: 'Mar',
                    y: 0,
                },
                {
                    label: 'Apr',
                    y: 0,
                },
                {
                    label: 'May',
                    y: 0,
                },
                {
                    label: 'June',
                    y: 0,
                },
                {
                    label: 'July',
                    y: 0,
                },
                {
                    label: 'Aug',
                    y: 0,
                },
                {
                    label: 'Sept',
                    y: 0,
                },
                {
                    label: 'Oct',
                    y: 0,
                },
                {
                    label: 'Nov',
                    y: 0,
                },
                {
                    label: 'Dec',
                    y: 0,
                },
            ];
        }
        this.chart = new CanvasJS.Chart(chartId, {
            animationEnabled: true,
            exportEnabled: true,
            theme: 'light1',
            title: {
                text: this.title,
            },
            axisX: {
                interval: 1,
            },
            data: [{
                type: 'column',
                indexLabelFontColor: '#5A5757',
                indexLabelPlacement: 'outside',
                dataPoints: this.jobChart,
            }]
        });
        return this.chart.render();
    }
}
