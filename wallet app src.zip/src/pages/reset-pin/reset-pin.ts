import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { FormGroup, FormControl } from "@angular/forms";
import { Validators } from "@angular/forms";
import { ServiceServicesProvider } from "../../providers/service-services/service-services";
import { LoginPage } from "../login/login";
import { SignpinPage } from "../signpin/signpin";

@IonicPage()
@Component({
  selector: 'page-reset-pin',
  templateUrl: 'reset-pin.html',
})
export class ResetPinPage {

  form: FormGroup
  result: any;
  newPinModel: any = '';
  confirmPinModel: any = '';
  constructor(public navCtrl: NavController, public navParams: NavParams, private server: ServiceServicesProvider) {
  }

  ngOnInit() {
    this.form = new FormGroup({
      newPin: new FormControl('', [Validators.minLength(4), Validators.required, Validators.pattern(/^\d+$/)]),
      confirmPin: new FormControl('', [Validators.required])
    }, pinMatchValidator)

    /** Function for password match and mismatch */
    function pinMatchValidator(g: FormGroup) {
      let pass = g.get('newPin').value;
      let confPass = g.get('confirmPin').value;
      if (pass != confPass) {
        g.get('confirmPin').setErrors({ mismatch: true });
      } else {
        g.get('confirmPin').setErrors(null)
        return null
      }
    }
  }

  get newPin(): any {
    return this.form.get('newPin')
  }

  get confirmPin(): any {
    return this.form.get('confirmPin')
  }

  back() {
    this.navCtrl.pop()
  }

  submit() {
    if (navigator.onLine) {
      this.server.presentLoading();
      let data = {
        "userId": localStorage.getItem('userId'),
        "pin": this.form.value.newPin
      }
      this.server.postApi(data, 'user/resetPin', 0).subscribe((response: any) => {
        this.server.dismissLoading();
        if (response.response_code == 200) {
          this.navCtrl.setRoot(SignpinPage)
          this.server.presentToast(response.response_message)
        } else if (response.response_code == 403 || response.response_code == 409 || response.response_code == 401) {
          this.server.presentToast(response.response_message)
          this.server.logout();
        }
        else
          this.server.presentToast(response.response_message)
      }, err => {
        this.server.dismissLoading();
        this.server.presentToast('Something went wrong')
      })
    } else
      this.server.presentToast('Your internet connection seems to be lost')
  }

  signin() {
    this.navCtrl.setRoot(SignpinPage)
  }

}
