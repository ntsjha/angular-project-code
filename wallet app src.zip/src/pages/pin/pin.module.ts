import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PinPage } from './pin';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    PinPage,
  ],
  imports: [
    IonicPageModule.forChild(PinPage),
    FormsModule,
    ReactiveFormsModule
  ],
})
export class PinPageModule {}
