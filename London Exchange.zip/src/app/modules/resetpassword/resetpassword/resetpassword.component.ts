import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '../../../../../node_modules/@angular/forms';
import { Ng4LoadingSpinnerService } from '../../../../../node_modules/ng4-loading-spinner';
import { HeaderComponent } from '../../header/header/header.component';
import { AppComponent } from '../../../app.component';
import { ServerService } from '../../../service/server.service';
import { Router } from '../../../../../node_modules/@angular/router';

@Component({
    selector: 'app-resetpassword',
    templateUrl: './resetpassword.component.html',
    styleUrls: ['./resetpassword.component.css']
})
export class ResetpasswordComponent implements OnInit {
    resetForm: FormGroup;
    constructor(private spinnerService :Ng4LoadingSpinnerService, private router: Router, private header:HeaderComponent, private appC:AppComponent ,private server:ServerService) { }

    ngOnInit() {
        this.checkInputs();
    }

    checkInputs() {
        this.resetForm = new FormGroup ({
            newpassword: new FormControl('', [Validators.required, Validators.pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})/i)]),
            confrmpassword: new FormControl('', [Validators.required]),
        }, passwordMatchValidator);
        /** Function for password match and mismatch */
        function passwordMatchValidator(g: FormGroup) {
            let pass = g.get('newpassword').value;
            let confPass = g.get('confrmpassword').value;
            if (pass != confPass) {
                g.get('confrmpassword').setErrors({ mismatch: true });
            } else {
                g.get('confrmpassword').setErrors(null)
                return null
            }
        }
    }

    get newpassword(): any {
        return this.resetForm.get('newpassword');
    }

    get confrmpassword(): any {
        return this.resetForm.get('confrmpassword');
    }

    resetPassword() {
        let url = window.location.href.split('=')
        let page = url[url.length - 1]
        // let data = {      
        //     "eventExternal": {
        //         "name":"request_resetpassword",
        //         "key":"mykey"
        //     },
        //     "transferObjectMap": {
        //         "gatewayrequest": {
        //             "password": this.resetForm.value.newpassword,
        //             "token":page
        //         }
        //     }
        // }
          
        let data = {
            "password":this.resetForm.value.newpassword,
            "token":page
           }
        this.spinnerService.show();
        this.server.postApi('account/reset-password', data,0).subscribe(response => {
            this.spinnerService.hide();
            if (response.status == 200) {
                this.appC.showSuccToast("password changed successfully");
                this.router.navigate(['header']);
                
            } else if(response.status== 403){
                this.appC.showErrToast(response.message); 
                this.header.tokenExpire()
            } else {
                this.appC.showErrToast(response.message);
                
            }
        }, error => {
            this.spinnerService.hide();
            this.appC.showErrToast('Something went wrong');
        });
    }

}
