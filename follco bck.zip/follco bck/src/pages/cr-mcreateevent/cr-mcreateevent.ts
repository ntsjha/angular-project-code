import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, App } from 'ionic-angular';
import { SettingprivacyPage } from '../settingprivacy/settingprivacy';
import { RestProvider } from '../../providers/rest/rest';
import { CrmPage } from '../crm/crm';
import { FormGroup, Validators, FormControl } from '@angular/forms';

/**
 * Generated class for the CrMcreateeventPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-cr-mcreateevent',
  templateUrl: 'cr-mcreateevent.html',
})
export class CrMcreateeventPage {
  reminderArr: any=[];
  newArrrr: any=[];
  eventForm:FormGroup;
   show: boolean = false;
   show1: boolean = false;
  validation_messages = {
     'startDate': [
      { type: 'required', message: 'Start date is required.' },
      // { type: 'pattern', message: 'Please enter a valid email.' }
    ],
    'enddate':[
      { type: 'required', message: 'End date is required.' },
    ],
    'eventtype': [
      { type: 'required', message: 'Type is required.' },
      
    ],
  };
  leadsList: any;
  CutomerList: any;
  type1: any;
  value: any;
  newArrrr1: any=[];
  value1: any;
  startdatehours: any;
  startdateminutes: any;
  enddateminutes: any;
  enddatehours: any;
  constructor(public navCtrl: NavController,private service: RestProvider, public app :App,public navParams: NavParams) {
    this.eventForm = new FormGroup({
      title: new FormControl('', Validators.compose([
        Validators.maxLength(132),
        //  Validators.required,
        //  Validators.pattern(/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/)
       ])),
       startDate: new FormControl('', Validators.compose([
        Validators.required,
       ])),
       startdateTime: new FormControl('', Validators.compose([
         
       ])),
      //  startdateminutes: new FormControl('', Validators.compose([
      //   //  Validators.required,
      //  ])),
       enddate: new FormControl('', Validators.compose([
        Validators.required,
       ])),
       enddateTime: new FormControl('', Validators.compose([
         
       ])),
      //  enddateminutes: new FormControl('', Validators.compose([
         
      //  ])),
       reminder: new FormControl('', Validators.compose([
         
       ])),
       eventnote: new FormControl('', Validators.compose([
         
       ])),
       location:new FormControl('', Validators.compose([
         
       ])),
       eventtype:new FormControl('', Validators.compose([
        Validators.required,
      ])),
      customer_id:new FormControl('', Validators.compose([
         
      ])),
      lead_id:new FormControl('', Validators.compose([
         
      ])),
     });
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad CrMcreateeventPage');
    this.getReminder();
    this.getcustomers();
    this.getleads();
  }
  back(){
    this.navCtrl.pop();
  }
  setting()
{
  this.app.getRootNav().push(SettingprivacyPage);
}

onChange(type1) {
  console.log(type1);
   if(this.type1 == 'Customer meeting') {
    // this.value = 'customer';
    this.show = true;
    this.show1 = false; 
    
  }
  else if (this.type1 == 'Lead meeting') {
    // this.value = 'lead';  
    this.show = false;  
    this.show1 = true; 
   
  }
  else{
    this.show = false;  
    this.show1 = false; 
  }
}
Createevent(data){
//   var a="12:00";
// undefined
// var d= a.split(':');
// undefined
// d[0]
// "12"
// d[1]
// "00"


var a= this.eventForm.value.startDate.substring(11,16);
var startTime = a.split(':');
this.startdatehours =startTime[0];
this.startdateminutes=startTime[1];

console.log('start_time====>',this.startdatehours);
var b= this.eventForm.value.enddate.substring(11,16);
var endTime =b.split(':');
this.enddatehours =endTime[0];
this.enddateminutes =endTime[1];




  console.log(data);
  console.log(data.type);
  this.service.presentLoadingDefault('Creating event...');
  console.log('startdate====>',this.eventForm.value.startDate.substring(11,16));
  console.log('enddate====>',this.eventForm.value.enddate.substring(11,16));
  console.log('startdate====>',this.eventForm.value.startDate.substring(0,10));
  console.log('enddate====>',this.eventForm.value.enddate.substring(0,10));
  if(this.type1== 'customer'){
    let data1= new FormData();
    data1.append('customer_id',this.eventForm.value.customer_id);
    data1.append('event_title',this.eventForm.value.title);
    data1.append('event_date',this.eventForm.value.startDatedate.substring(0,10));
    data1.append('event_time_hour',this.startdatehours);
    data1.append('event_time_minute',this.startdateminutes);
    data1.append('event_time_end_date',this.eventForm.value.enddatedate.substring(0,10));
    data1.append('event_time_end_hour',this.enddatehours);
    data1.append('event_time_end_minute',this.enddateminutes);
    data1.append('reminder',this.eventForm.value.reminder =='None' ? '' : this.eventForm.value.reminder);
    data1.append('event_notes',this.eventForm.value.eventnote);
    data1.append('location',this.eventForm.value.location);
    data1.append('event_type',this.eventForm.value.eventtype);
    console.log("data1===+++>>",data1)
    this.service.post('events/save?follco_token=' + localStorage.getItem('new_token'),data1,0).subscribe(res =>{
    console.log("Succ"+JSON.stringify(res)); 
    
    
    if(res.message){
      this.service.dismissLoading();
      this.service.presentToast(res.message) ; 
      this.navCtrl.pop();
    }else{
      this.service.presentToast(res.error) ; 
      this.service.dismissLoading();
      
    }
   
   
  },err =>{
    console.log(err);
    
  })

  }
  else if(this.type1 == 'lead'){
    let data2= new FormData();
    data2.append('lead_id',this.eventForm.value.lead_id);
    data2.append('event_title',this.eventForm.value.title);
    data2.append('event_date',this.eventForm.value.startDate.substring(0,10));
    data2.append('event_time_hour',this.startdatehours);
    data2.append('event_time_minute',this.startdateminutes);
    data2.append('event_time_end_date',this.eventForm.value.enddate.substring(0,10));
    data2.append('event_time_end_hour',this.enddatehours);
    data2.append('event_time_end_minute',this.enddateminutes);
    data2.append('reminder',this.eventForm.value.reminder =='None' ? '' : this.eventForm.value.reminder);
    data2.append('event_notes',this.eventForm.value.eventnote);
    data2.append('location',this.eventForm.value.location);
    data2.append('event_type',this.eventForm.value.eventtype);
    console.log("data2===+++>>",data2)
    this.service.post('events/save?follco_token=' + localStorage.getItem('new_token'),data2,0).subscribe(res =>{
    console.log("Succ"+JSON.stringify(res)); 
    
    
    if(res.message){
      this.service.dismissLoading();
      this.service.presentToast(res.message); 
      this.navCtrl.pop();
    }else{
      this.service.presentToast(res.error) ; 
      this.service.dismissLoading();
      
    }
   
   
  },err =>{
    console.log(err);
    
  })
    
  }
  else{
    let data3= new FormData();
    // data1.append('customer_id',this.eventForm.value.firstname);
    data3.append('event_title',this.eventForm.value.title);
    data3.append('event_date',this.eventForm.value.startDate.substring(0,10));
    data3.append('event_time_hour',this.startdatehours);
    data3.append('event_time_minute',this.startdateminutes);
    data3.append('event_time_end_date',this.eventForm.value.enddate.substring(0,10));
    data3.append('event_time_end_hour',this.enddatehours);
    data3.append('event_time_end_minute',this.enddateminutes);
    data3.append('reminder',this.eventForm.value.reminder =='None' ? '' : this.eventForm.value.reminder);
    data3.append('event_notes',this.eventForm.value.eventnote);
    data3.append('location',this.eventForm.value.location);
    data3.append('event_type',this.eventForm.value.eventtype);
    console.log("data3===+++>>",data3)
    this.service.post('events/save?follco_token=' + localStorage.getItem('new_token'),data3,0).subscribe(res =>{
    console.log("Succ"+JSON.stringify(res)); 
    
    
    if(res.message){
      this.service.dismissLoading();
      this.service.presentToast(res.message) ; 
      this.navCtrl.pop();
    }else{
      this.service.presentToast(res.error) ; 
      this.service.dismissLoading();
      
    }
   
   
  },err =>{
    console.log(err);
    
  })

  }
  
   

}
getReminder(){
  // console.log('Country')
   this.service.get('misc/reminder_value_list',0).subscribe(res =>{
     console.log('ReminderList'+JSON.stringify(res));
     if(res){
      this.reminderArr = res['list'];
      console.log('reminderList=====>>>>'+JSON.stringify(this.reminderArr));
      for (let [key, value] of (<any>Object).entries(this.reminderArr)) {  
        console.log('Aashish====> ',key + ':' + value);
        if(key == ''){
          this. newArrrr1.push({
            'Key'  :  'None',
            'Type' :  value
          })
        }else{
          this. newArrrr1.push({
            'Key' : key,
            'Type' : value
          })
        }

      }
      // this.newArrrr1 = [{"Key":"None","Type":"None"},{"Key":"5min","Type":"5 minutes before"},{"Key":"15min","Type":"15 minutes before"},{"Key":"30min","Type":"30 minutes before"},{"Key":"1hour","Type":"1 Hour before"},{"Key":"2hour","Type":"2 Hours before"},{"Key":"1day","Type":"1 Day before"},{"Key":"2day","Type":"2 Days before"},{"Key":"1week","Type":"1 week"}]
      console.log('shivam===>'+JSON.stringify(this.newArrrr1))


     }
   
   },err =>{
     console.log(err)
   })
}
getleads() {
  // this.service.presentLoadingDefault('Loading...');
  this.service.get('leads/list?follco_token=' + localStorage.getItem('new_token'),0).subscribe(res =>{
      console.log(res);
      if(res) {
          // this.service.dismissLoading();
          this.leadsList = res['list'];
          
          // this.time = new Date (this.campaignList[0].created_at);
          // this.time1 =this.time.getDate() + '/' + (this.time.getMonth()+1) + '/' + this.time.getFullYear();
          // console.log(this.time1); 
       
        
      }
  }, err => {
      // this.service.dismissLoading();
      console.log(err);
  })
}
getcustomers() {
  // this.service.presentLoadingDefault('Loading...');
  this.service.get('customers/list?follco_token=' + localStorage.getItem('new_token'),0).subscribe(res =>{
      console.log(res);
      if(res) {
          // this.service.dismissLoading();
          this.CutomerList = res['list'];
         
          // this.time = new Date (this.campaignList[0].created_at);
          // this.time1 =this.time.getDate() + '/' + (this.time.getMonth()+1) + '/' + this.time.getFullYear();
          // console.log(this.time1); 
       
        
      }
  }, err => {
      // this.service.dismissLoading();
      console.log(err);
  })
}
}
