import { Component, OnInit } from '@angular/core';
import { IMyDpOptions, IMyDateModel } from 'mydatepicker';
import { ServiceService } from 'src/app/service/service.service';
import { Router } from '@angular/router';

@Component({
    selector: 'app-report-commission',
    templateUrl: './report-commission.component.html',
    styleUrls: ['./report-commission.component.css']
})
export class ReportCommissionComponent implements OnInit {
    reportArr: any=[];
    obj:any={}
    total :any =0;
    page = 1;
    public fromPickerOptions: IMyDpOptions = {
        dateFormat: 'dd.mm.yyyy',
    };
    public toPickerOptions: IMyDpOptions = {
        dateFormat: 'dd.mm.yyyy',
    };
    constructor(public service:ServiceService, public router:Router) { 
       
    }

    ngOnInit() {
        window.scrollTo(0, 0);
    }

    onFromDateChanged(event: IMyDateModel) {
        let copy1 = this.getCopyOfOptions1();
        copy1.disableUntil = event.date
        this.toPickerOptions = copy1; 
    }

    getCopyOfOptions1(): IMyDpOptions {
        return JSON.parse(JSON.stringify(this.toPickerOptions));
    }

    getCopyOfOptions2(): IMyDpOptions {
        return JSON.parse(JSON.stringify(this.fromPickerOptions));
    }
    onToDateChanged(event: IMyDateModel) {
        let copy1 = this.getCopyOfOptions2();
        copy1.disableSince = event.date
        this.fromPickerOptions = copy1;
    }

}
