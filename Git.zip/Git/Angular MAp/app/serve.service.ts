import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})

export class ServeService {
  single:any;
 teacher:any ;
 student:any;
 studata:any;
  // slang: any;
  // slong: any;
  empp:any[];
  constructor() {
    this.empp = [
      { empcode:'01',name:'Nitesh Jha'  },
      { empcode:'02',name:'Deepak Jha'  },
      { empcode:'03',name:'Sanjeev Jha'  },
    ];
   }

   rights():boolean{ 
     return true;


   }
}
