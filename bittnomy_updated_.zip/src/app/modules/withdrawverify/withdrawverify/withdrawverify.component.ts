import { Component, OnInit } from '@angular/core';
import { ServerService } from '../../../service/server.service';
import { Ng4LoadingSpinnerService } from '../../../../../node_modules/ng4-loading-spinner';
import { HeaderComponent } from '../../header/header/header.component';
import { AppComponent } from '../../../app.component';

@Component({
    selector: 'app-withdrawverify',
    templateUrl: './withdrawverify.component.html',
    styleUrls: ['./withdrawverify.component.css']
})
export class WithdrawverifyComponent implements OnInit {
    page: boolean = true;
    message: any;
    processing: boolean;

    constructor( private appC: AppComponent, private server: ServerService, private spinnerService: Ng4LoadingSpinnerService, public header: HeaderComponent) { }

    ngOnInit() {
        window.scrollTo(0, 0);
        this.urlCheck();
    }

    urlCheck() {
        let url = window.location.href.split('#'); 
        let page = url[url.length - 1];
        if(page == '1') 
            this.rejectWithdrawalAPI();
        else 
            this.withdrawalAPI();
    }

    /** Function for submit withdraw request */
    withdrawalAPI() {
        this.processing = false;
        let url = window.location.href.split('/');
        let page = url[url.length - 1];
        let url1 = page.split('_');
        let data =  {
            "eventExternal":{
                "name":"request_withdraw",
                "key":"mykey"
            },
            "transferObjectMap": {
                "gatewayrequest": {
                    "isWithdraw":'true',
                    "token": url1[0],
                    "uniqueKey": url1[1]
                }
            }              
        }
        this.spinnerService.show();
        this.server.postApi("",data,0).subscribe((succ) => {
            this.spinnerService.hide();
            this.page = true;
            //this.appC.showInfoToast("Withdrawal is successfully completed.");
            if(succ.transferObjectMap.statusCode == 200) {
                this.page = true;
                this.processing = true;
                this.message = succ.transferObjectMap.message;
                //this.appC.showInfoToast("Withdrawal is successfully completed.");
            } else if(succ.transferObjectMap.statusCode == 201) {
                this.page = false;
                this.appC.showErrToast(succ.transferObjectMap.message);
            } else if(succ.transferObjectMap.statusCode == 403){
                this.header.tokenExpire();
            } else if(succ.transferObjectMap.transactionType == 'FIAT') {
                this.page = true;
                this.processing = true;
                this.message = 'Your withdraw request has been confirmed successfully.';
            } else {
                this.page = false;
               //this.appC.showErrToast(succ.transferObjectMap.message);
            }
        }, (err) => {
            this.page = false;
            this.spinnerService.hide();
            //this.appC.showErrToast("Something went wrong.");
        });
    }

    /** Function for submit withdraw request */
    rejectWithdrawalAPI() {
        this.processing = false;
        let url = window.location.href.split('/');
        let page = url[url.length - 1];
        let url1 = page.split('_');
        let url2 = url1[1].split('#');
        let data =  {
            "eventExternal":{
                "name":"request_withdraw_cancel",
                "key":"mykey"
            },
            "transferObjectMap": {
                "gatewayrequest": {
                    "token": url1[0],
                    "uniqueKey": url2[0]
                }
            }              
        }
        this.spinnerService.show();
        this.server.postApi("",data,0).subscribe((succ) => {
            this.spinnerService.hide();
            //this.appC.showInfoToast("Withdrawal is successfully completed.");
            if(succ.transferObjectMap.statusCode == 200) {
                this.processing = true;
                this.page = true;
                this.message = succ.transferObjectMap.message;
                //this.appC.showInfoToast("Your withdrawal process is rejected");
            } else if(succ.transferObjectMap.statusCode == 201) {
                this.page = false;
                this.appC.showErrToast(succ.transferObjectMap.message);
            } else if(succ.transferObjectMap.statusCode == 403){
                this.header.tokenExpire();
            } else {
                this.page = false;
                //this.appC.showErrToast(succ.transferObjectMap.message);
            }
        }, (err) => {
            this.page = false;
            this.spinnerService.hide();
            //this.appC.showErrToast("Something went wrong.");
        });
    }
}
