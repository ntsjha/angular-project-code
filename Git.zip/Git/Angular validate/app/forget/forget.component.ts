import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators} from '@angular/forms';
@Component({
  selector: 'app-forget',
  templateUrl: './forget.component.html',
  styleUrls: ['./forget.component.css']
})
export class ForgetComponent {

  submitted = false;
  
      forget = new FormGroup({
    email: new FormControl('',[Validators.required,Validators.pattern(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/)]), 
    number: new FormControl('',[Validators.required, 
      Validators.pattern(/^\+?\d{2}[- ]?\d{3}[- ]?\d{5}$/)] ),
    

  });
  onSubmit() {
    // TODO: Use EventEmitter with form value
    for (let i = 0; i < localStorage.length; i++){
      let key = localStorage.key(i);
      let value = localStorage.getItem(key);
      console.log(key, value);
    }
    
    let myObj = { Fullinformation: this.forget.value };
    localStorage.setItem('i', JSON.stringify(myObj));
    
    
    var retrievedObject = localStorage.getItem('i');

    console.log('retrievedObject: ', JSON.parse(retrievedObject)); 
    alert(retrievedObject);
    this.submitted = true;
    console.warn(this.forget.value);
    
  }


  ngOnInit(){
    this.forget.valueChanges.subscribe((event) => {
      console.log(event.email)
         })
  
  }
  onreset() {
    this.forget.patchValue({
      email:"Jaipur@jp.com",
      //number:"2323232323"
    
    })
  
  }
}
