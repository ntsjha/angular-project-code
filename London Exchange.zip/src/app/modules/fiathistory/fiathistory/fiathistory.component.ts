import { Component, OnInit } from '@angular/core';
import { AppComponent } from '../../../app.component';
import { ServerService } from '../../../service/server.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { HeaderComponent } from '../../header/header/header.component';

@Component({
    selector: 'app-fiathistory',
    templateUrl: './fiathistory.component.html',
    styleUrls: ['./fiathistory.component.css']
})
export class FiathistoryComponent implements OnInit {
    currCoin = "USD";
    history = [];
    currTab = "DEPOSIT";

    constructor(private appC: AppComponent, private server: ServerService, private spinnerService: Ng4LoadingSpinnerService, public header: HeaderComponent) { }

    ngOnInit() {
        this.deposit(this.currTab,this.currCoin);
    }

    /** Function to select coin */
    selectCoin(coin) {
        this.currCoin = coin;
        this.history = [];
        this.deposit(this.currTab,this.currCoin);
    }

    tabClick(val) {
        this.currTab = val;
        this.deposit(this.currTab,this.currCoin);
    }

    deposit(tab,coin) {
        let data = {
            "eventExternal": {
                "name":"withdrawlist_history",
                "key":"mykey"
            },
            "transferObjectMap": {
                "gatewayrequest": {
                "coinType": coin,
                "transactionType": tab,
                "token": localStorage.getItem("token")
                }
            }
        }
        this.spinnerService.show();
        this.server.postApi('', data,0).subscribe(response => {
            this.spinnerService.hide();
            if (response.transferObjectMap.statusCode == 200) {
                this.appC.showSuccToast(response.transferObjectMap.message);
                this.history = response.transferObjectMap.withdraws;
            } else if(response.transferObjectMap.statusCode == 403){
                this.appC.showErrToast(response.transferObjectMap.message); 
                this.header.tokenExpire()
            } else {
                this.appC.showErrToast(response.transferObjectMap.message);                     
            }
        }, error => {
            this.spinnerService.hide();
            this.appC.showErrToast('Something went wrong');
        });      
    }

}
