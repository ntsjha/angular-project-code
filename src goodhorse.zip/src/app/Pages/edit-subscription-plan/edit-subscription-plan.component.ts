import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ServiceService } from 'src/app/Shared/service.service';
import { AngularFirestore } from '@angular/fire/firestore';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { Subscriptionplan } from 'src/app/Shared/subscriptionplan';
@Component({
  selector: 'app-edit-subscription-plan',
  templateUrl: './edit-subscription-plan.component.html',
  styleUrls: ['./edit-subscription-plan.component.css']
})
export class EditSubscriptionPlanComponent implements OnInit {
  contributorForm: FormGroup;
  Subscriptionplan: Subscriptionplan[];
  SubscriptionplanLength: Subscriptionplan[];
  contentId: any;

  constructor(private router: Router, private firebaseServ: ServiceService, private afb: AngularFirestore,public route: ActivatedRoute) { }

  ngOnInit() {

    this.route.params.subscribe((res)=>{
      console.log('params--->>> ',res.id);
      this.contentId = res.id
    })    

    this.contributorForm = new FormGroup({
      planType: new FormControl('', [ Validators.required]),
      duration: new FormControl('', [Validators.pattern(/^[#.0-9a-zA-Z\s,-]+$/), Validators.required]),
      maxhorses: new FormControl('', [Validators.pattern(/^[#.0-9a-zA-Z\s,-]+$/), Validators.required]),
      price: new FormControl('',[Validators.required,Validators.maxLength(50)]),
    
  })
  this.getsubscription()
  }

  getsubscription(){
    this.firebaseServ.getSubscriptionplan().subscribe(res =>{
    this.Subscriptionplan=res.map( item =>{
     return{
       id: item.payload.doc.id,
       ...item.payload.doc.data()
     } as Subscriptionplan
   })
  
  this.SubscriptionplanLength = this.Subscriptionplan.filter(x=>(x.id == this.contentId))
  this.contributorForm.patchValue({
    'planType'  :this.SubscriptionplanLength[0].planType?this.SubscriptionplanLength[0].planType:'',
    'duration'  :this.SubscriptionplanLength[0].duration?this.SubscriptionplanLength[0].duration:'',
    'maxhorses' :this.SubscriptionplanLength[0].maxHorses?this.SubscriptionplanLength[0].maxHorses:'',
   'price'      :this.SubscriptionplanLength[0].price?this.SubscriptionplanLength[0].price:'',
  //  'description':this.SubscriptionplanLength[0].description?this.SubscriptionplanLength[0].description:''
  })
  this.firebaseServ.hideSpinner();
   console.log(this.SubscriptionplanLength)
  });
  }

  editSubscriptionplan() {
    //db.collection('books').doc('fK3ddutEpD2qQqRMXNW5').get()
    console.log(this.contributorForm.value)
    this.afb.collection('SubscriptionPlan').doc(this.SubscriptionplanLength[0].id).update({
      planType: this.contributorForm.value.planType,
      duration:this.contributorForm.value.duration,
      maxHorses: this.contributorForm.value.maxhorses,
      price: this.contributorForm.value.price,
      // description:this.contributorForm.value.description
    });
    this.firebaseServ.showSuccess('Subscription plan has been upated successfully.');
    this.router.navigate(['/subscription'])
  }
    
  preventSpace(event){
    if(event.charCode==32 && !event.target.value){
    event.preventDefault()
    } else{
    // console.log(event)
    }
    console.log('event',event.charCode)
  }
  
}
