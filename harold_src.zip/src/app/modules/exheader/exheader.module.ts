import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ExheaderComponent } from './exheader/exheader.component';
import { AppRoutingModule } from '../../app-routing.module';

@NgModule({
  imports: [
    CommonModule,
    AppRoutingModule,
  ],
  declarations: [ExheaderComponent]
})
export class ExheaderModule { }
