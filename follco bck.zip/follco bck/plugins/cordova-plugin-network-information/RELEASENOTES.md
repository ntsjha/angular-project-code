### 2.0.1 (Dec 27, 2017)
* [CB-13708](https://issues.apache.org/jira/browse/CB-13708) Fix to allow 2.0.0 version install (#60)

