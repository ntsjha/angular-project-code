import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ModalController, AlertController } from 'ionic-angular';
import { SignpinPage } from '../signpin/signpin';
import { SignupPage } from '../signup/signup';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { TabsPage } from '../tabs/tabs';
import { ForgotPage } from '../forgot/forgot';
import { HomePage } from '../home/home';
import { ServiceServicesProvider } from '../../providers/service-services/service-services';
import { Facebook, FacebookLoginResponse } from "@ionic-native/facebook";
import { GooglePlus } from "@ionic-native/google-plus";
import { PinPage } from "../pin/pin";

@IonicPage()
@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
})
export class LoginPage {
  form: FormGroup
  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    private server: ServiceServicesProvider,
    private modalCtrl: ModalController,
    public alerCtrl: AlertController,
    private fb: Facebook,
    private googlePlus: GooglePlus,
  ) {
  }
  // Validators.pattern(/^\S*$/),
  ngOnInit() {
    this.form = new FormGroup({
      email: new FormControl('', [Validators.required]),
      password: new FormControl('', [Validators.required, Validators.pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,16})/i)])
    })
  }

  get email(): any {
    return this.form.get('email')
  }

  get password(): any {
    return this.form.get('password')
  }

  changeToggle(event) {
    if (event.target.checked == true) {
      this.navCtrl.setRoot(SignpinPage)
    }
  }

  loginWithPin() {
    this.navCtrl.setRoot(SignpinPage)
  }

  signup() {
    let data = {
      socialId: 12348567,
      socialType: "google",
      socialLogin: true,
      firstName: 'Deepika',
      lastName: '',
      email: 'deepika@google.com'
    }
    this.navCtrl.push(SignupPage)
  }

  login() {
    if (navigator.onLine){
      this.server.presentLoading();
    let data = {
      "userName": this.form.value.email,
      "password": this.form.value.password
    }
    this.server.postApi(data, 'user/login', 0).subscribe((response: any) => {
      this.server.dismissLoading();
      if (response['response_code'] == 200) {
        this.server.presentToast(response['response_message'])
        localStorage.setItem('JWT', response.result.token)
        localStorage.setItem('userId', response.result.userDetail._id)
        localStorage.setItem('userName', this.form.value.email);
        if (response.result.userDetail.pin)
          this.navCtrl.setRoot(TabsPage, { selectedTab: 2 })
        else
          this.navCtrl.setRoot(PinPage)
      } else if (response['response_code'] == 402 || response['response_code'] == 400 || response['response_code'] == 500) {
        this.server.presentToast(response['response_message'])
      } else if(response['response_code'] == 201){
        this.server.presentToast(response['response_message'])
        this.server.userId = response['result']._id;
        let modalPage = this.modalCtrl.create('ModalPage');
        modalPage.present();
        modalPage.onDidDismiss((data) => {
          if (data != 'failure') {
            if (response.result.userDetail.pin) {
              localStorage.setItem('JWT', response.result.token)
              localStorage.setItem('userId', response.result.userDetail._id)
              localStorage.setItem('userName', this.form.value.email);
              this.navCtrl.setRoot(TabsPage, { selectedTab: 2 })
            }
            else
              this.navCtrl.setRoot(PinPage)
          }
        });
      }
      else {
        this.server.presentToast(response['response_message'])
      }

    }, err => {
      this.server.dismissLoading();
      this.server.presentToast('Something went wrong')
    })
  } else
  this.server.presentToast('Your internet connection seems to be lost')
  }

  forget() {
    this.navCtrl.push(ForgotPage, { forgot: 'PASSWORD' })
  }

  loginFacebook() {
    if (navigator.onLine){
      this.server.presentLoading();
    this.fb.login(['email', 'public_profile']).then((response: FacebookLoginResponse) => {
      // this.server.dismissLoading();
      this.fb.api('me?fields=id,name,email,first_name,last_name,picture.width(720).height(720).as(picture_large)', []).then(profile => {
        let userData = { id: profile['id'], email: profile['email'], first_name: profile['first_name'], last_name: profile['first_name'], picture: profile['picture_large']['data']['url'], username: profile['name'] }
        let name = userData.username.split(" ")
        let params = {
          socialId: userData.id,
          socialType: "facebook",
          socialLogin: true,
          firstName: name[0],
          lastName: name[1],
          email: userData.email
        }
        this.checkForSocialLogin(params);
      })
    },
      err => {
        this.server.dismissLoading();
        this.server.presentToast('Facebook is experiencing some issues currently. Please try again later')
      })
      .catch(e => {
        this.server.dismissLoading();
        this.server.presentToast('Facebook is experiencing some issues currently. Please try again later')
      });  
    } else
    this.server.presentToast('Your internet connection seems to be lost')
  }

  loginGoogle() {
    console.log('GooglePlus_Plugin Called')
    if(navigator.onLine){
      this.server.presentLoading();
    this.googlePlus.login({}).then(res => {
  console.log('GooglePlus res--->>',JSON.stringify(res))
      // this.server.dismissLoading();
      let userData = res;
      var regex = new RegExp("^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$")
      let name;
      var check = regex.test(userData.displayName)
      if (check)
        name = ["", ""]
      else
        name = userData.displayName.split(" ")
      let params = {
        socialId: userData.userId,
        socialType: "google",
        socialLogin: true,
        firstName: name[0],
        lastName: name[1],
        email: userData.email
      }
      console.log('params--->>',JSON.stringify(params))

      this.checkForSocialLogin(params);
    }, err => {
      console.log('error=>'+JSON.stringify(err));
      this.server.dismissLoading();
      this.server.presentToast('Google is experiencing some issues currently. Please try again later')
    })
      .catch(err => {
        console.log('error=>'+JSON.stringify(err));
        this.server.dismissLoading();
        this.server.presentToast('Google is experiencing some issues currently. Please try again later')
      });
    } else
    this.server.presentToast('Your internet connection seems to be lost')
  }

  checkForSocialLogin(params) {
    if (navigator.onLine){
      let data = {
      socialId: params.socialId,
      socialType: params.socialType
    }
    this.server.postApi(data, 'user/socialLogin', 0).subscribe(
      (response: any) => {
        console.log('GooglePlus Api res--->>',JSON.stringify(response))

        this.server.dismissLoading();
        if (response['response_code'] == 200) {
          this.server.presentToast(response['response_message'])
          localStorage.setItem('JWT', response.result.token)
          localStorage.setItem('userId', response.result.userDetail._id)
          localStorage.setItem('userName', response.result.userDetail.userName);
          if (response.result.userDetail.pin)
            this.navCtrl.setRoot(TabsPage, { selectedTab: 2 })
          else
            this.navCtrl.setRoot( PinPage)
        }
        else {
          this.server.presentToast(response['response_message'])
          this.navCtrl.push(SignupPage, {params: params})
        }
      },
      err => {
        this.server.dismissLoading();
      })
    } else
    this.server.presentToast('Your internet connection seems to be lost')
  }

  loginGoogle2(){
    this.googlePlus.login({}).then(res => {
      console.log('GooglePlus res--->>',JSON.stringify(res))
    }).catch(err =>{
      console.log('GooglePluss Err --->>',err)
    })

  }
}
