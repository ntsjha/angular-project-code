import { Component, OnInit } from '@angular/core';
import { ServiceService } from 'src/app/service/service.service';
import { CookieService } from 'ngx-cookie-service';
import { NgxSpinnerService } from 'ngx-spinner';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
    selector: 'app-view-admin',
    templateUrl: './view-admin.component.html',
    styleUrls: ['./view-admin.component.css']
})
export class ViewAdminComponent implements OnInit {

    adminDetails: any = {};
    userData: any = {};
    permissionArray = [];
    google: any = { one: '', two: '', three: '', four: '', five: '', six: '' };
    id: any;
    email: any;
    arr: any = [];

    constructor(private service: ServiceService, private cookie: CookieService, private spinner: NgxSpinnerService, private activatedRoute: ActivatedRoute, private router: Router) {}

    ngOnInit() {
        this.activatedRoute.params.subscribe(id => {
            this.id = id.id;
            this.viewAdminProfile(id.id);
        });
        window.scrollTo(0, 0);
    }

    /** Function to view admin profile */
    viewAdminProfile(id) {
        this.spinner.show();
        const data = {
            userId: this.service.encrypt(String(id)),
        };
        this.service.postMethod('account/superAdmin/user-management/get-admin-profile', data, 1).subscribe((response: any) => {
            this.spinner.hide();
            const responseData = response.data;
            this.userData = responseData;
            this.spinner.hide();
            this.permissionArray = responseData.userPermissions;
            this.createArr();
            this.email = this.userData.userDetails.email;
        }, (error) => {
            this.spinner.hide();
        });
    }

    createArr() {
        this.arr = [];
        this.permissionArray.forEach(element => {
            if (element.masterPermissionList.menuPermission.menuName) {
                this.arr.push(element);
            }
        });
        this.permissionArray.forEach(element => {
            if (element.masterPermissionList.menuPermission.subMenuName) {
                this.arr.forEach((menu, ind) => {
                    if (menu.masterPermissionList.masterPermissionListId == element.masterPermissionList.parentId) {
                        this.arr.splice(ind + 1, 0, element);
                    }
                });
            }
        });
    }

    /** Auto focus functionality */
    onKey(event, next, previous) {
        if (event.key === 'Backspace') {
            document.getElementById(previous).focus();
        } else {
            if (event.keyCode >= 48 && event.keyCode <= 57) {
                if (event.target.value.trim() !== '') {
                    document.getElementById(next).focus();
                } else {
                    event.target.value = '';
                }
            } else {
                event.target.value = '';
            }
        }
    }


    goToFunc(val) {
        switch (val) {
            case 1:
                this.service.email = this.email;
                this.router.navigateByUrl('logs');
                break;
            case 2:
                this.router.navigateByUrl('edit-admin/' + this.id);
                break;
        }
    }

}
