import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditJobComponent } from './edit-job.component';
import { FormGroup, FormControl, Validators } from '@angular/forms';

describe('EditJobComponent', () => {
  let component: EditJobComponent;
  let fixture: ComponentFixture<EditJobComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [EditJobComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditJobComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    this.editJobForm = new FormGroup({
      title: new FormControl('', [Validators.required]),
      editorValue: new FormControl('', [Validators.required]),
      noOfOpenings: new FormControl('', [Validators.required])
    })
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('general form invalid when empty', async(() => {
    const emptyValue = component.editJobFormTest('', '', '');
    expect(emptyValue).toBeFalsy();
  }));

  it('general form valid with all fields', async(() => {
    const value = component.editJobFormTest('title', 'description', '5');
    expect(value).toBeTruthy();
  }));
});
