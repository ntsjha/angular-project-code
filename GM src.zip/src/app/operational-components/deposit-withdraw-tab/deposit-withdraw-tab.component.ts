import { Component, OnInit } from '@angular/core';
import { IMyDpOptions, IMyDateModel } from 'mydatepicker';
import { ServiceService } from 'src/app/service/service.service';
import { Router } from '@angular/router';
import { AngularCsv } from 'angular7-csv/dist/Angular-csv';

@Component({
    selector: 'app-deposit-withdraw-tab',
    templateUrl: './deposit-withdraw-tab.component.html',
    styleUrls: ['./deposit-withdraw-tab.component.css']
})
export class DepositWithdrawTabComponent implements OnInit {
    coinArr: any=[];
    obj:any={};

    public fromPickerOptions: IMyDpOptions = {
        dateFormat: 'dd.mm.yyyy',
    };
    public toPickerOptions: IMyDpOptions = {
        dateFormat: 'dd.mm.yyyy',
    };
    selectedTab: any='deposit';
    transacArr: any=[];
    selectedCoin: any;
    currencyType: any='crypto';
    page: number= 1;
    pageSize: any=10;
    total: number;
    constructor(public service:ServiceService, public router:Router) { 
    }

    ngOnInit() {
        this.getCurrencyList();
        this.getCurrencyType('crypto');
        window.scrollTo(0, 0);
    }

    getCurrencyList() {
        this.service.getMethod('wallet/currency/get-currency-list',1).subscribe((res)=> {
            if(res['data']){
                let data = JSON.parse(this.service.decrypt(res['data']));
                this.coinArr = data.data;
            }
        });
    }

    onFromDateChanged(event: IMyDateModel) {
        let copy1 = this.getCopyOfOptions1();
        copy1.disableUntil = event.date;
        this.toPickerOptions = copy1; 
    }

    getCopyOfOptions1(): IMyDpOptions {
        return JSON.parse(JSON.stringify(this.toPickerOptions));
    }

    getCopyOfOptions2(): IMyDpOptions {
        return JSON.parse(JSON.stringify(this.fromPickerOptions));
    }
    
    onToDateChanged(event: IMyDateModel) {
        let copy1 = this.getCopyOfOptions2();
        copy1.disableSince = event.date;
        this.fromPickerOptions = copy1;
    }

    selectTab(tab) {
        this.selectedTab =  tab;
        this.page = 1 ;
        this.total = 0;
        this.getData();
    }

    getCurrencyType(type) {
        this.transacArr = [];
        this.total = 0;
        this.currencyType = type;
        this.getData();
    }

    getData() {
        let type = this.currencyType;
        let url , data = {};
        if(this.selectedTab == 'deposit') {
            if(type== 'fiat') {
                url = 'wallet/admin/history/get-transaction-history-fiat';
                data['txnType'] = "USER_DEPOSIT";
            }else {
                url = 'wallet/admin/history/get-transfer-history';
                data['txnType'] = "USER_DEPOSIT";
            }
        }else if(this.selectedTab == 'withdrawal') {
            if(type == 'crypto') {
                url = 'wallet/admin/history/get-transfer-history';
                data['txnType'] = "WITHDRAW";
            }else {
                url = 'wallet/admin/history/get-transaction-history-fiat';
                data['txnType'] = "WITHDRAW";
            }
        }

        if(this.selectCoin) {
            data['coinName'] = this.selectedCoin;
        }

        if(this.obj.fromDate && this.obj.toDate) {
            data['fromDate'] = this.obj.fromDate.epoc;
            data['toDate'] =  this.obj.toDate.epoc;
        }

        data['page'] = this.page - 1;
        data['pageSize'] = this.pageSize;
        this.service.postMethod(url,data,1).subscribe((res)=>{
           this.transacArr  = res.data.resultlist;  
           this.total =  res.data.totalCount;
        });
    }

    selectCoin(coin) {
        this.selectedCoin = coin;
    }

    exportList() {
        let headerArr = [];
        if(this.selectedTab == 'deposit') {
            headerArr = ['Date','Currency','From Address','Amount','Transaction Id','Status'];
        }
        var options = { 
            fieldSeparator: ',',
            quoteStrings: '"',
            decimalseparator: '.',
            showLabels: true,
            showTitle: true,
            title: 'Transaction List :',
            useBom: true,
            noDownload: false,
            headers: headerArr
        };

        let data = [];
        let obj = {};
        this.transacArr.forEach((element,index) => {
           
            if(this.selectedTab == 'deposit') {
                obj = {
                    'date' : '',
                    'currency': '',
                    'from_address': '',
                    'amount': '',
                    'transac_id': '',
                    'status': ''
                };
            }else {
                obj = {
                    'date' : '',
                    'currency':'',
                    'to_address': '',
                    'amount': '',
                    'fee': '',
                    'status': '',
                    'ip': '',
                    'location': ''
                };
            }
        });
        data.push(obj);
        new AngularCsv(data, 'Transaction List', options);
    }

    callOnSubmit() {
        this.page = 1;
        this.total = 0;
        this.getData();
    }

    managePagination(page) {
        this.page = page;
        this.total = 0;
    }

    reset() {
        this.transacArr = [];
        this.page = 1;
        this.total = 0;
        this.obj.fromDate = '';
        this.obj.toDate = '';
        this.fromPickerOptions = {
            disableSince: { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() + 1 },
            disableUntil: { year: 0, month: 0, day: 0 }
        };
        this.toPickerOptions = {
            disableSince: { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() + 1 },
            disableUntil: { year: 0, month: 0, day: 0 }
        };
        this.getData();
    }
    

}
