import { hrTradeChartService } from './hrTradeChart';
import { Component, OnInit, AfterViewInit, OnDestroy } from '@angular/core';
import { ServiceService } from 'src/app/service/service.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { walletChart } from './walletChart';
import { hrTradeFIATChartService } from './hrTradeFIATChart';
import { hrWithdrawalCryptoChartService } from './hrWithdrawalCryptoChart';
import { hrWithdrawalFIATChartService } from './hrWithdrawalFIATChart';
import { hrDepositeCryptoChartService } from './hrDepositeCryptoChart';
import { hrDepositeFIATChartService } from './hrDepositeFIATChart';
import { totalJobsService } from './totalJobs';
import { Subject } from 'rxjs';
import { totalApplicationService } from './totalApplications';
import { marketingGraphService } from './marketingGraph';

declare var angular: any;

@Component({
    selector: 'app-dashboard',
    templateUrl: './dashboard.component.html',
    styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit, AfterViewInit, OnDestroy {
    dashboardData: any;
    hrDashboardData: any;
    getPromotionListArr: any = [];
    dualApproval: any = [];
    getDefaultRewardSetting: any = [];
    private subject = new Subject<any>();
    role: any;
    eventCount: any;
    offerCount: any;
    ticketCount: any;
    totalOffers: any;
    adminRoleSubscription: any;
    onGoingEvent: any;
    upcomingEvent: any;
    onGoingEventCount: any;
    upcomingEventCount: any;
    topFiveOffer: any = [];
    currentRewardPoints: any;
    offerExpiringNextWeek: any = [];
    viewData = 'monthly';
    withdrawlStatus = false;
    tradingStatus = false;
    depositStatus = false;
    maintenanceStartDate: any = null;
    maintenanceEndDate: any = null;
    page = 1;
    expiryOfferPage: any = { p: 1, page: 0, total: 0 };
    topFivePerformingOffer: any = { p: 1, page: 0, total: 0 };
    onGoingEventPage: any = { p: 1, page: 0, total: 0 };
    upcomingEventPage: any = { p: 1, page: 0, total: 0 };

    constructor(
        private service: ServiceService,
        private spinner: NgxSpinnerService,
        private walletChartService: walletChart,
        private hrTradeChart: hrTradeChartService,
        private hrTradeFIATChart: hrTradeFIATChartService,
        private hrWithdrawalCryptoChart: hrWithdrawalCryptoChartService,
        private hrWithdrawalFIATChart: hrWithdrawalFIATChartService,
        private hrDepositeCryptoChart: hrDepositeCryptoChartService,
        private hrDepositeFIATChart: hrDepositeFIATChartService,
        private hrTotalJobs: totalJobsService,
        private htTotalApplication: totalApplicationService,
        private marketingGraphApplication: marketingGraphService,
    ) { }

    ngOnInit() {
        window.scrollTo(0, 0);
        this.startLoader();
        this.getDashboardData();
        this.getDefaultReward();
        this.fetchDualApproval();
        this.getEventCount();
        this.getOfferCount();
        this.getTicketCount();
    }

    ngAfterViewInit() {
        this.adminRoleSubscription = this.service.adminRole.subscribe(value => {
            if (value) {
                this.role = value;
                setTimeout(() => {
                    this.graphInitialisingFunc();
                }, 2000);
            }
        });
    }

    graphInitialisingFunc() {
        if (this.role === 'SUPERADMIN' || this.role === 'ADMIN' || this.role === 'OPERATION' || this.role === 'ACCOUNTS') {
            if (!angular.element('#wallet-graph').length || !angular.element('#hr-trade-crypto').length
                || !angular.element('#hrFIATChart').length || !angular.element('#hrFIATChart').length
                || !angular.element('#hrWithdrawalCrypto').length || !angular.element('#hrWithdrawalFIAT').length
                || !angular.element('#hrDepositeCrypto').length || !angular.element('#hrDepositFIAT').length) {
                return;
            }
            this.getWithdrawCrypto();
            this.getDepositCrypto();
            this.getTradeCrypto();
            this.getWalletData();
            this.getCurrentRewardPoints();
            this.getExchangeFunctionControl();
            this.getMaintenanceModeDetails();
            this.getDefaultReward();
            const data = [];
            this.hrTradeFIATChart.hrTradeFIATChartData(data, 'hrFIATChart');
            this.hrWithdrawalFIATChart.hrWithdrawalFIATChartData(data, 'hrWithdrawalFIAT');
            this.hrDepositeFIATChart.hrDepositeCryptoChartData(data, 'hrDepositFIAT');
        } else if (this.role === 'HR') {
            if (!angular.element('#hrTotalJobs').length || !angular.element('#hrTotalApplication').length) {
                return;
            }
            this.getHrGraph();
            this.getTotalAttendes();
            this.getHrTotalCounts();
        } else if (this.role === 'MARKETING') {
            if (!angular.element('#marketingGraph').length) {
                return;
            }
            this.getOffersExpiringNextWeek(1);
            this.getTopFivePerformingOffer(1);
            this.getMarketingOngoingEvent(1);
            this.getUpcomingEvent(1);
            this.getMarketingGraph();
            this.getOfferCount();
            this.getCurrentRewardPoints();
            this.getOnGoingEventCount();
            this.getUpcomingEventCount();
            this.getDefaultReward();
        }
    }

    getExchangeFunctionControl() {
        this.service.postMethod('setting-service/common-permit/get-exchange-function-control', {}, 1)
            .subscribe((response: any) => {
                const data = JSON.parse(this.service.decrypt(response.data));
                const setData = data.data[0];
                if (data.status === 1516) {
                    this.depositStatus = setData.isDepositEnabled;
                    this.tradingStatus = setData.isTradingEnabled;
                    this.withdrawlStatus = setData.isWithdrawalEnabled;
                }
            }, (error) => {
                this.withdrawlStatus = false;
                this.tradingStatus = false;
                this.depositStatus = false;
            });
    }

    getMaintenanceModeDetails() {
        // this.service.postMethod('setting-service/common-permit/get-maintenance-mode-list?pageSize='+ encodeURIComponent(this.service.encrypt(JSON.stringify(10))) + '&page='+ encodeURIComponent(this.service.encrypt(this.page - 1)) , {}, 1).subscribe((response: any) => {
        this.service.getMethod('setting-service/common-permit/get-maintenance-mode-for-dashboard', 1).subscribe((response: any) => {
            let responseData = this.service.decrypt(response.data);
            responseData = JSON.parse(responseData);
            console.log(responseData)
            if (responseData.status === 1509) {
                this.maintenanceStartDate = responseData.data.scheduledMaintenanceStart;
                this.maintenanceEndDate = responseData.data.scheduledMaintenanceEnd;
            } 
        }, (error) => {
        });
    }

    getWithdrawCrypto() {
        this.service.getMethod('wallet/common-permit/graph-data/24hr-crypto-data?transactionType=WITHDRAW', 1)
            .subscribe((response: any) => {
                this.hrWithdrawalCryptoChart.hrwithdrawlCryptoChartData(response.data, 'hrWithdrawalCrypto');
            }, (error) => {
                this.hrWithdrawalCryptoChart.hrwithdrawlCryptoChartData('', 'hrWithdrawalCrypto');
            });
    }

    getDepositCrypto() {
        this.service.getMethod('wallet/common-permit/graph-data/24hr-crypto-data?transactionType=USER_DEPOSIT', 1)
            .subscribe((response: any) => {
                this.hrDepositeCryptoChart.hrDepositeCryptoChartData(response.data, 'hrDepositeCrypto');
            }, (error) => {
                this.hrDepositeCryptoChart.hrDepositeCryptoChartData('', 'hrDepositeCrypto');
            });
    }

    getTradeCrypto() {
        this.service.postMethod('order-service/common-permit/24hr-crypto', {}, 1)
            .subscribe((response: any) => {
                this.hrTradeChart.hrTradeChartData(response.data, 'hr-trade-crypto');
            }, (error) => {
                this.hrTradeChart.hrTradeChartData('', 'hr-trade-crypto');
            });
    }

    getHrGraph() {
        this.service.getMethod('career/common-permit/hr-dashboard', 1)
            .subscribe((response: any) => {
                if (response.status === 756) {
                    this.hrTotalJobs.totalJobsData(response.data, 'hrTotalJobs', 1);
                }
            }, (error) => {
                this.hrTotalJobs.totalJobsData('', 'hrTotalJobs', 1);
            });
    }

    getTotalAttendes() {
        this.service.getMethod('career/common-permit/hr-applicants-dashboard', 1)
            .subscribe((succ: any) => {
                if (succ.status === 758) {
                    this.htTotalApplication.totalJobsData(succ.data, 'hrTotalApplication');
                }
            }, (error) => {
                this.htTotalApplication.totalJobsData('', 'hrTotalApplication');
            });
    }

    getHrTotalCounts() {
        this.service.getMethod('career/common-permit/hr-dashboard-count', 1)
            .subscribe((response: any) => {
                if (response.status === 759) {
                    this.hrDashboardData = response.data;
                }
            }, (error) => {
            });
    }

    getMarketingGraph() {
        if (this.viewData === 'monthly') {
            this.service.getMethod('rewards/common-permit/get-rewards-monthly-graph-data', 1)
                .subscribe((succ: any) => {
                    if (succ.status === 200) {
                        this.marketingGraphApplication.totalJobsData(succ.data, 'marketingGraph', 1);
                    }
                }, (error) => {
                    this.marketingGraphApplication.totalJobsData('', 'marketingGraph', 1);
                });
        } else if (this.viewData === 'lastSevenDays') {
            this.service.getMethod('rewards/common-permit/get-rewards-sevendays-graph-data', 1)
                .subscribe((succ: any) => {
                    if (succ.status === 200) {
                        this.marketingGraphApplication.totalJobsData(succ.data, 'marketingGraph', 3);
                    }
                }, (error) => {
                    this.marketingGraphApplication.totalJobsData('', 'marketingGraph', 3);
                });
        } else if (this.viewData === 'weekly') {
            this.service.getMethod('rewards/common-permit/get-rewards-weekly-graph-data', 1)
                .subscribe((succ: any) => {
                    if (succ.status === 200) {
                        this.marketingGraphApplication.totalJobsData(succ.data, 'marketingGraph', 2);
                    }
                }, (error) => {
                    this.marketingGraphApplication.totalJobsData('', 'marketingGraph', 2);
                });
        }
    }

    getWalletData() {
        this.service.getMethod('wallet/common-permit/graph-data/get-storage-amount-data', 1)
            .subscribe((response: any) => {
                this.walletChartService.walletData(response.data, 'wallet-graph');
            }, (error) => {
                this.walletChartService.walletData('', 'wallet-graph');
            });
    }

    getCurrentRewardPoints() {
        this.service.postMethod('rewards/common-permit/total-points-of-users', {}, 1)
            .subscribe((response: any) => {
                if (response.status === 1333) {
                    this.currentRewardPoints = response.data;
                }
            }, (error) => {
                this.walletChartService.walletData('', 'wallet-graph');
            });
    }

    getOnGoingEventCount() {
        this.service.postMethod('event/common-permit/get-ongoing-event-list-count', {}, 1)
            .subscribe((response) => {
                this.onGoingEventCount = response.data.ongoingEvent;
            }, (error) => {
            });
    }

    getUpcomingEventCount() {
        this.service.postMethod('event/common-permit/get-upcoming-event-list-count', {}, 1)
            .subscribe((response) => {
                this.upcomingEventCount = response.data.upcomingEvent;
            }, (error) => {
            });
    }

    startLoader() {
        this.spinner.show();
        setTimeout(() => {
            this.spinner.hide();
        }, 300);
    }

    getDashboardData() {
        this.service.postMethod('account/common-permit/dashboard-api', {}, 1)
            .subscribe((res) => {
                if (res.status === 550) {
                    this.dashboardData = res.data;
                }
            }, (error) => {
            });
    }

    getDefaultReward() {
        this.getDefaultRewardSetting = [];
        this.getPromotionListArr = [];
        this.service.getMethod('rewards/common-permit/get-default-reward-setting', 1).subscribe((response: any) => {
            if (response.status === 1328) {
                this.getDefaultRewardSetting = response.data.defaultRewardData;
                this.getPromotionListArr = response.data.promotionData[0];
            }
        }, (error) => {
        });
    }

    fetchDualApproval() {
        this.service.postMethod('account/common-permit/fetch-details-for-dual-approval', {}, 1)
            .subscribe((res) => {
                if (res.status === 550) {
                    this.dualApproval = res.data.list;
                }
            }, (error) => {
            });
    }

    getOffersExpiringNextWeek(page) {
        this.expiryOfferPage.p = page;
        this.expiryOfferPage.page = page - 1;
        this.service.postMethod('rewards/common-permit/list-offer-expire-next-week?page=' + this.expiryOfferPage.page + '&pageSize=5', {}, 1)
            .subscribe((res) => {
                if (res.status === 1334) {
                    res.data.data.forEach(element => {
                        if (element != null) {
                            this.offerExpiringNextWeek.push(element);
                        }
                    });
                    this.expiryOfferPage.total = res.data.totalSize;
                } else {
                    this.offerExpiringNextWeek = [];
                    this.expiryOfferPage.total = 0;
                }
            }, (error) => {
                this.offerExpiringNextWeek = [];
                this.expiryOfferPage.total = 0;
            });
    }

    getTopFivePerformingOffer(page) {
        this.topFivePerformingOffer.p = page;
        this.topFivePerformingOffer.page = page - 1;
        this.service.postMethod('rewards/common-permit/top-live-performing-offer', {}, 1)
            .subscribe((res) => {
                if (res.status === 1335) {
                    this.topFiveOffer = res.data;
                    this.topFivePerformingOffer.total = res.data.totalSize;
                } else {
                    this.topFiveOffer = [];
                    this.topFivePerformingOffer.total = 0;
                }
            }, (error) => {
                this.topFiveOffer = [];
                this.topFivePerformingOffer.total = 0;
            });
    }

    getMarketingOngoingEvent(page) {
        this.onGoingEventPage.p = page;
        this.onGoingEventPage.page = page - 1;
        this.service.postMethod('event/common-permit/get-ongoing-event-list?page=' + this.onGoingEventPage.page + '&pageSize=5', {}, 1)
            .subscribe((succ) => {
                this.onGoingEvent = succ.data.list;
                this.onGoingEventPage.total = succ.data.size;
            }, (error) => {
                this.onGoingEvent = [];
                this.onGoingEventPage.total = 0;
            });
    }

    getUpcomingEvent(page) {
        this.upcomingEventPage.p = page;
        this.upcomingEventPage.page = page - 1;
        this.service.postMethod('event/common-permit/get-upcoming-event-list?page=' + this.upcomingEventPage.page + '&pageSize=5', {}, 1)
            .subscribe((res) => {
                if (res.status === 1050) {
                    this.upcomingEvent = res.data.list;
                    this.upcomingEventPage.total = res.data.size;
                } else {
                    this.upcomingEvent = [];
                    this.upcomingEventPage.total = 0;
                }
            }, (error) => {
                this.upcomingEvent = [];
                this.upcomingEventPage.total = 0;
            });
    }

    getEventCount() {
        this.service.postMethod('event/common-permit/get-ongoing-event-list-count', {}, 1)
            .subscribe((res) => {
                if (res.status === 1051) {
                    this.eventCount = res.data.ongoingEvent;
                }
            }, (error) => {
            });
    }

    getOfferCount() {
        this.service.getMethod('rewards/common-permit/get-active-offers-count', 1)
            .subscribe((res: any) => {
                if (res.status === 1420) {
                    this.offerCount = res.data[0].activeOffers;
                }
            }, (error) => {
            });
    }

    getTotalOfferCount() {
        this.service.getMethod(`rewards/get-offer-list?languageName=en&page=1&pageSize=5`, 1).subscribe((success: any) => {
            if (success.status === 1367) {
                this.totalOffers = success.data.size;
            }
        }, error => {
        });
    }

    getTicketCount() {
        this.service.postMethod('support/common-permit/get-open-ticket-count', {}, 1)
            .subscribe((res: any) => {
                if (res.status === 1209) {
                    this.ticketCount = res.data;
                }
            }, (error) => {
            });
    }

    ngOnDestroy() {
        this.adminRoleSubscription.unsubscribe();
    }

    changePage(mode, page) {
        if (mode === 'offerExpiring') {
            this.getOffersExpiringNextWeek(page);
        } else if (mode === 'topFiveOffer') {
            this.getTopFivePerformingOffer(page);
        } else if (mode === 'ongoingEvent') {
            this.getMarketingOngoingEvent(page);
        } else if (mode === 'upcomingEvent') {
            this.getUpcomingEvent(page);
        }
    }
}



