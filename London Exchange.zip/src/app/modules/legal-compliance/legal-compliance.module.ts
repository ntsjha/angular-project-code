import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LegalComplianceComponent } from './legal-compliance/legal-compliance.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [LegalComplianceComponent]
})
export class LegalComplianceModule { }
