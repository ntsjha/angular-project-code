import { NgModule } from '@angular/core';
import { StatePipe } from './state/state';

@NgModule({
	declarations: [StatePipe],
	imports: [],
	exports: [StatePipe]
})
export class PipesModule {}
