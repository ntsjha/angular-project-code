import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, App } from 'ionic-angular';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ServiceServicesProvider } from '../../providers/service-services/service-services';
import { WithdrawOptionsPage } from '../withdraw-options/withdraw-options';

@IonicPage()
@Component({
  selector: 'page-withdraw',
  templateUrl: 'withdraw.html',
})
export class WithdrawPage {
  withdrawMoneyForm: FormGroup;

  constructor(public navCtrl: NavController, public navParams: NavParams, public app: App, public service: ServiceServicesProvider) {
    this.withdrawMoneyForm = new FormGroup({
      amount: new FormControl('', [Validators.required, Validators.pattern(/^\d+(\.\d{1,2})?$/)])
    })
  }

  continue() {
    console.log('contine')
    if (navigator.onLine) {
      console.log('inside')
      // if(this.withdrawMoneyForm.value.amount >= 50) {
        let withdrawMoneyProcess = {
          amount: this.withdrawMoneyForm.value.amount
        }
        localStorage.withdrawMoneyProcess = JSON.stringify(withdrawMoneyProcess);
        this.app.getRootNav().setRoot(WithdrawOptionsPage);
      // }
      // else {
      //   this.service.presentToast('The minimum amount that can be added is 50')
      // }
    } else
      this.service.presentToast('Your internet connection seems to be lost')
  }

}
