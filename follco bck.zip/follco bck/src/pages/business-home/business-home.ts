import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController, ToastController, App } from 'ionic-angular';
import { RestProvider } from '../../providers/rest/rest';
import { LoginPage } from '../login/login';
import { EmailCampaingsPage } from '../email-campaings/email-campaings';
import { SmsCampaignPage } from '../sms-campaign/sms-campaign';
import { SettingPage } from '../setting 3/setting';
import { DashboardPage } from '../dashboard/dashboard';
import { TimelinePostPage } from '../timeline-post/timeline-post';
import { ProfileonePage } from '../profileone/profileone';
import { CrmInvoicesPage } from '../crm-invoices/crm-invoices';
import { CrmLeadsPage } from '../crm-leads/crm-leads';
import { CrmProductsPage } from '../crm-products/crm-products';
import { CrmFollowersPage } from '../crm-followers/crm-followers';
import { CrmCutomersPage } from '../crm-cutomers/crm-cutomers';

/**
 * Generated class for the BusinessHomePage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-business-home',
  templateUrl: 'business-home.html',
})
export class BusinessHomePage {

  constructor(public navCtrl: NavController, public app :App,public navParams: NavParams,private service:RestProvider,public lodingController: LoadingController,public toast:ToastController) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad BusinessHomePage');
  }
  leads(){
    this.app.getRootNav().push(CrmLeadsPage);
  }
  emailCamp(){
    this.app.getRootNav().push(EmailCampaingsPage);

    // this.navCtrl.push(EmailCampaingsPage);
  }
  smsCamp(){
    this.app.getRootNav().push(SmsCampaignPage);
    // this.navCtrl.push(SmsCampaignPage);
  }
product(){
  this.app.getRootNav().push(CrmProductsPage);
}
customer(){
  this.app.getRootNav().push(CrmCutomersPage);
}
followers(){
  this.app.getRootNav().push(CrmFollowersPage);
}
  posts(){
    this.app.getRootNav().push(TimelinePostPage);
    // this.navCtrl.push(TimelinePostPage);
  }
  setting(){
    this.app.getRootNav().push(SettingPage);
   // this.service.presentLoadingDefault('Loading...');
    // this.navCtrl.push(SettingPage);
    //this.service.dismissLoading();
  }
  profile(){
    this.app.getRootNav().push(ProfileonePage);
    //this.service.presentLoadingDefault('Loading...');
    // this.navCtrl.push(ProfileonePage);
    //this.service.dismissLoading();
  }

  crmInvoices(){
    this.app.getRootNav().push(CrmInvoicesPage);
  }
  logOut(){
    this.service.presentLoadingDefault('Logout');
    let data = new FormData();
    data.append('device_token','abc123');
    console.log("data===+++>>",data);  
    this.service.post('users/logout?follco_token='+localStorage.getItem('new_token'),data,1).subscribe(res =>{
      if(res.message){      
        console.log("Logout_Succ"+JSON.stringify(res)); 
        this.service.dismissLoading();
        this.service.presentToast(res.message);
        localStorage.removeItem('new_token');
        localStorage.removeItem('modeType');
        localStorage.clear();
        // this.navCtrl.push(LoginPage); 
        this.app.getRootNav().setRoot(LoginPage);

        
  
       
   
      }
      else{
       
         
          this.service.dismissLoading();
          this.service.presentToast(res.error);
    
      
      }
    },err =>{
      console.log(err)
      this.service.presentToast(err)
    })
  
    }
}
