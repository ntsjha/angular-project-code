import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController, ToastController, ToastOptions } from 'ionic-angular';
import { FormGroup, FormControl, Validators, ValidatorFn, AbstractControl } from '@angular/forms';
import { RestProvider } from '../../providers/rest/rest';
import { LoginPage } from '../login/login';
import { CustomerprofilePage } from '../customerprofile/customerprofile';

/**
 * Generated class for the ChangepassPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-changepass',
  templateUrl: 'changepass.html',
})
export class ChangepassPage {
  changePassword : FormGroup;
  errorMessage: string = '';
  toastoptions:ToastOptions;
  // validation_messages = {
  //   'oldPassword': [
  //     { type: 'required', message: 'Password is required.' },
  //   ],
  //   'newpassword': [
  //     { type: 'required', message: 'New Password is required.' },
  //     { type: 'pattern', message: 'require minimum eight characters, at least one uppercase letter, one lowercase letter, one number and one special character' }
  //   ],
  //   'confirmnewpassword':[
  //     { type: 'required', message: 'Confirm Password is required.' },
  //     { type: 'equalTo', message: 'Confirm password is not same.' },
  //   ]
  // };

  constructor(public navCtrl: NavController, public navParams: NavParams,private service:RestProvider,public lodingController: LoadingController,private toast: ToastController) {
    this.changePassword = new FormGroup({
      oldPassword: new FormControl('', Validators.compose([
        Validators.required,
      ])),
      newpassword: new FormControl('', Validators.compose([
        Validators.required,
        Validators.pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/)
      ])),
      confirmnewpassword: new FormControl('', Validators.compose([
        Validators.required
      ])),
    });
  }
  // equalTo(field_name): ValidatorFn {
  //   return (control: AbstractControl): {[key: string]: any} => {
    
  //   let input = control.value;
    
  //   let isValid=control.root.value[field_name]==input
  //   if(!isValid) 
  //   return { 'equalTo': {isValid} }
  //   else 
  //   return null;
  //   };
  //   }
  ionViewDidLoad() {
    console.log('ionViewDidLoad ChangepassPage');
  }
  trychnage(value){
    
    if(this.changePassword.value.newpassword !== this.changePassword.value.confirmnewpassword){
      return
    }
    if(this.changePassword.invalid){
      return;
    }
    this.service.presentLoadingDefault('Changing Password');

    let data = new FormData();
    data.append('current_password',this.changePassword.value.oldPassword);
    data.append('new_password',this.changePassword.value.newpassword);
    data.append('repeat_password',this.changePassword.value.confirmnewpassword);
    console.log("data===+++>>",data);
    this.service.post('users/change_password?follco_token='+localStorage.getItem('new_token'),data,1).subscribe(res =>{
      // let lodingController = this.lodingController.create({
      //   content: 'Changing Password',
      // });
      if(this.changePassword.value.oldPassword !== this.changePassword.value.newpassword){
      console.log("Change_password"+JSON.stringify(res)); 
      
      if(res.message){
        this.service.dismissLoading();
        this.service.presentToast(res.message) ;

        this.navCtrl.push(CustomerprofilePage);

        // this.toastoptions = {
        //   message : res.message,
        //   duration: 2000,
        //   position: 'bottom',
        //   // showCloseButton: true,
        // };
        // var toast =this.toast.create(this.toastoptions);
        // lodingController.present();
        // setTimeout(() => {
        
         
        //   this.navCtrl.push(CustomerprofilePage);
         
         
          
        //   toast.present();
        //  lodingController.dismiss();
        // }, 2000);   
        
      }
      else{
        // this.toastoptions = {
        //   message : res.error,
        //   duration: 3000,
        //   position: 'bottom',
        //   // showCloseButton: true,
        // };
        // var toast =this.toast.create(this.toastoptions);
        // lodingController.present();
        // setTimeout(() => {     
        //  toast.present();
        //  lodingController.dismiss();
        // }, 2000);   
        this.service.presentToast(res.error);
        this.service.dismissLoading();
       
      }}else{
        // this.toastoptions = {
        //   message : 'Enter new password',
        //   duration: 3000,
        //   position: 'bottom',
        //   // showCloseButton: true,
        // };
        // var toast =this.toast.create(this.toastoptions);
        // lodingController.present();
        // setTimeout(() => {     
        //  toast.present();
        //  lodingController.dismiss();
        // }, 2000);   
        this.service.presentToast(res.error);
        this.service.dismissLoading();
       

      }
     
      
     },err =>{
      console.log(err)
      
    })
  }
  back(){
    this.navCtrl.pop();
  
   
  }
}
