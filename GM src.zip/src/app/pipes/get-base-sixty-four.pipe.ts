import { NgxSpinnerService } from 'ngx-spinner';
import { ServiceService } from './../service/service.service';
import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'getBaseSixtyFour'
})
export class GetBaseSixtyFourPipe implements PipeTransform {
  image: any = null;

  constructor(
    private service: ServiceService,
    private spinner: NgxSpinnerService,
  ) {}

  transform(value: any): any {
    if (value) {
        this.service.getMethod('account/convert-image-base64?imageUrl=' + this.service.imageUrl + value, 1).subscribe((res: any) => {
          this.spinner.hide();
          return null;
        }, error => {
          this.spinner.hide();
          if (error.error.text) {
            this.image = 'data:image/jpg;base64,' + error.error.text;
            return this.image;
          } else {
            return null;
          }
        });
    } else {
      return null;
    }
  }

}
