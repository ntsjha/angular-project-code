import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { ServiceService } from './service/service.service';
import { DeviceDetectorService } from 'ngx-device-detector';
import { CookieService } from 'ngx-cookie-service';
import { Subject, Observable } from 'rxjs';
import { TranslateService } from '@ngx-translate/core';
import { NgxSpinnerService } from 'ngx-spinner';

declare var $: any;
@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

    title = 'backendPanel';
    showSidePanel = false;
    url: any = '';
    response: any = {};
    googleVerificationResult: any;
    private subject = new Subject<any>();
    google: any = { one: '', two: '', three: '', four: '', five: '', six: '' };
    user: any;

    constructor(public translate: TranslateService, public router: Router, private service: ServiceService, private deviceService: DeviceDetectorService, private cookie: CookieService, private spinner: NgxSpinnerService) {
        translate.setDefaultLang('en');
        translate.use('en');
        this.service.authVerify.subscribe(val => {
            if (val == 'false') {
                this.response['status'] = 201;
                this.response['message'] = 'Invalid code';
                this.google = { one: '', two: '', three: '', four: '', five: '', six: '' };
            }
        });
    }
    /** Function for call event in child component */
    fireToChild(): Observable<any> {
        return this.subject.asObservable();
    }

    ngOnInit() {
        let sBrowser;
        const sUsrAg = this.deviceService.getDeviceInfo()['userAgent'];
        if (sUsrAg.indexOf('Firefox') > -1) {
            sBrowser = 'Mozilla Firefox';
        } else if (sUsrAg.indexOf('Opera') > -1 || sUsrAg.indexOf('OPR') > -1) {
            sBrowser = 'Opera';
        } else if (sUsrAg.indexOf('Trident') > -1) {
            sBrowser = 'Microsoft Internet Explorer';
        } else if (sUsrAg.indexOf('Edge') > -1) {
            sBrowser = 'Microsoft Edge';
        } else if (sUsrAg.indexOf('Chrome') > -1) {
            sBrowser = 'Google Chrome or Chromium';
        } else if (sUsrAg.indexOf('Safari') > -1) {
            sBrowser = 'Apple Safari';
        } else {
            sBrowser = 'unknown';
        }
        this.service.changeBrowser(sBrowser);
        this.getUserInfo();
        this.getUrl();
        this.userInfoNotFoundInCookie();
    }

    getUserInfo() {
        if (this.cookie.get('userInfo')) {
            this.user = (this.cookie.get('userInfo')) ? JSON.parse(this.cookie.get('userInfo')) : this.service.initialUserInfo;
            if (this.user['country']) {
                this.service.changeUserInfo(JSON.parse(this.cookie.get('userInfo')));
            } else {
                this.userInfoNotFoundInCookie();
            }
        } else {
            this.userInfoNotFoundInCookie();
        }
    }

    userInfoNotFoundInCookie() {
        let userInfo;
        // $.getJSON('http://api.ipapi.com/check?access_key=94e675bdad759a7c1b6a3e73fca3ea01', (data) => {
        $.getJSON('https://ipapi.co/json/', (data) => {
            this.service.changeUserInfo(data);
            this.cookie.set('userInfo', JSON.stringify(data), 0, '/');
            // if (!data.success) {
            //     userInfo = {
            //         ip: 'No IP Found',
            //         city: 'No Location Found',
            //         region: 'National Capital Territory of Delhi',
            //         region_code: 'DL',
            //         country: ' ',
            //         country_name: '',
            //         continent_code: 'AS',
            //         in_eu: false,
            //         postal: '110022',
            //         latitude: 28.6014,
            //         longitude: 77.1989,
            //         timezone: 'Asia/Kolkata',
            //         utc_offset: '+0530',
            //         country_calling_code: '+91',
            //         currency: 'INR',
            //         languages: 'en-IN,hi,bn,te,mr,ta,ur,gu,kn,ml,or,pa,as,bh,sat,ks,ne,sd,kok,doi,mni,sit,sa,fr,lus,inc","asn":"AS38571","org":"Star Broadband Services'
            //     };
            //     this.service.changeUserInfo(userInfo);
            //     this.cookie.set('userInfo', JSON.stringify(userInfo), 0, '/');
            // } else {
            //     this.service.changeUserInfo(data);
            //     this.cookie.set('userInfo', JSON.stringify(data), 0, '/');
            // }
        }, error => {
            userInfo = {
                ip: 'No IP address found',
                city: 'No location found',
                region: 'National Capital Territory of Delhi',
                region_code: 'DL',
                country: '',
                country_name: '',
                continent_code: 'AS',
                in_eu: false,
                postal: '110022',
                latitude: 28.6014,
                longitude: 77.1989,
                timezone: 'Asia/Kolkata',
                utc_offset: '+0530',
                country_calling_code: '+91',
                currency: 'INR',
                languages: 'en-IN,hi,bn,te,mr,ta,ur,gu,kn,ml,or,pa,as,bh,sat,ks,ne,sd,kok,doi,mni,sit,sa,fr,lus,inc","asn":"AS38571","org":"Star Broadband Services'
            };
            this.service.changeUserInfo(userInfo);
            this.cookie.set('userInfo', JSON.stringify(userInfo), 0, '/');
        });
    }

    getUrl() {
        this.router.events.subscribe(e => {
            if (e instanceof NavigationEnd) {
                this.url = e.url.split('/')[1];
            }
            this.subject.next({ text: "urlChange" });
        });
    }

    googleVerification() {
        this.user = (this.cookie.get('userInfo')) ? JSON.parse(this.cookie.get('userInfo')) : this.service.initialUserInfo;
        this.response = { 'message': '' };
        if ((this.google.one === '') || (this.google.two === '') || (this.google.three === '') || (this.google.four === '') || (this.google.five === '') || (this.google.six === '')) {
            return;
        } else {
            this.spinner.show();
            const data = {
                otp: this.service.encrypt(this.google.one + this.google.two + this.google.three + this.google.four + this.google.five + this.google.six),
                previousToken: this.cookie.get('token'),
                ipAddress: this.service.encrypt(this.user.ip),
                location: this.service.encrypt(this.user.city + ',' + this.user.country_name),
            };
            this.service.googleVerificationFunc(data);
        }
    }

    onKey(event, next, previous) {
        if (event.key === 'Backspace') {
            document.getElementById(previous).focus();
        } else {
            if (event.key >= "0" && event.key <= "9") {
                if (event.target.value.trim() !== '') {
                    document.getElementById(next).focus();
                }
            }
        }
    }

    restrictChar(event) {
        if (!(event.key >= "0" && event.key <= "9")) {
            return false;
        }
    }


}
