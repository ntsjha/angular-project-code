import { Component, OnInit } from '@angular/core';
import { ServiceService } from 'src/app/Shared/service.service';
import Swal from 'sweetalert2';
import { Router, ActivatedRoute } from '@angular/router';
import { AngularFirestore } from '@angular/fire/firestore';

import { FormGroup, FormControl, Validators } from '@angular/forms';

declare var $:any;
@Component({
  selector: 'app-view-feed-type',
  templateUrl: './view-feed-type.component.html',
  styleUrls: ['./view-feed-type.component.css']
})
export class ViewFeedTypeComponent implements OnInit {
  contentname: any;
  updateform: FormGroup;
  feedtype: string;
  BreedTypeArr: any;
  
  p: number = 1;
  pageSize = 10;
  total = 0
  FeedTypeArr: any;
  ind: any;
  docname: any;
  deleteindex: any;
  deleteValue: any;
  messagepop: any;
  constructor(public router: Router, private afs: AngularFirestore,private firebaseServ : ServiceService,public route: ActivatedRoute) { }

  ngOnInit() {

    this.route.queryParams.subscribe((res)=>{
      console.log('params--->>> ',res);
      this.contentname = res.type
      this.docname = res.value
    }) 
  
    this.updateform = new FormGroup({
      updateddata: new FormControl('', [Validators.pattern("^[a-zA-Z ]{1,20}$"), Validators.required,Validators.maxLength(50)]),
      
    });
    this.getFeedtypeFunc()
    this.messagepop=this.contentname.toLowerCase()
  }

  
// ***********get  Feedtype data ****************//
getFeedtypeFunc(){
  this.firebaseServ.getFeedFunc(this.docname).then(res => {
    console.log('getFeedChaffFunc'+JSON.stringify(res))
    if(this.contentname=="Feed"){
    this.BreedTypeArr = res.Feed
    }
    else{
      this.BreedTypeArr = res.unit
    }
    this.total = this.BreedTypeArr.length;          
  }).catch(err => {
    console.log(err)
  })
  
}



// *********For Update value************
contributorEdit(data,index){
  console.log('getdata',data,index)
  this.ind =index
  this.updateform.patchValue({
    'updateddata': data,
  })

  $('#update_farms_modal').modal('show');
}
UpdateSubFeeddata(){
  var ind=this.BreedTypeArr.findIndex((x) => x==   this.updateform.value.updateddata);
  
  if(ind == -1) {

  this.BreedTypeArr[this.ind]=this.updateform.value.updateddata
  console.log('getdata==>',this.contentname,this.docname,this.BreedTypeArr)
  this.firebaseServ.addSubFeedType(this.contentname,this.docname,this.BreedTypeArr).then(res => {
  console.log('AddBreed_Succ',res)
  $('#update_farms_modal').modal('hide');
   this.firebaseServ.hideSpinner();
  // this.breed = '';
  this.firebaseServ.showSuccess('Your changes has been updated successfully.')

  // this.getServiceTypeFunc();
}).catch(err => {
  console.log('AddBreed_Err',err)
})
  }
  else{
    this.firebaseServ.toastErr(['This '+this.contentname +' name is already taken'])
  }
  

}


// *********For Delete value************
deleteFuction(data,valuename){
  console.log(data,valuename)
  this.deleteindex=data
  // ********FeedType**************************
  this.deleteValue=valuename
  $('#delet_farms_modal').modal('show');
}

deleteSubFeedFunc(){
  this.BreedTypeArr.splice([this.deleteindex],1);
 console.log('getdata==>',this.BreedTypeArr)
  this.firebaseServ.addSubFeedType(this.contentname,this.docname,this.BreedTypeArr).then(res => {
    console.log('AddBreed_Succ',res)
    $('#delet_farms_modal').modal('hide');
    this.firebaseServ.showSuccess('Your data has been deleted successfully.')

     this.firebaseServ.hideSpinner();
     
    // this.breed = '';
    this.getFeedtypeFunc()
  }).catch(err => {
    console.log('AddBreed_Err',err)
  })
}

addFeedtype(type,data){
  console.log('data',type,data)
    let info=data;
    this.router.navigate(['/setting/add-setting/'+ this.contentname],{
      queryParams:{id:'Feed',section:this.docname}})
      // queryParams:{id:'Feed',section:this.docname}})
  
  }
  gotofeedmenu(){
    this.router.navigate(['/setting/viewsetting/id'],{
      queryParams:{value:'FeedType',section:'Feed'}})
  }
  
}
