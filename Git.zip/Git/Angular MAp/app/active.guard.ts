import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { ServeService } from './serve.service';
@Injectable({
  providedIn: 'root'
})
export class ActiveGuard implements CanActivate {
  constructor(public serve:ServeService,public router:Router) { }

  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
   if(this.serve.rights()) {
     
    return true;
  }
  else
  {
    alert("You Don't Have Permition");
    this.router.navigate(['login']);
}

}
}
