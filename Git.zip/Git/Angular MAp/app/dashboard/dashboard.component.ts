import { Component, OnInit } from '@angular/core';
import { ServeService } from '../serve.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
  providers: [ServeService]
})
export class DashboardComponent implements OnInit {
   teacher:any[];
   empinfo:any [];
  constructor(private serve:ServeService,public router:Router) { }

  ngOnInit() {
    if(!sessionStorage.getItem('userID')){
       this.router.navigate(['/login'])
    }
    else {
      this.router.navigate(['/dashboard']) 
    }
   
   
  }

  logout(){
    sessionStorage.removeItem('userID');
    this.router.navigate(['/login'])
  }
}
