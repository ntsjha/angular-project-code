import { MainServiceService } from './../../main-service.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUpComponent implements OnInit {
  error: any;
  signupForm: any;
  constructor(
    public service: MainServiceService,
    public router: Router,
    private spinnerService: Ng4LoadingSpinnerService
  ) { }

  ngOnInit() {
    this.signForm();
    // this.otpModal();
  }
  // , Validators.pattern(/^[A-Z0-9_-]+([\.][A-Z0-9_]+)*@[A-Z0-9-]+(\.[a-zA-Z]{2,3})+$/i)
  signForm() {
    this.signupForm = new FormGroup({
      email: new FormControl('', [Validators.required]),
      termsAndCondition: new FormControl(false),
      phoneNo: new FormControl('', [Validators.required, Validators.minLength(10), Validators.maxLength(14), Validators.pattern(/^[6-9][0-9]*$/)]),
      password: new FormControl('', [Validators.required, Validators.minLength(8), Validators.maxLength(16)]),
      confirmPassword: new FormControl('', [Validators.required])
    }, passwordMatchValidator);

    function passwordMatchValidator(g: FormGroup) {
      let pass = g.get('password').value;
      let confPass = g.get('confirmPassword').value;
      if (pass !== confPass) {
          g.get('confirmPassword').setErrors({ mismatch: true });
      } else {
        g.get('confirmPassword').setErrors(null);
        return null;
      }
    }
  }

  changeTermsAndConditionsValue() {
    this.signupForm.patchValue({
      termsAndCondition: !this.signupForm.value.termsAndCondition
    });
  }

  register() {
    if (
        this.signupForm.invalid ||
        (this.signupForm.value.password !== this.signupForm.value.confirmPassword) || !(this.signupForm.value.termsAndCondition)
      ) {
      return;
    }
    if (!navigator.onLine) {
      this.service.showWarning('Please check internet conectivity');
      return;
    }
    this.router.navigate(['/buySubscriptionPlan']);
    console.log('form value ===>>>', this.signupForm.value);
    this.spinnerService.show();
    let data = {
      email          :   this.signupForm.value.email,
      phoneNumber    :   '+91' + this.signupForm.value.phoneNo,
      password       :   this.signupForm.value.password
    };
    this.service.post('user/signup', data, 2).subscribe(res => {
    this.spinnerService.hide();
    if (res.responseCode === 200) {
      this.service.showSuccess(res['responseMessage']);
      this.router.navigate(['login']);
      // this.otpModal();
    } else {
      this.service.showWarning(res.responseMessage);
    }
    console.log('res ===>>>', res);
    }, err => {
      this.spinnerService.hide();
      this.service.showError('Something went wrong');
    });
  }

  // otpModal() {
  //   Swal.fire({
  //     title: 'Enter your OTP',
  //     input: 'text',
  //     inputAttributes: {
  //       autocapitalize: 'off'
  //     },
  //     inputValidator: (value) => {
  //       if (!value) {
  //         return 'You need to write something!';
  //       } else {
  //         var numReg = (/^[0-9]*$/);
  //         console.log(numReg.test(value));
  //         if (!numReg.test(value)) {
  //           return 'Only numbers are accepted!';
  //         }
  //       }
  //     },
  //     showCancelButton: true,
  //     confirmButtonText: 'Submit',
  //     showLoaderOnConfirm: true,
  //     preConfirm: (login) => {
  //       return fetch(`//api.github.com/users/${login}`)
  //         .then(response => {
  //           if (!response.ok) {
  //             throw new Error(response.statusText);
  //           }
  //           return response.json();
  //         })
  //         .catch(error => {
  //           Swal.showValidationMessage(
  //             `Request failed: ${error}`
  //           );
  //         });
  //     },
  //     allowOutsideClick: () => !Swal.isLoading()
  //   }).then((result) => {
  //     if (result.value) {
  //       Swal.fire('Success', 'OTP verified successfully', 'success').then(success => {
  //         console.log('success ===>>>', success);
  //         this.router.navigate(['/login']);
  //       });
  //     }
  //   }).catch(error => {
  //     Swal.fire('Oops...', 'Something went wrong!', 'error');
  //   });
  // }
}
