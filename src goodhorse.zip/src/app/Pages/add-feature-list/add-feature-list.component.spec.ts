import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddFeatureListComponent } from './add-feature-list.component';

describe('AddFeatureListComponent', () => {
  let component: AddFeatureListComponent;
  let fixture: ComponentFixture<AddFeatureListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddFeatureListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddFeatureListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
