import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, App, Platform } from 'ionic-angular';
import { ServiceServicesProvider } from "../../providers/service-services/service-services";
import { FaqPage } from "../faq/faq";
import { NotificationsPage } from "../notifications/notifications";
import { SocketProvider } from '../../providers/socket/socket';

@IonicPage()
@Component({
  selector: 'page-home',
  templateUrl: 'home.html',
})
export class HomePage {
  profile: any;
  currency: any;
  notifi: string;
  amout: any;

  constructor(public navCtrl: NavController, public navParams: NavParams, public server: ServiceServicesProvider, private app: App, public platform: Platform, public socketService: SocketProvider) {}

  ionViewWillEnter() {
    this.socketService.getBalance();
    this.notifi = localStorage.getItem('notibadge')
    console.log('notifi=>',this.notifi);
    if (navigator.onLine) {
      let userId = localStorage.getItem('userId');
      this.server.presentLoading();
      this.server.getApi('user/userDetail/' + userId, 1).subscribe((response: any) => {
        this.server.dismissLoading();
        if (response.response_code == 200) {
          this.profile = response.result.userDetails;
          localStorage.countryCode = response.result.userDetails.countryCode;
          this.getCurrency(response.result.userDetails.country);
        } else if (response.response_code == 403 || response.response_code == 409 || response.response_code == 401) {
          this.server.presentToast(response.response_message)
          this.server.logout();
        }
        else {
          this.server.presentToast(response.response_message)
        }
      }, err => {
        this.server.dismissLoading();
        this.server.presentToast('Something went wrong')
      })
    } else
      this.server.presentToast('Your internet connection seems to be lost')




    if (this.platform.is('cordova'))
      this.saveFCMToken();

  }

  seeNotifications() {
    this.app.getRootNav().push(NotificationsPage)
  }

  seeFAQ() {
    this.app.getRootNav().push(FaqPage)
  }

  goto(page) {
    this.navCtrl.parent.select(page);
  }

  //------------------------------------------ SAVE FCM TOKEN API INTEGRATION STARTS ------------------------------------------//
  saveFCMToken() {
    if (navigator.onLine) {
      let detail = {
        "userId": localStorage.getItem('userId'),
        "fcmToken": localStorage.FCM
      }
      this.server.postApi(detail, 'transaction/tokenFcm', 0).subscribe(res => {
      },
      err => {
        // this.server.presentToast('Something went wrong');
      })
    }
    else
      this.server.presentToast('Your internet connection seems to be lost')
  }
  //------------------------------------------ SAVE FCM TOKEN API INTEGRATION ENDS ------------------------------------------//

  getCurrency(country) {
    console.log(country)
      this.server.getCurrencyAndFlag(country, 1).subscribe(res => {
        console.log(res)
        this.currency = res[0].currencies[0].symbol;
        this.amout = (this.socketService.balance)?(this.socketService.balance):(this.profile.balance)
      });
    }
}
