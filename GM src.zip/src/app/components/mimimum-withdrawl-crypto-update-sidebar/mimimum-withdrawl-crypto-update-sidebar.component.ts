import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ServiceService } from 'src/app/service/service.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { AppComponent } from 'src/app/app.component';
import { CookieService } from 'ngx-cookie-service';

declare var $: any;

@Component({
  selector: 'app-mimimum-withdrawl-crypto-update-sidebar',
  templateUrl: './mimimum-withdrawl-crypto-update-sidebar.component.html',
  styleUrls: ['./mimimum-withdrawl-crypto-update-sidebar.component.css']
})
export class MimimumWithdrawlCryptoUpdateSidebarComponent implements OnInit, OnDestroy {
  cryptoFunction: FormGroup;
  currentUser: any;
  coinName: any;
  cryptoFiat: any;
  subscription: any;
  userIp: any;

  constructor(
    private service: ServiceService,
    private spinner: NgxSpinnerService,
    private activatedRoute: ActivatedRoute,
    private route: Router,
    private appC: AppComponent,
    private cookie: CookieService
  ) {
    this.cryptoFunction = new FormGroup({
      fee: new FormControl(null, [Validators.required, Validators.maxLength(8)]),
    });

    this.service.currentUserInfo.subscribe((response) => {
      this.currentUser = response;
    });
    this.subscription = this.service.authVerify.subscribe(val => {
      if (val === 'min-withdrawal') {
        this.withdrawlCrypto();
        this.service.authVerify.next('false');
      }
    });
  }

  ngOnInit() {
    this.activatedRoute.params.subscribe(id => {
      this.coinName = id.id;
    });
    this.minWithdrawlCrypto();
    this.userIp = (this.cookie.get('userInfo')) ? JSON.parse(this.cookie.get('userInfo')) : this.service.initialUserInfo;
    window.scrollTo(0, 0);
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  minWithdrawlCrypto() {
    this.spinner.show();
    this.service.getMethod('wallet/admin/fees/get-fee-details?currencyName=' + this.coinName + '&currencyType=crypto', 1).subscribe((response: any) => {
        this.spinner.hide();
        const res = JSON.parse(this.service.decrypt(response.data));
        if (res.status === 845 || res.status === 842) {
          this.cryptoFiat = res.data;
          this.loadform();
        }
    }, (error) => {
      this.spinner.hide();
    });
    this.spinner.hide();

  }

  loadform() {
    this.cryptoFunction.patchValue({
      fee: this.cryptoFiat.minWithdrawalFee
    });
  }

  /** Function to verify google authentication */
  verifyGoogleAuth() {
    this.appC.google = { one: '', two: '', three: '', four: '', five: '', six: '' };
    this.appC.response = { message: '' };
    this.service.googleAuthCalledFrom = 'min-withdrawal';
    $('#google-auth-modal').modal({ keyboard: false, backdrop: 'static' });

  }

  withdrawlCrypto() {
    this.spinner.show();
    const data = {
      amount: this.cryptoFunction.value.fee,
      coinName: this.coinName,
      ipAddress: this.userIp.ip,
      location: this.userIp.city + ',' + this.userIp.country_name
    };

    this.service.postMethod('wallet/admin/fees/set-min-crypto-withdraw-fee', data, 1).subscribe((response: any) => {
      this.spinner.hide();
      if (response.status === 842) {
        this.route.navigate(['/mimimum-withdrawl-crypto-sidebar']);
      }
    }, (error) => {
      this.spinner.hide();
    });
  }
}
