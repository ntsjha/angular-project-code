import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ServerService } from '../../../service/server.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { AppComponent } from '../../../app.component';
import { HeaderComponent } from '../../header/header/header.component';

@Component({
    selector: 'app-newipdetect',
    templateUrl: './newipdetect.component.html',
    styleUrls: ['./newipdetect.component.css']
})
export class NewipdetectComponent implements OnInit {

    constructor(private router :Router, private server: ServerService, private loader: Ng4LoadingSpinnerService, private appC: AppComponent, public header: HeaderComponent) { }

    ngOnInit() {
        window.scrollTo(0,0);
        this.verifyIPFunc();
    }

    /** Function for verify ip */
    verifyIPFunc(): any {
        let url = window.location.href.split('/');
        let token = url[url.length - 1];
        let data = {
            "eventExternal": {
                "name":"verify_ip",
                "key":"mykey"
            },
            "transferObjectMap": {
                "gatewayrequest": {
                    "token": token
                }
            }      
        }
        this.loader.show();
        this.server.postApi('',data,0).subscribe((succ) => {
            this.loader.hide();
            if (succ.transferObjectMap.statusCode == 200) {
                this.appC.showSuccToast(succ.transferObjectMap.message);
            } else if(succ.transferObjectMap.statusCode == 403) {
                this.appC.showErrToast("Your token has been expired.");
                this.header.tokenExpire();
            } else {
                this.appC.showErrToast(succ.transferObjectMap.message);
            }
        }, (err) => {
            this.loader.hide();
            this.appC.showErrToast("Something went wrong");
        });
    }

}
