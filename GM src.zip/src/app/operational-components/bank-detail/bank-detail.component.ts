import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { IMyDpOptions, IMyDateModel } from 'mydatepicker';
import { ServiceService } from 'src/app/service/service.service';
import { AppComponent } from 'src/app/app.component';
import { CookieService } from 'ngx-cookie-service';
import { NgxSpinnerService } from 'ngx-spinner';

declare var $: any;
@Component({
  selector: 'app-bank-detail',
  templateUrl: './bank-detail.component.html',
  styleUrls: ['./bank-detail.component.css']
})
export class BankDetailComponent implements OnInit, OnDestroy {

  userId: any;
  bankDetail: any = {};
  openHistoryData: any;
  status: any;
  reasonbox: any;
  total: any = 0;
  tab1: boolean = false; tab2: boolean = false; tab3: boolean = false; tab4: boolean = false;
  tab5: boolean = false; tab6: boolean = false; tab7: boolean = false; tab8: boolean = false; tab9: boolean = false;
  filterFunction: FormGroup;
  toDateInTimestamp: any = 0;
  fromDateInTimestamp: any = 0;
  page: any = 0;
  p: any;
  coinList = [];
  referralCode: any;
  selectedCoin1: any = 'BTC';
  side = ['BUY', 'SELL']
  baseCoin = [{ coin: "BTC", coinID: "", coinType: "" },
  { coin: "THB", coinID: "", coinType: "" }];
  exeCoin = [];
  selectedExeCoin: any = 'ETH';
  selectedTab: any;
  tabArr: any[];
  totalItems: number;
  obj: any = {};
  selectedCoin: any = 'BTC';
  internalTab: any;
  pageSize = 10;

  public fromPickerOptions: IMyDpOptions = {
    disableSince: { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() },
    dateFormat: 'dd/mm/yyyy',
  };

  public toPickerOptions: IMyDpOptions = {
    disableSince: { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() },
    dateFormat: 'dd/mm/yyyy',
  };
  rejectionModalForm: FormGroup;
  userBankDetailId: any;
  subscription: any;
  userIp: any;
  sideBuy: any;
  getCoinList: any = [];


  constructor(private service: ServiceService, private activateRoute: ActivatedRoute, private appC: AppComponent, private cookie: CookieService, private spinner: NgxSpinnerService) {
    this.activateRoute.params.subscribe((params) => {
      this.userId = params.id;
      this.userBankDetailId = params.userBankDetailId;
      this.userIp = (this.cookie.get('userInfo')) ? JSON.parse(this.cookie.get('userInfo')) : this.service.initialUserInfo;
    });

    this.subscription = this.service.authVerify.subscribe((res) => {
      if (res == 'add-bank') {
        $('#google-auth-modal').modal('hide');
        this.actionOnWithdrawal();
      }
    });

    this.rejectionModalForm = new FormGroup({
      remark: new FormControl(''),
    });
  }


  get remark(): any {
    return this.rejectionModalForm.get('remark');
  }


  ngOnInit() {
    this.getBankDetail();
    this.selectTab('wallet');
    window.scrollTo(0,0);
    this.getCoin();
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  cancelSession(index, id) {
    this.service.postMethod('account/operation/remove-customer-login-session?loginId=' + encodeURIComponent(this.service.encrypt(id)), {}, 1).subscribe((res) => {
      if (res.status === 361) {
        this.tabArr.splice(index, 1);
      }
    });
  }

  /** get bank detail */
  getBankDetail() {
    let data = {};
    this.service.postMethod('account/operation/customer-bank-details?customerUserId=' + encodeURIComponent(this.service.encrypt(this.userId)) + '&userBankDetailId=' + encodeURIComponent(this.service.encrypt(this.userBankDetailId)), data, 1).subscribe((response: any) => {
      let responseData = this.service.decrypt(response.data);
      responseData = JSON.parse(responseData);
      if (responseData.status == 567) {
        this.bankDetail = responseData.data;
        // this.userBankDetailId = this.bankDetail.bankId;
        if (this.bankDetail.passbookImageUrl) {
          this.getBase64Func(this.bankDetail.passbookImageUrl);
        }
      }
    },
      (err) => {
      });
  }

  getBase64Func(img) {
    if (img) {
      this.service.getMethod('account/convert-image-base64?imageUrl=' + this.service.imageUrl + img, 1).subscribe((res: any) => {
        this.spinner.hide();
      }, error => {
        if (error && error.error.text) {
          this.spinner.hide();
          this.bankDetail.passbookImageUrl = 'data:image/jpg;base64,' + error.error.text;
        }

      });
    }
  }
  approvedRejectModal(status) {
    this.status = status;
    $('#reasonModal').modal('show');
  }
  /** Approve /\/ reject  */
  approveReject() {
    let data = {
      bankStatus: this.status,
      languageCode: this.service.encrypt(this.service.currLang),
      ipAddress: this.userIp.ip,
      location: this.userIp.city + ',' + this.userIp.country_name,
      reason: this.reasonbox,
      userBankDetailId: this.userBankDetailId,
      userId: this.userId
    };
    this.service.postMethod('account/admin/customer-approve-or-reject-bank-request', data, 1).subscribe((response: any) => {
      this.getBankDetail();
      $('#reasonModal').modal('hide');
    },
      (err) => {
      });
  }

  selectTab(tab) {
    this.selectedTab = tab;
    this.page = 1;
    this.totalItems = 0;
    this.obj.fromDate = '';
    this.obj.toDate = '';
    this.getTabDetails();
  }

  getTabDetails() {
    this.tabArr = [];
    this.totalItems = 0;
    let url = {};
    const data: any = {};
    if (this.selectedTab === 'wallet') {
      data.userId = this.userId;
      url = 'wallet/common-permit/customer/get-customer-wallets?userId=' + this.userId;
    } else if (this.selectedTab === 'tradeHistory') {
      data.baseCoin = this.selectedCoin
      data.exeCoin = this.selectedExeCoin
      data.side = this.sideBuy
      data.fromDate = this.obj.fromDate.epoc * 1000;
      data.toDate = this.obj.toDate.epoc * 1000 + (86400000 - 1);
      url = 'order-service/common-permit/get-trade-history?userData=' + this.userId;
    } else if (this.selectedTab === 'openOrders') {
      data.baseCoin = this.selectedCoin
      data.exeCoin = this.selectedExeCoin
      data.side = this.sideBuy
      data.fromDate = this.obj.fromDate.epoc * 1000;
      data.toDate = this.obj.toDate.epoc * 1000 + (86400000 - 1);
      url = 'order-service/common-permit/get-Open-order-history?userData=' + this.userId;
    } else if (this.selectedTab === 'withdrawHistory') {
      data.txnType = 'WITHDRAW';
      if (this.obj.fromDate && this.obj.toDate) {
        data.fromDate = this.obj.fromDate.epoc * 1000;
        data.toDate = this.obj.toDate.epoc * 1000 + (86400000 - 1);
      } else {
        data.fromDate = null;
        data.toDate = null;
      }
      data.page = this.page - 1;
      data.pageSize = this.pageSize;
      if (this.selectedCoin) {
        data.coinName = this.selectedCoin;
      } else {
        data.coinName = null;
      }

      if (this.internalTab) {
        data.status = this.internalTab;
        data.page = this.page - 1;
      }
      url = `wallet/common-permit/history/get-transfer-history-per-user?userId=${this.userId}`;
    } else if (this.selectedTab === 'depositHistory') {
      this.page = 1;
      this.p = 1;
      url = `wallet/common-permit/history/get-transfer-history-per-user?userId=${this.userId}`;
      data.txnType = 'USER_DEPOSIT';
      if (this.obj.fromDate && this.obj.toDate) {
        data.fromDate = this.obj.fromDate.epoc * 1000;
        data.toDate = (this.obj.toDate.epoc * 1000 + (86400000 - 1));
      } else {
        data.fromDate = null;
        data.toDate = null;
      }
      data.page = this.page - 1;
      data.pageSize = this.pageSize;
      if (this.selectedCoin) {
        data.coinName = this.selectedCoin;
      } else {
        data.coinName = null;
      }
      if (this.internalTab) {
        data.status = this.internalTab;
        data.page = this.page - 1;
      }
    } else if (this.selectedTab === 'rewardHistory') {
      data.page = this.page - 1;
      data.pageSize = this.pageSize;
      data.userId = this.userId;
      if (this.obj.fromDate && this.obj.toDate) {
        data.fromDate = (this.obj.fromDate.epoc) * 1000;
        data.toDate = ((this.obj.toDate.epoc) * 1000 + (86400000 - 1));
      }
      url = 'rewards/common-permit/search-and-filter-reward-transaction-history';
    } else if (this.selectedTab === 'activity') {
      if (this.obj.fromDate && this.obj.toDate) {
        url = 'account/common-permit/customer-activity-logs?customerUserId=' + (this.userId) + '&fromDate=' + (this.obj.fromDate.epoc * 1000) + '&toDate=' + ((this.obj.toDate.epoc * 1000) + (86400000 - 1)) + '&page=' + (this.page - 1) + '&pageSize=10';
      } else {
        url = 'account/common-permit/customer-activity-logs?customerUserId=' + (this.userId) + '&page=' + (this.page - 1) + '&pageSize=10';
      }
    } else if (this.selectedTab === 'sessionManagement') {
      url = `account/common-permit/customer-current-login-detail?customerUserId=${this.userId}`;
    }
    if (this.selectedTab !== 'wallet') {
      this.service.postMethod(url, data, 1).subscribe((res) => {
        if (this.selectedTab === 'wallet') {
          const arr = res.data;
          this.tabArr = res.data;
          this.totalItems = this.tabArr.length;
          arr.forEach(element => {
            element.showFullAddress = false;
          });
        } else if (this.selectedTab === 'openOrders') {
          const arr = res.data;
          arr.forEach(element => {
            let historyArr = [];
            historyArr = [...element.history];
            historyArr.forEach(obj => {
              this.tabArr.push(obj);
            });

          });
          this.totalItems = this.tabArr.length;
        } else if (this.selectedTab === 'tradeHistory') {
          const arr = res.data;
          arr.forEach(element => {
            this.tabArr.push(element.orderHistory);
          });
          this.totalItems = this.tabArr.length;
        } else if (this.selectedTab === 'withdrawHistory' || this.selectedTab === 'depositHistory') {
          this.tabArr = res.data.resultlist;
          this.totalItems = res.data.totalCount;
        } else if (this.selectedTab === 'sessionManagement') {
          const response = JSON.parse(this.service.decrypt(res.data));
          this.tabArr = response.data;
          if (response.status === 364) {
            this.tabArr = [];
          }
          this.totalItems = response.data ? response.data.length : 0;
        } else if (this.selectedTab === 'rewardHistory') {
          this.tabArr = res.data.list;
          this.totalItems = res.data.size;
        } else if (this.selectedTab === 'activity') {
          const response = JSON.parse(this.service.decrypt(res.data));
          this.tabArr = response.data.list;
          this.totalItems = response.data.size;
        }
      });
    } else {
      this.service.getMethod(url, 1).subscribe((res: any) => {
        this.tabArr = res.data;
      });
    }

  }

  exportData() {

  }


  /** get date */
  fromDateChanged(event: IMyDateModel) {
    this.fromDateInTimestamp = event.epoc;
    if (event.epoc === 0) {
      const date = new Date();
      this.filterFunction.patchValue({
        fromDate: {
          date: {
            year: date.getFullYear(),
            month: date.getMonth() + 1,
            day: date.getDate()
          }
        }
      });
      this.toPickerOptions = {
        disableUntil: event.date
      };
    } else {
      this.filterFunction.patchValue({
        fromDate: event.date
      });
      this.toPickerOptions = {
        disableUntil: event.date
      };
    }
  }

  toDateChanged(event: IMyDateModel) {
    this.toDateInTimestamp = event.epoc;
    if (event.epoc === 0) {
      const date = new Date();
      this.filterFunction.patchValue({
        toDate: {
          date: {
            year: date.getFullYear(),
            month: date.getMonth() + 1,
            day: date.getDate()
          }
        }
      });
      this.fromPickerOptions = {
        disableSince: {
          year: date.getFullYear(),
          month: date.getMonth() + 1,
          day: date.getDate()
        }
      };
    } else {
      this.filterFunction.patchValue({
        toDate: event.date
      });
      this.fromPickerOptions = {
        disableSince: event.date
      };
    }
  }

  basicDetail() {
  }

  changePage(page) {
    this.p = page;
    this.page = page - 1;
    this.getTabDetails();
  }

  openHistory() {
    let data = {
      baseCoin: null,
      exeCoin: null,
      fromDate: null,
      side: null,
      toDate: null
    };
    this.service.postMethod('order-service-eth_btc/admin/get-order-history-by-using-filter?userData=' + this.userId, data, 1).subscribe((response: any) => {
      this.openHistoryData = response.data;
    });
  }

  open2FA(status) {
    this.status = status;
    this.appC.google = { one: '', two: '', three: '', four: '', five: '', six: '' };
    this.appC.response = { message: '' };
    this.service.googleAuthCalledFrom = 'add-bank';
    $('#google-auth-modal').modal({ backdrop: 'static', keyboard: false });
  }

  actionOnWithdrawal() {
    let data = {
      bankStatus: this.service.encrypt(this.status),
      userId: this.service.encrypt(this.userId),
      userBankDetailId: this.service.encrypt(this.userBankDetailId),
      languageCode: this.service.encrypt(this.service.currLang),
      ipAddress: this.userIp.ip,
      location: this.userIp.city + ',' + this.userIp.country_name,
    };
    if (this.status == 'REJECTED' && this.rejectionModalForm.value.remark) {
      data['reason'] = this.service.encrypt(this.rejectionModalForm.value.remark);
    }

    this.service.postMethod('account/operation/customer-approve-or-reject-bank-request', data, 1).subscribe((res) => {
      $('#myticket1').modal('hide');
      this.spinner.hide();
      if (res.data) {
        let response = JSON.parse(this.service.decrypt(res.data));
        this.bankDetail.bankStatus = this.status;
      }
    }, err => {
      this.spinner.hide();
    });

  }

  openModal() {
    $('#myticket1').modal({ backdrop: 'static', keyboard: false });
  }

  onToDateChanged(event: IMyDateModel) {
    const copy1 = this.getCopyOfOptions2();
    copy1.disableSince = event.date;
    this.fromPickerOptions = copy1;
  }

  onFromDateChanged(event: IMyDateModel) {
    const copy1 = this.getCopyOfOptions1();
    copy1.disableUntil = event.date;
    this.toPickerOptions = copy1;
  }

  // Returns copy of myDatePickerOptions
  getCopyOfOptions1(): IMyDpOptions {
    return JSON.parse(JSON.stringify(this.toPickerOptions));
  }

  getCopyOfOptions2(): IMyDpOptions {
    return JSON.parse(JSON.stringify(this.fromPickerOptions));
  }

  closeModal() {
    this.rejectionModalForm.reset();
  }

  resetData() {
    this.tabArr = [];
    this.page = 1;
    this.obj.fromDate = '';
    this.obj.toDate = '';
    this.totalItems = 0;
    this.fromPickerOptions = {
      disableSince: { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() + 1 },
      disableUntil: { year: 0, month: 0, day: 0 }
    };
    this.toPickerOptions = {
      disableSince: { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() + 1 },
      disableUntil: { year: 0, month: 0, day: 0 }
    };
    this.getTabDetails();
  }

  getCoin() {
    this.spinner.show();
    this.service.getMethod('wallet/currency/get-all-currency-list', 1)
      .subscribe((response: any) => {
        this.spinner.hide();
        let responseData = this.service.decrypt(response.data);
        responseData = JSON.parse(responseData);
        if (responseData.status === 830) {
          this.getCoinList = responseData.data;
        }
      }, (error) => {
        this.spinner.hide();
      });
  }


}
