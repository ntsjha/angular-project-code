import { Component, OnInit } from '@angular/core';
import { ServiceService } from 'src/app/service/service.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { Router } from '@angular/router';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-otc-setting',
  templateUrl: './otc-setting.component.html',
  styleUrls: ['./otc-setting.component.css']
})
export class OTCSettingComponent implements OnInit {
  getRewardsDefault: any;
  selectedId: any;
  getRewardsettingDefault: any = [];

  constructor(
    private service: ServiceService,
    public datepipe: DatePipe,
    private spinner: NgxSpinnerService,
    private route: Router
  ) { }

  ngOnInit() {
    this.getRewardDefault();
    window.scrollTo(0, 0);
  }

  goToUpdate() {
    if (this.service.sideMenuArr.includes('updateDefaultRewardPoints')) {
      this.route.navigate(['/update-otc-setting']);
    }
  }



  getRewardDefault() {
    this.spinner.show();
    this.service.getMethod('rewards/common-permit/get-default-reward-setting', 1).subscribe((response: any) => {
      this.spinner.hide();
      if (response.status === 1328) {
        // this.getRewardsDefault = response.data.promotionData;
        this.getRewardsDefault=[{name:'asdasd'},{name:'asdas'}]
        this.getRewardsettingDefault = response.data.defaultRewardData;
      }
    }, (error) => {
      this.spinner.hide();
    });
    this.spinner.hide();
  }
}



