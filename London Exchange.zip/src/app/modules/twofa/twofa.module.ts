import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TwofaComponent } from './twofa/twofa.component';
import { FormsModule } from '@angular/forms';
import { QRCodeModule } from '../../../../node_modules/angularx-qrcode';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    QRCodeModule
   
  ],
  declarations: [TwofaComponent]
})
export class TwofaModule { }
