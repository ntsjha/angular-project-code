import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DepositReqDetailComponent } from './deposit-req-detail.component';

describe('DepositReqDetailComponent', () => {
  let component: DepositReqDetailComponent;
  let fixture: ComponentFixture<DepositReqDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DepositReqDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DepositReqDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
