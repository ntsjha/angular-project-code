import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppComponent } from '../../../app.component';
import { ServerService } from '../../../service/server.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { HeaderComponent } from '../../header/header/header.component';

@Component({
    selector: 'app-tradelist',
    templateUrl: './tradelist.component.html',
    styleUrls: ['./tradelist.component.css']
})
export class TradelistComponent implements OnInit {
    loginStatus = false;
    currTab = "BUY";
    searchObj = {coin:"", payment_method:"", fiat:""};
    paymentArr = [{name:"Cash",value:"cash"},{name:"Bank",value:"bank"},{name:"PayPal",value:"paypal"}];
    coinListArr = [];
    fiatCurrencyArr = [];
    currCoinName = "";
    buyOrderArr = [];
    sellOrderArr = [];

    constructor(private router: Router, private appC: AppComponent, private server: ServerService, private loader: Ng4LoadingSpinnerService, public header: HeaderComponent) { }

    ngOnInit() {
        localStorage.getItem("token") ? this.loginStatus = true : this.loginStatus = false;
        this.searchObj.payment_method = this.paymentArr[0].value;
        window.scrollTo(0,0);
        this.getCoinList();
    }

    /** Function to navigate page */
    goToPage(type) {
        switch(type) {
            case 1:
                this.router.navigateByUrl("header/postTrade");
                break;
            case 2:
                this.router.navigateByUrl("header/tradeAction");
                break;
        } 
    }

    /** Function for get all coins and fiat from api */
    getCoinList() {
        let data = {
            "eventExternal": {
                "name":"request_get_coin_list",
                "key":"mykey"
            },
            "transferObjectMap": {
                
            }
        }
        this.loader.show();
        this.server.postApi("",data,0).subscribe((succ) => {
            this.loader.hide();
            if(succ.transferObjectMap.statusCode == 200) {
                let data = succ.transferObjectMap.coinList;
                this.coinListArr = data.filter((x) => x.coinType=="crypto");
                this.fiatCurrencyArr = data.filter((x) => x.coinType=="fiat");
                if(this.coinListArr.length) {
                    this.searchObj.coin = this.coinListArr[0].coinId;
                }
                if(this.fiatCurrencyArr.length) {
                    this.searchObj.fiat = this.fiatCurrencyArr[0].coinId;
                }
                this.searchData("BUY");
            } else {
            }
        }, (err) => {
            this.loader.hide();
        });
    }

    /** Function for tab click */
    tabClick(tab) {
        this.currTab = tab;
        this.searchData(tab);
    }

    /** Function for search data */
    searchData(type) {
        let data = {
            "eventExternal": {
                "name": "request_get_otc_orders",
                "key": "mykey"
            },
            "transferObjectMap": {
                "orderType": "",
                "baseCurrency": this.searchObj.coin,
                "executableCurrency" : this.searchObj.fiat,
                "paymentMethod": this.searchObj.payment_method,
            }
        }
        type == "BUY" ? data.transferObjectMap.orderType = "SELL" : data.transferObjectMap.orderType = "BUY";
        /*this.loader.show();
        this.server.postApi("",data).subscribe((succ) => {
            this.loader.hide();
            if(succ.transferObjectMap.statusCode == 200) {
                if(type == "BUY") {
                    this.buyOrderArr = succ.transferObjectMap.orderList;
                } else {
                    this.sellOrderArr = succ.transferObjectMap.orderList;
                }
            } else {
                this.appC.showErrToast(succ.transferObjectMap.message);
            }
        }, (err) => {
            this.loader.hide();
        });*/
    }
}
