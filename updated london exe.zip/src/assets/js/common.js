function headerbg() {
    var scroll = $(window).scrollTop();
    if (scroll >= 50) {
        $("header").addClass("header-bg");
    } else {
        $("header").removeClass("header-bg");
    }
}

$(window).scroll(function() {
    headerbg();
});


// $("#menuShow").on('click', function(e) {
//     $('#menubox').toggleClass('menu-slide');
// });
// $("#menuClose").on('click', function(e) {
//     $('#menubox').toggleClass('menu-slide');
// });


$(window).resize(function() {
    if ($(window).width() <= 1024) {
        $(".top-dropdown .dropdown-toggle").removeAttr("data-toggle");
    } else {
        $(".top-dropdown .dropdown-toggle").attr("data-toggle", "dropdown");
    }
});

if ($(window).width() <= 1024) {
    $(".top-dropdown .dropdown-toggle").removeAttr("data-toggle");
} else {
    $(".top-dropdown .dropdown-toggle").attr("data-toggle", "dropdown");
}

$("#showUser").on('click', function(e) {
    $('.chat-user-box').toggle();
    $(this).children('i.fas').toggleClass('fa-users fa-times')
});

$("#showSearch").on('click', function(e) {
    $('.header-search').toggle();
});

$(".security-input").keyup(function() {
    console.log(this.value.length);
    if (this.value.length == this.maxLength) {
        $(this).next('.security-input').focus();
    } else {
        $(this).prev('.security-input').focus();
    }
});

$(document).ready(function() {

    $('[data-toggle="tooltip"]').tooltip();
});






/* =====Increase Descrese========== */
$(".inc-btn").click(function() {
    var get_val = parseInt($(this).parent().prev("input.form-control").val());
    get_val = get_val + 1;
    $(this).parent().prev("input.form-control").val(get_val)
});

$(".dec-btn").click(function() {
    var dec_val = parseInt($(this).parent().next("input.form-control").val());
    if (dec_val <= 0) {
        return false;
    } else {
        dec_val = dec_val - 1;
        $(this).parent().next("input.form-control").val(dec_val)
    }
});
/* =====Increase Descrese End========== */


$(document).ready(function() {




    /* =========Marqee Animate======== */
    $('.marquee').marquee({
        //speed in milliseconds of the marquee
        duration: 15000,
        //gap in pixels between the tickers
        gap: 50,
        //time in milliseconds before the marquee will start animating
        delayBeforeStart: 0,
        //'left' or 'right'
        direction: 'left',
        //true or false - should the marquee be duplicated to show an effect of continues flow
        duplicated: true
    });

    /* Toggle Header User info Drop Down */
    $(document).on("click", ".user_top_box ", function() {
        $(".user_top_box .dropdown-menu").toggleClass("show");
    });

    $(document).click(function(e) {
        if (!$(e.target).is(".head-drop-down, .head-drop-down *, .user_top_box, .user_top_box *")) {
            $(".user_top_box .dropdown-menu").removeClass('show');
        }
    });

    /* Toggle Header User info Drop Down */
    $(document).on("click", ".menu-wallet a", function() {
        $(".wallet-drop-down.dropdown-menu").toggleClass("show");
    });

    $(document).click(function(e) {
        if (!$(e.target).is(".wallet-drop-down, .wallet-drop-down *, .menu-wallet, .menu-wallet *")) {
            $(".menu-wallet .dropdown-menu").removeClass('show');
        }
    });

    /* ============Nice Scroll============= */
    /*var nice = $("html").niceScroll();
    $(".scroll-section, .sidebar").niceScroll({
        cursorborder: "",
        cursorcolor: "#f1592a",
        boxzoom: false

    });
    $("#div-to-scroll").scroll(function(){
        $("#div-to-scroll").getNiceScroll().resize();
    });*/
});


$(document).ready(function() {

    // $(".menu-wallet").click(function() {
    //     $(".wallet-drop-down").toggleClass("show-wallet");
    // });

});