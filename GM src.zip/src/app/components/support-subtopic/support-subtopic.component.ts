import { Component, OnInit } from '@angular/core';
import { ServiceService } from 'src/app/service/service.service';
import { ActivatedRoute, Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
declare var $: any;
@Component({
  selector: 'app-support-subtopic',
  templateUrl: './support-subtopic.component.html',
  styleUrls: ['./support-subtopic.component.css']
})
export class SupportSubtopicComponent implements OnInit {
  modeOfAction: any;
  currentTopicId: any;
  selectedLanguage: string;
  translate: boolean;
  topicArr: any;
  selectedTopic: any;
  modalType: string;
  currentUser: any;
  p: any = 0;
  total:any = 10;

  constructor(private service: ServiceService, private activatedRoutes: ActivatedRoute, private router: Router, private spinner: NgxSpinnerService) { }

  ngOnInit() {
    window.scrollTo(0, 0);
    this.activatedRoutes.params.subscribe((data) => {
      this.currentTopicId = data.id;
    });
    this.service.currentUserInfo.subscribe((response) => {
      this.currentUser = response;
    });
    this.getSubtopicList();
  }

  getSubtopicList() {
    this.spinner.show();
    this.service.postMethod('support/admin/get-support-sub-topic-list?topicId=' + encodeURIComponent(this.service.encrypt(this.currentTopicId)), {}, 1)
      .subscribe((data: any) => {
        this.spinner.hide();
        this.topicArr = data.data;
        this.topicArr.forEach(element => {
          if(element.updatedBy == null) {
            element.updatedAt = null;
          }
        });
      }, (error) => {
        this.spinner.hide();
      });
  }

  addNewTopic() {
    this.router.navigate(['add-edit-support-subtopic/Add/en/' + this.currentTopicId]);
  }

  editTopic(id) {
    this.router.navigate(['add-edit-support-subtopic/Edit/en/' + id]);
  }

  openTranslate(id) {
    this.router.navigate(['manage-subtopic/' + id]);
  }

  openModal(whichModal, id) {
    this.selectedTopic = id;
    if (whichModal === 'delete') {
      this.modalType = 'delete';
    } else {
      const arr = this.topicArr.findIndex(x => x.subTopicId === id);
      if (this.topicArr[arr].status) {
        this.modalType = 'unpublish';
      } else {
        this.modalType = 'publish';
      }
    }
    $('#unPublishdeleteModal').modal({ backdrop: 'static', keyboard: false });
  }

  changeStatus() {
    this.spinner.show();
    const encID = {
      ipAddress: this.service.encrypt(this.currentUser.ip),
      location: this.service.encrypt(this.currentUser.city + ', ' + this.currentUser.country_name),
      topicId: this.service.encrypt(this.selectedTopic),
    };
    this.service.postMethod('support/admin/publish-unpublish-support-sub-topic', encID, 1)
      .subscribe((response) => {
        this.spinner.hide();
        this.getSubtopicList();
        $('#unPublishdeleteModal').modal('hide');
      }, (error) => {
        this.spinner.hide();
        $('#unPublishdeleteModal').modal('hide');
        this.getSubtopicList();
      });
  }

  delete() {
    this.spinner.show();
    const encID = {
      ipAddress: this.service.encrypt(this.currentUser.ip),
      location: this.service.encrypt(this.currentUser.city + ', ' + this.currentUser.country_name),
      topicId: this.service.encrypt(this.selectedTopic),
    };
    this.service.postMethod('support/admin/delete-support-sub-topic', encID, 1)
      .subscribe((response) => {
        this.spinner.hide();
        $('#unPublishdeleteModal').modal('hide');
        this.getSubtopicList();
      }, (error) => {
        this.spinner.hide();
        $('#unPublishdeleteModal').modal('hide');
        this.getSubtopicList();
      });
  }
}
