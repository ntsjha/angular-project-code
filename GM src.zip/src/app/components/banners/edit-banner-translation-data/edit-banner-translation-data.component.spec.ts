import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditBannerTranslationDataComponent } from './edit-banner-translation-data.component';

describe('EditBannerTranslationDataComponent', () => {
  let component: EditBannerTranslationDataComponent;
  let fixture: ComponentFixture<EditBannerTranslationDataComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditBannerTranslationDataComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditBannerTranslationDataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
