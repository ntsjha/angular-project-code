import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { HeaderComponent } from '../../header/header/header.component';
import { ServerService } from '../../../service/server.service';
import { AppComponent } from '../../../app.component';

declare var $: any;
declare const TradingView: any;
declare const Datafeeds: any;
declare var particlesJS: any;

@Component({
    selector: 'app-home',
    templateUrl: './home.component.html',
    styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
    loginStatus: any;
    quickTab = "";
    baseFiatID = "";
    liveCoinObj = {btcPrice:"", ethPrice:"", ltcPrice:"", xrpPrice:"", neoPrice:"", xlmPrice:"", lcxPrice:"", dashPrice:"", bchPrice:"", usdtPrice:"", xvgPrice:""};
    currType = 1;
    baseFiatCurrency = "USD";
    coinListArr = [
        {
            fullName: "LCX",
            shortName: "LCX",
            // img: "assets/images/lcx_token.png",
            img: "assets/img/home/lcx.png",
            currPrice:""
        },{
            fullName: "BITCOIN",
            shortName: "BTC",
            img: "assets/images/bit-icon-img.png",
            currPrice:""
        },{
            fullName: "ETHEREUM",
            shortName: "ETH",
            img: "assets/images/ether-icon-img.png",
            currPrice:""
        },{
            fullName: "LITECOIN",
            shortName: "LTC",
            img: "assets/images/lite-icon-img.png",
            currPrice:""
        },{
            fullName: "RIPPLE",
            shortName: "XRP",
            img: "assets/images/ripple-icon-img.png",
            currPrice:""
        },{
            fullName: "DASH",
            shortName: "DASH",
            img: "assets/images/images.jpeg",
            currPrice:""
        },{
            fullName: "NEO",
            shortName: "NEO",
            img: "assets/images/neo-icon-img.png",
            currPrice:""
        },{
            fullName: "BCH",
            shortName: "BCH",
            img: "assets/images/bitcoin-cash.png",
            currPrice:""
        },{
            fullName: "XLM",
            shortName: "XLM",
            img: "assets/images/xlm-icon-img.png",
            currPrice:""
        },{
            fullName: "USDT",
            shortName: "USDT",
            img: "assets/images/USDT.png",
            currPrice:""
        },{
            fullName: "XVG",
            shortName: "XVG",
            img: "assets/images/xvg.svg",
            currPrice:""
        }
    ];
    animateObj = {happy_traders: 0, community:0, txn_processed:0, stored_value: 0}; // 246, 156, 2.4, 99
    h_t_id: any;
    com_id: any;
    txn_p_id: any;
    c_s_id: any;

    constructor(private router:Router, public header: HeaderComponent, public myService: ServerService, private loader: Ng4LoadingSpinnerService, private server: ServerService, private appC: AppComponent) { 
        this.header.fireToChild().subscribe(message => {
            this.quickTab = message.text;
            if(this.quickTab== "logout")
            this.check();
        });
    }


    ngOnInit() {
        this.header.getprofile();
        window.scrollTo(0,0);
        this.check();
        this.currType = 1;
        this.showTradingChart("BTC", "ETH");
        this.loadParticleContent();
        $('.coinScrollList').slick({
            dots: true,
            infinite: false,
            speed: 300,
            slidesToShow: 6,
            slidesToScroll: 1,
            responsive: [{
                    breakpoint: 991,
                    settings: {
                        slidesToShow: 4,
                        slidesToScroll: 1,
                        infinite: true,
                        dots: true
                    }
                },
                {
                    breakpoint: 600,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 2
                    }
                },
                {
                    breakpoint: 480,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 1
                    }
                }
                // You can unslick at a given breakpoint now by adding:
                // settings: "unslick"
                // instead of a settings object
            ]
        });
        //call function on ngonInit
        this.getCoinList();
        this.getPriceFromCMC();
        this.setTradersValue();
        this.setCommunityValue();
        this.setTxnProcessedValue();
        this.setStoredValue();
    }

    ngOnDestroy() {
        clearTimeout(this.h_t_id);
        clearTimeout(this.com_id);
        clearTimeout(this.txn_p_id);
        clearTimeout(this.c_s_id);
    }

    /** Function to load particle file */
    loadParticleContent() {
        particlesJS('particles-js', {
            "particles": {
                "number": {
                    "value": 80,
                    "density": {
                        "enable": true,
                        "value_area": 800
                    }
                },
                "color": {
                    "value": "#efefef"
                },
                "shape": {
                    "type": "circle",
                    "stroke": {
                        "width": 0,
                        "color": "#efefef"
                    },
                    "polygon": {
                        "nb_sides": 5
                    },
                    "image": {
                        "src": "img/github.svg",
                        "width": 100,
                        "height": 100
                    }
                },
                "opacity": {
                    "value": 0.5,
                    "random": false,
                    "anim": {
                        "enable": false,
                        "speed": 1,
                        "opacity_min": 0.1,
                        "sync": false
                    }
                },
                "size": {
                    "value": 5,
                    "random": true,
                    "anim": {
                        "enable": false,
                        "speed": 40,
                        "size_min": 0.1,
                        "sync": false
                    }
                },
                "line_linked": {
                    "enable": true,
                    "distance": 150,
                    "color": "#efefef",
                    "opacity": 0.4,
                    "width": 1
                },
                "move": {
                    "enable": true,
                    "speed": 6,
                    "direction": "none",
                    "random": false,
                    "straight": false,
                    "out_mode": "out",
                    "attract": {
                        "enable": false,
                        "rotateX": 600,
                        "rotateY": 1200
                    }
                }
            },
            "interactivity": {
                "detect_on": "canvas",
                "events": {
                    "onhover": {
                        "enable": true,
                        "mode": "repulse"
                    },
                    "onclick": {
                        "enable": true,
                        "mode": "push"
                    },
                    "resize": true
                },
                "modes": {
                    "grab": {
                        "distance": 400,
                        "line_linked": {
                            "opacity": 1
                        }
                    },
                    "bubble": {
                        "distance": 400,
                        "size": 40,
                        "duration": 2,
                        "opacity": 8,
                        "speed": 3
                    },
                    "repulse": {
                        "distance": 200
                    },
                    "push": {
                        "particles_nb": 4
                    },
                    "remove": {
                        "particles_nb": 2
                    }
                }
            },
            "retina_detect": true,
            "config_demo": {
                "hide_card": false,
                "background_color": "#b61924",
                "background_image": "",
                "background_position": "50% 50%",
                "background_repeat": "no-repeat",
                "background_size": "cover"
            }
        });
    }

    /** Function to draw trading chart */
    showTradingChart(base,exe) {
        new TradingView.widget({
             debug: true, // uncomment this line to see Library errors and warnings in the console
            fullscreen: true,
            //symbol: 'BTCUSD',
            symbol:base+'/'+exe,
            interval: 'D',
            container_id: "tradingview_cb72b",
            datafeed: new Datafeeds.UDFCompatibleDatafeed("http://172.16.21.84:8765/order/exchange-feed",60000),
            library_path: "assets/lib/charting_library/",
            locale: "en",
            drawings_access: { type: 'black', tools: [ { name: "Regression Trend" } ] },
            disabled_features: ["use_localstorage_for_settings"],
            overrides: {
                "paneProperties.background": "#222222",
                "paneProperties.vertGridProperties.color": "#454545",
                "paneProperties.horzGridProperties.color": "#454545",
                "symbolWatermarkProperties.transparency": 90,
                "scalesProperties.textColor" : "#AAA"
            }
        },500);
    }

    signup() {
        this.router.navigate(['header/signup']);
    }

    goToMarket() {
        this.router.navigate(['exHeader/exchange']);
    }

    check() {
        if(localStorage.getItem("token") || (localStorage.getItem('header'))) {            
            this.loginStatus = true;
        } else {
            this.loginStatus = false;
        }
    }
    
    /** Function to get coin list form API */
    getCoinList() {
        // let data = {
        //     "eventExternal": {
        //       "name": "request_get_coin_list",
        //       "key": "mykey"
        //     },
        //     "transferObjectMap": {
        //         "gatewayrequest": {}
        //     }
        // }
        // this.loader.show();
       
        this.server.getApi('wallet/coin/get-coin-list', 0).subscribe((succ) => {
            if(succ.body.status == 200) {
                console.log('fiat',this.baseFiatCurrency)
                this.baseFiatID = succ.body.data.filter((obj) => obj.coinShortName == this.baseFiatCurrency)[0].coinId;
                this.getLiveCoinBalance();
            } else {
                // this.loader.hide();
            }
        }, (err) => {
            // this.loader.hide();
        });
    }

    /** Function to get live coin balance based on GBP */
    getLiveCoinBalance() {
        let data = {
            "eventExternal": {
                "name":"request_coin_pair_list",
                "key":"mykey"
            },
            "transferObjectMap": { 
                "gatewayrequest": {
                    "baseCurrency": this.baseFiatID,
                }
            }
        }
        this.server.post('',data).subscribe((succ) => {
            // this.loader.hide();
            if(succ.transferObjectMap.statusCode == 200) {
                // this.liveCoinObj.btcPrice = succ.transferObjectMap.coinLastPairList.filter((obj) => obj.COIN_SHORT_NAME == "BTC")[0].LAST_PRICE;
                // this.liveCoinObj.ethPrice = succ.transferObjectMap.coinLastPairList.filter((obj) => obj.COIN_SHORT_NAME == "ETH")[0].LAST_PRICE;
                // this.liveCoinObj.ltcPrice = succ.transferObjectMap.coinLastPairList.filter((obj) => obj.COIN_SHORT_NAME == "LTC")[0].LAST_PRICE;
                // this.liveCoinObj.neoPrice = succ.transferObjectMap.coinLastPairList.filter((obj) => obj.COIN_SHORT_NAME == "NEO")[0].LAST_PRICE;
                // this.liveCoinObj.xlmPrice = succ.transferObjectMap.coinLastPairList.filter((obj) => obj.COIN_SHORT_NAME == "XLM")[0].LAST_PRICE;
                // this.liveCoinObj.xrpPrice = succ.transferObjectMap.coinLastPairList.filter((obj) => obj.COIN_SHORT_NAME == "XRP")[0].LAST_PRICE;
                // this.liveCoinObj.lcxPrice = succ.transferObjectMap.coinLastPairList.filter((obj) => obj.COIN_SHORT_NAME == "LCX")[0].LAST_PRICE;
                this.coinListArr.filter((obj) => obj.shortName == "LCX")[0].currPrice = succ.transferObjectMap.coinLastPairList.filter((obj) => obj.COIN_SHORT_NAME == "LCX")[0].LAST_PRICE;
                // this.liveCoinObj.dashPrice = succ.transferObjectMap.coinLastPairList.filter((obj) => obj.COIN_SHORT_NAME == "DASH")[0].LAST_PRICE;
                // this.liveCoinObj.bchPrice = succ.transferObjectMap.coinLastPairList.filter((obj) => obj.COIN_SHORT_NAME == "BCH")[0].LAST_PRICE;
                // this.liveCoinObj.usdtPrice = succ.transferObjectMap.coinLastPairList.filter((obj) => obj.COIN_SHORT_NAME == "USDT")[0].LAST_PRICE;
                // this.liveCoinObj.xvgPrice = succ.transferObjectMap.coinLastPairList.filter((obj) => obj.COIN_SHORT_NAME == "XVG")[0].LAST_PRICE;
            } else {
                // this.loader.hide();
            }
        }, (err) => {
            // this.loader.hide();
        });
    }

    /** Function to change the chart data */
    changeChart(base,pair,type) {
        this.currType = type;
        this.showTradingChart(pair,base);
    }

    /* Function to get coin price from CMC */
    getPriceFromCMC() {
        this.server.callListForCMC().subscribe((succ) => {
            if(succ.length) {
                // this.liveCoinObj.btcPrice = succ.filter((x) => x.symbol == "BTC")[0].price_usd;
                // this.liveCoinObj.ethPrice = succ.filter((x) => x.symbol == "ETH")[0].price_usd;
                // this.liveCoinObj.ltcPrice = succ.filter((x) => x.symbol == "LTC")[0].price_usd;
                // this.liveCoinObj.neoPrice = succ.filter((x) => x.symbol == "NEO")[0].price_usd;
                // this.liveCoinObj.xlmPrice = succ.filter((x) => x.symbol == "XLM")[0].price_usd;
                // this.liveCoinObj.xrpPrice = succ.filter((x) => x.symbol == "XRP")[0].price_usd;
                // this.liveCoinObj.dashPrice = succ.filter((x) => x.symbol == "DASH")[0].price_usd;
                // this.liveCoinObj.bchPrice = succ.filter((x) => x.symbol == "BCH")[0].price_usd;
                // this.liveCoinObj.usdtPrice = succ.filter((x) => x.symbol == "USDT")[0].price_usd;
                // this.liveCoinObj.xvgPrice = succ.filter((x) => x.symbol == "XVG")[0].price_usd;

                this.coinListArr.filter((obj) => obj.shortName == "BTC")[0].currPrice = succ.filter((x) => x.symbol == "BTC")[0].price_usd;
                this.coinListArr.filter((obj) => obj.shortName == "ETH")[0].currPrice = succ.filter((x) => x.symbol == "ETH")[0].price_usd;
                this.coinListArr.filter((obj) => obj.shortName == "LTC")[0].currPrice = succ.filter((x) => x.symbol == "LTC")[0].price_usd;
                this.coinListArr.filter((obj) => obj.shortName == "NEO")[0].currPrice = succ.filter((x) => x.symbol == "NEO")[0].price_usd;
                this.coinListArr.filter((obj) => obj.shortName == "XLM")[0].currPrice = succ.filter((x) => x.symbol == "XLM")[0].price_usd;
                this.coinListArr.filter((obj) => obj.shortName == "XRP")[0].currPrice = succ.filter((x) => x.symbol == "XRP")[0].price_usd;
                this.coinListArr.filter((obj) => obj.shortName == "DASH")[0].currPrice = succ.filter((x) => x.symbol == "DASH")[0].price_usd;
                this.coinListArr.filter((obj) => obj.shortName == "BCH")[0].currPrice = succ.filter((x) => x.symbol == "BCH")[0].price_usd;
                this.coinListArr.filter((obj) => obj.shortName == "USDT")[0].currPrice = succ.filter((x) => x.symbol == "USDT")[0].price_usd;
                this.coinListArr.filter((obj) => obj.shortName == "XVG")[0].currPrice = succ.filter((x) => x.symbol == "XVG")[0].price_usd;
            }
        }, (err) => {
        });
    }

    /** Function for setting animated value */
    setTradersValue() {
        if(this.animateObj.happy_traders <= 1999) {
            this.h_t_id = setTimeout(() => {
                this.animateObj.happy_traders++;
                this.setTradersValue();
            },10);
        }
    }

    setCommunityValue() {
        if(this.animateObj.community <= 2999) {
            this.com_id = setTimeout(() => {
                this.animateObj.community++;
                this.setCommunityValue();
            },10);
        }   
    }

    setTxnProcessedValue() {
        if(this.animateObj.txn_processed <= 2.3) {
            this.txn_p_id = setTimeout(() => {
                this.animateObj.txn_processed = Number((this.animateObj.txn_processed + .1).toFixed(1));
                this.setTxnProcessedValue();
            },10);
        }   
    }

    setStoredValue() {
        if(this.animateObj.stored_value <= 98) {
            this.c_s_id = setTimeout(() => {
                this.animateObj.stored_value++;
                this.setStoredValue();
            },10);
        }   
    }
}
