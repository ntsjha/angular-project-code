import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ViewController, AlertController, ToastController, ToastOptions } from 'ionic-angular';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { PinPage } from '../pin/pin';
import { ServiceServicesProvider } from '../../providers/service-services/service-services';
// import { Toast } from '@ionic-native/toast/ngx';

@IonicPage()
@Component({
  selector: 'page-modal',
  templateUrl: 'modal.html',
})
export class ModalPage {
  form1: FormGroup;
  toastoptions: ToastOptions
  pin1: any
  pin2: any
  pin3: any
  pin4: any
  pin: any
  email: boolean;
  constructor(public navCtrl: NavController,
    public navParams: NavParams,
    public viewCtrl: ViewController,
    private server: ServiceServicesProvider,
    public alerCtrl: AlertController
    , private toast: ToastController) {
  }

  ionViewWillEnter() {
    if(this.navParams.get('via') == 'EMAIL')
      this.email = true;
    else
      this.email = false;
  }

  ngOnInit() {
    console.log(this.navCtrl.last())
    this.form1 = new FormGroup({
      pin1: new FormControl('', [Validators.required, Validators.pattern(/^\d+$/)]),
      pin2: new FormControl('', [Validators.required, Validators.pattern(/^\d+$/)]),
      pin3: new FormControl('', [Validators.required, Validators.pattern(/^\d+$/)]),
      pin4: new FormControl('', [Validators.required, Validators.pattern(/^\d+$/)]),
    })
  }

  // get firstName(): any {
  //   return this.form1.get('firstName')
  // }

  dismiss() {
    if (navigator.onLine) {
      if (this.server.phoneNumber) {
        this.server.presentLoading();
        let pin = '';
        pin = this.pin1 + this.pin2 + this.pin3 + this.pin4
        let data = {
          "userId": (localStorage.getItem('userId')) ? (localStorage.getItem('userId')) : this.server.userId,
          "otp": Number(pin),
          "type": 2,
          "mobileNumber": this.server.phoneNumber
        }
        this.server.postApi(data, 'user/verifyOtpUpdate', 0).subscribe((response: any) => {
          this.server.phoneNumber = null;
          this.server.type = null;
          this.server.dismissLoading();
          if (response['response_code'] == 200) {
            this.server.phoneNumber = null;
            this.server.type = null;
            this.server.presentToast(response['response_message'])
            this.viewCtrl.dismiss();
          } else if (response.response_code == 403 || response.response_code == 409 || response.response_code == 401) {
            this.server.presentToast(response.response_message)
            this.server.logout();
          } else {
            this.server.presentToast(response['response_message'])
          }
        }, err => {
          this.server.dismissLoading();
          this.server.presentToast('Something went wrong')
        })
      }
      else {
        this.server.presentLoading();
        let pin = '';
        pin = this.pin1 + this.pin2 + this.pin3 + this.pin4
        let data = {
          "userId": (localStorage.getItem('userId')) ? (localStorage.getItem('userId')) : this.server.userId,
          "otp": Number(pin),
          "type": (this.server.type) ? (this.server.type) : 1,
          "phoneNumber": this.server.phoneNumber
        }
        this.server.postApi(data, 'user/verifyOtp', 0).subscribe((response: any) => {
          this.server.dismissLoading();
          if (response['response_code'] == 200) {
            this.server.type = null;
            this.server.presentToast(response['response_message'])
            this.viewCtrl.dismiss();
          } else if (response.response_code == 403 || response.response_code == 409 || response.response_code == 401) {
            this.server.presentToast(response.response_message)
            this.server.logout();
          } else {
            this.server.presentToast(response['response_message'])
          }
        }, err => {
          this.server.dismissLoading();
          this.server.presentToast('Something went wrong')
        })
      }
    }
    else
      this.server.presentToast('Your internet connection seems to be lost')

  }

  resendOtp() {
    if (navigator.onLine) {
      this.server.presentLoading();
      let data = {
        "userId": (localStorage.getItem('userId')) ? (localStorage.getItem('userId')) : this.server.userId
      }
      this.server.postApi(data, 'user/resendOtp', 0).subscribe((response: any) => {
        this.server.dismissLoading();
        if (response.response_code == 200) {
          this.server.presentToast(response.response_message)
        } else if (response.response_code == 403 || response.response_code == 409 || response.response_code == 401) {
          this.server.presentToast(response.response_message)
          this.server.logout();
        } else {
          this.server.presentToast(response.response_message)
        }
      }, err => {
        this.server.dismissLoading();
        this.server.presentToast('Something went wrong')
      })
    } else
      this.server.presentToast('Your internet connection seems to be lost')
  }

  dismissModal() {
    this.viewCtrl.dismiss('failure');
    this.server.phoneNumber = null;
    this.server.type = null;
  }

  /** Auto focus functionality */
  onKey(value, type, nextElement) {
    console.log(value)
    if (type == 1) {
      if (value != "") {
        // $('#otp2').focus();
        nextElement.setFocus();
      }
    } else if (type == 2) {
      if (value != "") {
        // $('#otp3').focus();
        nextElement.setFocus();
      }
    } else if (type == 3) {
      if (value != "") {
        // $('#otp4').focus();
        nextElement.setFocus();
      }
    } else if (type == 4) {
      console.log(value)
      if (value.key == 'Backspace') {
        this.pin1 = '';
        this.pin2 = '';
        this.pin3 = '';
        this.pin4 = '';
        nextElement.setFocus();
      }
    }
  }

}
