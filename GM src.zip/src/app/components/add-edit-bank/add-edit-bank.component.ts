import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ServiceService } from 'src/app/service/service.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CookieService } from 'ngx-cookie-service';
import { AppComponent } from 'src/app/app.component';
declare var $: any;
@Component({
  selector: 'app-add-edit-bank',
  templateUrl: './add-edit-bank.component.html',
  styleUrls: ['./add-edit-bank.component.css']
})
export class AddEditBankComponent implements OnInit {
  addEditBankForm: FormGroup;
  modeOfAction: any;
  currentId: any;
  bankData: any;
  currentUser: any;
  success: any = {};
  showApiMessage: any = false;
  subscription: any;

  constructor(
    private router: Router,
    private service: ServiceService,
    private activatedRoutes: ActivatedRoute,
    private fb: FormBuilder,
    private cookie: CookieService,
    private appC: AppComponent
  ) {
    this.addEditBankForm = this.fb.group({
      bankName: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(255), Validators.pattern(/^[a-zA-Z][a-zA-Z ]*$/)]],
      bankShortName: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(255), Validators.pattern(/^[a-zA-Z][a-zA-Z ]*$/)]],
    });
    this.currentUser = (this.cookie.get('userInfo')) ? JSON.parse(this.cookie.get('userInfo')) : this.service.initialUserInfo;
    this.subscription = this.service.authVerify.subscribe(val => {
      if (val === 'add-bank') {
        this.updateBankInfo();
        this.service.authVerify.next('false');
      }
    });
  }

  ngOnInit() {
    window.scrollTo(0, 0);
    this.activatedRoutes.params.subscribe((response) => {
      if (response.id1 === 'no') {
        this.modeOfAction = 'Add';
      } else {
        this.modeOfAction = 'Edit';
        this.currentId = response.id1;
        this.loadForm();
      }
    });
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  loadForm() {
    this.service.postMethod('account/common-permit/get-bank-by-id?bankId=' + this.currentId, {}, 1)
      .subscribe((res) => {
        if (res.status === 636 || res.status === 638) {
          this.addEditBankForm.patchValue({
            bankName: res.data.bankName,
            bankShortName: res.data.bankShortName,
          });
          this.bankData = res.data;
        }
      });
  }


  openGoogleAuth() {
    if (this.addEditBankForm.invalid) {
      return;
    }
    this.appC.google = { one: '', two: '', three: '', four: '', five: '', six: '' };
    this.appC.response = { message: '' };
    this.service.googleAuthCalledFrom = 'add-bank';
    $('#google-auth-modal').modal({ keyboard: false, backdrop: 'static' });
  }

  updateBankInfo() {
    if (this.addEditBankForm.invalid) {
      return;
    }
    if (this.modeOfAction === 'Add') {
      const data = {
        bankName: this.service.encrypt(this.addEditBankForm.value.bankName),
        bankShortName: this.service.encrypt(this.addEditBankForm.value.bankShortName),
        ipAddress: this.service.encrypt(this.currentUser.ip),
        location: this.service.encrypt(this.currentUser.city + ',' + this.currentUser.country_name),
      };
      this.service.postMethod('account/common-permit/add-bank-from-backend', data, 1).subscribe((res) => {
        this.success = res;
        if (res.status === 200) {
          this.router.navigate(['/bank-list/View/no']);
        } else {
          this.showApiMessage = true;
        }
      }, (error) => {
        this.showError(error);
      });
    } else {
      if (this.bankData ? !this.bankData.bankId : true) {
        this.showError({ error: 'error' });
        return;
      }
      const data = {
        bankId: this.service.encrypt(this.bankData.bankId),
        bankName: this.service.encrypt(this.addEditBankForm.value.bankName),
        bankShortName: this.service.encrypt(this.addEditBankForm.value.bankShortName),
        ipAddress: this.service.encrypt(this.currentUser.ip),
        location: this.service.encrypt(this.currentUser.city + ',' + this.currentUser.country_name),
      };
      this.service.postMethod('account/common-permit/edit-bank-detail', data, 1).subscribe((response) => {
        this.success = response;
        if (response.status === 200) {
          this.router.navigate(['/bank-list/View/no']);
        } else {
          this.showApiMessage = true;
        }
      }, error => {
        this.showError(error);
      });
    }

  }

  showError(error) {
    this.showApiMessage = true;
    if (error) {
      if (error.error) {
        if (error.error.status) {
          this.success.status = error.error.status;
          this.success.message = error.error.error;
        } else {
          this.success.status = 500;
          this.success.message = 'Internal server error';
        }
      } else {
        this.success.status = 500;
        this.success.message = 'Internal server error';
      }
    } else {
      this.success.status = 500;
      this.success.message = 'Internal server error';
    }
  }

}
