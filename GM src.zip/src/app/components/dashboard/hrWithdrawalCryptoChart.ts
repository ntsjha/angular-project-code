import { ServiceService } from 'src/app/service/service.service';

declare var CanvasJS: any;

export class hrWithdrawalCryptoChartService {
  chart: any;
  coinData = [];
  chartUpdated = [];

  hrwithdrawlCryptoChartData(data, chartId) {
    this.coinData = [];
    this.chartUpdated = data;
    if (this.chartUpdated) {
      this.chartUpdated.forEach(element => {
        let arr = [];
        if (element.graphResponseDto.graphObject.length) {
          element.graphResponseDto.graphObject.forEach((graphObj) => {
            const res1 = {
              x: (new Date(graphObj.timestamp)),
              y: graphObj.value,
            };
            arr.push(res1);
        }) ;
      } else {
        arr = [{ x: (new Date()), y: 0}];
      }
        const obj = {
          type: 'spline',
          xValueFormatString: 'hh:mm TT',
          yValueFormatString: '#,##0.###',
          name: element.graphResponseDto.currencyShortName,
          dataPoints: arr
        };
        this.coinData.push(obj);
      });
    } else {
      this.coinData = [
        {
          type: 'spline',
          xValueFormatString: 'hh:mm TT',
          yValueFormatString: '#,##0.###',
          name: '',
          dataPoints: [ { x: (new Date()), y: 0 } ]
        }
      ];
    }
    this.chart = new CanvasJS.Chart(chartId, {
      exportEnabled: true,
      zoomEnabled: true,
      animationEnabled: true,
      axisX: {
        valueFormatString: 'hh:mm TT'
      },
      axisY: {
        valueFormatString: '#,##0.###',
        includeZero: true,
      },
      legend: {
        cursor: 'pointer',
        fontSize: 16,
      },
      toolTip: {
        shared: true
      },
      data: this.coinData
    });
    return this.chart.render();
  }
}
