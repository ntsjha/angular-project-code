import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { ServerService } from '../../../service/server.service';
import { AppComponent } from '../../../app.component';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { HeaderComponent } from '../../header/header/header.component';
declare var $ : any;

@Component({
    selector: 'app-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
    loginForm: FormGroup;
    token: any;
    name: any;
    userID: any;
    qrCode = {Code1:""};
    otp = { one: "", two: "", three: "", four: "" };
    code: string;
    seconds: number=59;
    const: any;
    showEye: boolean = false;
    page;

    constructor(private router: Router, private server: ServerService, private appC: AppComponent, private spinnerService: Ng4LoadingSpinnerService, public myService: ServerService, public header:HeaderComponent) { }

    ngOnInit() {
        let url = window.location.href.split('=');
        this.page = url[url.length - 1];
        window.scrollTo(0, 0);
        this.checkInputs();
        if(url.length!=1){
            this.emailVerify()
        }
       
    }

    /** Function to validate form inputs */
    checkInputs() {
        this.loginForm = new FormGroup({
            email: new FormControl('ex@mailinator.com', [Validators.required, Validators.pattern(/^[A-Z0-9_-]+([\.][A-Z0-9_]+)*@[A-Z0-9-]+(\.[a-zA-Z]{2,3})+$/i)]),
            password: new FormControl('qwert@11', [Validators.required]),      
               
        });
        // this.loginForm = new FormGroup({
        //     email: new FormControl('', [Validators.required, Validators.pattern(/^[A-Z0-9_-]+([\.][A-Z0-9_]+)*@[A-Z0-9-]+(\.[a-zA-Z]{2,3})+$/i)]),
        //     password: new FormControl('', [Validators.required]),          
        // });
    }
    
    /** to get the value of field  */
    get email(): any {
        return this.loginForm.get('email');
    }
    get password(): any {
        return this.loginForm.get('password');
    }

    signup() {
        this.router.navigateByUrl('header/signup')
    }

    forgetPassword()  {
        this.router.navigateByUrl('header/forgotpassword')
    }

    /** to show and hide password */
    showHidePassword() {
        if(this.showEye == false) {
        this.showEye = true;
        } else if(this.showEye == true){
        this.showEye = false;
        }
    }

    /**for login function */
    login() {
        if(this.loginForm.invalid) {
            this.appC.showErrToast('Please provide all details.');
            return;
        } else {
            let loginData = {
                "email":this.loginForm.value.email,
                "password":this.loginForm.value.password,
            }                
            this.spinnerService.show();
            this.server.postApi('auth', loginData,0).subscribe(response => {   
                this.spinnerService.hide();
                localStorage.setItem('email',this.loginForm.value.email);
                if (response.body.status == 200) {
                    if ((response.body.data.TwoFa=="NONE")) {
                        this.appC.showSuccToast(response.body.message);
                        this.router.navigateByUrl('header/twofa/'+response.body.data.token); 
                   
                    } else if (response.body.data.TwoFa=="SKIP") {
                        this.appC.showSuccToast('Sucessfully login');
                        localStorage.setItem('token',response.body.data.token);
                        this.header.checkLogin();
                        this.router.navigate(['header/exchange-pair']);
                    } else if(response.body.data.TwoFa=="GOOGLE") {
                        this.qrCode = {Code1: ""};
                        this.token=response.body.data.token;
                        $('#googleAuth').modal({backdrop: 'static',keyboard:false});
                    }
                } else {
                    this.appC.showErrToast(response.message);                    
                }
            }, error => {
                this.spinnerService.hide();
                this.appC.showErrToast(error.error.message);
                if(error.error.status == 203){
                    this.router.navigateByUrl('header/verify/login');
                }
            });    
        }                         
    }


    qrVerify() {
        let data= {
            "otp":Number(this.qrCode.Code1),
        }
        this.spinnerService.show();
        this.server.postApi('auth/verify-google',data,this.token).subscribe(response => {
            this.spinnerService.hide();
            if (response.body.status == 200) {
                this.appC.showSuccToast('Google authentication verified successfully.');
                localStorage.setItem('token',response.body.data);
                localStorage.setItem('userId',this.userID);
                $('#googleAuth').modal('hide');
                this.header.checkLogin();
                this.router.navigate(['header/exchange-pair']);
            } else {
                
                this.appC.showErrToast(response.body.message);
                this.qrCode = {Code1:""} ;
                
            }
        }, error => {
            this.spinnerService.hide();
            this.appC.showErrToast(error.error.message);
        });
    }

    emailVerify(){
        this.spinnerService.show();
        this.server.getApi('account/verify-user?token='+this.page,0).subscribe(response => {
            this.spinnerService.hide();
            if (response.status == 200) {
                this.appC.showSuccToast(response.body.message);
                localStorage.setItem('userId',response.userId);
            } else {
                this.appC.showErrToast(response.body.message);                     
            }
        }, error => {
            this.spinnerService.hide();
            this.appC.showErrToast('Something went wrong');
        });
    }
    

}
