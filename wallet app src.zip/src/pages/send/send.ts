import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, App } from 'ionic-angular';
import { SendExchangePage } from "../send-exchange/send-exchange";
import { ServiceServicesProvider } from "../../providers/service-services/service-services";
import { NotificationsPage } from '../notifications/notifications';
import { FaqPage } from '../faq/faq';
import { VendorsListPage } from '../vendors-list/vendors-list';
import { SendMoneyOptionsPage } from '../send-money-options/send-money-options';
import { ContactsPage } from '../contacts/contacts';
import { SocketProvider } from '../../providers/socket/socket';

import { debounceTime, map } from 'rxjs/operators';
import { Subject } from 'rxjs/Rx';

@IonicPage()
@Component({
  selector: 'page-send',
  templateUrl: 'send.html',
})
export class SendPage {
  phoneNumbersInDB: any;
  phoneNumber: any;
  profile: any;
  receivers: any;
  currency: any;
  notifi: string;
  inputChange = new Subject<string>();
  amout: any;

  constructor(public navCtrl: NavController, public navParams: NavParams, private server: ServiceServicesProvider, public app: App, public socketService: SocketProvider) {
    const search = this.inputChange.debounceTime(500).distinctUntilChanged().subscribe(response => {
      this.numberExists(response)
    })
  }

  seeNotifications() {
    this.app.getRootNav().push(NotificationsPage)
  }

  seeFAQ() {
    this.app.getRootNav().push(FaqPage)
  }

  ionViewWillEnter() {
   
    this.socketService.getBalance();
    this.notifi = localStorage.getItem('notibadge')
    if (navigator.onLine) {
      console.log('test')
      let userId = localStorage.getItem('userId');
      this.server.presentLoading();
      this.server.getApi('user/userDetail/' + userId, 1).subscribe((response: any) => {
        this.server.dismissLoading();
        if (response.response_code == 200) {
          this.profile = response.result.userDetails;
          console.log('country',response.result.userDetails.country);
          this.getCurrency(response.result.userDetails.country);
        } else if (response.response_code == 403 || response.response_code == 409 || response.response_code == 401) {
          this.server.presentToast(response.response_message)
          this.server.logout();
          console.log('else if');
        }
        else {
          console.log('else country');
          this.server.presentToast(response.response_message)
        }
      }, err => {
        console.log('err',err);
        this.server.dismissLoading();
        this.server.presentToast('Something went wrong')
      })
    } else
      this.server.presentToast('Your internet connection seems to be lost')
      console.log('recentReceivers');
    this.recentReceivers();
  }

  // getAllContacts(){
  //   console.log('contact');
  //   this.contacts.find(['phoneNumbers','displayName']).then(
  //     (res : Contact[]) => {
  //       console.log("contacts fetched " + JSON.stringify(res));
  //     },
  //     (error: any) => {
  //       console.log('Error gettings contact.', error)
  //     }
  //   );
    
  // }

  sendMoney(number) {
    console.log('anshul number', number);
    this.phoneNumber = number.mobileNumber;
    let data = {
      phoneNumber: this.phoneNumber,
      receiverId: number._id
    };
    localStorage.sendMoneyProcess = JSON.stringify(data)
    this.app.getRootNav().push(SendExchangePage, { sender: this.profile.countryCode, receiver: number.countryCode })
  }

  numberExists(val) {
    console.log("phone----->>>", val)
    if (navigator.onLine) {
      if(this.phoneNumber.length >= 7 && this.phoneNumber.length <= 14){
            let data = {
              userId: localStorage.getItem('userId'),
              search: '+' + this.phoneNumber
            }
            this.server.postApi(data, 'user/searchContactList', 1).subscribe((response: any) => {
              if (response.response_code == 200) {
                this.phoneNumbersInDB = response.result.slice(0, 3);
                
              } else if (response.response_code == 403 || response.response_code == 409 || response.response_code == 401) {
                this.server.presentToast(response.response_message)
                this.server.logout();
              }
              else {
                this.server.presentToast(response.response_message);
              }
            }, err => {
              this.server.presentToast('Something went wrong')
            });
      }
    } else
      this.server.presentToast('Your internet connection seems to be lost')
  }

  recentReceivers() {
    if (navigator.onLine) {
      let data = { userId: localStorage.getItem('userId') }
      this.server.postApi(data, 'transaction/receiverList', 1).subscribe((response: any) => {
        if (response.response_code == 200) {
          this.receivers = response.result;
        } else if (response.response_code == 403 || response.response_code == 409 || response.response_code == 401) {
          this.server.presentToast(response.response_message)
          this.server.logout();
        }
        else {
          this.server.presentToast(response.response_message)
        }
      }, err => {
        this.server.presentToast('Something went wrong')
      })
    } else
      this.server.presentToast('Your internet connection seems to be lost')
  }

  isNumberValid() {
    console.log("",this.phoneNumber)
    if (navigator.onLine) {
      this.server.presentLoading();
      let data = {
        userId: localStorage.getItem('userId'),
        search: '+'+this.phoneNumber
      }
      this.server.postApi(data, 'user/isNumberValid', 1).subscribe((response: any) => {
        if (response.response_code == 200) {
          this.server.dismissLoading();
          this.sendMoney(response.result[0]);
        } else if (response.response_code == 403 || response.response_code == 409 || response.response_code == 401) {
          this.server.dismissLoading();
          this.server.presentToast(response.response_message)
          this.server.logout();
        }
        else {
          this.server.dismissLoading();
          this.server.presentToast('Your friend is not a Remittance user. Please ask him to signup as a user and then try again.')
        }
      }, err => {
        this.server.dismissLoading();
        this.server.presentToast('Something went wrong')
      })
    } else
      this.server.presentToast('Your internet connection seems to be lost')
  }

  getCurrency(country) {
    console.log(country)
    this.server.getCurrencyAndFlag(country, 1).subscribe(res => {
      console.log(res)
      this.currency = res[0].currencies[0].symbol;
      this.amout = (this.socketService.balance)?(this.socketService.balance):(this.profile.balance)
    });
  }

  sendViaVendor() {
      let data = {
        phoneNumber: this.phoneNumber,
        vendor: true
      };
      localStorage.sendMoneyProcess = JSON.stringify(data)
      this.app.getRootNav().push(SendMoneyOptionsPage)
  }

  getContacts() {
    this.app.getRootNav().push(ContactsPage, {process: 'SEND'})
  }
}
