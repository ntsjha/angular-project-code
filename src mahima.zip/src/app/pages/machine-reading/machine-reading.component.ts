import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-machine-reading',
  templateUrl: './machine-reading.component.html',
  styleUrls: ['./machine-reading.component.css']
})
export class MachineReadingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
