import { Component, OnInit } from '@angular/core';
import { AngularFirestore } from '@angular/fire/firestore';
import { ServiceService } from 'src/app/Shared/service.service';
import { ActivatedRoute } from '@angular/router';
import { Featurelist } from 'src/app/Shared/feed-type';
declare var $: any;
@Component({
  selector: 'app-feature-list',
  templateUrl: './feature-list.component.html',
  styleUrls: ['./feature-list.component.css']
})
export class FeatureListComponent implements OnInit {
  Subscriptionplan: {}[];
  p: number = 1;
  pageSize = 5;
  total = 0
  searchText: any;
  id: any;
  featurelist: any;
  featurelistLength: number;
  featurelistview: any;
  constructor(private afs: AngularFirestore, private firebaseServ: ServiceService, public route: ActivatedRoute) { }

  ngOnInit() {
    this.searchText=''
    this.getfeaturelist()
  }

  getfeaturelist() {
    this.firebaseServ.showSpinner();
    this.firebaseServ.getfeaturelist().subscribe(res => {
      this.featurelist = res.map(item => {
        return {
          
          id: item.payload.doc.id,
          ...item.payload.doc.data()
          // Declare model at FeedType for resuable
        } as Featurelist 
      })
      this.firebaseServ.hideSpinner();
      this.featurelistLength = this.featurelist.length
      console.log('DATA===>', this.featurelist)
    })

  }
  viewFuction(id) {
   
   var data  = this.featurelist.filter(x => (x.id == id));
   this.featurelistview=data[0]
    console.log(id,this.featurelistview)

  }
 


  deleteFuction(id) {
    this.id = id
    console.log(this.id)

  }
  onDelete() {
    
// return this.afs.refFromURL('asdasd').delete();
     


    this.afs.doc('FeatureListing/' + this.id).delete();

    this.firebaseServ.showSuccess('Feature has been deleted successfully.');
    this.getfeaturelist()
  }

  search() {
        
    var searchData = this.featurelist.filter(x => (x.Title.toLowerCase() == this.searchText.toLowerCase()));

    console.log("Nts jha -->>",searchData)
    this.featurelist = searchData;
    this.total = this.featurelist.length;

  }
  

  // search(){
  
  //   var searchData = this.contributorList.filter(x=>(x['userName'] == this.searchText));
  //   console.log("Contributor List-->>",this.searchText,searchData)
  //   this.contributorList = searchData;
  //   this.total = this.contributorList.length;
    
  //   console.log("Contributor List-->>",this.contributorList.length)
  // }

   page(event) {
    console.log(event);
    this.p = event
  }


}
