import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { ServerService } from '../../../server.service';
import { AppComponent } from '../../../app.component';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { Router } from '@angular/router';
import { GooglePlaceDirective } from 'ngx-google-places-autocomplete';
import { Address } from 'ngx-google-places-autocomplete/objects/address';

@Component({
    selector: 'app-editprofile',
    templateUrl: './editprofile.component.html',
    styleUrls: ['./editprofile.component.css']
})
export class EditprofileComponent implements OnInit {
    @ViewChild("placesRef") placesRef : GooglePlaceDirective;
    again: any;
    image: any;
    editProfile: FormGroup;
    options: any;
    myAddress: string ='';

    public handleAddressChange(address: Address) {
        //console.log(address)
        this.myAddress = address.formatted_address;
        address.address_components.forEach((obj) => {
            if(obj.types[0] == "locality") {
                this.editProfile.patchValue({
                    city: obj.long_name
                })
            }
            if(obj.types[0] == "administrative_area_level_1") {
                this.editProfile.patchValue({
                    state: obj.long_name
                })
            }
            if(obj.types[0] == "country") {
                this.editProfile.patchValue({
                    country: obj.long_name
                })
            }
        })
      
    } 


    constructor(private server: ServerService, public appC: AppComponent, private spinnerService: Ng4LoadingSpinnerService, private router: Router) { }

    ngOnInit() {
        this.getprofile();
        this.checkpoints()

    }

    checkpoints() {
        this.editProfile = new FormGroup({
            email: new FormControl('', [Validators.pattern(/^[A-Z0-9_]+([\.-][A-Z0-9_]+)*@[A-Z0-9-]+(\.[a-zA-Z]{2,5})+$/i)]),
            lastname: new FormControl('', [Validators.required, Validators.pattern(/^[a-z A-Z]*$/)]),
            name: new FormControl('', [Validators.required, Validators.minLength(2), Validators.pattern(/^[a-zA-Z ]*$/i)]),
            phone: new FormControl(''),
            state: new FormControl('', [Validators.required]),
            country: new FormControl('', [Validators.required]),
            address: new FormControl('', [Validators.required]),
            gender: new FormControl('', [Validators.required]),
            city: new FormControl('', [Validators.required]),
            propic: new FormControl('')
        });
    }

    get email(): any {
        return this.editProfile.get('email');
    }

    get propic(): any {
        return this.editProfile.get('propic');
    }


    get lastname(): any {
        return this.editProfile.get('lastname');
    }

    get phone(): any {
        return this.editProfile.get('phone');
    }

    get name(): any {
        return this.editProfile.get('name');
    }

    get address(): any {
        return this.editProfile.get('address');
    }
    get city(): any {
        return this.editProfile.get('city');
    }


    get state(): any {
        return this.editProfile.get('state');
    }

    get country(): any {
        return this.editProfile.get('country');
    }

    get gender(): any {
        return this.editProfile.get('gender');
    }


    cancl() {
        this.router.navigateByUrl('profile')
    }
    getprofile() {
        this.spinnerService.show();
        this.server.getApi('account/my-account').subscribe((res) => {
            this.spinnerService.hide();
            if (res.status == 200) {
                this.editProfile.patchValue({
                    name: res.data.firstName,
                    lastname: res.data.lastName,
                    phone: res.data.phoneNo,
                    email: res.data.email,
                    gender: res.data.gender || '',
                    country: res.data.country,
                    state: res.data.state,
                    city: res.data.city,
                    address: res.data.address,
                    // propic:res.data.imageUrl

                })
                if (this.again != 'undefined' || this.again != '') {
                    this.again = res.data.imageUrl;
                } else {
                    this.again = "assets/images/edit-img.png"
                }

            }
            else {
                this.spinnerService.hide();
                this.appC.showErrToast(res.message);
            }

        }, (err) => {
            this.spinnerService.hide();
            this.appC.showErrToast('Something went wrong')
        })
    }


    fileSelect($event): void {
        var self = this;
        // this.readThis($event.target);
        if ($event.target.files && $event.target.files[0]) {
            var fileType = $event.target.files[0].type;
            var fileSize = $event.target.files[0].size;
            if(fileSize < 10000000){
                if (fileType === 'image/jpeg' || fileType === 'image/png' || fileType === 'image/jpg') {
                    this.image = $event.target.files[0];
                    this.picphoto()
                    var reader = new FileReader()
                    reader.onload = (e) => {
                        self.editProfile.value.propic = e.target['result']
                    }
                    // reader.readAsDataURL($event.target.files[0])
                } else {
                    this.image = '';
                    this.appC.showErrToast("Please select only jpeg,png,jpg");
                }
            } else {
                this.again = "assets/images/edit-img.png";
                this.appC.showErrToast("Please select file less than 10 MB.");
                $event.target.value = '';
                return;
            }
        }
    }

    readThis(inputValue: any): void {
        var file: File = inputValue.files[0];
        var myReader: FileReader = new FileReader();
        myReader.onloadend = (e) => {
            this.image = myReader.result;
        }
        myReader.readAsDataURL(file);
    }

    picphoto() {
        let formData = new FormData();
        formData.append('file', this.image);
        this.spinnerService.show();
        this.server.postApi('account/upload-file', formData).subscribe((res) => {
            this.spinnerService.hide();
            if (res.status == 200) {
                this.again = res.data;

            }
            else {
                this.spinnerService.hide();
                this.appC.showErrToast(res.message);
            }

        }, (err) => {
            this.spinnerService.hide();
            this.appC.showErrToast('Something went wrong')
        })
    }

    updateProfile() {
        if (this.editProfile.value.country == "" || this.editProfile.value.address== "" || this.editProfile.value.state== "" || this.editProfile.value.lastname == "" ||
        this.editProfile.value.name =="" ||  this.editProfile.value.city =="") {
            this.appC.showErrToast("Please enter details");
            return;
        }
        if(this.myAddress == ''){
            this.myAddress = this.editProfile.value.address;
           
        }
        let data = {
                "city": this.editProfile.value.city,
                "country": this.editProfile.value.country,
                "firstName": this.editProfile.value.name,
                "gender": this.editProfile.value.gender,
                "imageUrl": this.again,
                "lastName": this.editProfile.value.lastname,
                "state":this.editProfile.value.state,
                "address":this.myAddress      
        }
        this.spinnerService.show();
        this.server.postApi('account/profile-update',data).subscribe((res) => {
            this.spinnerService.hide();
            if (res.status == 200) {
                this.appC.showSuccToast(res.message);
                this.router.navigateByUrl('profile');
            } else {
                this.spinnerService.hide();
                this.appC.showErrToast(res.message);
            }
        }, (err) => {
            this.spinnerService.hide();
            this.appC.showErrToast('Something went wrong')
        })
    }

    onKey(obj) {
        if(obj.target.value == '') {
            this.editProfile.patchValue({
                city:"",
                state: "",
                country:""
            });
        }
    }
}
