import { Component, OnInit, OnDestroy } from '@angular/core';
import { ServiceService } from 'src/app/service/service.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';
import { CookieService } from 'ngx-cookie-service';
declare var $:any;

@Component({
    selector: 'app-withdraw-req',
    templateUrl: './withdraw-req.component.html',
    styleUrls: ['./withdraw-req.component.css']
})
export class WithdrawReqComponent implements OnInit, OnDestroy {
    obj:any={};
    id: string;
    rejectionModalForm: FormGroup;
    type: string;
    currencyName: any;
    txnId: any;
    custObj: any={};
    txnObj:any ={};
    status: any;
    subscription: any;
    userIp: any;
    constructor(public server:ServiceService, private spinner: NgxSpinnerService, private cookie: CookieService, private service: ServiceService) {
        this.subscription = this.server.authVerify.subscribe((res)=>{
            if(res == 'withdraw-req') {
                $('#google-auth-modal').modal('hide');
                this.actionOnWithdrawal();
                this.server.authVerify.next('false');
            }
        });

        this.rejectionModalForm = new FormGroup({
            'select_reason': new FormControl('',[Validators.required]),
            'remark': new FormControl(''),
        });
        this.userIp = (this.cookie.get('userInfo')) ? JSON.parse(this.cookie.get('userInfo')) : this.service.initialUserInfo;
     }

    ngOnInit() {
        this.callByUrl();
        window.scrollTo(0, 0);
    }

    ngOnDestroy() {
        this.subscription.unsubscribe();
    }

    callByUrl() {
        let url = window.location.href;
        let arr = url.split('/');
        let arr2 = arr[arr.length -1].split('-');
        this.type = arr2[arr2.length-4];
        this.id = arr2[arr2.length-3];
        this.currencyName = arr2[arr2.length -2];
        this.txnId = arr2[arr2.length -1];
        this.getDetails();
    }

    getDetails() {
        this.server.getMethod(`wallet/common-permit/history/get-transaction-details?currencyName=${this.currencyName}&txnId=${this.txnId}`,1).subscribe((res)=>{
            if(res['data']) {
                this.custObj = res['data'].custObj;
                this.txnObj = res['data'].txnObj;
            }
        });
    }

    get select_reason(): any {
        return this.rejectionModalForm.get('select_reason');
    }
    get remark(): any {
        return this.rejectionModalForm.get('remark');
    }

    open2FA(status) {
        this.status = status;
        this.server.googleAuthCalledFrom = 'withdraw-req';
        $('#google-auth-modal').modal({backdrop: 'static', keyboard: false});

    }

    actionOnWithdrawal() {
        let data = {    
            "status": this.status,
            "transactionId": this.txnId,
            "userId": this.id,
            "ipAddress": this.userIp.ip,
            "location": this.userIp.city + ',' + this.userIp.country_name,
            
        };

        if(this.rejectionModalForm.value.select_reason) {
            data['reason'] = this.rejectionModalForm.value.select_reason;
        }
        if(this.rejectionModalForm.value.remark) {
            data['remarks'] = this.rejectionModalForm.value.remark;
        }
        let url ;
        if(this.type== 'crypto') {
            url= 'wallet/common-permit/crypto-withdraw-management/update-withdraw-txn-details';
        }else if(this.type == 'fiat'){
            url='wallet/common-permit/fiat-withdraw-management/update-withdraw-txn-details';
        }
        this.server.postMethod(url, data,1).subscribe((res)=>{
            if(this.status == 'QUEUED') {
                this.txnObj.status = 'QUEUED';
            }else if(this.status == 'REJECTED') {
                this.txnObj.status = 'REJECTED';
            }
        });
        $('#myticket1').modal('hide');
        this.spinner.hide();
        this.getDetails();
    }

    openModal() {
        $('#myticket1').modal({backdrop: 'static', keyboard: false});
    }

    closeModal() {
        this.rejectionModalForm.reset();
    }

}
