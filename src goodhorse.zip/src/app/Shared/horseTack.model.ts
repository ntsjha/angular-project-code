export class HorseTack{
    id:string
    s_no:string
    type:string
    brand:string
    model:string
    size:string
    material:string
    use:string
    note:string
}