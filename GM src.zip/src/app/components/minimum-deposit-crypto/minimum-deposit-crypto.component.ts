import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ServiceService } from 'src/app/service/service.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { ActivatedRoute, Router } from '@angular/router';
import { AppComponent } from 'src/app/app.component';
import { CookieService } from 'ngx-cookie-service';

declare var $: any;

@Component({
  selector: 'app-minimum-deposit-crypto',
  templateUrl: './minimum-deposit-crypto.component.html',
  styleUrls: ['./minimum-deposit-crypto.component.css']
})
export class MinimumDepositCryptoComponent implements OnInit, OnDestroy {
  cryptoFunction: FormGroup;
  coinName: any;
  cryptoFiat: any;
  currentUser: any;
  subscription: any;
  userIp: any;
  response: any = { 'message': '' };

  constructor(
    private service: ServiceService,
    private spinner: NgxSpinnerService,
    private activatedRoute: ActivatedRoute,
    private route: Router,
    private appC: AppComponent,
    private cookie: CookieService
  ) {
    this.cryptoFunction = new FormGroup({
      fee: new FormControl(null, [Validators.required, Validators.maxLength(8), Validators.pattern(/^^\d+(\.\d{1,8})*$/)]),
    });
    this.service.currentUserInfo.subscribe((response) => {
      this.currentUser = response;
    });
    this.subscription = this.service.authVerify.subscribe(val => {
      if (val === 'min-deposit') {
        this.depositCrypto();
        this.service.authVerify.next('false');
      }
    });
    this.userIp = (this.cookie.get('userInfo')) ? JSON.parse(this.cookie.get('userInfo')) : this.service.initialUserInfo;
  }

  ngOnInit() {
    this.activatedRoute.params.subscribe(id => {
      this.coinName = id.id;
    });
    this.minDepositCrypto();
    window.scrollTo(0, 0);
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  minDepositCrypto() {
    this.spinner.show();
    this.service.getMethod('wallet/admin/fees/get-fee-details?currencyName=' + this.coinName + '&currencyType=crypto', 1).subscribe((response: any) => {
      this.spinner.hide();
      this.cryptoFiat = JSON.parse(this.service.decrypt(response.data));
      if (this.cryptoFiat.status === 845 || this.cryptoFiat.status === 842) {
        this.cryptoFunction.patchValue({
          fee: this.cryptoFiat.data.minDepositFee
        });
      }
    }, (error) => {
      this.spinner.hide();
    });
    this.spinner.hide();

  }

  /** Function to verify google authentication */
  verifyGoogleAuth() {
    this.appC.google = { one: '', two: '', three: '', four: '', five: '', six: '' };
    this.appC.response = { message : '' };
    this.service.googleAuthCalledFrom = 'min-deposit';
    $('#google-auth-modal').modal({ keyboard: false, backdrop: 'static' });

  }

  depositCrypto() {
    this.spinner.show();
    const data = {
      amount: this.cryptoFunction.value.fee,
      coinName: this.coinName,
      ipAddress: this.userIp.ip,
      location: this.userIp.city + ',' + this.userIp.country_name
    };

    this.service.postMethod('wallet/admin/fees/set-min-crypto-deposit-fee', data, 1).subscribe((response: any) => {
      this.spinner.hide();
      if (response.status === 842) {
        this.route.navigate(['/minimum-deposit']);
      } else {
        this.response = response;
      }
    }, (error) => {
      this.spinner.hide();
    });
  }

}
