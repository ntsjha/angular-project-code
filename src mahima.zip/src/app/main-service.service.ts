import { CookieService } from 'ngx-cookie-service';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ToastrService } from 'ngx-toastr';
import * as crypto from 'crypto-js';
import { Observable } from 'rxjs';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
@Injectable({
  providedIn: 'root'
})
export class MainServiceService {
  headerOption: any;
  token: any;
  id: any;
  baseUrl = 'http://172.16.16.218:3030/';
  constructor(
    public http: HttpClient,
    private toastr: ToastrService,
    public cookie: CookieService,
    public spinner: Ng4LoadingSpinnerService
  ) { }
  // get api method
  get(url, header): Observable<any> {
    this.token = this.cookie.get('token');
    this.id = this.decrypt(this.cookie.get('id'));
   if (header === 0) {
     this.headerOption = {
       headers: new HttpHeaders({
         'Content-Type': 'application/json',
          _id : this.id
       }),
     };
    } else if (header === 1) {
      this.headerOption = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
            token: this.token,
            _id: this.id
        }),
      };
    } else {
      this.headerOption = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
        }),
      };
    }
    return this.http.get(this.baseUrl + url, this.headerOption);
  }
// post api method
  post(url, data, header): Observable<any> {
    this.token = this.cookie.get('token');
    this.id = this.decrypt(this.cookie.get('id'));
    if (header === 0) {
     this.headerOption = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
            _id: this.id
        }),
      };
    } else if (header === 1) {
      this.headerOption = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
            token: this.token,
            _id: this.id
        }),
      };
    } else {
      this.headerOption = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
        }),
      };
    }
    return this.http.post(this.baseUrl + url, data, this.headerOption);
  }
  // Encrypt method
  encrypt(value) {
    let cypherText = crypto.AES.encrypt(value, '123');
    return cypherText.toString();
  }
 // Decrypt method
  decrypt(value) {
    let decypherText = crypto.AES.decrypt(value, '123');
    return decypherText.toString(crypto.enc.Utf8);
  }
  showSuccess(msg) {
    this.toastr.success(msg, 'FUEL');
  }
  showError(msg) {
    this.toastr.error(msg, 'FUEL');
  }
  showWarning(msg) {
    this.toastr.warning(msg, 'FUEL');
  }
  showInfo(msg) {
    this.toastr.info(msg, 'FUEL');
  }
}