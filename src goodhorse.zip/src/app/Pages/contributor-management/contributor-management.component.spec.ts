import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ContributorManagementComponent } from './contributor-management.component';

describe('ContributorManagementComponent', () => {
  let component: ContributorManagementComponent;
  let fixture: ComponentFixture<ContributorManagementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ContributorManagementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ContributorManagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
