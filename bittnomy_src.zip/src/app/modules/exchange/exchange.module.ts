import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ExchangeComponent } from './exchange/exchange.component';
import { FormsModule } from '@angular/forms';
import { FilterdataPipe } from '../../filterdata.pipe';

@NgModule({
    imports: [
        CommonModule,
        FormsModule
    ],
    declarations: [
        ExchangeComponent,
        FilterdataPipe
    ]
})
export class ExchangeModule { }
