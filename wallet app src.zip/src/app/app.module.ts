import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';
import { SplashScreen } from '@ionic-native/splash-screen';
import { StatusBar } from '@ionic-native/status-bar';
import { ActionSheet, ActionSheetOptions } from '@ionic-native/action-sheet';

import { MyApp } from './app.component';
import { HomePage } from '../pages/home/home';
import { SignupPage } from '../pages/signup/signup';
import { TabsPage } from '../pages/tabs/tabs';
import { LoginPage } from '../pages/login/login';
import { PinPage } from '../pages/pin/pin';
import { SignpinPage } from '../pages/signpin/signpin';
import { ForgotPage } from '../pages/forgot/forgot';
import { ResetPage } from '../pages/reset/reset';
import { ChangepassPage } from '../pages/changepass/changepass';
import { AccountPage } from '../pages/account/account';
import { TermsPage } from '../pages/terms/terms';
import { AddmoneyPage } from '../pages/addmoney/addmoney';
import { WithdrawPage } from '../pages/withdraw/withdraw';
import { ReceivePage } from '../pages/receive/receive';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { FaqPage } from '../pages/faq/faq';
import { SendPage } from '../pages/send/send';
import { InternationalPhoneNumberModule } from 'ngx-international-phone-number';
import { SettingNewPage } from '../pages/setting-new/setting-new';

import { ServiceServicesProvider } from '../providers/service-services/service-services';
import { HttpClientModule } from '@angular/common/http';
import { Facebook } from '@ionic-native/facebook';
import { Camera } from '@ionic-native/camera';
import { ModalPage } from '../pages/modal/modal';
import { AddMoneyOptionsPage } from "../pages/add-money-options/add-money-options";
import { MyCardsPage } from "../pages/my-cards/my-cards";
import { AddCardPage } from "../pages/add-card/add-card";
import { EnterCvcPage } from "../pages/enter-cvc/enter-cvc";
import { NotificationsPage } from "../pages/notifications/notifications";
import { ResetPinPage } from "../pages/reset-pin/reset-pin";
import { TransactionStatusPage } from "../pages/transaction-status/transaction-status";
import { SendExchangePage } from "../pages/send-exchange/send-exchange";
import { ConvertedCurrencyPipe } from "../pipes/converted-currency/converted-currency";
import { CardMaskPipe } from "../pipes/card-mask/card-mask";
import { SendMoneyOptionsPage } from "../pages/send-money-options/send-money-options";
import { FCM } from '@ionic-native/fcm';
import { SendMoneyConfirmationPage } from '../pages/send-money-confirmation/send-money-confirmation';
import { InAppBrowser } from '@ionic-native/in-app-browser';
import { SelectContactPage } from '../pages/select-contact/select-contact';
import { VendorsListPage } from '../pages/vendors-list/vendors-list';
import { WithdrawOptionsPage } from '../pages/withdraw-options/withdraw-options';
import { BankListPage } from '../pages/bank-list/bank-list';
import { AddBankPage } from '../pages/add-bank/add-bank';
import { ContactsPage } from '../pages/contacts/contacts';
import { ContactsAddPage } from '../pages/contacts-add/contacts-add';
import { SocketProvider } from '../providers/socket/socket';
// import { GooglePlus } from '@ionic-native/google-plus';
import { GooglePlus } from '@ionic-native/google-plus';

@NgModule({
  declarations: [MyApp, HomePage, TabsPage, LoginPage, SignupPage, PinPage, SignpinPage, ForgotPage,ResetPage, ChangepassPage, AccountPage, TermsPage, AddmoneyPage, WithdrawPage, ReceivePage,FaqPage,SendPage,SettingNewPage, AddMoneyOptionsPage, MyCardsPage, AddCardPage, EnterCvcPage, NotificationsPage, ResetPinPage, TransactionStatusPage, SendExchangePage, ConvertedCurrencyPipe, CardMaskPipe, SendMoneyOptionsPage, SendMoneyConfirmationPage, SelectContactPage, VendorsListPage, WithdrawOptionsPage, BankListPage, AddBankPage, ContactsPage, ContactsAddPage],
  imports: [
    BrowserModule,
    IonicModule.forRoot(MyApp),
    ReactiveFormsModule,
    FormsModule,
    InternationalPhoneNumberModule,
    HttpClientModule
  ],
  bootstrap: [IonicApp],
  entryComponents: [MyApp, HomePage, TabsPage, LoginPage, SignupPage, PinPage, SignpinPage, ForgotPage,ResetPage, ChangepassPage, AccountPage, TermsPage, AddmoneyPage, WithdrawPage, ReceivePage,FaqPage,SendPage,SettingNewPage, AddMoneyOptionsPage, MyCardsPage, AddCardPage, EnterCvcPage, NotificationsPage, ResetPinPage, TransactionStatusPage, SendExchangePage, SendMoneyOptionsPage, SendMoneyConfirmationPage, SelectContactPage, VendorsListPage, WithdrawOptionsPage, BankListPage, AddBankPage, ContactsPage, ContactsAddPage],
  providers: [
    StatusBar,
    SplashScreen,
    ServiceServicesProvider,
    {provide: ErrorHandler, useClass: IonicErrorHandler},
    Facebook,
    GooglePlus,
    Camera,
    ActionSheet,
    FCM,
    InAppBrowser,
    SocketProvider
  ]
})
export class AppModule {}
