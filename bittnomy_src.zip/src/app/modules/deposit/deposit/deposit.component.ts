import { Component, OnInit } from '@angular/core';
import { AppComponent } from '../../../app.component';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { ServerService } from '../../../service/server.service';
import { HeaderComponent } from '../../header/header/header.component';
import { Router } from '@angular/router';

@Component({
    selector: 'app-deposit',
    templateUrl: './deposit.component.html',
    styleUrls: ['./deposit.component.css']
})
export class DepositComponent implements OnInit {
    accObj = {iban:"", bic_swift_code:"", bank_name:"", bank_address:"", recipient_name:"", recipient_address:"", user_ref_no:""};
    user = {amount:""};
    regexForSixChar = (/^(\d+)?([.]?\d{0,6})?$/);
    fileName = "Choose file...";
    fileData = "";

    constructor(private appC: AppComponent, private spinnerService: Ng4LoadingSpinnerService, private server: ServerService, public header:HeaderComponent, public router: Router) { }

    ngOnInit() {
        window.scrollTo(0, 0);
        this.fileName = "Choose file...";
        this.fileData = "";
        this.getAccountDetails();
    }

    /** Function to get account details of admin */
    getAccountDetails() {
        let data = {
            "eventExternal" : {
                "name" : "get_admin_account_detail",
                "key" : "mykey"
            },
            "transferObjectMap" : {
                "gatewayrequest": {
                    "loginToken": localStorage.getItem("token"),
                    "paymentType": "bittnomy"
                }
            }
        }
        this.spinnerService.show();
        this.server.postApi('',data,0).subscribe((succ) => {
            this.spinnerService.hide();
            if(succ.transferObjectMap.statusCode == 200) {
                if(succ.transferObjectMap.result.length) {
                    this.accObj.bank_address = succ.transferObjectMap.result[0].bankAddress;
                    this.accObj.bank_name = succ.transferObjectMap.result[0].bankName;
                    this.accObj.bic_swift_code = succ.transferObjectMap.result[0].swiftCode;
                    this.accObj.iban = succ.transferObjectMap.result[0].international_bank_acc_no;
                    this.accObj.recipient_address = succ.transferObjectMap.result[0].recipientAddress;
                    this.accObj.recipient_name = succ.transferObjectMap.result[0].recipientName;
                    this.accObj.user_ref_no = succ.transferObjectMap.uniqueReferrenceNumber;
                }
            } else if(succ.transferObjectMap.statusCode == 403){
                this.header.tokenExpire();
            } else {
                this.appC.showErrToast(succ.transferObjectMap.message);
            }
        }, (err) => {
            this.spinnerService.hide();
        });
    }

    /** Function to restrict space */
    restrictSpace(event) {
        var k = event.charCode;
        if (k === 32) return false;
    }

    /** Function to restrict character */
    restrictChar(event) {
        var k = event.charCode;
        if (event.key === 'Backspace')
            k = 8;
        if (k >= 48 && k <= 57 || k == 8 || k == 46)
            return true;
        else
            return false;    
    }

    /** Function to restrict length after dot */
    restrictLength(type) {
        if(this.user.amount.includes(".")) {
            if (!this.regexForSixChar.test(this.user.amount)) {
                let tempVal = this.user.amount.split('.');
                this.user.amount = tempVal[0] + '.' + tempVal[1].slice(0, 6);
            }
        }
    }

    /** Function for I have Paid */
    iHavePaidFunc() {
        if(this.user.amount == "") {
            this.appC.showErrToast("Enter amount value");
            return;
        } else if(this.user.amount == ".") {
            this.appC.showErrToast("Enter valid amount value");
            return;
        } else if(Number(this.user.amount) <= 0) {
            this.appC.showErrToast("Enter valid amount value");
            return;
        } else if(this.fileData == "") {
            this.appC.showErrToast("Choose receipt image");
            return;
        } else {
            let data = {
                "eventExternal": {
                    "name": "payment_callback",
                    "key": ""
                },
                "transferObjectMap": {
                    "gatewayrequest": {
                        "token": localStorage.getItem('token'),
                        "paymentGateway": "",
                        "amount": this.user.amount,
                        "currency": "USD",
                        "transactionId": "",
                        "paymentHash": "",
                        "attachment": this.fileData,
                        "code": "200",
                        "message": "success",
                        "paymentGatewayId": "1"
                    }
                }
            }
            this.spinnerService.show();
            this.server.postApi('',data,0).subscribe((succ) => {
                this.spinnerService.hide();
                if(succ.transferObjectMap.statusCode == 200) {
                    this.appC.showSuccToast("Requested submitted successfully.Admin will take action on your request shortly.");
                    this.user.amount = "";
                    this.fileName = "Choose file...";
                    this.fileData = "";
                } else if(succ.transferObjectMap.statusCode == 403) {
                    this.header.tokenExpire();
                } else {
                    this.appC.showErrToast(succ.transferObjectMap.message);
                }
            }, (err) => {
                this.spinnerService.hide();
                this.appC.showErrToast("Something went wrong.");
            });
        }
    }

    /** Function for file input handler */
    handleFileInput(event) {
        var self = this;
        if(event.target.files && event.target.files[0]){
            var type = event.target.files[0].type;
            if(type === 'image/png' || type === 'application/pdf' || type === 'image/jpeg' || type === 'image/jpg') {
                self.fileName = event.target.files[0].name;
                var reader = new FileReader()
                reader.onload = (e) =>  {
                    switch(type) {
                        case 'image/png':
                            self.fileData = e.target['result'].substring(22);
                            break;
                        case 'image/jpg':
                            self.fileData = e.target['result'].substring(22);
                            break;
                        case 'image/jpeg':
                            self.fileData = e.target['result'].substring(23);
                            break;
                        case 'application/pdf':
                            self.fileData = e.target['result'].substring(28);
                            break;
                    }
                }
                reader.readAsDataURL(event.target.files[0]);
            } else {
                this.appC.showErrToast("Select png, jpg, jpeg and pdf file only.");
                self.fileName = "Choose file...";
                self.fileData = "";
            }
        }
    }
}
