import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ServiceService } from 'src/app/service/service.service';
import { CookieService } from 'ngx-cookie-service';
import { NgxSpinnerService } from 'ngx-spinner';
import { ActivatedRoute } from '@angular/router';
import { AppComponent } from 'src/app/app.component';

declare var $: any;

@Component({
    selector: 'app-admin-change-password',
    templateUrl: './admin-change-password.component.html',
    styleUrls: ['./admin-change-password.component.css']
})
export class AdminChangePasswordComponent implements OnInit, OnDestroy {

    changePasswordForm: FormGroup;
    success: any = { data: '' };
    userIp: any;
    showApiError: any = false;
    adminMail: string;
    subscription: any;

    constructor(private service: ServiceService, private cookie: CookieService, private spinner: NgxSpinnerService, private activatedRoute: ActivatedRoute, private appC: AppComponent) {
        this.changePasswordForm = new FormGroup({
            newPassword: new FormControl('', [Validators.required, Validators.pattern(/^(?=.{10,128})(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=]).*$/), Validators.minLength(10), Validators.maxLength(128)]),
            confirmPassword: new FormControl('', [Validators.required, Validators.minLength(10), Validators.maxLength(128)]),
        }, passwordMatchValidator);
        /** Function for password match and mismatch */
        function passwordMatchValidator(g: FormGroup) {
            const pass = g.get('newPassword').value;
            const confPass = g.get('confirmPassword').value;
            if (pass !== confPass) {
                g.get('confirmPassword').setErrors({ mismatch: true });
            } else {
                g.get('confirmPassword').setErrors(null);
                return null;
            }
        }
        this.userIp = (this.cookie.get('userInfo')) ? JSON.parse(this.cookie.get('userInfo')) : this.service.initialUserInfo;
        this.subscription = this.service.authVerify.subscribe(val => {
            if (val === 'admin-change-password') {
                this.changePasswordFunc();
                this.service.authVerify.next('false');
            }
        });
    }

    get newPassword(): any {
        return this.changePasswordForm.get('newPassword');
    }

    get confirmPassword(): any {
        return this.changePasswordForm.get('confirmPassword');
    }

    /** Function to send value */
    changePasswordFormTest(...val) {
        this.changePasswordForm.controls.newPassword.setValue(val[1]);
        this.changePasswordForm.controls.newPassword.setValue(val[2]);
        return this.changePasswordForm.valid;
    }

    ngOnInit() {
        window.scrollTo(0, 0);
        this.activatedRoute.params.subscribe((id) => {
            this.adminMail = id.id;
        });
        
    }

    ngOnDestroy() {
        this.subscription.unsubscribe();
    }

    /** Function to verify google authentication */
    verifyGoogleAuth() {
        this.appC.google = { one: '', two: '', three: '', four: '', five: '', six: '' };
        this.appC.response = { message: '' };
        this.service.googleAuthCalledFrom = 'admin-change-password';
        $('#google-auth-modal').modal({ keyboard: false, backdrop: 'static' });

    }

    /** Function to change password */
    changePasswordFunc() {
        if (this.changePasswordForm.invalid) {
            return;
        }
        const data = {
            newPassword: this.service.encrypt(this.changePasswordForm.value.newPassword),
            ipAddress: this.service.encrypt(this.userIp.ip),
            location: this.service.encrypt(this.userIp.city + ', ' + this.userIp.country_name),
            email: this.service.encrypt(this.adminMail),
        };
        this.spinner.show();
        this.service.postMethod('account/superAdmin/user-management/change-admin-password', data, 1).subscribe((res) => {
            this.spinner.hide();
            if (res.status === 924) {
                this.success = res;
                this.showApiError = true;
                this.success.data = `Password of account ${this.adminMail} has been updated successfully.`;
                this.changePasswordForm.reset();
            } else {
                this.success = res;
                this.showApiError = true;
                this.success.data = res.message;
                this.spinner.hide();
                this.changePasswordForm.reset();
            }
        }, (err) => {
            this.changePasswordForm.reset();
            this.showApiError = true;
            this.success = err.error;
            this.success.data = err.error.message;
            this.spinner.hide();
        });
    }

}
