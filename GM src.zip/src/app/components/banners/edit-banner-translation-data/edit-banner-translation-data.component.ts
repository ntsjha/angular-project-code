import { ActivatedRoute, Router } from '@angular/router';
import { ServiceService } from './../../../service/service.service';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-edit-banner-translation-data',
  templateUrl: './edit-banner-translation-data.component.html',
  styleUrls: ['./edit-banner-translation-data.component.css']
})
export class EditBannerTranslationDataComponent implements OnInit {

  editBannerTranslationForm: FormGroup;
  apiResponse: any = { status: 200 };
  fileData: any = { valid: false };
  paramData: any;
  userInfo: any;
  selectedFileName: any;
  fileSelectedOrNot: any = false;
  pageName: any;

  constructor(
    private service: ServiceService,
    private activatedRoute: ActivatedRoute,
    private spinner: NgxSpinnerService,
    private router: Router
  ) { }

  ngOnInit() {
    window.scrollTo(0, 0);
    this.form();
    this.getUserInfo();
    this.getParamData();
  }

  getParamData() {
    this.activatedRoute.params.subscribe(success => {
      this.paramData = success;
      this.managePageNameValue(this.paramData.pageName);
      this.getBannerData();
    });
  }

  managePageNameValue(val) {
    switch (val) {
      case 'aboutUs': this.pageName = 'About Us';
        break;
      case 'termsCondition': this.pageName = 'Terms & Condittion';
        break;
      case 'privacyPolicy': this.pageName = 'Privacy Policy';
        break;
      case 'homePage': this.pageName = 'Home Page';
        break;
      case 'rewards': this.pageName = 'Rewards';
        break;
      case 'otc': this.pageName = 'OTC';
        break;
      case 'events': this.pageName = 'Events';
        break;
      case 'careers': this.pageName = 'Careers';
        break;
      case 'fees': this.pageName = 'Fees';
        break;
    }
  }

  getUserInfo() {
    this.service.userInfo.subscribe(success => {
      this.userInfo = success;
    });
  }

  getBannerData() {
    this.spinner.show();
    this.service.getMethod(`static/admin/get-banner-detail?bannerId=${encodeURIComponent(this.service.encrypt(this.paramData.id))}&language=${encodeURIComponent(this.service.encrypt(this.paramData.lang))}`, 1).subscribe((success: any) => {
      this.spinner.hide();
      if (success.status === 200) {
        this.editBannerTranslationForm.patchValue({
          bannerText: success.data.text
        });
        if (success.data.bannerImage) {
          this.fileData.fileData = success.data.bannerImage;
          this.selectedFileName = success.data.bannerImage;
          this.fileData.valid = true;
          this.fileData.url = success.data.bannerImage;
        }
      }
    }, error => {
      this.spinner.hide();
    });
  }

  form() {
    this.editBannerTranslationForm = new FormGroup({
      bannerText: new FormControl('', [Validators.required, Validators.minLength(2), Validators.maxLength(255)])
    });
  }

  editBannerTranslation() {
    this.spinner.show();
    if (this.editBannerTranslationForm.invalid || !this.fileData.valid || !this.fileData.url) {
      this.spinner.hide();
      return;
    }
    const apireq = JSON.stringify({
      pageName: this.paramData.pageName,
      pageNameValue: this.pageName,
      bannerImage: this.fileData.url,
      ipAddress: this.userInfo.ip,
      location: this.userInfo.city + ',' + this.userInfo.country_name,
      text: this.editBannerTranslationForm.value.bannerText
    });
    const formData = new FormData();
    formData.append('bannerDto', this.service.encrypt(apireq));
    formData.append('bannerId', this.service.encrypt(this.paramData.id));
    this.service.postMethod('static/admin/edit-banner-translation', formData, 2).subscribe(success => {
      this.spinner.hide();
      this.apiResponse = success;
      this.spinner.hide();
      if (success.status === 200) {
        this.router.navigate(['/translate-banner/' + this.paramData.contentId + '/' + this.paramData.pageName + '/en']);
      }
    }, error => {
      this.spinner.hide();
      this.apiResponse.status = error.error.status;
      this.apiResponse.message = error.error.error;
    });
  }

  getFile(event) {
    this.fileData = this.service.uploadImage(event);
    this.selectedFileName = this.fileData.fileData.name;
    if (this.selectedFileName) {
      this.fileSelectedOrNot = true;
    } else {
      this.fileSelectedOrNot = false;
    }
    if (this.fileData.error === 'formatError') {
      this.fileData.error = 'Image accept only jpg, jpeg, png format.';
    } else {
      if (this.fileData.error === 'sizeError') {
        this.fileData.error = 'Image size should be less than 5Mb.';
      }
    }
    if (this.fileData.valid) {
      this.uploadFile();
    }
  }

  uploadFile() {
    this.spinner.show();
    const formData = new FormData();
    formData.append('file', this.fileData.fileData);
    this.service.postMethod('account/uploadFile', formData, 2).subscribe(success => {
      this.spinner.hide();
      this.fileData.url = success.fileName;
    }, error => {
      this.spinner.hide();
      this.fileData.url = null;
    });
  }

}
