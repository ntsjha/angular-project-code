import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, AlertController } from 'ionic-angular';
import {Validators, FormBuilder, FormGroup, FormControl } from '@angular/forms';
import { HomePage } from '../home/home';
import { SignupPage } from '../signup/signup';
/**
 * Generated class for the LoginPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
})
export class LoginPage {

      
 
  submitted = false;
  
  loginForm = new FormGroup({
    email: new FormControl ('', [Validators.required,Validators.pattern(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/)]),
      password: new FormControl ('', [Validators.required,Validators.maxLength(16),
        Validators.pattern("^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$")])

       
  });
  item: any;
  match: any;
  password: any;
  

  constructor(public navCtrl: NavController, public navParams: NavParams, public formBuilder: FormBuilder, public alertController: AlertController) {
  }

  ionViewDidLoad() {
    this.item = JSON.parse(localStorage.getItem('teacher'));
    console.log(this.item);
  }
  get f() { return this.loginForm.controls; }

  async onSignIn() {
    this.submitted = true; 
      console.log(this.loginForm.value);
      console.log(this.f.email.value);
      
      for(let i=0;i<this.item.length;i++)
      {  
         
        console.log(this.item[i].email); 
        if(this.f.email.value==this.item[i].email)
        {
          
        
           this.match=this.item[i].email;
          this.password=this.item[i].password;

        }
      }
      if(this.f.email.value == this.match && this.f.password.value == this.password){
        sessionStorage.setItem('userid',JSON.stringify(this.f.email.value));
       
       
        this.navCtrl.push(HomePage);    
  
         }
      else{
        const alert = await this.alertController.create({
        
          message: 'Wrong Email or Password',
          buttons: ['OK']
        });
        await alert.present();
      } 


     
      
  }
   
  public register(){
   this.navCtrl.push(SignupPage);
   }
   public gotologin(){
    this.navCtrl.push(HomePage);
    }

}
