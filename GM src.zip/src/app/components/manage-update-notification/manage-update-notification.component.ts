import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ServiceService } from 'src/app/service/service.service';

@Component({
  selector: 'app-manage-update-notification',
  templateUrl: './manage-update-notification.component.html',
  styleUrls: ['./manage-update-notification.component.css']
})
export class ManageUpdateNotificationComponent implements OnInit {
  activityType: any;
  notificationData: any;
  contentId: any;
  notificationDataLangauge: any;
  notificationDataTransalation: any;
  thId: any;
  chId: any;
  enId: any;

  constructor(
    private service: ServiceService,
    private spinner: NgxSpinnerService,
    private activatedRoute: ActivatedRoute,
    private route: Router
  ) { }

  ngOnInit() {
    this.activatedRoute.params.subscribe(id => {
      this.activityType = id.id;
      this.contentId = id.id2;
    });
    this.notificationList();
    window.scrollTo(0, 0);
  }

  editPages(translationId, langaugeId) {
    this.route.navigate(['/edit-notification-translation/' + translationId + '/' + langaugeId]);
  }

  notificationList() {
    this.spinner.show();
    this.service.getMethod('notification-service/admin/get-manage-translation-templates?activityType=' + this.activityType + '&contentId=' + this.contentId, 1).subscribe((response: any) => {
      this.spinner.hide();
      if (response.status === 1610) {
        this.notificationData = response.data.notificationList;
        this.notificationDataLangauge = response.data.languageList.data;
        this.notificationDataTransalation = response.data.translationList;
        this.notificationDataTransalation.forEach(element => {
          if(element.updatedBy == null) {
            element.updatedAt = null;
          }
        });
        this.langauge();
      }
    }, (error) => {
      this.spinner.hide();

    });
    this.spinner.hide();
  }

  langauge() {
    this.notificationDataLangauge.forEach(element => {
      if (element.languageShortName === 'th') {
        this.thId = element.languageId;
      }
      if (element.languageShortName === 'ch') {
        this.chId = element.languageId;
      }
      if (element.languageShortName === 'en') {
        this.enId = element.languageId;
      }
    });
  }

  
}
