import {
    FormGroup,
    Validators,
    FormControl,
    FormArray,
    FormBuilder
  } from "@angular/forms";
  import { Component, OnInit, Inject } from "@angular/core";
  import { MainServiceService } from "src/app/main-service.service";
  import { Ng4LoadingSpinnerService } from "ng4-loading-spinner";
  import { Router } from "@angular/router";
  import { MatDialog, MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { EditProfileComponent } from "../edit-profile/edit-profile.component";
  
@Component({
    selector: 'add-petrol-pump-modal',
    templateUrl: 'add-petrol-pump-modal.component.html',
    styleUrls: ["./add-petrol-pump-modal.component.css"]
  })
  export class AddPetrolPumpModal implements OnInit {
    addPetrolForm: FormGroup;

    constructor(public service: MainServiceService,
        public spinner: Ng4LoadingSpinnerService,
        public router: Router,
        public fb: FormBuilder,
        @Inject(MAT_DIALOG_DATA) public data: EditProfileComponent,
        private dialogRef:MatDialogRef<EditProfileComponent>
        ) { }
  
    ngOnInit() {
      this.addPetrolPumpFormMethod();
    }
  
    addPetrolPumpFormMethod() {
      this.addPetrolForm = new FormGroup({
        petrolName: new FormControl("", [Validators.required]),
        petrolBrandName: new FormControl("", [Validators.required]),
        pinCode: new FormControl("", [Validators.required, Validators.pattern(/^[0-9]{6}?$/)]),
        address: new FormControl("", [Validators.required]),
        city: new FormControl("", [Validators.required]),
        ownerName: new FormControl("", [Validators.required]),
        mobileNumber: new FormControl("", [Validators.required]),
        state: new FormControl("", [Validators.required]),
        email: new FormControl("", [Validators.required, Validators.pattern(/^[a-z]+[a-z0-9._]+@[a-z]+\.[a-z.]{2,5}$/)]),
        landMark: new FormControl("", [Validators.required])
      });
    }

    get petrolName(): any {
        return this.addPetrolForm.get('petrolName');
    }
    get petrolBrandName(): any {
        return this.addPetrolForm.get('petrolBrandName');
    }
    get pinCode(): any {
        return this.addPetrolForm.get('pinCode');
    }
    get address(): any {
        return this.addPetrolForm.get('address');
    }
    get city(): any {
        return this.addPetrolForm.get('city');
    }
    get ownerName(): any {
        return this.addPetrolForm.get('ownerName');
    }
    get mobileNumber(): any {
        return this.addPetrolForm.get('mobileNumber');
    }
    get state(): any {
        return this.addPetrolForm.get('state');
    }
    get email(): any {
        return this.addPetrolForm.get('email');
    }
    get landMark(): any {
        return this.addPetrolForm.get('landMark');
    }

    // public hasError = (controlName: string, errorName: string) =>{
    //     return this.addPetrolForm.controls[controlName].hasError(errorName);
    //   }

    // add petrol method
    addPetrol() {
        this.dialogRef.close();
        let petrolPumpData = {
          petrolPumpName: this.addPetrolForm.value.petrolName,
          ownerName: this.addPetrolForm.value.ownerName,
          brandName: this.addPetrolForm.value.petrolBrandName,
          mobileNumber: this.addPetrolForm.value.mobileNumber,
          pinCode: this.addPetrolForm.value.pinCode,
          state: this.addPetrolForm.value.state,
          address: this.addPetrolForm.value.address,
          email: this.addPetrolForm.value.email,
          city: this.addPetrolForm.value.city,
          landmark: this.addPetrolForm.value.landMark
        };
        this.spinner.show();
        this.service.post("user/addPetrolPump", petrolPumpData, 1).subscribe(
          res => {
            if (res["responseCode"] == 200) {
              this.service.showSuccess(res["responseMessage"]);
              this.addPetrolForm.reset();
            } else {
            }
            this.spinner.hide();
          },
          error => {
            console.log(error);
          }
        );
    }
  }