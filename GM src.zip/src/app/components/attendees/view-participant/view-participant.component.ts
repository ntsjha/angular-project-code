import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ServiceService } from 'src/app/service/service.service';

@Component({
    selector: 'app-view-participant',
    templateUrl: './view-participant.component.html',
    styleUrls: ['./view-participant.component.css']
})
export class ViewParticipantComponent implements OnInit {

    paginationData: any = { limit: 10, currPage: 1, total: 0 };
    participantList: any = [];

    constructor(private activatedRoute: ActivatedRoute, private service: ServiceService) { }

    ngOnInit() {
        this.activatedRoute.params.subscribe(param => {
            this.getParticipantList(param.id);
        });
    }

    /** Function to get participant list */
    getParticipantList(id) {
        this.service.postMethod('event/admin/get-participants-list?registrationId='+encodeURIComponent(this.service.encrypt(id)), {}, 1).subscribe(success => {
            if (success.status === 1094) {
                this.participantList = success.data.participantsList;
            } else {
                this.participantList = [];
            }
        }, error => {
            this.participantList = [];
        });
    }

}
