export class Contributor{
    id: string;
    userName: string;
    email:any;
   
}
