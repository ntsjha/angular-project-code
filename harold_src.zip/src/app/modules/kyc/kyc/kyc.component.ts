import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ServerService } from '../../../server.service';
import { AppComponent } from '../../../app.component';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { Router } from '@angular/router';

@Component({
    selector: 'app-kyc',
    templateUrl: './kyc.component.html',
    styleUrls: ['./kyc.component.css']
})
export class KycComponent implements OnInit {

    view4: any;
    view3: any;
    view2: any;
    view1: any;
    imageDoc2back: any;
    kycstatus: any = '';
    kycone2Url: any;
    kyctwo2Url
    kyctwo1Url
    kyctab: any = 'kycList';
    kycData: any = []
    kycone1Url: any;
    imageDoc1fornt: any;
    imageDoc1back
    imageDoc2fornt
    kycDoc1: FormGroup;
    kycDoc2: FormGroup;
    kycReason: any;

    constructor(private server: ServerService, public appC: AppComponent, private spinnerService: Ng4LoadingSpinnerService, private router: Router) { }

    ngOnInit() {
        this.getKYCListFromAPI();
        this.checkInputs();
        this.checkInput();

    }

    /** To validate inputs fields */
    checkInputs() {
        this.kycDoc1 = new FormGroup({
            docName1: new FormControl('', [Validators.required, Validators.pattern(/^[a-zA-Z ]*$/i)]),
            docNum1: new FormControl('', [Validators.required]),
            docfront1: new FormControl('', [Validators.required]),
            docback1: new FormControl('', [Validators.required]),


        })
    }
    /** To validate inputs fields */
    checkInput() {
        this.kycDoc2 = new FormGroup({
            docName2: new FormControl('', [Validators.required, Validators.pattern(/^[a-zA-Z ]*$/i)]),
            docNum2: new FormControl('', [Validators.required]),
            docfront2: new FormControl('', [Validators.required]),
            docback2: new FormControl('', [Validators.required])
        })
    }

    // document upload 1 ////
    get docName1(): any {
        return this.kycDoc1.get('docName1');
    }
    get docNum1(): any {
        return this.kycDoc1.get('docNum1');
    }
    get docfront1(): any {
        return this.kycDoc1.get('docfront1');
    }
    get docback1(): any {
        return this.kycDoc1.get('docback1');
    }

    // document 2 ////

    get docName2(): any {
        return this.kycDoc2.get('docName2');
    }
    get docNum2(): any {
        return this.kycDoc2.get('docNum2');
    }
    get docfront2(): any {
        return this.kycDoc2.get('docfront2');
    }
    get docback2(): any {
        return this.kycDoc2.get('docback2');
    }

    selectTab(tab) {
        if (tab == "kycList") {
            this.kyctab = tab;
            this.getKYCListFromAPI();
        } else if (tab == "doc1") {
            if(this.kycstatus == 'PENDING') {
                this.appC.showInfoToast('Your KYC Document has been uploaded.');
                this.kyctab = "kycList";
            } else {
                this.kyctab = tab;
                this.clearForm();
                this.imageDoc2back = '';
                this.view1 = '';
                this.view2 = '';
                this.view3 = '';
                this.view4 = '';
            }
            
        }

    }

    cancel() {
        this.router.navigateByUrl('profile')
    }

    /** Function to clear KYC form  */
    clearForm() {
        this.kycDoc1.reset();
        this.kycDoc2.reset();

    }

    fileSelectdoc1($event): void {
        var self = this;
        // this.readThis($event.target);
        if ($event.target.files && $event.target.files[0]) {
            var fileType = $event.target.files[0].type
            var fileSize = $event.target.files[0].size;
            if(fileSize < 10000000){
                if (fileType === 'image/jpeg' || fileType === 'image/png' || fileType === 'image/jpg' || fileType === 'application/pdf') {
                    this.imageDoc1fornt = $event.target.files[0]
                    this.picphoto()
                    var reader = new FileReader()
                    this.view1 = $event.target.files[0].name;
                } else {
                    this.imageDoc1fornt = '';
                    this.view1 = '';
                    this.appC.showErrToast("Select only pdf and png, jpeg, jpg file");
                    $event.target.value = ''
                    return;
    
                }
            } else {
                this.imageDoc1fornt = ''
                this.appC.showErrToast("Please select file less than 10 MB.");
                $event.target.value = ''
                return;
            }
        }
    }
    readThis1(inputValue: any): void {
        var file: File = inputValue.files[0];
        var myReader: FileReader = new FileReader();
        myReader.onloadend = (e) => {
            this.imageDoc1fornt = myReader.result;
        }
        myReader.readAsDataURL(file);
    }

    picphoto() {

        let formData = new FormData();
        formData.append('file', this.imageDoc1fornt)

        //this.spinnerService.show();
        this.server.postApi('account/upload-file', formData).subscribe((res) => {
            this.spinnerService.hide();
            if (res.status == 200) {
                this.kycone1Url = res.data
            }
            else {
                this.spinnerService.hide();
                this.appC.showErrToast(res.message);
            }

        }, (err) => {
            this.spinnerService.hide();

            this.appC.showErrToast('Something went wrong')
        })
    }


    fileSelectdoc2($event): void {
        var self = this;
        // this.readThis($event.target);
        if ($event.target.files && $event.target.files[0]) {
            var fileType = $event.target.files[0].type;
            var fileSize = $event.target.files[0].size;
            if(fileSize < 10000000){
                if (fileType === 'image/jpeg' || fileType === 'image/png' || fileType === 'image/jpg' || fileType === 'application/pdf') {
                    this.imageDoc1back = $event.target.files[0]
                    this.picphoto2()
                    var reader = new FileReader()
                    this.view2 = $event.target.files[0].name
                    // reader.onload = (e) => {
                    //     self.kycDoc1.value.propic = e.target['result']
                    // }
                    // reader.readAsDataURL($event.target.files[0])
                } else {
                    this.appC.showErrToast("Select only pdf and png, jpeg, jpg file");
                    this.imageDoc1back = ""
                    $event.target.value = ''
                    return;
                
                    // self.editProfile['photo'];

                }
            } else {
                this.imageDoc1back = '';
                this.view2 = '';
                this.appC.showErrToast("Please select file less than 10 MB.");
                $event.target.value = ''
                return;
            }
        }
    }
    readThis(inputValue: any): void {
        var file: File = inputValue.files[0];
        var myReader: FileReader = new FileReader();
        myReader.onloadend = (e) => {
            this.imageDoc1back = myReader.result;
        }
        myReader.readAsDataURL(file);
    }

    picphoto2() {

        let formData = new FormData();
        formData.append('file', this.imageDoc1back)

        //this.spinnerService.show();
        this.server.postApi('account/upload-file', formData).subscribe((res) => {
            this.spinnerService.hide();
            if (res.status == 200) {
                this.kycone2Url = res.data
            }
            else {
                this.spinnerService.hide();
                this.appC.showErrToast(res.message);
            }

        }, (err) => {
            this.spinnerService.hide();
            this.appC.showErrToast('Something went wrong')
        })
    }


    fileSelectDocTwo1($event): void {
        var self = this;
        // this.readThis($event.target);
        if ($event.target.files && $event.target.files[0]) {
            var fileType = $event.target.files[0].type;
            var fileSize = $event.target.files[0].size;
            if(fileSize < 10000000){
                if (fileType === 'image/jpeg' || fileType === 'image/png' || fileType === 'image/jpg' || fileType === 'application/pdf') {
                    this.imageDoc2fornt = $event.target.files[0]
                    this.picphoto3()
                    var reader = new FileReader()
                    this.view3 = $event.target.files[0].name
                    // reader.onload = (e) => {
                    //     self.kycDoc2.value.docfront2 = e.target['result']
                    // }
                    // reader.readAsDataURL($event.target.files[0])
                } else {
                    this.imageDoc2fornt = '';
                    this.appC.showErrToast("Select only pdf and png, jpeg, jpg file");
                    $event.target.value = ''
                    return;
                    // self.editProfile['photo'];

                }
            } else {
                this.imageDoc2fornt = '';
                this.view3 = '';
                this.appC.showErrToast("Please select file less than 10 MB.");
                $event.target.value = ''
                return;
            }
        }
    }
    readThis2(inputValue: any): void {
        var file: File = inputValue.files[0];
        var myReader: FileReader = new FileReader();
        myReader.onloadend = (e) => {
            this.imageDoc2fornt = myReader.result;
        }
        myReader.readAsDataURL(file);
    }

    picphoto3() {

        let formData = new FormData();
        formData.append('file', this.imageDoc2fornt)

        // this.spinnerService.show();
        this.server.postApi('account/upload-file', formData).subscribe((res) => {
            this.spinnerService.hide();
            if (res.status == 200) {
                this.kyctwo1Url = res.data
            }
            else {
                this.spinnerService.hide();
                this.appC.showErrToast(res.message);
            }

        }, (err) => {
            this.spinnerService.hide();
            this.appC.showErrToast('Something went wrong')
        })
    }

    fileSelectDocTwo2($event): void {
        var self = this;
        // this.readThis($event.target);
        if ($event.target.files && $event.target.files[0]) {
            var fileType = $event.target.files[0].type;
            var fileSize = $event.target.files[0].size;
            if(fileSize < 10000000){
                if (fileType === 'image/jpeg' || fileType === 'image/png' || fileType === 'image/jpg' || fileType === 'application/pdf') {
                    this.imageDoc2back = $event.target.files[0];
                    this.picphoto4()
                    var reader = new FileReader();
                    this.view4 = $event.target.files[0].name;
                } else {
                    this.imageDoc2back = '';
                    this.appC.showErrToast("Select only pdf and png, jpeg, jpg file");
                    $event.target.value = '';
                    return;
                }
            } else {
                this.imageDoc2back = '';
                this.view3 = '';
                this.appC.showErrToast("Please select file less than 10 MB.");
                $event.target.value = ''
                return;
            }
        }
    }
    readThis4(inputValue: any): void {
        var file: File = inputValue.files[0];
        var myReader: FileReader = new FileReader();
        myReader.onloadend = (e) => {
            this.imageDoc2back = myReader.result;
        }
        myReader.readAsDataURL(file);
    }

    picphoto4() {

        let formData = new FormData();
        formData.append('file', this.imageDoc2back)

        // this.spinnerService.show();
        this.server.postApi('account/upload-file', formData).subscribe((res) => {
            this.spinnerService.hide();
            if (res.status == 200) {
                this.kyctwo2Url = res.data
            }
            else {
                this.spinnerService.hide();
                this.appC.showErrToast(res.message);
            }

        }, (err) => {
            this.spinnerService.hide();
            this.appC.showErrToast('Something went wrong')
        })
    }



    submitDoc() {
        if (this.kycDoc1.value.docName1 == "" || this.kycDoc1.value.docNum1 == "" 
        || this.kycDoc1.value.docfront1 == "" || this.kycDoc1.value.docback1  == ""
        || this.kycDoc2.value.docName2 == "" || this.kycDoc2.value.docNum2 == ""
        || this.kycDoc2.value.docfront2 == "" || this.kycDoc2.value.docback2 =="") {
           
            this.appC.showErrToast("Please update your kyc");
            return;
        }
        let data = {
            "document": [
                {
                  "name": this.kycDoc1.value.docName1,
                  "frontUrl":this.kycone1Url,
                  "backUrl":this.kycone2Url,
                  "number": this.kycDoc1.value.docNum1
                },
                {
                  "name":this.kycDoc2.value.docName2,
                  "frontUrl":this.kyctwo1Url,
                  "backUrl":this.kyctwo2Url,
                  "number": this.kycDoc2.value.docNum2
                }
              ]
        }
        this.spinnerService.show();
        this.server.postApi('account/save-kyc-details', data).subscribe((res) => {
            this.spinnerService.hide();
            if (res.status == 200) {
                this.appC.showSuccToast("Document uploaded successfully");
                this.kycDoc1.reset();
                this.kycDoc2.reset();
                this.view1 = '';
                this.view2 = '';
                this.view3 = '';
                this.view4 = '';
            }
            else {
                this.spinnerService.hide();
                this.appC.showErrToast(res.message);
            }

        }, (err) => {
            this.spinnerService.hide();
            this.appC.showErrToast('Something went wrong')
        })
    }

    getKYCListFromAPI() {
        this.spinnerService.show();
        this.server.getApi('account/get-kyc-details?userId=' + localStorage.getItem('token')).subscribe((res) => {
            this.spinnerService.hide();
            if (res.status == 200) {
                this.kycstatus = res.data[0].kycStatus;
                this.kycData = res.data[0].document;
                this.kycReason = res.data[0].reason;
            }
        }, (err) => {
            this.spinnerService.hide();
        });
        

    }

}




