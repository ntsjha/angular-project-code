import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CrmLeadsPage } from './crm-leads';

@NgModule({
  declarations: [
    CrmLeadsPage,
  ],
  imports: [
    IonicPageModule.forChild(CrmLeadsPage),
  ],
})
export class CrmLeadsPageModule {}
