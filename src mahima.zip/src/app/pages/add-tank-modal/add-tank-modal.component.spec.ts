import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddTankModalComponent } from './add-tank-modal.component';

describe('AddTankModalComponent', () => {
  let component: AddTankModalComponent;
  let fixture: ComponentFixture<AddTankModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddTankModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddTankModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
