import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateRewardSettingComponent } from './update-reward-setting.component';

describe('UpdateRewardSettingComponent', () => {
  let component: UpdateRewardSettingComponent;
  let fixture: ComponentFixture<UpdateRewardSettingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdateRewardSettingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateRewardSettingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
