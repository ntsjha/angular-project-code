import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddContributorManagementComponent } from './add-contributor-management.component';

describe('AddContributorManagementComponent', () => {
  let component: AddContributorManagementComponent;
  let fixture: ComponentFixture<AddContributorManagementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddContributorManagementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddContributorManagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
