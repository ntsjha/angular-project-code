import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageTransferExchangeWalletComponent } from './manage-transfer-exchange-wallet.component';

describe('ManageTransferExchangeWalletComponent', () => {
  let component: ManageTransferExchangeWalletComponent;
  let fixture: ComponentFixture<ManageTransferExchangeWalletComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManageTransferExchangeWalletComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageTransferExchangeWalletComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
