import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HeaderComponent } from './modules/header/header/header.component';
import { LoginComponent } from './modules/login/login/login.component';
import { SignupComponent } from './modules/signup/signup/signup.component';
import { ForgetpasswordComponent } from './modules/forgetpassword/forgetpassword/forgetpassword.component';
import { WalletComponent } from './modules/wallet/wallet/wallet.component';
import { TwofaComponent } from './modules/twofa/twofa/twofa.component';
import { ProfileComponent } from './modules/profile/profile/profile.component';
import { EmailverifyComponent } from './modules/emailverify/emailverify/emailverify.component';
import { PagenotfoundComponent } from './modules/pagenotfound/pagenotfound/pagenotfound.component';
import { HomeComponent } from './modules/home/home/home.component';
import { AboutusComponent } from './modules/aboutus/aboutus/aboutus.component';
import { PrivacypolicyComponent } from './modules/privacypolicy/privacypolicy/privacypolicy.component';
import { TermsconditionsComponent } from './modules/termsconditions/termsconditions/termsconditions.component';
import { FaqComponent } from './modules/faq/faq/faq.component';
import { SmsauthComponent } from './modules/smsauth/smsauth/smsauth.component';
import { TransactionDetailComponent } from './modules/transaction-detail/transaction-detail/transaction-detail.component';
import { ExchangeComponent } from './modules/exchange/exchange/exchange.component';
import { ResetComponent } from './modules/reset/reset/reset.component';
import { DepositComponent } from './modules/deposit/deposit/deposit.component';
import { WithdrawComponent } from './modules/withdraw/withdraw/withdraw.component';
import { FiathistoryComponent } from './modules/fiathistory/fiathistory/fiathistory.component';
import { OrderComponent } from './modules/order/order/order.component';
import { NewipdetectComponent } from './modules/newipdetect/newipdetect/newipdetect.component';
import { DashboardComponent } from './modules/dashboard/dashboard/dashboard.component';
import { PosttrdeComponent } from './modules/posttrde/posttrde/posttrde.component';
import { TraddetailComponent } from './modules/traddetail/traddetail/traddetail.component';
import { TradeactionComponent } from './modules/tradeaction/tradeaction/tradeaction.component';
import { TradelistComponent } from './modules/tradelist/tradelist/tradelist.component';
import { WithdrawverifyComponent } from './modules/withdrawverify/withdrawverify/withdrawverify.component';
import { UsdtransactionComponent } from './modules/usdtransaction/usdtransaction/usdtransaction.component';
import { ExchangepairComponent } from './modules/exchangepair/exchangepair/exchangepair.component';
import { ExchangeMicroServiceComponent } from './modules/exchange-micro-service/exchange-micro-service/exchange-micro-service.component';
import { GuardsGuard } from './modules/guards.guard';

const routes: Routes = [
  {path: '', redirectTo: 'header', pathMatch: 'full'},
  { path: 'header', component: HeaderComponent, 
        children: [            
            { path: '', component: HomeComponent},
            { path: 'login', component: LoginComponent},
            { path: 'signup', component: SignupComponent},
            { path: 'forgotpassword', component: ForgetpasswordComponent},
            { path: 'wallet', component:WalletComponent,canActivate:[GuardsGuard]},
            { path: 'twofa/:token', component:TwofaComponent},
            { path: 'profile', component:ProfileComponent, canActivate:[GuardsGuard]},
            { path: 'verify/:token', component:EmailverifyComponent},
            { path: 'reset', component:ResetComponent},
            { path: 'transactionDetail/:token', component:TransactionDetailComponent, canActivate:[GuardsGuard]},
            { path: 'aboutUs', component:AboutusComponent},
            { path: 'privacyPolicy', component:PrivacypolicyComponent},
            { path: 'termsConditions', component:TermsconditionsComponent},
            { path: 'faq', component:FaqComponent},
            { path: 'contactUs', component:SmsauthComponent},
            { path: 'exchange/:base/:exe', component:ExchangeMicroServiceComponent},
            { path: 'deposit', component:DepositComponent, canActivate: [GuardsGuard]},
            { path: 'withdraw', component:WithdrawComponent, canActivate: [GuardsGuard]},
            { path: 'fiathistory', component:FiathistoryComponent,canActivate:[GuardsGuard]},
            { path: 'order', component:OrderComponent, canActivate: [GuardsGuard]},
            { path: 'newIPDetect/:token', component:NewipdetectComponent},
            { path: 'dashboard', component:DashboardComponent, canActivate:[GuardsGuard]},
            { path: 'postTrade', component:PosttrdeComponent,canActivate: [GuardsGuard]},
            { path: 'exchange', component:ExchangeComponent},
            { path: 'tradeDetail', component:TraddetailComponent, canActivate: [GuardsGuard]},
            { path: 'tradeAction', component:TradeactionComponent, canActivate: [GuardsGuard]},
            { path: 'tradeList', component:TradelistComponent, canActivate: [GuardsGuard]},
            { path: 'TransactionDetail', component:UsdtransactionComponent, canActivate:[GuardsGuard]},
            { path: 'withdrawVerify/:token', component:WithdrawverifyComponent, canActivate:[GuardsGuard]},
            { path: 'exchange-pair', component:ExchangepairComponent},
            { path: '**', component: PagenotfoundComponent}
          
        ],
  },
  { path: '**', component: PagenotfoundComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
