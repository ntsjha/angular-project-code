import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FiatDepositReqComponent } from './fiat-deposit-req.component';

describe('FiatDepositReqComponent', () => {
  let component: FiatDepositReqComponent;
  let fixture: ComponentFixture<FiatDepositReqComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FiatDepositReqComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FiatDepositReqComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
