import { RewardTransactionComponent } from './components/reward/reward-transaction/reward-transaction.component';
import { AddPromotionComponent } from './components/promotion/add-promotion/add-promotion.component';
import { AddParticipantComponent } from './components/attendees/add-participant/add-participant.component';
import { AttendeesManagementComponent } from './components/attendees/attendees-management/attendees-management.component';
import { EditEventTranslationComponent } from './components/event/edit-event-translation/edit-event-translation.component';
import { EventtranslationListComponent } from './components/event/eventtranslation-list/eventtranslation-list.component';
import { EditEventComponent } from './components/event/edit-event/edit-event.component';
import { AddEventComponent } from './components/event/add-event/add-event.component';
import { EditBannerTranslationDataComponent } from './components/banners/edit-banner-translation-data/edit-banner-translation-data.component';
import { TranslateBannersComponent } from './components/banners/translate-banners/translate-banners.component';
import { ManageBannersComponent } from './components/banners/manage-banners/manage-banners.component';
import { ViewJobDetailComponent } from './components/job-and-applications/view-job-detail/view-job-detail.component';
import { JobTranslateListComponent } from './components/job-and-applications/job-translate-list/job-translate-list.component';
import { OfferManagementComponent } from './components/offer-management/offer-management.component';
import { PromotionManagementComponent } from './components/promotion-management/promotion-management.component';
import { EventManagementComponent } from './components/event-management/event-management.component';
import { ActivityLogComponent } from './components/activity-log/activity-log.component';
import { FAQComponent } from './components/faq/faq.component';
import { ManageCustomerComponent } from './components/manage-customer/manage-customer.component';
import { ManageStaffComponent } from './components/manage-staff/manage-staff.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { ResetPasswordComponent } from './components/reset-password/reset-password.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { ChangePasswordComponent } from './components/change-password/change-password.component';
import { ManageRolesComponent } from './components/manage-roles/manage-roles.component';
import { ManageAdminComponent } from './components/manage-admin/manage-admin.component';
import { LogsComponent } from './components/logs/logs.component';
import { AddRoleComponent } from './components/add-role/add-role.component';
import { EditRoleComponent } from './components/edit-role/edit-role.component';
import { EditAdminComponent } from './components/edit-admin/edit-admin.component';
import { ViewAdminComponent } from './components/view-admin/view-admin.component';
import { AddAdminComponent } from './components/add-admin/add-admin.component';
import { BeforeLoginGuard } from './before-login.guard';
import { AdminChangePasswordComponent } from './components/admin-change-password/admin-change-password.component';
import { RolesAndPermissionsComponent } from './components/roles-and-permissions/roles-and-permissions.component';
import { ManageApprovalsComponent } from './components/manage-approvals/manage-approvals.component';
import { TopicsComponent } from './components/topics/topics.component';
import { TransferHistoryComponent } from './components/transfer-history/transfer-history.component';
import { ViewStaffComponent } from './components/view-staff/view-staff.component';
import { EditStaffComponent } from './components/edit-staff/edit-staff.component';
import { AddStaffComponent } from './components/add-staff/add-staff.component';
import { PasswordChangeComponent } from './components/password-change/password-change.component';
import { ViewCustomerComponent } from './components/view-customer/view-customer.component';
import { ManageSiteContentComponent } from './components/manage-site-content/manage-site-content.component';
import { AboutUsComponent } from './components/about-us/about-us.component';
import { TermsAndContentComponent } from './components/terms-and-content/terms-and-content.component';
import { PrivacyPolicyComponent } from './components/privacy-policy/privacy-policy.component';
import { TranslationComponent } from './components/translation/translation.component';
import { SocialMediaLinkComponent } from './components/social-media-link/social-media-link.component';
import { EditTopicComponent } from './components/edit-topic/edit-topic.component';
import { AddEditFaqComponent } from './components/add-edit-faq/add-edit-faq.component';
import { TranslateFaqTopicComponent } from './components/translate-faq-topic/translate-faq-topic.component';
import { HomepageComponent } from './components/homepage/homepage.component';
import { ContactInfoComponent } from './components/contact-info/contact-info.component';
import { CountriesListComponent } from './components/countries-list/countries-list.component';
import { StateNameComponent } from './components/state-name/state-name.component';
import { BankListComponent } from './components/bank-list/bank-list.component';
import { AddEditBankComponent } from './components/add-edit-bank/add-edit-bank.component';
import { RewardsComponent } from './components/rewards/rewards.component';
import { SettingallComponent } from './components/settingall/settingall.component';
import { ExchangeFunctionComponent } from './components/exchange-function/exchange-function.component';
import { TwoFaComponent } from './components/two-fa/two-fa.component';
import { LiquidityComponent } from './components/liquidity/liquidity.component';
import { DeskoperatorsComponent } from './components/deskoperators/deskoperators.component';
import { TransactioncontrolComponent } from './components/transactioncontrol/transactioncontrol.component';
import { SupportTopicsComponent } from './components/support-topics/support-topics.component';
import { AlertSettingsComponent } from './components/alert-settings/alert-settings.component';
import { ManageTradingPairComponent } from './components/manage-trading-pair/manage-trading-pair.component';
import { MinimumTradingComponent } from './components/minimum-trading/minimum-trading.component';
import { MinimumTradingFeeComponent } from './components/minimum-trading-fee/minimum-trading-fee.component';
import { StandardTradingComponent } from './components/standard-trading/standard-trading.component';
import { StandardTradingFeeComponent } from './components/standard-trading-fee/standard-trading-fee.component';
import { MinimumWithdrawlComponent } from './components/minimum-withdrawl/minimum-withdrawl.component';
import { MinimumWithdrawlCryptoComponent } from './components/minimum-withdrawl-crypto/minimum-withdrawl-crypto.component';
import { MinimumWithdrawlFiatComponent } from './components/minimum-withdrawl-fiat/minimum-withdrawl-fiat.component';
import { StandardWithdrawlComponent } from './components/standard-withdrawl/standard-withdrawl.component';
import { StandardWithdrawlCryptoComponent } from './components/standard-withdrawl-crypto/standard-withdrawl-crypto.component';
import { StandardWithdrawlFiatComponent } from './components/standard-withdrawl-fiat/standard-withdrawl-fiat.component';
import { MinimumDepositComponent } from './components/minimum-deposit/minimum-deposit.component';
import { MinimumDepositCryptoComponent } from './components/minimum-deposit-crypto/minimum-deposit-crypto.component';
import { MinimumDepositFiatComponent } from './components/minimum-deposit-fiat/minimum-deposit-fiat.component';
import { StandardDepositComponent } from './components/standard-deposit/standard-deposit.component';
import { StandardDepositCryptoComponent } from './components/standard-deposit-crypto/standard-deposit-crypto.component';
import { StandardDepositFiatComponent } from './components/standard-deposit-fiat/standard-deposit-fiat.component';
import { RewardsSettingComponent } from './components/rewards-setting/rewards-setting.component';
import { ManageCoinsComponent } from './components/manage-coins/manage-coins.component';
import { ManageFeeComponent } from './components/manage-fee/manage-fee.component';
import { DailyClouserComponent } from './components/daily-clouser/daily-clouser.component';
import { SecComponent } from './components/sec/sec.component';
import { UpdateCoinComponent } from './components/update-coin/update-coin.component';
import { JobsComponent } from './components/job-and-applications/jobs/jobs.component';
import { AddJobComponent } from './components/job-and-applications/add-job/add-job.component';
import { JobApplicationComponent } from './components/job-and-applications/job-application/job-application.component';
import { BlogManagementComponent } from './components/blog/blog-management/blog-management.component';
import { EditJobComponent } from './components/job-and-applications/edit-job/edit-job.component';
import { AddJobTranslationComponent } from './components/job-and-applications/add-job-translation/add-job-translation.component';
import { ViewApplicationDetailComponent } from './components/job-and-applications/view-application-detail/view-application-detail.component';
import { AddBlogComponent } from './components/blog/add-blog/add-blog.component';
import { EditBlogComponent } from './components/blog/edit-blog/edit-blog.component';
import { BlogTranslationListComponent } from './components/blog/blog-translation-list/blog-translation-list.component';
import { WithdrawReqComponent } from './operational-components/withdraw-req/withdraw-req.component';
import { BasicDetailComponent } from './operational-components/basic-detail/basic-detail.component';
import { CompanyDetailComponent } from './operational-components/company-detail/company-detail.component';
import { BankDetailComponent } from './operational-components/bank-detail/bank-detail.component';
import { AddNewUserComponent } from './operational-components/add-new-user/add-new-user.component';
import { PlaceOrderComponent } from './operational-components/place-order/place-order.component';
import { SupportChatComponent } from './operational-components/support-chat/support-chat.component';
import { ViewHistoryComponent } from './operational-components/view-history/view-history.component';
import { TicketDetailsComponent } from './operational-components/ticket-details/ticket-details.component';
import { ReplyHistoryComponent } from './operational-components/reply-history/reply-history.component';
import { ManageCustomersComponent } from './operational-components/manage-customers/manage-customers.component';
import { TickesComponent } from './operational-components/tickes/tickes.component';
import { TicketReplyComponent } from './operational-components/ticket-reply/ticket-reply.component';
import { ReportDepositComponent } from './operational-components/report-deposit/report-deposit.component';
import { ReportWithdrawComponent } from './operational-components/report-withdraw/report-withdraw.component';
import { DepositReqDetailComponent } from './operational-components/deposit-req-detail/deposit-req-detail.component';
import { CryptoWithdrawlReqComponent } from './operational-components/crypto-withdrawl-req/crypto-withdrawl-req.component';
import { ManageExchangeWalletComponent } from './components/manage-exchange-wallet/manage-exchange-wallet.component';
import { ManageTransferExchangeWalletComponent } from './components/manage-transfer-exchange-wallet/manage-transfer-exchange-wallet.component';
import { ManageExchangeFeeWalletComponent } from './components/manage-exchange-fee-wallet/manage-exchange-fee-wallet.component';
import { ManageSettingExchangeFeeWalletComponent } from './components/manage-setting-exchange-fee-wallet/manage-setting-exchange-fee-wallet.component';
import { EditBlogTranslateComponent } from './components/blog/edit-blog-translate/edit-blog-translate.component';
import { ViewBlogDetailComponent } from './components/blog/view-blog-detail/view-blog-detail.component';
import { EditBannersComponent } from './components/banners/edit-banners/edit-banners.component';
import { ExportComponent } from './components/export/export.component';
import { AddScheduleComponent } from './components/add-schedule/add-schedule.component';
import { StaffLogComponent } from './components/staff-log/staff-log.component';
import { RewardsSettingSidebarComponent } from './components/rewards-setting-sidebar/rewards-setting-sidebar.component';
import { UpdateRewardSettingComponent } from './components/update-reward-setting/update-reward-setting.component';
import { MimimumWithdrawlCryptoSidebarComponent } from './components/mimimum-withdrawl-crypto-sidebar/mimimum-withdrawl-crypto-sidebar.component';
import { MimimumWithdrawlCryptoUpdateSidebarComponent } from './components/mimimum-withdrawl-crypto-update-sidebar/mimimum-withdrawl-crypto-update-sidebar.component';
import { MimimumWithdrawlFiatSidebarComponent } from './components/mimimum-withdrawl-fiat-sidebar/mimimum-withdrawl-fiat-sidebar.component';
import { MimimumWithdrawlFiatUpdateSidebarComponent } from './components/mimimum-withdrawl-fiat-update-sidebar/mimimum-withdrawl-fiat-update-sidebar.component';
import { ManageNotificationComponent } from './components/manage-notification/manage-notification.component';
import { FaqTranslationComponent } from './components/faq-translation/faq-translation.component';
import { ManageUpdateNotificationComponent } from './components/manage-update-notification/manage-update-notification.component';
import { ViewEventDetailsComponent } from './components/event/view-event-details/view-event-details.component';
import { AuthGuard } from './guard/auth.guard';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { PermissionGuardGuard } from './guard/permission-guard.guard';
import { AddOfferComponent } from './components/offer/add-offer/add-offer.component';
import { ReportFiatDepositComponent } from './operational-components/report-fiat-deposit/report-fiat-deposit.component';
import { ReportFiatWithdrawComponent } from './operational-components/report-fiat-withdraw/report-fiat-withdraw.component';
import { FiatDepositReqComponent } from './operational-components/fiat-deposit-req/fiat-deposit-req.component';
import { InquiriesComponent } from './operational-components/inquiries/inquiries.component';
import { ReportCommissionComponent } from './operational-components/report-commission/report-commission.component';
import { OtcCustomersComponent } from './operational-components/otc-customers/otc-customers.component';
import { ManageBankRegistrationComponent } from './operational-components/manage-bank-registration/manage-bank-registration.component';
import { DepositWithdrawTabComponent } from './operational-components/deposit-withdraw-tab/deposit-withdraw-tab.component';
import { MarketMakersComponent } from './operational-components/market-makers/market-makers.component';
import { FaResetDetailComponent } from './operational-components/fa-reset-detail/fa-reset-detail.component';
import { ParticularFaDetailComponent } from './operational-components/particular-fa-detail/particular-fa-detail.component';
import { EditExportComponent } from './components/edit-export/edit-export.component';
import { AddNewReqComponent } from './operational-components/add-new-req/add-new-req.component';
import { EditOfferComponent } from './components/offer/edit-offer/edit-offer.component';
import { OfferTranslationComponent } from './components/offer/offer-translation/offer-translation.component';
import { OfferTranslationListComponent } from './components/offer/offer-translation-list/offer-translation-list.component';
import { CustomerListComponent } from './components/reward/customer-list/customer-list.component';
import { EditNotificationTranslationComponent } from './components/edit-notification-translation/edit-notification-translation.component';
import { OperationKycComponent } from './operational-components/operation-kyc/operation-kyc.component';
import { CustomersKycComponent } from './operational-components/customers-kyc/customers-kyc.component';
import { KycComponent } from './components/kyc/kyc.component';
import { AddEditSupportTopicComponent } from './components/add-edit-support-topic/add-edit-support-topic.component';
import { AddSupportTopicComponent } from './components/add-support-topic/add-support-topic.component';
import { SupportTopicTranslationComponent } from './components/support-topic-translation/support-topic-translation.component';
import { SupportSubtopicComponent } from './components/support-subtopic/support-subtopic.component';
import { ManageSubtopicComponent } from './components/manage-subtopic/manage-subtopic.component';
import { ViewNotificationComponent } from './components/view-notification/view-notification.component';
import { ViewParticipantComponent } from './components/attendees/view-participant/view-participant.component';
import { ViewMaintenanceComponent } from './components/view-maintenance/view-maintenance.component';
import { ViewofferComponent } from './components/viewoffer/viewoffer.component';
import { OTCSettingComponent } from './components/otc-setting/otc-setting.component';
import { OTCPermotionComponent } from './components/otc-permotion/otc-permotion.component';
import { AddOTCPermotionComponent } from './components/OTC-section/add-otc-permotion/add-otc-permotion.component';
import { UpdateOTCSettingComponent } from './components/OTC-section/update-otc-setting/update-otc-setting.component';

const routes: Routes = [
    { path: '', redirectTo: 'login', pathMatch: 'full' },
    { path: 'login', component: LoginComponent, canActivate: [BeforeLoginGuard] },
    { path: 'reset-password', component: ResetPasswordComponent },
    {
        path: 'dashboard', component: DashboardComponent, canActivate: [AuthGuard],
        data: {
            menuName: 'dashboard'
        }
    },
    {
        path: 'admin-change-password/:id', component: AdminChangePasswordComponent, canActivate: [AuthGuard],
        data: {
            menuName: 'updateStaffPassword'
        }
    },
    {
        path: 'change-password', component: ChangePasswordComponent, canActivate: [AuthGuard],
        data: {
            menuName: 'updateStaffPassword'
        }

    },
    {
        path: 'manage-roles', component: ManageRolesComponent, canActivate: [AuthGuard],
        data: {
            menuName: 'manageRoles'
        }
    },
    {
        path: 'manage-administrator', component: ManageAdminComponent, canActivate: [AuthGuard],
        data: {
            menuName: 'manageAdmin'
        }
    },
    {
        path: 'logs', component: LogsComponent, canActivate: [AuthGuard],
        data: {
            menuName: 'logs'
        }
    },
    {
        path: 'add-role', component: AddRoleComponent, canActivate: [AuthGuard],
        data: {
            menuName: 'addRole'
        }
    },
    {
        path: 'edit-role/:id', component: EditRoleComponent, canActivate: [AuthGuard],
        data: {
            menuName: 'editRole'
        }
    },
    {
        path: 'edit-admin/:id', component: EditAdminComponent, canActivate: [AuthGuard],
        data: {
            menuName: 'editAdmin'
        }
    },
    {
        path: 'view-admin/:id', component: ViewAdminComponent, canActivate: [AuthGuard],
        data: {
            menuName: 'viewAdmin'
        }
    },
    {
        path: 'add-admin', component: AddAdminComponent, canActivate: [AuthGuard],
        data: {
            menuName: 'addAdmin'
        }
    },
    {
        path: 'jobs', component: JobsComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'careers'
        }
    },
    {
        path: 'add-job', component: AddJobComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'createJob'
        }
    },
    {
        path: 'job-application/:id', component: JobApplicationComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'viewJobApplications'
        }
    },
    {
        path: 'roles-and-permissions', component: RolesAndPermissionsComponent, canActivate: [AuthGuard],
        data: {
            menuName: 'rolesPermissions'
        }
    },
    {
        path: 'manage-approvals', component: ManageApprovalsComponent, canActivate: [AuthGuard],
        data: {
            menuName: 'manageApprovals'
        }
    },

    // anshul
    {
        path: 'manage-staff', component: ManageStaffComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'manageStaff'
        }
    },
    {
        path: 'manage-customer', component: ManageCustomerComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'manageCustomer'
        }
    },
    {
        path: 'transfer-history', component: TransferHistoryComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'transactionHistory'
        }
    },
    {
        path: 'activity-log', component: ActivityLogComponent, canActivate: [AuthGuard],
        data: {
            menuName: 'viewCustomerLog'
        }
    },
    {
        path: 'blog-management', component: BlogManagementComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'blogs'
        }
    },
    {
        path: 'event-management', component: EventManagementComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'events'
        }
    },
    {
        path: 'add-offer', component: AddOfferComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'createOffer'
        }
    },
    {
        path: 'edit-offer/:id', component: EditOfferComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'updateOffer'
        }
    },
    {
        path: 'translate-offer/:id/:translationId/:lang', component: OfferTranslationComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'updateOffer'
        }
    },
    {
        path: 'offer-translationList/:id', component: OfferTranslationListComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'updateOffer'
        }
    },
    {
        path: 'offer-management', component: OfferManagementComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'offers'
        }
    },
    {
        path: 'view-offer/:id', component: ViewofferComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'offers'
        }
    },
    {
        path: 'add-promotion', component: AddPromotionComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'createRewardPromotion'
        }
    },
    {
        path: 'promotion-management', component: PromotionManagementComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'rewardsPromotion'
        }
    },
    {
        path: 'reward-customer-list', component: CustomerListComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'rewardCustomerList'
        }
    },
    {
        path: 'reward-transaction', component: RewardTransactionComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'rewards'
        }
    },
    {
        path: 'add-job/:lang', component: AddJobComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'createJob'
        }
    },
    {
        path: 'edit-job/:id/:lang', component: EditJobComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'updateJob'
        }
    },
    {
        path: 'translate-job/:id', component: JobTranslateListComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'updateJob'
        }
    },
    {
        path: 'add-translate-job/:id/:translateId/:lang', component: AddJobTranslationComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'updateJob'
        }
    },
    {
        path: 'view-job-detail/:id/:lang', component: ViewJobDetailComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'viewJobDetails'
        }
    },
    {
        path: 'view-application-detail/:jobId/:applicationId', component: ViewApplicationDetailComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'viewJobApplications'
        }
    },
    {
        path: 'add-blog', component: AddBlogComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'createBlogs'
        }
    },
    {
        path: 'edit-blog/:id/:lang', component: EditBlogComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'updateBlogs'
        }
    },
    {
        path: 'blog-translate-list/:slug', component: BlogTranslationListComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'viewBlogs'
        }
    },
    {
        path: 'edit-blog-translate/:id/:slug/:lang', component: EditBlogTranslateComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'updateBlogs'
        }
    },
    {
        path: 'view-blog-translate/:id/:slug/:lang', component: ViewBlogDetailComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'viewBlogs'
        }
    },
    {
        path: 'manage-banners', component: ManageBannersComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'manageBanners'
        }
    },
    {
        path: 'edit-banner/:id/:pageName/:lang', component: EditBannersComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'manageBanners'
        }
    },
    {
        path: 'translate-banner/:id/:pageName/:lang', component: TranslateBannersComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'manageBanners'
        }
    },
    {
        path: 'edit-translate-banner/:contentId/:id/:pageName/:lang', component: EditBannerTranslationDataComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'manageBanners'
        }
    },
    {
        path: 'add-event', component: AddEventComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'addEventAttendees'
        }
    },
    {
        path: 'edit-event/:id/:lang', component: EditEventComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'events'
        }
    },
    {
        path: 'event-translationlist/:id', component: EventtranslationListComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'events'
        }
    },
    {
        path: 'edit-event-translate/:contentId/:translationId/:lang', component: EditEventTranslationComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'events'
        }
    },
    {
        path: 'view-event/:id/:lang', component: ViewEventDetailsComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'viewEventAttendees'
        }
    },
    {
        path: 'attendees-management/:id', component: AttendeesManagementComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'events'
        }
    },
    {
        path: 'view-participant/:id', component: ViewParticipantComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'events'
        }
    },
    {
        path: 'add-participant/:eventId', component: AddParticipantComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'addEventAttendees'
        }
    },
    // pragyansh
    {
        path: 'view-staff/:id', component: ViewStaffComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'viewStaffProfile'
        }
    },
    {
        path: 'edit-staff/:id', component: EditStaffComponent,
        data: {
            menuName: 'updateStaffProfile'
        }
    },
    {
        path: 'add-staff', component: AddStaffComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'createStaffProfile'
        }
    },
    {
        path: 'password-change/:id', component: PasswordChangeComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'updateStaffPassword'
        }
    },
    {
        path: 'view-customer/:id', component: ViewCustomerComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'viewCustomerProfile'
        }
    },
    {
        path: 'manage-site-content', component: ManageSiteContentComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'manageStaticContent'
        }
    },
    {
        path: 'about-us/:id1/:id2', component: AboutUsComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'manageStaticContent'
        }
    },
    {
        path: 'terms-and-content/:id1/:id2', component: TermsAndContentComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'manageStaticContent'
        }
    },
    {
        path: 'privacy-policy/:id1/:id2', component: PrivacyPolicyComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'manageStaticContent'
        }
    },
    {
        path: 'social-media-link/:id1/:id2', component: SocialMediaLinkComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'manageStaticContent'
        }
    },
    {
        path: 'homepage/:id1/:id2', component: HomepageComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'manageStaticContent'
        }
    },
    {
        path: 'contact-info/:id1/:id2', component: ContactInfoComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'updateContactInfo'
        }
    },
    {
        path: 'countries-list/:id1/:id2', component: CountriesListComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'manageStaticContent'
        }
    },
    {
        path: 'state-name/:id1/:id2', component: StateNameComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'manageStaticContent'
        }
    },
    {
        path: 'add-edit-bank/:id1', component: AddEditBankComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'manageStaticContent'
        }
    },
    {
        path: 'bank-list/:id1/:id2', component: BankListComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'manageStaticContent'
        }
    },
    {
        path: 'rewards/:id1/:id2', component: RewardsComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'manageStaticContent'
        }
    },
    {
        path: 'translation/:id', component: TranslationComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'manageStaticContent'
        }
    },
    {
        path: 'faq/:id1/:id2', component: FAQComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'manageStaticContent'
        }
    },
    {
        path: 'topics', component: TopicsComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'manageStaticContent'
        }
    },
    {
        path: 'manage-site-content', component: ManageSiteContentComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'manageStaticContent'
        }
    },
    {
        path: 'edit-topic/:id1/:id2/:id3', component: EditTopicComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'updateFaqTopic'
        }
    },
    {
        path: 'add-edit-faq/:id1/:id2/:id3', component: AddEditFaqComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'updateFaq'
        }
    },
    {
        path: 'translate-faq-topic/:id', component: TranslateFaqTopicComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'manageStaticContent'
        }
    },
    {
        path: 'settingall', component: SettingallComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'settings'
        }
    },
    {
        path: 'exchange-function', component: ExchangeFunctionComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'manageFunctionalControl'
        }
    },
    {
        path: 'two-fa', component: TwoFaComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'manage2Fa'
        }
    },
    {
        path: 'liquidity', component: LiquidityComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'manageLiquidityProvider'
        }
    },
    {
        path: 'support-topics/:id1/:id2', component: SupportTopicsComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'manageStaticContent'
        }
    },
    {
        path: 'alert-settings', component: AlertSettingsComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'manageComplainceAlerts'
        }
    },
    {
        path: 'manage-trading-pair', component: ManageTradingPairComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'manageTradingPairs'
        }
    },
    {
        path: 'faq-translation/:id', component: FaqTranslationComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'manageStaticContent'
        }
    },
    {
        path: 'manage-exchange-wallet', component: ManageExchangeWalletComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'exchangeWalletManagement'
        }
    },
    {
        path: 'manage-transfer-exchange-wallet/:id', component: ManageTransferExchangeWalletComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'updateSettings'
        }
    },
    {
        path: 'manage-exchange-fee-wallet', component: ManageExchangeFeeWalletComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'exchangeWalletManagement'
        }
    },
    {
        path: 'manage-setting-exchange-fee-wallet', component: ManageSettingExchangeFeeWalletComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'updateSettings'
        }
    },

    // Abhinav
    {
        path: 'alert-settings', component: AlertSettingsComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'manageComplainceAlerts'
        }
    },
    {
        path: 'manage-trading-pair', component: ManageTradingPairComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'manageTradingPairs'
        }
    },

    // Abhinav
    {
        path: 'deskoperators', component: DeskoperatorsComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'manageMaintenance'
        }
    },
    {
        path: 'view-maintenance/:id', component: ViewMaintenanceComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'manageMaintenance'
        }
    },
    {
        path: 'transactioncontrol', component: TransactioncontrolComponent,
        data: {
            menuName: 'manageTransactionalControlAndLimit'
        }
    },
    {
        path: 'minimum-trading', component: MinimumTradingComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'manageFees'
        }
    },
    {
        path: 'minimum-trading-fee', component: MinimumTradingFeeComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'manageFees'
        }
    },
    {
        path: 'standard-trading', component: StandardTradingComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'manageFees'
        }
    },
    {
        path: 'standard-trading-fee', component: StandardTradingFeeComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'manageFees'
        }
    },
    {
        path: 'minimum-withdrawl', component: MinimumWithdrawlComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'manageFees'
        }
    },
    {
        path: 'minimum-withdrawl-crypto/:id', component: MinimumWithdrawlCryptoComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'manageFees'
        }
    },
    {
        path: 'minimum-withdrawl-fiat/:id', component: MinimumWithdrawlFiatComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'manageFees'
        }
    },
    {
        path: 'standard-withdrawl', component: StandardWithdrawlComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'manageFees'
        }
    },
    {
        path: 'standard-withdrawl-crypto/:id', component: StandardWithdrawlCryptoComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'manageFees'
        }
    },
    {
        path: 'standard-withdrawl-fiat/:id', component: StandardWithdrawlFiatComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'manageFees'
        }
    },
    {
        path: 'minimum-deposit', component: MinimumDepositComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'manageFees'
        }
    },
    {
        path: 'minimum-deposit-crypto/:id', component: MinimumDepositCryptoComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'manageFees'
        }
    },
    {
        path: 'minimum-deposit-fiat/:id/:id2', component: MinimumDepositFiatComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'manageFees'
        }
    },
    {
        path: 'standard-deposit', component: StandardDepositComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'manageFees'
        }
    },
    {
        path: 'standard-deposit-crypto/:id', component: StandardDepositCryptoComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'manageFees'
        }
    },
    {
        path: 'standard-deposit-fiat/:id', component: StandardDepositFiatComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'manageFees'
        }
    },
    {
        path: 'rewardsSetting', component: RewardsSettingComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'rewardSettings'
        }
    },
    {
        path: 'manage-coins', component: ManageCoinsComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'manageCoins'
        }
    },
    {
        path: 'manage-fee', component: ManageFeeComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'manageFees'
        }
    },
    {
        path: 'daily-closure', component: DailyClouserComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'manageDailyClosureTime'
        }
    },
    {
        path: 'sec', component: SecComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'manageSecReportSetting'
        }
    },
    {
        path: 'update-coins/:id', component: UpdateCoinComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'manageCoins'
        }
    },
    {
        path: 'edit-notification-translation/:id/:id2', component: EditNotificationTranslationComponent // canActivate: [PermissionGuardGuard],
        // data: {
        //     menuName: 'manageCoins'
        // }
    },

    // operational by shaurya
    { path: 'withdraw-req/:id', component: WithdrawReqComponent },
    { path: 'cust-kyc-detail/:id/:kycId', component: BasicDetailComponent},
    { path: 'company-detail', component: CompanyDetailComponent }, // no work done , dont know its use(done by arvind)
    { path: 'bank-detail/:id/:userBankDetailId', component: BankDetailComponent}, // change tab
    { path: 'manage-customers', component: ManageCustomersComponent },
    { path: 'add-new-user', component: AddNewUserComponent },
    { path: 'support-chat', component: SupportChatComponent }, // in next phase
    {
        path: 'ticket-details/:id', component: TicketDetailsComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'manageSupport'
        }
    }, // done wid permission
    {
        path: 'ticket-reply/:id', component: TicketReplyComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'manageSupport'
        }
    },
    {
        path: 'reply-history/:id', component: ReplyHistoryComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'manageSupport'
        }
    }, // done(reply-history - api) wid permission
    {
        path: 'tickets', component: TickesComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'manageSupport'
        }
    }, // done wid permission
    {
        path: 'report-deposit', component: ReportDepositComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'depsositHistory'
        }
    }, // done (404 API ) wid permission
    {
        path: 'report-withdraw', component: ReportWithdrawComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'withdrawal'
        }
    }, // done wid permission
    {
        path: 'report-fiat-deposit', component: ReportFiatDepositComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'depsositHistory'
        }
    }, // done wid permission
    {
        path: 'report-fiat-withdraw', component: ReportFiatWithdrawComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'withdrawal'
        }
    }, // done wid permission
    { path: 'operation-kyc', component: OperationKycComponent},
    { path: 'customers-kyc', component: CustomersKycComponent}, // done  need to uncomment
    { path: 'deposit-req-detail/:id', component: DepositReqDetailComponent}, // done
    { path: 'deposit-req-detail/:id', component: DepositReqDetailComponent }, // done
    { path: 'crypto-withdrawl-req', component: CryptoWithdrawlReqComponent }, // fiat pending
    { path: 'fiat-withdrawl-req', component: CryptoWithdrawlReqComponent }, // done
    { path: 'fiat-deposit-req', component: FiatDepositReqComponent }, // done(appr - req api not made)
    {
        path: 'inquiries', component: InquiriesComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'manageSupport'
        }
    }, // done wid permission
    { path: 'activity-logs', component: ActivityLogComponent }, // inside components (done)
    { path: 'manage-bank-registration', component: ManageBankRegistrationComponent },  // arvind
    { path: 'deposit-withdraw-tab', component: DepositWithdrawTabComponent }, // done
    { path: 'fa-reset-detail', component: FaResetDetailComponent },
    { path: 'particular-fa-detail/:id/:resetId', component: ParticularFaDetailComponent },
    { path: 'market-makers', component: MarketMakersComponent }, // in next sprint
    { path: 'otc-customers', component: OtcCustomersComponent }, // in next sprint
    { path: 'add-new-req', component: AddNewReqComponent }, // in next sprint
    { path: 'place-order', component: PlaceOrderComponent }, // in next sprint
    { path: 'view-history', component: ViewHistoryComponent }, // in next phase
    { path: 'report-commission', component: ReportCommissionComponent }, // next sprint

    {
        path: 'manage-setting-exchange-fee-wallet/:id/:id2', component: ManageSettingExchangeFeeWalletComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'updateSettings'
        }
    },
    {
        path: 'export', component: ExportComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'exportSchedule'
        }
    },
    {
        path: 'add-schedule', component: AddScheduleComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'addSchedule'
        }
    },
    {
        path: 'edit-schedule/:id', component: EditExportComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'updateSchedule'
        }
    },
    {
        path: 'staff-log', component: StaffLogComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'viewStafflogs'
        }
    },
    {
        path: 'update-reward-setting', component: UpdateRewardSettingComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'updateDefaultRewardPoints'
        }
    },
    {
        path: 'mimimum-withdrawl-crypto-sidebar', component: MimimumWithdrawlCryptoSidebarComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'withdrawalSetting'
        }
    },
    {
        path: 'mimimum-withdrawl-crypto-update-sidebar/:id', component: MimimumWithdrawlCryptoUpdateSidebarComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'updateSettings'
        }
    },
    {
        path: 'mimimum-withdrawl-fiat-sidebar', component: MimimumWithdrawlFiatSidebarComponent,
        data: {
            menuName: 'withdrawalSetting'
        }
    },
    {
        path: 'mimimum-withdrawl-fiat-update-sidebar/:id', component: MimimumWithdrawlFiatUpdateSidebarComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'updateSettings'
        }
    },
    {
        path: 'manage-notification', component: ManageNotificationComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'manageNoitification'
        }
    },
    {
        path: 'manage-update-notification/:id/:id2', component: ManageUpdateNotificationComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'manageNoitification'
        }
    },

    // Pragyansh
 
    {
        path: 'add-edit-support-subtopic/:id1/:id2/:id3', component: AddEditSupportTopicComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'manageStaticContent'
        }
    },

    {
        path: 'add-support-topic/:id/:id2/:id3', component: AddSupportTopicComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'manageStaticContent'
        }
    },

    {
        path: 'support-topic-translation/:id', component: SupportTopicTranslationComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'manageStaticContent'
        }
    },

    {
        path: 'support-subtopic/:id', component: SupportSubtopicComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'manageStaticContent'
        }
    },

    {
        path: 'manage-subtopic/:id', component: ManageSubtopicComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'manageStaticContent'
        }
    },





    {
        path: 'kyc', component: KycComponent, canActivate: [PermissionGuardGuard],
        data: {
            // menuName: 'manageNoitification'
        }
    },
    {
        path: 'reward-setting-sidebar', component: RewardsSettingSidebarComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'rewards'
        }
    },
    {
        path: 'otc-setting', component: OTCSettingComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'rewards'
        }
    },
    {
        path: 'otc-promotion', component: OTCPermotionComponent, canActivate: [PermissionGuardGuard],
        data: {
            menuName: 'rewards'
        }
    },
    {
        path: 'add-otc-promotion', component: AddOTCPermotionComponent, canActivate: [PermissionGuardGuard],
        data: {
            // menuName: 'rewards'
        }
    },
    {
        path: 'update-otc-setting', component: UpdateOTCSettingComponent, canActivate: [PermissionGuardGuard],
        data: {
            // menuName: 'rewards'
        }
    },
    {path:'view-notification', component: ViewNotificationComponent },
    { path: '404.HTML', component: PageNotFoundComponent },
    { path: '**', component: PageNotFoundComponent },

];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class AppRoutingModule { }
