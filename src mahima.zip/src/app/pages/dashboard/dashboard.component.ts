import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { MediaMatcher } from '@angular/cdk/layout';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  
  content="This is just test";
  
  ngOnInit() {
  }
 data=[{name:'data1'},
 {name:'datafdsjfjkdsfjkdskjfdsjkfkdfdkfh'},
 {name:'data3'},
 {name:'data4'},
 {name:'data5'}
]

  mobileQuery: MediaQueryList;

  fillerNav = Array.from({length: 5}, (_, i) => `${this.data[i].name}`);


  private _mobileQueryListener: () => void;

  constructor(changeDetectorRef: ChangeDetectorRef, media: MediaMatcher) {
    this.mobileQuery = media.matchMedia('(max-width: 600px)');
    this._mobileQueryListener = () => changeDetectorRef.detectChanges();
    this.mobileQuery.addListener(this._mobileQueryListener);
  }

  ngOnDestroy(): void {
    this.mobileQuery.removeListener(this._mobileQueryListener);
  }

  
}
