export class Employee {
    id: string;
    fullName: string;
    email:any;
    empCode: string;
    position: string;
    mobile: string;
    plantype:any;
    EAnumber:any;
}
