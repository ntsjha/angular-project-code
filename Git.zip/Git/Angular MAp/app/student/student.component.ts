import { Component, OnInit, ViewChild } from '@angular/core';
import { ServeService } from '../serve.service';
import { GooglePlaceDirective } from 'ngx-google-places-autocomplete';
declare var google:any;
@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css']
})
export class StudentComponent implements OnInit {
  data: any;
  map: any;
  studata:any;
  @ViewChild("placesRef") placesRef : GooglePlaceDirective;   
  constructor(public serve: ServeService) { }

  ngOnInit() {

    this.data= (this.serve.studata);
    this.studata=this.serve.studata;
    console.log(this.studata);

   // console.log(this.Student[0].latitude,this.Student[0].longitude)

    this.initializeMap(this.studata.latitude,this.studata.longitude  )
    
  }

  initializeMap(Lattt,lnggg){
    console.log(Lattt,lnggg)
    var mapProp = {
        center:new google.maps.LatLng(Lattt,lnggg),
        zoom:5,
    };
    this.map = new google.maps.Map(document.getElementById("googleMap"),mapProp);
        // console.log(this.teacher[i].teacherlatlng.lat,this.teacher[i].teacherlatlng.lng);
      this.addMarker(Lattt,lnggg);
    }
    
     
   addMarker(Lattt,lnggg){
    //  console.log(lat1,lng1);
    var myLatLng = {lat:Lattt, lng:lnggg};
    var marker = new google.maps.Marker({
      position: myLatLng,
      map: this.map,
      title: 'Hello World!'
    });
    marker.setMap(this.map);
   }
 }
