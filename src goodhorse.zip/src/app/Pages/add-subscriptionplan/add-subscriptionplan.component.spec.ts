import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddSubscriptionplanComponent } from './add-subscriptionplan.component';

describe('AddSubscriptionplanComponent', () => {
  let component: AddSubscriptionplanComponent;
  let fixture: ComponentFixture<AddSubscriptionplanComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddSubscriptionplanComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddSubscriptionplanComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
