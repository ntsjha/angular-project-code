import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { TransactionStatusPage } from './transaction-status';

@NgModule({
  declarations: [
    TransactionStatusPage,
  ],
  imports: [
    IonicPageModule.forChild(TransactionStatusPage),
  ],
})
export class TransactionStatusPageModule {}
