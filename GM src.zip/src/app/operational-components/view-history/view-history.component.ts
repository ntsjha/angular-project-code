import { Component, OnInit } from '@angular/core';
import { ServiceService } from 'src/app/service/service.service';
import { IMyDpOptions, IMyDateModel } from 'mydatepicker';


@Component({
    selector: 'app-view-history',
    templateUrl: './view-history.component.html',
    styleUrls: ['./view-history.component.css']
})
export class ViewHistoryComponent implements OnInit {
    customerList: any;
    page: number=1;
    pageSize: any=10;
    customer: any='';
    obj: any={};
    replyHistory: any=[];
    totalItems: any=0;

    public fromPickerOptions: IMyDpOptions = {
        dateFormat: 'dd.mm.yyyy',
    };
    public toPickerOptions: IMyDpOptions = {
        dateFormat: 'dd.mm.yyyy',
    };
    constructor(public server:ServiceService) { }

    ngOnInit() {
        this.getCustomerList();
        this.getReplyHistory();
        window.scrollTo(0, 0);
    }
    getCustomerList() {
        this.server.getMethod('support/operation/get-customer-names',1).subscribe((res)=>{
            if(res['status'] == 1211) {
                this.customerList =   res['data']
            }
        })
    }

    onFromDateChanged(event: IMyDateModel) {
        let copy1 = this.getCopyOfOptions1();
        copy1.disableUntil = event.date
        this.toPickerOptions = copy1; 
    }

    changeCustomer(val) {
        
    }

    getCopyOfOptions1(): IMyDpOptions {
        return JSON.parse(JSON.stringify(this.toPickerOptions));
    }

    getCopyOfOptions2(): IMyDpOptions {
        return JSON.parse(JSON.stringify(this.fromPickerOptions));
    }
    
    onToDateChanged(event: IMyDateModel) {
        let copy1 = this.getCopyOfOptions2();
        copy1.disableSince = event.date
        this.fromPickerOptions = copy1;
    }

    getReplyHistory() {
        let data = {
            'page': this.page -1,
            'pageSize': this.pageSize,
        }

        if(this.customer){
            data['search'] = this.customer
        }
        if(this.obj.toDate && this.obj.fromDate) {
            data['fromDate'] = this.obj.fromDate.epoc;
            data['toDate'] = this.obj.toDate.epoc
        }
        this.server.postMethod('support/operation/get-enquiry-reply-history',data,1).subscribe((res)=>{
            if(res.status == 1200) {
                this.replyHistory = res.data.list;
                this.totalItems = res.data.size;
            }
        })
    }

    getSelectedCustomer(name) {
        this.customer = name
    }

    applyFilter() {
        if(this.customer) {
            this.page = 1;
            this.totalItems = 0;
            this.getReplyHistory();
        }
    }

    removeFilter() {
        this.page = 1;
        this.totalItems = 0;
        this.replyHistory = [];
        this.customer = '';
        this.fromPickerOptions = {
            disableSince: { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() + 1 },
            disableUntil: { year: 0, month: 0, day: 0 }
        };
        this.toPickerOptions = {
            disableSince: { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() + 1 },
            disableUntil: { year: 0, month: 0, day: 0 }
        };
        this.getReplyHistory();
    }

}
