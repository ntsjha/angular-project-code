import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ServerService } from '../../../service/server.service';
import { AppComponent } from '../../../app.component';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';

@Component({
    selector: 'app-smsauth',
    templateUrl: './smsauth.component.html',
    styleUrls: ['./smsauth.component.css']
})
export class SmsauthComponent implements OnInit {
    contactForm: FormGroup;

    constructor(private server: ServerService, private appC: AppComponent, private spinnerService: Ng4LoadingSpinnerService, public myService: ServerService) { }

    ngOnInit() {
        window.scrollTo(0,0);
        this.checkInputs();
    }

    /** Function to validate form inputs */
    checkInputs() {
      this.contactForm = new FormGroup ({
          email: new FormControl('', [Validators.required, Validators.pattern(/^[A-Z0-9_-]+([\.][A-Z0-9_]+)*@[A-Z0-9-]+(\.[a-zA-Z]{2,3})+$/i)]),
          name: new FormControl('', [Validators.required, Validators.pattern(/^[a-zA-Z ]*$/i)]),
          message: new FormControl('', [Validators.required]),
      });
    }

    /** to get the value of field  */
    get email(): any {
        return this.contactForm.get('email');
    }
    get name(): any {
        return this.contactForm.get('name');
    }
    get message(): any {
        return this.contactForm.get('message');
    }

    contactform() {
        let data = {
              "email":this.contactForm.value.email,
              "name":this.contactForm.value.name,
              "message":this.contactForm.value.message,
        }
        this.spinnerService.show();
        this.server.postApi('static/contact-us', data,0).subscribe(response => {
            this.spinnerService.hide();
            if (response.transferObjectMap.statusCode == 200) {
                this.appC.showSuccToast(response.transferObjectMap.message)
            } else {
                this.appC.showErrToast(response.transferObjectMap.message);
            }
        }, error => {
            this.spinnerService.hide();
            this.appC.showErrToast('Something went wrong');
        });
    }

}
