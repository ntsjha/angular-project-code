import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TranslateBannersComponent } from './translate-banners.component';

describe('TranslateBannersComponent', () => {
  let component: TranslateBannersComponent;
  let fixture: ComponentFixture<TranslateBannersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TranslateBannersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TranslateBannersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
