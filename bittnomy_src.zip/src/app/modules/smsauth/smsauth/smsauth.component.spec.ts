import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SmsauthComponent } from './smsauth.component';

describe('SmsauthComponent', () => {
  let component: SmsauthComponent;
  let fixture: ComponentFixture<SmsauthComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SmsauthComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SmsauthComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
