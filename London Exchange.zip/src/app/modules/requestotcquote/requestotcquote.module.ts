import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RequestotcquoteComponent } from './requestotcquote/requestotcquote.component';

@NgModule({
    imports: [
        CommonModule
    ],
    declarations: [RequestotcquoteComponent]
})
export class RequestotcquoteModule { }
