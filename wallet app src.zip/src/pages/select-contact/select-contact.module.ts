import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SelectContactPage } from './select-contact';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


@NgModule({
  declarations: [
    SelectContactPage,
  ],
  imports: [
    IonicPageModule.forChild(SelectContactPage),
    FormsModule,
    ReactiveFormsModule,
  ],
})
export class SelectContactPageModule {}
