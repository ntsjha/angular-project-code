import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { ServiceServicesProvider } from '../../providers/service-services/service-services';
import { AddBankPage } from '../add-bank/add-bank';

@IonicPage()
@Component({
  selector: 'page-bank-list',
  templateUrl: 'bank-list.html',
})
export class BankListPage {
  banks: any = [];
  selectedBank: any;
  usdAmount: any;

  constructor(public navCtrl: NavController, public navParams: NavParams, public service: ServiceServicesProvider) {
  }

  back() {
    this.navCtrl.pop();
  }

  ionViewWillEnter() {
    if (navigator.onLine) {
      this.getUsdAmount();
      this.service.presentLoading();
      let data = {
        "userId": localStorage.getItem('userId')
      }
      this.service.postApi(data, 'transaction/userBankAccounts', 0).subscribe(
        (response: any) => {
          this.service.dismissLoading();
          if (response[`response_code`] == 200) {
            this.banks = response.result;
          } else if (response[`response_code`] == 403 || response[`response_code`] == 409 || response[`response_code`] == 401) {
            this.service.presentToast(response[`response_message`])
            this.service.logout();
          } else {
            this.service.presentToast(response[`response_message`])
          }
        },
        err => {
          this.service.dismissLoading();
          this.service.presentToast('Something went wrong')
        }
      )
    } else
      this.service.presentToast('Your internet connection seems to be lost')
  }

  addBank() {
    this.navCtrl.push(AddBankPage)
  }

  getUsdAmount() {
    this.service.getExchangeRate(localStorage.countryCode).subscribe(
      (res: any) => {
        this.service.dismissLoading();
        if(res[`rates`]['USD'])
          this.usdAmount = res[`rates`]['USD']
        else {
          this.usdAmount = JSON.parse(localStorage.withdrawMoneyProcess).amount;
        }
      },
      err => {
        this.service.dismissLoading();
        this.usdAmount = JSON.parse(localStorage.withdrawMoneyProcess).amount;
      }
    );
  }

  withdraw() {
    console.log(this.selectedBank)
    // if (navigator.onLine) {
    //   let userId = localStorage.getItem('userId');
    //   this.service.presentLoading();
    //   let data = {
    //     "userId": localStorage.getItem('userId'),
    //     "amount": Number(JSON.parse(localStorage.withdrawMoneyProcess).amount),
    //     "usdAmount": Number(this.usdAmount),
    //     "transactionType": "WITHDRAW",
    //     "bankName": this.addBankForm.value.bankName,
    //     "branchName": this.addBankForm.value.branchName,
    //     "bankImage": this.bankPicture,
    //     "nickName": this.addBankForm.value.nickName,
    //     "holdersName": this.addBankForm.value.accountHolderName,
    //     "routingNumber": "110000000",
    //     "number": "000123456789" //this.addBankForm.value.accountNo
    //   }
    //   this.service.postApi(data, 'transaction/withdraw', 1).subscribe((response: any) => {
    //     this.service.dismissLoading();
    //     if (response.response_code == 200) {
    //       this.service.presentToast(response.response_message)
    //       this.navCtrl.setRoot(TabsPage, { selectedTab: 2 })
    //     } else if (response.response_code == 403 || response.response_code == 409 || response.response_code == 401) {
    //       this.service.presentToast(response.response_message)
    //       this.service.logout();
    //     }
    //     else {
    //       this.service.presentToast(response.response_message)
    //     }
    //   }, err => {
    //     this.service.dismissLoading();
    //     this.service.presentToast('Something went wrong')
    //   })
    // } else
    //   this.service.presentToast('Your internet connection seems to be lost')
  }

}
