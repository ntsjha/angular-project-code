declare var CanvasJS: any;

export class marketingGraphService {
    chart: any;
    chartData: any = [];
    jobChart: any = [];
    title = '';

    totalJobsData(data, chartId, point) {
        this.chartData = data;
        this.jobChart = [];
        if (this.chartData.length) {
            this.title = '';
            if (point === 1) {
                // Monthly Data
                this.chartData.forEach((element: any) => {
                    const obj = {
                        label: this.getMonthName(element.month),
                        y: this.getSumOfArray(element.data, point),
                    };
                    this.jobChart.push(obj);
                });
            } else if (point === 2) {
                // Weekly Data
                this.chartData.forEach((element: any, index) => {
                    const obj = {
                        label: this.getWeekDay(index),
                        y: this.getSumOfArray(element.perDateData, point),
                    };
                    this.jobChart.push(obj);
                });
            } else {
                // last 7 days
                this.chartData.forEach((element: any) => {
                    const obj = {
                        label: (this.getDateString(element.perDateData[0].date)),
                        y: this.getSumOfArray(element.perDateData, point),
                    };
                    this.jobChart.push(obj);
                });
            }
        } else {
            this.title = 'No data found';
            this.jobChart = [
                {
                    label: 'Jan',
                    y: 0,
                },
                {
                    label: 'Feb',
                    y: 0,
                },
                {
                    label: 'Mar',
                    y: 0,
                },
                {
                    label: 'Apr',
                    y: 0,
                },
                {
                    label: 'May',
                    y: 0,
                },
                {
                    label: 'June',
                    y: 0,
                },
                {
                    label: 'July',
                    y: 0,
                },
                {
                    label: 'Aug',
                    y: 0,
                },
                {
                    label: 'Sept',
                    y: 0,
                },
                {
                    label: 'Oct',
                    y: 0,
                },
                {
                    label: 'Nov',
                    y: 0,
                },
                {
                    label: 'Dec',
                    y: 0,
                },
            ];
        }
        if ( point === 2) {
            this.chart = new CanvasJS.Chart(chartId, {
                animationEnabled: true,
                exportEnabled: true,
                theme: 'light1',
                title: {
                    text: this.title,
                },
                data: [{
                    type: 'column',
                    indexLabelFontColor: '#5A5757',
                    indexLabelPlacement: 'outside',
                    dataPoints: this.jobChart,
                }]
            });
        } else {
            this.chart = new CanvasJS.Chart(chartId, {
                animationEnabled: true,
                exportEnabled: true,
                theme: 'light1',
                title: {
                    text: this.title,
                },
                axisX: {
                    interval: 1,
                },
                data: [{
                    type: 'column',
                    indexLabelFontColor: '#5A5757',
                    indexLabelPlacement: 'outside',
                    dataPoints: this.jobChart,
                }]
            });
        }
        return this.chart.render();
    }

    getMonthName(month) {
        let monthName = '';
        switch (month) {
            case 1: monthName = 'Jan';
                break;
            case 2: monthName = 'Feb';
                break;
            case 3: monthName = 'Mar';
                break;
            case 4: monthName = 'Apr';
                break;
            case 5: monthName = 'May';
                break;
            case 6: monthName = 'Jun';
                break;
            case 7: monthName = 'Jul';
                break;
            case 8: monthName = 'Aug';
                break;
            case 9: monthName = 'Sept';
                break;
            case 10: monthName = 'Oct';
                break;
            case 11: monthName = 'Nov';
                break;
            case 12: monthName = 'Dec';
                break;
        }
        return monthName;
    }

    getWeekDay(weekDay) {
        let weekDayName = '';
        switch (weekDay) {
            case 0: weekDayName = 'Monday';
                break;
            case 1: weekDayName = 'Tuesday';
                break;
            case 2: weekDayName = 'Wednesday';
                break;
            case 3: weekDayName = 'Thursday';
                break;
            case 4: weekDayName = 'Friday';
                break;
            case 5: weekDayName = 'Saturday';
                break;
            case 6: weekDayName = 'Sunday';
                break;
        }
        return weekDayName;
    }

    getSumOfArray(data, point) {
        let sum = 0;
        data.forEach(element => {
            if (point === 1) {
                sum = sum + element.finalPoint;
            } else {
                sum = sum + element.sum;
            }
        });
        return sum;
    }

    getDateString(date) {
        const dateStr = new Date(date);
        return dateStr.getDate() + '-' + (dateStr.getMonth() + 1) + '-' + dateStr.getFullYear();
    }

    destroyChart() {
        this.chart.destroy();
    }
}
