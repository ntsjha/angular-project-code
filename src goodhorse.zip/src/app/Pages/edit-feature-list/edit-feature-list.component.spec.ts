import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditFeatureListComponent } from './edit-feature-list.component';

describe('EditFeatureListComponent', () => {
  let component: EditFeatureListComponent;
  let fixture: ComponentFixture<EditFeatureListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditFeatureListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditFeatureListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
