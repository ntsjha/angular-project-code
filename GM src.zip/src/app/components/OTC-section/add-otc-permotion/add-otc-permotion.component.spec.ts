import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddOTCPermotionComponent } from './add-otc-permotion.component';

describe('AddOTCPermotionComponent', () => {
  let component: AddOTCPermotionComponent;
  let fixture: ComponentFixture<AddOTCPermotionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddOTCPermotionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddOTCPermotionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
