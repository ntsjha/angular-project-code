import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TranslateFaqTopicComponent } from './translate-faq-topic.component';

describe('TranslateFaqTopicComponent', () => {
  let component: TranslateFaqTopicComponent;
  let fixture: ComponentFixture<TranslateFaqTopicComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TranslateFaqTopicComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TranslateFaqTopicComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
