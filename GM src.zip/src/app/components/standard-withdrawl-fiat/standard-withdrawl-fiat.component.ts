import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { CookieService } from 'ngx-cookie-service';
import { ServiceService } from 'src/app/service/service.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-standard-withdrawl-fiat',
  templateUrl: './standard-withdrawl-fiat.component.html',
  styleUrls: ['./standard-withdrawl-fiat.component.css']
})
export class StandardWithdrawlFiatComponent implements OnInit {
  stdFiatDeposit: FormGroup;
  currentUser: any;
  coinName: any;
  depositeFiat: any;

  constructor(
    private cookie: CookieService,
    private service: ServiceService,
    private spinner: NgxSpinnerService,
    private activatedRoute: ActivatedRoute,
    private route: Router
  ) {
    this.stdFiatDeposit = new FormGroup({
      fixedFee: new FormControl(null, [Validators.required, Validators.maxLength(8), Validators.pattern(/^[1-9][0-9]*$/)]),
      extraFee: new FormControl(null, [Validators.required, Validators.maxLength(8), Validators.pattern(/^[1-9][0-9]*$/)]),
      forFirst: new FormControl(null, [Validators.required, Validators.maxLength(8), Validators.pattern(/^[1-9][0-9]*$/)]),
      per: new FormControl(null, [Validators.required, Validators.maxLength(8), Validators.pattern(/^[1-9][0-9]*$/)]),

    });


    this.service.currentUserInfo.subscribe((response) => {
      this.currentUser = response;
    });
  }

  ngOnInit() {
    this.activatedRoute.params.subscribe(id => {

      this.coinName = id.id;
    });
    this.stdDepositFiat();
    window.scrollTo(0, 0);
  }



  stdDepositFiat() {
    this.spinner.show();
    this.service.getMethod('wallet/admin/fees/get-fee-details?currencyName=' + this.coinName + '&currencyType=fiat', 1).subscribe((response: any) => {
      this.spinner.hide();
      if (response.status === 845 || response.status === 842) {
        this.depositeFiat = response.data;
        this.loadform();
      }
      this.depositeFiat = JSON.parse(this.service.decrypt(response.data)).data;
    }, (error) => {
      this.spinner.hide();
    });
    this.spinner.hide();

  }

  loadform() {
    this.stdFiatDeposit.patchValue({
      fixedFee: this.depositeFiat.stdWithdrawalFixedFee,
      extraFee: this.depositeFiat.minExtraFee,
      forFirst: this.depositeFiat.stdWithdrawalFixedFeeForFirst,
      per: this.depositeFiat.minExtraFeePer
    });
  }


  depositFiat() {
    this.spinner.show();
    const data = {
      coinName: this.coinName,
      extraFee: this.stdFiatDeposit.value.extraFee,
      extraFeePer: this.stdFiatDeposit.value.per,
      fixedFee: this.stdFiatDeposit.value.fixedFee,
      fixedFeeForFirst: this.stdFiatDeposit.value.forFirst,
      ipAddress: this.currentUser.ip,
      location: this.currentUser.city + ', ' + this.currentUser.country_name
    };

    this.service.postMethod('wallet/admin/fees/set-std-fiat-withdraw-fee', data, 1).subscribe((response: any) => {
      this.spinner.hide();
      if (response.status === 842) {
        this.route.navigate(['/standard-withdrawl']);
      }
    }, (error) => {
      this.spinner.hide();
    });
  }
}
