import { Component, OnInit } from '@angular/core';
import { ServiceService } from 'src/app/service/service.service';
import { FormBuilder, Validators, FormArray } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
    selector: 'app-place-order',
    templateUrl: './place-order.component.html',
    styleUrls: ['./place-order.component.css']
})
export class PlaceOrderComponent implements OnInit {
    form: any;

    constructor(public fb: FormBuilder, public server:ServiceService,private router:Router){ }

    ngOnInit() {
        window.scrollTo(0, 0);
        this.initialiseForm();
    }


    initialiseForm() {
        this.form = this.fb.group({
        'mainArr': this.fb.array([
            this.initMainForm()
        ])
        });
    }

    initMainForm() {
        return this.fb.group({
        'select_pair': ['', [Validators.required]],
        'trade_type': ['', [Validators.required]],
        'side': ['', [Validators.required]],
        'price': ['', [Validators.required]],
        'amount': ['', [Validators.required]],
        'total': ['', [Validators.required]],  
        'reward_points': ['', [Validators.required]] 
        });
    }

    add_MainForm() {
        const control = <FormArray>this.form.controls['mainArr'];
        control.push(this.initMainForm());
    }

    submitForm() {
        this.form.controls.mainArr['controls'].forEach(element => {
            let data = {
                "limitPrice": element.value.price,
                "orderSide": element.value.side,
                "orderType": element.value.trade_type,
                "quantity": element.value.amount,
                "symbol": element.value.select_pair,
                "useMyReward": element.value.reward_points
            };
        });
    }

    toCheckSpaceChar(evt) {
        var charCode = (evt.which) ? evt.which : evt.keyCode;
        if((charCode == 32) || (charCode > 64 && charCode < 91) || (charCode > 96 && charCode < 123)) {
            evt.preventDefault();
        }else {
            return true;
        }
    }

    getCoinPairList() {
        
    }
}
