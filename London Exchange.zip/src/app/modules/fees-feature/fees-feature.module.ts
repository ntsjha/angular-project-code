import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FeesFeatureComponent } from './fees-feature/fees-feature.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [FeesFeatureComponent]
})
export class FeesFeatureModule { }
