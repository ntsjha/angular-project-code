import { Component, OnInit } from '@angular/core';
import { ServiceService } from 'src/app/service/service.service';
import { ActivatedRoute, Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-translation',
  templateUrl: './translation.component.html',
  styleUrls: ['./translation.component.css']
})
export class TranslationComponent implements OnInit {
  pageToTranslate: string;
  pageToNavigate: string;
  api = '';
  apiEng = '';
  translateThai: any = {};
  translateChai: any = {};
  engLangObj: any = {};
  aboutUsId: string;
  thaiLangId: any;
  chaiLangId: any;
  enLangId: any;
  selectedID: any;
  pageName: any;
  constructor(private service: ServiceService, private activatedRoutes: ActivatedRoute, private router: Router, private spinner: NgxSpinnerService) {
  }

  ngOnInit() {
    this.activatedRoutes.params.subscribe((data) => {
      this.pageToTranslate = data.id;
      this.pageToTranslatePage();
    });
    window.scrollTo(0, 0);
  }

  pageToTranslatePage() {
    switch ((this.pageToTranslate).toLowerCase()) {
      case 'about-us':
        this.api = 'static/admin/get-aboutus-page-translation';
        this.pageName = 'About Us';
        this.pageToNavigate = 'about-us';
        this.getAboutUsTranslation();
        this.getAboutUsEng();
        break;
      case 'terms-and-content':
        this.api = 'static/view-terms-and-condition';
        this.pageToNavigate = 'terms-and-content';
        this.pageName = 'Terms & Condition';
        this.getTermsNCondition();
        this.getEngTermsCond();
        break;
      case 'privacy-policy':
        this.api = 'static/get-privacypolicy-translation';
        this.pageToNavigate = 'privacy-policy';
        this.pageName = 'Privacy Policy';
        this.getPrivacyPolicy();
        this.getPrivacyPolicyEng();
        break;
      case 'otc':
        break;
      case 'rewards':
        this.api = 'rewards/admin/get-reward-content-data';
        this.pageToNavigate = 'rewards';
        this.pageName = 'Rewards';
        this.getRewardTranslation();
        break;
      case 'homepage':
        this.api = 'static/admin/get-homepage-translation';
        this.pageToNavigate = 'homepage';
        this.pageName = 'Homepage';
        this.getTranslationHomepage();
        this.getHomepage();
        break;
      case 'faq':
        break;
      case 'contact-info':
        this.api = 'static/get-ContactUs-List';
        this.pageToNavigate = 'contact-info';
        this.pageName = 'Contact Info';
        this.getContactInfo();
        break;
      case 'support topics':
        break;
    }
  }

  editPage(lang) {
    this.router.navigate(['/' + this.pageToNavigate + '/edit/' + lang]);
  }

  addPage(lang) {
    this.router.navigate(['/' + this.pageToNavigate + '/add/' + lang]);
  }

  getThaiAndChaiTranslation(response) {
    const langList = response.data.languageList.data;
    langList.forEach(element => {
      if (element.languageShortName === 'th') {
        this.thaiLangId = element.languageId;
      } else if (element.languageShortName === 'ch') {
        this.chaiLangId = element.languageId;
      } else {
        this.enLangId = element.languageId;
      }
    });
    const translationData = response.data.translationList;
    translationData.forEach(element => {
      if (element.fkLanguageId === this.thaiLangId) {
        this.translateThai = element;
        if(this.translateThai.updatedBy == null) {
          this.translateThai.updatedAt = null;
        }
      }
      if (element.fkLanguageId === this.chaiLangId) {
        this.translateChai = element;
        if(this.translateThai.updatedBy == null) {
          this.translateThai.updatedAt = null;
        }
      }
      if (element.fkLanguageId === this.enLangId) {
        this.engLangObj = element;
         if(this.engLangObj.updatedBy == null) {
          this.engLangObj.updatedAt = null;
        }
      }
    });
  }

  getAboutUsTranslation() {
    this.spinner.show();
    this.service.postMethod(this.api + '?language=' + encodeURIComponent(this.service.encrypt('th')), {}, 1)
      .subscribe((response) => {
        this.translateThai = response.data.aboutUsTranslation[0];
        if(this.translateThai.updatedBy == null) {
          this.translateThai.updatedAt = null;
        }
        this.spinner.hide();
      }, (err) => {
        this.spinner.hide();
      });
    this.service.postMethod(this.api + '?language=' + encodeURIComponent(this.service.encrypt('ch')), {}, 1)
      .subscribe((response) => {
        this.translateChai = response.data.aboutUsTranslation[0];
        if(this.translateThai.updatedBy == null) {
          this.translateThai.updatedAt = null;
        }
        this.spinner.hide();
      }, (error) => {
        this.spinner.hide();
      });
  }

  getTermsNCondition() {
    this.spinner.show();
    this.service.postMethod('static/admin/view-terms-and-condition', {}, 1)
      .subscribe((response) => {
        this.spinner.hide();
        if (response.status === 676) {
          this.selectedID = response.data[0].termsNConditionId;
          this.termsTrasnlation();
        }
      }, (err) => {
        this.spinner.hide();
      });
  }

  termsTrasnlation() {
    this.spinner.show();
    this.service.postMethod('static/admin/get-terms-and-condition-translation?termsNConditionId=' + encodeURIComponent(this.service.encrypt(this.selectedID)), {}, 1)
      .subscribe((response) => {
        this.spinner.hide();
        this.getThaiAndChaiTranslation(response);
      }, (err) => {
        this.spinner.hide();
      });
  }

  getPrivacyPolicy() {
    this.spinner.show();
    this.service.postMethod('static/admin/get-PrivacyPolicy-List', {}, 1)
      .subscribe((response) => {
        this.spinner.hide();
        if (response.status === 1063) {
          this.selectedID = response.data[0].privacyPolicyId;
          this.privacyTranslation();
        }
      }, (err) => {
        this.spinner.hide();
      });
  }

  privacyTranslation() {
    this.spinner.show();
    this.service.postMethod('static/admin/get-privacypolicy-translation?privacyPolicyId=' + encodeURIComponent(this.service.encrypt(this.selectedID)), {}, 1)
      .subscribe((response) => {
        this.spinner.hide();
        this.getThaiAndChaiTranslation(response);
      }, (err) => {
        this.spinner.hide();
      });
  }

  getTranslation() {
    this.spinner.show();
    this.service.postMethod(this.api + '?language=' + encodeURIComponent(this.service.encrypt('th')), {}, 1)
      .subscribe((response) => {
        this.translateThai = response.data.aboutUsTranslation;
        this.spinner.hide();
      }, (err) => {
        this.spinner.hide();
      });
    this.service.postMethod(this.api + '?language=' + encodeURIComponent(this.service.encrypt('ch')), {}, 1)
      .subscribe((response) => {
        this.translateChai = response.data.aboutUsTranslation;
        this.spinner.hide();
      }, (error) => {
        this.spinner.hide();
      });
  }

  getRewardTranslation() {
    this.spinner.show();
    this.service.getMethod(this.api, 1)
      .subscribe((response: any) => {
        if (response.status === 1322) {
          this.engLangObj = response.data.englishData.length ? response.data.englishData[0] : {};
          this.translateThai = response.data.otherLanguageData.length ? this.filterByLanguageId(response.data.otherLanguageData, 2) : {};
          this.translateChai = response.data.otherLanguageData.length ? this.filterByLanguageId(response.data.otherLanguageData, 3) : {};
        }
        this.spinner.hide();
      }, (err) => {
        this.spinner.hide();
      });
  }

  filterByLanguageId(data, id) {
    const filteredData = data.filter(item => item.languageId == id);
    return filteredData.length ? filteredData[0] : {};
  }

  getAboutUsEng() {
    this.spinner.show();
    this.service.postMethod('static/admin/getAllAboutUsData?languageShortName=' + encodeURIComponent(this.service.encrypt('en')), {}, 1)
      .subscribe((response) => {
        this.spinner.hide();
        this.engLangObj = response.data[0].aboutUs[0];
      }, (error) => {
        this.spinner.hide();
      });
  }

  getEngTermsCond() {
    this.spinner.show();
    this.service.postMethod('static/admin/view-terms-and-condition', {}, 1)
      .subscribe((response) => {
        this.spinner.hide();
        if (response.status === 676) {
          this.engLangObj = response.data[0];
        }
      }, (error) => {
        this.spinner.hide();
      });
  }

  getPrivacyPolicyEng() {
    this.spinner.show();
    this.service.postMethod('static/admin/get-PrivacyPolicy-List', {}, 1)
      .subscribe((response) => {
        this.spinner.hide();
        this.engLangObj = response.data[0];
      }, (error) => {
        this.spinner.hide();
      });
  }

  getTranslationHomepage() {
    this.spinner.show();
    this.service.postMethod(this.api + '?language=' + encodeURIComponent(this.service.encrypt('th')), {}, 1)
      .subscribe((response) => {
        this.translateThai = response.data.flashMessageTranslation[0];
        this.spinner.hide();
      }, (err) => {
        this.spinner.hide();
      });
    this.service.postMethod(this.api + '?language=' + encodeURIComponent(this.service.encrypt('ch')), {}, 1)
      .subscribe((response) => {
        this.translateChai = response.data.flashMessageTranslation[0];
        this.spinner.hide();
      }, (error) => {
        this.spinner.hide();
      });
  }
  getHomepage() {
    this.spinner.show();
    this.service.postMethod('static/admin/get-flash-message-content/?languageShortName=' + encodeURIComponent(this.service.encrypt('en')), {}, 1)
      .subscribe((response) => {
        this.engLangObj = response.data[0];
      }, (error) => {
        this.spinner.hide();
      });
  }

  getContactInfo() {
    this.spinner.show();
    this.service.postMethod(this.api + '?languageName=' + encodeURIComponent(this.service.encrypt('en')), {}, 1)
      .subscribe((response) => {
        this.spinner.hide();
        this.engLangObj = response.data[0];
      }, (err) => {
        this.spinner.hide();
      });
    this.service.postMethod(this.api + '?languageName=' + encodeURIComponent(this.service.encrypt('th')), {}, 1)
      .subscribe((response) => {
        this.spinner.hide();
        this.translateThai = response.data[0];
      }, (err) => {
        this.spinner.hide();
      });
    this.service.postMethod(this.api + '?languageName=' + encodeURIComponent(this.service.encrypt('ch')), {}, 1)
      .subscribe((response) => {
        this.spinner.hide();
        this.translateChai = response.data[0];
      }, (error) => {
        this.spinner.hide();
      });
  }
}
