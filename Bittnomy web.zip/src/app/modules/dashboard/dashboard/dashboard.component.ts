import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppComponent } from '../../../app.component';
import { ServerService } from '../../../service/server.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { HeaderComponent } from '../../header/header/header.component';

@Component({
    selector: 'app-dashboard',
    templateUrl: './dashboard.component.html',
    styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
    openTradesArr = [{orderId:"3e3deed", orderTime: Date.now(), orderStatus:"PENDING", coinShortName:"BCT", originalType:"BUY", pay_method:"Cash", trading_partner:"Smith", amount:"2", price:"6500", fiatShortName:"USD"}];
    advertismentArr = [];
    completedTradesArr = [];
    
    constructor(private router: Router, private appC: AppComponent, private server: ServerService, private spinnerService: Ng4LoadingSpinnerService, public header: HeaderComponent) { }

    ngOnInit() {
        window.scrollTo(0, 0);
    }

    /** Function for go to trade details page */
    goToDetail(obj) {
        this.router.navigateByUrl("header/tradeDetail");
    }
}
