import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ServiceService } from 'src/app/service/service.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { Router } from '@angular/router';
import { DatePipe } from '@angular/common';
import { CookieService } from 'ngx-cookie-service';
import { AppComponent } from 'src/app/app.component';

declare var $: any;

@Component({
  selector: 'app-add-new-user',
  templateUrl: './add-new-user.component.html',
  styleUrls: ['./add-new-user.component.css']
})
export class AddNewUserComponent implements OnInit, OnDestroy {
  addNewuser: FormGroup;
  userdata: any;
  userIp: any;
  showApiMessage: boolean;
  response: any;
  model_phone_number: '';
  subscription: any;

  constructor(private cookie: CookieService, private service: ServiceService, private spinner: NgxSpinnerService, private router: Router, public datepipe: DatePipe, private appC: AppComponent) {
    this.subscription = this.service.authVerify.subscribe(val => {
      if (val == 'add-new-user') {
        this.createUser();
        this.service.authVerify.next('false');
      }
    });
  }

  ngOnInit() {

    this.addNewuser = new FormGroup({
      usertype: new FormControl('INDIVIDUAL', [Validators.required]),
      email: new FormControl('', [Validators.required, Validators.pattern(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,3}))$/), Validators.maxLength(256)]),
    });
    this.userIp = (this.cookie.get('userInfo')) ? JSON.parse(this.cookie.get('userInfo')) : this.service.initialUserInfo;
    window.scrollTo(0, 0);
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  get email(): any {
    return this.addNewuser.get('email');
  }

  get phone(): any {
    return this.addNewuser.get('phoneNumber');
  }

  get usertype(): any {
    return this.addNewuser.get('usertype');
  }

  /** Function to verify google authentication */
  verifyGoogleAuth() {
    this.appC.google = { one: '', two: '', three: '', four: '', five: '', six: '' };
    this.appC.response = { message: '' };
    this.service.googleAuthCalledFrom = 'add-new-user';
    $('#google-auth-modal').modal({ keyboard: false, backdrop: 'static' });

  }


  createUser() {
    const data = {
      email: this.addNewuser.value.email,
      ipAddress: this.userIp.ip,
      location: this.userIp.city + ',' + this.userIp.country_name,
      phoneNo: this.model_phone_number,
      userType: this.addNewuser.value.usertype
    }
    const enc = this.service.encrypt('EN');
    this.service.postMethod('account/admin/create-customer?languageCode=' + encodeURIComponent(enc), data, 1)
      .subscribe((response) => {
        if (response.status == 912) {
          this.showApiMessage = true;
          this.spinner.hide();
        } else {
          this.spinner.hide();
        }
      }, (error) => {
        if (error.error) {
          this.showApiMessage = true;
          this.response = error.error;
          this.spinner.hide();
        } else {
          this.showApiMessage = true;
          this.response = 'Something went wrong!';
          this.spinner.hide();
        }
      });
  }
}
