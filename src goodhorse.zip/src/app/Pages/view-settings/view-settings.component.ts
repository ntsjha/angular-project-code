import { Component, OnInit } from '@angular/core';
import { ServiceService } from 'src/app/Shared/service.service';
import Swal from 'sweetalert2';
import { Router, ActivatedRoute } from '@angular/router';
import { AngularFirestore } from '@angular/fire/firestore';

import { FormGroup, FormControl, Validators } from '@angular/forms';

import { FeedType } from 'src/app/Shared/feed-type';
import * as firebase from 'firebase/app';
declare var $: any;

@Component({
  selector: 'app-view-settings',
  templateUrl: './view-settings.component.html',
  styleUrls: ['./view-settings.component.css']
})
export class ViewSettingsComponent implements OnInit {

  BreedTypeArr: any = [];
  ColorTypeArr: any = [];
  serviceTypeArr: any = [];
  tackTypeArr: any = [];
  tackBrandArr: any = [];
  tackUseArr: any = [];
  contentname: any;
  searchText: string = "";
  p: number = 1;
  pageSize = 10;
  total = 0
  updateform: FormGroup;
  ind: any;
  deleteindex: any;
  feedtype: any;
  deleteValue: any;
  messagepop: any;
  updatedata: any;
  section: any;
  constructor(public router: Router, private afs: AngularFirestore, private firebaseServ: ServiceService, public route: ActivatedRoute) { }

  ngOnInit() {


    // ********Get url data ******************
   
    this.route.queryParams.subscribe((res) => {
      console.log('params--->>> ', res);

      this.contentname = res.value
      this.section = res.section
    })
    this.callfunction()

    this.updateform = new FormGroup({
      updateddata: new FormControl('', [Validators.pattern("^[a-zA-Z ]{1,20}$"), Validators.required]),

    });
    this.messagepop = this.contentname.toLowerCase()
  }

  async callfunction() {

    // ********Get dropdown data according to condition ******************
    switch (this.contentname) {
      case 'Breed':
        console.log('params--->>> ', this.contentname);
        await this.getBreedTypes();
        break;
      case 'Colour':
        await this.getColorTypes();
        break;
      case 'Brand':
        await this.getTackTypeList();
        break;
      case 'Type':
        await this.getTackBrandList();
        break;
      case 'Use':
        await this.getTackUseList();
        break;
      case 'Service':
        await this.getServiceTypeFunc();
        break;
      case 'Discipline':
        await this.getDisciplineTypeFunc();
        break;
      case 'TackUse':
        await this.getDisciplineTackUseTypeFunc();
        break;
      case 'ActivityType':
        await this.getActivityTypeFunc();
        break;
      case 'Temperature':
        await this.getRugTemperatureFunc();
        break;
      case 'RugType':
        await this.getRugTypeFunc();
        break;
      case 'Weather':
        await this.getRugWeatherFunc();
        break;
      case 'When':
        await this.getRugWhenFunc();
        break;
      case 'FeedType':
        await this.getFeedTypeFunc()

        break;
      default:
        this.firebaseServ.toastErr("Something went wrong")
        break;
    }


  }
  getBreedTypes() {
    this.firebaseServ.getBreedTypeFunc().then(res => {

      this.BreedTypeArr = res[0].BreedType;

      this.total = this.BreedTypeArr.length;
      console.log('BreedType_Succ', this.BreedTypeArr)
    }).catch(err => {
      console.log(err)
    })
  }


  getColorTypes() {
    this.firebaseServ.getColorTypeFunc().then(res => {
      console.log('ColorType_Succ', res)
      this.BreedTypeArr = res[0].ColorType;
      this.total = this.BreedTypeArr.length;
    }).catch(err => {
      console.log(err)
    })
  }

  getTackTypeList() {
    this.firebaseServ.getTackTypeListFunc().then(res => {
      console.log('TackTypes =======>', res)
      this.BreedTypeArr = res.TackType;
      this.total = this.BreedTypeArr.length;
    }).catch(err => {
      console.log(err)
    })
  }

  getTackBrandList() {
    this.firebaseServ.getTackBrandListFunc().then(res => {
      console.log('TackBrands =======>', res)
      this.BreedTypeArr = res.TackBrand;
      this.total = this.BreedTypeArr.length;
    }).catch(err => {
      console.log(err)
    })
  }

  getTackUseList() {
    this.firebaseServ.getTackUseListFunc().then(res => {
      console.log('TackUses =======>', res)
      this.BreedTypeArr = res.TackUse;
      this.total = this.BreedTypeArr.length;
    }).catch(err => {
      console.log(err)
    })
  }


  getServiceTypeFunc() {
    this.firebaseServ.getServiceTypeFunc().then(res => {
      console.log('SelectServiceType' + JSON.stringify(res))
      this.BreedTypeArr = res[0].ServiceType
      this.total = this.BreedTypeArr.length;
    }).catch(err => {
      console.log(err)
    })
  }

  getDisciplineTypeFunc() {
    this.firebaseServ.getDisciplineTypeFunc().then(res => {
      console.log('Discipline' + JSON.stringify(res))
      this.BreedTypeArr = res.Discipline
      this.total = this.BreedTypeArr.length;
    }).catch(err => {
      console.log(err)
    })

  }

  getDisciplineTackUseTypeFunc() {
    this.firebaseServ.getDisciplineTackuseFunc().then(res => {
      console.log('DisciplineTack' + JSON.stringify(res))
      this.BreedTypeArr = res.TackUse
      this.total = this.BreedTypeArr.length;
    }).catch(err => {
      console.log(err)
    })

  }

  getActivityTypeFunc() {
    this.firebaseServ.getActivitytypeFunc().then(res => {
      console.log('DisciplineTack' + JSON.stringify(res))
      this.BreedTypeArr = res.ActivityList
      this.total = this.BreedTypeArr.length;
    }).catch(err => {
      console.log(err)
    })

  }

  getRugTemperatureFunc() {
    this.firebaseServ.getRugtypeFunc().then(res => {
      console.log('getRugtypeFunc' + JSON.stringify(res))
      this.BreedTypeArr = res.Temperature
      this.total = this.BreedTypeArr.length;
    }).catch(err => {
      console.log(err)
    })
  }

  getRugTypeFunc() {
    this.firebaseServ.getRugtypeFunc().then(res => {
      console.log('getRugtypeFunc' + JSON.stringify(res))
      this.BreedTypeArr = res.Type
      this.total = this.BreedTypeArr.length;
    }).catch(err => {
      console.log(err)
    })
  }
  getRugWeatherFunc() {
    this.firebaseServ.getRugtypeFunc().then(res => {
      console.log('getRugtypeFunc' + JSON.stringify(res))
      this.BreedTypeArr = res.Weather
      this.total = this.BreedTypeArr.length;
    }).catch(err => {
      console.log(err)
    })
  }

  getRugWhenFunc() {
    this.firebaseServ.getRugtypeFunc().then(res => {
      console.log('getRugtypeFunc' + JSON.stringify(res))
      this.BreedTypeArr = res.When
      this.total = this.BreedTypeArr.length;
    }).catch(err => {
      console.log(err)
    })
  }


  getFeedTypeFunc() {

    this.firebaseServ.getFeedTypeFunc().subscribe(actionArray => {
      // console.log('=========>', actionArray)
      var userList = actionArray.map(item => {
        // console.log('Items====>', item)
        return {
          id: item.payload.doc.id,
          ...item.payload.doc.data()

        } as FeedType;

      })
      this.BreedTypeArr = [];
      userList.forEach(element => {

        this.BreedTypeArr.push(element.id)

      });
      this.total = this.BreedTypeArr.length;
      console.log("user Count--->>>", this.BreedTypeArr)
    });
  }


  // ***********Event for geting UPDATE VALUE *****************//
  contributorEdit(data, index) {
    console.log('getdata', data, index)
    this.ind = index
    this.updateform.patchValue({
      'updateddata': data,
    })
    this.updatedata = data

    $('#update_farms_modal').modal('show');
  }



  // ***********UPDATE VALUE  functions*****************//
  updateviewdata() {
    var ind = this.BreedTypeArr.findIndex((x) => x == this.updateform.value.updateddata);
    console.log(ind, this.BreedTypeArr[5], this.updateform.value.updateddata)
    if (ind == -1) {

      switch (this.contentname) {
        case 'Breed':
          console.log('params--->>> ', this.contentname);
          this.Updatebreeddata();
          break;
        case 'Colour':
          this.UpdateColorTypes();
          break;
        case 'Brand':
          this.UpdateTackTypeList();
          break;
        case 'Type':
          this.UpdateTackBrandList();
          break;
        case 'Use':
          this.UpdateTackUseList();
          break;
        case 'Service':
          this.UpdateServiceTypeFunc();
          break;
        case 'Discipline':
          this.UpdateDisciplineTypeFunc();
          break;
        case 'TackUse':
          this.UpdateDisciplineTackUseTypeFunc();
          break;
        case 'ActivityType':
          this.UpdateActivityTypeFunc();
          break;
        case 'Temperature':
          this.UpdateRugTemperatureFunc();
          break;
        case 'RugType':
          this.UpdateRugTypeFunc();
          break;
        case 'Weather':
          this.UpdateRugWeatherFunc();
          break;
        case 'When':
          this.UpdateRugWhenFunc();
          break;
        case 'FeedType':
          this.UpdateFeedTypemenuFunc();
          break;
        default:
          // this.UpdateServiceTypeFunc();
          break;

      }
    }
    else {
      this.firebaseServ.toastErr(['This ' + this.messagepop + ' name is already taken'])
    }

  }



  Updatebreeddata() {
    this.BreedTypeArr[this.ind] = this.updateform.value.updateddata
    console.log('getdata==>', this.BreedTypeArr)
    this.firebaseServ.addNewBreedFunc(this.BreedTypeArr).then(res => {
      console.log('AddBreed_Succ', res)
      // Swal.fire(
      //   'Success!',
      //   'Your changes are updated successfully.',
      //   'success'
      // )
      $('#update_farms_modal').modal('hide');
      this.firebaseServ.showSuccess('Your changes has been updated successfully.')
      this.firebaseServ.hideSpinner();
      this.getBreedTypes();
    }).catch(err => {
      console.log('AddBreed_Err', err)
    })
  }


  UpdateColorTypes() {
    this.BreedTypeArr[this.ind] = this.updateform.value.updateddata
    console.log('getdata==>', this.BreedTypeArr)
    this.firebaseServ.addNewColourFunc(this.BreedTypeArr).then(res => {
      console.log('AddBreed_Succ', res)

      $('#update_farms_modal').modal('hide');
      this.firebaseServ.hideSpinner();
      // this.breed = '';
      this.firebaseServ.showSuccess('Your changes has been updated successfully.')
      this.getColorTypes();
    }).catch(err => {
      console.log('AddBreed_Err', err)
    })
  }

  UpdateTackTypeList() {
    this.BreedTypeArr[this.ind] = this.updateform.value.updateddata
    console.log('getdata==>', this.BreedTypeArr)
    this.firebaseServ.addNewTackTypeFunc(this.BreedTypeArr).then(res => {
      console.log('AddBreed_Succ', res)

      $('#update_farms_modal').modal('hide');
      this.firebaseServ.hideSpinner();
      // this.breed = '';
      this.firebaseServ.showSuccess('Your changes has been updated successfully.')

      this.getTackTypeList();
    }).catch(err => {
      console.log('AddBreed_Err', err)
    })
  }

  UpdateTackBrandList() {
    this.BreedTypeArr[this.ind] = this.updateform.value.updateddata
    console.log('getdata==>', this.BreedTypeArr)
    this.firebaseServ.addNewTackBrandFunc(this.BreedTypeArr).then(res => {
      console.log('AddBreed_Succ', res)

      // Swal.fire(
      //   'Success!',
      //   'Your changes has been updated successfully.',
      //   'success'
      // )
      $('#update_farms_modal').modal('hide');
      this.firebaseServ.hideSpinner();
      // this.breed = '';
      this.firebaseServ.showSuccess('Your changes has been updated successfully.')

      this.getTackBrandList();
    }).catch(err => {
      console.log('AddBreed_Err', err)
    })
  }
  UpdateTackUseList() {
    this.BreedTypeArr[this.ind] = this.updateform.value.updateddata
    console.log('getdata==>', this.BreedTypeArr, this.ind)
    this.firebaseServ.addNewTackUseFunc(this.BreedTypeArr).then(res => {
      console.log('AddBreed_Succ', res)

      // Swal.fire(
      //   'Success!',
      //   'Your changes has been updated successfully.',
      //   'success'
      // )
      $('#update_farms_modal').modal('hide');
      this.firebaseServ.hideSpinner();
      // this.breed = '';
      this.firebaseServ.showSuccess('Your changes has been updated successfully.')

      this.getTackUseList();
    }).catch(err => {
      console.log('AddBreed_Err', err)
    })
  }

  UpdateServiceTypeFunc() {
    this.BreedTypeArr[this.ind] = this.updateform.value.updateddata
    console.log('getdata==>', this.BreedTypeArr)
    this.firebaseServ.addNewServiceTypeFunc(this.BreedTypeArr).then(res => {
      console.log('AddBreed_Succ', res)

      // Swal.fire(
      //   'Success!',
      //   'Your changes has been updated successfully.',
      //   'success'
      // )
      $('#update_farms_modal').modal('hide');
      this.firebaseServ.hideSpinner();
      // this.breed = '';
      this.firebaseServ.showSuccess('Your changes has been updated successfully.')

      this.getServiceTypeFunc();
    }).catch(err => {
      console.log('AddBreed_Err', err)
    })
  }

  UpdateDisciplineTypeFunc() {
    this.BreedTypeArr[this.ind] = this.updateform.value.updateddata
    console.log('getdata==>', this.BreedTypeArr)
    this.firebaseServ.addNewDisciplineUseFunc(this.BreedTypeArr).then(res => {
      console.log('AddBreed_Succ', res)
      $('#update_farms_modal').modal('hide');
      this.firebaseServ.hideSpinner();
      // this.breed = '';
      this.firebaseServ.showSuccess('Your changes has been updated successfully.')

      // this.getServiceTypeFunc();
    }).catch(err => {
      console.log('AddBreed_Err', err)
    })
  }


  UpdateDisciplineTackUseTypeFunc() {
    this.BreedTypeArr[this.ind] = this.updateform.value.updateddata
    console.log('getdata==>', this.BreedTypeArr)
    this.firebaseServ.addNewDisciplineTackuseFunc(this.BreedTypeArr).then(res => {
      console.log('AddBreed_Succ', res)
      $('#update_farms_modal').modal('hide');
      this.firebaseServ.hideSpinner();
      // this.breed = '';
      this.firebaseServ.showSuccess('Your changes has been updated successfully.')

      // this.getServiceTypeFunc();
    }).catch(err => {
      console.log('AddBreed_Err', err)
    })
  }

  UpdateActivityTypeFunc() {
    this.BreedTypeArr[this.ind] = this.updateform.value.updateddata
    console.log('getdata==>', this.BreedTypeArr)
    this.firebaseServ.addNewActivitytypeFunc(this.BreedTypeArr).then(res => {
      console.log('AddBreed_Succ', res)
      $('#update_farms_modal').modal('hide');
      this.firebaseServ.hideSpinner();
      // this.breed = '';
      this.firebaseServ.showSuccess('Your changes has been updated successfully.')

      // this.getServiceTypeFunc();
    }).catch(err => {
      console.log('AddBreed_Err', err)
    })

  }
  UpdateRugTemperatureFunc() {
    this.BreedTypeArr[this.ind] = this.updateform.value.updateddata
    console.log('getdata==>', this.BreedTypeArr)
    this.firebaseServ.addRugtypesFunc(this.BreedTypeArr, 'Temperature').then(res => {
      console.log('AddBreed_Succ', res)
      $('#update_farms_modal').modal('hide');
      this.firebaseServ.hideSpinner();
      // this.breed = '';
      this.firebaseServ.showSuccess('Your changes has been updated successfully.')

      // this.getServiceTypeFunc();
    }).catch(err => {
      console.log('AddBreed_Err', err)
    })

  }

  UpdateRugTypeFunc() {
    this.BreedTypeArr[this.ind] = this.updateform.value.updateddata
    console.log('getdata==>', this.BreedTypeArr)
    this.firebaseServ.addRugtypesFunc(this.BreedTypeArr, 'Type').then(res => {
      console.log('AddBreed_Succ', res)
      $('#update_farms_modal').modal('hide');
      this.firebaseServ.hideSpinner();
      // this.breed = '';
      this.firebaseServ.showSuccess('Your changes has been updated successfully.')

      // this.getServiceTypeFunc();
    }).catch(err => {
      console.log('AddBreed_Err', err)
    })

  }

  UpdateRugWeatherFunc() {
    this.BreedTypeArr[this.ind] = this.updateform.value.updateddata
    console.log('getdata==>', this.BreedTypeArr)
    this.firebaseServ.addRugtypesFunc(this.BreedTypeArr, 'Weather').then(res => {
      console.log('AddBreed_Succ', res)
      $('#update_farms_modal').modal('hide');
      this.firebaseServ.hideSpinner();
      // this.breed = '';
      this.firebaseServ.showSuccess('Your changes has been updated successfully.')

      // this.getServiceTypeFunc();
    }).catch(err => {
      console.log('AddBreed_Err', err)
    })

  }
  UpdateRugWhenFunc() {
    this.BreedTypeArr[this.ind] = this.updateform.value.updateddata
    console.log('getdata==>', this.BreedTypeArr)
    this.firebaseServ.addRugtypesFunc(this.BreedTypeArr, 'When').then(res => {
      console.log('AddBreed_Succ', res)
      $('#update_farms_modal').modal('hide');
      this.firebaseServ.hideSpinner();
      // this.breed = '';
      this.firebaseServ.showSuccess('Your changes has been updated successfully.')

      // this.getServiceTypeFunc();
    }).catch(err => {
      console.log('AddBreed_Err', err)
    })

  }

  UpdateFeedTypemenuFunc() {

    this.BreedTypeArr[this.ind] = this.updateform.value.updateddata
    this.BreedTypeArr = []
    // *********local declare varible because globle variable is not understand**************
    var olddocname = this.updatedata;
    var updatedValue = this.updateform.value.updateddata
    var toster = this.firebaseServ
    firebase.firestore().collection("FeedType").doc(olddocname).get().then(function (doc) {
      if (doc && doc.exists) {
        console.log('AddBreed_Err', doc)
        let docId = updatedValue; // changein to this name

        var data = doc.data();

        console.log('DOC NAme', olddocname)
        // saves the data to 'name'
        firebase.firestore().collection("FeedType").doc(docId).set(data).then(res => {
          // deletes the old document

          firebase.firestore().collection("FeedType").doc(olddocname).delete();
        });
        $('#update_farms_modal').modal('hide');

        toster.showSuccess('Your changes has been updated successfully.')
      }

    })
    this.callfunction()


  }
  // *******Event DELETE SETTING DATA ****************


  deleteFuction(data, valuename) {
    console.log(data, valuename)
    this.deleteindex = data
    // ********FeedType**************************
    this.deleteValue = valuename
    $('#delet_farms_modal').modal('show');
  }


  // ***********Delete VALUE  according functions*****************//
  deletesettingdata() {
    switch (this.contentname) {
      case 'Breed':
        console.log('params--->>> ', this.contentname);
        this.deleteBreedArrFunc();
        break;
      case 'Colour':
        this.deleteColorTypes();
        break;
      case 'Brand':
        this.deleteTackTypeList();
        break;
      case 'Type':
        this.deleteTackBrandList();
        break;
      case 'Use':
        this.deleteTackUseList();
        break;
      case 'Service':
        this.deleteServiceTypeFunc();
        break;
      case 'Discipline':
        this.deleteDisciplineTypeFunc();
        break;
      case 'TackUse':
        this.deleteDisciplineTackUseTypeFunc();
        break;
      case 'ActivityType':
        this.deleteActivityTypeFunc();
        break;
      case 'Temperature':
        this.deleteRugTemperatureFunc();
        break;
      case 'RugType':
        this.deleteRugTypeFunc();
        break;
      case 'Weather':
        this.deleteRugWeatherFunc();
        break;
      case 'When':
        this.deleteRugWhenFunc();
        break;
        break;
      case 'FeedType':
        this.deleteFeedTypeFunc()

        break;
      default:
        // this.UpdateServiceTypeFunc();
        break;

    }
  }


  deleteBreedArrFunc() {
    this.BreedTypeArr.splice([this.deleteindex], 1);
    console.log('getdata==>', this.BreedTypeArr)
    this.firebaseServ.addNewBreedFunc(this.BreedTypeArr).then(res => {
      console.log('AddBreed_Succ', res)
      $('#delet_farms_modal').modal('hide');
      this.firebaseServ.showSuccess('Your data has been deleted successfully.')

      this.firebaseServ.hideSpinner();

      // this.breed = '';
      this.callfunction()
    }).catch(err => {
      console.log('AddBreed_Err', err)
    })
  }

  deleteColorTypes() {
    this.BreedTypeArr.splice([this.deleteindex], 1);
    console.log('getdata==>', this.BreedTypeArr)
    this.firebaseServ.addNewColourFunc(this.BreedTypeArr).then(res => {
      console.log('AddBreed_Succ', res)
      $('#delet_farms_modal').modal('hide');
      this.firebaseServ.hideSpinner();
      // this.breed = '';
      this.firebaseServ.showSuccess('Your data has been deleted successfully.')
      this.callfunction()
    }).catch(err => {
      console.log('AddBreed_Err', err)
    })
  }


  deleteTackTypeList() {
    this.BreedTypeArr.splice([this.deleteindex], 1);
    console.log('Nitesh data==>', this.BreedTypeArr)
    this.firebaseServ.addNewTackTypeFunc(this.BreedTypeArr).then(res => {
      console.log('AddBreed_Succ', res)

      // Swal.fire(
      //   'Success!',
      //   'Your changes are updated successfully.',
      //   'success'
      // )
      $('#delet_farms_modal').modal('hide');
      this.firebaseServ.showSuccess('Your data has been deleted successfully.')
      this.firebaseServ.hideSpinner();
      // this.breed = '';

      this.callfunction()
    }).catch(err => {
      console.log('AddBreed_Err', err)
    })
  }

  deleteTackBrandList() {
    this.BreedTypeArr.splice([this.deleteindex], 1);
    console.log('Nitesh data==>', this.BreedTypeArr)
    this.firebaseServ.addNewTackBrandFunc(this.BreedTypeArr).then(res => {
      console.log('AddBreed_Succ', res)

      // Swal.fire(
      //   'Success!',
      //   'Your changes are updated successfully.',
      //   'success'
      // )
      $('#delet_farms_modal').modal('hide');
      this.firebaseServ.showSuccess('Your data has been deleted successfully.')
      this.firebaseServ.hideSpinner();
      this.callfunction()
    }).catch(err => {
      console.log('AddBreed_Err', err)
    })
  }
  deleteTackUseList() {
    this.BreedTypeArr.splice([this.deleteindex], 1);
    console.log('Nitesh data==>', this.BreedTypeArr)
    this.firebaseServ.addNewTackUseFunc(this.BreedTypeArr).then(res => {
      console.log('AddBreed_Succ', res)
      $('#delet_farms_modal').modal('hide');
      this.firebaseServ.hideSpinner();
      this.firebaseServ.showSuccess('Your data has been deleted successfully.')

      this.callfunction()
    }).catch(err => {
      console.log('AddBreed_Err', err)
    })
  }

  deleteServiceTypeFunc() {
    this.BreedTypeArr.splice([this.deleteindex], 1);
    console.log('Nitesh data=>', this.BreedTypeArr)
    this.firebaseServ.addNewServiceTypeFunc(this.BreedTypeArr).then(res => {
      console.log('AddBreed_Succ', res)
      $('#delet_farms_modal').modal('hide');
      this.firebaseServ.hideSpinner();
      this.firebaseServ.showSuccess('Your data has been deleted successfully.')
      this.callfunction()
    }).catch(err => {
      console.log('AddBreed_Err', err)
    })
  }

  deleteDisciplineTypeFunc() {
    this.BreedTypeArr.splice([this.deleteindex], 1);
    console.log('Nitesh data=>', this.BreedTypeArr)
    this.firebaseServ.addNewDisciplineUseFunc(this.BreedTypeArr).then(res => {
      console.log('AddBreed_Succ', res)
      $('#delet_farms_modal').modal('hide');
      this.firebaseServ.hideSpinner();
      this.firebaseServ.showSuccess('Your data has been deleted successfully.')
      // this.getServiceTypeFunc();
      this.callfunction()
    }).catch(err => {
      console.log('AddBreed_Err', err)
    })
  }

  deleteDisciplineTackUseTypeFunc() {
    this.BreedTypeArr.splice([this.deleteindex], 1);
    console.log('Nitesh data=>', this.BreedTypeArr)
    this.firebaseServ.addNewDisciplineTackuseFunc(this.BreedTypeArr).then(res => {
      console.log('AddBreed_Succ', res)
      $('#delet_farms_modal').modal('hide');
      this.firebaseServ.hideSpinner();
      this.firebaseServ.showSuccess('Your data has been deleted successfully.')
      this.callfunction()
    }).catch(err => {
      console.log('AddBreed_Err', err)
    })
  }
  deleteActivityTypeFunc() {
    this.BreedTypeArr.splice([this.deleteindex], 1);
    console.log('Nitesh data=>', this.BreedTypeArr)
    this.firebaseServ.addNewActivitytypeFunc(this.BreedTypeArr).then(res => {
      console.log('AddBreed_Succ', res)
      $('#delet_farms_modal').modal('hide');
      this.firebaseServ.hideSpinner();
      this.firebaseServ.showSuccess('Your data has been deleted successfully.')
      this.callfunction()
    }).catch(err => {
      console.log('AddBreed_Err', err)
    })
  }

  deleteRugTemperatureFunc() {
    this.BreedTypeArr.splice([this.deleteindex], 1);
    console.log('Nitesh data=>', this.BreedTypeArr)
    this.firebaseServ.addRugtypesFunc(this.BreedTypeArr, 'Temperature').then(res => {
      console.log('AddBreed_Succ', res)
      $('#delet_farms_modal').modal('hide');
      this.firebaseServ.hideSpinner();
      this.firebaseServ.showSuccess('Your data has been deleted successfully.')
      this.callfunction()
    }).catch(err => {
      console.log('AddBreed_Err', err)
    })
  }
  deleteRugTypeFunc() {
    this.BreedTypeArr.splice([this.deleteindex], 1);
    console.log('Nitesh data=>', this.BreedTypeArr)
    this.firebaseServ.addRugtypesFunc(this.BreedTypeArr, 'Type').then(res => {
      console.log('AddBreed_Succ', res)
      $('#delet_farms_modal').modal('hide');
      this.firebaseServ.hideSpinner();
      this.firebaseServ.showSuccess('Your data has been deleted successfully.')
      this.callfunction()
    }).catch(err => {
      console.log('AddBreed_Err', err)
    })
  }
  deleteRugWeatherFunc() {
    this.BreedTypeArr.splice([this.deleteindex], 1);
    console.log('Nitesh data=>', this.BreedTypeArr)
    this.firebaseServ.addRugtypesFunc(this.BreedTypeArr, 'Weather').then(res => {
      console.log('AddBreed_Succ', res)
      $('#delet_farms_modal').modal('hide');
      this.firebaseServ.hideSpinner();
      this.firebaseServ.showSuccess('Your data has been deleted successfully.')
      this.callfunction()
    }).catch(err => {
      console.log('AddBreed_Err', err)
    })
  }
  deleteRugWhenFunc() {
    this.BreedTypeArr.splice([this.deleteindex], 1);
    console.log('Nitesh data=>', this.BreedTypeArr)
    this.firebaseServ.addRugtypesFunc(this.BreedTypeArr, 'When').then(res => {
      console.log('AddBreed_Succ', res)
      $('#delet_farms_modal').modal('hide');
      this.firebaseServ.hideSpinner();
      this.firebaseServ.showSuccess('Your data has been deleted successfully.')
      this.callfunction()
    }).catch(err => {
      console.log('AddBreed_Err', err)
    })
  }


  deleteFeedTypeFunc() {
    this.BreedTypeArr.splice([this.deleteindex], 1);
    console.log('Nitesh data=>', this.deleteValue)

    firebase.firestore().collection("FeedType").doc(this.deleteValue).delete();
    $('#delet_farms_modal').modal('hide');
    this.firebaseServ.hideSpinner();
    this.firebaseServ.showSuccess('Your data has been deleted successfully.')
    this.callfunction()

  }




  viewFeedtype(type, data) {
    console.log('data', type, data)
    // var info=data;
    if (type == 'Feed') {
      let info = data;
      this.router.navigate(['/setting/view-feed-setting/Feed'], {
        queryParams: { value: info, type: type }
      })


    }
    else {

      let info = data;
      this.router.navigate(['/setting/view-feed-setting/unit'], {
        queryParams: { value: info, type: type }
      })

    }

  }
  addsetting() {
    this.router.navigate(['/setting/add-setting/id'], {
      queryParams: { id: this.contentname, section: this.section }
    })
  }
  search() {
    // console.log("Contributor List-->>",this.BreedTypeArr,this.searchText)
    let searchData = []
    searchData = this.BreedTypeArr.filter(x => (console.log(x == this.searchText)));

    console.log("Contributor List-->>", this.BreedTypeArr, searchData)
    this.BreedTypeArr = searchData;
    this.total = this.BreedTypeArr.length;

  }

  page(event) {
    console.log(event);
    this.p = event
  }

  preventSpace(event){
    if(event.charCode==32 && !event.target.value){
    event.preventDefault()
    } else{
    console.log(event)
    }
    console.log('event',event.charCode)
    }

}
