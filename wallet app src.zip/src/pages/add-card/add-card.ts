import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';
import { EnterCvcPage } from "../enter-cvc/enter-cvc";
import { ServiceServicesProvider } from "../../providers/service-services/service-services";

@IonicPage()
@Component({
  selector: 'page-add-card',
  templateUrl: 'add-card.html',
})
export class AddCardPage {
  expiry: any;
  upComingYears: any = [];
  AddCardForm: FormGroup;

  constructor(public navCtrl: NavController, public navParams: NavParams, public fb: FormBuilder, public service: ServiceServicesProvider) {
    //----------------------------------------- FORMAT THE EXPIRY YEAR OF THE CARD -----------------------------------------//
    let year = new Date().getFullYear();
    for (let i = 0; i < 35; i++) {
      this.upComingYears[i] = year + i;
    }

    //----------------------------------------- BUILD ADD CARD FORM & VALIDATE IT -----------------------------------------//
    this.AddCardForm = fb.group({
      'cardNumber': [null, Validators.compose([Validators.required, Validators.minLength(13), Validators.pattern(/^\d+$/)])],
      'cardHolderName': [null, Validators.compose([Validators.required])]
    });
  }

  back() {
    this.navCtrl.pop();
  }

  next() {
    if (navigator.onLine) {
      let data = JSON.parse(localStorage.addMoneyProcess);
      data.cardDetails = {
        cardNumber: this.AddCardForm.value.cardNumber,
        cardHolderName: this.AddCardForm.value.cardHolderName,
        expiry: this.expiry
      }
      localStorage.addMoneyProcess = JSON.stringify(data)
      this.navCtrl.push(EnterCvcPage)
    } else
      this.service.presentToast('Your internet connections seems to be lost')
  }

}
