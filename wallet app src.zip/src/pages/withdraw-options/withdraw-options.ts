import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { TabsPage } from '../tabs/tabs';
import { ServiceServicesProvider } from '../../providers/service-services/service-services';
import { BankListPage } from '../bank-list/bank-list';
import { VendorsListPage } from '../vendors-list/vendors-list';

@IonicPage()
@Component({
  selector: 'page-withdraw-options',
  templateUrl: 'withdraw-options.html',
})
export class WithdrawOptionsPage {
  howTo: any;

  constructor(public navCtrl: NavController, public navParams: NavParams, private service: ServiceServicesProvider) {
  }

  back() {
    this.navCtrl.setRoot(TabsPage, { selectedTab:  4})
  }

  next() {
    if (navigator.onLine) {
      let data = JSON.parse(localStorage.withdrawMoneyProcess);
      data.howTo = this.howTo
      localStorage.withdrawMoneyProcess = JSON.stringify(data)
      if(this.howTo == 'bank')
        this.navCtrl.push(BankListPage)
      else
        this.navCtrl.push(VendorsListPage, {process: 'WITHDRAW'})
    } else
      this.service.presentToast('Your internet connection seems to be lost')
  }

}
