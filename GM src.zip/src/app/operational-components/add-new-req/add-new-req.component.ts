import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { CookieService } from 'ngx-cookie-service';
import { ServiceService } from 'src/app/service/service.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { Router } from '@angular/router';
import { DatePipe } from '@angular/common';

@Component({
    selector: 'app-add-new-req',
    templateUrl: './add-new-req.component.html',
    styleUrls: ['./add-new-req.component.css']
})
export class AddNewReqComponent implements OnInit {
    addNewuser: FormGroup;
    userdata: any;
    userIp: any;
    showApiMessage: boolean;
    response: any;
    model_phone_number:'';
  
    constructor(private cookie: CookieService,private service: ServiceService, private spinner: NgxSpinnerService, private router: Router, public datepipe: DatePipe) {  }
  
    ngOnInit() {
    this.addNewuser = new FormGroup({
        usertype: new FormControl('INDIVIDUAL',[Validators.required]),
        email: new FormControl('', [Validators.required, Validators.pattern(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,3}))$/), Validators.maxLength(256)]),
    });
    this.userIp = (this.cookie.get('userInfo')) ? JSON.parse(this.cookie.get('userInfo')) : this.service.initialUserInfo;
    window.scrollTo(0, 0);
    }
  
    get email(): any {
        return this.addNewuser.get('email');
    }
    
    get phone(): any {
        return this.addNewuser.get('phoneNumber');
    }
    
    get usertype(): any {
        return this.addNewuser.get('usertype');
    }

    createUser() {
    }
  


}
