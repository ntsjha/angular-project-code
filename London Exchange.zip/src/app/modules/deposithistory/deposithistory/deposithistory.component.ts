import { Component, OnInit } from '@angular/core';
import { Router } from '../../../../../node_modules/@angular/router';
import { AppComponent } from '../../../app.component';
import { ServerService } from '../../../service/server.service';
import { Ng4LoadingSpinnerService } from '../../../../../node_modules/ng4-loading-spinner';
import { THIS_EXPR } from '../../../../../node_modules/@angular/compiler/src/output/output_ast';
import { HeaderComponent } from '../../header/header/header.component';

@Component({
    selector: 'app-deposithistory',
    templateUrl: './deposithistory.component.html',
    styleUrls: ['./deposithistory.component.css']
})
export class DeposithistoryComponent implements OnInit {
    currCoin = "LCX";
    depositArr = [];
    explorerName = "https://etherscan.io/tx/" ;

    constructor( private appC: AppComponent, private server: ServerService, private spinnerService: Ng4LoadingSpinnerService, public header: HeaderComponent) { }

    ngOnInit() {    
        window.scrollTo(0,0);
        this.deposit(this.currCoin);
    }

    /** Function to get deposit list from api */
    deposit(coin){
    //     let data = {
    //         "eventExternal": {
    //             "name": "request_deposits",
    //             "key": "mykey"                
    //         },   
    //        "transferObjectMap": { 
    //            "gatewayrequest": { 
    //                "coinType": coin,
    //                 "token": localStorage.getItem('token')
    //             }
    //         }
    //     }
    //     this.spinnerService.show();
    //     this.server.postApi('', data,0).subscribe(response => {
    //         this.spinnerService.hide();
    //         if (response.transferObjectMap.statusCode == 200) {
    //             this.appC.showSuccToast("Deposit history fetched successfully.");
    //             this.depositArr = response.transferObjectMap.deposits;
    //         } else if(response.transferObjectMap.statusCode == 403){
    //             this.appC.showErrToast(response.transferObjectMap.message); 
    //             this.header.tokenExpire()
    //         } else {
    //             this.appC.showErrToast(response.transferObjectMap.message);                     
    //         }
    //     }, error => {
    //         this.spinnerService.hide();
    //         //this.appC.showErrToast('Something went wrong');
    //     }); 
    
    
    // let data = {
    //     "coinName": coin

    // }
    // console.log(data);
//    this.router.navigateByUrl('header/transactionDetail/'+this.coinName)
    this.spinnerService.show();
    this.server.getApi('wallet/wallet/get-deposits?coinName='+coin+'&page=4&pageSize=1',localStorage.getItem('token')).subscribe(response => {
        this.spinnerService.hide();
        if (response.body.status == 200) {
           
            console.log('deposit data--->',response.body.data)
           this.depositArr = response.body.data.resultlist;
        } else if(response.status == 403){ 
            this.header.tokenExpire()
        } else {
            this.appC.showErrToast(response.body.message);                     
        }
    }, error => {
        this.spinnerService.hide();
        this.appC.showErrToast(error.error.message);
    });

     }

    
    
    /** Function to select coin */
    selectCoin(coin) {
        this.currCoin = coin;
        switch(this.currCoin) {
            case 'BTC' : 
                this.explorerName = 'https://live.blockcypher.com/btc/tx/';
                break;
            case 'LTC' : 
                this.explorerName = 'https://live.blockcypher.com/ltc/tx/';
                break;
            case 'ETH' : 
                this.explorerName = 'https://etherscan.io/tx/';
                break;
            case 'DASH' : 
                this.explorerName = 'https://live.blockcypher.com/dash/tx/';
                break;
            case 'XRP' : 
                this.explorerName = 'https://bithomp.com/explorer/';
                break;
            case 'NEO' : 
                this.explorerName = 'https://neoscan.io/address/';
                break;
            case 'BCH' : 
                this.explorerName = 'https://explorer.bitcoin.com/bch/address/bitcoincash:';
                break;
            case 'XLM' : 
                this.explorerName = 'https://stellarscan.io/account/';
                break;
            case 'USDT' : 
                this.explorerName = 'https://www.omniexplorer.info/search/';
                break;
            case 'XVG' : 
                this.explorerName = 'https://verge-blockchain.info/tx/';
                break;
        }
        this.depositArr = [];
        this.deposit(this.currCoin);
    }

}
