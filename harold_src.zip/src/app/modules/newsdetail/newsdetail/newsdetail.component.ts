import { Component, OnInit } from '@angular/core';
import { ServerService } from '../../../server.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { Router } from '@angular/router';
import { AppComponent } from '../../../app.component';

@Component({
    selector: 'app-newsdetail',
    templateUrl: './newsdetail.component.html',
    styleUrls: ['./newsdetail.component.css']
})
export class NewsdetailComponent implements OnInit {
    pageData: any = [];
    commentSection = false;
    likes = false;
    dislikes = false;
    id: string;
    like: any;
    dislike: any;
    comment: any;
    commentList: any = [];
    message: any;

    constructor(private server : ServerService, private spinnerService: Ng4LoadingSpinnerService, private router: Router, private appC: AppComponent) { }

    ngOnInit() {
        let url = window.location.href.split('/');
        this.id = url[url.length - 1];
        this.getPageData();
        this.getCountApi();
        this.getCommentList();
    }

    getPageData() {
        this.spinnerService.show();
        this.server.getApi('static/news/getNews?newsId='+this.id).subscribe((succ) => {
            this.spinnerService.hide();
            this.pageData = succ.data;
            if(succ.data.response == 'LIKED') {
                this.likes = true;
                
            } else if(succ.data.response == 'DISLIKED') {
                this.dislikes = true;
            }
            if(!this.pageData.newsImage.includes('https')) {
                this.pageData.newsImage = '';
            }
        },err =>{
            this.spinnerService.hide();
        });
    }

    showComment() {
        this.commentSection = true;
    }

    getCountApi() {
        this.server.getApi('static/comment/getLikesAndDislike?newsId='+this.id).subscribe((succ) => {
            this.like = succ.data.likes;
            this.dislike = succ.data.dislikes;
            this.comment = succ.data.comments;
        })
    }

    getCommentList() {
        this.server.getApi('static/comment?newsId='+this.id).subscribe((succ) => {
            this.commentList = succ.data;
        })
    }

    sendComment() {
        if(localStorage.getItem('token')) {
            if(this.message != '') {
                let data = {
                    "message": this.message,
                    "newsId": this.id,
                    "userId": localStorage.getItem('userId') 
                }
                this.server.postApi('static/comment',data).subscribe((succ) => {
                    this.commentSection = false;
                    this.getCommentList();
                });
            } else {
                this.appC.showErrToast('Please type message')
            }
        } else {
            this.appC.showErrToast('Please login first');
        }
        
    }

    hitLike() {
        if(localStorage.getItem('token')) {
            this.server.getApi('static/comment/hitLike?newsId='+this.id).subscribe((succ) => {
                this.likes = true;
                this.dislikes = false;
                this.getCountApi();
            });
        } else {
            this.appC.showErrToast('Please login first');
        }
    }

    hitDislike() {
        if(localStorage.getItem('token')) {
            this.server.getApi('static/comment/hitDislike?newsId='+this.id).subscribe((succ) => {
                this.dislikes = true;
                this.likes = false;
                this.getCountApi();
            });
        } else {
            this.appC.showErrToast('Please login first');
        }
    }



    // $(".comment").click(function(){
    //     $(".comment-post").toggle();
    //   });


}


