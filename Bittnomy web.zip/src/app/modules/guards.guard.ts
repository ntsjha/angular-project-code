import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, Router } from '@angular/router';
import { Observable } from 'rxjs';


@Injectable({
    providedIn: 'root'
})


export class GuardsGuard implements CanActivate {
    constructor(private router: Router) { }
    canActivate(next: ActivatedRouteSnapshot,state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
        state.url
        if (localStorage.getItem('token') != null) {
            if ((state.url == '/header/login') || (state.url == '/header/signup') || (state.url == '/header/forgotpassword')) {
                this.router.navigate(['']);
            }
            return true;
        } else {
            if ((state.url == '/header/wallet') || (state.url == '/header/profile') || (state.url == '/header/transactionDetail') || (state.url == '/header/deposit') || (state.url == '/header/withdraw') || (state.url == '/header/fiathistory') || (state.url == '/header/order') || (state.url == '/header/dashboard') || (state.url == '/header/postTrade') || (state.url == '/header/deposit') || (state.url == '/header/tradeDetail') || (state.url == '/header/tradeAction') || (state.url == '/header/tradeList') || (state.url == '/header/TransactionDetail') || (state.url == '/header/withdrawVerify/:token') || (state.url == '/header/exchange-pair') || (state.url == '/header/exchange/:base/:exe') || (state.url == '/header/transactionDetail/:token')) {
                this.router.navigate(['/header/exchange'])
            }
            return false;
        }

    }
}
