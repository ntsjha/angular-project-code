import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '../../../../../node_modules/@angular/forms';
import { Ng4LoadingSpinnerService } from '../../../../../node_modules/ng4-loading-spinner';
import { AppComponent } from '../../../app.component';
import { ServerService } from '../../../service/server.service';
import { HeaderComponent } from '../../header/header/header.component';

@Component({
  selector: 'app-changepassword',
  templateUrl: './changepassword.component.html',
  styleUrls: ['./changepassword.component.css']
})
export class ChangepasswordComponent implements OnInit {
    changeForm: FormGroup
    check: boolean;
    numRegxForPattern: any = (/^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})/i);
  constructor(private spinnerService :Ng4LoadingSpinnerService, private appC: AppComponent, private server: ServerService, public header:HeaderComponent) { }

  ngOnInit() {
    this.checkInputs();
  }

  checkInputs() {
      this.changeForm = new FormGroup ({
          password: new FormControl('', [Validators.required]),
          newPassword: new FormControl('', [Validators.required, Validators.pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})/i)]),
          confirmPassword: new FormControl('', [Validators.required]),
      }, passwordMatchValidator);
      /** Function for password match and mismatch */
      function passwordMatchValidator(g: FormGroup) {
          let pass = g.get('newPassword').value;
          let confPass = g.get('confirmPassword').value;
          if (pass != confPass) {
              g.get('confirmPassword').setErrors({ mismatch: true });
          } else {
              g.get('confirmPassword').setErrors(null)
              return null
          }
      }

      
  }

  /** Function for old password  and new password match and mismatch */
  passwordValidator() {
    this.check = true
    if(this.changeForm.value.newPassword!='')   {
        if(this.changeForm.value.newPassword == this.changeForm.value.password)
            this.changeForm.get('newPassword').setErrors({ mismatch: true });
        else if(!this.numRegxForPattern.test(this.changeForm.value.newPassword)) {
            this.changeForm.get('newPassword').setErrors({ pattern: true });
        } else {
            this.changeForm.get('newPassword').setErrors(null)
            this.check = false
        } 
    }
  }


  /** to get the value of field  */
  get password(): any {
    return this.changeForm.get('password');
  } 
  get newPassword(): any {
    return this.changeForm.get('newPassword');
  }
  get confirmPassword(): any {
    return this.changeForm.get('confirmPassword');
  }
  /** to change password  */
  changePass() {

      let data = {
        
                            "oldPassword": this.changeForm.value.password , 
                            "newPassword":this.changeForm.value.newPassword ,
                            
                          }
           
      this.spinnerService.show();
      this.server.postApi('account/change-password', data,localStorage.getItem('token')).subscribe(response => {
          this.spinnerService.hide();
          if (response.body.status == 200) {
            this.appC.showSuccToast('Password change sucessfully'); 
            this.changeForm.reset()
            
          } else if(response.statusCode == 403){
            this.appC.showErrToast(response.body.message); 
            this.header.tokenExpire();
          } else {
            this.appC.showInfoToast(response.body.message); 
            this.changeForm.reset()
          }
      }, error => {
          this.spinnerService.hide();
          this.appC.showErrToast('Something went wrong');
      });
      

  }

}
