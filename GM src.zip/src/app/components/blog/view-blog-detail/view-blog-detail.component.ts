// import { GetBaseSixtyFourPipe } from './../../../pipes/get-base-sixty-four.pipe';
import { ActivatedRoute } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { ServiceService } from 'src/app/service/service.service';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-view-blog-detail',
  templateUrl: './view-blog-detail.component.html',
  styleUrls: ['./view-blog-detail.component.css']
})
export class ViewBlogDetailComponent implements OnInit {

  paramData: any;
  blogDetail: any = {};
  image: any;

  constructor(
    private activatedRoute: ActivatedRoute,
    private service: ServiceService,
    private spinner: NgxSpinnerService,
  ) { }

  ngOnInit() {
    window.scrollTo(0, 0);
    this.getParamData();
  }

  getParamData() {
    this.activatedRoute.params.subscribe(param => {
      this.paramData = param;
      this.getBlogDetail();
    });
  }

  getBlogDetail() {
    this.spinner.show();
    this.service.postMethod(`blog/admin/get-blog-detail?contentId=${encodeURIComponent(this.service.encrypt(this.paramData.id))}&language=${encodeURIComponent(this.service.encrypt(this.paramData.lang))}`, {}, 1).subscribe(success => {
      this.spinner.hide();
      if (success.status === 628) {
        this.blogDetail = success.data;
        if (this.blogDetail.image) {
          this.service.getMethod('account/convert-image-base64?imageUrl=' + this.service.imageUrl +  this.blogDetail.image, 1).subscribe((res: any) => {
            this.spinner.hide();
          }, error => {
            this.spinner.hide();
            if (error.error.text) {
              this.image = 'data:image/jpg;base64,' + error.error.text;
              return this.image;
            }
          });
        }
      }
    }, error => {
      this.spinner.hide();
    });
  }

}
