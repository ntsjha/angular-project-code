import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fees-feature',
  templateUrl: './fees-feature.component.html',
  styleUrls: ['./fees-feature.component.css']
})
export class FeesFeatureComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    window.scrollTo(0,0);
  }

}
