import { Component, OnInit } from '@angular/core';
import { AngularFirestore, AngularFirestoreModule } from '@angular/fire/firestore';
import { ServiceService } from 'src/app/Shared/service.service';
import { FormGroup, Validators, FormControl } from '@angular/forms';

import * as _ from "lodash";
import { Upload } from 'src/app/Shared/common-class';
import * as firebase from 'firebase/app';
import { Router } from '@angular/router';
import { formatDate } from '@angular/common';
@Component({
  selector: 'app-add-user-guide',
  templateUrl: './add-user-guide.component.html',
  styleUrls: ['./add-user-guide.component.css']
})
export class AddUserGuideComponent implements OnInit {

  addUserGuideForm: FormGroup;
  fileName1: any;


  selectedFiles: FileList;
  currentUpload: Upload;
  ref: any;
  task: any;
  uploadProgress: any;
  downloadURL: any;
  userProfileImg: any;
  randomId: string;
  image: any;
  size: string;
  vidourl: any;
  constructor(private afStorage: AngularFirestoreModule, private router: Router, private afb: AngularFirestore, public firebaseServ: ServiceService) { }

  ngOnInit() {

    this.addUserGuideForm = new FormGroup({
      title: new FormControl('', [Validators.required, Validators.pattern(/^[a-z\d\-_?.,:'@*;!&%-\s]+$/i)]),
      video: new FormControl('', [Validators.required]),

    })

  }



  /**Function To upload front side of pic */
  handleFileInputFront(event) {

    var self = this;
    if (event.target.files && event.target.files[0]) {
      var type = event.target.files[0].type;
      var size = event.target.files[0].size;
      let count = 0;
      if (size < 100000000) {
        if (type === 'video/mp4' || type === 'video/mov' || type === 'video/wmv' || type === 'video/mpeg' || type === 'video/3gp' || type === 'video/avi' || type === 'video/flv' || type === 'video/mkv') {
          this.size = event.target.files[0].size / 1024 / 1024 + "MB"
          this.fileName1 = event.target.files[0];
          this.addUserGuideForm.patchValue({
            video: this.fileName1.name
          })
          count++;
        } else if (type === 'video/mp4') {
          this.size = event.target.files[0].size / 1024 / 1024 + "MB"
          this.fileName1 = event.target.files[0];

          this.addUserGuideForm.patchValue({
            video: this.fileName1.name

          })
          count++;

        } else {
          this.firebaseServ.toastErr('Select only  mp4,wmv,mpeg,3gp,avi,flv and mkv file.')

        }
      } else {
        this.firebaseServ.toastErr('Video size should be less than 100 MB.')


      }

      console.log('File', this.fileName1)
    }
  }



  // Uploading Video Functionality
  onUpload(evt: any) {
    this.firebaseServ.showSpinner()
    console.log('File')

    const file = this.fileName1;
    // const randomId = Math.random().toString(36).substring(2);
    // this.ref = firebase.storage().ref('video/'+randomId);
    // this.task = this.ref.put(file);
    // this.ref.fullPath  



    if (file) {
      console.log('File')
      const reader = new FileReader();
      reader.onload = this.handleReaderLoadedCustom.bind(this);
      reader.readAsBinaryString(file);
    }

  }




  handleReaderLoadedCustom(e) {
    this.uploadvideoToFirebase('data:video/mp4;base64,' + btoa(e.target.result))
  }
  uploadvideoToFirebase(image) {
    let randomId = Math.random().toString(36).substr(2, 5);
    this.firebaseServ.getUserProfileImageuploadVideo(image, randomId)
      .then(videoURL => {

        this.vidourl = videoURL;
        // this.firebaseServ.hideSpinner()
        // console.log('URL', this.image)
        var time = formatDate(new Date(), 'yyyy/MM/dd h:mm:ss', 'en');

        let data = {
          Title: this.addUserGuideForm.value.title,
          VideoUrl: this.vidourl,
          LastUpdate: time,
        }
        // console.log('INFO==>', data)
        this.afb.collection('UserGuide').add(data);
        this.firebaseServ.showSuccess('User guide has been added successfully.');
        this.firebaseServ.hideSpinner();
        this.addUserGuideForm.reset();
        this.router.navigate(['/user-guide']);


      }).catch(err => {
        console.log(err)
        this.firebaseServ.hideSpinner()
      })

  }






  numberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;

  }
  preventSpace(event) {
    if (event.charCode == 32 && !event.target.value) {
      event.preventDefault()
    } else {
      // console.log(event)
    }
    // console.log('event',event.charCode)
  }




}

