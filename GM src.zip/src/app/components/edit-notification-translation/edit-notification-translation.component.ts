import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ServiceService } from 'src/app/service/service.service';
import { FormGroup, Validators, FormControl } from '@angular/forms';

@Component({
  selector: 'app-edit-notification-translation',
  templateUrl: './edit-notification-translation.component.html',
  styleUrls: ['./edit-notification-translation.component.css']
})
export class EditNotificationTranslationComponent implements OnInit {
  notificationData: any;
  translationId: any;
  notificationTokenData: any;
  translationFunction: FormGroup;
  enId: string;
  thId: any;
  chId: any;
  langaugeId: any;

  constructor(
    private service: ServiceService,
    private spinner: NgxSpinnerService,
    private activatedRoute: ActivatedRoute,
    private route: Router
  ) {
    this.translationFunction = new FormGroup({
      translationMessage: new FormControl(null, Validators.required),
    });
  }

  ngOnInit() {
    this.activatedRoute.params.subscribe(id => {
      this.translationId = id.id;
      this.langaugeId = id.id2;
    });
    this.notificationList();
    window.scrollTo(0, 0);
  }
  onSubmit() {
    this.spinner.show();
    const data = {
      message    : this.translationFunction.value.translationMessage,
      languageId : this.langaugeId,
      translationId : this.translationId
    };

    this.service.postMethod('notification-service/admin/update-translation-detail', data, 1).subscribe((response: any) => {
      this.spinner.hide();
      if (response.status === 1618  ) {
        this.route.navigate(['/manage-notification']);
      }
    }, (error) => {
      this.spinner.hide();
    });
  }



  notificationList() {
    this.spinner.show();
    this.service.getMethod('notification-service/admin/get-translation-details?translationId=' + this.translationId , 1).subscribe((response: any) => {
      this.spinner.hide();
      if (response.status === 1616) {
        this.notificationData = response.data;
        this.translationFunction.patchValue({
          translationMessage: response.data.message
        });
        this.notificationTokenList();
        this.langauge();
      }
    }, (error) => {
      this.spinner.hide();

    });
    this.spinner.hide();
  }






  

  notificationTokenList() {
    this.spinner.show();
    this.service.getMethod('notification-service/admin/get-replacementToken-lists', 1).subscribe((response: any) => {
      this.spinner.hide();
      if (response.status === 1200) {
        this.notificationTokenData = response.data;
      }
    }, (error) => {
      this.spinner.hide();

    });
    this.spinner.hide();
  }
  langauge() {
      if (this.notificationData.fkLanguageId === '1') {
        this.enId = 'English';
      }
      if (this.notificationData.fkLanguageId === '2') {
        this.enId = 'Thai';
      }
      if (this.notificationData.fkLanguageId === '3') {
        this.enId = 'Chinese';
      }
  }
}
