import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ResetPinPage } from './reset-pin';

@NgModule({
  declarations: [
    ResetPinPage,
  ],
  imports: [
    IonicPageModule.forChild(ResetPinPage),
  ],
})
export class ResetPinPageModule {}
