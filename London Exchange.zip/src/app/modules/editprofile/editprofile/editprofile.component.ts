import { Component, OnInit, ViewChild} from '@angular/core';
import { Router } from '../../../../../node_modules/@angular/router';
import { FormGroup, FormControl, Validators } from '../../../../../node_modules/@angular/forms';
import { Ng4LoadingSpinnerService } from '../../../../../node_modules/ng4-loading-spinner';
import { AppComponent } from '../../../app.component';
import { ServerService } from '../../../service/server.service';
import { GooglePlaceDirective } from '../../../../../node_modules/ngx-google-places-autocomplete';
import { Address } from '../../../../../node_modules/ngx-google-places-autocomplete/objects/address';
import { HeaderComponent } from '../../header/header/header.component';
declare var $: any;

@Component({
    selector: 'app-editprofile',
    templateUrl: './editprofile.component.html',
    styleUrls: ['./editprofile.component.css']
})
export class EditprofileComponent implements OnInit {
    @ViewChild("placesRef") placesRef : GooglePlaceDirective;
    userImage: any;
    userimage: any;
    options: any;
    public handleAddressChange(address: Address) {
        //console.log(address)
        this.address1 = address.formatted_address;
        address.address_components.forEach((obj) => {
            if(obj.types[0] == "locality") {
                this.editProfile.patchValue({
                    city: obj.long_name
                })
            }
            if(obj.types[0] == "administrative_area_level_1") {
                this.editProfile.patchValue({
                    state: obj.long_name
                })
            }
            if(obj.types[0] == "country") {
                this.editProfile.patchValue({
                    country: obj.long_name
                })
            }
        })
      
    } 
    editProfile: FormGroup
    countryData: any;
    myCode: any;
    minAge: Date;
    name1: any;
    email1: any;
    address1: any;
    city1: any;
    state1: any;
    country1: any;
    myCountryCode: any;  
    myPhone: any;
    gender1: any;
    authObj: any= {};
    fileName: any;
    fileData: any;
    myImage:any;

    constructor(private router:Router,  private spinnerService :Ng4LoadingSpinnerService, private appC:AppComponent, private server:ServerService, public header: HeaderComponent) { }


    ngOnInit() {   
        $("#phoneNum").intlTelInput({
            autoPlaceholder: true,
            autoFormat: false,
            autoHideDialCode: false,
            initialCountry: 'in',
            nationalMode: false,
            onlyCountries: [],
            preferredCountries: ["us"],
            formatOnInit: true,
            separateDialCode: true
        });
        this.checkpoints();
        this.getprofile();   
       
    }
    
    updateProfile() {
        this.countryData = $("#phoneNum").intlTelInput("getSelectedCountryData");
        this.myCountryCode = this.countryData.dialCode;
        if(this.fileData.includes('https'))
            this.myImage= ''
        else if(this.fileData.includes('assets'))
            this.myImage= ''
        let data = {
            
                        "firstName": this.editProfile.value.name , 
                        "phoneCountryCode": this.myCountryCode,
                        "email": this.email1,
                        "phone":this.myPhone,
                        "address":this.address1,
                        "city":this.editProfile.value.city,
                        "state":this.editProfile.value.state,
                        "country":this.editProfile.value.country,
                        "gender":this.editProfile.value.gender,
                        "imageUrl": this.myImage,
                        "token":localStorage.getItem('token')
                    }
           
        //console.log(this.fileData)
        this.spinnerService.show();
        this.server.postApi('account/profile-update', data,localStorage.getItem('token')).subscribe(response => {
            this.spinnerService.hide();
            if (response.body.status == 200) {
                this.appC.showSuccToast(response.body.message);
                this.router.navigate(['header/kyc']);
            } else if(response.body.statusCode == 403){
                this.appC.showErrToast(response.body.message); 
                this.header.tokenExpire()
            } else {
                this.appC.showInfoToast(response.body.message); 
                this.getprofile()                   
            }
        }, error => {
            this.spinnerService.hide();
            this.getprofile();
            this.appC.showErrToast('Profile cannot be updated at the moment....');
            
        });
    }

    getprofile() {
        this.spinnerService.show();
        this.server.getApi("account/my-account",localStorage.getItem('token')).subscribe((succ) => {
            this.spinnerService.hide();
            this.name1 = succ.body.data.firstName;
            this.email1 = succ.body.data.email;  
            this.myPhone = succ.body.data.phoneNo;
            this.city1 = succ.body.data.city;
            this.state1 = succ.body.data.state;  
            this.country1 = succ.body.data.country;
            this.address1 = succ.body.data.address;
            this.gender1 = succ.body.data.gender;
            if(succ.body.data.imageUrl==null || succ.body.data.imageUrl=='') {
                this.myImage = 'assets/images/user.png';
                this.fileData = 'assets/images/user.png';}
            else {
                this.myImage = succ.body.data.imageUrl;
                this.fileData = succ.body.data.imageUrl;
            }
            if(succ.body.data.address==null || succ.body.data.gender== null) {
                this.city1 = '';
                this.state1 = '';
                this.country1 = '';
                this.address1 = '';
                this.gender1 = '';
            }
                
            //console.log("image423---->>>>>"+this.fileData)
            this.editProfile.patchValue({
                name : this.name1,
                city : this.city1,
                state : this.state1,
                country : this.country1,
                address : this.address1,
                email : this.email1,
                phone:this.myPhone,
                gender:this.gender1,
                
            })
        }, (err) => {
            this.spinnerService.hide();
        });
    }

  

    checkpoints() {
        this.editProfile = new FormGroup ({
            email: new FormControl(this.email1, [Validators.required, Validators.pattern(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/i)]),
            name: new FormControl(this.name1, [Validators.required, Validators.minLength(3), Validators.pattern(/^[a-zA-Z ]*$/i)]),
            date:new FormControl(),
            phone:new FormControl(this.myPhone),
            city:new FormControl(this.city1),
            state:new FormControl(this.state1),
            country:new FormControl(this.country1),
            address:new FormControl(this.address1),
            gender:new FormControl(this.gender1),

        });
    }

    get email(): any {
        return this.editProfile.get('email');
    }

    get phone(): any {
        return this.editProfile.get('phone');
    }
    get name(): any {
        return this.editProfile.get('name');
    }
    get address(): any {
        return this.editProfile.get('address');
    }
    get city(): any {
        return this.editProfile.get('city');
    }
    get state(): any {
        return this.editProfile.get('state');
    }
    get country(): any {
        return this.editProfile.get('country');
    }
    get gender(): any {
        return this.editProfile.get('gender');
    }

    onKey(obj) {
        //console.log(obj.target.value)
        if(obj.target.value=='') {
            this.editProfile.patchValue({
                city:"",
                state: "",
                country:""

            })
        }
    }

    profilePic(event) {
        var self = this;
        let formData = new FormData();
        let count = 0
        if (event.target.files && event.target.files[0]) {
            var type = event.target.files[0].type;
            if (type === 'image/png' || type === 'image/jpg') {
                self.authObj.docFile = event.target.files[0].name;
                this.fileName = event.target.files[0];
                formData.append('file', this.fileName);
                var reader = new FileReader()
                reader.onload = (e) => {
                    self.fileData = e.target['result']
                    self.myImage = e.target['result'].substring(22);
                }
                reader.readAsDataURL(event.target.files[0]);
                count++;
            } else if (type === 'image/jpeg') {
                self.authObj.docFile = event.target.files[0].name;
                this.fileName = event.target.files[0];
                formData.append('file', this.fileName);
                var reader = new FileReader()
                reader.onload = (e) => {
                    self.fileData = e.target['result'];
                    self.myImage = e.target['result'].substring(23);
                }
                reader.readAsDataURL(event.target.files[0]);
                count++
            } else {
                this.appC.showErrToast("Please select png, jpeg and jpg format.");
                self.authObj.docFile = "";

            }
        }
        if (count != 0) {
            this.spinnerService.show();
            this.server.postApi('account/upload-file', formData, 1).subscribe(res => {
                this.spinnerService.hide();
                if (res.body.status == 200) {
                    this.myImage = res.body.data;
                }
                else {
                   
                    this.appC.showErrToast('Please select valid file')
                }
            }, err => {
                this.spinnerService.hide();
                this.appC.showErrToast('Please select valid file')
            })

      

        }
    }

}
