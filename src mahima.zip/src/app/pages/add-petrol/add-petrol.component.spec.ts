import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddPetrolComponent } from './add-petrol.component';

describe('AddPetrolComponent', () => {
  let component: AddPetrolComponent;
  let fixture: ComponentFixture<AddPetrolComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddPetrolComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddPetrolComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
