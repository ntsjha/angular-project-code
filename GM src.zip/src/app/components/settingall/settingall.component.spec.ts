import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SettingallComponent } from './settingall.component';

describe('SettingallComponent', () => {
  let component: SettingallComponent;
  let fixture: ComponentFixture<SettingallComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SettingallComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SettingallComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
