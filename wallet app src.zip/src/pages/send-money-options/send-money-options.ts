import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { SendMoneyConfirmationPage } from '../send-money-confirmation/send-money-confirmation';
import { VendorsListPage } from '../vendors-list/vendors-list';
import { ServiceServicesProvider } from '../../providers/service-services/service-services';

@IonicPage()
@Component({
  selector: 'page-send-money-options',
  templateUrl: 'send-money-options.html',
})
export class SendMoneyOptionsPage {
  onlyVendor: boolean;
  amount: string;

  constructor(public navCtrl: NavController, public navParams: NavParams, public service: ServiceServicesProvider) {
    if(JSON.parse(localStorage.sendMoneyProcess).vendor)
      this.onlyVendor = true;
    else
      this.onlyVendor = false;
  }

  back() {
    this.navCtrl.pop();
  }

  next() {
    let data = JSON.parse(localStorage.sendMoneyProcess)
    data.howTo = 'directToAppWallet';
    localStorage.sendMoneyProcess = JSON.stringify(data);
    this.navCtrl.push(SendMoneyConfirmationPage)
  }

  nextViaVendor() {
    if((/^\d+$/).test(this.amount)) {
      let data = JSON.parse(localStorage.sendMoneyProcess)
      data.howTo = 'vendor';
      data.amount = this.amount;
      localStorage.sendMoneyProcess = JSON.stringify(data);
      this.navCtrl.push(VendorsListPage, {process: 'SEND'} )
    }
    else
      this.service.presentToast('Enter a valid amount')
  }

}
