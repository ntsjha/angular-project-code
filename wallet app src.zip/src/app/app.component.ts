import { Component } from '@angular/core';
import { Platform, AlertController } from 'ionic-angular';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { LoginPage } from '../pages/login/login';
import { ServiceServicesProvider } from "../providers/service-services/service-services";
import { SignpinPage } from "../pages/signpin/signpin";
import { FCM } from '@ionic-native/fcm';
import { SocketProvider } from '../providers/socket/socket';


@Component({
  templateUrl: 'app.html'
})
export class MyApp {
  rootPage: any;
  constructor(platform: Platform, statusBar: StatusBar, splashScreen: SplashScreen, public server: ServiceServicesProvider, private fcm: FCM, public alertCtrl: AlertController, public socketService: SocketProvider) {
    platform.ready().then(() => {
      // Okay, so the platform is ready and our plugins are available.
      // Here you can do any higher level native things you might need.
      statusBar.styleBlackOpaque();
      splashScreen.hide();
      localStorage.setItem('notibadge','false')
      this.initSocket();
      if (localStorage.getItem('userName'))
        this.checkPin();
      else
        this.rootPage = LoginPage;
      console.log('updated')
      if (platform.is('cordova')) {
        this.getFCMToken();
        this.getNotification();
      }
    });
  }

  initSocket() {
    this.socketService.initSocket();

    this.socketService.onEvent('connect')
      .subscribe(() => {
        console.log('connected');
      });
      
    this.socketService.onEvent('disconnect')
      .subscribe(() => {
        console.log('disconnected');
      });
  }

  checkPin() {
    if (navigator.onLine) {
    this.server.presentLoading();
    let data = {
      userName: localStorage.getItem('userName')
    }
    this.server.postApi(data, 'user/pinExists', 0).subscribe((resposne: any) => {
      this.server.dismissLoading();
      if (resposne[`response_code`] == 200)
        this.rootPage = SignpinPage;
      else
        this.rootPage = LoginPage;
    }, err => {
      this.rootPage = LoginPage;
      this.server.dismissLoading();
      this.server.presentToast('Something went wrong')
    })
    } else
    this.server.presentToast('Your internet connection seems to be lost')
  }

  //------------------------------------------ GET FCM TOKEN ON APP LAUNCH ------------------------------------------//
  getFCMToken() {
    this.fcm.getToken().then(token => {
      if (token) {
        localStorage.FCM = token;
      } else {
        this.getFCMToken();
      }
    });

    this.fcm.onTokenRefresh().subscribe(token => {
      localStorage.FCM = token;
    });
  }

  //------------------------------------------ RECEIVE APP NOTIFICATION ------------------------------------------//
  getNotification() {
    this.fcm.onNotification().subscribe(data => {
      // this.notificationAlert(data.param1, data.param2);
      if (data.wasTapped) {
        alert('Notification')
        console.log('received')
        localStorage.setItem('notibadge','true')
        //Notification was received on device tray and tapped by the user.
      } else {
        alert('Notification')
        console.log('received')
        localStorage.setItem('notibadge','true')
        //Notification was received in foreground. The user needs to be notified.
      }
    });
  }
  //------------------------------------------ RECEIVE APP NOTIFICATION ------------------------------------------//

  //------------------------------------------ NOTIFICATION ALERT STARTS ------------------------------------------//
  notificationAlert(title, msg) {
    let alert = this.alertCtrl.create({
      title: title,
      message: msg,
      cssClass: 'customAlert singleBtn',
      buttons: [
        {
          text: 'OK',
          role: 'cancel',
        }
      ]
    });
    alert.present();
  }
  //------------------------------------------ NOTIFICATION ALERT ENDS ------------------------------------------//
}



// 383114294702-7edt6ula330oue6sfp5utb40t08dna1k.apps.googleusercontent.com
// com.googleusercontent.apps.383114294702-7edt6ula330oue6sfp5utb40t08dna1k

// ionic cordova plugin add cordova-plugin-googleplus --save --variable REVERSED_CLIENT_ID=com.googleusercontent.apps.383114294702-7edt6ula330oue6sfp5utb40t08dna1k