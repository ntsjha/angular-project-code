import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OTCSettingComponent } from './otc-setting.component';

describe('OTCSettingComponent', () => {
  let component: OTCSettingComponent;
  let fixture: ComponentFixture<OTCSettingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OTCSettingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OTCSettingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
