import { Component, OnInit, OnDestroy } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { ServiceService } from 'src/app/service/service.service';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { AppComponent } from 'src/app/app.component';

declare var $: any;

@Component({
  selector: 'app-edit-export',
  templateUrl: './edit-export.component.html',
  styleUrls: ['./edit-export.component.css']
})
export class EditExportComponent implements OnInit, OnDestroy {
  exportId: any;
  addScheduleForm: FormGroup;
  currentUser: any;
  scheduleHistory: any[];
  scheduleFrequinciesType: any;
  scheduleHistoryType: any;
  subscription: any;
  showFilePath = false;



  constructor(
    private route: Router,
    private service: ServiceService,
    private spinner: NgxSpinnerService,
    private activatedRoute: ActivatedRoute,
    private appC: AppComponent
  ) {
    this.service.currentUserInfo.subscribe((response) => {
      this.currentUser = response;
    });
    this.subscription = this.service.authVerify.subscribe(val => {
      if (val === 'edit-export') {
        this.submit();
        this.service.authVerify.next('false');
      }
    });
  }

  ngOnInit() {
    this.activatedRoute.params.subscribe(id => {
      this.exportId = id.id;
    });
    window.scrollTo(0, 0);
    this.form();
    this.getSchedule();
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  form() {
    this.addScheduleForm = new FormGroup({
      selectType: new FormControl('', [Validators.required]),
      frequency: new FormControl('', [Validators.required]),
      typeOfConnection: new FormControl('', [Validators.required]),
      host: new FormControl('', [Validators.required, Validators.minLength(2), Validators.maxLength(30)]),
      userName: new FormControl('', [Validators.required, Validators.pattern(/^[a-zA-Z][a-zA-Z ]*$/), Validators.minLength(2), Validators.maxLength(255)]),
      password: new FormControl('', [Validators.required, Validators.minLength(10), Validators.maxLength(128), Validators.pattern(/(?=^.{10,128}$)(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&amp;*()_+}{&quot;:;'?/&gt;.&lt;,])(?!.*\s).*$/)]),
      pathToSaveFile: new FormControl('', [Validators.required, Validators.minLength(2), Validators.maxLength(255)]),
      port: new FormControl('', [Validators.required, Validators.minLength(2), Validators.maxLength(30)]),
    });
  }

  loadForms() {
    this.addScheduleForm.patchValue({
      typeOfConnection: this.scheduleHistory[0].connectionType,
      host: this.scheduleHistory[0].host,
      userName: this.scheduleHistory[0].username,
      password: this.scheduleHistory[0].password,
      pathToSaveFile: this.scheduleHistory[0].pathToSaveFile,
      port: this.scheduleHistory[0].port
    });
  }

  getSchedule() {

    this.spinner.show();
    this.service.getMethod('setting/common-permit/get-export-schedule-detail?exportsId=' + encodeURIComponent(this.service.encrypt(this.exportId)), 1).subscribe((response: any) => {
      this.spinner.hide();
      if (response.status === 1221) {
        this.scheduleHistory = response.data;
        this.loadForms();
        this.getFrequincies();
        this.getTypeSchedule();
      }
    }, (error) => {
      this.spinner.hide();
    });
    this.spinner.hide();
  }



  getFrequincies() {
    this.spinner.show();
    this.service.getMethod('setting/common-permit/get-export-schedule-frequency', 1).subscribe((response: any) => {
      this.spinner.hide();
      if (response.status === 1232) {
        this.scheduleFrequinciesType = response.data;
        this.addScheduleForm.patchValue({
          frequency: this.scheduleHistory[0].scheduleFrequencies.frequencyId,
        });
        this.checkForFile();
      }
    }, (error) => {
      this.spinner.hide();
    });
    this.spinner.hide();
  }

  checkForFile() {
    if (this.addScheduleForm.value.typeOfConnection === 'filePath') {
      this.showFilePath = true;
      this.addScheduleForm.controls['pathToSaveFile'].setValidators([Validators.required, Validators.minLength(2), Validators.maxLength(255)]);
    } else {
      this.addScheduleForm.patchValue({
        pathToSaveFile: null
      });
      this.addScheduleForm.controls['pathToSaveFile'].clearValidators();
      this.showFilePath = false;
    }
  }

  getTypeSchedule() {
    this.spinner.show();
    this.service.getMethod('setting/common-permit/get-export-schedule-type', 1).subscribe((response: any) => {
      this.spinner.hide();
      if (response.status === 1234) {
        this.scheduleHistoryType = response.data;
        this.addScheduleForm.patchValue({
          selectType: this.scheduleHistory[0].scheduleTypes.typeId
        });
      }
    }, (error) => {
      this.spinner.hide();
    });
    this.spinner.hide();
  }

  /** Function to verify google authentication */
  verifyGoogleAuth() {
    this.appC.google = { one: '', two: '', three: '', four: '', five: '', six: '' };
    this.appC.response = { message: '' };
    this.service.googleAuthCalledFrom = 'edit-export';
    $('#google-auth-modal').modal({ keyboard: false, backdrop: 'static' });

  }

  submit() {
    if (this.addScheduleForm.invalid) {
      return;
    }
    // this.spinner.show();
    const data = {
      connectionType: this.service.encrypt(this.addScheduleForm.value.typeOfConnection),
      frequencyId: this.service.encrypt(this.addScheduleForm.value.frequency),
      host: this.service.encrypt(this.addScheduleForm.value.host),
      ipAddress: this.service.encrypt(this.currentUser.ip),
      location: this.service.encrypt(this.currentUser.city + ',' + this.currentUser.country_name),
      password: this.service.encrypt(this.addScheduleForm.value.password),
      pathToSaveFile: this.service.encrypt(this.addScheduleForm.value.pathToSaveFile),
      port: this.service.encrypt(this.addScheduleForm.value.port),
      typeId: this.service.encrypt(this.addScheduleForm.value.selectType),
      username: this.service.encrypt(this.addScheduleForm.value.userName)
    };
    this.service.postMethod('setting/common-permit/edit-export-schedule?exportsId=' + encodeURIComponent(this.service.encrypt(this.exportId)), data, 1).subscribe((response: any) => {
      if (response.status === 1226) {
        this.route.navigate(['/export']);
      }
    }, (error) => {
      // this.spinner.hide();
    });
    this.spinner.hide();
  }

}
