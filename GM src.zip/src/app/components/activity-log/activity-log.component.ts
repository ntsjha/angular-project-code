import { Component, OnInit } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { ServiceService } from 'src/app/service/service.service';
import { FormGroup, FormControl } from '@angular/forms';
import { IMyDpOptions, IMyDateModel } from 'mydatepicker';

@Component({
  selector: 'app-activity-log',
  templateUrl: './activity-log.component.html',
  styleUrls: ['./activity-log.component.css']
})
export class ActivityLogComponent implements OnInit {
  getLogs: any = [];
  search: any = null;
  page: any = 1;
  total: any;
  toDateInTimestamp: any = 0;
  fromDateInTimestamp: any = 0;
  filterFunction: FormGroup;
  public fromPickerOptions: IMyDpOptions = {
    disableSince: { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() },
    dateFormat: 'dd/mm/yyyy',
  };
  public toPickerOptions: IMyDpOptions = {
    disableSince: { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() },
    dateFormat: 'dd/mm/yyyy',
  };
  datepipe: any;

  constructor(private spinner: NgxSpinnerService, private service: ServiceService) {
    this.filterFunction = new FormGroup({
      fromDate: new FormControl(null),
      toDate: new FormControl(null),
      search: new FormControl(null)
    });
  }

  ngOnInit() {
    window.scrollTo(0, 0);
    this.getActivityLogs();
  } 

  searchFilter(){
    this.page = 1;
    this.getActivityLogs();
  }

  /** Function to get activity logs */
  getActivityLogs() {
    this.getLogs = [];
    const count = 0;
    this.spinner.show();
    const data = {
      page: this.service.encrypt(String(this.page - 1)),
      pageSize: this.service.encrypt(String('10')),
      search: (this.filterFunction.value.search == null) ? ((this.service.email != null) ? this.service.encrypt(this.service.email) : null) : this.service.encrypt(this.filterFunction.value.search.trim()),
      fromDate: (this.filterFunction.value.fromDate) ? (this.filterFunction.value.fromDate.epoc ? this.service.encrypt((this.filterFunction.value.fromDate.epoc * 1000)) : null) : null,
      toDate: (this.filterFunction.value.toDate) ? (this.filterFunction.value.toDate.epoc ? this.service.encrypt(((this.filterFunction.value.toDate.epoc * 1000) + (86400000 - 1))) : null) : null
    };
    this.service.postMethod('account/common-permit/search-and-filter-customers-activity-logs', data, 1).subscribe((response: any) => {
      let responseData = this.service.decrypt(response.data);
      responseData = JSON.parse(responseData);
      if (responseData.status === 928 || responseData.status === 585) {
        if (responseData.data.list) {
          this.getLogs = responseData.data.list;
          this.total = responseData.data.size - count;
        }
        this.spinner.hide();
      } else {
        this.spinner.hide();
      }
    }, (error) => {
      this.spinner.hide();
    });
  }

  fromDateChanged(event) {
    if (event.epoc) {
      this.toPickerOptions = {
        disableUntil: { year: new Date(event.epoc * 1000).getFullYear(), month: new Date(event.epoc * 1000).getMonth() + 1, day: new Date(event.epoc * 1000).getDate() - 1 }
      };
    } else {
      this.toPickerOptions = {
        disableUntil: { year: 0, month: 0, day: 0 },
        disableSince: { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() + 1 }
      };
    }
  }
     
  toDateChanged(event) {
    if (event.epoc) { 
      this.fromPickerOptions = {
        disableSince: { year: new Date(event.epoc * 1000).getFullYear(), month: new Date(event.epoc * 1000).getMonth() + 1, day: new Date(event.epoc * 1000).getDate() + 1 }
      };
    } else {
      this.fromPickerOptions = {
        disableSince: { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() + 1 },
      };
    }
  }

  /** Function to convert date format */
  convertFormat(time) {
    if (time != null) {
      return this.datepipe.transform(time, 'MM/dd/yyy, hh:mm a');
    }
  }

  changePage(page) {
    this.page = page;
    this.getActivityLogs();
  }

  resetFunc() {
    this.page = 1;
    this.search = null;
    this.filterFunction.value.fromDate = null;
    this.filterFunction.value.toDate = null;
    this.filterFunction.patchValue({
      search: null,
      fromDate: null,
      toDate: null
    })
    this.fromPickerOptions = {
      disableSince: { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() + 1 },
      disableUntil: { year: 0, month: 0, day: 0 }
    };
    this.toPickerOptions = {
      disableSince: { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() + 1 },
      disableUntil: { year: 0, month: 0, day: 0 }
    };
    this.getActivityLogs();
  }
}
