import { Component, OnInit } from '@angular/core';
import { Router } from '../../../../../node_modules/@angular/router';
import { AppComponent } from '../../../app.component';
import { FormGroup, FormControl, Validators } from '../../../../../node_modules/@angular/forms';
import { ServerService } from '../../../service/server.service';
import { Ng4LoadingSpinnerService } from '../../../../../node_modules/ng4-loading-spinner';
import { Observable } from '../../../../../node_modules/rxjs';
import { HeaderComponent } from '../../header/header/header.component';
declare var $ : any;

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
    check: any;
    
    authObj: any= {};
    fileName: any;
    fileData: any;
    uploadForm: FormGroup
    obj:any= {};
    attachmentData:any;
    name: any;
    email:any;
    toggle:any ={}
    countryData: any;
    myCode: any;
    phone: any = {};
    myAngularxQrCode:any= null;
    otp = { one: "", two: "", three: "", four: "" };
    qrCode = {Code1:""} 
    code: any;
    time: number;
    seconds: number = 60;
    google11: any;
    sms11: any;
    count: number = 1;
    googleEnabled: any;
    smsEnabled: any;
    phoneCountryCode: any = '';
    phoneNo: any = '';
    userImage: string;
    const: any;
    kyc: any = [];
    kycToken: boolean;
    
  

  constructor(private router:Router, public appC: AppComponent, private server: ServerService,  private spinnerService: Ng4LoadingSpinnerService,public header: HeaderComponent) { }

  ngOnInit() {
    this.count = 1;
    this.getprofile();
    window.scrollTo(0,0);
    this.checkInputs();
    this.checkKycStatus();
    
   
  }

    checkInputs() {
        this.uploadForm = new FormGroup ({
        docName: new FormControl('', [Validators.required , Validators.pattern(/^([a-zA-Z' ]+)$/i)]),
        docNum: new FormControl('', [Validators.required]),
        attachmentNum: new FormControl('', [Validators.required])
        })
    }

    myTimer() {
       this.const =  Observable.interval(1000)
        .takeWhile(() => this.seconds > 0 || (this.seconds != 60 && this.seconds > 0))
        .subscribe(i => { 
            // This will be called every 10 seconds until `stopCondition` flag is set to true
            
            --this.seconds;
            console.log(this.seconds)
        })
        if(this.seconds==0)
        {
            clearInterval(this.seconds);
        }
    } 
    
    mytoggle(val){
        this.count = 1;
        console.log("timeout--->>>"+ this.toggle.google)
        Observable.interval(1000)
            .takeWhile(() => this.count < 2)
            .subscribe(i => { 
        // This will be called every 1 seconds until `stopCondition` flag is set to true
        if(val==1)
            this.toggle.google = true;
        else
            this.toggle.sms = true;   
        this.count++ ;
        console.log("timeout function")
    })
    }

    //Function to verify the otp send on registered phone number
    openotpmodal() {
       
      this.seconds = 59;
      this.otp = { one: "", two: "", three: "", four: "",  };
      
      
      
      let data= {
          "eventExternal":
              {
                  "name":"request_sms_auth",
                  "key":"mykey"
              },
         "transferObjectMap": {
                      "gatewayrequest":
                          {
                              "phoneCountryCode":this.phoneCountryCode,
                              "phone":this.phoneNo,
                              "token":localStorage.getItem('token')
                          }
          }
      }
      //localStorage.setItem('phone',this.phone.phn);
      //localStorage.setItem('code',this.myCode);
      this.spinnerService.show();
      this.server.postApi('', data,0).subscribe(response => {
          this.spinnerService.hide();
          if (response.transferObjectMap.statusCode == 200) {
              this.appC.showSuccToast(response.transferObjectMap.message);
              
              $('#otpmodal').modal({
                  backdrop: 'static',
                  keyboard: false  // to prevent closing with Esc button (if you want this too)
              })
              this.myTimer();
          } else if(response.transferObjectMap.statusCode == 403){
            this.appC.showErrToast(response.transferObjectMap.message); 
            this.header.tokenExpire();
          } else {
              this.appC.showErrToast(response.transferObjectMap.message);
              
          }
      }, error => {
          this.spinnerService.hide();
          this.appC.showErrToast('Something went wrong');
      });
 
      
    }

    editProfile() {
        this.router.navigate(['header/edit']);
                
    }


    getprofile() {
        
        this.spinnerService.show();
        this.server.getApi("?key="+localStorage.getItem('token')+"USER",0).subscribe((succ) => {
        this.spinnerService.hide();
        this.name = succ[0].firstName;
        this.email = succ[0].email;
        this.phoneNo = succ[0].phone;
        this.phoneCountryCode = succ[0].phoneCountryCode;
        if(succ[0].userImage==null || succ[0].userImage=='')
            this.userImage = 'assets/images/edit-img.png';
        else
            this.userImage = succ[0].userImage;
        localStorage.setItem('googleEnabled',succ[0].google2faEnabled)
        localStorage.setItem('smsEnabled',succ[0].smsEnabled)
        
        if(succ[0].google2faEnabled == "true" || succ[0].google2faEnabled == "1") {
            console.log("google")
            this.toggle.google = true
            this.toggle.sms = false

        } else if(succ[0].smsEnabled == "true" || succ[0].smsEnabled == "1") {
            console.log("sms")
            this.toggle.sms = true
            this.toggle.google = false

        } else {
            this.toggle.sms = false;
            this.toggle.google = false;
        
        }
        
        }, (err) => {
        this.spinnerService.hide();
        });
        this.header.getprofile();
    }

    /** Auto focus functionality */
    onKey(value, type) 
    {
        if (type == 1) {
            if (value != "") {
                $('#otp2').focus();
            }
        } else if (type == 2) {
            if (value != "") {
                $('#otp3').focus();
            }
        } else if (type == 3) {
            if (value != "") {
                $('#otp4').focus();
            }
        } else if (type == 4) {
            if (value.keyCode == 13) {
                this.smsVerify()
            }
        } 
    }

    // Function to verify otp
    smsVerify() {
        this.code =  this.otp.one + this.otp.two + this.otp.three + this.otp.four ;
        let data = {
            "eventExternal":
                {
                    "name":"request_sms_verify",
                    "key":"mykey"
                },
        "transferObjectMap":{"gatewayrequest":
                {
                "code":this.code,
                    "token":localStorage.getItem('token'),
                    "clientTime":  new Date().getTime()

                }
            }
        }
            //console.log(this.otp.one+this.otp.two+this.otp.three+this.otp.four)
            this.spinnerService.show();
            this.server.postApi('', data,0).subscribe(response => {
                this.spinnerService.hide();
                if (response.transferObjectMap.statusCode == 200) {
                    clearInterval(this.const)
                    //this.appC.showSuccToast(response.transferObjectMap.message);
                    if(this.sms11 == "sms") {
                        this.toggle.google = false;
                        this.req_user();
                        
                    }

                    else {
                        this.request_google();
                    }
                } else if(response.transferObjectMap.statusCode == 403){
                        this.appC.showErrToast(response.transferObjectMap.message); 
                        this.header.tokenExpire()
                } else  {
                            this.appC.showErrToast(response.transferObjectMap.message);   
                            this.otp = { one: "", two: "", three: "", four: "" };    
                            this.googleEnabled = localStorage.getItem('googleEnabled');
                            this.smsEnabled = localStorage.getItem('smsEnabled');
                            if(this.googleEnabled == '1' || this.googleEnabled == 'true' )  {
                            this.toggle.google = true;
                            this.toggle.sms = false;
                            }   else {
                                    this.toggle.google = false;
                                    this.toggle.sms = true;
                                }                 
                }
            }, error => {
                this.spinnerService.hide();
                this.appC.showErrToast('Something went wrong');
                this.googleEnabled = localStorage.getItem('googleEnabled');
                this.smsEnabled = localStorage.getItem('smsEnabled');
                    if(this.googleEnabled == '1' || this.googleEnabled == 'true' )  {
                        this.toggle.google = true;
                        this.toggle.sms = false;
                    }   else {
                            this.toggle.google = false;
                            this.toggle.sms = true;
                        }      
            });
    
    }


    handleFileInput(event) {
            
        var self = this;
        self.fileData = "";
        self.fileName = "";

        if(event.target.files && event.target.files[0]){
            var type = event.target.files[0].type;
            if(type === 'image/png' || type === 'image/jpg') {
                self.authObj.docFile = event.target.files[0].name;
                this.fileName = self.authObj.docFile;
                var reader = new FileReader()
                reader.onload = (e) =>  {
                    self.fileData = e.target['result'].substring(22);
                    //console.log("fileURL -> "+self.fileData);
                }
                reader.readAsDataURL(event.target.files[0]);
            } else if(type === 'application/pdf') {
                self.authObj.docFile = event.target.files[0].name;
                this.fileName = self.authObj.docFile;
                var reader = new FileReader()
                reader.onload = (e) =>  {
                    self.fileData = e.target['result'].substring(28);
                    
                }
                reader.readAsDataURL(event.target.files[0]);
            } else if(type === 'image/jpeg') {
                self.authObj.docFile = event.target.files[0].name;
                this.fileName = self.authObj.docFile;
                var reader = new FileReader()
                reader.onload = (e) =>  {
                    self.fileData = e.target['result'].substring(23);
                    
                }
                reader.readAsDataURL(event.target.files[0]);
            } else {
                this.appC.showErrToast("Select only pdf, jpg, jpeg and png file.");
                self.authObj.docFile = "";
                self.fileData = "";
            }
        }

    }

    resendOtp() {
        clearInterval(this.const)
        this.seconds= 59;
        this.otpSend();
    }

    otpSend() {
        this.myTimer();
        let data =   {
            "eventExternal": {
                    "name":"request_sms_auth",
                    "key":"mykey"
            },
            "transferObjectMap": {
                "gatewayrequest": {
                        "phoneCountryCode":this.phoneCountryCode,
                        "phone":this.phoneNo,
                        "token":localStorage.getItem('token')
                }
            }
        }
        
        this.spinnerService.show();
        this.server.postApi('', data,0).subscribe(response => {
            this.spinnerService.hide();
            if (response.transferObjectMap.statusCode == 200) {
                //this.appC.showSuccToast(response.transferObjectMap.message);
                this.smsVerify();
        
            }  else if(response.transferObjectMap.statusCode == 403){
                this.appC.showErrToast(response.transferObjectMap.message); 
                this.header.tokenExpire()
            } else {
                this.appC.showErrToast(response.transferObjectMap.message);
                this.googleEnabled = localStorage.getItem('googleEnabled');
                this.smsEnabled = localStorage.getItem('smsEnabled');
                if(this.googleEnabled == '1' || this.googleEnabled == 'true' )  {
                    this.toggle.google = true;
                    this.toggle.sms = false;
                }   else {
                        this.toggle.google = false;
                        this.toggle.sms = true;
                    }       
                
            }
        }, error => {
            this.spinnerService.hide();
            this.appC.showErrToast('Something went wrong');
            this.googleEnabled = localStorage.getItem('googleEnabled');
                this.smsEnabled = localStorage.getItem('smsEnabled');
                if(this.googleEnabled == '1' || this.googleEnabled == 'true' )  {
                    this.toggle.google = true;
                    this.toggle.sms = false;
                }   else {
                        this.toggle.google = false;
                        this.toggle.sms = true;
                    }       
        });
    } 


    changeToggle(val) {
        if(val == 1) {
            this.google11 = 'google' ;
            this.sms11 = '' ;
            console.log("google---"+this.toggle.google)
            console.log("sms---"+this.toggle.sms)
        //this.toggle.google = true;
            //this.toggle.sms = false;
            if(!this.toggle.google)
                this.otpVerification();

            else {
                
                this.appC.showErrToast('Google auth already enabled');
                this.mytoggle(val);                
            }       
        }
        
      else {
            this.sms11 = 'sms' ;
            this.google11 = '' ;
            console.log("google---"+this.toggle.google)
            console.log("sms---"+this.toggle.sms)
            //this.toggle.sms = true;
            //this.toggle.google = false;
        
        if(!this.toggle.sms)
            {this.qrCode = {Code1:""} 
            $('#googleAuth').modal({
                backdrop: 'static',
                keyboard: false  // to prevent closing with Esc button (if you want this too)
            })
        } else {
            this.appC.showErrToast('sms auth already enabled');
            this.mytoggle(val);
        }

        
      }             
    
    }

    request_google()   {
        this.qrCode = {Code1: ""}
              
        let data= {
            "eventExternal": {
              "name": "request_google_auth",
              "key": "mykey"
            },
            "transferObjectMap": {
              "gatewayrequest": {
                "token": localStorage.getItem('token'),
              }
            }
          }

        this.spinnerService.show();
        this.server.postApi('', data,0).subscribe(response => {
            this.spinnerService.hide();
            if (response.transferObjectMap.statusCode == 200) {   
                    this.qrCode = {Code1:""} 
                    $('#googleAuth').modal({
                    backdrop: 'static',
                    keyboard: false  // to prevent closing with Esc button (if you want this too)
                    })
                    //this.appC.showSuccToast("Qr Code generated successfully");
                    
                    localStorage.setItem('key',response.transferObjectMap.secretKey);
                    this.myAngularxQrCode = "data:image/png;base64," + response.transferObjectMap.QRData;
            }  else if(response.transferObjectMap.statusCode == 403){
                    this.appC.showErrToast(response.transferObjectMap.message); 
                    this.header.tokenExpire()
            } else {
                    this.appC.showErrToast(response.transferObjectMap.message);
                    this.googleEnabled = localStorage.getItem('googleEnabled');
                    this.smsEnabled = localStorage.getItem('smsEnabled');
                    if(this.googleEnabled == '1' || this.googleEnabled == 'true' )  {
                        this.toggle.google = true;
                        this.toggle.sms = false;
                    }
                    else {
                        this.toggle.google = false;
                        this.toggle.sms = true;
                    }
                }
        }, error => {
            this.spinnerService.hide();
            this.appC.showErrToast('Something went wrong');
            this.googleEnabled = localStorage.getItem('googleEnabled');
                    this.smsEnabled = localStorage.getItem('smsEnabled');
                    if(this.googleEnabled == '1' || this.googleEnabled == 'true' )  {
                        this.toggle.google = true;
                        this.toggle.sms = false;
                    }
                    else {
                        this.toggle.google = false;
                        this.toggle.sms = true;
                    }
        });
    }

    submitDoc() {
    $('#UploadDoc').modal('hide');
    this.obj = {
      docName: this.uploadForm.get('docName').value ,
      docNum: this.uploadForm.get('docNum').value,
      attachmentData: this.fileData
    }

    /**KYC API */
    let data = {
      "eventExternal": {
        "name": "request_kyc",
        "key": "mykey"
      },
      "transferObjectMap": {
            "gatewayrequest": { 
                "kyc":
                        [{
                            "name": this.obj.docName,
                            "number": this.obj.docNum,
                            "attachment": this.obj.attachmentData,
                        }], "token": localStorage.getItem("token"),
            }
        }
    }
      console.log("data*** -> ",JSON.stringify(data))
      this.spinnerService.show();
      this.server.postApi('', data,0).subscribe(response => {
          this.spinnerService.hide();
          if (response.transferObjectMap.statusCode == 200) {
              this.appC.showSuccToast(response.transferObjectMap.message)
              this.checkKycStatus() ;
              
          } else if(response.transferObjectMap.statusCode == 403)   {
                this.appC.showErrToast(response.transferObjectMap.message); 
                this.header.tokenExpire();
          } else {
              this.appC.showErrToast(response.transferObjectMap.message);
          }
      }, error => {
          this.spinnerService.hide();
          this.appC.showErrToast('Something went wrong');
      });
    }

    /** To check Kyc status */
    checkKycStatus() {
      
        let kycDetails= { 
            "eventExternal": { 
                "name":"request_kyc_list", 
                "key":"mykey" 
            }, 
            "transferObjectMap":{
                  "gatewayrequest": {
                    "token":localStorage.getItem('token')
                  } 
            } 
        } 
        this.spinnerService.show();
        this.server.postApi('', kycDetails,0).subscribe(response => {
        this.spinnerService.hide();
        if (response.transferObjectMap.statusCode == 200) {
          //this.appC.showSuccToast(response.transferObjectMap.message);  
          this.kyc = response.transferObjectMap.result;    
          if(this.kyc.length===0){
            this.kycToken=true
          }
          else
            this.kycToken=false
  
        } else {
          this.appC.showErrToast(response.transferObjectMap.message);
        }
        }, error => {
          this.appC.showErrToast('Something went wrong');
          this.spinnerService.hide();
        }) 
        
    }
   
    
   
        
       

    

    

    uploadBtn() {
        this.uploadForm.reset();
        $('#UploadDoc').modal({backdrop: 'static',keyboard: false});
    }

    /** to get the value of field  */
    get docName(): any {
        return this.uploadForm.get('docName');
    }
    get docNum(): any {
    return this.uploadForm.get('docNum');
    }
    get attachmentNum(): any {
        return this.uploadForm.get('attachmentNum');
    }
    qrVerify() {
        if(this.qrCode.Code1==''){
            this.appC.showErrToast("Enter Qr Code");

        }   else {
                let data= {
                    "eventExternal":
                        {
                            "name":"request_google_verify",
                            "key":"mykey"
                        },
                    "transferObjectMap":  {    
                        "gatewayrequest":
                                {
                                    "otp": this.qrCode.Code1,
                                    "secretKey":localStorage.getItem('key'),
                                    "token":localStorage.getItem('token'),
                                    "clientTime":  new Date().getTime()

                                }
                        }
                }

                this.spinnerService.show();
                this.server.postApi('', data,0).subscribe(response => {
                    this.spinnerService.hide();
                    if (response.transferObjectMap.statusCode == 200) {
                        $('#googleAuth').modal('hide')
                        //this.appC.showSuccToast("Qr Code verified successfully");
                        if(this.google11 == 'google')   {
                            this.toggle.sms = false;
                            this.req_user();
                        }   else
                                this.otpVerification() ;


                        
            
                    }  else if(response.transferObjectMap.statusCode == 403){
                        this.appC.showErrToast(response.transferObjectMap.message); 
                        this.header.tokenExpire()
                    } else {
                        this.qrCode = {Code1:""} 
                        this.appC.showErrToast("Qr Code not verified");
                        this.googleEnabled = localStorage.getItem('googleEnabled');
                        this.smsEnabled = localStorage.getItem('smsEnabled');
                        if(this.googleEnabled == '1' || this.googleEnabled == 'true' )  {
                            this.toggle.google = true;
                            this.toggle.sms = false;
                        }
                        else {
                            this.toggle.google = false;
                            this.toggle.sms = true;
                        }
                                    
                    }
                }, error => {
                    this.spinnerService.hide();
                    this.appC.showErrToast('Something went wrong');
                    this.googleEnabled = localStorage.getItem('googleEnabled');
                        this.smsEnabled = localStorage.getItem('smsEnabled');
                        if(this.googleEnabled == '1' || this.googleEnabled == 'true' )  {
                            this.toggle.google = true;
                            this.toggle.sms = false;
                        }
                        else {
                            this.toggle.google = false;
                            this.toggle.sms = true;
                        }
                });
            }
     
    }

    /**request user setting */
    req_user() {
        
        let data = {
            "eventExternal": {
            "name": "request_user_setting",
            "key": "mykey"
            },
            "transferObjectMap": {
            "gatewayrequest": {
                "google2faEnabled": this.toggle.google,
                "smsEnabled": this.toggle.sms,
                "token": localStorage.getItem('token')
            }
            }
        }
            console.log("data -> "+JSON.stringify(data));
            this.spinnerService.show();
            this.server.postApi('',data,0).subscribe((succ) => {
            this.spinnerService.hide();
            if(succ.transferObjectMap.statusCode == 200) {
                localStorage.setItem('googleEnabled',succ.transferObjectMap.gatewayrequest.google2faEnabled);
                localStorage.setItem('smsEnabled',succ.transferObjectMap.gatewayrequest.smsEnabled)
                this.appC.showSuccToast(succ.transferObjectMap.message);
            }  else if(succ.transferObjectMap.statusCode == 403){
                this.appC.showErrToast(succ.transferObjectMap.message); 
                this.header.tokenExpire()
            } else {
                this.appC.showErrToast(succ.transferObjectMap.message);
            }
        }, (err) => {
                this.spinnerService.hide();
        });
    }

    /**to send otp for verification */
    otpVerification() {
        let data =   {
            "eventExternal": {
                "name":"request_sms_auth",
                "key":"mykey"
            },
            "transferObjectMap": {
                "gatewayrequest": {
                    "phoneCountryCode":this.phoneCountryCode,
                    "phone":this.phoneNo,
                    "token":localStorage.getItem('token')
                }
            }
        }    
        this.spinnerService.show();
        this.server.postApi('', data,0).subscribe(response => {
            this.spinnerService.hide();
            if (response.transferObjectMap.statusCode == 200) {
                this.appC.showSuccToast("OTP sent successfully.");
                this.otp = { one: "", two: "", three: "", four: "" };
                this.seconds = 59;
                
                this.myTimer();
                $('#otpmodal').modal({
                    backdrop: 'static',
                    keyboard: false  // to prevent closing with Esc button (if you want this too)
                })
            } else if(response.transferObjectMap.statusCode == 403){
                this.appC.showErrToast(response.transferObjectMap.message); 
                this.header.tokenExpire()
            } else {
                this.appC.showErrToast(response.transferObjectMap.message);
                this.googleEnabled = localStorage.getItem('googleEnabled');
                this.smsEnabled = localStorage.getItem('smsEnabled');
                if(this.googleEnabled == '1' || this.googleEnabled == 'true' )  {
                    this.toggle.google = true;
                    this.toggle.sms = false;
                }   else {
                        this.toggle.google = false;
                        this.toggle.sms = true;
                    }  
                
            }
        }, error => {
            this.spinnerService.hide();
            this.appC.showErrToast('Something went wrong');
            this.googleEnabled = localStorage.getItem('googleEnabled');
                this.smsEnabled = localStorage.getItem('smsEnabled');
                if(this.googleEnabled == '1' || this.googleEnabled == 'true' )  {
                    this.toggle.google = true;
                    this.toggle.sms = false;
                }   else {
                        this.toggle.google = false;
                        this.toggle.sms = true;
                    }  
        });
    }

    closeModal() {
        $('#otpmodal').modal('hide');
        $('#googleAuth').modal('hide');
        this.googleEnabled = localStorage.getItem('googleEnabled');
        this.smsEnabled = localStorage.getItem('smsEnabled');
        if(this.googleEnabled == '1' || this.googleEnabled == 'true' )  {
            this.toggle.google = true;
            this.toggle.sms = false;
        }
        else {
            this.toggle.google = false;
            this.toggle.sms = true;
        }
        
    }

    

     


}
