import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewBlogDetailComponent } from './view-blog-detail.component';

describe('ViewBlogDetailComponent', () => {
  let component: ViewBlogDetailComponent;
  let fixture: ComponentFixture<ViewBlogDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewBlogDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewBlogDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
