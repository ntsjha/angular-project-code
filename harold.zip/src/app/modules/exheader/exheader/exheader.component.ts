import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ServerService } from '../../../server.service';
import { AppComponent } from '../../../app.component';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { Observable, Subject } from 'rxjs';
declare var $: any;

@Component({
    selector: 'app-exheader',
    templateUrl: './exheader.component.html',
    styleUrls: ['./exheader.component.css']
})
export class ExheaderComponent implements OnInit {

    image: any;
    name: any;
    flag: boolean;
    private subject = new Subject<any>();

    constructor(private server: ServerService, public appC: AppComponent, private spinnerService: Ng4LoadingSpinnerService, private router: Router) { 
    }

    ngOnInit() {
        window.scrollTo(0,0);
        this.getprofile();
        this.check();
      
    }

    /** Function for call event in child component */
    fireToChild(): Observable<any> {
        return this.subject.asObservable();
    }

    /** Function for go to page */
    goToPage(type) {
        switch (type) {
            case 0:
                this.router.navigate(['']);
                break;
            case 1:
                this.router.navigate(['login']);
                break;
            case 2:
                this.router.navigate(['signup']);
                break;
            case 3:
                this.router.navigate(['wallet']);
                break;
            case 4:
                this.router.navigate(['news']);
                break;
            case 5:
                this.router.navigate(['aboutus']);
                break;
            case 6:
                $('#logout').modal({backdrop: 'static',keyboard: false })
                break;
            case 7:
                this.router.navigate(['affiliate']);
                break;
            case 8:
                this.router.navigate(['exchange']);
                break;
            case 9:
                this.router.navigate(['PrivacyPolicy']);
                break;
            case 10:
                this.router.navigate(['TermsAndConditions']);
                break;
                
        }
    }


    /**Function to check header */
    check() {
        if (localStorage.getItem('token'))
            this.flag = true;
        else
            this.flag = false;
    }

    profile() {
        this.router.navigate(['profile'])
    }

    logout() {
        localStorage.clear();
        this.check();
        $('#logout').modal('hide');
        this.subject.next({ text: "logout" });
        this.appC.showSuccToast('You have logout successfully.')
        this.router.navigate(['']);
       
    }

    getprofile() {
        if(localStorage.getItem('token')){
            this.spinnerService.show();
            this.server.getApi('account/my-account' ).subscribe((res) => {
                this.spinnerService.hide();
                if (res.status == 200) {
                    this.check();
                    this.name = res.data.firstName;  
                    this.image = res.data.imageUrl;
                    localStorage.setItem('userId', res.data.userId);
                }
                else {
                    this.spinnerService.hide();
                    this.appC.showErrToast(res.message);
                }
    
            }, (err) => {
                this.spinnerService.hide();
                this.appC.showErrToast('Something went wrong')
            })
        }  
    }

}
