import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppComponent } from '../../../app.component';
import { ServerService } from '../../../service/server.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner'; ``
import { HeaderComponent } from '../../header/header/header.component';
import { Observable } from '../../../../../node_modules/rxjs';
import { FormControl, FormGroup, Validators } from '@angular/forms';

declare var $: any;

@Component({
    selector: 'app-twofa',
    templateUrl: './twofa.component.html',
    styleUrls: ['./twofa.component.css']
})
export class TwofaComponent implements OnInit {
    otp = { one: "", two: "", three: "", four: "" };
    qrCode = { Code1: "" }
    page: string;
    key: string;
    myAngularxQrCode: string = null;
    phone: any;
    myCode: any;
    seconds: number = 59;
    const: any;
    code: string;
    checkbox: boolean;
    twoForm: FormGroup;
    constructor(private router: Router, private appC: AppComponent, private server: ServerService, private spinnerService: Ng4LoadingSpinnerService, public header: HeaderComponent) { }

    ngOnInit() {
        window.scrollTo(0, 0);
        this.checkInputs();
        let url = window.location.href.split('/');
        this.page = url[url.length - 1];
        //this.verifyUser();
        //this.getprofile();
console.log('page=',this.page )
    }

    /** Function to validate form inputs */
    checkInputs() {
        this.twoForm = new FormGroup({
            checkbox1: new FormControl('', [Validators.required]),
        });
    }

    get checkbox1(): any {
        return this.twoForm.get('checkbox1');
    }


    getprofile() {
        this.spinnerService.show();
        this.server.getApi("?key=" + this.page + "USER", 0).subscribe((succ) => {
            this.spinnerService.hide();
            this.phone = succ[0].phone;
            this.myCode = succ[0].phoneCountryCode;
        }, (err) => {
            this.spinnerService.hide();
        });
    }

    googleModal() {
        this.qrCode = { Code1: "" }
        // let data = {
        //     "eventExternal": {
        //         "name": "request_google_auth",
        //         "key": "mykey"
        //     },
        //     "transferObjectMap": {
        //         "gatewayrequest": {
        //             "token": this.page,
        //         }
        //     }
        // }
        this.spinnerService.show();
        this.server.getApi('account/google-auth', this.page).subscribe(response => {
            this.spinnerService.hide();
            if (response.status == 200) {
                $('#googlemodal').modal({ backdrop: 'static', keyboard: false });
                this.key = response.body.data.secretKey;

                this.myAngularxQrCode = response.body.data.qrCode;
            } else {
                this.appC.showErrToast(response.body.message);
            }
        }, error => {
            this.spinnerService.hide();
            this.appC.showErrToast(error.error.message);
        });
    }

    qrVerify() {
        let data = {
            // "eventExternal":{
            //     "name":"request_google_verify",
            //     "key":"mykey"
            // },
            // "transferObjectMap":  {    
            //     "gatewayrequest":{
            //         "otp": this.qrCode.Code1,
            //         "secretKey":this.key,
            //         "token":this.page,
            //         "clientTime":  new Date().getTime()
            //     }
            // }
            "code": this.qrCode.Code1,
            "secretKey": this.key
        }
        this.spinnerService.show();
        this.server.postApi('account/verify-google-code', data, this.page).subscribe(response => {
            this.spinnerService.hide();
            if (response.body.status == 200) {
                this.appC.showSuccToast(response.body.message);
                $('#googlemodal').modal('hide')
                localStorage.setItem('token', this.page)
                //localStorage.setItem('userId',response.transferObjectMap.result[0].userId)
                this.header.checkLogin();
                let data = {
                    messageType: "userUpdated",
                    token: this.page
                }
                //this.server.wsExchange.send(JSON.stringify(data));
                this.router.navigateByUrl('header/exchange-pair');
            } else {
                this.qrCode = { Code1: "" }
                this.appC.showErrToast(response.body.message);

            }
        }, error => {
            this.spinnerService.hide();
            this.appC.showErrToast(error.error.message);
        });

    }


    login() {
        this.spinnerService.show();
        this.server.getApi('account/skip-twoFa', this.page).subscribe(res => {
            this.spinnerService.hide();
            if (res.status == 200) {
                localStorage.setItem('token', this.page);
                this.header.checkLogin();
                this.router.navigateByUrl('header/exchange-pair');
            }
            else {
                this.appC.showErrToast(res.body.message)
            }
        }, err => {
            this.spinnerService.hide();
        })
    }

}
