import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, NavigationEnd } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ServiceService } from 'src/app/Shared/service.service';
import { ToastrService } from 'ngx-toastr';

declare var $: any
@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent implements OnInit {
 
  dynamic: any;
  id:any

  constructor(private route: Router, private spinner: NgxSpinnerService, private service: ServiceService, private toastr: ToastrService) { }

  ngOnInit() {
    this.dynamic=this.route.url.split('/')
    this.id=this.dynamic[1]?this.dynamic[1]:''
    console.log('urllll==>',)


    this.route.events
      .subscribe((event) => {
          

        if (event instanceof NavigationEnd) {
          
          this.dynamic = event.url.split('/');
          this.id=this.dynamic[1]?this.dynamic[1]:''
          console.log("id ====>>", this.dynamic,this.id)
        }
      });
  }
  logout() {
    localStorage.removeItem('key');
    console.log("==========>>>?>", localStorage.getItem('key'))
    $('#side_signout_modal').modal('hide')
    this.route.navigate(['/login']);
    this.service.showSuccess("Logout has been successfully.")

  }

}
