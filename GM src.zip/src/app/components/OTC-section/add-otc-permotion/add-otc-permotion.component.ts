import { Component, OnInit } from '@angular/core';
import { IMyDpOptions } from 'mydatepicker';
import { ServiceService } from 'src/app/service/service.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { AppComponent } from 'src/app/app.component';
import { CookieService } from 'ngx-cookie-service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';

declare var $: any;
@Component({
  selector: 'app-add-otc-permotion',
  templateUrl: './add-otc-permotion.component.html',
  styleUrls: ['./add-otc-permotion.component.css']
})
export class AddOTCPermotionComponent implements OnInit {

  addPromotionForm: FormGroup;
  subscription: any;
  startDateMax: any = null;
  todayEndDate: any = new Date();
  todayDate: any = new Date();

  public fromPickerOptions: IMyDpOptions = {
    disableUntil: { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() - 1 },
    dateFormat: 'dd/mm/yyyy',
  };
  public toPickerOptions: IMyDpOptions = {
    disableUntil: { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() - 1 },
    dateFormat: 'dd/mm/yyyy',
  };
  apiResponse: any = { status: 1335 };
  userIp: any;

  constructor(
    private service: ServiceService,
    private router: Router,
    private spinner: NgxSpinnerService,
    private appC: AppComponent,
    private cookie: CookieService
  ) {
    this.subscription = this.service.authVerify.subscribe(val => {
      if (val == 'add-promotion') {
        this.addPromotion();
        this.service.authVerify.next('false');
      }
    });
  }

  ngOnInit() {
    this.form();
    window.scrollTo(0, 0);
    this.userIp = (this.cookie.get('userInfo')) ? JSON.parse(this.cookie.get('userInfo')) : this.service.initialUserInfo;
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  form() {
    this.addPromotionForm = new FormGroup({
      promotionName: new FormControl('', [Validators.required, Validators.minLength(2), Validators.maxLength(255)]),
      fromDate: new FormControl('', [Validators.required]),
      toDate: new FormControl('', [Validators.required]),
      referPoint: new FormControl('', [Validators.required, Validators.pattern(/^[0-9]*$/)]),
      KYCPoint: new FormControl('', [Validators.required, Validators.pattern(/^[0-9]*$/)]),
      earnPoint: new FormControl('', [Validators.required, Validators.pattern(/^(100(?:\.00)?|0(?:\.\d\d)?|\d?\d(?:\.\d\d)?)$/)]),
      tradingperiod: new FormControl('', [Validators.required]),
      totalwalletamount: new FormControl('', [Validators.required]),
      totaltrading: new FormControl('', [Validators.required]),
      otcperiod: new FormControl('', [Validators.required,Validators.pattern(/^[0-9]*$/)]),
    });
  }


  /** Function to verify google authentication */
  verifyGoogleAuth() {
    if (this.addPromotionForm.invalid) {
      return;
    }
    this.appC.google = { one: '', two: '', three: '', four: '', five: '', six: '' };
    this.appC.response = { 'message': '' };
    this.service.googleAuthCalledFrom = 'add-promotion';
    $('#google-auth-modal').modal({ keyboard: false, backdrop: 'static' });

  }

  addPromotion() {
    this.spinner.show();
    if (this.addPromotionForm.invalid) {
      this.spinner.hide();
      return;
    }
    const apireq = {
      promotionName: this.service.encrypt(this.addPromotionForm.value.promotionName),
      startDate: this.addPromotionForm.value.fromDate ? this.service.encrypt(new Date(this.addPromotionForm.value.fromDate).getTime()) : null,
      endDate: this.addPromotionForm.value.toDate ? this.service.encrypt(new Date(this.addPromotionForm.value.toDate).getTime()) : null,
      referFriendPoint: this.service.encrypt(this.addPromotionForm.value.referPoint),
      completeKycPoint: this.service.encrypt(this.addPromotionForm.value.KYCPoint),
      tradingPercentage: this.service.encrypt(this.addPromotionForm.value.earnPoint),
      languageShortName: this.service.encrypt('en'),
      ipAddress: this.userIp.ip,
      location: this.userIp.city + ',' + this.userIp.country_name,
    };
    this.service.postMethod('rewards/marketing/add-promotion', apireq, 1).subscribe(success => {
      this.apiResponse = success;
      this.spinner.hide();
      if (success.status === 1335) {
        this.router.navigate(['/promotion-management']);
      } else {
        if (success.status === 1363 || success.status === 1450) {
          $('#alreadyPresentModal').modal({ backdrop: 'static', keyboard: false });
        }
      }
    }, error => {
      this.spinner.hide();
      this.apiResponse.status = error.error.status;
      this.apiResponse.message = error.error.message;
    });
  }

  fromDateChanged(event) {
    if (event.epoc) {
      this.toPickerOptions = {
        disableUntil: { year: new Date((event.epoc * 1000)).getFullYear(), month: new Date((event.epoc * 1000)).getMonth() + 1, day: new Date((event.epoc * 1000)).getDate() - 1 }
      };
    } else {
      this.toPickerOptions = {
        disableUntil: { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() - 1 }
      };
    }
  }

  toDateChanged(event) {
    if (event.epoc) {
      this.fromPickerOptions = {
        disableSince: { year: new Date((event.epoc * 1000)).getFullYear(), month: new Date((event.epoc * 1000)).getMonth() + 1, day: new Date((event.epoc * 1000)).getDate() + 1 }
      };
    } else {
      this.fromPickerOptions = {
        disableSince: { year: 0, month: 0, day: 0 },
      };
    }
  }

  startDateChange() {
    if (this.addPromotionForm.value.fromDate) {
      this.todayEndDate = new Date(this.addPromotionForm.value.fromDate);
    } else {
      this.todayEndDate = new Date();
    }
  }

  endDateChange() {
    if (this.addPromotionForm.value.toDate) {
      this.startDateMax = new Date(this.addPromotionForm.value.toDate);
    } else {
      this.startDateMax = null;
    }
  }

}
