import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, MinLengthValidator } from '@angular/forms';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
 
  availableColors = [{ name: 'Pizza', id: 1, imageSrc: 'assets/img1.jpeg' }, { name: 'Onion', id: 2, imageSrc: 'assets/img1.jpeg' },
  { name: 'Chezze', id: 3, imageSrc: 'assets/img2.jpg' }];
  itemname: any;



  foods = [
    { id: 1, viewValue: 'Normal Crust' },
    { id: 1, viewValue: 'Pan Crust' },
    { id: 2, viewValue: 'Normal Crust' },
    { id: 2, viewValue: 'Pan Crust' },
    { id: 2, viewValue: 'Chizze Bust' },
    { id: 3, viewValue: 'Normal Crust' },
    { id: 3, viewValue: 'Pan Crust' },
    { id: 3, viewValue: 'Chizze Bust' },
    { id: 3, viewValue: 'Extra Bust' }
  ];
  info: any;

  size = [{ name: 'Regular', id: 1 }, { name: 'Medium', id: 2 }, { name: 'Large', id: 3 }];

  select = [];
  order: FormGroup;
  value: 100;
  openform: boolean;
  quantity: any;
  data: any;
  
  dataarray=[];
  id:any;
  message: boolean;
  checkAll: any;
  myCheckbox: any;
  title: String;
  names: any;
  selectedAll: any;
  topping=[];
  allTopping;
  obj: { topping: any[]; pizzaname: any; size: any; crust: any; quantity: any; };
  changeCount: number;
  countt=1;
  counter : number = 0;
  constructor() { 
    this.title = "Select all/Deselect all checkbox - Angular 2";
    this.names = [
      { name: 'Panner', selected: false },
      { name: 'Extra Chezze', selected: false },
      { name: 'Onion', selected: false },
      
    ]
  }

  ngOnInit() {
    this.order = new FormGroup({
      checked: new FormControl(false, []),
      checked1: new FormControl('', []),
      checked2: new FormControl('', []),
      quantity:new FormControl('',[Validators.minLength(1)]),
      crust:new FormControl('',[Validators.required]),
     size:new FormControl(''),
      
    });

    // console.log(this.order.value.quantity)
   
  }

    increment(){
      
      this.counter += 1;
    }
    decrement(){
      if(this.counter>=2)
      this.counter -= 1;
    }

  selectAll(data) {
    
    let result = this.names.filter((m) => { return this.selectedAll })
    .map((m) => { return m.name });
    this.topping=result;
    console.log(this.topping)
    for (var i = 0; i < this.names.length; i++) {
     
  
     
      this.names[i].selected = this.selectedAll;
    
    }
    
  }


  checkIfAllSelected(event,data) {
    let result = this.names.filter((n) => { return n.selected })
    .map((n) => { return n.name });
    this.topping=result;
    console.log(this.topping)
  
    this.selectedAll = this.names.every(function(item:any) {
      
        item.selected == true;
        
      
      })
     
  }

  onClickOpenForm(){
    this.openform=true;  
    }

    
  pitch(event: any) {
    this.quantity=event.value;
   
  }

  onChangeSelect(data){
  //  console.log(data.target.value);
  }



  test(event) {
    console.log(event); 
  }
  All(event) {
    console.log(event); 
  }

  radioChange(event) {
    this.select = [];
    this.data = event.value;
    // console.log(this.data.id);
    for (let i = 0; i < this.foods.length; i++) {
      if (this.data.id == this.foods[i].id) {

        this.select.push({name:this.foods[i].viewValue});
// console.log(this.select);
      }
    }
  }


  onsubmit(){
    console.log(this.topping)
    


    if(this.quantity==null){
    this.message=true;
    }
    else{
      this.message=false;
      this.obj={topping:this.topping,pizzaname:this.itemname,size:this.data.name,crust:this.order.value.crust,quantity:this.order.value.quantity}
      console.log( this.obj)
   

    var count=1;
    for(let i in this.dataarray)
    {  
      
     
      if(this.order.value.crust==this.dataarray[i].crust && this.itemname==this.dataarray[i].pizzaname && this.data.name==this.dataarray[i].size) 
      {
        console.log('==>',this.dataarray[i].topping);
       // this.obj={topping:this.dataarray[i].topping,pizzaname:this.itemname,size:this.data.name,crust:this.order.value.crust,quantity:this.order.value.quantity}
       var temp=this.dataarray[i].quantity
       
    
       this.dataarray[i]=this.obj
       this.dataarray[i].quantity=temp+this.order.value.quantity;
       console.log(temp+this.value);
        count++;
      }
    }
    if(count==1){
      this.dataarray.push(this.obj);
    }    
  }
  this.order.reset();
  this.openform=false;
}

  showdata(item) {
    this.itemname = item;
  }
}
