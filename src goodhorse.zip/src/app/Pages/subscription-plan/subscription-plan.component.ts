import { Component, OnInit } from '@angular/core';
import { AngularFirestore } from '@angular/fire/firestore';
import { ServiceService } from 'src/app/Shared/service.service';
import { ActivatedRoute } from '@angular/router';
import { Subscriptionplan } from 'src/app/Shared/subscriptionplan';

@Component({
  selector: 'app-subscription-plan',
  templateUrl: './subscription-plan.component.html',
  styleUrls: ['./subscription-plan.component.css']
})
export class SubscriptionPlanComponent implements OnInit {
  Subscriptionplan: Subscriptionplan[];
  SubscriptionplanLength: number;
  p: number = 1;
  pageSize = 5;
  total = 0
  searchText: any;
  id: any;
  constructor(private afs: AngularFirestore, private firebaseServ: ServiceService, public route: ActivatedRoute) { }

  ngOnInit() {
    this.getsubscription()


  }

  getsubscription() {
    this.firebaseServ.getSubscriptionplan().subscribe(res => {
      this.Subscriptionplan = res.map(item => {
        return {
          id: item.payload.doc.id,
          ...item.payload.doc.data()
        } as Subscriptionplan
      })
      this.firebaseServ.hideSpinner();
      this.SubscriptionplanLength = this.Subscriptionplan.length
      console.log('DATA===>', this.Subscriptionplan)
    })

  }

  deleteFuction(id) {
    this.id = id
    console.log(this.id)

  }
  onDelete() {
    this.afs.doc('SubscriptionPlan/' + this.id).delete();
    this.firebaseServ.showSuccess('Subscription plan has been deleted successfully.');
    this.getsubscription()

  }

  search() {
    // console.log("Contributor List-->>",this.BreedTypeArr,this.searchText)
    let searchData = []
    searchData = this.Subscriptionplan.filter(x => (x['planType'] == this.searchText));

    console.log("Nts jha -->>", this.Subscriptionplan, searchData)
    this.Subscriptionplan = searchData;
    this.total = this.Subscriptionplan.length;

  }

  page(event) {
    console.log(event);
    this.p = event
  }

}
