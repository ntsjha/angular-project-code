import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
// import { LoginAccountService } from '../core/account/login-account.service';
import { Login } from './login.model';

import { qbEndpoints, qbAccount } from '../core/qb.config';
import { HomePage } from '../home/home';
declare var QB: any;
/**
 * Generated class for the LoginPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
})
export class LoginPage {

  loginForm: FormGroup;
  loginErrorMessage: string;
  submitted: boolean;
  submissionInProgress: boolean;
  userDetails: any;

  constructor( public navCtrl: NavController,private fb: FormBuilder) { }

  /**
   * Login form Submission
   *
   * @param loginValue: (Login) login details
   */
  submitForm(loginValue: Login) {
    this.submitted = true;
    if (this.loginForm.valid) {
      this.submissionInProgress = true;
      QB.init(qbAccount.appId, qbAccount.authKey, qbAccount.authSecret, qbEndpoints);
      QB.createSession({ login: loginValue.userid, password: loginValue.password }, (error, response) => {
        if (response) {
          this.loginErrorMessage = '';
          if (response.user_id) {
            console.log('Login Success');
            sessionStorage.setItem('session', JSON.stringify(response));
            sessionStorage.setItem('pass', loginValue.password);
            sessionStorage.setItem('uname', loginValue.userid);
            this.navCtrl.push(HomePage);
            alert('sucess');
          }
        } else {
          console.log('Login Error');
          alert('Faild');
          this.loginErrorMessage = 'Invalid Credentials';
        }
        this.submissionInProgress = false;
      });
    }
  }

  ngOnInit() {

   if(sessionStorage.getItem('uname') != null){
    this.navCtrl.push(HomePage);

   }

    this.loginForm = this.fb.group({
      'userid': [null, Validators.required],
      'password': [null, Validators.required]
    });
  }


}
