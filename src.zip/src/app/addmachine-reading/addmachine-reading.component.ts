import { Component, OnInit } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { CookieService } from 'ngx-cookie-service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { DomSanitizer } from '@angular/platform-browser';
import { MatIconRegistry } from '@angular/material';
import { Router } from '@angular/router';
import { MainServiceService } from '../main-service.service';
import { FormGroup, Validators, FormControl, FormArray, FormBuilder } from "@angular/forms";
declare var $ : any;
declare var $ : any;
export interface PeriodicElement {
  name: string;
  imageSrc: any;
  startReading: string;
  testing: string;
  endReading: string;
  fuelType: string;
}
const ELEMENT_DATA: PeriodicElement[] = [
  {imageSrc: 'assets/image/petrol.png', name: 'N1', startReading: '988988', endReading: '87282234343', testing: '5 Ltr', fuelType: 'HSD'},
  
];



@Component({
  selector: 'app-addmachine-reading',
  templateUrl: './addmachine-reading.component.html',
  styleUrls: ['./addmachine-reading.component.css']
})
export class AddmachineReadingComponent implements OnInit {
  displayedColumns: string[] = [ 'name', 'startReading','endReading','testing','fuelType',];
  dataSource = ELEMENT_DATA;
  displayMode: number;
  addmachinereadingForm: FormGroup;
  machineData: any;
  data: any;
  constructor(sanitizer: DomSanitizer,private service:MainServiceService,
    iconRegistry: MatIconRegistry,  public spinner:Ng4LoadingSpinnerService,public router:Router) { }

  ngOnInit() {
    this.addPetrolPumpFormMethod();
    this.getmachinereadingdata();
  }
  addPetrolPumpFormMethod() {

    this.addmachinereadingForm = new FormGroup({
      nozzleStartReading: new FormControl("", [Validators.required]),
      nozzleEndReading: new FormControl("", [Validators.required, ]),
      nozzleTesting: new FormControl("", [Validators.required, Validators.maxLength(100),]),
      
      });
  }


  
  getmachinereadingdata(){

    let petrolpumpid = {
     "petrolPumpId": localStorage.getItem('petrolpump_data'),
     "pageNumber":"2"	
     
   }
    console.log(petrolpumpid)
     this.service.post('user/getMachineReading',petrolpumpid,1).subscribe(
       res => {
         console.log(res);
            this.spinner.hide();
         if (res["responseCode"] == 200) {
           this.machineData = res["result"].success.docs;
             console.log('DATA===>', this.machineData)
          
             console.log('PAGENO.===>', res["result"].success.pages)
         
         }      
    }, err=>{
      this.spinner.hide();
      console.log(err);
    })
   }
  
  addmachine(){
    let obj: any = {};
    let modifyPetrolPumpData=[];
    for (let i = 0; i <  this.machineData.length; i++) {
    // console.log('machinedata', this.machineData[i].machines[0]._id);
    
      for(let j=0; j< this.machineData[i].machines.length; j++)
     {

      obj.machineId = this.machineData[i].machines[j]._id;
      // obj.machineName = this.machineData[i].machines[j].machineName;

    //    let machines = {
      
    //     _id:this.machineData[i].machines[j]._id,

    //     machineName: this.machineData[i].machines[j].machineName,

    // };
    for(let k=0;k<this.machineData[i].machines[j].nozzles.length;k++ )
    {
      obj.nozzleId = this.machineData[i].machines[j].nozzles[k]._id
      obj.nozzleName = this.machineData[i].machines[j].nozzles[k].nozzleName;
      obj.nozzleFuelType = this.machineData[i].machines[j].nozzles[k].fuelType
     
    }

  }
   }
   obj.nozzleStartReading=this.addmachinereadingForm.value.nozzleStartReading
   obj.nozzleEndReading=this.addmachinereadingForm.value.nozzleEndReading
   obj.nozzleTesting=this.addmachinereadingForm.value.nozzleTesting
   obj.machineStartReading='11',
   obj.machineEndReading="2222",
   obj.machineTesting='5'
   obj.petrolPumpId= localStorage.getItem('petrolpump_data'),

   console.log('modifydata-->',obj)

    console.log(this.addmachinereadingForm.value)
    
     if (!navigator.onLine) {
       this.service.showWarning('Please check internet conectivity');
       return;
     }
  
     this.spinner.show();
     let data = this.addmachinereadingForm.value    
     data.docs=modifyPetrolPumpData
     data.petrolPumpId= localStorage.getItem('petrolpump_data'),

console.log('alldata-->',data)
     
     this.service.post('user/addMachineReading ', obj, 1).subscribe(res => {
     this.spinner.hide();
     if (res.responseCode === 200) {
       this.service.showSuccess(res['responseMessage']);
       // this.router.navigate(['login']);
       console.log('res',res);
       // this.otpModal();
     } else {
       this.service.showWarning(res.responseMessage);
     }
     console.log('res ===>>>', res);
     }, err => {
       this.spinner.hide();
       this.service.showError('Something went wrong');
     });
   }
}
