import { Component, OnInit } from '@angular/core';
import { ServerService } from '../../../service/server.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { AppComponent } from '../../../app.component';
import { HeaderComponent } from '../../header/header/header.component';

@Component({
  selector: 'app-withdrawverify',
  templateUrl: './withdrawverify.component.html',
  styleUrls: ['./withdrawverify.component.css']
})
export class WithdrawverifyComponent implements OnInit {
  page: string;
  uniquekey: string;
  message: any;
  display: boolean;

  constructor(private appC: AppComponent, private spinnerService: Ng4LoadingSpinnerService, private server: ServerService, public header:HeaderComponent) { }

  ngOnInit() {
      let url = window.location.href.split('/');
      this.page = url[url.length - 1];
      console.log(this.page.split('_')[0])
      this.uniquekey = this.page.split('_')[1].split('#')[0];
      console.log(this.uniquekey)
      if(this.page.split('_')[1].split('#')[1] == "1") {
        this.rejectWithdraw();
      } else {
        this.acceptWithdraw();
      }
  }

  acceptWithdraw() {
    let data = {
      "eventExternal":{
        "name":"request_withdraw",
        "key":"mykey"
      },
      "transferObjectMap": {
        "gatewayrequest": {
          "isWithdraw":'true',
          "token": this.page.split('_')[0],
          "uniqueKey": this.uniquekey
        }
      } 
    }
    this.spinnerService.show();
    this.server.postApi('',data,0).subscribe((res) => {
      this.spinnerService.hide();
      if(res.transferObjectMap.statusCode == 200) {
        this.display = true;
        this.message = res.transferObjectMap.message;
        this.appC.showSuccToast(res.transferObjectMap.message);
      } else {
        this.display = false;
        this.appC.showErrToast(res.transferObjectMap.message);
      }
    }, (err) => {
      this.spinnerService.hide();
    })
  }

  rejectWithdraw() {
    let data = {
        "eventExternal":{
          "name":"request_withdraw_cancel",
          "key":"mykey"
        },
        "transferObjectMap": {
          "gatewayrequest": {
            "token": this.page.split('_')[0],
            "uniqueKey": this.uniquekey
          }
        } 
    }
    this.spinnerService.show();
    this.server.postApi('',data,0).subscribe((res) => {
      this.spinnerService.hide();
      if(res.transferObjectMap.statusCode == 200) {
        this.display = true;
        this.message = res.transferObjectMap.message;
        this.appC.showSuccToast(res.transferObjectMap.message);
      } else {
        this.display = false;
        this.appC.showErrToast(res.transferObjectMap.message);
      }
    }, (err) => {
      this.spinnerService.hide();
    })
  }

}
