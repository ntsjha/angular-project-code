import { ActivatedRoute, Router } from '@angular/router';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { ServiceService } from 'src/app/service/service.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { AppComponent } from 'src/app/app.component';
import { CookieService } from 'ngx-cookie-service';

declare var $: any;

@Component({
    selector: 'app-edit-job',
    templateUrl: './edit-job.component.html',
    styleUrls: ['./edit-job.component.css']
})
export class EditJobComponent implements OnInit, OnDestroy {

    editJobForm: FormGroup;
    paramData: any;
    jobDetail: any;
    subscription: any;
    userIp: any;
    saveApiResponse: any = { status: 815, message: '' };

    constructor(
        private spinner: NgxSpinnerService,
        private service: ServiceService,
        private activatedRoute: ActivatedRoute,
        private route: Router,
        private appC: AppComponent,
        private cookie: CookieService,
    ) {
        this.editJobForm = new FormGroup({
            title: new FormControl('', [Validators.required]),
            editorValue: new FormControl('', [Validators.required]),
            noOfOpenings: new FormControl('', [Validators.required])
        });
        this.subscription = this.service.authVerify.subscribe(val => {
            if (val == 'edit-job') {
                this.editJob();
                this.service.authVerify.next('false');
            }
        });
        this.userIp = (this.cookie.get('userInfo')) ? JSON.parse(this.cookie.get('userInfo')) : this.service.initialUserInfo;
    }

    /** Function to get data values */
    get title(): any {
        return this.editJobForm.get('title');
    }
    get editorValue(): any {
        return this.editJobForm.get('editorValue');
    }
    get noOfOpenings(): any {
        return this.editJobForm.get('noOfOpenings');
    }

    /** Function to send value */
    editJobFormTest(...val) {
        this.editJobForm.controls.title.setValue(val[0]);
        this.editJobForm.controls.editorValue.setValue(val[1]);
        this.editJobForm.controls.noOfOpenings.setValue(val[2]);
        return this.editJobForm.valid;
    }

    ngOnInit() {
        window.scrollTo(0, 0);
        this.getParamData();
    }

    ngOnDestroy() {
        this.subscription.unsubscribe();
    }

    getParamData() {
        this.activatedRoute.params.subscribe(param => {
            this.paramData = param;
            this.getJobData();
        });
    }

    getJobData() {
        this.spinner.show();
        this.service.getMethod(`career/admin/get-job-slug-name?language=${encodeURIComponent(this.service.encrypt(this.paramData.lang))}&contentId=${encodeURIComponent(this.service.encrypt(this.paramData.id))}`, 1).subscribe((success: any) => {
            this.spinner.hide();
            const decryptedData = success.data ? JSON.parse(this.service.decrypt(success.data)) : {};
            if (decryptedData.status === 805) {
                this.editJobForm.patchValue({
                    title: decryptedData.data.title,
                    editorValue: decryptedData.data.description,
                    noOfOpenings: decryptedData.data.noOfOpening
                });
                this.jobDetail = decryptedData.data;
            }
        }, error => {
            this.spinner.hide();
        });
    }

    /** Function to verify google authentication */
    verifyGoogleAuth() {
        this.appC.google = { one: '', two: '', three: '', four: '', five: '', six: '' };
        this.appC.response = { 'message': '' };
        this.service.googleAuthCalledFrom = 'edit-job';
        $('#google-auth-modal').modal({ keyboard: false, backdrop: 'static' });

    }

    /** Function to edit job */
    editJob() {
        if (this.editJobForm.invalid) {
            return;
        }
        this.spinner.show();
        const data = {
            languageShortName: this.service.encrypt(this.service.currLang),
            description: this.service.encrypt(this.editJobForm.value.editorValue),
            noOfOpening: this.service.encrypt(this.editJobForm.value.noOfOpenings),
            title: this.service.encrypt(this.editJobForm.value.title),
            slug: this.service.encrypt(this.jobDetail.slug),
            id: this.service.encrypt(this.jobDetail.id),
            contentId: this.service.encrypt(this.jobDetail.id),
            ipAddress: this.userIp.ip,
            location: this.userIp.city + ', ' + this.userIp.country_name,
        };
        this.service.postMethod('career/admin/edit-job-details', data, 1).subscribe((response: any) => {
            this.spinner.hide();
            const decryptedData = response.data ? JSON.parse(this.service.decrypt(response.data)) : {};
            this.saveApiResponse = response;
            if (decryptedData.status === 815) {
                this.route.navigate(['/jobs']);
            }
            this.spinner.hide();
        }, (error) => {
            this.spinner.hide();
            if (error) {
                if (error.error) {
                    this.saveApiResponse.status = error.error.status;
                    this.saveApiResponse.message = error.error.error;
                } else {
                    this.saveApiResponse.status = 500;
                    this.saveApiResponse.message = 'Something went wrong';
                }
            } else {
                this.saveApiResponse.status = 500;
                this.saveApiResponse.message = 'Something went wrong';
            }
        });
    }


}
