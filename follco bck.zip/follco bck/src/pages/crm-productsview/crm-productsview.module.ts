import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CrmProductsviewPage } from './crm-productsview';

@NgModule({
  declarations: [
    CrmProductsviewPage,
  ],
  imports: [
    IonicPageModule.forChild(CrmProductsviewPage),
  ],
})
export class CrmProductsviewPageModule {}
