import { NgModule } from '@angular/core';
import { ConvertedCurrencyPipe } from './converted-currency/converted-currency';
import { CardMaskPipe } from './card-mask/card-mask';
@NgModule({
	declarations: [ConvertedCurrencyPipe,
    CardMaskPipe],
	imports: [],
	exports: [ConvertedCurrencyPipe,
    CardMaskPipe]
})
export class PipesModule {}
