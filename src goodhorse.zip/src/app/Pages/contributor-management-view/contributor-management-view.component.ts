import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ServiceService } from 'src/app/Shared/service.service';
import { Contributor } from 'src/app/Shared/Contributor.model';

@Component({
  selector: 'app-contributor-management-view',
  templateUrl: './contributor-management-view.component.html',
  styleUrls: ['./contributor-management-view.component.css']
})
export class ContributorManagementViewComponent implements OnInit {
  contiList;
  contentId: any;
  constructor(public route: ActivatedRoute,public serve: ServiceService) {
    // this.contiList=JSON.parse(localStorage.getItem('testView'))
   }

  ngOnInit() {
    this.route.params.subscribe((res)=>{
      console.log('params--->>> ',res.id);
      this.contentId = res.id
    }) 
    this.getSelectedContributor();
  }

  // Get Selector Contributor Data
  getSelectedContributor(){
    this.serve.showSpinner();
this.serve.getContributor().subscribe(res =>{
      console.log(res)
     var contributorList = res.map(item => {
       console.log('Items====>', item)
       return {
         id: item.payload.doc.id,
         ...item.payload.doc.data()

       } as Contributor;
        
     })
     this.contiList = contributorList.filter(x=>(x.id == this.contentId))
     this.serve.hideSpinner();
      console.log(this.contiList)
     });
  }

}
