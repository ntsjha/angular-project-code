import { MainServiceService } from './../../main-service.service';
import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { Router } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm: any;
  error: any;
  constructor(
    public service: MainServiceService,
    private spinnerService: Ng4LoadingSpinnerService,
    public router: Router,
    private cookie: CookieService
  ) { }

  ngOnInit() {
    this.loginFormFunc();
    this.setValues();
  }
  // , Validators.pattern(/^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/i)

  loginFormFunc() {
    this.loginForm = new FormGroup({
      email: new FormControl('', [Validators.required]),
      password: new FormControl('', [Validators.required, Validators.minLength(8)]),
      rememberMe: new FormControl()
    });
  }
  setValues() {
    this.loginForm.patchValue({
      email : this.cookie.get('userName') ? this.service.decrypt(this.cookie.get('userName')) : '',
      password : this.cookie.get('userPassword') ? this.service.decrypt(this.cookie.get('userPassword')) : '',
    });
  }

  // setValues() {
  //   this.loginForm.patchValue({
  //     email: this.cookie.get('userName'),
  //     password: this.cookie.get('userPassword'),
  //   });
  // }

  login() {
    console.log('data ===>>', this.loginForm.value);
    let data = {
      loginId: this.loginForm.value.email.toLowerCase(),
      password: this.loginForm.value.password
    };
    this.spinnerService.show();
    this.service.post('user/login', data, 0).subscribe(res => {
      if (res['responseCode'] === 200) {
        this.service.showSuccess(res['responseMessage']);
        let cypher = this.service.encrypt(res['result']._id);
        if (this.loginForm.value.rememberMe) {
          let userNameCypher = this.service.encrypt(this.loginForm.value.email);
          this.cookie.set('userName', userNameCypher);
          let userPassword = this.service.encrypt(this.loginForm.value.password);
          this.cookie.set('userPassword', userPassword);
        } else {
          this.cookie.set('id', this.service.encrypt(res['result']._id));
          console.log(this.cookie.get('id'));
          this.cookie.set('token', this.service.encrypt(res['result'].token));
        }
        this.router.navigate(['header/user-managment']);
        // this.router.navigate(['petrolPumpMain']);
      } else {
        this.service.showWarning(res['responseMessage']);
      }
      this.spinnerService.hide();
      console.log(res);
    }, error => {
      this.service.showError('Something went wrong');
      console.log(error);
    });
  }

}
