import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { Contributor } from 'src/app/Shared/Contributor.model';
import { ServiceService } from 'src/app/Shared/service.service';
import { AngularFirestore } from '@angular/fire/firestore';

@Component({
  selector: 'app-edit-contributor-management',
  templateUrl: './edit-contributor-management.component.html',
  styleUrls: ['./edit-contributor-management.component.css']
})
export class EditContributorManagementComponent implements OnInit {
   contiList;
   total: any;
   searchText: string = "";
  contributorForm: FormGroup;
  contentId: any;
  constructor(private router: Router, private serve: ServiceService, private afb: AngularFirestore,public route: ActivatedRoute) {
    this.contributorForm = new FormGroup({
      userName: new FormControl('', [Validators.pattern("^[a-zA-Z ]{1,40}$"), Validators.required]),
      email: new FormControl('', [Validators.pattern(/^([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,3})$/)]),
      password: new FormControl('', [Validators.required]),
     // confirmPassword: new FormControl('', Validators.required),
    });
    //  this.contiList=JSON.parse(localStorage.getItem('testEdit'))
   }
  dataobj={'userName':'soeone'}
  ngOnInit() {
    this.route.params.subscribe((res)=>{
      console.log('params--->>> ',res.id);
      this.contentId = res.id
    })       
     
    this.getSelectedContributor();
    // function passwordMatchValidator(g: FormGroup) {
    //   let pass = g.get('password').value;
    //   let confPass = g.get('confirmPassword').value;
    //   if (pass != confPass) {
    //     g.get('confirmPassword').setErrors({ mismatch: true });
    //   } else {
    //     g.get('confirmPassword').setErrors(null)
    //     return null
    //   }
    // }
   
  }

  // Get Selector Contributor Data
  getSelectedContributor(){
    this.serve.showSpinner();
this.serve.getContributor().subscribe(res =>{
      console.log(res)
     var contributorList = res.map(item => {
       console.log('Items====>', item)
       return {
         id: item.payload.doc.id,
         ...item.payload.doc.data()

       } as Contributor;
        
     })
     this.contiList = contributorList.filter(x=>(x.id == this.contentId))
     this.contributorForm.patchValue({
       'userName': this.contiList[0].userName,
       'email': this.contiList[0].email,
       'password': '*********',
     //  confirmPassword: this.contiList.password
     })
     this.serve.hideSpinner();
      console.log(this.contiList)
     });
  }
  editContributor() {
    //db.collection('books').doc('fK3ddutEpD2qQqRMXNW5').get()
    console.log(this.contributorForm.value)
    this.afb.collection('people').doc(this.contiList[0].id).update({
      userName: this.contributorForm.value.userName,
      email:this.contributorForm.value.email,
      password: this.contributorForm.value.password
    });
    this.router.navigate(['/contributorManagement'])
  }

  preventSpace(event){
    if(event.charCode==32 && !event.target.value){
    event.preventDefault()
    } else{
    console.log(event)
    }
    console.log('event',event.charCode)
    }
}
