import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MinimumWithdrawlCryptoComponent } from './minimum-withdrawl-crypto.component';

describe('MinimumWithdrawlCryptoComponent', () => {
  let component: MinimumWithdrawlCryptoComponent;
  let fixture: ComponentFixture<MinimumWithdrawlCryptoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MinimumWithdrawlCryptoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MinimumWithdrawlCryptoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
