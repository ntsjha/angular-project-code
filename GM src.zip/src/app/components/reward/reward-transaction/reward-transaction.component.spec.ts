import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RewardTransactionComponent } from './reward-transaction.component';

describe('RewardTransactionComponent', () => {
  let component: RewardTransactionComponent;
  let fixture: ComponentFixture<RewardTransactionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RewardTransactionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RewardTransactionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
