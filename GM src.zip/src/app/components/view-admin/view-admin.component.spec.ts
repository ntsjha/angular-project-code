import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ViewAdminComponent } from './view-admin.component';
import { SharedModuleModule } from 'src/app/shared-module/shared-module.module';
import { MarketingSidebarComponent } from '../sidebar/sidebar.component';
import { RouterTestingModule } from '@angular/router/testing';
import { RouterModule } from '@angular/router';
import { AppComponent } from 'src/app/app.component';
import { DeviceDetectorService } from 'ngx-device-detector';
declare var $: any;
describe('ViewAdminComponent', () => {
  let component: ViewAdminComponent;
  let fixture: ComponentFixture<ViewAdminComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewAdminComponent, MarketingSidebarComponent, ],
      imports: [SharedModuleModule, RouterModule,
        RouterTestingModule,],
        providers: [AppComponent, DeviceDetectorService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewAdminComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
