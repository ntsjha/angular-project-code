import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ServiceService } from 'src/app/service/service.service';
import { Router } from '@angular/router';
import { DatePipe } from '@angular/common';
import { NgxSpinnerService } from 'ngx-spinner';

declare var $: any;
@Component({
  selector: 'app-countries-list',
  templateUrl: './countries-list.component.html',
  styleUrls: ['./countries-list.component.css']
})
export class CountriesListComponent implements OnInit {
  filterFunction: FormGroup;
  page = 0;
  countryList: any = [];
  currentId: any;
  p = 1;
  currentUser: any;
  total: any;
  addCountryForm: FormGroup;


  csvCountryOptions = {
    fieldSeparator: ',',
    quoteStrings: '"',
    decimalseparator: '.',
    showLabels: true,
    showTitle: true,
    title: 'Country List :',
    useBom: true,
    noDownload: false,
    headers: ['Name', 'Created By', 'Updated At', 'Updated By', 'Status']
  };
  showApiMessage: boolean;
  response: any;
  modalHeading: string;

  constructor(private fb: FormBuilder, private service: ServiceService, private router: Router, public datepipe: DatePipe, private spinner: NgxSpinnerService) { }

  ngOnInit() {
    window.scrollTo(0, 0);
    this.filterFunction = this.fb.group({
      search: [null],
      status: [null],
    });
    this.addCountryForm = this.fb.group({
      countryName: ['', [Validators.required, Validators.maxLength(20), Validators.minLength(2), Validators.pattern(/[a-zA-Z]{2,}/)]],
      countryShortName: ['', [Validators.required, Validators.maxLength(20), Validators.minLength(2), Validators.pattern(/[a-zA-Z]{2,}/)]],
      phoneCode: ['', [Validators.required, Validators.maxLength(4), Validators.minLength(2)]],
    });
    this.service.currentUserInfo.subscribe((response) => {
      this.currentUser = response;
    });
    this.getCountryList();
  }

  convertFormat(time) {
    if (time != null) {
      return this.datepipe.transform(time, 'MM/dd/yyy, hh:mm a');
    }
  }

  exportData() {
    if (this.countryList.length > 0) {
      const data = [];
      this.countryList.forEach((ele) => {
        data.push({
          name: ele.countryName,
          createdBy: ele.createdBy,
          createdAt: (ele.createdAt != null) ? this.convertFormat(ele.createdAt) : '',
          updatedBy: ele.updatedBy,
          status: ele.status,
        });
      });
      this.service.exportAsExcelFile(data, 'Country List');
    }
  }

  searchCountry() {
    this.page = 0;
    this.getCountryList();
  }

  getCountryList() {
    this.spinner.show();
    const data = {
      page: this.service.encrypt(String(this.page)),
      pageSize: this.service.encrypt(String(10)),
      search: (this.filterFunction.value.search != null) ? this.service.encrypt(this.filterFunction.value.search.trim()) : null,
      status: (this.filterFunction.value.status != null) ? this.service.encrypt(this.filterFunction.value.status) : null,
    };

    this.service.postMethod('setting/admin/search-and-filter-countries', data, 1)
      .subscribe((res) => {
        this.spinner.hide();
        let dataList = this.service.decrypt(res.data);
        dataList = JSON.parse(dataList);
        if (dataList.status === 718) {
          this.countryList = dataList.data.list;
          this.countryList.forEach(element => {
            if(element.updatedBy == null) {
              element.updatedAt = null;
            }
          });
          this.total = dataList.data.size;
        }
        if (dataList.status === 719) {
          this.countryList = [];
          this.total = 0;
        }
      }, (error) => {
        this.spinner.show();
        this.countryList = [];
      });
  }

  resetFunction() {
    this.filterFunction.value.search = null;
    this.filterFunction.value.status = null;
    this.filterFunction.patchValue({
      search: null,
      status: null
    });
    this.p = 1;
    this.page = 0;
    this.getCountryList();
  }

  addNewCountry() {
    $('#addCountry').modal('show');
  }

  addCountry() {
    if (this.addCountryForm.invalid) {
      return;
    }
    if (this.modalHeading === 'Add') {
      const data = {
      countryName: this.service.encrypt(this.addCountryForm.value.countryName),
      countryshortName: this.service.encrypt(this.addCountryForm.value.countryShortName),
      ipAddress: this.service.encrypt(this.currentUser.ip),
      location: this.service.encrypt(this.currentUser.city + ',' + this.currentUser.country_name),
      phoneCode: this.service.encrypt(this.addCountryForm.value.phoneCode),
    };
      this.service.postMethod('setting/admin/add-new-country', data, 1)
      .subscribe((res) => {
        if (res.status === 710) {
          this.addCountryForm.reset();
          this.getCountryList();
          $('#addCountry').modal('hide');
        }
        if (res.status === 731) {
          this.showMessage(res);
        }
      }, (error) => {
        this.showMessage(error);
      });
    } else {
      const data1 = {
        countryName: this.service.encrypt(this.addCountryForm.value.countryName),
        countryShortName: this.service.encrypt(this.addCountryForm.value.countryShortName),
        ipAddress: this.service.encrypt(this.currentUser.ip),
        location: this.service.encrypt(this.currentUser.city + ',' + this.currentUser.country_name),
        phoneCode: this.service.encrypt(this.addCountryForm.value.phoneCode),
        countriesId: this.service.encrypt(this.currentId),
      };
      this.service.postMethod('setting/admin/edit-country', data1, 1)
        .subscribe((resp) => {
          if (resp.status === 714) {
            this.addCountryForm.reset();
            this.getCountryList();
            $('#addCountry').modal('hide');
          }
          if (resp.status === 731) {
            this.showMessage(resp);
          }
        }, (error) => {
          this.showMessage(error);
        });
    }
  }

  showMessage(response) {
    this.showApiMessage = true;
    this.response = response;
  }



  openModal(modal, id) {
    if (modal === 'editCountry') {
      this.modalHeading = 'Edit';
      this.currentId = id;
      this.editCountry(id);
      $('#addCountry').modal('show');
    } else {
      this.modalHeading = 'Add';
      this.addCountryForm.reset();
      this.currentId = id;
      $('#' + modal).modal('show');
    }
  }

  disableCountry() {
    this.service.postMethod('setting/admin/change-country-status/?countriesId=' + encodeURIComponent(this.service.encrypt(this.currentId)) + '&ipAddress=' + encodeURIComponent(this.service.encrypt(this.currentUser.ip)) + '&location=' + encodeURIComponent(this.service.encrypt(this.currentUser.city)), {}, 1)
      .subscribe((response) => {
        this.getCountryList();
      }, (error) => {
        this.getCountryList();
      });
    $('#unPublishdeleteModal').modal('hide');
  }

  deleteCountry() {
    this.service.postMethod('setting/admin/delete-country/?countriesId=' + encodeURIComponent(this.service.encrypt(this.currentId)) + '&ipAddress=' + encodeURIComponent(this.service.encrypt(this.currentUser.ip)) + '&location=' + encodeURIComponent(this.service.encrypt(this.currentUser.city)), {}, 1)
      .subscribe((res) => {
        if (res.status ===  712) {
          $('#deleteCountryModal').modal('hide');
        }
        this.getCountryList();
      }, (error) => {
        this.getCountryList();
        $('#deleteCountryModal').modal('hide');
      });
  }

  editCountry(id) {
    if (this.service.sideMenuArr.includes('updateCountryList')) {
      this.service.postMethod('setting/admin/get-country-detail?countriesId=' + encodeURIComponent(this.service.encrypt(id)) + '&language=' + encodeURIComponent(this.service.encrypt('en')), {}, 1)
        .subscribe((response) => {
          if (response.status === 712) {
            this.addCountryForm.patchValue({
              countryName: response.data.countryName,
              countryShortName: response.data.countryShortName,
              phoneCode: response.data.phoneCode,
            });
          }
        }, (error) => {
          this.showApiMessage = true;
          this.response = error;
        });
    }
  }

  openState(country, id) {
    if (this.service.sideMenuArr.includes('viewStateList')) {
      this.currentId = id;
      this.router.navigate(['/state-name/' + country + '/' + id]);
    }
  }

  changePage(page) {
    this.p = page;
    this.page = page - 1;
    this.getCountryList();
  }
}
