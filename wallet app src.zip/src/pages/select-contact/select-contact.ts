import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { ServiceServicesProvider } from '../../providers/service-services/service-services';
import { TabsPage } from '../tabs/tabs';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@IonicPage()
@Component({
  selector: 'page-select-contact',
  templateUrl: 'select-contact.html',
})
export class SelectContactPage {
  search: any = '';
  userList: any = [];
  radio: any = false;
  sender: any ={};
  receiver: any = {};
  countryListJson: any=[];
  formVal: boolean = false;
  constructor(public navCtrl: NavController, public navParams: NavParams, public server: ServiceServicesProvider) {
console.log('radio', this.radio)
 
  }
  ionViewWillEnter() {
    
    this.countryListApi();

    // if (navigator.onLine) {
    //   let userId = localStorage.getItem('userId');
    //   this.server.presentLoading();
    //   this.server.getApi('user/userDetail/' + userId, 1).subscribe((response: any) => {
    //     this.server.dismissLoading();
    //     if (response.response_code == 200) {
    //       this.profile = response.result.userDetails;
    //     } else if (response.response_code == 403 || response.response_code == 409 || response.response_code == 401) {
    //       this.server.presentToast(response.response_message)
    //       this.server.logout();
    //     }
    //     else {
    //       this.server.presentToast(response.response_message)
    //     }
    //   }, err => {
    //     this.server.dismissLoading();
    //     this.server.presentToast('Something went wrong')
    //   })
    // } else
    //   this.server.presentToast('Your internet connection seems to be lost')
  }

  checkRadio(){
    console.log('radio check', this.radio)
    this.radio = true;
  }

  countryListApi() {
    this.server.getCountryJson().subscribe(response => {
      this.countryListJson = response['countries']
    }, error => {
      this.server.presentToast('Could not fetch list of countries. Please try again later')
    })

    this.searchUser();
  }

  searchUser() {
    if (navigator.onLine) {
      let data = {
        userId:localStorage.getItem('userId'),
        search:this.search
      }
      this.server.postApi(data,'user/searchUser', 1).subscribe((response: any) => {
        if (response.response_code == 200) {
          this.userList = response.result;
        } else if (response.response_code == 403 || response.response_code == 409 || response.response_code == 401) {
          this.server.presentToast(response.response_message)
          this.server.logout();
        }
        else {
          this.server.presentToast(response.response_message)
        }
      },err => {
        this.server.presentToast('Something went wrong')
      })
    } else
      this.server.presentToast('Your internet connection seems to be lost')
  }

  getSenderCurrency() {
    console.log(localStorage.countryCode)
    let index =  this.countryListJson.findIndex(x=>x.code == localStorage.countryCode)
    console.log(this.countryListJson[index].name)
    return new Promise(resolve => {
      this.server.getCurrencyAndFlag(this.countryListJson[index].name, 1).subscribe(res => {
        this.sender.currencyCode = res[0].currencies[0].code;
        resolve(true);
      });
    });
  }

  getReceiverCurrency() {
    console.log(this.radio.countryCode)
    let index =  this.countryListJson.findIndex(x=>x.code == localStorage.countryCode)
    console.log('anshul==>>', this.countryListJson[index].name)
    return new Promise(resolve => {
      this.server.getCurrencyAndFlag(this.countryListJson[index].name, 1).subscribe(res => {
        console.log(res)
        this.receiver.currencyCode = res[0].currencies[0].code;
        resolve(true);
      });
    });
  }
  
  async getExchangeRate() {
    if (navigator.onLine) {
      await this.getSenderCurrency();
      await this.getReceiverCurrency();
      if(localStorage.countryCode == this.radio.countryCode) {
        this.server.dismissLoading();
        this.sender.exchangeRate = 1;
        this.requestMoney();
      }
      else {
        this.server.getExchangeRate(this.sender.currencyCode).subscribe(
          (res: any) => {
            this.server.dismissLoading();
            if(res[`rates`][this.receiver.currencyCode]) {
              this.sender.exchangeRate = res[`rates`][this.receiver.currencyCode]
              this.requestMoney();
            }
            else {
              this.sender.exchangeRate = 1;
              this.server.presentToast('Could not fetch exact exchange rate')
              this.requestMoney();
            }
              
          },
          err => {
            this.server.dismissLoading();
            this.sender.exchangeRate = 1;
            this.server.presentToast(err.error.error)
            this.requestMoney();
          }
        );
      }
      return true;
    }
    else {
      this.server.presentToast('Your internet connection seems to be lost')
    }

  }

  requestMoney() {
    if (navigator.onLine) {
      this.server.presentLoading();
      let data = {
        userId: localStorage.getItem('userId'),
        requestTo:this.radio._id,
        amount: Number(JSON.parse(localStorage.receiveMoneyProcess).amount),
        message: JSON.parse(localStorage.receiveMoneyProcess).message,
        convertedAmount: Number(JSON.parse(localStorage.receiveMoneyProcess).amount * this.sender.exchangeRate)
      }
      this.server.postApi(data,'transaction/requestMoney', 1).subscribe((response: any) => {
        this.server.dismissLoading();
        if (response.response_code == 200) {
          this.server.presentToast(response.response_message)
          this.navCtrl.setRoot(TabsPage, { selectedTab: 2 })
        } else if (response.response_code == 403 || response.response_code == 409 || response.response_code == 401) {
          this.server.presentToast(response.response_message)
          this.server.logout();
        }
        else {
          this.server.presentToast(response.response_message)
        }
      }, err => {
        this.server.dismissLoading();
        this.server.presentToast('Something went wrong')
      })
    } else
      this.server.presentToast('Your internet connection seems to be lost')
  }

  back() {
    this.navCtrl.pop();
  }
}
