import { MainServiceService } from './../../main-service.service';
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-sms-verify',
  templateUrl: './sms-verify.component.html',
  styleUrls: ['./sms-verify.component.css']
})
export class SmsVerifyComponent implements OnInit {
  phoneVerify: any;

  constructor(public service:MainServiceService, public router:Router) { }

  ngOnInit() {
    this.phoneVerify=new FormGroup({
      smsOtp:new FormControl('',[Validators.required])
    })
  }
  optVerify(){
    let data={'otp':this.phoneVerify.value.smsOpt}
    this.service.post('user/otpVerify',data,1).subscribe(res=>{
      if(res['responseCode']==200){
         this.router.navigate(['login'])
      }
    },err=>{
      console.log(err)
    })
 }

 resend(){
   
 }

}
