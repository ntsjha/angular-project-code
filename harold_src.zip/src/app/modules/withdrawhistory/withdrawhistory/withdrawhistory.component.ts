import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ServerService } from '../../../server.service';
import { AppComponent } from '../../../app.component';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';

@Component({
    selector: 'app-withdrawhistory',
    templateUrl: './withdrawhistory.component.html',
    styleUrls: ['./withdrawhistory.component.css']
})
export class WithdrawhistoryComponent implements OnInit {
    withdrawArr: any = [];
    coin: string = "";
    coinList: any = [];
    p = 1;
    explorerName: string;

    constructor(private router: Router, private server: ServerService, private spinnerService: Ng4LoadingSpinnerService, private appC: AppComponent) { }

    ngOnInit() {
        window.scrollTo(0,0);
        this.getCoinList();
    }

    selectCoin(coin) {
        this.coin = coin;
        switch(this.coin) {
            case 'BTC' : 
                this.explorerName = 'https://live.blockcypher.com/btc/address/';
                break;
            case 'LTC' : 
                this.explorerName = 'https://live.blockcypher.com/ltc/address/';
                break;
            case 'ETH' : 
                this.explorerName = 'https://etherscan.io/address/';
                break;
            case 'XRP' : 
                this.explorerName = 'https://bithomp.com/explorer/';
                break;
            case 'USDT' : 
                this.explorerName = 'https://www.omniexplorer.info/search/';
                break;
        }
        this.getWithdrawList();
    }

    back() {
        this.router.navigateByUrl('wallet');
    }

    /**Function to get coin list */
    getCoinList() {
        this.spinnerService.show();
        this.server.getApi("wallet/coin/get-coin-list").subscribe((succ) => {
            this.coinList = succ.data;
            this.coin = succ.data[0].coinShortName;
            this.selectCoin(this.coin);
        }, (err) => {
            this.spinnerService.hide();
        }); 
    }

    getWithdrawList() {
        this.withdrawArr = [];
        this.spinnerService.show();
        this.server.getApi("wallet/wallet/get-withdrawlist?coinName="+this.coin).subscribe((succ) => {
            this.spinnerService.hide();
            if(succ.data == undefined){
                this.withdrawArr = [];
            } else
                this.withdrawArr = succ.data;       
        }, (err) => {
            this.spinnerService.hide();
        }); 
    }

}
