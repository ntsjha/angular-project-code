import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, AlertController } from 'ionic-angular';
import { LoginPage } from '../login/login';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { PinPage } from '../pin/pin';
 //import { Facebook, FacebookLoginResponse } from '@ionic-native/facebook';
import { ModalController } from 'ionic-angular';
 //import { GooglePlus } from '@ionic-native/google-plus';
import { ServiceServicesProvider } from '../../providers/service-services/service-services';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/observable/combineLatest';
import 'rxjs/add/operator/startWith';
import { Observable } from 'rxjs/Observable';
declare var $: any;


@IonicPage()
@Component({
  selector: 'page-signup',
  templateUrl: 'signup.html',
})
export class SignupPage {
  countryCodeString: void;
  params: any;
  code: any;
  socialType: string;
  socialId: any;
  socialLogin: boolean;
  name: string[];
  // userNameField: any;
  usernameValid: any;
  usernameMessage: any;
  // userName :any  = new FormControl('');
  form1: FormGroup;
  countryData: any;
  isLoggedIn: boolean = false;
  users: any;
  phone: any
  countryCode: any
  defaultCountry: any = 'in';
  countryListJson: any = [];
  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    public modalCtrl: ModalController,
     //private fb: Facebook,
    // private googlePlus: GooglePlus,
    private server: ServiceServicesProvider,
    public alerCtrl: AlertController
  ) {
    this.params = (this.navParams.get('params')) ? (this.navParams.get('params')) : false;
    /** Function for password match and mismatch */
    function passwordMatchValidator(g: FormGroup) {
      let pass = g.get('password').value;
      let confPass = g.get('confirmPassword').value;
      if (pass != confPass) {
        g.get('confirmPassword').setErrors({ mismatch: true });
      } else {
        g.get('confirmPassword').setErrors(null)
        return null
      }
    }
    if (this.params) {
      this.socialLogin = true;
      this.form1 = new FormGroup({
        firstName: new FormControl(this.params.firstName, [Validators.pattern(/^[a-zA-Z]*$/i), Validators.required]),
        middleName: new FormControl('', [Validators.pattern(/^[a-zA-Z]*$/i)]),
        lastName: new FormControl(this.params.lastName, [Validators.pattern(/^[a-zA-Z]*$/i)]),
        userName: new FormControl('', [Validators.required, Validators.minLength(4)]),
        email: new FormControl(this.params.email, [Validators.required, Validators.pattern(/^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/i)]),
        country: new FormControl('', [Validators.required]),
        mobileNo: new FormControl('', [Validators.required, Validators.pattern(/^\d+$/), Validators.minLength(7)]),
      })
    }
    else {
      this.socialLogin = false;
      this.form1 = new FormGroup({
        firstName: new FormControl('', [Validators.pattern(/^[a-zA-Z]*$/i), Validators.required]),
        middleName: new FormControl('', [Validators.pattern(/^[a-zA-Z]*$/i)]),
        lastName: new FormControl('', [Validators.pattern(/^[a-zA-Z]*$/i)]),
        userName: new FormControl('', [Validators.required, Validators.minLength(4)]),
        email: new FormControl('', [Validators.required, Validators.pattern(/^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/i)]),
        country: new FormControl('', [Validators.required]),
        mobileNo: new FormControl('', [Validators.required, Validators.pattern(/^\d+$/), Validators.minLength(7)]),
        // Validators.required
        password: new FormControl('', [Validators.required, Validators.pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,16})/i)]),
        confirmPassword: new FormControl('', [Validators.required]),
      }, passwordMatchValidator)
    }


    // this.userNameField = new FormControl('')
    // this.form1.value.userName
    //   .valueChanges
    //   .debounceTime(1000)
    //   .subscribe((value) => {
    //     this.checkUserName(value)
    //   });

    Observable.combineLatest(
      this.form1.get('userName').valueChanges.debounceTime(1000).startWith('')
    ).subscribe((value) => {
      this.checkUserName(value)
    });
  }

  ionViewWillEnter() {
    this.countryListApi();
  }

  //------------------------------ Country JSON ------------------------------//
  countryListApi() {
    this.server.getCountryJson().subscribe(response => {
      this.countryListJson = response['countries']
    }, error => {
      this.server.presentToast('Could not fetch list of countries. Please try again later')
    })
  }
  //------------------------------ End Country JSON ------------------------------//

  get firstName(): any {
    return this.form1.get('firstName')
  }

  get middleName(): any {
    return this.form1.get('middleName')
  }

  get lastName(): any {
    return this.form1.get('lastName')
  }

  get userName(): any {
    return this.form1.get('userName')
  }

  get email(): any {
    return this.form1.get('email')
  }

  get country(): any {
    return this.form1.get('country')
  }

  get mobileNo(): any {
    return this.form1.get('mobileNo')
  }

  get password(): any {
    return this.form1.get('password')
  }

  get confirmPassword(): any {
    return this.form1.get('confirmPassword')
  }


  register() {
    this.navCtrl.push(PinPage)
  }

  signin() {
    this.navCtrl.pop();
  }

  key(event) {
    this.countryCode = event.target.value;
  }

  openModal() {
    if (navigator.onLine) {
      this.server.presentLoading();
      if (this.socialLogin) {
        let data = {
          "socialId": this.params.socialId,
          "socialType": this.params.socialType,
          "email": this.form1.value.email,
          "userName": this.form1.value.userName,
          "country": this.form1.value.country,
          "countryCode": this.code.code,
          "mobileNumber": this.code.dial_code + this.form1.value.mobileNo,
          "password": this.form1.value.password,
          "firstName": this.form1.value.firstName,
          "lastName": this.form1.value.lastName,
          "middleName": this.form1.value.middleName,
        }
        this.server.postApi(data, 'user/signup', 0).subscribe((response: any) => {
          this.server.dismissLoading();
          if (response['response_code'] == 201) {
            localStorage.setItem('JWT', response.result.token)
            localStorage.setItem('userName', this.form1.value.userName);
            localStorage.setItem('userId', response.result.userDetail._id)
            let modalPage = this.modalCtrl.create('ModalPage');
            modalPage.present();
            modalPage.onDidDismiss((data) => {
              if (data != 'failure')
                this.navCtrl.push(PinPage, { userName: this.form1.value.userName });
            });
          } else {
            this.server.presentToast(response['response_message'])
          }
        }, err => {
          this.server.dismissLoading();
          this.server.presentToast('Something went wrong')
        })
      }
      else {
        let data = {
          "email": this.form1.value.email,
          "userName": this.form1.value.userName,
          "country": this.form1.value.country,
          "countryCode": this.code.code,
          "mobileNumber": this.code.dial_code + this.form1.value.mobileNo,
          "password": this.form1.value.password,
          "firstName": this.form1.value.firstName,
          "lastName": this.form1.value.lastName,
          "middleName": this.form1.value.middleName,
        }
        this.server.postApi(data, 'user/signup', 0).subscribe((response: any) => {
          this.server.dismissLoading();
          if (response['response_code'] == 201) {
            localStorage.setItem('JWT', response.result.token)
            localStorage.setItem('userName', this.form1.value.userName);
            localStorage.setItem('userId', response.result.userDetail._id)
            let modalPage = this.modalCtrl.create('ModalPage');
            modalPage.present();
            modalPage.onDidDismiss((data) => {
              if (data != 'failure')
                this.navCtrl.push(PinPage, { userName: this.form1.value.userName });
            });
          } else {
            this.server.presentToast(response['response_message'])
          }
        }, err => {
          this.server.dismissLoading();
          this.server.presentToast('Something went wrong')
        })
      }
    }
    else
      this.server.presentToast('Your internet connection seems to be lost')
  }

  checkUserName(value) {
    if (navigator.onLine) {
      if (value[0].length >= 4) {
        this.server.presentLoading();
        let data = {
          "userName": value[0]
        }
        console.log('data=>',data);
        this.server.postApi(data, 'user/userNameExist', 0).subscribe((response: any) => {
          this.server.dismissLoading();
          this.usernameValid = response['response_code'];
          this.usernameMessage = response['response_message'];
        }, err => {
          this.server.dismissLoading();
          this.server.presentToast('Something went wrong')
        })
      }
    }
    else
      this.server.presentToast('Your internet connection seems to be lost')
  }

  countryChange(country) {
    let code = this.countryListJson.filter((item) => item.name == country);
    this.code = code[0]
  }

  back() {
    this.navCtrl.pop();
  }

}
