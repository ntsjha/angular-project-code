import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ForgetpassPage } from './forgetpass';

@NgModule({
  declarations: [
    ForgetpassPage,
  ],
  imports: [
    IonicPageModule.forChild(ForgetpassPage),
  ],
})
export class ForgetpassPageModule {}
