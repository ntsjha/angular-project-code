import { ServiceService } from 'src/app/service/service.service';
import { Component, OnInit, NgZone } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { CookieService } from 'ngx-cookie-service';

declare var $: any;
@Component({
  selector: 'app-offer-management',
  templateUrl: './offer-management.component.html',
  styleUrls: ['./offer-management.component.css']
})
export class OfferManagementComponent implements OnInit {

  modalType: any;
  offerList: any = [];
  selectedData: any;
  selectedIndex: any;
  todayDate: any = new Date().toISOString();
  paginationData: any = {currPage: 1, limit: 10, total: 0};
  offerType: any;
  userIp: any;
  updateOffer: any = true;

  constructor(
    private service: ServiceService,
    private zone: NgZone,
    private spinner: NgxSpinnerService,
    private cookie: CookieService
  ) {
    this.updateOffer = this.service.sideMenuArr.length ? this.service.sideMenuArr.includes('updateOffer') : true;
   }

  ngOnInit() {
    this.getOfferList();
    window.scrollTo(0, 0);
    this.userIp = (this.cookie.get('userInfo')) ? JSON.parse(this.cookie.get('userInfo')) : this.service.initialUserInfo;
  }

  getOfferList() {
    this.spinner.show();
    this.service.getMethod(`rewards/get-offer-list?languageName=${this.service.currLang}&page=${this.paginationData.currPage - 1}&pageSize=${this.paginationData.limit}`, 1).subscribe((success: any) => {
      this.spinner.hide();
      if (success.status === 1367 || success.status === 1453) {
        this.offerList = success.data.offerList;
        this.paginationData.total = success.data.size;
        this.offerList.forEach(element => {
          if(element.updatedBy == null) {
            element.updatedAt = null;
          }
        });
      } else {
        this.offerList = [];
      }
    }, error => {
      this.spinner.hide();
      this.offerList = [];
    });
  }

  changePage(event) {
    this.paginationData.currPage = event;
    this.getOfferList();
  }

  openModal(data, index, whichModal ) {
    this.selectedIndex = index;
    // if (data.offerEndDate < this.todayDate) {
    //   this.modalNo();
    //   return;
    // }
    this.selectedData = data;
    this.modalType = whichModal;
    this.offerType = data.offerType;
    $('#unPublishdeleteModal').modal({backdrop: 'static', keyboard: false});
  }

  enableDisableModal() {
    this.spinner.show();
    this.service.getMethod('rewards/enable-disable-offer?offerId=' + this.selectedData.contentId + '&ipAddress=' + this.userIp.ip + '&location=' + this.userIp.city + ',' + this.userIp.country_name, 1).subscribe((success: any) => {
      this.spinner.hide();
      if (success.status === 1374 || success.status === 1373) {
        $('#unPublishdeleteModal').modal('hide');
      }
      this.getOfferList();
    }, error => {
      this.spinner.hide();
    });
  }

  deleteModal() {
    this.spinner.show();
    this.service.getMethod(`rewards/marketing/delete-offer?offerId=${this.selectedData.contentId}`, 1).subscribe((success: any) => {
      this.spinner.hide();
      if (success.status === 1372) {
        $('#unPublishdeleteModal').modal('hide');
      }
      this.getOfferList();
    }, error => {
      this.spinner.hide();
    });
  }

  modalNo() {
    this.zone.run(() => {
      $('#status' + this.selectedIndex).toggleClass('active');
    });
  }
}
