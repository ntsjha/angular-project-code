import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EditprofileComponent } from './editprofile/editprofile.component';
import { FormsModule, ReactiveFormsModule } from '../../../../node_modules/@angular/forms';
import { GooglePlaceModule } from '../../../../node_modules/ngx-google-places-autocomplete';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    GooglePlaceModule
  ],
  declarations: [EditprofileComponent]
})
export class EditprofileModule { }
