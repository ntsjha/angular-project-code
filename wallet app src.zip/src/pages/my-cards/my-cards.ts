import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { ServiceServicesProvider } from "../../providers/service-services/service-services";
import { AddCardPage } from "../add-card/add-card";
import { EnterCvcPage } from "../enter-cvc/enter-cvc";

@IonicPage()
@Component({
  selector: 'page-my-cards',
  templateUrl: 'my-cards.html',
})
export class MyCardsPage {
  Cards: any;

  constructor(public navCtrl: NavController, public navParams: NavParams, private service: ServiceServicesProvider) {
  }

  back() {
    this.navCtrl.pop();
  }

  ionViewWillEnter() {
    this.getCards();
  }

  getCards() {
    if (navigator.onLine){
      this.service.presentLoading();
    this.service.getApi('transaction/listCard/' + localStorage.getItem('userId'), 0).subscribe(
      (response: any) => {
        this.service.dismissLoading();
        if (response['response_code'] == 200) {
          this.Cards = response[`result`];
        }
        else if (response.response_code == 403 || response.response_code == 409 || response.response_code == 401) {
          this.service.presentToast(response.response_message)
          this.service.logout();
        } else {
          this.service.presentToast(response[`response_message`])
        }
      },
      err => {
        this.service.dismissLoading();
        this.service.presentToast('Something went wrong')
      })
    } else
    this.service.presentToast('Your internet connection seems to be lost')
  }

  addCard() {
    this.navCtrl.push(AddCardPage)
  }

  next(cardDetails) {
    let data = JSON.parse(localStorage.addMoneyProcess);
    data.cardDetails = {
      cardNumber: cardDetails.number,
      cardHolderName: cardDetails.holdersName,
      expiry: cardDetails.exp_year + '-' + cardDetails.exp_month
    }
    localStorage.addMoneyProcess = JSON.stringify(data)
    this.navCtrl.push(EnterCvcPage)
  }

}
