import { ActivatedRoute } from '@angular/router';
import { ServiceService } from './../../../service/service.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blog-translation-list',
  templateUrl: './blog-translation-list.component.html',
  styleUrls: ['./blog-translation-list.component.css']
})
export class BlogTranslationListComponent implements OnInit {

  translationList: any = [];
  languageArr: any = [];
  paramData: any;

  constructor(
    private service: ServiceService,
    private activatedRoute: ActivatedRoute
  ) { }

  ngOnInit() {
    window.scrollTo(0, 0);
    this.getParamData();
  }

  getParamData() {
    this.activatedRoute.params.subscribe(param => {
      this.paramData = param;
      this.getTranslationList(param);
    });
  }

  getTranslationList(param) {
    this.service.postMethod(`blog/admin/find-translation-by-slug?slug=${param.slug}`, {}, 1).subscribe((success: any) => {
      const decryptedData = success.data ? JSON.parse(this.service.decrypt(success.data)) : {};
      if (decryptedData.status === 634) {
        // this.translationList = decryptedData.data.translationList;
        decryptedData.data.translationList.forEach(element => {
          if (element.updatedBy) {
            this.translationList.push({
              translationId: element.translationId,
              title: element.title,
              description: element.description,
              createdAt: element.createdAt,
              updatedAt: element.updatedBy == null ? null : element.updatedAt,
              createdBy: element.createdBy,
              updatedBy: element.updatedBy,
              image: element.image,
              author: element.author,
              status: element.status,
              fkLanguageId: element.fkLanguageId,
            });
          } else {
            this.translationList.push({
              translationId: element.translationId,
              title:  null,
              description:  null,
              createdAt:  null,
              updatedAt:  null,
              createdBy:  null,
              updatedBy:  null,
              image: null,
              author: null,
              status: null,
              fkLanguageId: element.fkLanguageId,
            });
          }
        });
        this.languageArr = decryptedData.data.languageList.data;
      }
    }, error => {
    });
  }

  getLanguage(data) {
    let lang;
    this.languageArr.forEach((element, i) => {
      if (data.fkLanguageId === element.languageId) {
        lang = element.languageShortName;
      }
    });
    return lang;
  }

}
