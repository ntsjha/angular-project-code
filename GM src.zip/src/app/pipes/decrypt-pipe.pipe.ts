import { Pipe, PipeTransform } from '@angular/core';
import { ServiceService } from '../service/service.service';

@Pipe({
    name: 'decrypt'
})
export class DecryptPipePipe implements PipeTransform {
    
    constructor(private service: ServiceService) {}

    transform(value: any): any {
        return this.service.decrypt(value);
        
    }

}
