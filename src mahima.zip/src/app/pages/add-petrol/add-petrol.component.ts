import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { MainServiceService } from './../../main-service.service';
import { Router } from '@angular/router';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { MatDialog, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { AddPetrolPumpModal } from '../modals/add-petrol-pump-modal.component';
import { AddTankModalComponent } from '../add-tank-modal/add-tank-modal.component';
declare var $ : any;

@Component({
  selector: 'app-add-petrol',
  templateUrl: './add-petrol.component.html',
  styleUrls: ['./add-petrol.component.css']
})
export class AddPetrolComponent implements OnInit {
    user="Mr. Stark"
    view=true;
    addPetrolForm:any;
    addTankForm:any;
    profileData: any;
    petrolPumpLength:any=0;
    petrolData:any;
  constructor(public service:MainServiceService,public router:Router,private spinnerService: Ng4LoadingSpinnerService, public spinner:Ng4LoadingSpinnerService, public dialog: MatDialog) { }

  ngOnInit() {
    this.addPetrolFormMethod();
    this.addTankFormMethod();
     this.getProfileData();
  }

  // get profile data

  getProfileData(){
    this.spinner.show();
    this.service.get('user/getProfile',1).subscribe( res=>{
      this.spinner.hide();
      this.user=res['result'].name?res['result'].name:'Mr. Stark';
      this.profileData=res['result'];
      this.petrolData=res['result'].petrolPump;
      // this.petrolPumpLength=res['result'].petrolPump.length?res['result'].petrolPump.length:0;
      localStorage.setItem('petrolpump_data',this.petrolData._id);
      console.log(this.petrolPumpLength)
      console.log(this.profileData);
      console.log(res);
   }, err=>{
     this.spinner.hide();
     console.log(err);
   })
  }

  // add petrol form method

  addPetrolFormMethod(){
     this.addPetrolForm=new FormGroup({
      petrolName:new FormControl('',[Validators.required]),
      petrolBrandName:new FormControl('Brand name',[Validators.required]),
      pinCode:new FormControl('',[Validators.required]),
      address:new FormControl('',[Validators.required]),
      city:new FormControl('',[Validators.required]),
      ownerName:new FormControl('',[Validators.required]),
      mobileNumber:new FormControl('',[Validators.required]),
      state:new FormControl('',[Validators.required]),
      email:new FormControl('',[Validators.required]),
      landMark:new FormControl('',[Validators.required])
     })
  }

  //add tank form method

  addTankFormMethod(){
  
    this.addTankForm=new FormGroup({
      tankName:new FormControl('',[Validators.required]),
      fuelType:new FormControl('Fuel type',[Validators.required]),
      vendorName:new FormControl('',[Validators.required]),
      tankBrandName:new FormControl('Brand name',[Validators.required]),
      tankNumber:new FormControl('',[Validators.required]),
    })

  }

 // Add petrol open modal
  addPetrolOpenModal(){
    this.dialog.open(AddPetrolPumpModal, {
      width: '630px',
      height: '595px'
    });       
  }
 
  // Add tank open modal method
  addTankOpenModal(){
    this.dialog.open(AddTankModalComponent, {
      width: '610px',
      height: '550px'
    });
  }

  addPetrol(){
    console.log(this.addPetrolForm.value);
    let petrolPumpData= {
      "petrolPumpName":this.addPetrolForm.value.petrolName,
      "ownerName":this.addPetrolForm.value.ownerName,
      "brandName": this.addPetrolForm.value.petrolBrandName,	
      "mobileNumber":this.addPetrolForm.value.mobileNumber,
      "pinCode":this.addPetrolForm.value.pinCode,
      "state": this.addPetrolForm.value.state,	
      "address":this.addPetrolForm.value.address,
      "email":this.addPetrolForm.value.email,
      "city": this.addPetrolForm.value.city,
      "landmark": this.addPetrolForm.value.landMark    	
      }
    this.spinnerService.show();
      this.service.post('user/addPetrolPump',petrolPumpData,1).subscribe( res => {
        
        if(res['responseCode']==200){
          this.service.showSuccess(res['responseMessage'])
          this.getProfileData();
          this.addPetrolForm.reset();
          $('#addPetrolModal').modal('hide');
        }else{

        }
        this.spinnerService.hide();
        console.log(res)
      },error =>{
    console.log(error)
      })

   
  }

  

  // select petrol pump
  selectPetrolPump(){
    this.router.navigate(['profile']);
  }

}
