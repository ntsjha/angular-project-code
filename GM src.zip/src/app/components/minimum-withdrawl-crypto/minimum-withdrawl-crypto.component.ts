import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ServiceService } from 'src/app/service/service.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { ActivatedRoute, Router } from '@angular/router';
import { AppComponent } from 'src/app/app.component';
import { CookieService } from 'ngx-cookie-service';

declare var $: any;

@Component({
  selector: 'app-minimum-withdrawl-crypto',
  templateUrl: './minimum-withdrawl-crypto.component.html',
  styleUrls: ['./minimum-withdrawl-crypto.component.css']
})
export class MinimumWithdrawlCryptoComponent implements OnInit, OnDestroy {
  coinName: any;
  currentUser: any;
  cryptoFunction: FormGroup;
  cryptoFiat: any;
  subscription: any;
  userIp: any;
  response: any = { 'message': '' };

  constructor(
    private service: ServiceService,
    private spinner: NgxSpinnerService,
    private activatedRoute: ActivatedRoute,
    private cookie: CookieService,
    private route: Router,
    private appC: AppComponent
  ) {
    this.cryptoFunction = new FormGroup({
      fee: new FormControl(null, [Validators.required, Validators.maxLength(8), Validators.pattern(/^^\d+(\.\d{1,8})*$/)]),
    });

    this.service.currentUserInfo.subscribe((response) => {
      this.currentUser = response;
    });
    this.subscription = this.service.authVerify.subscribe(val => {
      if (val === 'min-withdraw-crypto') {
        this.withdrawlCrypto();
        this.service.authVerify.next('false');
      }
    });
    this.userIp = (this.cookie.get('userInfo')) ? JSON.parse(this.cookie.get('userInfo')) : this.service.initialUserInfo;
  }

  ngOnInit() {
    this.activatedRoute.params.subscribe(id => {
      this.coinName = id.id;
    });
    this.minWithdrawlCrypto();
    
    window.scrollTo(0, 0);
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  minWithdrawlCrypto() {
    this.spinner.show();
    this.service.getMethod('wallet/admin/fees/get-fee-details?currencyName=' + this.coinName + '&currencyType=crypto', 1).subscribe((response: any) => {
      this.spinner.hide();
      const res = JSON.parse(this.service.decrypt(response.data));
      if (res.status === 845 || res.status === 842) {
        this.cryptoFiat = res.data;
        this.loadform();
      }
    }, (error) => {
      this.spinner.hide();
    });
    this.spinner.hide();
  }

  loadform() {
    this.cryptoFunction.patchValue({
      fee: this.cryptoFiat.minWithdrawalFee
    });
  }

  /** Function to verify google authentication */
  verifyGoogleAuth() {
    this.appC.google = { one: '', two: '', three: '', four: '', five: '', six: '' };
    this.appC.response = { message : '' };
    this.service.googleAuthCalledFrom = 'min-withdraw-crypto';
    $('#google-auth-modal').modal({ keyboard: false, backdrop: 'static' });

  }


  withdrawlCrypto() {
    this.spinner.show();
    const data = {
      amount: this.cryptoFunction.value.fee,
      coinName: this.coinName,
      ipAddress: this.userIp.ip,
      location: this.userIp.city + ',' + this.userIp.country_name
    };
    this.service.postMethod('wallet/admin/fees/set-min-crypto-withdraw-fee', data, 1).subscribe((response: any) => {
      this.spinner.hide();  
      if (response.status === 842) {
        this.route.navigate(['/minimum-withdrawl']);
      } else {
        this.response = response;
      }
    }, (error) => {
      this.spinner.hide();
    });
  }
}
