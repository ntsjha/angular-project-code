import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-kycaml',
    templateUrl: './kycaml.component.html',
    styleUrls: ['./kycaml.component.css']
})
export class KycamlComponent implements OnInit {

    constructor() { }

    ngOnInit() {
        window.scrollTo(0,0);
    }

}
