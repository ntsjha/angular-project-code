import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, App } from 'ionic-angular';
import { ContactsAddPage } from '../contacts-add/contacts-add';
import { ServiceServicesProvider } from '../../providers/service-services/service-services';
import { SendExchangePage } from '../send-exchange/send-exchange';
import { TabsPage } from '../tabs/tabs';
import { AlertController } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-contacts',
  templateUrl: 'contacts.html',
})
export class ContactsPage {
  radio: any;
  contacts: any = [];
  groupedContacts: any = [];
  profile: any;
  sender: any = {};
  receiver: any = {};
  clicked: boolean = false;
  


  constructor(public navCtrl: NavController, public alertCtrl: AlertController, public navParams: NavParams, private service: ServiceServicesProvider, public app: App) { }

  ionViewWillEnter() {
    this.clicked = false;
    if (navigator.onLine) {
      this.getProfile();
      this.service.presentLoading();
      let data = {
        "userId": localStorage.getItem('userId')
      }
      this.service.postApi(data, 'user/listContact', 0).subscribe(
        (response: any) => {
          this.service.dismissLoading();
          if (response[`response_code`] == 200) {
            this.contacts = (response[`result`])?(response[`result`]):[];
            if (this.contacts.length == 0)
              this.groupedContacts = [];
            else
              this.groupContacts(response[`result`]);
          } else if (response[`response_code`] == 403 || response[`response_code`] == 409 || response[`response_code`] == 401) {
            this.service.presentToast(response[`response_message`])
            this.service.logout();
          } else {
            this.service.presentToast(response[`response_message`])
          }
        },
        err => {
          this.service.dismissLoading();
          this.service.presentToast('Something went wrong')
        }
      )
    } else
      this.service.presentToast('Your internet connection seems to be lost')
  } 

  getListOfContact(){
    this.service.presentLoading();
    let data = {
      "userId": localStorage.getItem('userId')
    }
    this.service.postApi(data, 'user/listContact', 0).subscribe(
      (response: any) => {
        this.service.dismissLoading();
        if (response[`response_code`] == 200) {
          this.contacts = (response[`result`])?(response[`result`]):[];
          if (this.contacts.length == 0)
            this.groupedContacts = [];
          else
            this.groupContacts(response[`result`]);
        } else if (response[`response_code`] == 403 || response[`response_code`] == 409 || response[`response_code`] == 401) {
          this.service.presentToast(response[`response_message`])
          this.service.logout();
        } else {
          this.service.presentToast(response[`response_message`])
        }
      },
      err => {
        this.service.dismissLoading();
        this.service.presentToast('Something went wrong')
      }
    )
  }





  groupContacts(contacts) {
    this.groupedContacts = [];
    let sortedContacts = contacts.sort(this.compare);
    let currentLetter = false;
    let currentContacts = [];

    sortedContacts.forEach((value, index) => {
      if (value.name.charAt(0) != currentLetter) {

        currentLetter = value.name.charAt(0);

        let newGroup = {
          letter: currentLetter,
          contacts: []
        };

        currentContacts = newGroup.contacts;
        this.groupedContacts.push(newGroup);
      }
      currentContacts.push(value);

    });
  }

  compare(a, b) {
    // Use toUpperCase() to ignore character casing
    const genreA = a.name.toUpperCase();
    const genreB = b.name.toUpperCase();

    let comparison = 0;
    if (genreA > genreB) {
      comparison = 1;
    } else if (genreA < genreB) {
      comparison = -1;
    }
    return comparison;
  }

  back() {
    this.navCtrl.pop();
  }

  addContact() {
    this.navCtrl.push(ContactsAddPage)
  }

  editContact(contact) {
    console.log(contact)
    this.navCtrl.push(ContactsAddPage, {edit: contact})
  }

  selectContact() {
    if (navigator.onLine) {
      this.service.presentLoading();
      this.clicked = true;
      let data = {
        userId: localStorage.getItem('userId'),
        search: this.radio.number
      }
      this.service.postApi(data, 'user/isNumberValid', 1).subscribe((response: any) => {
        this.service.dismissLoading();
        if (response.response_code == 200) {
          if (this.navParams.get('process') == 'SEND')
            this.sendMoney(response.result[0]);
          else if (this.navParams.get('process') == 'RECEIVE') {
            this.getExchangeRate(response.result[0]);
          }
        } else if (response.response_code == 403 || response.response_code == 409 || response.response_code == 401) {
          this.service.presentToast(response.response_message)
          this.service.logout();
        }
        else {
          this.service.presentToast('Your friend is not a Remittance user. Please ask him to signup as a user and then try again.')
          this.navCtrl.pop();
        }
      }, err => {
        this.service.dismissLoading();
        this.service.presentToast('Something went wrong')
      })
    } else
      this.service.presentToast('Your internet connection seems to be lost')
  }

  getSenderCurrency() {
    return new Promise(resolve => {
      this.service.getCurrencyAndFlag(localStorage.countryCode, 1).subscribe(res => {
        this.sender.currencyCode = res[0].currencies[0].code;
        resolve(true);
      });
    });
  }

  getReceiverCurrency(receiver) {
    return new Promise(resolve => {
      this.service.getCurrencyAndFlag(receiver.countryCode, 1).subscribe(res => {
        this.receiver.currencyCode = res[0].currencies[0].code;
        resolve(true);
      });
    });
  }

  async getExchangeRate(receiver) {
    if (navigator.onLine) {
      await this.getSenderCurrency();
      await this.getReceiverCurrency(receiver);
      if (localStorage.countryCode == receiver.countryCode) {
        this.service.dismissLoading();
        this.sender.exchangeRate = 1;
        this.requestMoney(receiver);
      }
      else {
        this.service.getExchangeRate(this.sender.currencyCode).subscribe(
          (res: any) => {
            this.service.dismissLoading();
            if (res[`rates`][this.receiver.currencyCode]) {
              this.sender.exchangeRate = res[`rates`][this.receiver.currencyCode]
              this.requestMoney(receiver);
            }
            else {
              this.sender.exchangeRate = 1;
              this.service.presentToast('Could not fetch exact exchange rate')
              this.requestMoney(receiver);
            }

          },
          err => {
            this.service.dismissLoading();
            this.sender.exchangeRate = 1;
            this.service.presentToast(err.error.error)
            this.requestMoney(receiver);
          }
        );
      }
      return true;
    }
    else {
      this.service.presentToast('Your internet connection seems to be lost')
    }

  }

  requestMoney(receiver) {
    if (navigator.onLine) {
      this.service.presentLoading();
      let data = {
        userId: localStorage.getItem('userId'),
        requestTo: receiver._id,
        amount: Number(JSON.parse(localStorage.receiveMoneyProcess).amount),
        message: JSON.parse(localStorage.receiveMoneyProcess).message,
        convertedAmount: Number(JSON.parse(localStorage.receiveMoneyProcess).amount * this.sender.exchangeRate)
      }
      this.service.postApi(data, 'transaction/requestMoney', 1).subscribe((response: any) => {
        this.service.dismissLoading();
        if (response.response_code == 200) {
          this.service.presentToast(response.response_message)
          this.navCtrl.setRoot(TabsPage, { selectedTab: 2 })
        } else if (response.response_code == 403 || response.response_code == 409 || response.response_code == 401) {
          this.service.presentToast(response.response_message)
          this.service.logout();
        }
        else {
          this.service.presentToast(response.response_message)
        }
      }, err => {
        this.service.dismissLoading();
        this.service.presentToast('Something went wrong')
      })
    } else
      this.service.presentToast('Your internet connection seems to be lost')
  }

  getProfile() {
    if (navigator.onLine) {
      let userId = localStorage.getItem('userId');
      this.service.getApi('user/userDetail/' + userId, 1).subscribe((response: any) => {
        if (response.response_code == 200) {
          this.profile = response.result.userDetails;
        } else if (response.response_code == 403 || response.response_code == 409 || response.response_code == 401) {
          this.service.presentToast(response.response_message)
          this.service.logout();
        }
        else {
          this.service.presentToast(response.response_message)
        }
      }, err => {
        this.service.presentToast('Something went wrong')
      })
    } else
      this.service.presentToast('Your internet connection seems to be lost')
  }

  sendMoney(number) {
    this.radio.number = number.mobileNumber;
    let data = {
      phoneNumber: this.radio.number,
      receiverId: number._id
    };
    localStorage.sendMoneyProcess = JSON.stringify(data)
    this.app.getRootNav().push(SendExchangePage, { sender: this.profile.countryCode, receiver: number.countryCode })
  }



 

  deleteContact(userid){
    // console.log('id-->',id)
    let data = {
      id: userid,
   
    }
    const confirm = this.alertCtrl.create({
      title: '',
      message: 'Are you sure you want to delete the contact from your list?',
      buttons: [
        {
          text: 'Disagree',
          handler: () => {
            console.log('Disagree clicked');
          }
        },
        {
          text: 'Agree',
          handler: () => {
            console.log('data',data)
            this.service.postApi(data, 'user/deleteContact', 1).subscribe((response: any) => {
              this.service.dismissLoading();
              if (response.response_code == 200) {
                this.service.presentToast(response.response_message)
                this.getListOfContact();
              console.log('delete')
              } 
          })
          }
        }
      ]
    });
    confirm.present();
   
}

}


// deletePerson(mortgage) {
//   let confirm = this.alertCtrl.create({
//     title: 'Delete Person',
//     message: 'Are you sure?',
//     buttons: [
//       {
//         text: 'No',
//         role: 'cancel'
//       },
//       {
//         text: 'yws',
//         handler: () => {
//         }
//       }
//     ]
//   });
// }

