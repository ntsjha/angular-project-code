import { Component, OnInit, OnDestroy } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { ServiceService } from 'src/app/service/service.service';
import { FormControl, FormGroup } from '@angular/forms';
import { ngxCsv } from 'ngx-csv/ngx-csv';
import { AppComponent } from 'src/app/app.component';

declare var $: any;

@Component({
    selector: 'app-jobs',
    templateUrl: './jobs.component.html',
    styleUrls: ['./jobs.component.css']
})
export class JobsComponent implements OnInit, OnDestroy {
    jobList: any = [];
    jobFilter: FormGroup;
    paginationData: any = { limit: 10, currPage: 1, total: 0 };
    selectedData: any;
    whichModal: any;
    userInfo: any;
    subscription: any;
    englishShortCode: any;
    publish: any = false;

    constructor(private spinner: NgxSpinnerService, private service: ServiceService, private appC: AppComponent) {
        this.englishShortCode = this.service.englishLanguageShortCode;
        this.jobFilter = new FormGroup({
            search: new FormControl(null),
            status: new FormControl(null),
        });
        this.service.userInfo.subscribe(success => {
            this.userInfo = success;
        }, error => {
        });
        this.publish = this.service.sideBarData.includes('publish/UnpublishJob');
        this.subscription = this.service.authVerify.subscribe(val => {
            if (val == 'jobs') {
                this.deleteJob();
                this.service.authVerify.next('false');
            }
        });
    }

    /** Function to get data values */
    get search(): any {
        return this.jobFilter.get('search');
    }
    get status(): any {
        return this.jobFilter.get('status');
    }

    /** Function to send value */
    jobFilterTest(...val) {
        this.jobFilter.controls.search.setValue(val[0]);
        this.jobFilter.controls.status.setValue(val[1]);
        return this.jobFilter.valid;
    }

    ngOnInit() {
        window.scrollTo(0, 0);
        this.getJobList('reset');
    }

    ngOnDestroy() {
        this.subscription.unsubscribe();
    }

    /** Function to get job list */
    getJobList(event) {
        this.spinner.show();
        let data;
        if (event === 'reset') {
            data = {
                page: this.service.encrypt(this.paginationData.currPage - 1),
                pageSize: this.service.encrypt(this.paginationData.limit),
                search: null,
                status: null
            };
            this.paginationData.currPage = 1;
        } else {
            if (event === 'apply') {
                data = {
                    page: this.service.encrypt(0),
                    pageSize: this.service.encrypt(this.paginationData.limit),
                    search: (this.jobFilter.value.search != null) ? this.service.encrypt(this.jobFilter.value.search.trim()) : null,
                    status: (this.jobFilter.value.status === null || this.jobFilter.value.status === 'null') ? null : (this.jobFilter.value.status === 'true' ? this.service.encrypt(true) : this.service.encrypt(false))
                };
            } else {
                data = {
                    page: this.service.encrypt(this.paginationData.currPage - 1),
                    pageSize: this.service.encrypt(this.paginationData.limit),
                    search: (this.jobFilter.value.search != null) ? this.service.encrypt(this.jobFilter.value.search.trim()) : null,
                    status: (this.jobFilter.value.status === null || this.jobFilter.value.status === 'null') ? null : (this.jobFilter.value.status === 'true' ? this.service.encrypt(true) : this.service.encrypt(false))
                };
            }
        }
        this.service.postMethod('career/admin/search-job-filter', data, 1).subscribe((response: any) => {
            this.spinner.hide();
            const responseData = response.data ? JSON.parse(this.service.decrypt(response.data)) : {};
            if (responseData.status === 750) {
                this.jobList = responseData.data.reasponseData;
                this.jobList.forEach(element => {
                    if (element.updatedBy == null) {
                        element.updatedAt = null;
                    }
                });
                this.paginationData.total = responseData.data.size;
            } else {
                this.jobList = [];
            }
        }, (error) => {
            this.spinner.hide();
        });
    }

    changePage(event) {
        this.paginationData.currPage = event;
        this.getJobList('changePage');
    }

    openModal(data, whichOne) {
        if (this.publish) {
            this.selectedData = data;
            this.whichModal = whichOne;
            $('#del-modal').modal({ backdrop: 'static', keyboard: false });
        }
    }

    modalYes() {
        if (this.whichModal === 'delete') {
            this.verifyGoogleAuth();
        } else {
            this.publishUnpublishJob();
        }
    }

    /** Function to verify google authentication */
    verifyGoogleAuth() {
        this.appC.google = { one: '', two: '', three: '', four: '', five: '', six: '' };
        this.appC.response = { 'message': '' };
        this.service.googleAuthCalledFrom = 'jobs';
        $('#google-auth-modal').modal({ keyboard: false, backdrop: 'static' });

    }

    deleteJob() {
        this.spinner.show();
        this.service.postMethod(`career/admin/delete-job-details?contentId=${encodeURIComponent(this.service.encrypt(this.selectedData.contentId))}&ipAddress=${encodeURIComponent(this.service.encrypt(this.userInfo.ip))}&location=${encodeURIComponent(this.service.encrypt(this.userInfo.city + ',' + this.userInfo.country_name))}`, {}, 1).subscribe((success: any) => {
            this.spinner.hide();
            const decryptedData = success.data ? JSON.parse(this.service.decrypt(success.data)) : {};
            if (decryptedData.status === 811) {
                $('#del-modal').modal('hide');
                this.getJobList('event');
            }
        }, error => {
            this.spinner.hide();
        });
    }

    publishUnpublishJob() {
        this.spinner.show();
        const apireq = {
            contentId: this.service.encrypt(String(this.selectedData.contentId))
        };
        this.service.postMethod('career/admin/change-job-status', apireq, 1).subscribe(succ => {
            this.spinner.hide();
            const decryptedData = succ.data ? JSON.parse(this.service.decrypt(succ.data)) : {};
            if (decryptedData.status === 813) {
                $('#del-modal').modal('hide');
                this.getJobList('event');
            }
        }, error => {
            this.spinner.hide();
        });
    }

    exportCSV() {
        const options = {
            fieldSeparator: ',',
            quoteStrings: '"',
            decimalseparator: '.',
            showLabels: true,
            showTitle: false,
            useBom: true,
            noDownload: false,
            headers: ['Job Title', 'Created At', 'Created By', 'Updated At', 'Updated By', 'Status', 'Published On', 'Applications']
        };
        const arr = [];
        this.jobList.forEach((element, i) => {
            arr.push({ title: element.title, createdAt: (this.service.transformDate(element.createdAt)), createdBy: element.createdBy, updatedAt: (this.service.transformDate(element.updatedAt)), updatedBy: element.updatedBy, status: ((element.status) ? 'Published' : 'Un-published'), publishedOn: (this.service.transformDate(element.createdAt)), applications: element.count });
        });
        const importArr = arr;
        new ngxCsv(importArr, 'job', options);
    }

}
