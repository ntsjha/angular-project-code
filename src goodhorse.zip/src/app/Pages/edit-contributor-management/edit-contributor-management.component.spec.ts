import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditContributorManagementComponent } from './edit-contributor-management.component';

describe('EditContributorManagementComponent', () => {
  let component: EditContributorManagementComponent;
  let fixture: ComponentFixture<EditContributorManagementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditContributorManagementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditContributorManagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
