import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TradeactionComponent } from './tradeaction.component';

describe('TradeactionComponent', () => {
  let component: TradeactionComponent;
  let fixture: ComponentFixture<TradeactionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TradeactionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TradeactionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
