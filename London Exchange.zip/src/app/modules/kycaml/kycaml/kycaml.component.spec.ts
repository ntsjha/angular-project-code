import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { KycamlComponent } from './kycaml.component';

describe('KycamlComponent', () => {
  let component: KycamlComponent;
  let fixture: ComponentFixture<KycamlComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ KycamlComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(KycamlComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
