import { Component, OnInit, NgZone } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Subject, Observable } from 'rxjs';
import { IMyDpOptions } from 'mydatepicker';
import { ActivatedRoute, Router } from '@angular/router';
import { Title } from '@angular/platform-browser';
import { WebcamImage, WebcamInitError } from 'ngx-webcam';
import { NgxSpinnerService } from 'ngx-spinner';
import { ServiceService } from 'src/app/service/service.service';

declare var $:any;
@Component({
    selector: 'app-operation-kyc',
    templateUrl: './operation-kyc.component.html',
    styleUrls: ['./operation-kyc.component.css']
})
export class OperationKycComponent implements OnInit {
    iswebcam = false;
    whatsappNumValidOrNot = true;
    lineIdValidOrNot = true;
    weChatValidOrNot = true;
    idBase64: any = {backId: '', frontId: '', taxCertificate: '', DBD: ''};
    public webcamImage: WebcamImage = null;
    public allowCameraSwitch = true;
    public showWebcam = true;
    public deviceId: string;
    step: any = '1';
    kycFirstStep: FormGroup;
    stepTwoForm: FormGroup;
    companyStepThreeForm: FormGroup;
    fileDataOfSelfi: any;
    showThaiNameFields = false;
    companyNumValidOrNot = true;
    selfiImage: any = {show: false, msg: ''};
    fileData: FormData;
    nationalityList: any = [];
    countryList: any = [];
    stateList: any = [];
    stepThreeForm: FormGroup;
    id: any = { backId: {name : null}, frontId: {name : null}, taxCertificate: {name : null}, DBD: {name : null}, authoriseLetter: {name : null} };
    uploadingIdError: any = { backId: { show: false, msg: '' }, frontId: { show: false, msg: '' }, DBD: { show: false, msg: '' }, authoriseLetter: {show: false, msg: ''} };
    private trigger: Subject<void> = new Subject<void>();
    private nextWebcam: Subject<boolean | string> = new Subject<boolean | string>();
  
    firstStepCompanyForm: FormGroup;
    userData: any = {data : {userType : 'COMPANY'}};
    IdURLs: any = {backId : '', frontId: '', selfi: '', DBD: '', authoriseLetter: '', taxCertificate: ''};
  
    public myDatePickerOptions: IMyDpOptions = {
      disableSince: { year: new Date().getFullYear() - 20, month: new Date().getMonth() + 1, day: new Date().getDate() },
      dateFormat: 'dd-mm-yyyy',
    };
    paramData: any;
    kycUploaded = false;
    showFirstStepValidation: any = false;
    showSecondStepValidation: any = false;
    showThirdStepValidation: any = false;
    selfiBase64: any = '';
    showSelfiImage: any = false;
    resonToRejectKYC: any = '';
    myAccountApiData: any = {};
    numbers: any = [];
    unsubscribeUserInfo: any;
    currLanguage: any;
  
    constructor(
      private service: ServiceService,
      private zone: NgZone,
      private spinner: NgxSpinnerService,
      private activatedRoute: ActivatedRoute,
      private router: Router,
      public titleService: Title
    ) {
      this.titleService.setTitle('GMO KYC');
    }
  
    ngOnInit() {
      window.scrollTo(0, 0);
      this.getParamData();
      this.forms();
      this.getMyData();
      this.telInputFuncLineId();
      this.service.getMethod('account/my-account', 1).subscribe((success: any) => {
        const decryptedData = success.data ? JSON.parse(this.service.decrypt(success.data)) : '';
        this.myAccountApiData = decryptedData;
        if (decryptedData.status === 200) {
          this.resonToRejectKYC = (decryptedData.data ? (decryptedData.data.kyc ? (decryptedData.data.kyc.reason ? decryptedData.data.kyc.reason : '') : '') : '');
        }
      }, error => {
      });
      window.onbeforeunload = (event) => {
      };
    }
    getMyData() {
      this.spinner.show();
      this.service.getMethod('account/get-kyc-status', 1).subscribe((res: any) => {
        this.userData = res.data ? JSON.parse(this.service.decrypt(res.data)) : {data : {userType : 'COMPANY'}};
        if (!!this.userData.data.kycStatus) {
          this.kycUploaded = true;
          this.step = 4;
        }
        if(this.userData.data.kycStatus == 'ACCEPTED') {
          this.changeKYCStatus();
        }
          this.getCountries();
          this.spinner.hide();
      }, error => {
        this.getCountries();
        this.spinner.hide();
      });
    }
  
    changeKYCStatus() {
      let data = {}
      this.service.postMethod('account/update-kyc-seen', data,1).subscribe(x=> {
  
      })
    }
  
    rejectContinue() {
      this.kycUploaded = false;
      this.step = 1;
      setTimeout(() => {
        this.getCountries();
      }, 500);
      if (this.myAccountApiData.data.kyc.kycBasicDetails) {
        this.firstStepCompanyForm.patchValue({
          companyName: this.myAccountApiData.data.kyc.kycBasicDetails.companyName,
          companyRegistrationNumber: this.myAccountApiData.data.kyc.kycBasicDetails.registrationNo,
          companyWebsite: this.myAccountApiData.data.kyc.kycBasicDetails.companyWebsite,
          companyPhoneNumber: this.myAccountApiData.data.kyc.kycBasicDetails.companyPhoneNo
        });
        this.kycFirstStep.patchValue({
          functionInCompany: this.myAccountApiData.data.kyc.kycBasicDetails.companyFunction,
          nationality: this.myAccountApiData.data.kyc.kycBasicDetails.nationality,
          dob: {
            date: {
              year: new Date(Number(this.myAccountApiData.data.kyc.kycBasicDetails.dob)).getFullYear(),
              month: new Date(Number(this.myAccountApiData.data.kyc.kycBasicDetails.dob)).getMonth() + 1,
              day: new Date(Number(this.myAccountApiData.data.kyc.kycBasicDetails.dob)).getDate()
            }, epoc: (Number(this.myAccountApiData.data.kyc.kycBasicDetails.dob) / 1000)
          },
          title: this.myAccountApiData.data.kyc.kycBasicDetails.title,
          thaiFirstName: this.myAccountApiData.data.kyc.kycBasicDetails.thaiFirstName,
          thaiMiddleName: this.myAccountApiData.data.kyc.kycBasicDetails.thaiMiddleName,
          thaiLastName: this.myAccountApiData.data.kyc.kycBasicDetails.thaiLastName,
          englishFirstName: this.myAccountApiData.data.kyc.kycBasicDetails.englishFirstName,
          englishMiddleName: this.myAccountApiData.data.kyc.kycBasicDetails.englishMiddleName,
          englishLastName: this.myAccountApiData.data.kyc.kycBasicDetails.englishLastName,
        });
        this.stepTwoForm.patchValue({
          adressOne: this.myAccountApiData.data.kyc.kycBasicDetails.addressOne,
          addressTwo: this.myAccountApiData.data.kyc.kycBasicDetails.addressTwo,
          country: this.myAccountApiData.data.kyc.kycBasicDetails.country,
          city: this.myAccountApiData.data.kyc.kycBasicDetails.city,
          postalCode: this.myAccountApiData.data.kyc.kycBasicDetails.postalCode,
        });
        this.companyStepThreeForm.patchValue({
          companyTaxNumber: this.myAccountApiData.data.kyc.document.length ? this.myAccountApiData.data.kyc.document[0].companyTaxNumber : null
        });
        this.stepThreeForm.patchValue({
          nationalIdNumber: this.myAccountApiData.data.kyc.document.length ? this.myAccountApiData.data.kyc.document[0].nationalIdNumber : null,
          passportNumber: this.myAccountApiData.data.kyc.document.length ? this.myAccountApiData.data.kyc.document[0].passportNumber : null,
          laserCode: this.myAccountApiData.data.kyc.document.length ? this.myAccountApiData.data.kyc.document[0].laserCode : null,
          lineId: this.myAccountApiData.data.kyc.document.length ? this.myAccountApiData.data.kyc.document[0].lineId : null,
          whatsappId: this.myAccountApiData.data.kyc.document.length ? this.myAccountApiData.data.kyc.document[0].whatsAppNumber : null,
          weChatId: this.myAccountApiData.data.kyc.document.length ? this.myAccountApiData.data.kyc.document[0].weChat : null,
          usCitizen: this.myAccountApiData.data.kyc.document.length ? (this.myAccountApiData.data.kyc.document[0].usCitizen === true ? 'Yes' : 'No') : null,
          usResident: this.myAccountApiData.data.kyc.document.length ? (this.myAccountApiData.data.kyc.document[0].usResident === true ? 'Yes' : 'No') : null
        });
        this.id = {
          backId: {name: this.myAccountApiData.data.kyc.document.length ? this.myAccountApiData.data.kyc.document[0].backImageUrl : null},
          frontId: {name: this.myAccountApiData.data.kyc.document.length ? this.myAccountApiData.data.kyc.document[0].frontImageUrl : null},
          taxCertificate: { name : this.myAccountApiData.data.kyc.document.length ? this.myAccountApiData.data.kyc.document[0].taxCertificateUrl : null},
          DBD: {name: this.myAccountApiData.data.kyc.document.length ? this.myAccountApiData.data.kyc.document[0].dbd : null},
          authoriseLetter: {name: this.myAccountApiData.data.kyc.document.length ? this.myAccountApiData.data.kyc.document[0].authoriseLetterUrl : null}
        };
        this.showSelfiImage = true;
        this.selfiBase64 = this.myAccountApiData.data.kyc.document.length ? this.myAccountApiData.data.kyc.document[0].selfieImageUrl : null;
        this.webcamImage = this.myAccountApiData.data.kyc.document.length ? this.myAccountApiData.data.kyc.document[0].selfieImageUrl : null;
        this.IdURLs = {
          backId : this.myAccountApiData.data.kyc.document.length ? this.myAccountApiData.data.kyc.document[0].backImageUrl : null,
          frontId: this.myAccountApiData.data.kyc.document.length ? this.myAccountApiData.data.kyc.document[0].frontImageUrl : null,
          selfi: this.myAccountApiData.data.kyc.document.length ? this.myAccountApiData.data.kyc.document[0].selfieImageUrl : null,
          DBD: this.myAccountApiData.data.kyc.document.length ? this.myAccountApiData.data.kyc.document[0].dbd : null,
          authoriseLetter: this.myAccountApiData.data.kyc.document.length ? this.myAccountApiData.data.kyc.document[0].authoriseLetterUrl : null,
          taxCertificate: this.myAccountApiData.data.kyc.document.length ? this.myAccountApiData.data.kyc.document[0].taxCertificateUrl : null,
        };
      }
    }
  
    getParamData() {
      this.unsubscribeUserInfo = this.service.userInfo.subscribe(success => {
        if (success) {
          const lang = success.country_name ? (success.country_name.toLowerCase() === 'thailand' ? 'th' : ((success.country_name.toLowerCase() === 'china' || success.country_name.toLowerCase() === 'hong kong') ? 'ch' : 'en')) : 'th';
          this.currLanguage = lang;
          this.getNationalityList();
          setTimeout(() => {
            this.getCountryList();
          }, 100);
        }
      });
    }
  
    public triggerSnapshot(): void {
      this.trigger.next();
    }
  
    public toggleWebcam(): void {
      this.showWebcam = !this.showWebcam;
    }
    public showNextWebcam(directionOrDeviceId: boolean | string): void {
      this.nextWebcam.next(directionOrDeviceId);
    }
  
    public handleImage(webcamImage: WebcamImage): void {
      this.webcamImage = webcamImage;
      this.getFileData(this.webcamImage);
    }
    public cameraWasSwitched(deviceId: string): void {
      this.deviceId = deviceId;
    }
  
    public get triggerObservable(): Observable<void> {
      return this.trigger.asObservable();
    }
  
    public get nextWebcamObservable(): Observable<boolean | string> {
      return this.nextWebcam.asObservable();
    }
  
    public handleInitError(error: WebcamInitError): void {
      if (error.mediaStreamError && error.mediaStreamError.name === 'NotAllowedError') {
        this.iswebcam = false;
        $('#browserNotSupported').modal({ backdrop: 'static', keyboard: false });
      }
    }
  
    getFileData(data) {
      this.selfiBase64 = data._imageAsDataUrl;
      this.showSelfiImage = true;
      const arr = data['_imageAsDataUrl'].split(','), mime = arr[0].match(/:(.*?);/)[1],
        bstr = atob(arr[1]);
        let n = bstr.length;
        const u8arr = new Uint8Array(n);
      while (n--) {
        u8arr[n] = bstr.charCodeAt(n);
      }
      this.fileDataOfSelfi = new File([u8arr], 'imageName.jpeg', { type: mime });
      this.selfiImage.show = false;
      const selfi = [];
      selfi.push(this.fileDataOfSelfi);
      this.uploadImage('selfi', selfi);
    }
  
    retake() {
      this.showSelfiImage = false;
      this.webcamImage = null;
      this.selfiBase64 = '';
      this.IdURLs = {
        selfi: '',
      };
    }
  
    cameraSupportOrNot() {
      this.getCountries();
    }
  
    forms() {
      this.firstStepCompanyForm = new FormGroup({
        companyName: new FormControl(null, [Validators.required, Validators.pattern(/^[a-zA-Z$-_!@*%#][a-zA-Z$-_!@*%#]*$/), Validators.minLength(1), Validators.maxLength(255)]),
        companyRegistrationNumber: new FormControl(null, [Validators.required, Validators.pattern(/^[a-zA-Z$-_!@*%#][a-zA-Z$-_!@*%#]*$/), Validators.minLength(1), Validators.maxLength(255)]),
        companyWebsite: new FormControl(null, [Validators.required, Validators.pattern(/^((https?|ftp|smtp):\/\/)?(www.)?[a-z0-9]+(\.[a-z]{2,}){1,3}(#?\/?[a-zA-Z0-9#]+)*\/?(\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$/)]),
        companyPhoneNumber: new FormControl(null, [Validators.required, Validators.pattern(/^[0-9]*$/)]),
      });
      this.kycFirstStep = new FormGroup({
        functionInCompany: new FormControl(null, [Validators.pattern(/^[a-zA-Z$-_!@*%#][a-zA-Z$-_!@*%#]*$/), Validators.minLength(1), Validators.maxLength(255)]),
        nationality: new FormControl(null, [Validators.required]),
        dob: new FormControl(null, [Validators.required]),
        title: new FormControl(null, [Validators.required]),
        thaiFirstName: new FormControl(null, [Validators.pattern(/^[a-zA-Z]*$/), Validators.minLength(1), Validators.maxLength(255)]),
        thaiMiddleName: new FormControl(null, [Validators.pattern(/^[a-zA-Z]*$/), Validators.minLength(1), Validators.maxLength(255)]),
        thaiLastName: new FormControl(null, [Validators.pattern(/^[a-zA-Z]*$/), Validators.minLength(1), Validators.maxLength(255)]),
        englishFirstName: new FormControl(null, [Validators.required, Validators.pattern(/^[a-zA-Z]*$/), Validators.minLength(1), Validators.maxLength(255)]),
        englishMiddleName: new FormControl(null, [Validators.pattern(/^[a-zA-Z]*$/), Validators.minLength(1), Validators.maxLength(255)]),
        englishLastName: new FormControl(null, [Validators.required, Validators.pattern(/^[a-zA-Z]*$/), Validators.minLength(1), Validators.maxLength(255)]),
      });
      this.setDate();
      this.stepTwoForm = new FormGroup({
        adressOne: new FormControl(null, [Validators.required, Validators.pattern(/^[a-z0-9A-Z$-_!@*%#][a-z0-9A-Z$-_!@*%# ]*$/), Validators.minLength(1), Validators.maxLength(255)]),
        addressTwo: new FormControl(null, [Validators.required, Validators.pattern(/^[a-z0-9A-Z$-_!@*%#][a-z0-9A-Z$-_!@*%# ]*$/), Validators.minLength(1), Validators.maxLength(255)]),
        country: new FormControl(null, [Validators.required]),
        state: new FormControl(null, [Validators.required]),
        city: new FormControl(null, [Validators.required, Validators.pattern(/^[a-z0-9A-Z$-_!@*%#][a-z0-9A-Z$-_!@*%# ]*$/), Validators.minLength(1), Validators.maxLength(255)]),
        postalCode: new FormControl(null, [Validators.required, Validators.pattern(/^[0-9]*$/)]),
      });
      this.companyStepThreeForm = new FormGroup({
        companyTaxNumber: new FormControl(null, [Validators.required])
      });
      this.stepThreeForm = new FormGroup({
        nationalIdNumber: new FormControl(null, [Validators.maxLength(13)]),
        passportNumber: new FormControl(null, [Validators.minLength(7), Validators.maxLength(9),Validators.pattern(/^[a-zA-Z0-9]*$/)]),
        laserCode: new FormControl(null, [Validators.pattern(/^[A-z]{2}[0-9]{10}$/g)]),
        lineId: new FormControl(null ),
        whatsappId: new FormControl(null ),
        weChatId: new FormControl(null ),
        usCitizen: new FormControl(null, ),
        usResident: new FormControl(null, )
      });
    }
  
    firstStepCompanyFormForTestCases(...val) {
      this.firstStepCompanyForm.controls['companyName'].setValue(val[0]);
      this.firstStepCompanyForm.controls['companyRegistrationNumber'].setValue(val[1]);
      this.firstStepCompanyForm.controls['companyWebsite'].setValue(val[2]);
      this.firstStepCompanyForm.controls['companyPhoneNumber'].setValue(val[3]);
      return this.firstStepCompanyForm.valid;
    }
    kycFirstStepFormForTestCases(...val) {
      this.kycFirstStep.controls['functionInCompany'].setValue(val[0]);
      this.kycFirstStep.controls['nationality'].setValue(val[1]);
      this.kycFirstStep.controls['dob'].setValue(val[2]);
      this.kycFirstStep.controls['title'].setValue(val[3]);
      this.kycFirstStep.controls['thaiFirstName'].setValue(val[4]);
      this.kycFirstStep.controls['thaiMiddleName'].setValue(val[5]);
      this.kycFirstStep.controls['thaiLastName'].setValue(val[6]);
      this.kycFirstStep.controls['englishFirstName'].setValue(val[7]);
      this.kycFirstStep.controls['englishMiddleName'].setValue(val[8]);
      this.kycFirstStep.controls['englishLastName'].setValue(val[9]);
      return this.kycFirstStep.valid;
    }
    kycStepTwoForTestCases(...val) {
      this.stepTwoForm.controls['adressOne'].setValue(val[0]);
      this.stepTwoForm.controls['addressTwo'].setValue(val[1]);
      this.stepTwoForm.controls['country'].setValue(val[2]);
      this.stepTwoForm.controls['state'].setValue(val[3]);
      this.stepTwoForm.controls['city'].setValue(val[4]);
      this.stepTwoForm.controls['postalCode'].setValue(val[5]);
      return this.stepTwoForm.valid;
    }
    kycCompanyStepThreeForTestCases(...val) {
      this.companyStepThreeForm.controls['companyTaxNumber'].setValue(val[0]);
      return this.companyStepThreeForm.valid;
    }
    kycStepThreeForm(...val) {
      this.stepThreeForm.controls['nationalIdNumber'].setValue(val[0]);
      this.stepThreeForm.controls['passportNumber'].setValue(val[1]);
      this.stepThreeForm.controls['laserCode'].setValue(val[2]);
      this.stepThreeForm.controls['lineId'].setValue(val[3]);
      this.stepThreeForm.controls['whatsappId'].setValue(val[4]);
      this.stepThreeForm.controls['weChatId'].setValue(val[5]);
      this.stepThreeForm.controls['usCitizen'].setValue(val[6]);
      this.stepThreeForm.controls['usResident'].setValue(val[7]);
      return this.stepThreeForm.valid;
    }
  
    setDate(): void {
      const date = new Date();
      this.kycFirstStep.patchValue({
        dob: {
          date: {
            year: date.getFullYear() - 20,
            month: date.getMonth() + 1,
            day: date.getDate() - 1
          }, epoc: ((new Date(date.getFullYear() - 20, date.getMonth() + 1, date.getDate() - 1).getTime()) / 1000)
        }
      });
    }
  
    getCountries() {
      this.service.currentUserInfo.subscribe(currInfo => {
        if (currInfo) {
          this.filterCountry(currInfo.country_code);
        } else {
          this.filterCountry('TH');  
        }
      }, error => {
        this.filterCountry('TH');
      });
    }
  
    filterCountry(data) {
      $('#companyPhoneNum').intlTelInput({
        initialCountry: data,
        nationalMode: true,
        autoFormat: false,
        separateDialCode: true,
        formatOnDisplay: false,
        utilsScript: '/assets/vendors/custom/intl-tel-input/js/utils.js',
        geoIpLookup: function(callback) {
            callback('MY');
        }
      });
      $('#lineIdNumb').intlTelInput({
        initialCountry: data,
        nationalMode: true,
        autoFormat: false,
        separateDialCode: true,
        formatOnDisplay: false,
        utilsScript: '/assets/vendors/custom/intl-tel-input/js/utils.js',
        geoIpLookup: function(callback) {
            callback('MY');
        }
      });
      $('#whatsappNum').intlTelInput({
        initialCountry: data,
        nationalMode: true,
        autoFormat: false,
        separateDialCode: true,
        formatOnDisplay: false,
        utilsScript: '/assets/vendors/custom/intl-tel-input/js/utils.js',
        geoIpLookup: function(callback) {
            callback('MY');
        }
      });
      $('#weChatNum').intlTelInput({
        initialCountry: data,
        nationalMode: true,
        autoFormat: false,
        separateDialCode: true,
        formatOnDisplay: false,
        utilsScript: '/assets/vendors/custom/intl-tel-input/js/utils.js',
        geoIpLookup: function(callback) {
            callback('MY');
        }
      });
    }
  
    companyPhoneNumberValidOrNot() {
      this.zone.run(() => {
        this.companyNumValidOrNot = $('#companyPhoneNum').intlTelInput('isValidNumber');
      });
    }
  
    getNationalityList() {
      this.service.getMethod(`setting/get-nationality-List?languageName=${encodeURIComponent(this.service.encrypt(this.currLanguage))}`, 0).subscribe(success => {
        if (success['status'] === 701) {
          const nation = success['data'].filter((item) => {
            return (item.countryName.toLowerCase() !== 'thailand' || item.countryName.toLowerCase() !== 'China');
          });
          nation.unshift({
            'countryName': 'Thailand',
            'countryShortName': 'TH',
            'phoneCode': null,
            'countryId': null
          },
          {
            'countryName': 'China',
            'countryShortName': 'CN',
            'phoneCode': null,
            'countryId': null
          }
          );
          this.nationalityList['data'] = nation;
          this.selectNationality();
        } else {
          this.nationalityList['data'] = [];
        }
      }, error => {
        this.nationalityList['data'] = [];
      });
    }
  
    getCountryList() {
      this.service.getMethod(`setting/get-country-List?languageName=${encodeURIComponent(this.service.encrypt(this.currLanguage))}`, 0).subscribe(success => {
        if (success['status'] === 703) {
          const indexOfThailend = success['data'].findIndex(x => x.countryName.toLowerCase() === 'thailand');
          const indexOfChaina = success['data'].findIndex(x => x.countryName.toLowerCase() === 'china');
          const nationList = success['data'].filter((item) => {
            return (item.countryName.toLowerCase() !== 'thailand' || item.countryName.toLowerCase() !== 'china');
          });
          if (indexOfChaina >= 0) {
            nationList.unshift({
              'countryName': 'China',
              'countryShortName': 'CN',
              'phoneCode': '+86',
              'countryId': 49
            });
          }
          if (indexOfThailend >= 0) {
            nationList.unshift({
              'countryName': 'Thailand',
              'countryShortName': 'TH',
              'phoneCode': '+66',
              'countryId': 225
            });
          }
          this.countryList['data'] = nationList;
          this.changeCountry((this.myAccountApiData.data ? (this.myAccountApiData.data.kyc ? (this.myAccountApiData.data.kyc.kycBasicDetails ? (this.myAccountApiData.data.kyc.kycBasicDetails.country? this.myAccountApiData.data.kyc.kycBasicDetails.country : 'Thailand') : 'Thailand') : 'Thailand') : 'Thailand'), false);
        } else {
          this.countryList['data'] = [];
        }
      }, error => {
        this.countryList['data'] = [];
      });
    }
  
    changeCountry(event, whichOne) {
      let countrydata;
      if (whichOne) {
        countrydata = this.countryList.data.filter((item) => {
          return item.countryName.toLowerCase() === this.stepTwoForm.value.country.toLowerCase();
        });
      } else {
        countrydata = this.countryList.data.filter((item) => {
          return item.countryName.toLowerCase() === event.toLowerCase();
        });
      }
      if (countrydata.length) {
        this.getStateList(countrydata, whichOne);
      }
    }
  
    getStateList(countrydata, whichOne) {
      this.service.getMethod(`setting/get-state-list?countryId=${encodeURIComponent(this.service.encrypt(JSON.stringify(countrydata[0].countryId)))}&languageName=${encodeURIComponent(this.service.encrypt(this.currLanguage))}`, 1).subscribe(success => {
        if (success['status'] === 706) {
          this.stateList = success;
          if (!whichOne) {
            this.stepTwoForm.patchValue({
              state: (this.myAccountApiData.data ? (this.myAccountApiData.data.kyc ? (this.myAccountApiData.data.kyc.kycBasicDetails ? (this.myAccountApiData.data.kyc.kycBasicDetails.state ? this.myAccountApiData.data.kyc.kycBasicDetails.state : '') : '') : '') : '')
            });
          }
        } else {
          this.stateList = [];
        }
      }, error => {
          this.stateList = [];
      });
    }
  
    selectNationality() {
      if ((this.kycFirstStep.value.nationality ? (this.kycFirstStep.value.nationality).toLowerCase() : '') === 'thailand') {
        this.showThaiNameFields = true;
      } else {
        this.showThaiNameFields = false;
      }
    }
  
    firstStepNext(event) {
      let validOrNot = false;
      if (this.kycUploaded) {
        validOrNot = true;
      }
      if (this.userData.data.userType !== 'INDIVIDUAL') {
        if (this.firstStepCompanyForm.invalid || this.kycFirstStep.value.functionInCompany === null || this.kycFirstStep.value.functionInCompany === '' || !this.companyNumValidOrNot) {
          validOrNot = true;
        }
        if (this.kycFirstStep.value.functionInCompany === null || this.kycFirstStep.value.functionInCompany === '') {
          validOrNot = true;
        }
      }
      if (this.kycFirstStep.invalid) {
        validOrNot = true;
      }
      if (this.kycFirstStep.value.nationality) {
        if (this.kycFirstStep.value.nationality.toLowerCase() === 'thailand') {
          if (this.kycFirstStep.value.thaiFirstName === null || this.kycFirstStep.value.thaiFirstName === '' || this.kycFirstStep.value.thaiLastName === null || this.kycFirstStep.value.thaiLastName === '') {
            validOrNot = true;
          }
        }
      } else {
        validOrNot = true;
      }
      if (validOrNot) {
        this.showFirstStepValidation = true;
        return false;
      }
      this.step = event;
      return true;
    }
  
    secondStepNext(event) {
      let secondStepValidOrNot = false;
      if (this.kycUploaded) {
        secondStepValidOrNot = true;
      }
      if (this.stepTwoForm.invalid || !this.firstStepNext('2')) {
        secondStepValidOrNot = true;
      }
      if (this.kycFirstStep.value.nationality.toLowerCase() === 'thailand') {
        if (this.kycFirstStep.value.thaiFirstName === null || this.kycFirstStep.value.thaiLastName === null) {
          secondStepValidOrNot = true;
        }
      }
      if (secondStepValidOrNot) {
        this.showSecondStepValidation = true;
        return false;
      }
      if (event === '3') {
        if (navigator.getUserMedia) {
          navigator.getUserMedia(
            {
              video: true
            },
            (localMediaStream) => {
              this.zone.run(() => {
                this.iswebcam = true;
              });
            },
            (err) => {
              $('#browserNotSupported').modal({backdrop: 'static', keyboard: false});
            }
          );
        } else {
          this.iswebcam = false;
          $('#browserNotSupported').modal({backdrop: 'static', keyboard: false});
          alert('Sorry, your browser does not support getUserMedia');
        }
      }
      this.step = event;
      setTimeout(() => {
        this.getCountries();
      }, 500);
      return true;
    }
  
    thirdStepNext(event) {
      let thirdStepValidOrNot = false;
      if (this.kycUploaded) {
        thirdStepValidOrNot = true;
      }
      if (this.userData.data.userType !== 'INDIVIDUAL') {
        if (this.companyStepThreeForm.invalid) {
          thirdStepValidOrNot = true;
        }
        if (this.id['taxCertificate'] === '' || this.id['taxCertificate'].name === null) {
          thirdStepValidOrNot = true;
        }
        if (this.id['taxCertificate'] !== '' || this.id['taxCertificate'].name !== null) {
          if (this.id['taxCertificate'].size < 1000000 || this.id['taxCertificate'].size > 5000000) {
            thirdStepValidOrNot = true;
          }
        }
        if (this.id['authoriseLetter'] === '' || this.id['authoriseLetter'].name === null) {
          thirdStepValidOrNot = true;
        }
        if (this.id['authoriseLetter'] !== '' || this.id['authoriseLetter'].name !== null) {
          if (this.id['authoriseLetter'].size < 1000000 || this.id['authoriseLetter'].size > 5000000) {
            thirdStepValidOrNot = true;
          }
        }
      } else {
        if (this.stepThreeForm.value.usCitizen === '' || this.stepThreeForm.value.usResident === '' || this.stepThreeForm.value.usCitizen === null || this.stepThreeForm.value.usResident === null) {
          thirdStepValidOrNot = true;
        }
      }
      if (this.stepThreeForm.invalid || this.stepTwoForm.invalid || !this.firstStepNext('3')) {
        thirdStepValidOrNot = true;
      }
      if (this.kycFirstStep.value.nationality === 'Thailand') {
        if (this.stepThreeForm.value.nationalIdNumber === '' || this.stepThreeForm.value.laserCode === '' || this.stepThreeForm.value.nationalIdNumber === null || this.stepThreeForm.value.laserCode === null) {
          thirdStepValidOrNot = true;
        }
      } else {
        if (this.stepThreeForm.value.passportNumber === '' || this.stepThreeForm.value.passportNumber === null) {
          thirdStepValidOrNot = true;
        }
      }
      if (this.id['backId'] === '' || this.id['frontId'] === '' || this.id['backId'].name === null || this.id['frontId'].name === null) {
        thirdStepValidOrNot = true;
      } else {
        if (this.id['backId'].size < 1000000 || this.id['backId'].size > 5000000
          || this.id['frontId'].size < 1000000 || this.id['frontId'].size > 5000000) {
          thirdStepValidOrNot = true;
        }
      }
      if (!this.iswebcam) {
        if ((this.stepThreeForm.value.lineId === '') && (this.stepThreeForm.value.whatsappId === '')
             && (this.stepThreeForm.value.weChatId === '') || (this.stepThreeForm.value.lineId === null) && (this.stepThreeForm.value.whatsappId === null)
             && (this.stepThreeForm.value.weChatId === null)) {
              thirdStepValidOrNot = true;
        }
        if (!$('#lineIdNumb').intlTelInput('isValidNumber')) {
          thirdStepValidOrNot = true;
        }
        if (!$('#whatsappNum').intlTelInput('isValidNumber')) {
          thirdStepValidOrNot = true;
        }
        if (!$('#weChatNum').intlTelInput('isValidNumber')) {
          thirdStepValidOrNot = true;
        }
      }
      const webcam = this.webcamImage;
      if (this.iswebcam) {
        if (!(!!webcam)) {
          this.selfiImage = {show: true, msg: 'Please click your selfi'};
          thirdStepValidOrNot = true;
        }
      }
      if (thirdStepValidOrNot) {
        this.showThirdStepValidation = true;
        return false;
      }
      this.step = event;
      this.numbers.push($('#lineIdNumb').intlTelInput('getNumber'));
      this.numbers.push($('#whatsappNum').intlTelInput('getNumber'));
      this.numbers.push($('#weChatNum').intlTelInput('getNumber'));
      return true;
    }
  
    telInputFuncLineId() {
      $(document).on('click', '.country', () => {
        this.lineIdKeyup();
        this.whatsappKeyup();
        this.weChatKeyup();
        this.companyPhoneNumberValidOrNot();
      });
    }
  
    whatsappKeyup() {
      this.zone.run(() => {
        if (this.stepThreeForm.value.whatsappId === '') {
          this.whatsappNumValidOrNot = true;
        } else {
          this.whatsappNumValidOrNot = $('#whatsappNum').intlTelInput('isValidNumber');
        }
      });
    }
  
    lineIdKeyup() {
      this.zone.run(() => {
        if (this.stepThreeForm.value.lineId === '') {
          this.lineIdValidOrNot = true;
        } else {
          this.lineIdValidOrNot = $('#lineIdNumb').intlTelInput('isValidNumber');
        }
      });
    }
  
    weChatKeyup() {
      this.zone.run(() => {
        if (this.stepThreeForm.value.lineId === '') {
          this.weChatValidOrNot = true;
        } else {
          this.weChatValidOrNot = $('#weChatNum').intlTelInput('isValidNumber');
        }
      });
    }
  
    stepchange(event) {
      if (this.kycUploaded) {
        return false;
      }
      this.step = event;
      setTimeout(() => {
        this.getCountries();
      }, 500);
    }
  
    detectWebcam(callback) {
      const md = navigator.mediaDevices;
      if (!md || !md.enumerateDevices) {
        return callback(false);
      }
      md.enumerateDevices().then(devices => {
        callback(devices.some(device => 'videoinput' === device.kind));
      });
    }
  
    backTab(event) {
      this.step = event;
      setTimeout(() => {
        this.getCountries();
      }, 500);
    }
  
    submitKYCData() {
      this.spinner.show();
      if (!this.firstStepNext('4') || !this.secondStepNext('4') || !this.thirdStepNext('4')) {
        this.spinner.hide();
        return;
      }
      const apireq = {
        document: [
          {
            companyTaxNumber  : this.companyStepThreeForm.value.companyTaxNumber,
            dbd               : this.IdURLs['DBD'],
            taxCertificateUrl : this.IdURLs['taxCertificate'],
            passportNumber    : this.stepThreeForm.value.passportNumber,
            backImageUrl      : this.IdURLs['backId'],
            frontImageUrl     : this.IdURLs['frontId'],
            selfieImageUrl    : this.IdURLs['selfi'],
            authoriseLetterUrl: this.IdURLs['authoriseLetter'],
            usCitizen         : this.stepThreeForm.value.usCitizen,
            usResident        : this.stepThreeForm.value.usResident,
            weChat            : !this.iswebcam ? (this.numbers.length ? this.numbers[2] : '') : '',
            whatsAppNumber    : !this.iswebcam ? (this.numbers.length ? this.numbers[1] : '') : '',
            lineId            : !this.iswebcam ? (this.numbers.length ? this.numbers[0] : '') : '',
            laserCode         : this.stepThreeForm.value.laserCode,
            nationalIdNumber  : this.stepThreeForm.value.nationalIdNumber,
          }
        ],
        kycBasicDetails: {
            companyName             : this.firstStepCompanyForm.value.companyName,
            registrationNo          : this.firstStepCompanyForm.value.companyRegistrationNumber,
            companyWebsite          : this.firstStepCompanyForm.value.companyWebsite,
            companyPhoneNo          : this.firstStepCompanyForm.value.companyPhoneNumber,
            nationality             : this.kycFirstStep.value.nationality,
            dob                     : this.kycFirstStep.value.dob.epoc ? (this.kycFirstStep.value.dob.epoc * 1000) : 0,
            companyFunction         : this.kycFirstStep.value.functionInCompany,
            title                   : this.kycFirstStep.value.title,
            thaiFirstName           : this.kycFirstStep.value.thaiFirstName,
            thaiMiddleName          : this.kycFirstStep.value.thaiMiddleName,
            thaiLastName            : this.kycFirstStep.value.thaiLastName,
            englishFirstName        : this.kycFirstStep.value.englishFirstName,
            englishMiddleName       : this.kycFirstStep.value.englishMiddleName,
            englishLastName         : this.kycFirstStep.value.englishLastName,
            addressOne              : this.stepTwoForm.value.adressOne,
            addressTwo              : this.stepTwoForm.value.addressTwo,
            country                 : this.stepTwoForm.value.country,
            state                   : this.stepTwoForm.value.state,
            city                    : this.stepTwoForm.value.city,
            postalCode              : this.stepTwoForm.value.postalCode,
          }
      };
      const data = this.service.encrypt(JSON.stringify(apireq));
      this.service.postMethod('account/save-kyc-basic-details', { kycDto : data }, 1).subscribe(success => {
        if (success.status === 280) {
          this.spinner.hide();
          this.getMyData();
          $('#KYCUploadedSuccessfullyModal').modal({backdrop: 'static', keyboard: false});
        } else {
          this.spinner.hide();
        }
      }, error => {
        this.spinner.hide();
      });
    }
  
    getId(event, frontOrBack) {
      if (event.target.files && event.target.files[0]) {
        const file = event.target.files[0];
        if (file.type === 'image/jpeg' ||  file.type === 'image/jpg' || file.type === 'image/png' || ((frontOrBack === 'DBD' || frontOrBack === 'authoriseLetter') ? (file.type === 'application/pdf') : false)) {
          if (file.size < 5000000) {
            if (frontOrBack === 'back') {
              this.uploadingIdError['backId'] = { show: false, msg: '' };
              this.id['backId'] = event.target.files[0];
              const reader = new FileReader();
              reader.onload = (e: any) => {
                this.idBase64['backId'] = e.target.result;
              };
              reader.readAsDataURL(event.target.files[0]);
              this.uploadImage('backId', event.target.files);
            } else {
              if (frontOrBack === 'taxCertificate') {
                this.uploadingIdError['taxCertificate'] = { show: false, msg: '' };
                this.id['taxCertificate'] = event.target.files[0];
                const reader = new FileReader();
                reader.onload = (e: any) => {
                  this.idBase64['taxCertificate'] = e.target.result;
                };
                reader.readAsDataURL(event.target.files[0]);
                this.uploadImage('taxCertificate', event.target.files);
              } else {
                if (frontOrBack === 'DBD') {
                  this.uploadingIdError['DBD'] = { show: false, msg: '' };
                  this.id['DBD'] = event.target.files[0];
                  const reader = new FileReader();
                  reader.onload = (e: any) => {
                    this.idBase64['DBD'] = e.target.result;
                  };
                  reader.readAsDataURL(event.target.files[0]);
                  this.uploadImage('DBD', event.target.files);
                } else {
                  if (frontOrBack === 'authoriseLetter') {
                    this.uploadingIdError['authoriseLetter'] = { show: false, msg: '' };
                    this.id['authoriseLetter'] = event.target.files[0];
                    const reader = new FileReader();
                    reader.onload = (e: any) => {
                      this.idBase64['authoriseLetter'] = e.target.result;
                    };
                    reader.readAsDataURL(event.target.files[0]);
                    this.uploadImage('authoriseLetter', event.target.files);
                  } else {
                    this.uploadingIdError['frontId'] = { show: false, msg: '' };
                    this.id['frontId'] = event.target.files[0];
                    const reader = new FileReader();
                    reader.onload = (e: any) => {
                      this.idBase64['frontId'] = e.target.result;
                    };
                    reader.readAsDataURL(event.target.files[0]);
                    this.uploadImage('frontId', event.target.files);
                  }
                }
              }
            }
          } else {
            if (frontOrBack === 'back') {
              this.uploadingIdError['backId'] = { show: true, msg: 'backIdSizeError' };
            } else {
              if (frontOrBack === 'taxCertificate') {
                this.uploadingIdError['taxCertificate'] = { show: true, msg: 'taxCertificateSizeError' };
              } else {
                if (frontOrBack === 'DBD') {
                  this.uploadingIdError['DBD'] = { show: true, msg: 'DBDSizeError' };
                } else {
                  if (frontOrBack === 'authoriseLetter') {
                    this.uploadingIdError['authoriseLetter'] = { show: true, msg: 'authoriseLetterSizeError' };
                  } else {
                    this.uploadingIdError['frontId'] = { show: true, msg: 'frontIdSizeError' };
                  }
                }
              }
            }
          }
        } else {
          if (frontOrBack === 'back') {
            this.uploadingIdError['backId'] = { show: true, msg: 'backIdFormatError' };
          } else {
            if (frontOrBack === 'taxCertificate') {
              this.uploadingIdError['taxCertificate'] = { show: true, msg: 'taxCertificateFormatError' };
            } else {
              if (frontOrBack === 'DBD') {
                this.uploadingIdError['DBD'] = { show: true, msg: 'DBDFormatError' };
              } else {
                if (frontOrBack === 'authoriseLetter') {
                  this.uploadingIdError['authoriseLetter'] = { show: true, msg: 'authoriseLetterFormatError' };
                } else {
                  this.uploadingIdError['frontId'] = { show: true, msg: 'frontIdFormatError' };
                }
              }
            }
          }
        }
      }
    }
    uploadImage(whichId, imageData) {
      this.spinner.show();
      this.fileData = new FormData();
      this.fileData.append('file', imageData[0]);
      this.service.postMethod('account/uploadFile', this.fileData,2).subscribe(success => {
        if (whichId === 'backId') {
          this.IdURLs['backId'] = success.fileName;
        } else {
          if (whichId === 'frontId') {
            this.IdURLs['frontId'] = success.fileName;
          } else {
            if (whichId === 'selfi') {
              this.IdURLs['selfi'] = success.fileName;
            } else {
              if (whichId === 'taxCertificate') {
                this.IdURLs['taxCertificate'] = success.fileName;
              } else {
                if (whichId === 'DBD') {
                  this.IdURLs['DBD'] = success.fileName;
                } else {
                  if (whichId === 'authoriseLetter') {
                    this.IdURLs['authoriseLetter'] = success.fileName;
                  }
                }
              }
            }
          }
        }
        this.spinner.hide();
      }, error => {
        this.spinner.hide();
      });
    }
  
    KYCApprovedContinueButton() {
      if (this.userData.data.kycStatus === 'ACCEPTED') {
        this.router.navigate(['/my-account/authentication/en']);
      }
    }
  
    ngOnDestroy() {
      this.unsubscribeUserInfo.unsubscribe();
    }
}
