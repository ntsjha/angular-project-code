import { Component, OnInit } from "@angular/core";
import { MainServiceService } from "src/app/main-service.service";
import { Ng4LoadingSpinnerService } from "ng4-loading-spinner";
import { Router } from "@angular/router";

@Component({
  selector: "app-my-profile",
  templateUrl: "./my-profile.component.html",
  styleUrls: ["./my-profile.component.css"]
})
export class MyProfileComponent implements OnInit {
  basicLabels = [
    { label: "Name" },
    { label: "Email Id" },
    { label: "Contact No." },
    { label: "Address" }
  ];

  bussinessLabel = [
    { label: "Name" },
    { label: "Address" },
    { label: "Contact No." }
  ];

  petrolData=[
    {'name':"Mr. Nobody"},
    {"addres":"Somewhere"},
    {'contact':"99999999"}
  ];
  profileData:any ={
     'name':"Mr. Nobody",
     'email':"nobody@gmail.com",
     'phoneNumber':"9999999999",
     'address':"Somewhere"
    };
  userImage:any;
  petrolPumpData:any=[
    {'petrolPumpName':"pp1",'address':"Modinagar",'mobileNumber':"9045146697"},
    {'petrolPumpName':"pp2",'address':"Modinagar",'mobileNumber':"9045146697"},
  ];
  constructor(public service:MainServiceService, public spinner:Ng4LoadingSpinnerService,public router:Router) {}


  ngOnInit() {
    this.getProfileData();
  }
  getProfileData(){
    this.spinner.show();
    this.service.get('user/getProfile',1).subscribe( res=>{
      this.spinner.hide();
      this.profileData=res['result'];
      console.log('DATA===>', this.profileData)
      this.petrolPumpData=res['result'].petrolPump;
      console.log('PetrolPump-->',this.petrolPumpData[0]._id)
      localStorage.setItem('petrolpump_data',this.petrolPumpData[1]._id);
      this.userImage=res['result'].profilePic;
      console.log(this.profileData);
   console.log(res);
   }, err=>{
     this.spinner.hide();
     console.log(err);
   })
  }
  editProfile(){
     this.router.navigate(['header/edit-profile']);
  }
  userManagment(){
    this.router.navigate(['header/usermanagment']);
  }
  
  toggleChange(val){
    console.log("Checko------>",val.target.checked)
  }
  onChange(data){
    console.log("Checked------>")
  }
  buysubscription(){
    this.router.navigate(['buysubscription']);

  }
  
}
