import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';
import { ServiceServicesProvider } from "../../providers/service-services/service-services";

@IonicPage()
@Component({
  selector: 'page-contacts-add',
  templateUrl: 'contacts-add.html',
})
export class ContactsAddPage {

  AddContactForm: FormGroup;
  constructor(public navCtrl: NavController, public navParams: NavParams, public fb: FormBuilder, public service: ServiceServicesProvider) {
    //----------------------------------------- BUILD ADD CARD FORM & VALIDATE IT -----------------------------------------//
    this.AddContactForm = fb.group({
      'name': [null, Validators.compose([Validators.required])],
      'number': [null, Validators.compose([Validators.required])]
    });

    if(this.navParams.get('edit'))
      this.AddContactForm.setValue({
        name: this.navParams.get('edit').name,
        number: this.navParams.get('edit').number
      })
  }

  back() {
    this.navCtrl.pop();
  }

  next() {
    if (navigator.onLine) {
    if(this.navParams.get('edit'))
      this.editContact();
    else
      this.addContact();
    } else
      this.service.presentToast('Your internet connections seems to be lost')
  }

  addContact() {
    this.service.presentLoading();
      this.AddContactForm.value.userId = localStorage.getItem('userId');
      this.service.postApi(this.AddContactForm.value, 'user/addContact', 0).subscribe(
        (response: any) => {
          this.service.dismissLoading();
          if (response[`response_code`] == 200) {
            this.navCtrl.pop();
            this.service.presentToast(response[`response_message`])
          } else if (response[`response_code`] == 403 || response[`response_code`] == 409 || response[`response_code`] == 401) {
            this.service.presentToast(response[`response_message`])
            this.service.logout();
          } else {
            this.service.presentToast(response[`response_message`])
          }
        },
        err => {
          this.service.dismissLoading();
          this.service.presentToast('Something went wrong')
        }
      )
  }

  editContact() {
    this.service.presentLoading();
      this.AddContactForm.value.userId = localStorage.getItem('userId');
      this.AddContactForm.value.id = this.navParams.get('edit')._id;
      this.service.postApi(this.AddContactForm.value, 'user/editContact', 0).subscribe(
        (response: any) => {
          this.service.dismissLoading();
          if (response[`response_code`] == 200) {
            this.navCtrl.pop();
            this.service.presentToast(response[`response_message`])
          } else if (response[`response_code`] == 403 || response[`response_code`] == 409 || response[`response_code`] == 401) {
            this.service.presentToast(response[`response_message`])
            this.service.logout();
          } else {
            this.service.presentToast(response[`response_message`])
          }
        },
        err => {
          this.service.dismissLoading();
          this.service.presentToast('Something went wrong')
        }
      )
  }

}
