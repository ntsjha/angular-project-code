import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MinimumDepositFiatComponent } from './minimum-deposit-fiat.component';

describe('MinimumDepositFiatComponent', () => {
  let component: MinimumDepositFiatComponent;
  let fixture: ComponentFixture<MinimumDepositFiatComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MinimumDepositFiatComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MinimumDepositFiatComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
