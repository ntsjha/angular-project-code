import { Component, OnInit } from '@angular/core';
import { AppComponent } from '../../../app.component';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { ServerService } from '../../../service/server.service';
import { HeaderComponent } from '../../header/header/header.component';
import { Router } from '@angular/router';
declare var $: any;

@Component({
    selector: 'app-wallet',
    templateUrl: './wallet.component.html',
    styleUrls: ['./wallet.component.css']
})
export class WalletComponent implements OnInit {
    coinFullName: any;
    textValue: any;
    myAngularxQrCode: any = null;
    withdrawObj = { amount: "", address: "", tagID: "", fee: "" }
    numRegxForDot = (/(?: |^)\d*\.?\d+(?: |$)/);
    regexForEightChar = (/^(\d+)?([.]?\d{0,8})?$/);
    regexForBtc = (/^[123][a-km-zA-HJ-NP-Z1-9]{25,34}$/);
    regexForLtc = (/^[LM3][a-km-zA-HJ-NP-Z1-9]{26,33}$/);
    regexForEth = (/^0x[a-fA-F0-9]{40}$/);
    symbol: any;
    coinFee: any = [];
    coinListArr = [];
    coinList = [];
    tagId: any;
    kyc: any = [];
    checkyc: boolean = false;
    coinShortName: any;
    balance: any;
    coinBalance: any = 0.0;
    convertObj = { coinType: '', amt: "0.0", marketPrice: 0.0 };
    checkAmount = false;
    marketPrice: any;
    demotest = null

    constructor(private appC: AppComponent, private spinnerService: Ng4LoadingSpinnerService, private server: ServerService, public header: HeaderComponent, public router: Router) {
    }

    ngOnInit() {
        window.scrollTo(0, 0);
        this.getCoinListWithBalance();
    }

    /** Function to get coin list with their balance */
    getCoinListWithBalance() {
        this.spinnerService.show();
        this.server.getApi("wallet/coin/get-coin-list", 0).subscribe((succ) => {
            this.spinnerService.hide();
            if (succ.body.status == 200) {
                succ.body.data.forEach(element => {
                    if (element.coinShortName == 'BTC' || element.coinShortName == 'ETH' || element.coinShortName == 'XRP' || element.coinShortName == 'BCH' || element.coinShortName == 'XLM' || element.coinShortName == 'LTC' || element.coinShortName == 'IOTA' || element.coinShortName == 'USDT' || element.coinShortName == 'ECH' || element.coinShortName == 'XVG' || element.coinShortName == 'USD' || element.coinShortName == 'IPR') {
                        this.coinListArr.push({
                            "coinId": element.coinId,
                            "coinFee": element.withdrawlFee,
                            "coinFullName": element.coinFullName,
                            "coinImage": element.coinImage,
                            "coinMarketPrice": element.coinMarketPrice,
                            "coinShortName": element.coinShortName,
                            "coinType": element.coinType,
                            "withdrawlFee": element.withdrawlFee,
                            "coinDescription": element.coinDescription,
                            "usdPrice": element.usdPrice,
                            "balance": element.balance,
                            "blockBalance": element.blockBalance,
                        });
                    } if (element.coinShortName == 'BTC' || element.coinShortName == 'ETH' || element.coinShortName == 'XRP' || element.coinShortName == 'BCH' || element.coinShortName == 'XLM' || element.coinShortName == 'LTC' || element.coinShortName == 'IOTA' || element.coinShortName == 'USDT' || element.coinShortName == 'ECH' || element.coinShortName == 'XVG' || element.coinShortName == 'IPR') {
                        this.coinList.push(element);
                    }
                });
                this.convertObj.coinType = this.coinList[0].coinShortName;
                this.getCoinWalletBalance();
                this.getCoinAvailableBalance(this.coinList[0].coinShortName);
                // this.getCurrentUSDMktPrice(this.coinList[0].coinShortName);
            }
        }, (err) => {
            this.spinnerService.hide();
        });
    }

    /** Function for deposit */
    depositFunc(obj) {
        
        if (obj.coinShortName == "USD") {
            this.router.navigateByUrl('header/deposit');
        } else if (obj.coinShortName == "XRP") {

            this.spinnerService.show();
            this.server.getApi("wallet/wallet-type2/get-address?coinName=" + obj.coinShortName, localStorage.getItem('token')).subscribe((succ) => {
                this.spinnerService.hide();
                if (succ.body.status == 200) {
                    this.appC.showInfoToast(succ.body.message);
                    this.coinFullName = succ.body.data.coinName;
                    this.textValue = succ.body.data.walletAddress;
                    this.myAngularxQrCode = succ.body.data.walletAddress;
                    this.tagId = succ.tag;
                    $('#deposite').modal({ backdrop: 'static', keyboard: false });
                } else {
                    this.appC.showErrToast(succ.body.message);
                }
            }, (err) => {
                this.spinnerService.hide();
                this.appC.showErrToast(err.error.message);
            });

        }

        else {
            this.spinnerService.show();
            this.server.getApi("wallet/wallet/get-address?coinName=" + obj.coinShortName, localStorage.getItem('token')).subscribe((succ) => {
                this.spinnerService.hide();
                if (succ.body.status == 200) {
                    // this.appC.showInfoToast('Address fetched successfully.');
                    this.coinFullName = succ.body.data.coinName;
                    this.textValue = succ.body.data.walletAddress;
                    this.myAngularxQrCode = succ.body.data.walletAddress;
                    this.tagId = succ.tag;
                    $('#deposite').modal({ backdrop: 'static', keyboard: false });
                } else if (succ.body.status == 403) {
                    this.header.tokenExpire();
                } else {
                    this.appC.showErrToast(succ.body.message);
                }
            }, (err) => {
                this.spinnerService.hide();
                this.appC.showErrToast(err.error.message);
            });
        }
    }

    /** Function for withdraw */
    withdrawFunc() {
        console.log('coinname-->',this.coinFullName,this.symbol)
        if (this.withdrawObj.address == "") {
            this.appC.showErrToast("Enter address");
            return;
        } else if (this.coinFullName == 'BITCOIN') {
            if (!this.regexForBtc.test(this.withdrawObj.address)) {
                this.appC.showErrToast("Enter valid address ");
                return;
            }
        } else if (this.coinFullName == 'LITECOIN') {
            if (!this.regexForLtc.test(this.withdrawObj.address)) {
                this.appC.showErrToast("Enter valid address ");
                return;
            }
        } else if (this.coinFullName == 'ETHEREUM') {
            if (!this.regexForEth.test(this.withdrawObj.address)) {
                this.appC.showErrToast("Enter valid address ");
                return;
            }
        } else if (this.withdrawObj.amount == "") {
            this.appC.showErrToast("Enter amount value");
            return;
        } else if (!this.numRegxForDot.test(this.withdrawObj.amount)) {
            this.appC.showErrToast("Enter valid amount value");
            return;
        } else if (this.symbol == "XRP" || this.symbol == "XLM") {
            if (this.withdrawObj.tagID == "") {
                this.appC.showErrToast("Enter Tag ID.");
                return;
            }
        }
        this.checkKycStatus();
    }

    withdraw(obj) {
        if (obj.coinShortName == "USD") {
            this.router.navigateByUrl('header/withdraw');
        } else if (obj.balance > 0) {
            this.clearWithdrawFields();
            this.symbol = obj.coinShortName;
            this.coinFullName = obj.coinFullName;
            this.getCoinFee(obj);
        } else
            this.appC.showErrToast('Insufficient balance')
    }

    limitDigit(val) {
        if (val.includes(".")) {
            let str = "" + val;
            this.withdrawObj.amount = str.split('.')[0] + '.' + str.split('.')[1].slice(0, 8);
        }
    }

    limitDigitAmt() {
        if (this.convertObj.amt.includes(".")) {
            let str = "" + this.convertObj.amt;
            this.convertObj.amt = str.split('.')[0] + '.' + str.split('.')[1].slice(0, 8);
        } else if (this.convertObj.amt == '') {
            this.convertObj.marketPrice = 0.0;
        }
    }



    checkAmountValidation() {
        if (this.convertObj.amt > this.coinBalance) {
            this.checkAmount = true;
        } else {
            this.checkAmount = false;
        }
    }

    /** Function to submit withdraw after validation */
    submitWithdraw() {
        let data = {
            "amount": this.withdrawObj.amount,
            "coinName": this.symbol,
            "tag": this.withdrawObj.tagID,
            "toAddress": this.withdrawObj.address
        }
        console.log('withdrwa')
        this.spinnerService.show();
        this.server.postApi("wallet/wallet/withdraw", data, localStorage.getItem('token')).subscribe((succ) => {
            this.spinnerService.hide();
            if (succ.body.status == 200) {
                this.appC.showInfoToast("A confirmation mail has been sent to your registered E-mail ID. Please click on that link to complete the process.");
                $('#withdrawl').modal("hide");
            } else {
                this.appC.showErrToast(succ.body.message);
            }
        }, (err) => {
            this.spinnerService.hide();
            this.appC.showErrToast(err.error.message);
        });
    }

    /** Function to clear withdraw fields */
    clearWithdrawFields() {
        this.withdrawObj.address = "";
        this.withdrawObj.amount = "";
        this.withdrawObj.tagID = "";
    }

    /** get coin fee */
    getCoinFee(obj) {
        this.coinFee = obj.withdrawlFee;
        $('#withdrawl').modal({ backdrop: 'static', keyboard: false });
    }

    transactionDetail(obj) {
        this.coinShortName = obj.coinShortName;
        this.router.navigateByUrl('header/transactionDetail/' + this.coinShortName);
    }

    transactionDetailUSD() {
        this.router.navigateByUrl('header/TransactionDetail');
    }

    /** To check Kyc status */
    checkKycStatus() {
        this.kyc = [];
        let kycDetails = {

            "token": localStorage.getItem('token')
        }

        this.spinnerService.show();
        this.server.getApi('account/get-kyc-details', localStorage.getItem('token')).subscribe(response => {
            this.spinnerService.hide();
            if (response.body.status == 200) {
                console.log('KYC data-->')
                console.log('KYC-->', response.body)
                this.kyc = response.body.data
                if (response.body.document == "undefined") {
                    this.appC.showInfoToast("To get the functionalities of the Bittnomy exchange you need to get your kyc done");
                } else if (this.kyc.kycStatus == 'ACCEPTED' ) {
                    console.log("hiii")
                    this.checkyc = true;
                    this.submitWithdraw();
                }
                else if (this.kyc.kycStatus == null){
                    this.appC.showInfoToast('KYC verification is required to withdraw amount.');
                }

            } else {
                this.appC.showErrToast(response.body.message);
            }
        }, error => {
            this.appC.showErrToast(error.error.message);
            this.spinnerService.hide();
        });
    }
  
    getCoinWalletBalance() {
        for (let i = 0; i < this.coinListArr.length; i++) {
            let data = {
               
                        "coinType": this.coinListArr[i].coinShortName,
                        
            }
           
            this.spinnerService.show();
            this.server.getApi("wallet/wallet/get-balance?coinName="+data.coinType, localStorage.getItem('token')).subscribe((succ) => {
                this.spinnerService.hide();
                if (succ.status == 200) {
                    console.log('getbalance-->',succ.body.data.walletBalance)
                    this.coinListArr[i].balance = succ.body.data.walletBalance;
                    this.coinListArr[i].blockBalance = succ.body.data.blockedBalance;
                } else if (succ.status == 403) {
                    this.header.tokenExpire();
                } else {
                }
            }, (err) => {
                this.spinnerService.hide();
            });
        }
    }

    getCoinAvailableBalance(coin) {
        
        this.server.getApi("wallet/wallet/get-balance?coinName="+coin, localStorage.getItem('token')).subscribe((succ) => {
            if (succ.status == 200) {
                this.coinBalance = (succ.body.data.walletBalance).toFixed(5);
            } else if (succ.statusCode == 403) {
                this.header.tokenExpire();
            } else {
            }
        }, (err) => {
        });

    }

    /**  Function to open convert modal */
    openConvertModal() {
        $('#convert').modal({ backdrop: 'static', keyboard: false });
    }

    getCurrentUSDPrice() {
        this.convertObj.marketPrice = Number((this.marketPrice * Number(this.convertObj.amt)).toFixed(8));

    }

    // getCurrentUSDMktPrice(coin) {
    //     this.convertObj.amt = "0.0";
    //     this.server.get("https://min-api.cryptocompare.com/data/pricemultifull?fsyms=" + coin + "&tsyms=USD").subscribe((succ) => {
    //         this.convertObj.marketPrice = 0.0;
    //         this.marketPrice = succ.RAW[coin].USD.PRICE;
    //     }, (err) => {
    //     });
    // }

    // convertFunc() {
    //     let data = {
    //         "eventExternal": {
    //             "name": "request_update_USD_balance",
    //             "key": "mykey"
    //         },
    //         "transferObjectMap": {
    //             "gatewayrequest": {
    //                 "cryptoCoin": this.convertObj.coinType,
    //                 "cryptoCoinBalance": this.convertObj.amt,
    //                 "usdBalance": this.convertObj.marketPrice,
    //                 "loginToken": localStorage.getItem("token"),

    //             }
    //         }
    //     }
    //     this.spinnerService.show();
    //     this.server.postApi("", data, 0).subscribe((succ) => {
    //         if (succ.transferObjectMap.statusCode == 200) {
    //             this.spinnerService.hide();
    //             this.appC.showSuccToast(succ.transferObjectMap.message);
    //             $('#convert').modal("hide");
    //             this.getCoinWalletBalance();
    //         } else {
    //             this.spinnerService.hide();
    //         }
    //     }, (err) => {
    //         this.spinnerService.hide();
    //     });

    // }

    /** Function to restrict space */
    restrictSpace(event) {
        var k = event.charCode;
        if (k === 32) return false;
    }

    /** Function to restrict character */
    restrictChar(event) {
        var k = event.charCode;
        if (event.key === 'Backspace')
            k = 8;
        if (k >= 48 && k <= 57 || k == 8 || k == 46)
            return true;
        else
            return false;
    }

}
