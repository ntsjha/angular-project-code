import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExchangepairComponent } from './exchangepair.component';

describe('ExchangepairComponent', () => {
  let component: ExchangepairComponent;
  let fixture: ComponentFixture<ExchangepairComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExchangepairComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExchangepairComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
