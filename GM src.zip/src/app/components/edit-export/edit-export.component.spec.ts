import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditExportComponent } from './edit-export.component';

describe('EditExportComponent', () => {
  let component: EditExportComponent;
  let fixture: ComponentFixture<EditExportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditExportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditExportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
