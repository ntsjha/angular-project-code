import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators} from '@angular/forms';
import { Router } from '@angular/router';
import { MainComponent } from '../main/main.component';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent  {

  submitted = false;
  item:any

  ngOnInit(){
    this.item = JSON.parse(localStorage.getItem('token'));
    console.log(this.item.email);
  }
  
  profileForm = new FormGroup({ 
   email: new FormControl('',[Validators.required,Validators.maxLength(25),Validators.pattern(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/)]),
    password: new FormControl('',[Validators.required, Validators.maxLength(16),
      Validators.pattern("^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$")] ),     
    });
  message: string;
  
    constructor(private router: Router) {}
    
    get f() { return this.profileForm.controls; }

  onSubmit() {
    
    this.submitted = true;
     
       
    if(this.f.email.value == this.item.email){
      alert("Login successful");
     
      this.router.navigate(['main']);    

       }
    else{
      alert("Please check your userid and password");
    }

  
  
    console.warn(this.profileForm.value);   
  }
  
  
  }


