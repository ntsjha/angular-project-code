import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, AlertController } from 'ionic-angular';
import { LoginPage } from '../login/login';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ServiceServicesProvider } from '../../providers/service-services/service-services';
import { TabsPage } from "../tabs/tabs";

@IonicPage()
@Component({
  selector: 'page-pin',
  templateUrl: 'pin.html',
})
export class PinPage {
  form: FormGroup
  constructor(public navCtrl: NavController, public navParams: NavParams, private server: ServiceServicesProvider, public alerCtrl: AlertController) {
  }
  // Validators.pattern(/^\S*$/),

  ngOnInit() {
    this.form = new FormGroup({
      // userName :new FormControl('', [ Validators.required]),
      pin: new FormControl('', [Validators.minLength(4), Validators.required, Validators.pattern(/^\d+$/)]),
      retypePin: new FormControl('', Validators.required)
    }, pinValidator)

    /** Function for password match and mismatch */
    function pinValidator(g: FormGroup) {
      let pass = g.get('pin').value;
      let confPass = g.get('retypePin').value;
      if (pass != confPass) {
        g.get('retypePin').setErrors({ mismatch: true });
      } else {
        g.get('retypePin').setErrors(null)
        return null
      }
    }
  }

  get userName(): any {
    return this.form.get('userName')
  }

  get pin(): any {
    return this.form.get('pin')
  }

  get retypePin(): any {
    return this.form.get('retypePin')
  }

  registerPin() {
    if (navigator.onLine) {
      this.server.presentLoading();
      let data = {
        "pin": this.form.value.pin,
        "userName": localStorage.getItem('userName')
      }
      this.server.postApi(data, 'user/setPin', 0).subscribe((res: any) => {
        this.server.dismissLoading();
        if (res.response_code == 400) {
          this.server.presentToast(res.response_message)
        } else if (res.response_code == 200) {
          localStorage.setItem('userName', localStorage.getItem('userName'));
          this.navCtrl.setRoot(TabsPage, { selectedTab: 2 })
          this.server.presentToast(res.response_message)
        }
        else if (res.response_code == 403 || res.response_code == 409 || res.response_code == 401) {
          this.server.presentToast(res.response_message)
          this.server.logout();
        }
        else
          this.server.presentToast(res.response_message)
      }, err => {
        this.server.dismissLoading();
        this.server.presentToast('Something went wrong')
      })
    } else
      this.server.presentToast('Your internet connection seems to be lost')
  }

  signin() {
    this.navCtrl.setRoot(LoginPage)
  }
}
