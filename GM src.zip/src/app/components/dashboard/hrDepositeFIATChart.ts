
declare var CanvasJS: any;

export class hrDepositeFIATChartService {
    chart: any;
    chartCoinData: { type: string; xValueFormatString: string; yValueFormatString: string; name: string; dataPoints: { x: Date; y: number; }[]; }[];

    hrDepositeCryptoChartData(data, chartId) {
        if (data.length !== 0 ) {
        } else {
            this.chartCoinData = [ {
                type: 'spline',
                xValueFormatString: 'hh:mm TT',
                yValueFormatString: '#,##0.###',
                name: '',
                dataPoints: [{ x: (new Date()), y: 0 }],
              }
            ];
        }
        this.chart = new CanvasJS.Chart(chartId, {
            exportEnabled: true,
            zoomEnabled: true,
            animationEnabled: true,
            axisX: {
                valueFormatString: 'hh:mm TT'
            },
            axisY: {
                includeZero: false,
            },
            legend: {
                cursor: 'pointer',
                fontSize: 16,
            },
            toolTip: {
                shared: true
            },
            data: this.chartCoinData
        });
        return this.chart.render();
    }
}


