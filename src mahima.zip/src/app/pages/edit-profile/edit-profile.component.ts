import { FormGroup, Validators, FormControl, FormArray, FormBuilder } from "@angular/forms";
import { Component, OnInit } from "@angular/core";
import { MainServiceService } from "src/app/main-service.service";
import { Ng4LoadingSpinnerService } from "ng4-loading-spinner";
import { Router } from "@angular/router";
declare var $: any;
@Component({
  selector: 'app-edit-profile',
  templateUrl: './edit-profile.component.html',
  styleUrls: ['./edit-profile.component.css']
})
export class EditProfileComponent implements OnInit {
  basicLabels = [
    { label: "Name" },
    { label: "Email Id" },
    { label: "Contact No." },
    { label: "Address" }
  ];
  bussinessLabel = [
    { label: "Name" },
    { label: "Address" },
    { label: "Contact No." }
  ];



  profileData: any;
  userImage: any = "assets/image/person.jpg";
  editForm: any;
  addPetrolForm: FormGroup;
  petrolPumpData = [];
  petrolPump: FormArray;
  imageUrl: any;

  public myForm: FormGroup;
  state=[];
  data=[];
  city: any;
  statevalue: any;
  cityvalue: any;
  constructor(
    public service: MainServiceService,
    public spinner: Ng4LoadingSpinnerService,
    public router: Router,
    public fb: FormBuilder
  ) { }
  ngOnInit() {
    this.getProfileData(1);
    this.editFormMethod();
    this.addPetrolPumpFormMethod();


this.getcity();

  }

getcity(){

  fetch('/assets/state-city.json')
  .then(response => response.json())
  .then(json => {
    this.data=json
     this.state=(Object.keys(json))
    //  console.log('data==>', this.state)
    
    
  }, err => {
    // alert('loss')
      console.log(err);
    })
  
}

  getSelectedOptionText(event) {
    // console.log(event.target.value)
    this.statevalue=event.target.value;

    this.city= (Object.values(this.data[this.statevalue]))
    this.cityvalue=this.city
    // console.log('data==>', this.city)
        
    }
    getSelectedOptioncity(event) {
      this.cityvalue=event.target.value
      console.log(this.cityvalue)
    }


   
  /** to check characters */
  toCheckSpaceChar(evt) {
    if (!this.editForm.value.name) {
      var charCode = (evt.which) ? evt.which : evt.keyCode;
      if ((charCode == 32) || (charCode > 47 && charCode < 58)) {
        evt.preventDefault()
      } else {
        return true;
      }
    }

  }




  // editfrom mehtod
  editFormMethod() {
    this.editForm = new FormGroup({
      name: new FormControl("", [Validators.required, Validators.minLength(2), Validators.maxLength(250), Validators.pattern(/^[a-zA-Z ]{2,30}$/)]),
      email: new FormControl("", [Validators.required, Validators.maxLength(65), Validators.pattern(/^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,3}|[0-9]{1,3})(\]?)$/)]),
      userContact: new FormControl("", [Validators.required, Validators.pattern(/^[6-9]\d{9}$/)]),
      userAddress: new FormControl("", [Validators.required, Validators.maxLength(100), Validators.pattern(/^[-a-zA-Z0-9-()]+(\s+[-a-zA-Z0-9-()]+)*$/)]),
      petrolPump: this.fb.array([]),

    });
  }
  // cerate petrolpump from  array
  createPetrolPump(data): FormGroup {
    var mainData = !!data ? data : {petrolPumpName: '', address: '', mobileNumber:''}
    // console.log('anshul main data ===>>', mainData, data);
    return this.fb.group({
      petrolPumpName: new FormControl(mainData.petrolPumpName, [Validators.required, Validators.maxLength(250), Validators.pattern(/^[[a-zA-Z]+[[ '-]?[a-zA-Z]+]*$/)]),
      petrolPumpAddress: new FormControl(mainData.address, [Validators.required, Validators.maxLength(100), Validators.pattern(/^[-a-zA-Z0-9-()]+(\s+[-a-zA-Z0-9-()]+)*$/),]),
      petrolPumpContact: new FormControl(mainData.mobileNumber, [Validators.required, Validators.pattern(/^[6-9]\d{9}$/)])
    });
  }
  // add petrolpump array to template
  addPetrolPumpArray(data): void {
    // console.log('addPetrolPumpArray', data);
    // this.petrolPump = [];
    this.petrolPump = this.editForm.get("petrolPump") as FormArray;
    this.petrolPump.push(this.createPetrolPump(data));

  }
  // delete prtrolpump array from template
  deletePetrolPumpArray(i) {
    this.petrolPump = this.editForm.get("petrolPump") as FormArray;
    this.petrolPump.removeAt(i)
  }
  // add petrolpump form method
  addPetrolPumpFormMethod() {

    this.addPetrolForm = new FormGroup({
      petrolName: new FormControl("", [Validators.required, Validators.minLength(2), Validators.maxLength(250), Validators.pattern(/^[[a-zA-Z]+[[ '-]?[a-zA-Z]+]*$/)]),
      petrolBrandName: new FormControl("", [Validators.required]),
      pinCode: new FormControl("", [Validators.required, Validators.pattern(/^[1-9][0-9]{5}$/)]),
      address: new FormControl("", [Validators.required, Validators.maxLength(100), Validators.pattern(/^[-a-zA-Z0-9-()]+(\s+[-a-zA-Z0-9-()]+)*$/)]),
      city: new FormControl("", [Validators.required, Validators.maxLength(50)]),
      ownerName: new FormControl("", [Validators.required, Validators.minLength(2), Validators.maxLength(250), Validators.pattern(/^[[a-zA-Z]+[[ '-]?[a-zA-Z]+]*$/)]),
      mobileNumber: new FormControl("", [Validators.required, Validators.pattern(/^[6-9]\d{9}$/)]),
      state: new FormControl("", [Validators.required, Validators.maxLength(50),]),
      email: new FormControl("", [Validators.required, Validators.maxLength(65), Validators.pattern(/^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,3}|[0-9]{1,3})(\]?)$/)]),
      landMark: new FormControl("", [Validators.required, Validators.maxLength(100), Validators.pattern(/^[-a-zA-Z0-9-()]+(\s+[-a-zA-Z0-9-()]+)*$/)])
    });
  }
  // get profile data
  getProfileData(option) {
    if (option != 0) {
      this.spinner.show();
      this.service.get("user/getProfile", 1).subscribe(
        res => {
          // console.log(res);
          this.spinner.hide();
          if (res["responseCode"] == 200) {
            this.profileData = res["result"];
            this.userImage = res["result"].profilePic;
            this.petrolPumpData = [];
            this.petrolPumpData.push(res["result"].petrolPump);
            // console.log('datapetrolpump ===>', this.petrolPumpData,this.petrolPumpData[0].length);
// setTimeout(()=>{
  for (let i = 0; i < this.petrolPumpData[0].length; i++) {
         
    // console.log('data i-->',this.petrolPumpData[i]);
 this.addPetrolPumpArray(this.petrolPumpData[0][i]);


 
}
// },1000)

              
            // for(let i=1;i<this.petrolPumpData.length;i++){
            //   this.deletePetrolPumpArray(i);
            // }
            // console.log('PetorlPumpData>>>>>>', this.petrolPumpData)
            let modifyPetrolPumpData = [];
            this.petrolPumpData.map(a => {
              for (let i = 0; i < a.length; i++) {
                // console.log('anshul-->>', a)
                this.createPetrolPump(a[i])
                // let obj = {
                //   petrolPumpName: a[i].petrolPumpName,
                //   petrolPumpAddress: a[i].address,
                //   petrolPumpContact: a[i].mobileNumber
                // };
                // modifyPetrolPumpData.push(obj);
              }
            });
            this.setValueOfUser(modifyPetrolPumpData);
          } else {
            // console.log(res);
          }
        },
        err => {
          this.spinner.hide();
          // console.log(err);
        }
      );
    } else {
      this.spinner.show();
      this.service.get("user/getProfile", 1).subscribe(
        res => {
          // console.log(res);
          this.spinner.hide();
          if (res["responseCode"] == 200) {
            this.profileData = res['result'];
            this.userImage = res['result'].profilePic;
            this.petrolPumpData = [];
            this.petrolPumpData.push(res['result'].petrolPump);
            // console.log('Aashish ===>', this.petrolPumpData, this.petrolPumpData[0].length);
            // console.log('Aashish ===>', res['result'], this.petrolPumpData[0].length);
            for (let i = 1; i < this.petrolPumpData[0].length; i++) {
              
              // console.log('value i-->',i);
              this.addPetrolPumpArray(this.petrolPumpData[i]);
              
            }

            // for(let i=1;i<this.petrolPumpData.length;i++){
            //   this.deletePetrolPumpArray(i);
            // }

            let modifyPetrolPumpData = [];
            this.petrolPumpData.map(a => {
              for (let i = 0; i < a.length; i++) {
                let obj = {
                  petrolPumpName: a[i].petrolPumpName,
                  petrolPumpAddress: a[i].address,
                  petrolPumpContact: a[i].mobileNumber
                };
                modifyPetrolPumpData.push(obj);
              }
            });
            this.setValueOfUser(modifyPetrolPumpData);
          } else {
            // console.log(res);
          }
        },
        err => {
          this.spinner.hide();
          // console.log(err);
        }
      );
    }

  }
  setValueOfUser(data) {
    // console.log('Data>>>>>>>>', data)
    this.editForm.patchValue({
      name: this.profileData.name ? this.profileData.name : "",
      email: this.profileData.email ? this.profileData.email : "",
      userContact: this.profileData.phoneNumber
        ? this.profileData.phoneNumber
        : "",
      userAddress: this.profileData.address ? this.profileData.address : "",
      petrolPump: data
    });
  }

  
  // Add petrolpump method
  addPetrolPump() {
    $("#addPetrolModal").modal({ backdrop: "static", keyboard: false });
  }
  // update user profile
  updateProfile() {
    // console.log('edit form value===>>>', this.editForm.value);
    this.spinner.show();
    let checkPhoneOrEmail = {
      email: this.editForm.value.email,
      phoneNumber: this.editForm.value.userContact
    };
    //  console.log('MY-->',this.petrolPumpData[0]);
    let modifyPetrolPumpData = [];
    // this.petrolPumpData.map((a, i) => {
      // console.log("inner map", a, i);
      // console.log('edit form value ===>>>', this.editForm.value)
      for (let i = 0; i < this.editForm.value.petrolPump.length; i++) {
        let obj = {
          _id: this.petrolPumpData[0][i]._id,
          petrolPumpName: this.editForm.value.petrolPump[i].petrolPumpName,
          mobileNumber: this.editForm.value.petrolPump[i].petrolPumpContact,
          address: this.editForm.value.petrolPump[i].petrolPumpAddress,
          dayShiftStartTime: this.editForm.value.petrolPump[i].dayShiftStartTime,
          dayShiftEndTime: this.editForm.value.petrolPump[i].dayShiftEndTime,
          nightShiftStartTime: this.editForm.value.petrolPump[i].nightShiftStartTime,
          nightShiftEndTime: this.editForm.value.petrolPump[i].nightShiftEndTime

        };

        // console.log('OBJ-->', obj);
        modifyPetrolPumpData.push(obj);
        
      }
    // });
    console.log('MODIFY==>',modifyPetrolPumpData);
    let updateData = {
      profilePic: this.imageUrl ? this.imageUrl : this.profileData.profilePic,
      subscriptionsPlan: this.profileData.subscriptionsPlan,
      email: this.editForm.value.email,
      phoneNumber: this.editForm.value.userContact,
      name: this.editForm.value.name,
      address: this.editForm.value.userAddress,
      petrolPump: modifyPetrolPumpData
    };

    console.log('update Data>>>', updateData);
    this.service
      .post("user/checkEmailAndPhoneNumber", checkPhoneOrEmail, 1)
      .subscribe(
        res => {
          if (res["responseCode"] == 200) {
            this.service.post("user/editProfile", updateData, 1).subscribe(
              res => {
                // console.log("edit profile>>>>", res)
                this.spinner.hide();
                if (res["responseCode"] == 200) {
                  this.service.showSuccess(res["responseMessage"]);
                  this.getProfileData(0);
                  this.router.navigate(['header/profile']);
                }
              },
              err => {
                this.spinner.hide();
              }
            );
          } else {
            this.spinner.hide();
            this.service.showInfo(res["responseMessage"]);
          }
        },
        err => {
          this.spinner.hide();
          // console.log(err);
        }
      );
  }

  // add petrol method
  addPetrol() {
    // console.log(this.addPetrolForm.value);
    let petrolPumpData = {
      petrolPumpName: this.addPetrolForm.value.petrolName,
      ownerName: this.addPetrolForm.value.ownerName,
      brandName: this.addPetrolForm.value.petrolBrandName,
      mobileNumber: this.addPetrolForm.value.mobileNumber,
      pinCode: this.addPetrolForm.value.pinCode,
      state: this.statevalue,
      address: this.addPetrolForm.value.address,
      email: this.addPetrolForm.value.email,
      city: this.cityvalue,
      landmark: this.addPetrolForm.value.landMark
    };
    this.spinner.show();
   
    this.service.post("user/addPetrolPump", petrolPumpData, 1).subscribe(
      res => {
        if (res["responseCode"] == 200) {
          this.router.navigate(['header/profile']);
          this.service.showSuccess(res["responseMessage"]);
          this.addPetrolForm.reset();
          $("#addPetrolModal").modal("hide");
          this.petrolPumpData = [];

          this.getProfileData(1);
        
        } else {
        }
        this.spinner.hide();
        // console.log(res);
       
        $("#addPetrolModal").modal("hide");
      },
      error => {
        // console.log(error);
      }
    );
  }
  handleFileSelect(evt) {
    var files = evt.target.files;
    var file = files[0];

    if (files && file) {
      var reader = new FileReader();
      reader.onload = this._handleReaderLoaded.bind(this);
      reader.readAsBinaryString(file);

    }
  }
  _handleReaderLoaded(readerEvt) {
    var binaryString = readerEvt.target.result;
    let base64textString = btoa(binaryString);
    let data = {
      profilePic: "data:image/jpeg;base64," + base64textString
    }
    this.spinner.show();
    this.service.post('user/imageUpload', data, 37).subscribe(res => {
      this.spinner.hide();
      if (res['responseCode'] == 200) {
        this.imageUrl = res['result'];
      }
    }, err => {
      this.spinner.hide();
      // console.log(err);
    })

  }

}
