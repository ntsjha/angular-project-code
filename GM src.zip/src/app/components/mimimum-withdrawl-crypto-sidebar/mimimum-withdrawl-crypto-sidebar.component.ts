import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ServiceService } from 'src/app/service/service.service';
import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'app-mimimum-withdrawl-crypto-sidebar',
  templateUrl: './mimimum-withdrawl-crypto-sidebar.component.html',
  styleUrls: ['./mimimum-withdrawl-crypto-sidebar.component.css']
})
export class MimimumWithdrawlCryptoSidebarComponent implements OnInit {
  withdrawlCrypto: any[];
  user: any;

  constructor(
    private cookie: CookieService,
    private service: ServiceService,
    private spinner: NgxSpinnerService,
    private activatedRoute: ActivatedRoute,
    private route: Router
  ) { 
    this.user = (this.cookie.get('userInfo')) ? JSON.parse(this.cookie.get('userInfo')) : this.service.initialUserInfo;
  }

  ngOnInit() {
    this.getWithdrawlCrypto();
    window.scrollTo(0,0);
    this.CheckAndCreate();
  }


  goToMinWithdrawCrypto(coinName) {
    if (this.service.sideMenuArr.includes('updateSettings')) {
      this.route.navigate(['/mimimum-withdrawl-crypto-update-sidebar/' + coinName]);
    }
  }

  CheckAndCreate() {
    this.service.getMethod('wallet/admin/withdrawal-limit/check-and-create?ipAddress=' + encodeURIComponent(this.service.encrypt(this.user.ip)) + '&location=' +  encodeURIComponent(this.service.encrypt(this.user.city + ',' + this.user.country_name)), 1).subscribe((response:any) => {});
  }



  getWithdrawlCrypto() {
    this.spinner.show();
    this.service.getMethod('wallet/admin/withdrawal-limit/get-all', 1).subscribe((response: any) => {
      this.spinner.hide();
      var responseData = JSON.parse(this.service.decrypt(response.data));
      if (responseData.status === 845 || responseData.status === 842) {
        this.withdrawlCrypto = JSON.parse(this.service.decrypt(response.data)).data;
        this.withdrawlCrypto.forEach(element => {
          if(element.updatedByName == null) {
            element.updatedAt = null;
          }
        });
      }
    }, (error) => {
      this.spinner.hide();
    });
    this.spinner.hide();

  }
}
