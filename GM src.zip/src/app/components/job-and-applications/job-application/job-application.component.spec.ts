import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { JobApplicationComponent } from './job-application.component';
import { FormGroup, FormControl } from '@angular/forms';

describe('JobApplicationComponent', () => {
  let component: JobApplicationComponent;
  let fixture: ComponentFixture<JobApplicationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [JobApplicationComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(JobApplicationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    this.jobApplication = new FormGroup({
      search: new FormControl(null),
      status: new FormControl(null),
    })
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('general form invalid when empty', async(() => {
    const emptyValue = component.jobApplicationTest('', '');
    expect(emptyValue).toBeFalsy();
  }));

  it('general form valid with all fields', async(() => {
    const value = component.jobApplicationTest('123456', 'publish');
    expect(value).toBeTruthy();
  }));
});
