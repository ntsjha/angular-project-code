import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MachinereadingComponent } from './machinereading.component';

describe('MachinereadingComponent', () => {
  let component: MachinereadingComponent;
  let fixture: ComponentFixture<MachinereadingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MachinereadingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MachinereadingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
