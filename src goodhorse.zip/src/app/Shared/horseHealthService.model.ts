export class HorseHealthService{
    id:string
    sl_no: string
    service: string
    contact:string
    medication: string
    dsage: string
    start_date: string
    duration: string
    frequency: string
    time: string
    note: string
}