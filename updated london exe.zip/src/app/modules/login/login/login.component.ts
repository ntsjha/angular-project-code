import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ServerService } from '../../../service/server.service';
import { AppComponent } from '../../../app.component';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { HeaderComponent } from '../../header/header/header.component';
import { Observable } from '../../../../../node_modules/rxjs/Observable';

declare var $ :any;
@Component({
    selector: 'app-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
    loginForm:FormGroup;
    loginData:any={};
    qrCode = {Code1:""};
    code: any;
    token:any;
    name:any;
    otp = { one: "", two: "", three: "", four: "",five:"",six:"" };
    time: number;
    seconds: number = 59;
    Id: any;
    showEye: boolean = false;    
    page: string;

    constructor(private router: Router, private spinnerService :Ng4LoadingSpinnerService, private header:HeaderComponent, private appC:AppComponent ,private server:ServerService) { }

    ngOnInit() {
        window.scrollTo(0,0);
        this.checkInputs();
        this.verifyEmail()
    }

    /** Function to validate form inputs */
    checkInputs() {
        this.loginForm = new FormGroup({
            lemail: new FormControl('sss@mailinator.com', [Validators.required, Validators.pattern(/^[A-Z0-9_]+([\.-][A-Z0-9_]+)*@[A-Z0-9-]+(\.[a-zA-Z]{2,5})+$/i)]),
            password: new FormControl('Mobiloitte1@', [Validators.required]),
            remember:new FormControl(''),            
        });
        /*this.loginForm = new FormGroup({
            lemail: new FormControl('lcxtoken@mailinator.com', [Validators.required, Validators.pattern(/^[A-Z0-9_]+([\.-][A-Z0-9_]+)*@[A-Z0-9-]+(\.[a-zA-Z]{2,5})+$/i)]),
            password: new FormControl('qwerty@1', [Validators.required]),
            remember:new FormControl(''),            
        });*/
        
    }

    myTimer() {
        Observable.interval(1000)
        .takeWhile(() => this.seconds > 0 || (this.seconds != 60 && this.seconds > 0))
        .subscribe(i => { 
            --this.seconds;
        })
        if(this.seconds==0) {
            clearInterval(this.seconds);
        }
    }
    
    resendOtp() {
        this.seconds= 59;
        this.resend();
    }

    /**for login function */
    login() {
        let loginData = {
                    "email": this.loginForm.value.lemail, 
                    "password": this.loginForm.value.password
                }
            
        this.spinnerService.show();
        this.server.postApi('auth', loginData,0).subscribe(response => {        
            this.spinnerService.hide();
            console.log('auth',response.body)
            if(response.body.status==203) {
                this.appC.showErrToast(response.body.message);
                this.router.navigate(['/header/verify']);
             }
            else if (response.body.status == 200) {   
                if(response.body.data.TwoFa == 'NONE') {
         
                    this.router.navigate(['/header/twofa/',response.body.data.token]);
                  }
                  else{
                    if(response.body.data.TwoFa=="GOOGLE"){
                      this.token=response.body.data.token
                      console.log('>>>>>Token',this.token)
                      $('#googleAuth').modal({backdrop:'static',keyboard:false})
                                         
                        // this.qrVerify();
                   
                }
          
                else{
                    response.body.data.TwoFa=="SMS"
                 
                   localStorage.setItem('token', response.body.data.token)
                    this.token= response.body.data.token
                    // this.router.navigateByUrl('')
                    
                     $("#otp").modal({ backdrop: 'static', keyboard: false });
                     this.server.getApi('auth/send-sms-code',this.token).subscribe((res)=> {
      
                      this.spinnerService.hide();
                      this.myTimer();
                    //   this.smsVerify();
                     })
                    }
              }
             } else{
                this.appC.showErrToast(response.body.message);
              }
             
            
            
        }, error => {
            this.spinnerService.hide();
            if(error.status == 401) {
                this.appC.showErrToast('incorrect credentials')
               }
          
        });                    
    }

    verifyEmail() {
        let url =window.location.href.split('=')
        this.page = url[url.length - 1]
        console.log(this.page)
    
        if(url.length == 2) {
          this.spinnerService.show();
        this.server.getApi('account/verify-user?token='+this.page,0).subscribe(res => {
          this.spinnerService.hide();
          if(res.body.status == 200) {
            this.appC.showSuccToast(res.message);
    
    //check two FA Type
        } else {
            this.appC.showErrToast(res.message);
            this.router.navigate(['/header/verify']);
        }
        this.router.navigateByUrl('/header/login')
    
        }, error => {
            this.spinnerService.hide();
        })
      }
    }

    /**to navigate to signup page */
    signup() {
        this.router.navigateByUrl('header/signup')
    }
    
    /**for forget password function */
    forgetpassword() {
        this.router.navigateByUrl('header/forgotpassword');
    }

    /** to get the value of field  */
    get lemail(): any {
        return this.loginForm.get('lemail');
    }
    get password(): any {
        return this.loginForm.get('password');
    }

    qrVerify() {
        let data = {
                    "otp": this.qrCode.Code1,
                }
          
        this.spinnerService.show();
        this.server.postApi('auth/verify-google', data,this.token).subscribe(response => {
            this.spinnerService.hide();
            if (response.body.status == 200) {
                this.appC.showSuccToast("Qr Code verified successfully");
                localStorage.setItem('token',response.body.data);
                // localStorage.setItem('name',this.name);
                // localStorage.setItem('userId',this.Id);
                $('#googleAuth').modal('hide');
                this.header.checkLogin();
                this.router.navigate(['exHeader']);
            } else {
                this.qrCode = {Code1:""} 
                this.appC.showErrToast(response.body.message);
            }
        }, error => {
            this.spinnerService.hide();
            this.appC.showErrToast('Something went wrong');
        });
    }

    smsVerify() {
        this.code =  this.otp.one + this.otp.two + this.otp.three + this.otp.four + this.otp.five  + this.otp.six ;
        let data = {
          
                    "code":this.code,
                  
                }
          
        this.spinnerService.show();
        this.server.postApi('auth/verify-sms', data,this.token).subscribe(response => {
            this.spinnerService.hide();
            if (response.body.status == 200) {
                this.appC.showSuccToast(response.body.message);
                localStorage.setItem('token',response.body.data);
                // localStorage.setItem('name',this.name);
                // localStorage.setItem('userId',this.Id)
                $('#otp').modal('hide');
                this.header.checkLogin();
                this.router.navigate(['exHeader']);
            } else {
                this.otp = { one: "", two: "", three: "", four: "",five:"",six:"" };   
                this.appC.showErrToast("Please enter correct OTP.");
            }
        }, error => {
            this.spinnerService.hide();
            this.appC.showErrToast('Something went wrong');
        });    
    }

   

    /** Auto focus functionality */
    onKey(value, type) {
        if (type == 1) {
            if (value != "") {
                $('#otp2').focus();
            }
        } else if (type == 2) {
            if (value != "") {
                $('#otp3').focus();
            }
        } else if (type == 3) {
            if (value != "") {
                $('#otp4').focus();
            }
        } else if (type == 4) {
            if (value != "") {
                $('#otp5').focus();
            }
            
        } 
        else if (type == 5) {
            if (value != "") {
                $('#otp6').focus();
            }
            
        } 
        else if (type == 6) {
            if (value != "") {
                $('#otp6').focus();
            }
            
        } 
    }

    resend() {
      
        this.myTimer();
        this.spinnerService.show();
        this.server.getApi('auth/send-sms-code',this.token).subscribe(response => {
            this.spinnerService.hide();
            if (response.body.status == 200) {
                
                
               this.otp = { one: "", two: "", three: "", four: "" ,five: "", six: ""};
                
            } else {
                this.otp = { one: "", two: "", three: "", four: "" ,five: "", six: ""};
       
                this.appC.showErrToast(response.body.message);                
            }
        }, error => {
            this.spinnerService.hide();
            this.appC.showErrToast('Something went wrong');
        });
    }

    /** to show and hide password */
    showHidePassword() {
        if(this.showEye == false) {
        this.showEye = true;
        } else if(this.showEye == true){
        this.showEye = false;
        }
    }
    // otpSend() {
    //     let data =   {
    //         "eventExternal": {
    //             "name":"request_sms_auth",
    //             "key":"mykey"
    //         },
    //         "transferObjectMap": {
    //             "gatewayrequest": {
    //                 "phoneCountryCode":'',
    //                 "phone":'',
    //                 "token":this.token
    //             }
    //         }
    //     }    
    //     this.spinnerService.show();
    //     this.server.postApi('', data,0).subscribe(response => {
    //         this.spinnerService.hide();
    //         if (response.transferObjectMap.statusCode == 200) {
    //             this.appC.showSuccToast(response.transferObjectMap.message);
    //             this.otp = { one: "", two: "", three: "", four: "",five:"",six:"" };   
    //              this.seconds = 59;
    //             $('#otp').modal({backdrop: 'static',keyboard: false});
    //             this.myTimer();                
    //         } else {
    //             this.appC.showErrToast(response.transferObjectMap.message);
                
    //         }
    //     }, error => {
    //         this.spinnerService.hide();
    //         this.appC.showErrToast('Something went wrong');
    //     });
    // }

}
