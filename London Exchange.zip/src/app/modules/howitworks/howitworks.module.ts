import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HowitworksComponent } from './howitworks/howitworks.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [HowitworksComponent]
})
export class HowitworksModule { }
