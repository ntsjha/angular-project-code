import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { ServerService } from '../../../service/server.service';
import { AppComponent } from '../../../app.component';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';

@Component({
    selector: 'app-support',
    templateUrl: './support.component.html',
    styleUrls: ['./support.component.css']
})
export class SupportComponent implements OnInit {
    supportForm: FormGroup;

    constructor(private server: ServerService , private appC: AppComponent, private spinnerService: Ng4LoadingSpinnerService) { }

    ngOnInit() {
        window.scrollTo(0,0);
        this.checkInputs();
    }

    /** Function to validate form inputs */
    checkInputs() {
        this.supportForm = new FormGroup({
            email: new FormControl('', [Validators.required, Validators.pattern(/^[A-Z0-9_]+([\.-][A-Z0-9_]+)*@[A-Z0-9-]+(\.[a-zA-Z]{2,5})+$/i)]),
            message: new FormControl('',[Validators.required])
        })
    }

    /** to get the value of field  */
    get email(): any {
        return this.supportForm.get('email');
    }

    get message(): any {
        return this.supportForm.get('message');
    }

    /**Function to call support API */
    supportFunc() {
        let data = {
          
                    "description": this.supportForm.value.message,
                    "email": this.supportForm.value.email
                }
          
        this.spinnerService.show();
        this.server.postApi('static/support-api', data,0).subscribe(response => {
            this.spinnerService.hide();
            if (response.body.status == 200) {
                this.appC.showSuccToast(response.body.message);  
                this.supportForm.reset();              
            } else {
                this.appC.showErrToast(response.body.message)
            }
        }, error => {
            this.spinnerService.hide();
            this.appC.showErrToast('Something went wrong.');  
        })
    }

}
