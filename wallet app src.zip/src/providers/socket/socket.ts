import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { Injectable } from '@angular/core';
import * as socketIo from 'socket.io-client';

// const SERVER_URL = 'http://172.16.6.254:1600'; // LOCAL MANSI
// const SERVER_URL = 'http://172.16.6.74:1406'; //LOCAL PRAMOD
const SERVER_URL = 'http://162.222.32.20:1406' // STAGING
@Injectable()
export class SocketProvider {

  ETHBalace: any;
    balance: any;
    tokenBalance: any;
    data: any = '';
  constructor() { }

  private socket;

    initSocket(): void {
        this.socket = socketIo(SERVER_URL);
    }

    public send(message): void {
        this.socket.emit('calculatePrice', message);
    }

    public onMessage(event): Observable<any> {
        return new Observable<any>(observer => {
            this.socket.on(event, (data) => {
                if(event == 'calculatePrice')
                    this.data = data.data;
                else
                    this.tokenBalance = data;
                observer.next(data)});
        });
    }

    public onEvent(event): Observable<any> {
        return new Observable<Event>(observer => {
            this.socket.on(event, () => observer.next());
        });
    }

    getBalance() {
      console.log('getbalance')
        this.socket.emit('online_user', {userId:(localStorage.getItem('userId'))?(localStorage.getItem('userId')):''});
        this.onMessage('getBalance')
        .subscribe((response) => {
            // this.balance = message.balance.balance + " " + message.balance.symbol
            // this.ETHBalace = message.ethValue
            console.log('response')
            console.log('message',response)
          if(response.response_code == 200)
            this.balance = response.result;
          else
            this.balance = false;
        });   
    }

}
