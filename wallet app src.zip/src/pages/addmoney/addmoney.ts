import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, App } from 'ionic-angular';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { AddMoneyOptionsPage } from "../add-money-options/add-money-options";
import { ServiceServicesProvider } from "../../providers/service-services/service-services";

@IonicPage()
@Component({
  selector: 'page-addmoney',
  templateUrl: 'addmoney.html',
})
export class AddmoneyPage {
  addMoneyForm: FormGroup;

  constructor(public navCtrl: NavController, public navParams: NavParams, public app: App, public service: ServiceServicesProvider) 
  
  {
    this.addMoneyForm = new FormGroup({
      amount: new FormControl('', [Validators.required, Validators.pattern(/^\d+(\.\d{1,2})?$/)])
    })
  }

 myNumber : number = 10.747647;
  newNumber:string;
  next() {
    if (navigator.onLine) {
      if(this.addMoneyForm.value.amount >= 50) {
        let addMoneyProcess = {
          amount: this.addMoneyForm.value.amount
        }
        localStorage.addMoneyProcess = JSON.stringify(addMoneyProcess);
        this.app.getRootNav().setRoot(AddMoneyOptionsPage);
      }
      else {
        this.service.presentToast('The minimum amount that can be added is 50')
      }
    } else
      this.service.presentToast('Your internet connection seems to be lost')
  }
  Opencheck(){
    this.newNumber = this.myNumber.toFixed(3);
   }

}
