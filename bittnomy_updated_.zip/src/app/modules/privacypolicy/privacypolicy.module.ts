import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PrivacypolicyComponent } from './privacypolicy/privacypolicy.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [PrivacypolicyComponent]
})
export class PrivacypolicyModule { }
