import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CrmfollowersViewPage } from './crmfollowers-view';

@NgModule({
  declarations: [
    CrmfollowersViewPage,
  ],
  imports: [
    IonicPageModule.forChild(CrmfollowersViewPage),
  ],
})
export class CrmfollowersViewPageModule {}
