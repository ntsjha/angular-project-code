import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FaResetDetailComponent } from './fa-reset-detail.component';

describe('FaResetDetailComponent', () => {
  let component: FaResetDetailComponent;
  let fixture: ComponentFixture<FaResetDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FaResetDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FaResetDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
