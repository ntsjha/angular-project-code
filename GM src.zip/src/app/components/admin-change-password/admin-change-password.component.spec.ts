import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminChangePasswordComponent } from './admin-change-password.component';
import { MarketingSidebarComponent } from '../sidebar/sidebar.component';
import { SharedModuleModule } from 'src/app/shared-module/shared-module.module';
import { RouterTestingModule } from '@angular/router/testing';
import { AppComponent } from 'src/app/app.component';
import { RouterModule } from '@angular/router';
import { DeviceDetectorService } from 'ngx-device-detector';
import { FormGroup, FormControl, Validators } from '@angular/forms';

describe('AdminChangePasswordComponent', () => {
  let component: AdminChangePasswordComponent;
  let fixture: ComponentFixture<AdminChangePasswordComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminChangePasswordComponent, MarketingSidebarComponent ],
      imports: [SharedModuleModule, RouterModule,
        RouterTestingModule,],
        providers: [AppComponent, DeviceDetectorService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminChangePasswordComponent);
    component = fixture.componentInstance;
    component.changePasswordForm = new FormGroup({
      oldPassword: new FormControl('', [Validators.required, Validators.minLength(10), Validators.maxLength(128)]),
      newPassword: new FormControl('', [Validators.required, Validators.pattern(/^(?=.{10,128})(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=]).*$/), Validators.minLength(10), Validators.maxLength(128)]),
      confirmPassword: new FormControl('', [Validators.required, Validators.minLength(10), Validators.maxLength(128)]),
  });
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('general form invalid when empty', async(() => {
    const emptyValue = component.changePasswordFormTest('','','');
    expect(emptyValue).toBeFalsy();
  }));

  it('general form valid with all fields', async(() => {
    const value = component.changePasswordFormTest('Mobiloitte@1','Mobiloitte@1','Mobiloitte@1');
    expect(value).toBeTruthy();
  }));
});
