import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ServiceService } from 'src/app/service/service.service';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-translate-faq-topic',
  templateUrl: './translate-faq-topic.component.html',
  styleUrls: ['./translate-faq-topic.component.css']
})
export class TranslateFaqTopicComponent implements OnInit {
  topicToTranslate: any;
  translateThai :any ;
  translateChai :any ;
  api: any = 'static/admin/get-faq-topic-translation';
  thaiLangId: any;
  chaiLangId: any;
  enLangId: any;
  engLangObj: any;
  constructor(private activatedRoutes: ActivatedRoute, private service: ServiceService, private spinner: NgxSpinnerService, private router: Router) { }

  ngOnInit() {
    this.activatedRoutes.params.subscribe((data) => {
      this.topicToTranslate = data.id;
      this.getTranslation();
    });
    window.scrollTo(0, 0);
  }

  editPage(lang , id) {
    this.router.navigate(['/edit-topic/Edit/' + lang + '/' + id]);
  }

  getTranslation() {
    this.spinner.show();
    this.service.postMethod(this.api + '?faqTopicId=' + encodeURIComponent(this.service.encrypt(this.topicToTranslate)), {}, 1)
      .subscribe((response) => {
        this.spinner.hide();
        if (response.status === 170) {
          this.getThaiAndChaiTranslation(response);
        }
      }, (error) => {
        this.spinner.hide();
      });
  }

  getThaiAndChaiTranslation(response) {
    const langList = response.data.languageList.data;
    langList.forEach(element => {
      if (element.languageShortName === 'th') {
        this.thaiLangId = element.languageId;
      } else if (element.languageShortName === 'ch') {
        this.chaiLangId = element.languageId;
      } else {
        this.enLangId = element.languageId;
      }
    });
    const translationData = response.data.translationList;
    translationData.forEach(element => {
      if (element.fkLanguageId === this.thaiLangId) {
        this.translateThai = element;
        if(this.translateThai.updatedBy == null) {
          this.translateThai.updatedAt = null;
        }
      }
      if (element.fkLanguageId === this.chaiLangId) {
        this.translateChai = element;
        if(this.translateChai.updatedBy == null) {
          this.translateChai.updatedAt = null;
        }
      }
      if (element.fkLanguageId === this.enLangId) {
        this.engLangObj = element;
      }
    });
  }
}

