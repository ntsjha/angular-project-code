import { Component, OnInit } from '@angular/core';
import { AppComponent } from '../../../app.component';
import { ServerService } from '../../../service/server.service';
import { Ng4LoadingSpinnerService } from '../../../../../node_modules/ng4-loading-spinner';
import { HeaderComponent } from '../../header/header/header.component';
import { CurrencyPipe } from '@angular/common/src/pipes';

declare var $: any;

@Component({
    selector: 'app-withdrawhistory',
    templateUrl: './withdrawhistory.component.html',
    styleUrls: ['./withdrawhistory.component.css']
})

export class WithdrawhistoryComponent implements OnInit {
    currCoin = "LCX";
    withdrawArr = [];
    explorerName = "https://etherscan.io/address/";

    constructor(private appC: AppComponent, private server: ServerService, private spinnerService: Ng4LoadingSpinnerService, public header:HeaderComponent) { }

    ngOnInit() {
        window.scrollTo(0,0);
        this.getWithdrawHistory(this.currCoin);
    }

    /** Function to get deposit history */
    getWithdrawHistory(coin) {
    //     let data = {
    //         "eventExternal": {
    //             "name": "withdrawlist_history",
    //             "key": "mykey"
    //         },
    //         "transferObjectMap": {
    //             "gatewayrequest": {
    //                 "coinType": coin,
    //                 "token": localStorage.getItem("token")
    //             }
    //         }
    //     }
    //   this.spinnerService.show();
    //     this.server.postApi('', data,0).subscribe(response => {
    //         this.spinnerService.hide();
    //         if (response.transferObjectMap.statusCode == 200) {
    //             this.appC.showSuccToast("Withdraw history fetched successfully.");
    //             this.withdrawArr = response.transferObjectMap.withdraws;
    //         } else if(response.transferObjectMap.statusCode == 403){
    //             this.appC.showErrToast(response.transferObjectMap.message); 
    //             this.header.tokenExpire();
    //         } else {
    //             this.appC.showErrToast(response.transferObjectMap.message);                     
    //         }
    //     }, error => {
    //         this.spinnerService.hide();
    //         //this.appC.showErrToast('Something went wrong');
    //     });      
//     let data = {
//         "coinName": this.coinName

//    }
//    this.router.navigateByUrl('header/transactionDetail/'+this.coinName)
//    console.log('COINTYPE>>>>>>>>>>>>>>>',this. coinName);
   this.spinnerService.show();
   this.server.getApi('wallet/wallet/get-withdrawlist?coinName='+coin+'&page=1&pageSize=1',localStorage.getItem('token')).subscribe(response => {
       this.spinnerService.hide();
       if (response.body.status == 200) {
           this.appC.showSuccToast(response.body.message);
           this.withdrawArr = response.body.data.resultlist;
           console.log('withdraw', this.withdrawArr)
       } else if(response.status == 403){
           this.appC.showErrToast(response.body.message); 
           this.header.tokenExpire()
       } else {
           this.appC.showErrToast(response.body.message);                     
       }
    }, error => {
        this.spinnerService.hide();
        this.appC.showErrToast(error.error.message);
    });


    }

    /** Function for select coin */
    selectCoin(coin) {
        this.currCoin = coin;
        switch(this.currCoin) {
            case 'BTC' : 
                this.explorerName = 'https://live.blockcypher.com/btc/address/';
                break;
            case 'LTC' : 
                this.explorerName = 'https://live.blockcypher.com/ltc/address/';
                break;
            case 'ETH' : 
                this.explorerName = 'https://etherscan.io/address/';
                break;
            case 'DASH' : 
                this.explorerName = 'https://live.blockcypher.com/dash/address/';
                break;
            case 'XRP' : 
                this.explorerName = 'https://bithomp.com/explorer/';
                break;
            case 'NEO' : 
                this.explorerName = 'https://neoscan.io/address/';
                break;
            case 'BCH' : 
                this.explorerName = 'https://explorer.bitcoin.com/bch/address/bitcoincash:';
                break;
            case 'XLM' : 
                this.explorerName = 'https://stellarscan.io/account/';
                break;
            case 'USDT' : 
                this.explorerName = 'https://www.omniexplorer.info/search/';
                break;
            case 'XVG' : 
                this.explorerName = 'https://verge-blockchain.info/address/';
                break;
        }
        this.withdrawArr = [];
        this.getWithdrawHistory(this.currCoin);
    }

}
