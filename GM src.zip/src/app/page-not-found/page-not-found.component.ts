import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-page-not-found',
  templateUrl: './page-not-found.component.html',
  styleUrls: ['./page-not-found.component.css']
})
export class PageNotFoundComponent implements OnInit {

  constructor(
    public router: Router,
    private cookie: CookieService,
    public titleService: Title
  ) { }

  ngOnInit() {
    window.scrollTo(0, 0);
  }

  goToHome() {
    if (!!this.cookie.get('token')) {
      this.router.navigateByUrl('dashboard');
    } else {
      this.router.navigate(['']);
    }
  }

}
