import { Component, OnInit } from '@angular/core';
import { ServiceService } from 'src/app/service/service.service';
import { Router } from '@angular/router';
import { IMyDpOptions, IMyDateModel } from 'mydatepicker';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
    selector: 'app-crypto-withdrawl-req',
    templateUrl: './crypto-withdrawl-req.component.html',
    styleUrls: ['./crypto-withdrawl-req.component.css']
})
export class CryptoWithdrawlReqComponent implements OnInit {
    withdrawArr: any = [];
    obj: any = {};
    public fromPickerOptions: IMyDpOptions = {
        dateFormat: 'dd.mm.yyyy',
    };
    public toPickerOptions: IMyDpOptions = {
        dateFormat: 'dd.mm.yyyy',
    };
    total: any = 0;
    search_key: any = '';
    page = 1;
    coin: any;
    p: any = 1;

    constructor(public service: ServiceService, public router: Router, private spinner: NgxSpinnerService) {}

    ngOnInit() {
        this.getWithdrawalList();
        window.scrollTo(0, 0);
    }

    onFromDateChanged(event: IMyDateModel) {
        let copy1 = this.getCopyOfOptions1();
        copy1.disableUntil = event.date;
        this.toPickerOptions = copy1;
    }

    getCopyOfOptions1(): IMyDpOptions {
        return JSON.parse(JSON.stringify(this.toPickerOptions));
    }

    getCopyOfOptions2(): IMyDpOptions {
        return JSON.parse(JSON.stringify(this.fromPickerOptions));
    }

    onToDateChanged(event: IMyDateModel) {
        let copy1 = this.getCopyOfOptions2();
        copy1.disableSince = event.date;
        this.fromPickerOptions = copy1;
    }

    getWithdrawalList() {
        this.spinner.show();
        let data = {
            page: this.page != 1 ? this.page - 1 : 0,
            pageSize: 10,
            search: this.search_key.trim()
        };

        if (this.obj.fromDate) {
            data['fromDate'] = this.obj.fromDate.epoc ? this.obj.fromDate.epoc * 1000 : null;
        }

        if (this.obj.toDate) {
            data['toDate'] = this.obj.toDate.epoc ? this.obj.toDate.epoc * 1000 + (86400000 - 1) : null;
        }
        this.service.postMethod('wallet/common-permit/history/get-transfer-history', data, 1).subscribe((res) => {
            this.spinner.hide();
            if (res.data.resultlist) {
                this.withdrawArr = res.data.resultlist;
                this.total = res.data.totalCount;
            }
        }, err=> {
            this.spinner.hide();
        });
    }
    viewDetail(data) {
        this.router.navigate(['withdraw-req', 'crypto' + '-' + data.fkUserId + '-' + data.currencyShortName + '-' + data.coinDepositWithdrawalId]);
    }

    managePagination(page) {
        this.page = page;
        this.getWithdrawalList();
    }

    applyFilter() {
        if (this.search_key || (this.obj.fromDate.epoc && this.obj.toDate.epoc)) {
            this.page = 1;
           // this.total = 0;
            this.getWithdrawalList();
        }
    }

    reset() {
        this.page = 1;
        this.search_key = '';
        this.obj = {};
        this.fromPickerOptions = {
            disableSince: { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() + 1 },
            disableUntil: { year: 0, month: 0, day: 0 }
        };
        this.toPickerOptions = {
            disableSince: { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() + 1 },
            disableUntil: { year: 0, month: 0, day: 0 }
        };
        this.getWithdrawalList();
        
    }

}
