import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';
import { FormGroup, Validators, FormControl, FormBuilder } from '@angular/forms';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { Router } from '@angular/router';
export interface PeriodicElement {
  contact: number;
  name: string;
  sno: number;
  email: string;
  role: string;
  shift: string;
  pump: string;
  status: string;
}
@Component({
  selector: 'app-usermgmt',
  templateUrl: './usermgmt.component.html',
  styleUrls: ['./usermgmt.component.css']
})
export class UsermgmtComponent implements OnInit {
  p: number = 1;
  ELEMENT_DATA: PeriodicElement[] = [
      {sno: 1, name: 'Hydrogen', contact: 7563456375, email: 'abc@gmail.com',role : 'manager', shift:'Morning', pump: 'xyz', status:'Action'},
      {sno: 2, name: 'Sulphur', contact: 7563456375, email: 'abc@gmail.com',role : 'manager', shift:'Morning', pump: 'xyz', status:'Action1'},
      {sno: 3, name: 'Hydrogen', contact: 7563456375, email: 'abc@gmail.com',role : 'manager', shift:'Morning', pump: 'xyz', status:'Action'},
      {sno: 4, name: 'Sulphur', contact: 7563456375, email: 'abc@gmail.com',role : 'manager', shift:'Morning', pump: 'xyz', status:'Action1'},
      {sno: 5, name: 'Hydrogen', contact: 7563456375, email: 'abc@gmail.com',role : 'manager', shift:'Morning', pump: 'xyz', status:'Action'},
      {sno: 6, name: 'Sulphur', contact: 7563456375, email: 'abc@gmail.com',role : 'manager', shift:'Morning', pump: 'xyz', status:'Action1'},
      {sno: 7, name: 'Hydrogen', contact: 7563456375, email: 'abc@gmail.com',role : 'manager', shift:'Morning', pump: 'xyz', status:'Action'},
      {sno: 8, name: 'Sulphur', contact: 7563456375, email: 'abc@gmail.com',role : 'manager', shift:'Morning', pump: 'xyz', status:'Action1'},
      {sno: 9, name: 'Hydrogen', contact: 7563456375, email: 'abc@gmail.com',role : 'manager', shift:'Morning', pump: 'xyz', status:'Action'},
      {sno: 10, name: 'Sulphur', contact: 7563456375, email: 'abc@gmail.com',role : 'manager', shift:'Morning', pump: 'xyz', status:'Action1'},
      {sno: 11, name: 'Hydrogen', contact: 7563456375, email: 'abc@gmail.com',role : 'manager', shift:'Morning', pump: 'xyz', status:'Action'},
      {sno: 12, name: 'Sulphur', contact: 7563456375, email: 'abc@gmail.com',role : 'manager', shift:'Morning', pump: 'xyz', status:'Action1'},
  ];
  displayedColumns: string[];
  dataSource: any;
  constructor( public service: DataService,
    public spinner: Ng4LoadingSpinnerService,
    public router: Router,
    public fb: FormBuilder) { }

  ngOnInit() {
    this.displayedColumns = ['sno', 'name', 'email', 'role','contact', 'shift', 'pump', 'status'];
    this.dataSource =  this.ELEMENT_DATA;
  }
  importToCSVFunc() {
    var data = this.ELEMENT_DATA;
    // new Angular5Csv(data, 'User Detail');
  }




  getProfileData(option) {
    if(option!=0){
     this.spinner.show();
     this.service.get("user/getUser", 1).subscribe(
       res => {
         console.log(res);
         this.spinner.hide();
        });
      }
        //  if (res["responseCode"] == 200) {          
        //    this.profileData = res["result"];
        //    this.userImage = res["result"].profilePic;
        //    this.petrolPumpData=[];
        //    this.petrolPumpData.push(res["result"].petrolPump);
        //    console.log('Aashish ===>',this.petrolPumpData, this.petrolPumpData[0].length);
           
        //    for (let i = 1; i <this.petrolPumpData[0].length; i++) {
        //      console.log(i)
        //      this.addPetrolPumpArray();
        //    }
 
          
        //    console.log('PetorlPumpData>>>>>>',this.petrolPumpData)
        //    let modifyPetrolPumpData = [];
        //    this.petrolPumpData.map(a => {
        //      for (let i = 0; i < a.length; i++) {
        //        let obj = {
        //          petrolPumpName: a[i].petrolPumpName,
        //          petrolPumpAddress: a[i].address,
        //          petrolPumpContact: a[i].mobileNumber
        //        };
        //        modifyPetrolPumpData.push(obj);
        //      }
        //    });
        //    this.setValueOfUser(modifyPetrolPumpData);
        //  } else {
        //    console.log(res);
        //  }
      
     
       err => {
         this.spinner.hide();
         console.log(err);
       }
     
 }


}
