import { PermissionPipePipe } from './permission-pipe.pipe';

describe('PermissionPipePipe', () => {
  it('create an instance', () => {
    const pipe = new PermissionPipePipe();
    expect(pipe).toBeTruthy();
  });
});
