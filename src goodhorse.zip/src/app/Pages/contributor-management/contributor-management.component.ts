import { Component, OnInit } from '@angular/core';
import { ServiceService } from 'src/app/Shared/service.service';
import { Contributor } from 'src/app/Shared/Contributor.model';
import { Router } from '@angular/router';
import { AngularFirestore } from '@angular/fire/firestore';

@Component({
  selector: 'app-contributor-management',
  templateUrl: './contributor-management.component.html',
  styleUrls: ['./contributor-management.component.css']
})
export class ContributorManagementComponent implements OnInit {
   contributorList:Contributor[];
  
   pageSize = 5;
   p: number = 1;
   id
   total = 0
  searchText: string = "";
   constructor(private serve: ServiceService, private router: Router, private afb: AngularFirestore) { }
    
   ngOnInit() {
     this.getContributorList();
  }

   // Get Contributor List
   getContributorList(){
    this.searchText = ''
    this.serve.showSpinner() ;   
    this.serve.getContributor().subscribe(res =>{
      // console.log(res)
      var contributorList = res.map(item => {
  
       return {
         id: item.payload.doc.id,
         ...item.payload.doc.data()
       } as Contributor;
     })
     this.serve.hideSpinner();
     console.log('Items====>', contributorList)
           this.contributorList = contributorList.filter(x=>(x['type'] =='Contributor'))
           this.total = this.contributorList.length
      console.log("Contributor List-->>",this.contributorList)
     });
     
   }
  
  // filterCondition(emp) {
  //   return emp.name.toLowerCase().indexOf(this.searchText.toLowerCase()) != -1;
  // }

  contributorEdit(id){
    console.log(id)
    // localStorage.setItem('testEdit',JSON.stringify(item))
    this.router.navigate(['/contributorManagement/editContributorMangement',id])
  }
  contributorView(id){
    // localStorage.setItem('testView',JSON.stringify(item))
     this.router.navigate(['/contributorManagement/viewContributorMangement',id])
  }
  deleteFuction(id){
     this.id=id
     console.log(this.id)
  }
  onDelete() { 
    
    this.afb.doc('people/'+this.id).delete();    
  }
  page(event) {
    console.log(event);
    this.p = event
  }
  

  // Search Functionality
search(){
  
  var searchData = this.contributorList.filter(x=>(x['userName'] == this.searchText));
  console.log("Contributor List-->>",this.searchText,searchData)
  this.contributorList = searchData;
  this.total = this.contributorList.length;
  
  console.log("Contributor List-->>",this.contributorList.length)
}
  

}
