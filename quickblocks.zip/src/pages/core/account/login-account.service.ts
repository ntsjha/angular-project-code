// import { Injectable } from '@angular/core';
// import { NavController } from 'ionic-angular';
// import { HomePage } from '../../home/home';



// @Injectable()
// export class LoginAccountService {

//   constructor(private  navCtrl: NavController) { }

//   canActivate(): boolean {
//     if (this.isLoggedIn()) {
//       this.navCtrl.push(HomePage);
//       return false;
//     } else {
//       return true;
//     }
//   }

//   isLoggedIn() {
//     if (sessionStorage.getItem('session')) {
//       return true;
//     } else {
//       return false;
//     }
//   }
// }
