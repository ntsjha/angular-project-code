import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, App } from 'ionic-angular';
import { SettingprivacyPage } from '../settingprivacy/settingprivacy';
import { CrmInvoicesPage } from '../crm-invoices/crm-invoices';
import { CrmProductsPage } from '../crm-products/crm-products';
import { CrmCutomersPage } from '../crm-cutomers/crm-cutomers';
import { CrmLeadsPage } from '../crm-leads/crm-leads';
import { CreateleadsPage } from '../createleads/createleads';
import { LeadPage } from '../lead/lead';
import { RestProvider } from '../../providers/rest/rest';
import { EditleadscustomerPage } from '../editleadscustomer/editleadscustomer';
import { CrmInvoicesViewPage } from '../crm-invoices-view/crm-invoices-view';
import { CrmProductsviewPage } from '../crm-productsview/crm-productsview';
import { CrmFollowersPage } from '../crm-followers/crm-followers';
import { CrmfollowersViewPage } from '../crmfollowers-view/crmfollowers-view';
import { CrMcreateeventPage } from '../cr-mcreateevent/cr-mcreateevent';
import { CrmEventsViewPage } from '../crm-events-view/crm-events-view';
import { CrMediteventPage } from '../cr-meditevent/cr-meditevent';
import { CustomerLeadsSingleViewPage } from '../customer-leads-single-view/customer-leads-single-view';

/**
 * Generated class for the CrmPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-crm',
  templateUrl: 'crm.html',
})
export class CrmPage {
  hideMe= true;
  hideMe2=true;
  hideme3=true;
  hideMe4=true;
  leadsList: any=[];
  leadsList1: any=[];
  invoicesList: any=[];
  productList: any=[];
  hideMe5= true;
  followersList: any=[];
  hideMe6=true;
  eventsList: any=[];

  constructor(public navCtrl: NavController, private service: RestProvider,public app :App, public navParams: NavParams) {
  }
  ionViewDidLoad() {
    console.log('ionViewDidLoad CrmPage');
    // this.service.presentLoadingDefault('Loading..');
    this.getleads();
    this.getCustomer();
    this.getProducts();
    this.getInvoices();
    this.getFollowers();
    this.getEvents();
    
  }
  ionViewDidEnter(){
    this.getleads();
    this.getCustomer();
    this.getProducts();
    this.getInvoices();
    this.getFollowers();
    this.getEvents();
  }

  doRefresh(refresher) {
    console.log('Begin async operation', refresher);
     this.getleads();
     this.getCustomer();
     this.getProducts();
     this.getInvoices();
     this.getFollowers();
     this.getEvents();
    setTimeout(() => {
      console.log('Async operation has ended');
      refresher.complete();
    }, 2000);
  }
  
  doPulling(refresher) {
    // console.log('DOPULLING', refresher.progress);
  //   console.log('Begin async operation', refresher);
  //   this.getFollowers();
  //  setTimeout(() => {
  //    console.log('Async operation has ended');
  //    refresher.complete();
  //  }, 2000);
  }  
  getCustomer(){
    // this.service.presentLoadingDefault('Loading...');
    this.service.get('customers/list?follco_token=' + localStorage.getItem('new_token'),0).subscribe(res =>{
        console.log(res);
        if(res) {
            // this.service.dismissLoading();
            this.leadsList1 = res['list'];
            // this.time = new Date (this.campaignList[0].created_at);
            // this.time1 =this.time.getDate() + '/' + (this.time.getMonth()+1) + '/' + this.time.getFullYear();
            // console.log(this.time1); 
         
          
        }
    }, err => {
        // this.service.dismissLoading();
        console.log(err);
    })
  }
  getleads() {
    // this.service.presentLoadingDefault('Loading...');
    this.service.get('leads/list?follco_token=' + localStorage.getItem('new_token'),0).subscribe(res =>{
        console.log(res);
        if(res) {
            // this.service.dismissLoading();
            this.leadsList = res['list'];
            // this.time = new Date (this.campaignList[0].created_at);
            // this.time1 =this.time.getDate() + '/' + (this.time.getMonth()+1) + '/' + this.time.getFullYear();
            // console.log(this.time1); 
         
          
        }
    }, err => {
        // this.service.dismissLoading();
        console.log(err);
    })
  }

  getProducts() {
    // this.service.presentLoadingDefault('Loading...');
    this.service.get('products/list?follco_token=' + localStorage.getItem('new_token'),0).subscribe(res =>{
        console.log(res);
        if(res) {
            // this.service.dismissLoading();
            this.productList = res['list'];
            // this.time = new Date (this.campaignList[0].created_at);
            // this.time1 =this.time.getDate() + '/' + (this.time.getMonth()+1) + '/' + this.time.getFullYear();
            // console.log(this.time1); 
         
          
        }
    }, err => {
        // this.service.dismissLoading();
        console.log(err);
    })
}

getInvoices() {
  // this.service.presentLoadingDefault('Loading...');
  this.service.get('invoices/list?follco_token=' + localStorage.getItem('new_token'),0).subscribe(res =>{
      console.log(res);
      if(res) {
          // this.service.dismissLoading();
          this.invoicesList = res['list'];
          // this.time = new Date (this.campaignList[0].created_at);
          // this.time1 =this.time.getDate() + '/' + (this.time.getMonth()+1) + '/' + this.time.getFullYear();
          // console.log(this.time1); 
       
        
      }
  }, err => {
      // this.service.dismissLoading();
      console.log(err);
  })
}

getFollowers() {
  // this.service.presentLoadingDefault('Loading...');
  this.service.get('followers/list?follco_token=' + localStorage.getItem('new_token'),0).subscribe(res =>{
      console.log(res);
      if(res) {
          // this.service.dismissLoading();
          this.followersList = res['list'];
          // this.time = new Date (this.campaignList[0].created_at);
          // this.time1 =this.time.getDate() + '/' + (this.time.getMonth()+1) + '/' + this.time.getFullYear();
          // console.log(this.time1); 
          console.log(this.followersList[0]['extra']['customer'].id); 
        
      }
  }, err => {
      // this.service.dismissLoading();
      console.log(err);
  })
}
getEvents() {
  // this.service.presentLoadingDefault('Loading...');
  this.service.get('events/list?follco_token=' + localStorage.getItem('new_token'),0).subscribe(res =>{
      console.log(res);
      if(res) {
          // this.service.dismissLoading();
          this.eventsList = res['list'];
          // this.time = new Date (this.campaignList[0].created_at);
          // this.time1 =this.time.getDate() + '/' + (this.time.getMonth()+1) + '/' + this.time.getFullYear();
          // console.log(this.time1); 
          // console.log(this.followersList[0]['extra']['customer'].id); 
        
      }
  }, err => {
      // this.service.dismissLoading();
      console.log(err);
  })
}
  onChange(event){
    console.log(event);
  }
  leadId(ID){
    console.log(ID);
    localStorage.setItem('customer_id',ID);
    // this.navCtrl.push();
    this.app.getRootNav().push(CustomerLeadsSingleViewPage);

  
  }
  productitle(id){
    localStorage.setItem('product_id',id);
    // this.navCtrl.push();
    this.app.getRootNav().push(CrmProductsviewPage);

  }
  invoicestitle(id){
    localStorage.setItem('invoicesID',id);
    this.app.getRootNav().push(CrmInvoicesViewPage);
    // this.navCtrl.push();
  }
  follwerstitle(data){
    // console.log(id)
    // // localStorage.setItem('invoicesID',id);
    // this.app.getRootNav().push(CrmfollowersViewPage);
    console.log(data);
    console.log(data['extra']['customer'].id); 
    if(data['extra']['customer'].id){
      localStorage.setItem('customer_id',data['extra']['customer'].id);
      // this.navCtrl.push(EditleadscustomerPage);
      this.app.getRootNav().push(EditleadscustomerPage);
    }
  }
  eventstitle(id)
  {
     localStorage.setItem('event_id',id);
    this.app.getRootNav().push(CrMediteventPage);
  }
  hide() {
    this.hideMe = !this.hideMe;
  }
  hideProduct(){
    this.hideMe2 = !this.hideMe2;
  }
  hideFollwers(){
    this.hideMe5 = !this.hideMe5;
  }
  hideevents(){
    this.hideMe6 =!this.hideMe6;
  }
  hideLeads(){
    this.hideMe4 = !this.hideMe4
  }
  hideCustomer(){
    this.hideme3 = !this.hideme3
  }
  viewfollwers(){
  this.app.getRootNav().push(CrmFollowersPage);
  }
  viewevents(){
    this.app.getRootNav().push(CrmEventsViewPage);
  }
  viewProducts(){
    this.app.getRootNav().push(CrmProductsPage);
  }
  setting(){
    this.app.getRootNav().push(SettingprivacyPage);
  }

  ViewInvoices(){
    this.app.getRootNav().push(CrmInvoicesPage);
  }
  ViewCustomer(){
    this.app.getRootNav().push(CrmCutomersPage);

  }
  ViewLeads(){
    this.app.getRootNav().push(LeadPage);

  }
  createLeads(data){
    console.log(data)
    this.service.leadType = data;
    this.app.getRootNav().push(CreateleadsPage);

  }
  createevents(){
    this.app.getRootNav().push(CrMcreateeventPage);
  }
}
