import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-traddetail',
    templateUrl: './traddetail.component.html',
    styleUrls: ['./traddetail.component.css']
})
export class TraddetailComponent implements OnInit {

    constructor() { }

    ngOnInit() {
        window.scrollTo(0, 0);
    }

}
