import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-requestotcquote',
    templateUrl: './requestotcquote.component.html',
    styleUrls: ['./requestotcquote.component.css']
})
export class RequestotcquoteComponent implements OnInit {

    constructor() { }

    ngOnInit() {
        window.scrollTo(0,0);
    }

}
