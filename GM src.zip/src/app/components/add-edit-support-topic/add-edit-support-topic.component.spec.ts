import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditSupportTopicComponent } from './add-edit-support-topic.component';

describe('AddEditSupportTopicComponent', () => {
  let component: AddEditSupportTopicComponent;
  let fixture: ComponentFixture<AddEditSupportTopicComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddEditSupportTopicComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddEditSupportTopicComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
