import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ServiceService } from 'src/app/service/service.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { Router } from '@angular/router';
import { AppComponent } from 'src/app/app.component';
declare var $: any;

@Component({
  selector: 'app-minimum-trading-fee',
  templateUrl: './minimum-trading-fee.component.html',
  styleUrls: ['./minimum-trading-fee.component.css']
})
export class MinimumTradingFeeComponent implements OnInit {
  minTradingFee: FormGroup;
  response: any = { 'message': '' };
  subscription: any;

  constructor(
    private service: ServiceService,
    private spinner: NgxSpinnerService,
    private route: Router, private appC: AppComponent) {
    this.minTradingFee = new FormGroup({
      takerFee: new FormControl(null, [Validators.required, Validators.pattern(/^^\d+(\.\d{1,8})*$/)]),
      makerFee: new FormControl(null, [Validators.required, Validators.pattern(/^^\d+(\.\d{1,8})*$/)]),
    });
    this.subscription = this.service.authVerify.subscribe(val => {
      if (val === 'min-fee') {
        this.minimumTradingFee();
        this.service.authVerify.next('false');
      }
    });
  }
  ngOnInit() {
    window.scrollTo(0, 0);
    this.getMinTrading();
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  getMinTrading() {
    this.spinner.show();
    this.service.getMethod('fee/fetch-taker-maker', 1).subscribe((response: any) => {
      this.spinner.hide();
      if (response.status === 200) {
        if (response.data.length) {
          this.minTradingFee.patchValue({
            takerFee: response.data[0].minTakerfee,
            makerFee: response.data[0].minMakerFee,
          });
        } else {
          this.minTradingFee.patchValue({
            takerFee: response.data.minTakerfee,
            makerFee: response.data.minMakerFee,
          });
        }
      }
    }, (error) => {
      this.spinner.hide();
    });
    this.spinner.hide();
  }


  minimumTradingFee() {
    this.spinner.show();
    this.service.postMethod('fee/set-minimum-and-standard-taker-maker?feeEnum=MINIMUM&makerFee=' + this.minTradingFee.value.makerFee + '&takerFee=' + this.minTradingFee.value.takerFee, {}, 1).subscribe((response: any) => {
      this.spinner.hide();
      if (response.status === 200) {
        this.route.navigate(['/minimum-trading']);
      } else {
        this.response = response;
      }
    }, (error) => {
      this.spinner.hide();
    });
  }

  open2FAmodal() {
    this.appC.google = { one: '', two: '', three: '', four: '', five: '', six: '' };
    this.appC.response = { message: '' };
    this.service.googleAuthCalledFrom = 'min-fee';
    $('#google-auth-modal').modal({ keyboard: false, backdrop: 'static' });
  }
}
