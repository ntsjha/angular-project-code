import { Component, OnInit } from '@angular/core';
import { IMyDpOptions, IMyDateModel } from 'mydatepicker';
import { ServiceService } from 'src/app/service/service.service';

@Component({
    selector: 'app-report-deposit',
    templateUrl: './report-deposit.component.html',
    styleUrls: ['./report-deposit.component.css']
})
export class ReportDepositComponent implements OnInit {
    obj: any = {
        toDate: '',
        fromDate: '',
    };
    pageSize: any = 10;
    transacArr: any = [];
    // public fromPickerOptions: IMyDpOptions = {
    //     // dateFormat: 'dd.mm.yyyy',
    //     dateFormat: 'dd/mm/yyyy',
    // };
    // public toPickerOptions: IMyDpOptions = {
    //     // dateFormat: 'dd.mm.yyyy',
    //     dateFormat: 'dd/mm/yyyy',
    // };
    public fromPickerOptions: IMyDpOptions = {
        disableSince: { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() + 1 },
        dateFormat: 'dd/mm/yyyy',
    };
    public toPickerOptions: IMyDpOptions = {
        disableSince: { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() + 1 },
        dateFormat: 'dd/mm/yyyy',
    };
    page: any = 1;
    total = 0;
    coinArr: any = [];
    selectedCoin = '' ;
    constructor(public server: ServiceService) { }

    ngOnInit() {
        window.scrollTo(0, 0);
        this.getFiatDeposit();
        this.getCurrencyList();
    }

    onFromDateChanged(event: IMyDateModel) {
        const copy1 = this.getCopyOfOptions1();
        copy1.disableUntil = event.date;
        this.toPickerOptions = copy1;
    }

    getCopyOfOptions1(): IMyDpOptions {
        return JSON.parse(JSON.stringify(this.toPickerOptions));
    }

    getCopyOfOptions2(): IMyDpOptions {
        return JSON.parse(JSON.stringify(this.fromPickerOptions));
    }

    onToDateChanged(event: IMyDateModel) {
        const copy1 = this.getCopyOfOptions2();
        copy1.disableSince = event.date;
        this.fromPickerOptions = copy1;
    }

    getFiatDeposit() {
        let url;
        const data: any = {};
        url = 'wallet/common-permit/history/get-transfer-history';
        data.txnType = 'USER_DEPOSIT';
        if (this.obj.fromDate && this.obj.toDate) {
            data.fromDate = this.obj.fromDate.epoc;
            data.toDate = this.obj.toDate.epoc;
        }
        data.page = this.page - 1;
        data.pageSize = 10;
        if (this.selectCoin) {
            data.coinName = this.selectedCoin;
        }
        const data1 = {
            txnType: 'USER_DEPOSIT',
            page: this.page - 1,
            pageSize: 10,
            fromDate: ((this.obj.fromDate !== '') ? this.obj.fromDate.epoc : null),
            toDate: ((this.obj.toDate !== '') ? this.obj.toDate.epoc : null),
            coinName: ((this.selectedCoin != '') ? this.selectedCoin : null)
        }
        console.log('Data sending in report deposite ', data, data1);
        this.server.postMethod(url, data1, 1).subscribe((res) => {
            this.transacArr = res.data.resultlist;
            this.total = res.totalCount;
        });
    }
    managePagination(page) {
        this.page = page;
        this.total = 0;
        this.getFiatDeposit();
    }

    applyFilter() {
        this.transacArr = [];
        this.page = 1;
        this.total = 0;
        // this.selectedCoin = '';
        // if (this.obj.fromDate && this.obj.toDate) {
            this.getFiatDeposit();
        // }
    }

    clearFilter() {
        this.transacArr = [];
        this.page = 1;
        this.total = 0;
        this.obj.fromDate = null;
        this.obj.toDate = null;
        this.selectedCoin = '';
        this.getFiatDeposit();
        this.fromPickerOptions = {
            // disableSince: { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() + 1 },
            disableUntil: { year: 0, month: 0, day: 0}
        };
        this.toPickerOptions = {
            disableSince: { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() + 1 },
            // disableUntil: { year: 0, month: 0, day: 0}
        };
    }

    exportList() {
        let obj = {};
        const data = [];
        this.transacArr.forEach((element, index) => {
            obj = {
                cust_id: '',
                name: '',
                date: '',
                currency: '',
                amount: '',
                status: '',
            };
        });
        data.push(obj);
        this.server.exportAsExcelFile(data, 'Report Deposit');
    }

    getCurrencyList() {
        this.server.getMethod('wallet/currency/get-currency-list', 1).subscribe((res: any) => {
            if (res.data) {
                const data = JSON.parse(this.server.decrypt(res.data));
                this.coinArr = data.data;
            }
        });
    }

    selectCoin(coin) {
        this.selectedCoin = coin;
    }
}
