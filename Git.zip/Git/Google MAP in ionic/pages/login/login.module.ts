import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { LoginPage } from './login';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

import { SignupPage } from '../signup/signup';
@NgModule({
  declarations: [
    LoginPage,
    SignupPage
  
  ],
  imports: [
    IonicPageModule.forChild(LoginPage),ReactiveFormsModule,FormsModule
    
  ],
})
export class LoginPageModule {}
