import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { ServiceServicesProvider } from '../../providers/service-services/service-services';
import { TabsPage } from '../tabs/tabs';

@IonicPage()
@Component({
  selector: 'page-vendors-list',
  templateUrl: 'vendors-list.html',
})
export class VendorsListPage {

  vendors: any = [];
  selectedVendor: any;
  constructor(public navCtrl: NavController, public navParams: NavParams, private server: ServiceServicesProvider) {
  }

  ionViewWillEnter() {
    this.getVendors();
  }

  back() {
    this.navCtrl.pop();
  }

  getVendors() {
    if (navigator.onLine) {
      this.server.presentLoading();
      let data = {
        userId: localStorage.getItem('userId')
      }
      this.server.postApi(data, 'user/getVendors', 0).subscribe((res: any) => {
        this.server.dismissLoading();
        if (res.response_code == 200) {
          this.vendors = res.vendorDetails;
        }
        else if (res.response_code == 403 || res.response_code == 409 || res.response_code == 401) {
          this.server.presentToast(res.response_message)
          this.server.logout();
        }
        else
          this.server.presentToast(res.response_message)
      }, err => {
        this.server.dismissLoading();
        this.server.presentToast('Something went wrong')
      })
    } else
      this.server.presentToast('Your internet connection seems to be lost')
  }

  next() {
    if (navigator.onLine) {
      if(this.navParams.get('process') == 'ADD')
        this.requestAddMoney();
      else if(this.navParams.get('process') == 'WITHDRAW')
        this.requestWithdrawMoney();
      else if(this.navParams.get('process') == 'SEND')
        this.requestSendMoney();
    } else
      this.server.presentToast('Your internet connection seems to be lost')
  }

  requestSendMoney(): any {
    if(navigator.onLine) {
      this.server.presentLoading();
      let data = {
        userId: localStorage.getItem('userId'),
        vendorId: this.selectedVendor._id,
        amount: Number(JSON.parse(localStorage.sendMoneyProcess).amount),
        recieverNumber: 'ph-deepika@mobiloitte.com' //JSON.parse(localStorage.sendMoneyProcess).phoneNumber
      }
      this.server.postApi(data, 'user/sendMoneyRequest', 0).subscribe((res: any) => {
        this.server.dismissLoading();
        if (res.response_code == 200) {
          this.server.presentToast(res.response_message)
          this.navCtrl.setRoot(TabsPage, { selectedTab: 2 })
        }
        else if (res.response_code == 403 || res.response_code == 409 || res.response_code == 401) {
          this.server.presentToast(res.response_message)
          this.server.logout();
        }
        else
          this.server.presentToast(res.response_message)
      }, err => {
        this.server.dismissLoading();
        this.server.presentToast('Something went wrong')
      })
    }
    else
      this.server.presentToast('Your internet connection seems to be lost')
  }

  requestWithdrawMoney(): any {
    if(navigator.onLine) {
      this.server.presentLoading();
      let data = {
        userId: localStorage.getItem('userId'),
        vendorId: this.selectedVendor._id,
        amount: Number(JSON.parse(localStorage.addMoneyProcess).amount)
      }
      this.server.postApi(data, 'user/withdrawMoneyRequest', 0).subscribe((res: any) => {
        this.server.dismissLoading();
        if (res.response_code == 200) {
          this.server.presentToast(res.response_message)
          this.navCtrl.setRoot(TabsPage, { selectedTab: 2 })
        }
        else if (res.response_code == 403 || res.response_code == 409 || res.response_code == 401) {
          this.server.presentToast(res.response_message)
          this.server.logout();
        }
        else
          this.server.presentToast(res.response_message)
      }, err => {
        this.server.dismissLoading();
        this.server.presentToast('Something went wrong')
      })
    }
    else
      this.server.presentToast('Your internet connection seems to be lost')
  }
  
  requestAddMoney(): any {
    if(navigator.onLine) {
      this.server.presentLoading();
      let data = {
        userId: localStorage.getItem('userId'),
        vendorId: this.selectedVendor._id,
        amount: Number(JSON.parse(localStorage.addMoneyProcess).amount)
      }
      this.server.postApi(data, 'user/addMoneyRequest', 0).subscribe((res: any) => {
        this.server.dismissLoading();
        if (res.response_code == 200) {
          this.server.presentToast(res.response_message)
          this.navCtrl.setRoot(TabsPage, { selectedTab: 2 })
        }
        else if (res.response_code == 403 || res.response_code == 409 || res.response_code == 401) {
          this.server.presentToast(res.response_message)
          this.server.logout();
        }
        else
          this.server.presentToast(res.response_message)
      }, err => {
        this.server.dismissLoading();
        this.server.presentToast('Something went wrong')
      })
    }
    else
      this.server.presentToast('Your internet connection seems to be lost')
  }

}
