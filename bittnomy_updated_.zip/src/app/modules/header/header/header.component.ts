import { Component, OnInit, Renderer2 } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ServerService } from '../../../service/server.service';
import { AppComponent } from '../../../app.component';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { Observable, Subject } from 'rxjs';

declare var $: any ;

@Component({
    selector: 'app-header',
    templateUrl: './header.component.html',
    styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
    flag: boolean ;
    private subject = new Subject<any>();
    name: any;
    userImage: string = 'assets/images/profile-img.jpg';
    marqueData: any = [];
    
    constructor(private router: Router, private activatedRoute: ActivatedRoute, private server: ServerService, private appC: AppComponent, private spinnerService: Ng4LoadingSpinnerService, public myService: ServerService, private renderer: Renderer2) {
        this.appC.fireToChild().subscribe(message => {
            message.text == "sessionExpire" ? this.checkLogin() : "";
        });
    }

    ngOnInit() {
        window.scrollTo(0, 0);
        this.dropdownClicked();
        this.checkLogin();
        this.getprofile();
        this.getUserAgreement();
    }

    /** Function for call event in child component */
    fireToChild(): Observable<any> {
        return this.subject.asObservable();
    }

    goToPage(val) {
        switch(val) {
            case 1:
                this.router.navigateByUrl('header/login');
                break;
            case 2:
                this.router.navigateByUrl('header/signup');
                break;
            case 3:
                this.appC.showInfoToast("Work in progress...");
                break;
            case 4:
                this.router.navigateByUrl('');
                break;
            case 5:
                this.router.navigateByUrl('header/profile');
                break;
            case 6:
                this.router.navigateByUrl('header/faq');
                break;
            case 7:
                this.router.navigateByUrl('header/aboutUs');
                break;
            case 8:
                this.router.navigateByUrl('header/privacyPolicy');
                break;
            case 9:
                this.router.navigateByUrl('header/termsConditions');
                break;
            case 10:
                this.router.navigateByUrl('header/wallet');
                break;
            case 11:
                this.router.navigateByUrl('header/contactUs');
                break;
            case 12:
                this.router.navigateByUrl('header/exchange-pair');
                break;
            case 13:
                this.router.navigateByUrl('header/order');
                break;
            case 14:
                this.router.navigateByUrl('header/tradeList');
                break;
            case 15:
                this.router.navigateByUrl('header/dashboard');
                break;
        }
    }

    getprofile() {
        if(localStorage.getItem('token')) {
            this.server.getApi("account/my-account",localStorage.getItem('token')).subscribe((succ) => {
                this.name = succ.body.data.firstName+' '+succ.body.data.lastName ;  
                localStorage.setItem('userId', succ.body.data.userId);
                if(succ.body.data.imageUrl==null || succ.body.data.imageUrl=='' || succ.body.data.imageUrl=='image.jpg')
                    this.userImage = 'assets/images/profile-img.jpg';
                else
                    this.userImage = succ.body.data.imageUrl;
            }, (err) => {
            });
        }
    }
    
    /**For header management */
    checkLogin() {
        if(localStorage.getItem('token'))
            this.flag = true;
        else
            this.flag = false;
    }

    /**Function for token expire */
    tokenExpire() {
        this.appC.showErrToast('Session Expired');
        localStorage.clear();
        this.checkLogin();
        this.router.navigate(['header']);        
    }

    logOut() {
        localStorage.clear();
        this.flag=false;
        $('#logoutModal').modal('hide');
        // this.router.navigate(['header']);
        this.router.navigateByUrl('header/login');
    }

    dropdownClicked() {
        $('.drop-downbox').click(function() {
            $(this).children(".head-drop-down").toggleClass("show");
        });
        $('.dropdown-item').click(function() {
            $(".head-drop-down").removeClass("show");
            
        });
    }

    openThemeOpt() {
        if($('body').hasClass('nightmode')) {
            this.renderer.removeClass(document.body, 'nightmode');
        } else {
            this.renderer.addClass(document.body, 'nightmode');
        }
        this.subject.next({ text: "modeChange" });
    }

    getUserAgreement() {
        this.marqueData = [];
        this.server.getApi('static/static-content/NoticeBoard',localStorage.getItem('token')).subscribe((succ) => {
            this.marqueData = succ.data.pageData;
        },err =>{
        });
    }
}
