import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NewipdetectComponent } from './newipdetect.component';

describe('NewipdetectComponent', () => {
  let component: NewipdetectComponent;
  let fixture: ComponentFixture<NewipdetectComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NewipdetectComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NewipdetectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
