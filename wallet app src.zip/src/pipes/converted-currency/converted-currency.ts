import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'convertedCurrency',
})
export class ConvertedCurrencyPipe implements PipeTransform {
  /**
   * Takes a value and makes it lowercase.
   */
  transform(value: any, ...args) {
    value = Number(value)
    return (value).toFixed(2);
  }
}
