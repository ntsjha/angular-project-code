import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AngularFirestore } from '@angular/fire/firestore';
import { ServiceService } from 'src/app/Shared/service.service';

import { FormGroup, Validators, FormControl } from '@angular/forms';
import { formatDate } from '@angular/common';
@Component({
  selector: 'app-add-faqs',
  templateUrl: './add-faqs.component.html',
  styleUrls: ['./add-faqs.component.css']
})
export class AddFAQsComponent implements OnInit {
  docname: any;
  contentname: any;
  addFaqform: any;

  constructor(public router: Router,private afb: AngularFirestore,private firebaseServ : ServiceService,public route: ActivatedRoute) { }

  ngOnInit() {
    this.route.queryParams.subscribe((res) => {
      console.log('params--->>> ', res);

      this.contentname = res.value
      this.docname=res.docname
    })
    this.checkInput()

  }

  checkInput(){
    this.addFaqform = new FormGroup({
      question: new FormControl('', [ Validators.required,Validators.pattern(/^[^-\s][a-zA-Z0-9_:',$/%;.&*?\s-]*$/),Validators.maxLength(150)]),
      answer: new FormControl('', [ Validators.required,  Validators.pattern(/^[^-\s][a-z\d\-$=%()!#%/^;:_?@.'",*&?\s]*$/i),Validators.maxLength(350)]),
     
  })
  }


  addfaq(){
    var time = formatDate(new Date(), 'yyyy/MM/dd h:mm:ss', 'en');
    console.log('data==>',time, this.addFaqform.value)

    let data = {
      Question:this.addFaqform.value.question,
      Answer:this.addFaqform.value.answer,
      Lastupdate:time
     }

    this.afb.collection('StaticContent').doc('FAQ').collection('FAQ').add(data);
   this.firebaseServ.showSuccess('FAQ has been added successfully.');
  //  this.globalSer.hideSpinner();
   this.addFaqform.reset();
      this.router.navigate(['/static-content/view-static-content/id'],{
        queryParams:{value:this.contentname,docname:this.docname}})
  }





  viewFaq(){
    this.router.navigate(['/static-content/view-static-content/id'],{
      queryParams:{value:this.contentname,docname:this.docname}})
    
  }
  preventSpace(event){
    if(event.charCode==32 && !event.target.value){
    event.preventDefault()
    } else{
    console.log(event)
    }
    console.log('event',event.charCode)
    }
}
