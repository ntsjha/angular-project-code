import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ModalController } from 'ionic-angular';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ServiceServicesProvider } from '../../providers/service-services/service-services';
import { ActionSheet, ActionSheetOptions } from '@ionic-native/action-sheet';
import { Camera, CameraOptions } from '@ionic-native/camera';



@IonicPage()
@Component({
  selector: 'page-account',
  templateUrl: 'account.html',
})
export class AccountPage {

  imgSrc: any = '';
  form: FormGroup
  countryCode: any;
  result: any;
  constructor(public navCtrl: NavController, public actionSheet: ActionSheet, public camera: Camera, public navParams: NavParams, private server: ServiceServicesProvider, public modalCtrl: ModalController) {
  }

  ionViewWillEnter() {
    this.getUserDetail();
    // this.countryListApi();
  }

  getUserDetail() {
    if (navigator.onLine) {
      let userId = localStorage.getItem('userId');
      this.server.presentLoading();
      this.server.getApi('user/userDetail/' + userId, 1).subscribe((response: any) => {
        this.server.dismissLoading();
        if (response.response_code == 200) {
          this.result = response.result.userDetails;
          this.form.patchValue({
            firstName: this.result.firstName,
            middleName: this.result.middleName,
            lastName: this.result.lastName,
            email: this.result.email,
            mobileNo: this.result.mobileNumber
          })
          this.imgSrc = response.result.profilePic
        } else if (response.response_code == 403 || response.response_code == 409 || response.response_code == 401) {
          this.server.presentToast(response.response_message)
          this.server.logout();
        }
        else {
          this.server.presentToast(response.response_message)
        }

      }, err => {
        this.server.dismissLoading();
        this.server.presentToast('Something went wrong')
      })
    } else
      this.server.presentToast('Your internet connection seems to be lost')
  }

  ngOnInit() {
    this.form = new FormGroup({
      firstName: new FormControl('', [Validators.pattern(/^[a-zA-Z]*$/i), Validators.required]),
      middleName: new FormControl('', [Validators.pattern(/^[a-zA-Z]*$/i)]),
      lastName: new FormControl('', [Validators.pattern(/^[a-zA-Z]*$/i)]),
      email: new FormControl('', [Validators.required, Validators.pattern(/^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/i)]),
      mobileNo: new FormControl(''),
    })
  }

  //------------------------------ Country JSON ------------------------------//
  // countryListApi() {
  //   this.server.getJson().subscribe(response => {
  //     this.countryListJson = response['countries']
  //   }, error => {
  //     this.server.presentToast('Could not fetch list of countries. Please try again later')
  //   })
  // }
  //------------------------------ End Country JSON ------------------------------//

  get firstName(): any {
    return this.form.get('firstName')
  }

  get middleName(): any {
    return this.form.get('middleName')
  }

  get lastName(): any {
    return this.form.get('lastName')
  }

  get email(): any {
    return this.form.get('email')
  }

  get mobileNo(): any {
    return this.form.get('mobileNo')
  }

  back() {
    this.navCtrl.pop()
  }

  key(event) {
    this.countryCode = event.target.value;
  }

  uploadPhoto() {
    let buttonLabels = ['Take a Picture', 'From Gallery'];
    const options: ActionSheetOptions = {
      title: 'CHOOSE PICTURE',
      buttonLabels: buttonLabels,
      addCancelButtonWithLabel: 'Cancel',
      destructiveButtonLast: true
    };
    this.actionSheet.show(options).then((buttonIndex: number) => {
      var index = buttonIndex;
      if (index == 1) {
        this.camerafnc();
      } else if (index == 2) {
        this.galleryfnc();
      }
    });
  }

  camerafnc() {
    const options: CameraOptions = {
      quality: 50,
      destinationType: this.camera.DestinationType.DATA_URL,
      encodingType: this.camera.EncodingType.JPEG,
      mediaType: this.camera.MediaType.PICTURE,
      allowEdit: true
    }
    this.camera.getPicture(options).then((imageData) => {
      // imageData is either a base64 encoded string or a file URI
      // If it's base64:
      let base64Image = 'data:image/jpeg;base64,' + imageData;
      this.imgSrc = "";
      this.imgSrc = base64Image;
    }, (err) => {
      // Handle error
    });
  }

  galleryfnc() {
    const options: CameraOptions = {
      quality: 50,
      destinationType: this.camera.DestinationType.DATA_URL,
      encodingType: this.camera.EncodingType.JPEG,
      sourceType: this.camera.PictureSourceType.PHOTOLIBRARY,
      mediaType: this.camera.MediaType.PICTURE,
      allowEdit: true
    }
    this.camera.getPicture(options).then((imageData) => {
      // imageData is either a base64 encoded string or a file URI
      // If it's base64:
      let base64Image = 'data:image/jpeg;base64,' + imageData;
      this.imgSrc = "";
      this.imgSrc = base64Image;
    }, (err) => {
      // Handle error
    });
  }

  submit() {
    this.server.presentLoading()
    let data = {
      "email": this.form.value.email,
      "mobileNumber": this.form.value.mobileNo,
      "firstName": this.form.value.firstName,
      "lastName": this.form.value.lastName,
      "middleName": this.form.value.middleName,
      "image": this.imgSrc,
      "userId": localStorage.getItem('userId')
    }
    this.server.postApi(data, 'user/updateProfile', 1).subscribe((response: any) => {
      this.server.dismissLoading();
      if (response.response_code == 200) {
        this.imgSrc = response.result.profilePic
        this.server.presentToast(response.response_message)
      }
      else if (response.response_code == 201) {
        this.imgSrc = response.result.profilePic;
        this.server.presentToast(response.response_message);
        this.server.phoneNumber = this.form.value.mobileNo;
        let modalPage = this.modalCtrl.create('ModalPage');
        modalPage.present();
        modalPage.onDidDismiss((data) => {
          if (data != 'failure')
            this.server.presentToast('Your account details has been updated sucessfully.');
        });
      } else if (response.response_code == 403 || response.response_code == 409 || response.response_code == 401) {
        this.server.presentToast(response.response_message)
        this.server.logout();
      }
      else {
        this.server.presentToast(response.response_message)
      }
    }, err => {
      this.server.dismissLoading();
      this.server.presentToast('Something went wrong')
    })
  }

}
