import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { ServerService } from '../../../server.service';
import { AppComponent } from '../../../app.component';

declare var $ : any;

@Component({
    selector: 'app-wallet',
    templateUrl: './wallet.component.html',
    styleUrls: ['./wallet.component.css']
})
export class WalletComponent implements OnInit {

    coinList: any = [];
    withdrawObj = {amount: "", address: "", tagID: "", fee: ""}
    coinFullName: any;
    coinFee: any;
    myAngularxQrCode: any = null;
    tagID: any;
    coinShortName: any;
    regexForEightChar = (/^(\d+)?([.]?\d{0,8})?$/);
    numRegxForDot = (/(?: |^)\d*\.?\d+(?: |$)/);
    regexForBtc = (/^[123][a-km-zA-HJ-NP-Z1-9]{25,34}$/);
    regexForLtc = (/^[LM3][a-km-zA-HJ-NP-Z1-9]{26,33}$/);
    regexForEth = (/^0x[a-fA-F0-9]{40}$/);
    i : any = 0;
    coinBal = [];
    withdrawalAmount: any;
    qrCode = { Code1: "" };
    otp = { one: "", two: "", three: "", four: "" };

    constructor(private router: Router, private server: ServerService, private spinnerService: Ng4LoadingSpinnerService, private appC: AppComponent) { }

    ngOnInit() {
        window.scrollTo(0,0);
        this.getCoinList();
    }

    depositHistory() {
        this.router.navigateByUrl('deposithistory') ;
    }

    withdrawHistory() {
        this.router.navigateByUrl('withdrawhistory') ;
    }

    /**Function to get coin list */
    getCoinList() {
        this.coinList = [];
        this.i = 0;
        this.spinnerService.show();
        this.server.getApi("wallet/coin/get-coin-list").subscribe((succ) => {
            succ.data.forEach(element => {
                this.coinList.push({
                    "coinId": element.coinId,
                    "coinFee":element.coinFee,
                    "coinFullName":element.coinFullName,
                    "coinImage": element.coinImage,
                    "coinMarketPrice": element.coinMarketPrice,
                    "coinShortName": element.coinShortName,
                    "coinType": element.coinType,
                    "withdrawlFee": element.withdrawlFee,
                    "walletBalance": '',
                    "blockedBalance": '',
                    "totalBalance":'',
                });
                this.getCoinBalance(this.i,element.coinShortName);
                this.i++;
            });
        }, (err) => {
            this.spinnerService.hide();
        }); 
    }

    depositFunc(data) {
        this.coinFullName = data.coinFullName;
        if(data.coinFullName == 'Ripple') {
                this.spinnerService.show();
            this.server.getApi('wallet/wallet-type2/get-address?coinName='+data.coinShortName).subscribe(response => {
                this.spinnerService.hide();
                if (response.status == 200) {
                    this.myAngularxQrCode = response.data.walletAddress;
                    this.tagID = response.data.tag;
                    $('#wallet-address').modal({backdrop : 'static', keyboard: false}) ;
                } else if(response.status == 205){
                    this.appC.showErrToast('Failed to fetch address.');                    
                } else {
                    this.appC.showErrToast(response.message);                    
                }
            }, error => {
                this.spinnerService.hide();
                if(error.error.error)
                    this.appC.showErrToast(error.error.error);
                else
                    this.appC.showErrToast('Failed to fetch address.');
                        
            });   
        } else {
                this.spinnerService.show();
            this.server.getApi('wallet/wallet/get-address?coinName='+data.coinShortName).subscribe(response => {
                this.spinnerService.hide();
                if (response.status == 200) {
                    this.myAngularxQrCode = response.data.walletAddress;
                    this.tagID = response.data.tag;
                    $('#wallet-address').modal({backdrop : 'static', keyboard: false}) ;
                } else if(response.status == 205){
                    this.appC.showErrToast('Failed to fetch address.');                    
                } else {
                    this.appC.showErrToast(response.message);                    
                }
            }, error => {
                this.spinnerService.hide();
                if(error.error.error)
                    this.appC.showErrToast(error.error.error);
                else
                    this.appC.showErrToast('Failed to fetch address.');
                        
            });   
        }
    }

    withdrawFunc(data) {
        this.coinFullName = data.coinFullName;
        this.coinShortName = data.coinShortName;
        this.coinFee = data.withdrawlFee;
        this.withdrawObj = {amount: "", address: "", tagID: "", fee: ""};
        this.getWithdrawalAmount(this.coinShortName);
        

    }

    limitDigit(str) {
        if(str.indexOf('.') !== -1)
            this.withdrawObj.amount = str.split('.')[0]+'.'+ str.split('.')[1].slice(0,8);
    }

    limitNeg(event) {
        var k = event.code;
        if (k === 'Minus') return false;
    }

    /** Function for withdraw */
    withdrawalFunc() {  
        if(this.withdrawObj.address == "") {
            this.appC.showErrToast("Enter address");
            return;
           
        } 
        // else if(this.coinFullName == 'Bitcoin') {
        //     if(!this.regexForBtc.test(this.withdrawObj.address))
        //         this.appC.showErrToast("Enter valid address ");
        //         console.log('12')
        //         return;
        // } else if(this.coinFullName == 'Litecoin') {
        //     if(!this.regexForLtc.test(this.withdrawObj.address))
        //         this.appC.showErrToast("Enter valid address ");
        //         console.log('13')
        //         return;
        // } else if(this.coinFullName == 'Ethereum') {
        //     if(!this.regexForEth.test(this.withdrawObj.address))
        //         this.appC.showErrToast("Enter valid address ");
        //         console.log('14')
        //         return;
        // } 
        else if(this.withdrawObj.amount == "") {
            this.appC.showErrToast("Enter amount value");
            return;
        } else if(!this.numRegxForDot.test(this.withdrawObj.amount)) {
            this.appC.showErrToast("Enter valid amount value");
            return;
        } else if(this.withdrawalAmount < this.withdrawObj.amount) {
            this.appC.showErrToast("Please enter amount less than your withdrawal limit.");
            return;
        } else if(this.coinFullName=='Ripple' || this.coinFullName=='Stellar') {
            if(this.withdrawObj.tagID == "") {
                this.appC.showErrToast("Enter Tag ID.");
                return;
            } 
        } 
        else {
            this.getUserDetail();
        }  
    }

    submitWithdraw() {
        let data = {
            "amount": this.withdrawObj.amount,
            "coinName": this.coinShortName,
            "tag": this.withdrawObj.tagID,
            "toAddress": this.withdrawObj.address
        }
        this.spinnerService.show();
        this.server.postApi('wallet/wallet/withdraw',data).subscribe(res => {
            this.spinnerService.hide();
            if (res.status == 200) {
                this.appC.showInfoToast(res.message);
                $("#withdrawalModal").modal('hide');
            } else if(res.status == 205){
                this.withdrawObj = {amount: "", address: "", tagID: "", fee: ""};
                this.appC.showErrToast('Insufficient balance.');                    
            } else  {
                this.appC.showErrToast(res.message);
                this.withdrawObj = {amount: "", address: "", tagID: "", fee: ""};
            } 
        }, error => {
            this.appC.showErrToast(error.error.message)
            this.spinnerService.hide();
        });
    }

    copyToClipboard(data : string) {
        this.appC.showInfoToast("Text has been copied to clipboard.");
        let selBox = document.createElement('textarea');
        selBox.style.position = 'fixed';
        selBox.style.left = '0';
        selBox.style.top = '0';
        selBox.style.opacity = '0';
        selBox.value = data;
        document.body.appendChild(selBox);
        selBox.focus();
        selBox.select();
        document.execCommand('copy');
        document.body.removeChild(selBox);
    }

    /**Function to get wallet balance  */
    getCoinBalance(ind,coin) {
        this.spinnerService.show();
        this.server.getApi('wallet/wallet/get-balance?coinName='+coin).subscribe( res => {
            this.coinList[ind].walletBalance = res.data.walletBalance;
            this.coinList[ind].blockedBalance = res.data.blockedBalance;
            this.coinList[ind].totalBalance = this.coinList[ind].walletBalance + this.coinList[ind].blockedBalance;
        });  
        this.spinnerService.hide();
    }

    /**Function to get withdrawal Amount of coin */
    getWithdrawalAmount(coin) {
        this.spinnerService.show();
        this.server.getApi('wallet/coin/get-coin-details?coinName='+coin).subscribe( res => {
            this.withdrawalAmount = res.data.withdrawalAmount;
            $('#withdrawalModal').modal({backdrop : 'static', keyboard: false}) ;
        });  
        this.spinnerService.hide();

    }

    /** Function to manage exponential data */
    manageExponential(num) {
        //if the number is in scientific notation remove it
        if (/\d+\.?\d*e[\+\-]*\d+/i.test(num)) {
            var zero = '0',
            parts = String(num).toLowerCase().split('e'), //split into coeff and exponent
            es = Number(parts.pop()), //store the exponential part
            l = Math.abs(es), //get the number of zeros
            sign = es / l,
            coeff_array = parts[0].split('.');
            if (sign === -1) {
                num = zero + '.' + new Array(l).join(zero) + coeff_array.join('');
            } else {
                var dec = coeff_array[1];
                if (dec) l = l - dec.length;
                num = coeff_array.join('') + new Array(l + 1).join(zero);
            }
            return num;
        } else {
            return num;
        }
    };


    /** Function to get user detail */
    getUserDetail() {
        this.server.getApi('account/my-account').subscribe((res) => {
            if (res.status == 200) {
                if(res.data.twoFaType == 'GOOGLE'){
                    $('#googleAuthModal').modal({ backdrop: 'static', keyboard: false });

                } else if(res.data.twoFaType == 'SMS'){
                    $('#faOTPModal').modal({ backdrop: 'static', keyboard: false });

                } else if(res.data.twoFaType == 'NONE') {
                    $("#withdrawalModal").modal('hide');
                    this.appC.showErrToast('Please enable 2FA to your account for withdrawal.');
                    this.router.navigateByUrl('profile');

                }
            }

        }, (err) => {
        });
    }

    /** Function to verify QR code */
    qrVerify() {
        let data = this.qrCode.Code1
        this.spinnerService.show();
        this.server.postApi('auth/verify-google', data).subscribe((res) => {
          this.spinnerService.hide();
          if (res.status == 200) {
            $('#googleAuthModal').modal('hide');
            this.submitWithdraw();
          }
          else {
            this.qrCode.Code1 = "";
            this.appC.showErrToast("Enter valid QR Code");
          }
    
        }, (err) => {
          this.qrCode.Code1 = "";
          this.spinnerService.hide();
          this.appC.showErrToast("Enter valid QR Code")
        })
    }
    
    /** Function to verify SMS code */
    verifySmsCode() {
    if(this.otp.one == "" || this.otp.two == "" || this.otp.three == "" || this.otp.four == ""){
        this.appC.showErrToast("Please Enter Code");
        return; 
    } 
    let data = {
        "code": this.otp.one+this.otp.two+this.otp.three+this.otp.four,
    }
    this.spinnerService.show();
    this.server.postApi('account/verify-sms-code', data).subscribe((res) => {
        this.spinnerService.hide();
        if (res.status == 200) {
            $('#faOTPModal').modal('hide');
            this.submitWithdraw();
        }
        else {
            this.otp = { one: "", two: "", three: "", four: "" };
            this.appC.showErrToast(res.message);
        }

    }, (err) => {
        this.otp = { one: "", two: "", three: "", four: "" };
        this.spinnerService.hide();
        this.appC.showErrToast("Something went Wrong")
    })
    }

    /**Resend OTP */
    otpResend() {
        this.spinnerService.show();
        this.server.getApi('account/send-sms-code').subscribe(succ =>{
            if(succ.status == 200) {
                this.spinnerService.hide();
                this.appC.showErrToast(succ.message);
            } else {
                this.spinnerService.hide();
                this.appC.showErrToast(succ.message);
            }
        },err =>{
            this.spinnerService.hide();
            this.appC.showErrToast(err.error.error);
        })
    }
    
    /** Auto focus functionality */
    onKey(value, type) {
    if (type == 1) {
        if (value != "") {
            $('#otp2').focus();
        }
    } else if (type == 2) {
        if (value != "") {
            $('#otp3').focus();
        }
    } else if (type == 3) {
        if (value != "") {
            $('#otp4').focus();
        }
    } else if (type == 4) {
        if (value.keyCode == 13) {
            this.verifySmsCode();
        }
    } 
    }

    

}
