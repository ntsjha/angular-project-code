import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageSettingExchangeFeeWalletComponent } from './manage-setting-exchange-fee-wallet.component';

describe('ManageSettingExchangeFeeWalletComponent', () => {
  let component: ManageSettingExchangeFeeWalletComponent;
  let fixture: ComponentFixture<ManageSettingExchangeFeeWalletComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManageSettingExchangeFeeWalletComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageSettingExchangeFeeWalletComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
