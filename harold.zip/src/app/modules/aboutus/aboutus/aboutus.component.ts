import { Component, OnInit } from '@angular/core';
import { ServerService } from '../../../server.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';

@Component({
    selector: 'app-aboutus',
    templateUrl: './aboutus.component.html',
    styleUrls: ['./aboutus.component.css']
})
export class AboutusComponent implements OnInit {
    pageData: any = [];

    constructor(private server: ServerService, private spinnerService: Ng4LoadingSpinnerService) { }

    ngOnInit() {
        window.scrollTo(0,0);
        this.getPageData();
    }

    getPageData() {
        this.spinnerService.show();
        this.server.getApi('static/static-content/AboutUs').subscribe((succ) => {
            this.spinnerService.hide();
            this.pageData = succ.data.pageData;
        },err =>{
            this.spinnerService.hide();
            this.pageData = 'No Data Found.' ;
        });
    }

}
