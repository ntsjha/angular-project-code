import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ServiceService } from 'src/app/service/service.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { ActivatedRoute, Router } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'app-standard-deposit-fiat',
  templateUrl: './standard-deposit-fiat.component.html',
  styleUrls: ['./standard-deposit-fiat.component.css']
})
export class StandardDepositFiatComponent implements OnInit {
  currentUser: any;
  coinName: any;
  depositeFiat: any;
  stdFiatDeposit: FormGroup;
  userIp: any;

  constructor(
    private service: ServiceService,
    private spinner: NgxSpinnerService,
    private activatedRoute: ActivatedRoute,
    private cookie: CookieService,
    private route: Router
    ) {
    this.stdFiatDeposit = new FormGroup({
      fixedFee: new FormControl(null, [Validators.required, Validators.maxLength(8), Validators.pattern(/^[1-9][0-9]*$/)]),
      extraFee: new FormControl(null, [Validators.required, Validators.maxLength(8), Validators.pattern(/^[1-9][0-9]*$/)]),
      forFirst: new FormControl(null, [Validators.required, Validators.maxLength(8), Validators.pattern(/^[1-9][0-9]*$/)]),
      per: new FormControl(null, [Validators.required, Validators.maxLength(8), Validators.pattern(/^[1-9][0-9]*$/)]),

    });
    this.userIp = (this.cookie.get('userInfo')) ? JSON.parse(this.cookie.get('userInfo')) : this.service.initialUserInfo;
    this.service.currentUserInfo.subscribe((response) => {
      this.currentUser = response;
    });
  }

  ngOnInit() {
    this.activatedRoute.params.subscribe(id => {
      this.coinName = id.id;
    });
    this.stdDepositFiat();
    window.scrollTo(0, 0);
  }

  stdDepositFiat() {
    this.spinner.show();
    this.service.getMethod('wallet/admin/fees/get-fee-details?currencyName=' + this.coinName + '&currencyType=fiat', 1).subscribe((response: any) => {
      this.spinner.hide();
      if (response.status === 845 || response.status === 842) {
        this.depositeFiat = response.data;
        this.loadform();
      }
    }, (error) => {
      this.spinner.hide();
    });
    this.spinner.hide();

  }

  loadform() {
    this.stdFiatDeposit.patchValue({
      fixedFee: this.depositeFiat.stdDepositFixedFee,
      extraFee: this.depositeFiat.minExtraFee,
      forFirst: this.depositeFiat.stdDepositFixedFeeForFirst,
      per: this.depositeFiat.minExtraFeePer
    });
  }


  depositFiat() {
    this.spinner.show();
    const data = {
      coinName: this.coinName,
      extraFee: this.stdFiatDeposit.value.extraFee,
      extraFeePer: this.stdFiatDeposit.value.per,
      fixedFee: this.stdFiatDeposit.value.fixedFee,
      fixedFeeForFirst: this.stdFiatDeposit.value.forFirst,
      ipAddress: this.userIp.ip,
      location: this.userIp.city + ',' + this.userIp.country_name
    };

    this.service.postMethod('wallet/admin/fees/set-std-fiat-deposit-fee', data, 1).subscribe((response: any) => {
      this.spinner.hide();
      if (response.status === 847 || response.status === 842) {
        this.route.navigate(['/minimum-deposit']);
      }
    }, (error) => {
      this.spinner.hide();
    });
  }
}
