import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, FormArray, Validators } from '@angular/forms';
import { ServiceService } from 'src/app/service/service.service';
import { ActivatedRoute, Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';

declare var $: any;

@Component({
  selector: 'app-about-us',
  templateUrl: './about-us.component.html',
  styleUrls: ['./about-us.component.css']
})
export class AboutUsComponent implements OnInit {
  aboutUs: FormGroup;
  modeOfAction: string;
  aboutArr: any;
  teamArr: any;
  partnerArr: any;
  selectedLanguage: string;
  aboutUsData: any;
  canEdit: boolean;
  canView: boolean;
  canAdd: boolean;
  currentUser: any;
  teamForm: FormGroup;
  partner: FormGroup;
  partnerForm: FormGroup;
  translation: boolean;
  languageName: string;
  aboutUsUpdated = false;
  teamUpdated = false;
  partnerUpdated = false;
  updateAboutUsDescription: string;
  teamArray: FormArray;
  partnerArray: FormArray;
  removeIndex: any;
  removeForm: any;
  image: any;
  showApiMessage = false;
  response: any;
  teamImgError = [];
  partnerImgError = [];

  constructor(private service: ServiceService, private activatedRoutes: ActivatedRoute, private fb: FormBuilder, private router: Router, private spinner: NgxSpinnerService) {
    this.aboutUs = new FormGroup({
      aboutCompany: new FormControl()
    });
    this.teamForm = this.fb.group({
      teamArray: this.fb.array([])
    });
    this.partnerForm = this.fb.group({
      partnerArray: this.fb.array([])
    });
  }

  addTeam(): void {
    this.teamArray = this.teamForm.get('teamArray') as FormArray;
    this.teamArray.push(this.createTeam(null, null, null, null, ''));
  }

  addPartner(): void {
    this.partnerArray = this.partnerForm.get('partnerArray') as FormArray;
    this.partnerArray.push(this.createPartner(null, '', null, null));
  }

  addPartnerForm(image, partnerId, title, websiteUrl): void {
    this.partnerArray = this.partnerForm.get('partnerArray') as FormArray;
    this.partnerArray.push(this.createPartner(image, partnerId, title, websiteUrl));
  }

  createPartner(image, partnerId, title, websiteUrl): FormGroup {
    return this.fb.group({
      imageUrl: new FormControl(image, [Validators.required]),
      websiteUrl : new FormControl(websiteUrl, [Validators.required, Validators.pattern(/^(http:\/\/www\.|https:\/\/www\.|http:\/\/|https:\/\/)?[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,5}(:[0-9]{1,5})?(\/.*)?$/)]),
      partnerId: new FormControl(partnerId),
      title: new FormControl(title, [Validators.required, Validators.pattern(/^[a-z ,.'-]+$/i), Validators.maxLength(100), Validators.minLength(2)])
    });
  }

  createTeam(teamName, teamDesignation, teamDescription, imageUrl, id): FormGroup {
    return this.fb.group({
      memberName: new FormControl(teamName, [Validators.required, Validators.maxLength(100), Validators.minLength(2)]),
      designation: new FormControl(teamDesignation, [Validators.required, Validators.pattern(/^[a-z ,.'-]+$/i), Validators.maxLength(100), Validators.minLength(2)]),
      details: new FormControl(teamDescription, [Validators.required, Validators.maxLength(255), Validators.minLength(2) ]),
      imageUrl: new FormControl(imageUrl, [Validators.required]),
      memberId: new FormControl(id),
    });
  }
  ngOnInit() {
    window.scrollTo(0,0);
    this.activatedRoutes.params.subscribe((data) => {
      this.modeOfAction = data.id1;
      this.languageSelection(data.id2);
    });
    this.modeSelection();
    this.service.currentUserInfo.subscribe((response) => {
      this.currentUser = response;
    });
  }      

  languageSelection(lang) {
    if (lang === 'th') {
      this.selectedLanguage = 'th';
      this.translation = true;
      this.languageName = 'Thai';
      this.getAboutUsTranslation();
    } else if (lang === 'ch') {
      this.selectedLanguage = 'ch';
      this.translation = true;
      this.languageName = 'Chinese';
      this.getAboutUsTranslation();
    } else {
      this.selectedLanguage = 'en';
      this.translation = false;
      this.languageName = 'English';
      this.getAboutUs();
    }
  }

  modeSelection() {
    if (this.modeOfAction === 'edit' || this.modeOfAction === 'add') {
      this.canEdit = true;
      this.canAdd = false;
      this.canView = false;
    } else {
      this.canEdit = false;
      this.canAdd = false;
      this.canView = true;
    }
  }

  loadImageOnView(imageUrl, id) {
    if (imageUrl) {
      this.service.getMethod('account/convert-image-base64?imageUrl=' + this.service.imageUrl + imageUrl, 1)
      .subscribe((res: any) => {
        this.spinner.hide();
      }, error => {
        this.spinner.hide();
        if (error.error.text) {
              this.image = 'data:image/jpg;base64,' + error.error.text;
              $('#' + id).attr('src', this.image);
              return this.image;
            }
      });
    }
  }

  loadEditForm() {
    this.updateAboutUsDescription = this.aboutArr.aboutUsDescription;
    const i = 0;
    this.teamArr.forEach((element, i) => {
      this.teamArray = this.teamForm.get('teamArray') as FormArray;
      this.teamArray.push(this.createTeam(element.memberName, element.designation, element.details, element.imageUrl, element.memberId));
      this.loadImageOnView(element.imageUrl, 'team' + i );
      this.teamImgError.push({
        error: false,
        errorMsg: ''
      });
    });
    this.partnerArr.forEach((element, i) => {
      this.partnerArray = this.partnerForm.get('partnerArray') as FormArray;
      this.partnerArray.push(this.createPartner(element.imageUrl, element.partnerId, element.title, element.websiteUrl));
      this.loadImageOnView(element.imageUrl, 'partner' + i );
      this.partnerImgError.push({
        error: false,
        errorMsg: '',
      });
    });
  }

  loadEditFormTranslation() {
    this.updateAboutUsDescription = this.aboutArr.aboutUsDescription;
    this.teamArr.forEach((element, i) => {
      this.teamArray = this.teamForm.get('teamArray') as FormArray;
      this.teamArray.push(this.createTeam(element.memberName, element.designation, element.details, element.imageUrl, element.translationId));
      this.loadImageOnView(element.imageUrl, 'team' + i );
      this.teamImgError.push({
        error: false,
        errorMsg: ''
      });
    });
    this.partnerArr.forEach((element, i) => {
      this.partnerArray = this.partnerForm.get('partnerArray') as FormArray;
      this.partnerArray.push(this.createPartner(element.imageUrl, element.translationId, element.title, element.websiteUrl));
      this.loadImageOnView(element.imageUrl, 'partner' + i );
      this.partnerImgError.push({
        error: false,
        errorMsg: '',
      });
    });
  }

  removeteamOrpartner() {
    $('#deleteModal').modal('hide');
    if (this.removeForm === 'team') {
      this.service.postMethod('static/admin/delete-our-team?ipAddress=' + encodeURIComponent(this.service.encrypt(this.currentUser.ip)) + '&location=' + encodeURIComponent(this.service.encrypt(this.currentUser.city)) + '&memberId=' + encodeURIComponent(this.service.encrypt(this.teamArray.at(this.removeIndex).value.memberId)), {}, 1)
      .subscribe((response) => {
        if (response.status === 1548 ) {
          this.teamArray.removeAt(this.removeIndex);
          this.teamImgError.splice(this.removeIndex, 1);
        }
      }, (error) => {
      });
    } else if (this.removeForm === 'partner') {
      this.service.postMethod('static/admin/delete-partner?ipAddress=' + encodeURIComponent(this.service.encrypt(this.currentUser.ip)) + '&location=' + encodeURIComponent(this.service.encrypt(this.currentUser.city)) + '&partnerId=' + encodeURIComponent(this.service.encrypt(this.partnerArray.at(this.removeIndex).value.partnerId)), {}, 1)
      .subscribe((response) => {
        this.partnerArray.removeAt(this.removeIndex);
        this.partnerImgError.splice(this.removeIndex, 1);
      }, (error) => {
      });
    }
  }

  getAboutUs() {
    this.spinner.show();
    this.service.postMethod('static/admin/getAllAboutUsData?languageShortName=' + encodeURIComponent(this.service.encrypt(this.selectedLanguage)), {}, 1)
      .subscribe((response) => {
        this.spinner.hide();
        this.aboutUsData = response.data[0];
        this.aboutArr = this.aboutUsData.aboutUs[0];
        this.teamArr = this.aboutUsData.team;
        this.partnerArr = this.aboutUsData.partner;
        this.loadEditForm();
      }, (error) => {
        this.spinner.hide();
      });
  }

  getAboutUsTranslation() {
    if (this.modeOfAction === 'add') {
      return;
    }
    this.spinner.show();
    this.service.postMethod('static/admin/get-aboutus-page-translation?language=' + encodeURIComponent(this.service.encrypt(this.selectedLanguage)), {}, 1)
      .subscribe((response) => {
        this.spinner.hide();
        this.aboutUsData = response.data;
        this.aboutArr = this.aboutUsData.aboutUsTranslation[0];
        this.teamArr = this.aboutUsData.ourTeamTranslation;
        this.partnerArr = this.aboutUsData.partnersTranslation;
        this.loadEditFormTranslation();
      }, (error) => {
        this.spinner.hide();
      });
  }

  openModal(id, formType) {
    this.removeIndex = id;
    this.removeForm = formType;
    $('#deleteModal').modal('show');
  }

  updateImage(updatedForm, index, event) {
    const obj = this.service.uploadImage(event);
    if (obj.valid) {
      const formData = new FormData();
      formData.append('file', obj.fileData);
      this.spinner.show();
      this.service.postMethod('account/uploadFile', formData, 2)
        .subscribe((response) => {
          if (updatedForm === 'team') {
            this.teamArray.at(index).patchValue({
              imageUrl: response.fileName
            });
            this.teamImgError[index].error = false;
            const id = 'team' + index;
            this.loadImageOnView(response.fileName, id);
          } else {
            this.partnerArray.at(index).patchValue({
              imageUrl: response.fileName
            });
            this.partnerImgError[index].error = false;
            const id = 'partner' + index;
            this.loadImageOnView(response.fileName, id);
          }

        }, (error) => {
          this.spinner.hide();
        });
    } else {
      if(updatedForm === 'team') {
        this.teamImgError[index].error = true;
        if (obj.error === 'formatError') {
          this.teamImgError[index].errorMsg = 'Image format should be in JPEG, PNG & JPG.';
        } else {
          this.teamImgError[index].errorMsg = 'Image size be should be less than 5MB';
        }
      } else {
        this.partnerImgError[index].error = true;
        if (obj.error === 'formatError') {
          this.partnerImgError[index].errorMsg = 'Image format should be in JPEG, PNG & JPG.';
        } else {
          this.partnerImgError[index].errorMsg = 'Image size be should be less than 5MB';
        }
      }
    }
  } 

  submit() {
    if (this.translation) {
      this.updatedAboutUsTranslation();
    } else {
      this.updateAboutUsEnglish();
    }
  }

  updateAboutUsEnglish() {
    const engAboutUsUpdate = {
      aboutUsDescription: this.updateAboutUsDescription,
      aboutUsId: this.aboutArr.aboutUsId,
      ipAddress: this.currentUser.ip,
      location: this.currentUser.city,
      ourTeamDto: this.teamForm.get('teamArray').value,
      partnersDto: this.partnerForm.value.partnerArray,
      title: this.aboutArr.aboutUsTitle,
      // title: this.aboutArr.aboutUsTitle,
    };
    console.log('Data Sent ', engAboutUsUpdate);
    const data = {
      kycDto: this.service.encrypt(JSON.stringify(engAboutUsUpdate))
    };
    this.service.postMethod('static/admin/addAboutUsData', data, 1)
        .subscribe((response) => {
          this.partnerUpdated = true;
          this.aboutUsUpdated = true;
          this.teamUpdated = true;
          this.changeDir(response);
        },(error) => {
          this.changeDir(error);
        });
    }

  updatedAboutUsTranslation() {
    const aboutUs = {
      description: this.service.encrypt(this.updateAboutUsDescription),
      translationId: this.service.encrypt(this.aboutUsData.aboutUsTranslation[0].aboutUsId),
      ipAddress: this.service.encrypt(this.currentUser.ip),
      location: this.service.encrypt(this.currentUser.city),
      title: this.service.encrypt('AboutUs'),
    };
    const teamTranslation = {
      ipAddress: this.service.encrypt(this.currentUser.ip),
      location: this.service.encrypt(this.currentUser.city),
      ourTeamDto: this.teamForm.value.teamArray
    };
    const partnerTranslation = {
      ipAddress: this.service.encrypt(this.currentUser.ip),
      location: this.service.encrypt(this.currentUser.city),
      partnersDto: this.partnerForm.value.partnerArray
    };

    this.service.postMethod('static/admin/updateAboutUsTranslation', aboutUs, 1)
      .subscribe((response) => {
        this.aboutUsUpdated = true;
        this.changeDir(response);
      }, (error) => {
        this.changeDir(error);
      });
    this.service.postMethod('static/admin/updateOurTeamTranslation?translationDto=' + encodeURIComponent(this.service.encrypt(JSON.stringify(teamTranslation))), {}, 1)
      .subscribe((response) => {
        this.teamUpdated = true;
        this.changeDir(response);
      }, (error) => {
        this.changeDir(error);
      });

    this.service.postMethod('static/admin/updatePartnerTranslation?translationDto=' + encodeURIComponent(this.service.encrypt(JSON.stringify(partnerTranslation))), {}, 1)
      .subscribe((response) => {
        this.partnerUpdated = true;
        this.changeDir(response);
      }, (error) => {
        this.changeDir(error);
      });

  }

  changeDir(response) {
    if ((this.teamUpdated) && (this.aboutUsUpdated) && (this.partnerUpdated)) {
      this.router.navigate(['/translation/about-us']);
      window.scrollTo(0, 0);
      this.response = response;
      this.response.status = 911;
      this.response.message = 'About us updated successfully.';
      this.showApiMessage = true;
    } else {
      window.scrollTo(0, 0);
      this.response = response;
      this.response.status = 910;
      this.showApiMessage = true;
    }
  }
}
