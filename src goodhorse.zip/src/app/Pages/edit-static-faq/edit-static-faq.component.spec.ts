import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditStaticFAQComponent } from './edit-static-faq.component';

describe('EditStaticFAQComponent', () => {
  let component: EditStaticFAQComponent;
  let fixture: ComponentFixture<EditStaticFAQComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditStaticFAQComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditStaticFAQComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
