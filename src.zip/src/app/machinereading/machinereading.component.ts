import { Component, OnInit } from '@angular/core';

import {DomSanitizer} from '@angular/platform-browser';
import {MatIconRegistry} from '@angular/material/icon';
import { MainServiceService } from '../main-service.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { Router } from '@angular/router';

import { Inject} from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { CookieService } from 'ngx-cookie-service';
import { FormGroup, Validators, FormControl, FormArray, FormBuilder } from "@angular/forms";
declare var $ : any;
export interface DialogData {
  animal: string;
  name: string;

}

export interface PeriodicElement {
  name: string;
  imageSrc: any;
  startReading: string;
  testing: string;
  endReading: string;
  fuelType: string;
}
const ELEMENT_DATA: PeriodicElement[] = [
  {imageSrc: 'assets/image/petrol.png', name: 'N1', startReading: '988988', endReading: '87282234343', testing: '5 Ltr', fuelType: 'HSD'},
  {imageSrc: 'assets/image/petrol.png', name: 'N1', startReading: '988988', endReading: '87282234343', testing: '5 Ltr', fuelType: 'HSD'},

];

@Component({
  selector: 'app-machinereading',
  templateUrl: './machinereading.component.html',
  styleUrls: ['./machinereading.component.css']
})
export class MachinereadingComponent implements OnInit {

  dashbordList: any;
  
  options: string[] = ['One', 'Two', 'Three'];
  machineData: any;
  headerdata: any;
  endReading: string;
  displayedColumns: string[] = [ 'name', 'startReading','endReading','testing','fuelType',];
 

  dataSource = ELEMENT_DATA;
  displayMode: number;
  name: any;
  animal: any;

  
  

  constructor(public dialog: MatDialog,private service:MainServiceService, sanitizer: DomSanitizer,
    iconRegistry: MatIconRegistry,  public spinner:Ng4LoadingSpinnerService,public router:Router) {
   

  
}
ngOnInit() {
  this.getmachinereadingdata();
  
}


addTankOpenModal(){
  $('#addTankModal').modal({backdrop: 'static', keyboard: false});
}

onDisplayModeChange(mode: number): void {
  this.displayMode = mode;
}
OpenmachineReading(){
  this.router.navigate(['addmachinereading']);
}

getmachinereadingdata(){

 let petrolpumpid = {
  "petrolPumpId": localStorage.getItem('petrolpump_data'),
  "pageNumber":""	
  
}
 console.log(petrolpumpid)
  this.service.post('user/getMachineReading',petrolpumpid,1).subscribe(
    res => {
      console.log(res);

      this.spinner.hide();
      if (res["responseCode"] == 200) {
        this.machineData = res["result"].success;


        // console.log('DATA===>', this.machineData)
        // this.petrolPumpData=res['result'].petrolPump;
            
        
        
    // console.log('DATA===>', this.machineData)
      }
   
 }, err=>{
   this.spinner.hide();
   console.log(err);
 })
}

// open Modal ///
openDialog(): void {
  const dialogRef = this.dialog.open(AddnewMachine, {
    height: '800px',  
    width: '700px',
  });
  dialogRef.afterClosed().subscribe(result => {
    console.log('The dialog was closed');
    this.animal = result;
  });
}

}


@Component({
  selector: 'addnew-machine',
  templateUrl: 'addnew-machine.html',
  // styleUrls: ['logout-modal.component.css']
})
export class AddnewMachine {
  addmachineForm: FormGroup;
  

  constructor(public router: Router,private spinnerService: Ng4LoadingSpinnerService,private service:MainServiceService, private cookie: CookieService,
    public dialogRef: MatDialogRef<AddnewMachine>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData, public fb: FormBuilder) {}

  // onNoClick(): void {
  //   this.dialogRef.close();
  // }
  ngOnInit() {
    this.addNewMachine();  
    
    this.addNozzle();  
  }
  
  addNozzle(){
    const nozzles = this.addmachineForm.controls.nozzles as FormArray;
    nozzles.push(this.fb.group({
      'nozzleName': new FormControl('', Validators.required),
      'fuelType': new FormControl('', Validators.required)
    }));
  }

  removeNozzle(index){
    // if(this.addMoreNozzle.value.nozzles.length > 1){
      let control = <FormArray>this.addmachineForm.controls.nozzles;
      control.removeAt(index)
    // }
  }

   addNewMachine() {
    this.addmachineForm = new FormGroup({
      machineName: new FormControl("", [Validators.required, Validators.minLength(2), Validators.maxLength(250), Validators.pattern(/^[[a-zA-Z]+[[ '-]?[a-zA-Z]+]*$/)]),
      machineModelName: new FormControl("", [Validators.required]),
      serialNumber: new FormControl("", [Validators.required, ]),
      mfgYear: new FormControl("", [Validators.required, Validators.maxLength(100),]),
      'nozzles': this.fb.array([])
      });
  }

  addmachine(){
    if (!navigator.onLine) {
      this.service.showWarning('Please check internet conectivity');
      return;
    } 
    let data = this.addmachineForm.value;
    data.petrolPumpId = localStorage.getItem('petrolpump_data');
    // console.log("API data", data);
    this.service.post('user/addMachine ', data, 1).subscribe(res => {
    this.spinnerService.hide();
    if (res.responseCode === 200) {
      this.service.showSuccess(res['responseMessage']);
      // this.router.navigate(['login']);
      console.log('res',res);
      // this.otpModal();
    } else {
      this.service.showWarning(res.responseMessage);
    }
    console.log('res ===>>>', res);
    }, err => {
      this.spinnerService.hide();
      this.service.showError('Something went wrong');
    });
    this.dialogRef.close();
  }
  

}