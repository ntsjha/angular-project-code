export class Subscriptionplan {
    id: string;
    duration:string
    maxHorses:string
    planType:string
    price:number
    // description:string
}
