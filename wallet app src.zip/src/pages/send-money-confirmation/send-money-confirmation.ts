import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, App } from 'ionic-angular';
import { ServiceServicesProvider } from '../../providers/service-services/service-services';
import { TransactionStatusPage } from '../transaction-status/transaction-status';
import { TabsPage } from '../tabs/tabs';
import { HomePage } from '../home/home';

@IonicPage()
@Component({
  selector: 'page-send-money-confirmation',
  templateUrl: 'send-money-confirmation.html',
})
export class SendMoneyConfirmationPage {
  sendMoneyDetails: any;
  transactionFee: number = 0;
  conversionFee: number = 0;
  totalPay: string;

  constructor(private app: App,public navCtrl: NavController, public navParams: NavParams, public service: ServiceServicesProvider) {
    console.log('Send Money')
  }

  ionViewWillEnter() {
    this.sendMoneyDetails = JSON.parse(localStorage.sendMoneyProcess)
    console.log('sendMoney--->>>',this.sendMoneyDetails);
    this.getTransactionFees();
  }

  getTransactionFees() {
    if (navigator.onLine) {
      this.service.getApi('transaction/conTransFee', 1).subscribe((response: any) => {
        if (response.response_code == 200) {
          this.transactionFee = response.data.transactionFee;
          if(this.sendMoneyDetails.sender.country != this.sendMoneyDetails.receiver.country)
            this.conversionFee = response.data.conversionFee;
            this.getTotalPayable()
        } else if (response.response_code == 403 || response.response_code == 409 || response.response_code == 401) {
          this.service.presentToast(response.response_message)
          this.service.logout();
        }
        else {
          this.transactionFee = 0;
          this.service.presentToast(response.response_message)
        }
      }, err => {
        this.service.presentToast('Something went wrong')
      })
    } else
      this.service.presentToast('Your internet connection seems to be lost')
  }


  getTotalPayable(){
    var convert = ((this.conversionFee/100) * Number(this.sendMoneyDetails.amount));
    var transaction = ((this.transactionFee/100) * Number(this.sendMoneyDetails.amount));
    this.totalPay = (Number(this.sendMoneyDetails.amount) + convert + transaction).toFixed(3);
    console.log('TotalPay--->>',this.totalPay)
  }

  back() {
    this.navCtrl.pop();
  }

  confirm() {
    if (navigator.onLine) {
      this.service.presentLoading();
      let data = {};
      data[`to`] = this.sendMoneyDetails.receiverId;
      data[`from`] = localStorage.getItem('userId'),
      data[`balance`] = this.sendMoneyDetails.amount
      data[`message`] = this.sendMoneyDetails.message
      data[`amountSent`] = Number(this.sendMoneyDetails.amount * this.sendMoneyDetails.sender.exchangeRate);
      if(this.sendMoneyDetails.sender.country == this.sendMoneyDetails.receiver.country)
        data[`sameCountry`] = '1'
      this.service.postApi(data, 'transaction/sendRequest', 1).subscribe((response: any) => {
        this.service.dismissLoading();
        if (response.response_code == 200) {
          this.service.presentToast(response.response_message)
          this.navCtrl.setRoot(TabsPage, { selectedTab: 2 })
        } else if (response.response_code == 403 || response.response_code == 409 || response.response_code == 401) {
          this.service.presentToast(response.response_message)
          this.service.logout();
        }
        else {
          this.service.presentToast(response.response_message)
            }
      }, err => {
        this.service.dismissLoading();
        this.service.presentToast('Something went wrong')
      })
    } else
      this.service.presentToast('Your internet connection seems to be lost')
  }

  //To back to home
  backToHome(){
    // this.navCtrl.setRoot(HomePage);
    this.navCtrl.popToRoot();
    
  }

 

}
