import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ServiceService } from 'src/app/service/service.service';
import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'app-manage-exchange-fee-wallet',
  templateUrl: './manage-exchange-fee-wallet.component.html',
  styleUrls: ['./manage-exchange-fee-wallet.component.css']
})
export class ManageExchangeFeeWalletComponent implements OnInit {
  exchangeFeeWallet: any;
  p: any;
  page: number;
  total: any = 0;
  userIp: any;
  constructor(
    private service: ServiceService,
    private spinner: NgxSpinnerService,
    private route: Router,
    private cookie: CookieService
  ) { 
    this.userIp = (this.cookie.get('userInfo')) ? JSON.parse(this.cookie.get('userInfo')) : this.service.initialUserInfo;
  }

  ngOnInit() {
    this.getCheckAlert();
    
    window.scrollTo(0, 0);
  }

  goToSetting(coinName, id) {
    if (this.service.sideMenuArr.includes('updateSettings')) {
      this.route.navigate(['/manage-setting-exchange-fee-wallet/' + coinName + '/' + id]);
    }
  }

  getCheckAlert() {
    this.spinner.show();
    this.service.getMethod('wallet/admin/exchange-fee-wallet/check-and-create?ipAddress=' + this.userIp.ip + '&location=' + this.userIp.city + ',' + this.userIp.country_name, 1).subscribe((response: any) => {
      this.spinner.hide();
      if (response.status === 842) {
        this.getExchangeFeeWallet();
      }
    }, (error) => {
      this.spinner.hide();
    });
    this.spinner.hide();
  }

  getExchangeFeeWallet() {
    this.spinner.show();
    this.service.getMethod('wallet/admin/exchange-fee-wallet/get-all', 1).subscribe((response: any) => {
      this.spinner.hide();
      this.exchangeFeeWallet = [];
      if (response.status === 842) {
        response.data.forEach(element => {
            if(element.currencyName !== null) {
              this.exchangeFeeWallet.push(element);
            }
        });
      }
    }, (error) => {
      this.spinner.hide();
    });
    this.spinner.hide();

  }

  changePage(page) {
    this.p = page;
    this.page = page - 1;
    this.getExchangeFeeWallet();
  }
}
