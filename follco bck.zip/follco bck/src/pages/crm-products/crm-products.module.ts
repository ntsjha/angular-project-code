import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CrmProductsPage } from './crm-products';

@NgModule({
  declarations: [
    CrmProductsPage,
  ],
  imports: [
    IonicPageModule.forChild(CrmProductsPage),
  ],
})
export class CrmProductsPageModule {}
