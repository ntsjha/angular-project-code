import { Component, OnInit } from '@angular/core';
import { ServiceService } from 'src/app/service/service.service';
import { ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, FormArray, Validators } from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';
declare var $: any;

@Component({
  selector: 'app-social-media-link',
  templateUrl: './social-media-link.component.html',
  styleUrls: ['./social-media-link.component.css']
})
export class SocialMediaLinkComponent implements OnInit {
  canView: boolean;
  modeOfAction: string;
  canEdit: boolean;
  selectedLanguage: string;
  topicForm: FormGroup;
  socialMediaArray: any = [];
  links: FormArray;
  currentUser: any;
  currentId: any;
  arr = [];
  indexRemove: any;
  showApiMessage: boolean;
  response: any;


  constructor(private service: ServiceService, private activatedRoutes: ActivatedRoute, private fb: FormBuilder, private spinner: NgxSpinnerService) { }

  ngOnInit() {
    this.activatedRoutes.params.subscribe((data) => {
      this.modeOfAction = data.id1;
      this.languageSelection(data.id2);
    });
    this.service.currentUserInfo.subscribe((response) => {
      this.currentUser = response;
    });
    this.modeSelection();
    this.getSocialMedia();
    this.topicForm = this.fb.group({
      links: this.fb.array([
      ])
    });
    window.scrollTo(0, 0);
  }

  createLink(name, link, id, icon): FormGroup {
    return this.fb.group({
      icon: [name],
      link: [link, [Validators.required, Validators.pattern(/^(?:http(s)?:\/\/)?[\w.-]+(?:\.[\w\.-]+)+[\w\-\._~:/?#[\]@!\$&'\(\)\*\+,;=.]+$/)]],
      name: [name, [Validators.required, Validators.pattern(/^(\w+\s?)*\s*$/), Validators.maxLength(25), Validators.minLength(2)]],
      socialMediaId: [id],
    });
  }

  openModal(id) {
    if (this.service.sideMenuArr.includes('deleteSocialMediaLink')) {
      const IndexId = this.links.controls[id].value.socialMediaId;
      this.currentId = IndexId;
      this.indexRemove = id;
      $('#deleteModal').modal('show');
    }
  }

  removeSocialLink() {
    if (this.currentId === '') {
      this.links.removeAt(this.indexRemove);
      $('#deleteModal').modal('hide');
    } else {
      this.service.postMethod('static/admin/delete-social-media?ipAddress=' + encodeURIComponent(this.service.encrypt(this.currentUser.ip)) + '&location=' + encodeURIComponent(this.service.encrypt(this.currentUser.city)) + '&socialMediaId=' + encodeURIComponent(this.service.encrypt(this.currentId)), {}, 1)
        .subscribe((response) => {
          $('#deleteModal').modal('hide');
          if (response.status === 134 || response.status === 1084) {
            this.links.removeAt(this.indexRemove);
            this.showApiMessage = true;
            this.response = response;
          }
        }, (error) => {
          $('#deleteModal').modal('hide');
        });
    }
  }

  languageSelection(lang) {
    if (lang === 'th') {
      this.selectedLanguage = 'th';
    } else if (lang === 'ch') {
      this.selectedLanguage = 'ch';
    } else {
      this.selectedLanguage = 'en';
    }
  }

  modeSelection() {
    if (this.modeOfAction === 'edit') {
      this.canEdit = true;
      this.canView = false;
    } else {
      this.canEdit = false;
      this.canView = true;
    }
  }

  loadForm() {
    for (const social of this.socialMediaArray) {
      this.links = this.topicForm.get('links') as FormArray;
      this.links.push(this.createLink(social.name, social.link, social.socialMediaId, social.icon));
    }
  }

  addNewSocialMediaLink(): void {
    if (this.service.sideMenuArr.includes('createSocialMediaLink')) {
      this.links = this.topicForm.get('links') as FormArray;
      this.links.push(this.createLink(null, null, '', null));
    }
  }

  getSocialMedia() {
    this.links = this.fb.array([]);
    this.service.postMethod('static/admin/getSocialMedia', {}, 1)
      .subscribe((response) => {
        if (response.status === 134) {
          this.socialMediaArray = response.data;
          this.loadForm();
        }
      }, (error) => {
      });
  }

  updateSocialMedia() {
    if (this.service.sideMenuArr.includes('updateSocialMediaLink')) {
      if (this.topicForm.invalid) {
        return;
      }
      this.spinner.show();
      const socialArray = this.topicForm.value.links;
      const data = {
        ipAddress: (this.currentUser.ip),
        location: (this.currentUser.city + ', ' + this.currentUser.country_name),
        socialMediaDto: (socialArray),
      };
      this.service.postMethod('static/admin/addSocialMedia?socialDto=' + encodeURIComponent(this.service.encrypt(JSON.stringify(data))), {}, 1)
        .subscribe((response) => {
          this.spinner.hide();
          if (response.status === 132) {
            this.showApiMessage = true;
            this.response = response;
          }
        }, (error) => {
          this.spinner.hide();
          if (error.error) {
            this.showApiMessage = true;
            this.response = error.error;
          } else {
            this.showApiMessage = true;
            this.response = 'Something went wrong!';
          }
        });
    }
  }

}
