import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { CookieService } from 'ngx-cookie-service';
import { ServiceService } from 'src/app/service/service.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { ActivatedRoute, Router } from '@angular/router';
import { AppComponent } from 'src/app/app.component';
declare var $: any;

@Component({
  selector: 'app-standard-deposit-crypto',
  templateUrl: './standard-deposit-crypto.component.html',
  styleUrls: ['./standard-deposit-crypto.component.css']
})
export class StandardDepositCryptoComponent implements OnInit {
  cryptoFunction: FormGroup;
  currentUser: any;
  coinName: any;
  cryptoFiat: any;
  response: any = { 'message': '' };
  showApiMessage: boolean = false;
  userIp: any;
  subscription: any;

  constructor(
    private service: ServiceService,
    private spinner: NgxSpinnerService,
    private activatedRoute: ActivatedRoute,
    private cookie: CookieService,
    private route: Router,
    private appC: AppComponent
  ) {
    this.cryptoFunction = new FormGroup({
      fee: new FormControl(null, [Validators.required, Validators.maxLength(8), Validators.pattern(/^^\d+(\.\d{1,8})*$/)]),

    });
    this.service.currentUserInfo.subscribe((response) => {
      this.currentUser = response;
    });
    this.userIp = (this.cookie.get('userInfo')) ? JSON.parse(this.cookie.get('userInfo')) : this.service.initialUserInfo;
    this.subscription = this.service.authVerify.subscribe(val => {
      if (val === 'std-deposit-crypto') {
        this.depositCrypto();
        this.service.authVerify.next('false');
      }
    });
  }

  ngOnInit() {
    this.activatedRoute.params.subscribe(id => {
      this.coinName = id.id;
    });
    this.stdDepositCrypto();
    window.scrollTo(0, 0);
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  stdDepositCrypto() {
    this.spinner.show();
    this.service.getMethod('wallet/admin/fees/get-fee-details?currencyName=' + this.coinName + '&currencyType=crypto', 1).subscribe((response: any) => {
      this.spinner.hide();
      response = JSON.parse(this.service.decrypt(response.data))
      if (response.status === 845 || response.status === 842) {
        this.cryptoFiat = response.data;
        this.loadform();
      }
    }, (error) => {
      this.spinner.hide();
    });
    this.spinner.hide();
  }

  loadform() {
    this.cryptoFunction.patchValue({
      fee: this.cryptoFiat.stdDepositFee
    });
  }

  openGoogleAuth() {
    this.appC.google = { one: '', two: '', three: '', four: '', five: '', six: '' };
    this.appC.response = { message: '' };
    this.service.googleAuthCalledFrom = 'std-deposit-crypto';
    $('#google-auth-modal').modal({ keyboard: false, backdrop: 'static' });
  }

  depositCrypto() {
    this.spinner.show();
    const data = {
      amount: this.cryptoFunction.value.fee,
      coinName: this.coinName,
      ipAddress: this.userIp.ip,
      location: this.userIp.city + ',' + this.userIp.country_name
    };
    this.service.postMethod('wallet/admin/fees/set-std-crypto-deposit-fee', data, 1).subscribe((response: any) => {
      this.spinner.hide();
      if (response.status === 842) {
        this.route.navigate(['/standard-deposit']);
      } else if (response.status === 846) {
        this.response = response;
      }
    }, (error) => {
      this.spinner.hide();
    });
  }
}
