import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { CookieService } from 'ngx-cookie-service';
import { NgxSpinnerService } from 'ngx-spinner';
import { ServiceService } from 'src/app/service/service.service';
import { ActivatedRoute, Router } from '@angular/router';
import { AppComponent } from 'src/app/app.component';

declare var $: any;

@Component({
  selector: 'app-minimum-deposit-fiat',
  templateUrl: './minimum-deposit-fiat.component.html',
  styleUrls: ['./minimum-deposit-fiat.component.css']
})
export class MinimumDepositFiatComponent implements OnInit, OnDestroy {
  currentUser: any;
  fiatId: any;
  coinName: any;
  depositeFiat: any;
  subscription: any;
  minimumFiatDeposit: FormGroup;
  userIp: any;

  constructor(
    private cookie: CookieService,
    private service: ServiceService,
    private spinner: NgxSpinnerService,
    private activatedRoute: ActivatedRoute,
    private route: Router,
    private appC: AppComponent
  ) {
    this.minimumFiatDeposit = new FormGroup({
      fixedFee: new FormControl(null, [Validators.required, Validators.maxLength(8), Validators.pattern(/^[1-9][0-9]*$/)]),
      extraFee: new FormControl(null, [Validators.required, Validators.maxLength(8), Validators.pattern(/^[1-9][0-9]*$/)]),
      forFirst: new FormControl(null, [Validators.required, Validators.maxLength(8), Validators.pattern(/^[1-9][0-9]*$/)]),
      per: new FormControl(null, [Validators.required, Validators.maxLength(8), Validators.pattern(/^[1-9][0-9]*$/)]),
    });

    this.service.currentUserInfo.subscribe((response) => {
      this.currentUser = response;
    });
    this.subscription = this.service.authVerify.subscribe(val => {
      if (val === 'min-deposit-fiat') {
        this.depositFiat();
        this.service.authVerify.next('false');
      }
    });
    this.userIp = (this.cookie.get('userInfo')) ? JSON.parse(this.cookie.get('userInfo')) : this.service.initialUserInfo;
  }

  ngOnInit() {
    this.activatedRoute.params.subscribe(id => {
      this.fiatId = id.id;
      this.coinName = id.id2;
    });
    this.minDepositFiat();
    window.scrollTo(0, 0);
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  minDepositFiat() {
    this.spinner.show();
    this.service.getMethod('wallet/admin/fees/get-fee-details?currencyName=' + this.coinName + '&currencyType=fiat', 1).subscribe((response: any) => {
      this.spinner.hide();
      if (response.status === 845 || response.status === 842) {
        this.depositeFiat = response.data;
        this.loadform();
      }
      this.depositeFiat = JSON.parse(this.service.decrypt(response.data)).data;
    }, (error) => {
      this.spinner.hide();
    });
    this.spinner.hide();

  }

  loadform() {
    this.minimumFiatDeposit.patchValue({
      fixedFee: this.depositeFiat.minDepositFixedFee,
      extraFee: this.depositeFiat.minExtraFee,
      forFirst: this.depositeFiat.minDepositFixedFeeForFirst,
      per: this.depositeFiat.minExtraFeePer
    });
  }


  /** Function to verify google authentication */
  verifyGoogleAuth() {
    this.appC.google = { one: '', two: '', three: '', four: '', five: '', six: '' };
    this.appC.response = { message : '' };
    this.service.googleAuthCalledFrom = 'min-deposit-fiat';
    $('#google-auth-modal').modal({ keyboard: false, backdrop: 'static' });

  }

  depositFiat() {
    this.spinner.show();
    const data = {
      coinName: this.coinName,
      extraFee: this.minimumFiatDeposit.value.extraFee,
      extraFeePer: this.minimumFiatDeposit.value.per,
      fixedFee: this.minimumFiatDeposit.value.fixedFee,
      fixedFeeForFirst: this.minimumFiatDeposit.value.forFirst,
      ipAddress: this.userIp.ip,
      location: this.userIp.city + ',' + this.userIp.country_name
    };

    this.service.postMethod('wallet/admin/fees/set-min-fiat-deposit-fee', data, 1).subscribe((response: any) => {
      this.spinner.hide();
      if (response.status === 842) {
        this.route.navigate(['/minimum-deposit']);
      }
    }, (error) => {
      this.spinner.hide();
    });
  }

}
