import { Component, OnInit } from '@angular/core';
import { ServerService } from '../../../service/server.service';
import { AppComponent } from '../../../app.component';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { HeaderComponent } from '../../header/header/header.component';

@Component({
  selector: 'app-emailverify',
  templateUrl: './emailverify.component.html',
  styleUrls: ['./emailverify.component.css']
})
export class EmailverifyComponent implements OnInit {

  email: any;
  page: any;

  constructor(private server: ServerService, private appC: AppComponent, private spinnerService: Ng4LoadingSpinnerService, public header:HeaderComponent) { }

    ngOnInit() {
        window.scrollTo(0,0)
        let url = window.location.href.split('/')
        this.page = url[url.length - 1]
        if(this.page == 'login')  {
            this.page = true;
        } else 
            this.page = false;
    }
    

    resendEmail() {  
        this.spinnerService.show();
        this.server.getApi('account/resend-verify-email?email='+localStorage.getItem('email')+'&webUrl='+this.server.websiteURL+'header/login',0).subscribe(response => {
            this.spinnerService.hide();
            if (response.status == 200) {
                this.appC.showSuccToast("E-mail has been sent successfully.");
            } else if(response.status == 403){
                this.header.tokenExpire();
            } else {
                this.appC.showErrToast(response.message);
            }
        } , error => {
            this.spinnerService.hide();
            this.appC.showErrToast(error.error.message);
        });        
    }

}
