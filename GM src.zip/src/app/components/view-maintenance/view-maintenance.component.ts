import { Component, OnInit } from '@angular/core';
import { ServiceService } from 'src/app/service/service.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { ActivatedRoute } from '@angular/router';

@Component({
    selector: 'app-view-maintenance',
    templateUrl: './view-maintenance.component.html',
    styleUrls: ['./view-maintenance.component.css']
})
export class ViewMaintenanceComponent implements OnInit {
    maintenanceData: any;

    constructor(
        private service: ServiceService,
        private spinner: NgxSpinnerService,
        private activatedRoute: ActivatedRoute
    ) {
        this.activatedRoute.params.subscribe((id) => {
            this.getMaintenanceData(id.id);
        });
    }

    ngOnInit() {
    }

    /** Function to get maintenance data */
    getMaintenanceData(id) {
        this.spinner.show();
        this.service.getMethod('setting-service/common-permit/get-maintenance-mode-by-id?maintenanceId=' + encodeURIComponent(this.service.encrypt(id)), 1).subscribe((response: any) => {
            this.spinner.hide();
            let responseData = this.service.decrypt(response.data);
            responseData = JSON.parse(responseData);
            console.log(responseData)
            if(responseData.status == 1504) {
                this.maintenanceData = responseData.data;
            }

        }, (error) => {
            this.spinner.hide();
        });
    }

}
