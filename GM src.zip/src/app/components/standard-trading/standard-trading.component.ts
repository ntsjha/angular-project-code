import { Component, OnInit } from '@angular/core';
import { ServiceService } from 'src/app/service/service.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { Router } from '@angular/router';

@Component({
  selector: 'app-standard-trading',
  templateUrl: './standard-trading.component.html',
  styleUrls: ['./standard-trading.component.css']
})
export class StandardTradingComponent implements OnInit {
  stdTrading: any;

  constructor(
    private service: ServiceService,
    private spinner: NgxSpinnerService,
    private route: Router) { }

  ngOnInit() {
    this.getStdTrading();
    window.scrollTo(0, 0);
  }
  goToStdTradingFee() {
    this.route.navigate(['/standard-trading-fee']);
  }

  getStdTrading() {
    this.spinner.show();
    this.service.getMethod('fee/fetch-taker-maker', 1).subscribe((response: any) => {
      this.spinner.hide();
      if (response.status === 200) {
        if(response.data.length) {
          this.stdTrading = response.data[0];
        } else {
          this.stdTrading = response.data;
        }
        if(this.stdTrading.updatedBy == null) {
          this.stdTrading.updatedAt = null;
        }
      }
    }, (error) => {
      this.spinner.hide();
    });
    this.spinner.hide();
  }
}
