import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, App } from 'ionic-angular';
import { SettingprivacyPage } from '../settingprivacy/settingprivacy';
import { CrmPage } from '../crm/crm';
import { FormControl, Validators, FormGroup } from '@angular/forms';
import { RestProvider } from '../../providers/rest/rest';

/**
 * Generated class for the CrMediteventPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-cr-meditevent',
  templateUrl: 'cr-meditevent.html',
})
export class CrMediteventPage {
  reminderArr: any=[];
  newArrrr: any=[];
  eventForm:FormGroup;
  show: boolean = false;
   show1: boolean = false;
  validation_messages = {
     'email': [
      { type: 'required', message: 'Email is required.' },
      { type: 'pattern', message: 'Please enter a valid email.' }
    ],
    'type': [
      { type: 'required', message: 'Type is required.' },
      
    ],
  };
  leadsList: any;
  CutomerList: any;
  type1: any;
  value: any;
  newArrrr1: any=[];
  eventsList: any=[];
  starDDDate1: any;
  dateString1: any;
  endDDDate1: any;
  dateString2: any;
  myDate: any;
  startdatehours: any;
  startdateminutes: any;
  enddatehours: any;
  enddateminutes: any;
 
  constructor(public navCtrl: NavController,private service: RestProvider, public app :App,public navParams: NavParams) {
    this.eventForm = new FormGroup({
      title: new FormControl('', Validators.compose([
        //  Validators.required,
        //  Validators.pattern(/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/)
       ])),
       startDate: new FormControl('', Validators.compose([
         
       ])),
       startdateTime: new FormControl('', Validators.compose([
         
       ])),
      //  startdateminutes: new FormControl('', Validators.compose([
      //   //  Validators.required,
      //  ])),
       enddate: new FormControl('', Validators.compose([
         
       ])),
       enddateTime: new FormControl('', Validators.compose([
         
       ])),
      //  enddateminutes: new FormControl('', Validators.compose([
         
      //  ])),
       reminder: new FormControl('', Validators.compose([
         
       ])),
       eventnote: new FormControl('', Validators.compose([
         
       ])),
       location:new FormControl('', Validators.compose([
         
       ])),
       eventtype:new FormControl('', Validators.compose([
         
      ])),
      customer_id:new FormControl('', Validators.compose([
         
      ])),
      lead_id:new FormControl('', Validators.compose([
         
      ])),
     });
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad Crmediteventpage');
    this.getReminder();
    this.getcustomers();
    this.getleads();
    this.EventstDetails();
  }
  back(){
    this.navCtrl.pop();
  }
  setting()
{
  this.app.getRootNav().push(SettingprivacyPage);
}

onChange(type1) {
  console.log(type1);
  if(this.type1 == 'Customer meeting') {
   // this.value = 'customer';
   this.show = true;
   this.show1 = false; 
   
 }
 else if (this.type1 == 'Lead meeting') {
   // this.value = 'lead';  
   this.show = false;  
   this.show1 = true; 
  
 }else{
  this.show = false;  
  this.show1 = false; 
 }
}
Createevent(data){
  // console.log(this.myDate);
  console.log(data);
  console.log(data.type);

var a= this.eventForm.value.startdateTime;
var startTime = a.split(':');
this.startdatehours =startTime[0];
this.startdateminutes=startTime[1];

var b= this.eventForm.value.enddateTime;
var endTime =b.split(':');
this.enddatehours =endTime[0];
this.enddateminutes =endTime[1];

  this.service.presentLoadingDefault('Editing event');

  if(this.type1== 'customer'){
    let data1= new FormData();
    data1.append('customer_id',this.eventForm.value.customer_id);
    data1.append('event_title',this.eventForm.value.title);
    data1.append('event_date',this.eventForm.value.startDate);
    data1.append('event_time_hour',this.startdatehours);
    data1.append('event_time_minute',this.startdateminutes);
    data1.append('event_time_end_date',this.eventForm.value.enddate);
    data1.append('event_time_end_hour',this.enddatehours);
    data1.append('event_time_end_minute',this.enddateminutes);
    data1.append('reminder',this.eventForm.value.reminder =='None' ? '' : this.eventForm.value.reminder);
    data1.append('event_notes',this.eventForm.value.eventnote);
    data1.append('location',this.eventForm.value.location);
    data1.append('event_type',this.eventForm.value.eventtype);
    console.log("data1===+++>>",data1)
    this.service.post('events/save/'+ localStorage.getItem('event_id')+'?follco_token=' + localStorage.getItem('new_token'),data1,0).subscribe(res =>{
    console.log("Succ"+JSON.stringify(res)); 
    
    
    if(res.message){
      this.service.dismissLoading();
      this.service.presentToast(res.message) ; 
      this.navCtrl.pop();
    }else{
      this.service.presentToast(res.error) ; 
      this.service.dismissLoading();
      
    }
   
   
  },err =>{
    console.log(err);
    
  })

  }
  else if(this.type1 == 'lead'){
    let data2= new FormData();
    data2.append('lead_id',this.eventForm.value.lead_id);
    data2.append('event_title',this.eventForm.value.title);
    data2.append('event_date',this.eventForm.value.startDate);
    data2.append('event_time_hour',this.startdatehours);
    data2.append('event_time_minute',this.startdateminutes);
    data2.append('event_time_end_date',this.eventForm.value.enddate);
    data2.append('event_time_end_hour',this.enddatehours);
    data2.append('event_time_end_minute',this.enddateminutes);
    data2.append('reminder',this.eventForm.value.reminder =='None' ? '' : this.eventForm.value.reminder);
    data2.append('event_notes',this.eventForm.value.eventnote);
    data2.append('location',this.eventForm.value.location);
    data2.append('event_type',this.eventForm.value.eventtype);
    console.log("data2===+++>>",data2)
    this.service.post('events/save/'+ localStorage.getItem('event_id')+'?follco_token=' + localStorage.getItem('new_token'),data2,0).subscribe(res =>{
    console.log("Succ"+JSON.stringify(res)); 
    
    
    if(res.message){
      this.service.dismissLoading();
      this.service.presentToast(res.message) ; 
      this.navCtrl.pop();
    }else{
      this.service.presentToast(res.error) ; 
      this.service.dismissLoading();
      
    }
   
   
  },err =>{
    console.log(err);
    
  })
    
  }
  else{
    let data3= new FormData();
   
    data3.append('event_title',this.eventForm.value.title);
    data3.append('event_date',this.eventForm.value.startDate);
    data3.append('event_time_hour',this.startdatehours);
    data3.append('event_time_minute',this.startdateminutes);
    data3.append('event_time_end_date',this.eventForm.value.enddate);
    data3.append('event_time_end_hour',this.enddatehours);
    data3.append('event_time_end_minute',this.enddateminutes);
    data3.append('reminder',this.eventForm.value.reminder =='None' ? '' : this.eventForm.value.reminder);
    data3.append('event_notes',this.eventForm.value.eventnote);
    data3.append('location',this.eventForm.value.location);
    data3.append('event_type',this.eventForm.value.eventtype);
    console.log("data3===+++>>",data3)
    this.service.post('events/save/'+ localStorage.getItem('event_id')+'?follco_token=' + localStorage.getItem('new_token'),data3,0).subscribe(res =>{
    console.log("Succ"+JSON.stringify(res)); 
    
    
    if(res.message){
      this.service.dismissLoading();
      this.service.presentToast(res.message) ; 
      this.navCtrl.pop();
    }else{
      this.service.presentToast(res.error) ; 
      this.service.dismissLoading();
      
    }
   
   
  },err =>{
    console.log(err);
    
  })

  }
  
   

}
EventstDetails() {
  this.service.presentLoadingDefault('Loading...');
  this.service.get('events/single/'+ localStorage.getItem('event_id')+'?follco_token=' + localStorage.getItem('new_token'),0).subscribe(res =>{
      console.log(res);
      if(res) {
        this.service.dismissLoading();
        this.eventsList = res["record"];

     
        // var month_names =["Jan","Feb","Mar",
        // "Apr","May","Jun",
        // "Jul","Aug","Sep",
        // "Oct","Nov","Dec"];

        // var month = new Date(this.eventsList['extra'].event_time_start * 1000).getMonth()
        // console.log(month)
        // var dateval = new Date(this.eventsList['extra'].event_time_start * 1000).getDate()
        // console.log(dateval)
        // var year = new Date(this.eventsList['extra'].event_time_start * 1000).getFullYear()
        // console.log(year)
        // this.dateString1  =  dateval+ " " +  month_names[month] + " " + year
        // console.log(  this.dateString1 )
       


       if(this.eventsList['extra'].event_time_end != null){
         this.dateString1 =new Date((this.eventsList['extra'].event_time_end)*1000).toISOString();
       }
       else{
         this.dateString1 == ''
       }

       if(this.eventsList['extra'].event_time_start !=  null){
         this.dateString2 =new Date((this.eventsList['extra'].event_time_start)*1000).toISOString();
       }
       else{
         this.dateString2 == ''
       }
      


        // this.starDDDate1 = new Date(this.eventsList['extra'].event_time_start * 1000);
        // // var theDate = new Date(timeStamp_value * 1000);
        // this.dateString1 = this.starDDDate1.toLocaleDateString();
        // console.log(this.dateString1 );

        // this.endDDDate1 = new Date(this.eventsList['extra'].event_time_end * 1000);
        // this.dateString2 = this.endDDDate1.toDateString();
        // console.log(this.dateString2);
       
         
       this.eventForm.patchValue({
        title: this.eventsList.title,
        enddate:  this.dateString1,
        startDate:  this.dateString2,
        location: this.eventsList['extra'].location,
        // phone2: this.eventsList['extra'].phone2,
        // leadtype: this.eventsList['extra'].lead_type,
        // address3: this.eventsList['extra'].address3,
        // postCode :this.eventsList['extra'].postcode,
        // city :this.eventsList['extra'].city,
        // country1 : this.eventsList['extra'].country,
        // country2 :this.eventsList['extra'].county,
      })     
        
    }
      
       
      
     
      
  }, err => {
      this.service.dismissLoading();
      console.log(err);
  })
}
getReminder(){
  // console.log('Country')
   this.service.get('misc/reminder_value_list',0).subscribe(res =>{
     console.log('ReminderList'+JSON.stringify(res));
     if(res){
      this.reminderArr = res['list'];
      console.log('reminderList=====>>>>'+JSON.stringify(this.reminderArr));
      for (let [key, value] of (<any>Object).entries(this.reminderArr)) {  
        // console.log('Aashish====> ',key + ':' + value);
        if(key == ''){
          this. newArrrr1.push({
            'Key'  :  'None',
            'Type' :  value
          })
        }else{
          this. newArrrr1.push({
            'Key' : key,
            'Type' : value
          })
        }
      }
      console.log('shivam===>',this.newArrrr1);

     }
   
   },err =>{
     console.log(err)
   })
}
getleads() {
  // this.service.presentLoadingDefault('Loading...');
  this.service.get('leads/list?follco_token=' + localStorage.getItem('new_token'),0).subscribe(res =>{
      console.log(res);
      if(res) {
          // this.service.dismissLoading();
          this.leadsList = res['list'];
          
          // this.time = new Date (this.campaignList[0].created_at);
          // this.time1 =this.time.getDate() + '/' + (this.time.getMonth()+1) + '/' + this.time.getFullYear();
          // console.log(this.time1); 
       
        
      }
  }, err => {
      // this.service.dismissLoading();
      console.log(err);
  })
}
getcustomers() {
  // this.service.presentLoadingDefault('Loading...');
  this.service.get('customers/list?follco_token=' + localStorage.getItem('new_token'),0).subscribe(res =>{
      console.log(res);
      if(res) {
          // this.service.dismissLoading();
          this.CutomerList = res['list'];
         
          // this.time = new Date (this.campaignList[0].created_at);
          // this.time1 =this.time.getDate() + '/' + (this.time.getMonth()+1) + '/' + this.time.getFullYear();
          // console.log(this.time1); 
       
        
      }
  }, err => {
      // this.service.dismissLoading();
      console.log(err);
  })
}
}
