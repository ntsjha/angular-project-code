import { MainServiceService } from 'src/app/main-service.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { Router } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';

@Component({
    selector: 'app-reset-password',
    templateUrl: './reset-password.component.html',
    styleUrls: ['./reset-password.component.css']
})
export class ResetPasswordComponent implements OnInit {

    resetPasswordForm: FormGroup;

    constructor(
        public service: MainServiceService,
        public spinnerService: Ng4LoadingSpinnerService,
        private router: Router,
        public cookie: CookieService
    ) { }

    ngOnInit() {
        this.formValidation();
    }

    formValidation() {
        this.resetPasswordForm = new FormGroup({
            password: new FormControl('', [Validators.required, Validators.minLength(8), Validators.maxLength(16)]),
            confirmPassword: new FormControl('', [Validators.required]),
            verifyOtp: new FormControl('', [Validators.required]),
        });
    }

    /**Function to verify OTP */
    verifyOTPFunc() {
        let data = {
            "otp": this.resetPasswordForm.value.verifyOtp,
        }
        this.service.post('user/otpVerify', data, 0).subscribe(success => {
            if (success.responseCode == 200) {
                this.spinnerService.hide();
                this.resetPasswordFunc();
            } else {
                this.spinnerService.hide();
                this.service.showError(success.responseMessage);
            }
        }, error => {
            this.service.showError('Something went wrong');
            this.spinnerService.hide();
        });
    }

    /**Function to reset password */
    resetPasswordFunc() {
        this.spinnerService.show();
        if (this.resetPasswordForm.invalid || (this.resetPasswordForm.value.confirmPassword !== this.resetPasswordForm.value.password)) {
            this.spinnerService.hide();
            return;
        }
        if (!navigator.onLine) {
            this.service.showWarning('Please check your internet conectivity');
            this.spinnerService.hide();
            return;
        }
        let apireq = {
            newPassword: this.resetPasswordForm.value.password,
            confirmPassword: this.resetPasswordForm.value.confirmPassword,
        };
        this.service.post('user/resetPassword', apireq, 1).subscribe(success => {
            if (success.responseCode == 200) {
                this.spinnerService.hide();
                this.service.showSuccess(success.responseMessage);
                this.router.navigate(['login']);
            } else {
                this.spinnerService.hide();
                this.service.showError(success.responseMessage);
            }
        }, error => {
            this.service.showError('Something went wrong');
            this.spinnerService.hide();
        });
    }
}