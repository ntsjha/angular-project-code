import { Component, OnInit } from '@angular/core';
import { ServiceService } from 'src/app/Shared/service.service';
import Swal from 'sweetalert2';
import { AngularFirestore } from '@angular/fire/firestore';
import { ActivatedRoute, Router } from '@angular/router';
import { FeedType } from 'src/app/Shared/feed-type';
import { FormGroup, Validators, FormControl, FormArray, FormBuilder } from "@angular/forms";
import * as firebase from 'firebase/app';

@Component({
  selector: 'app-add-setting',
  templateUrl: './add-setting.component.html',
  styleUrls: ['./add-setting.component.css']
})
export class AddSettingComponent implements OnInit {

  breed: any = '';
  color: any = '';
  service: any = '';
  brand: any = '';
  type: any = '';
  use: any = '';
  discipline: any = ''
  disciplinetackuse: any = ''
  activitytype: any = ''
  contentname: any = '';

  formdata: any = '';
  BreedTypeArr: any = [];
  ColorTypeArr: any = [];
  serviceTypeArr: any = [];
  tackTypeArr: any = [];
  tackBrandArr: any = [];
  tackUseArr: any = [];
  disciplineArr: any = [];
  ActivityArr: any = [];
  RugTemperatureArr: any = [];
  RugWhenArr: any = [];
  RugWeatherArr: any = [];
  RugTypeArr: any = [];
  FeedTypeArr: any = [];

  orderForm: FormGroup;
  items: FormArray;
  addmachineForm: FormGroup;
  dataArray: { Feed: any[]; unit: any[]; };
  Feed: any = [];
  unit: any = [];
  docname: any;
  FeedUnitArry: any = [];
  feedunituse: any;
  messagepop: any;
  section: any;


  constructor(public router: Router, public formBuilder: FormBuilder, private afs: AngularFirestore, private firebaseServ: ServiceService, public route: ActivatedRoute) { }

  async ngOnInit() {

    this.route.queryParams.subscribe((res) => {
      console.log('params--->>> ', res);
      this.contentname = res.id
      this.section=res.section?res.section:''
    })
    this.callfunction()
    this.addfeedtype()
    this.addNozzle()
    this.addUnit()
    this.messagepop = this.contentname.toLowerCase()
  }

  // ************Form Array For adding a multiple sub data********************
  addfeedtype() {
    this.addmachineForm = new FormGroup({
      feedtype: new FormControl("", [Validators.required, Validators.maxLength(50),]),
      'nozzles': this.formBuilder.array([]),
      'unitname': this.formBuilder.array([])
    });
  }


  addNozzle() {
    const nozzles = this.addmachineForm.controls.nozzles as FormArray;
    nozzles.push(this.formBuilder.group({
      'feedname': new FormControl('', [Validators.required, Validators.maxLength(50),]),
      // 'unitname': new FormControl('', [Validators.required, Validators.maxLength(250)])
    }));
  }

  addUnit() {
    const unitname = this.addmachineForm.controls.unitname as FormArray;
    unitname.push(this.formBuilder.group({
      // 'feedname': new FormControl('', [Validators.required, Validators.maxLength(250),]),
      'unitdata': new FormControl('', [Validators.required, Validators.maxLength(50)])
    }));
  }



  removeNozzle(index) {

    let control = <FormArray>this.addmachineForm.controls.nozzles;
    control.removeAt(index)

  }
  removeUnit(index) {

    let control = <FormArray>this.addmachineForm.controls.unitname;
    control.removeAt(index)

  }


  // ************End  of Form Array ********************

  async  callfunction() {

    switch (this.contentname) {
      case 'Breed':
        console.log('params--->>> ', this.contentname);
        await this.getBreedTypes();
        break;
      case 'Colour':
        await this.getColorTypes();
        break;
      case 'Brand':
        await this.getTackTypeList();
        break;
      case 'Type':
        await this.getTackBrandList();
        break;
      case 'Use':
        await this.getTackUseList();
        break;
      case 'Service':
        await this.getServiceTypeFunc();
        break;
      case 'Discipline':
        await this.getDisciplineTypeFunc();
        break;
      case 'TackUse':
        await this.getDisciplineTackUseTypeFunc();
        break;
      case 'ActivityType':
        await this.getActivityTypeFunc();
        break;
      case 'Temperature':
        await this.getRugTemperatureFunc();
        break;
      case 'RugType':
        await this.getRugTypeFunc();
        break;
      case 'Weather':
        await this.getRugWeatherFunc();
        break;
      case 'When':
        await this.getRugWhenFunc();
        break;
      case 'FeedType':
        await this.getFeedTypeFunc();
        break;
      case 'unit':
        await this.getFeedUnitTypeFunc();
        break;
      case 'Feed':
        await this.getFeedUnitTypeFunc();
        break;
      default:
        this.firebaseServ.toastErr('Something went wrong')
        break;
    }
  }

  preventSpace(event){
    if(event.charCode==32 && !event.target.value){
    event.preventDefault()
    } else{
    console.log(event)
    }
    console.log('event',event.charCode)
    }


  getBreedTypes() {
    this.firebaseServ.getBreedTypeFunc().then(res => {
      console.log('BreedType_Succ', res)
      this.BreedTypeArr = res[0].BreedType;
    }).catch(err => {
      console.log(err)
    })
  }

  getColorTypes() {
    this.firebaseServ.getColorTypeFunc().then(res => {
      console.log('ColorType_Succ', res)
      this.ColorTypeArr = res[0].ColorType;
    }).catch(err => {
      console.log(err)
    })
  }

  getTackTypeList() {
    this.firebaseServ.getTackTypeListFunc().then(res => {
      console.log('TackTypes =======>', res)
      this.tackTypeArr = res.TackType;
    }).catch(err => {
      console.log(err)
    })
  }

  getTackBrandList() {
    this.firebaseServ.getTackBrandListFunc().then(res => {
      console.log('TackBrands =======>', res)
      this.tackBrandArr = res.TackBrand;
    }).catch(err => {
      console.log(err)
    })
  }

  getTackUseList() {
    this.firebaseServ.getTackUseListFunc().then(res => {
      console.log('TackUses =======>', res)
      this.tackUseArr = res.TackUse;
    }).catch(err => {
      console.log(err)
    })
  }


  getServiceTypeFunc() {
    this.firebaseServ.getServiceTypeFunc().then(res => {
      console.log('SelectServiceType' + JSON.stringify(res))
      this.serviceTypeArr = res[0].ServiceType
      console.log('SelectServiceType' + JSON.stringify(res[0]))
    }).catch(err => {
      console.log(err)
    })
  }
  getDisciplineTypeFunc() {
    this.firebaseServ.getDisciplineTypeFunc().then(res => {

      this.disciplineArr = res.Discipline
      console.log('Discipline', this.disciplineArr)

    }).catch(err => {
      console.log(err)
    })

  }

  getDisciplineTackUseTypeFunc() {
    this.firebaseServ.getDisciplineTackuseFunc().then(res => {
      console.log('DisciplineTack' + JSON.stringify(res))
      this.tackUseArr = res.TackUse

    }).catch(err => {
      console.log(err)
    })

  }
  getActivityTypeFunc() {
    this.firebaseServ.getActivitytypeFunc().then(res => {

      this.ActivityArr = res.ActivityList
      console.log('DisciplineTack', this.ActivityArr)
    }).catch(err => {
      console.log(err)
    })

  }
  getRugTemperatureFunc() {
    this.firebaseServ.getRugtypeFunc().then(res => {
      console.log('getRugtypeFunc' + JSON.stringify(res))
      this.RugTemperatureArr = res.Temperature

    }).catch(err => {
      console.log(err)
    })
  }

  getRugTypeFunc() {
    this.firebaseServ.getRugtypeFunc().then(res => {
      console.log('getRugtypeFunc' + JSON.stringify(res))
      this.RugTypeArr = res.Type

    }).catch(err => {
      console.log(err)
    })
  }
  getRugWeatherFunc() {
    this.firebaseServ.getRugtypeFunc().then(res => {
      console.log('getRugtypeFunc' + JSON.stringify(res))
      this.RugWeatherArr = res.Weather

    }).catch(err => {
      console.log(err)
    })
  }

  getRugWhenFunc() {
    this.firebaseServ.getRugtypeFunc().then(res => {
      console.log('getRugtypeFunc' + JSON.stringify(res))
      this.RugWhenArr = res.When

    }).catch(err => {
      console.log(err)
    })
  }

  getFeedTypeFunc() {
    this.firebaseServ.getFeedTypeFunc().subscribe(actionArray => {
      // console.log('=========>', actionArray)
      var userList = actionArray.map(item => {
        // console.log('Items====>', item)
        return {
          id: item.payload.doc.id,
          ...item.payload.doc.data()

        } as FeedType;

      })
      // console.log('=========>', userList)
      userList.forEach(element => {

        this.FeedTypeArr.push(element.id)

      });


      console.log("user Count--->>>", this.FeedTypeArr)
    });
  }

  getFeedUnitTypeFunc() {
    this.route.params.subscribe((res) => {
      console.log('params--->>> ', res);

      this.docname = res.id
    })
    console.log("user", this.contentname, this.docname)

    this.firebaseServ.getFeedFunc(this.section).then(res => {
      console.log('getRugtypeFunc' + JSON.stringify(res))
      if (this.docname == 'Feed') {
        this.FeedUnitArry = res.Feed
      }
      else {
        this.FeedUnitArry = res.unit
      }
      console.log('getRugtypeFunc', this.FeedUnitArry)
    }).catch(err => {
      console.log(err)
    })
  }


  // ***********UPDATE VALUE *****************
  Adddateviewdata() {

    switch (this.contentname) {
      case 'Breed':
        console.log('params--->>> ', this.contentname);
        this.AddNewBreedFunc();
        break;
      case 'Colour':
        this.AddNewColorFunc();
        break;
      case 'Brand':
        this.addNewTackTypeFunction();
        break;
      case 'Type':
        this.addnewTackBrandFunc();
        break;
      case 'Use':
        this.addNewTackUseFunc();
        break;
      case 'Service':
        this.AddNewServiceTypeFunction();
        break;
      case 'Discipline':
        this.AddNewDisciplineTypeFunc();
        break;
      case 'TackUse':
        this.AddNewTackUseTypeFunc();
        break;
      case 'ActivityType':
        this.AddnewActivityTypeFunc();
        break;
      case 'Temperature':
        this.AddnewRugTypeFunc();
        break;
      case 'RugType':
        this.AddnewRugTypeFunc();
        break;
      case 'Weather':
        this.AddnewRugTypeFunc();
        break;
      case 'When':
        this.AddnewRugTypeFunc();
        break;
      case 'FeedType':
        this.AddnewFeedTypeFunc();
        break;
      case 'unit':
        this.AddFeedUnitTypeFunc();
        break;
      case 'Feed':
        this.AddFeedUnitTypeFunc();
        break;
      default:
        // this.UpdateServiceTypeFunc();
        break;

    }

  }





  AddNewBreedFunc() {
    

    Swal.fire({
      title: 'Are you sure?',
      text: "You want to add this " + this.messagepop + " name",
      type: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes'
    }).then((result) => {
      if (result.value) {
        this.firebaseServ.showSpinner();
        if (this.BreedTypeArr.includes(this.formdata)) {
          console.log('BreeedExists====>', this.BreedTypeArr.includes(this.formdata))
          this.firebaseServ.hideSpinner();
          this.formdata='';
          this.firebaseServ.toastErr(['This  '+ this.messagepop +'  name is already taken'])
       
        } else {
          console.log('BreeedDontExists====>', this.BreedTypeArr.includes(this.formdata))
          if (this.formdata != '') {
            this.BreedTypeArr.push(this.formdata)
            console.log('NewBreedTypeArr', this.BreedTypeArr)
            this.updateBreedArrFunc(this.BreedTypeArr)
          }
        }
      }
    })
  }

  updateBreedArrFunc(newArr) {
    this.firebaseServ.addNewBreedFunc(newArr).then(res => {
      console.log('AddBreed_Succ', res)
      this.firebaseServ.hideSpinner();
      // Swal.fire(
      //   'Success!',
      //   'Your changes has been addeded successfully.',
      //   'success'
      // )
      this.firebaseServ.showSuccess('Your changes has been added successfully.')
      this.formdata = '';
    }).catch(err => {
      console.log('AddBreed_Err', err)
    })
  }

  AddNewColorFunc() {
    Swal.fire({
      title: 'Are you sure?',
      text: "You want to add this " + this.messagepop + " name",
      type: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes'
    }).then((result) => {
      if (result.value) {
        this.firebaseServ.showSpinner();
        if (this.ColorTypeArr.includes(this.formdata)) {
          console.log('ColourExists====>', this.ColorTypeArr.includes(this.formdata))
          this.firebaseServ.hideSpinner();
          this.formdata='';
          this.firebaseServ.toastErr(['This  '+ this.messagepop +'  name is already taken'])
        } else {
          console.log('ColourDontExists====>', this.ColorTypeArr.includes(this.formdata))
          if (this.formdata != '') {
            this.ColorTypeArr.push(this.formdata)
            console.log('NewColorTypeArr', this.ColorTypeArr)
            this.updateColourArrFunc(this.ColorTypeArr)
          }
        }
      }
    })
  }

  updateColourArrFunc(newArr) {
    this.firebaseServ.addNewColourFunc(newArr).then(res => {
      console.log('AddColour_Succ', res)
      this.firebaseServ.hideSpinner();
      // Swal.fire(
      //   'Success!',
      //   'Your changes has been added successfully.',
      //   'success'
      // )
      this.firebaseServ.showSuccess('Your changes has been added successfully.')
      this.formdata = '';
    }).catch(err => {
      console.log('AddColour_Err', err)
    })
  }


  AddNewServiceTypeFunction() {
    Swal.fire({
      title: 'Are you sure?',
      text: "You want to add this " + this.messagepop + " name",
      type: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes'
    }).then((result) => {
      if (result.value) {
        this.firebaseServ.showSpinner();
        if (this.serviceTypeArr.includes(this.formdata)) {
          console.log('Present', this.formdata, this.serviceTypeArr)
          this.firebaseServ.hideSpinner();
          this.formdata='';
          this.firebaseServ.toastErr(['This  '+ this.messagepop +'  name is already taken'])
          var data = [...this.serviceTypeArr];
        } else {
          var data = [...this.serviceTypeArr];
          data.push(
            this.formdata
          )
          console.log('NewArr' + JSON.stringify(data))
          console.log('NotPresent', this.formdata)
          this.updateServiceArrFunc(data)
        }
      }
    })
  }

  updateServiceArrFunc(newArr) {
    this.firebaseServ.addNewServiceTypeFunc(newArr).then(res => {
      console.log(res)
      this.firebaseServ.hideSpinner();
      this.firebaseServ.showSuccess('Your changes has been added successfully.')
      this.formdata = '';
    }).catch(err => {
      console.log(err)
    })
  }

  addnewTackBrandFunc() {
    Swal.fire({
      title: 'Are you sure?',
      text: "You want to add this " + this.messagepop + " name",
      type: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes'
    }).then((result) => {
      if (result.value) {
        this.firebaseServ.showSpinner();
        if (this.tackBrandArr.includes(this.formdata)) {
          console.log('Present', this.brand)
          this.firebaseServ.hideSpinner();
          this.formdata='';
          this.firebaseServ.toastErr(['This  '+ this.messagepop +'  name is already taken'])
          var data = [...this.tackBrandArr];
        } else {
          var data = [...this.tackBrandArr];
          data.push(
            this.formdata
          )
          console.log('NewArr' + JSON.stringify(data))
          console.log('NotPresent', this.formdata)
          this.updateTackBrandArrFunc(data)
        }
      }
    })
  }

  updateTackBrandArrFunc(newArr) {
    this.firebaseServ.addNewTackBrandFunc(newArr).then(res => {
      console.log(res)
      this.firebaseServ.hideSpinner();
    
      this.firebaseServ.showSuccess('Your changes has been added successfully.')
      this.formdata = '';
    }).catch(err => {
      console.log(err)
    })
  }

  addNewTackTypeFunction() {
    Swal.fire({
      title: 'Are you sure?',
      text: "You want to add this " + this.messagepop + " name",
      type: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes'
    }).then((result) => {
      if (result.value) {
        this.firebaseServ.showSpinner();
        if (this.tackTypeArr.includes(this.formdata)) {
          console.log('Present', this.formdata)
          var data = [...this.tackTypeArr];
          this.firebaseServ.hideSpinner();
          this.formdata='';
          this.firebaseServ.toastErr(['This  '+ this.messagepop +'  name is already taken'])
        } else {
          var data = [...this.tackTypeArr];
          data.push(
            this.formdata
          )
          console.log('NewArr' + JSON.stringify(data))
          console.log('NotPresent', this.type)
          this.updateTackTypeFunc(data)
        }
      }
    })
  }

  updateTackTypeFunc(newArr) {
    this.firebaseServ.addNewTackTypeFunc(newArr).then(res => {
      console.log(res)
      this.firebaseServ.hideSpinner();
      // Swal.fire(
      //   'Success!',
      //   'Your changes has been added successfully.',
      //   'success'
      // )
      this.firebaseServ.showSuccess('Your changes has been added successfully.')
      this.formdata = '';
    }).catch(err => {
      console.log(err)
    })
  }

  addNewTackUseFunc() {
    var data = '';
    Swal.fire({
      title: 'Are you sure?',
      text: "You want to add this " + this.messagepop + " name",
      type: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes'
    }).then((result) => {
      if (result.value) {
        this.firebaseServ.showSpinner();
        if (this.tackUseArr.includes(this.formdata)) {
          console.log('Present', this.formdata)
          this.firebaseServ.hideSpinner();
          this.formdata='';
          this.firebaseServ.toastErr(['This  '+ this.messagepop +'  name is already taken'])
          var data = [...this.tackUseArr];
        } else {
          var data = [...this.tackUseArr];
          data.push(
            this.formdata
          )
          console.log('NewArr' + JSON.stringify(data))
          console.log('NotPresent', this.formdata)
          this.updateTackUseFunc(data)
        }
      }
    })
  }

  updateTackUseFunc(newArr) {
    this.firebaseServ.addNewTackUseFunc(newArr).then(res => {
      console.log(res)
      this.firebaseServ.hideSpinner();
      // Swal.fire(
      //   'Success!',
      //   'Your changes has been added successfully.',
      //   'success'
      // )
      this.firebaseServ.showSuccess('Your changes has been added successfully.')
      this.formdata = '';
      this.getDisciplineTypeFunc()
    }).catch(err => {
      console.log(err)
    })
  }


  AddNewDisciplineTypeFunc() {
    Swal.fire({
      title: 'Are you sure?',
      text: "You want to add this " + this.messagepop + " name",
      type: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes'
    }).then((result) => {
      if (result.value) {
        this.firebaseServ.showSpinner();
        if (this.disciplineArr.includes(this.formdata)) {
          console.log('Discipline Existss====>', this.disciplineArr.includes(this.formdata))
          this.firebaseServ.hideSpinner();
          this.formdata='';
          this.firebaseServ.toastErr(['This  '+ this.messagepop +'  name is already taken'])
        } else {
          console.log('Discipline else====>', this.disciplineArr.includes(this.formdata))
          if (this.formdata != '') {
            this.disciplineArr.push(this.formdata)
            console.log('Discipline', this.disciplineArr)
            this.updateDisciplineUseFunc(this.disciplineArr)
          }
        }
      }
    })

  }

  updateDisciplineUseFunc(newArr) {
    this.firebaseServ.addNewDisciplineUseFunc(newArr).then(res => {
      console.log(res)
      this.firebaseServ.hideSpinner();
      // Swal.fire(
      //   'Success!',
      //   'Your changes has been added successfully.',
      //   'success'
      // )
      this.firebaseServ.showSuccess('Your changes has been added successfully.')

      this.formdata = '';
    }).catch(err => {
      this.firebaseServ.hideSpinner()
      console.log(err)
    })

  }
  AddNewTackUseTypeFunc() {
    Swal.fire({
      title: 'Are you sure?',
      text: "You want to add this " + this.messagepop + " name",
      type: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes'
    }).then((result) => {
      if (result.value) {
        this.firebaseServ.showSpinner();
        if (this.tackUseArr.includes(this.formdata)) {
          console.log('Discipline Exists====>', this.tackUseArr.includes(this.formdata))
          this.firebaseServ.hideSpinner();
          this.formdata='';
          this.firebaseServ.toastErr(['This  '+ this.messagepop +'  name is already taken'])
        } else {
          console.log('Discipline dont Exists====>', this.tackUseArr.includes(this.formdata))
          if (this.formdata != '') {
            this.tackUseArr.push(this.formdata)
            console.log('Discipline', this.disciplineArr)
            this.updateDisciplineTackUseFunc(this.tackUseArr)
          }
        }
      }
    })
  }

  updateDisciplineTackUseFunc(newArr) {
    this.firebaseServ.addNewDisciplineTackuseFunc(newArr).then(res => {
      console.log(res)
      this.firebaseServ.hideSpinner();
      // Swal.fire(
      //   'Success!',
      //   'Your changes has been added successfully.',
      //   'success'
      // )
      this.firebaseServ.showSuccess('Your changes has been added successfully.')

      this.formdata = '';
    }).catch(err => {

      this.firebaseServ.hideSpinner()
      console.log(err)
    })
  }

  AddnewActivityTypeFunc() {
    Swal.fire({
      title: 'Are you sure?',
      text: "You want to add this " + this.messagepop + " name",
      type: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes'
    }).then((result) => {
      if (result.value) {
        this.firebaseServ.showSpinner();
        if (this.ActivityArr.includes(this.formdata)) {
          console.log('ActivityArr Exists====>', this.ActivityArr.includes(this.formdata))
          this.firebaseServ.hideSpinner();
          this.formdata='';
          this.firebaseServ.toastErr(['This  '+ this.messagepop +'  name is already taken'])
        } else {
          console.log('ActivityArr else====>', this.ActivityArr.includes(this.formdata))
          if (this.formdata != '') {
            this.ActivityArr.push(this.formdata)
            console.log('Discipline', this.disciplineArr)
            this.updateActivitytypeUseFunc(this.ActivityArr)
          }
        }
      }
    })
  }

  updateActivitytypeUseFunc(newArr) {
    this.firebaseServ.addNewActivitytypeFunc(newArr).then(res => {
      console.log(res)
      this.firebaseServ.hideSpinner();

      this.firebaseServ.showSuccess('Your changes has been added successfully.')

      this.formdata = '';
    }).catch(err => {

      this.firebaseServ.hideSpinner()
      console.log(err)
    })
  }


  AddnewRugTypeFunc() {
    Swal.fire({
      title: 'Are you sure?',
      text: "You want to add this " + this.messagepop + " name",
      type: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes'
    }).then((result) => {
      if (result.value) {
        if (this.contentname == 'Temperature') {
          this.firebaseServ.showSpinner();
          if (this.RugTemperatureArr.includes(this.formdata)) {
            console.log('RugTemperatureArr Exists====>', this.RugTemperatureArr.includes(this.formdata))
            this.firebaseServ.hideSpinner();
            this.formdata='';
            this.firebaseServ.toastErr(['This  '+ this.messagepop +'  name is already taken'])
          } else {
            console.log('RugTemperatureArr else====>', this.RugTemperatureArr.includes(this.formdata))
            if (this.formdata != '') {
              this.RugTemperatureArr.push(this.formdata)
              console.log('Discipline', this.disciplineArr)
              this.updateRugtypeUseFunc(this.RugTemperatureArr, 'Temperature')
            }
          }
        }

        else if (this.contentname == 'RugType') {
          this.firebaseServ.showSpinner();
          if (this.RugTypeArr.includes(this.formdata)) {
            console.log('RugTypeArr Exists====>', this.BreedTypeArr.includes(this.formdata))
            this.firebaseServ.hideSpinner();
            this.formdata='';
            this.firebaseServ.toastErr(['This  '+ this.messagepop +'  name is already taken'])
          } else {
            console.log('RugTypeArr else====>', this.BreedTypeArr.includes(this.formdata))
            if (this.formdata != '') {
              this.RugTypeArr.push(this.formdata)
              console.log('RugTypeArr', this.RugTypeArr)
              this.updateRugtypeUseFunc(this.RugTypeArr, 'Type')
            }
          }
        }
        else if (this.contentname == 'Weather') {
          this.firebaseServ.showSpinner();
          if (this.RugWeatherArr.includes(this.formdata)) {
            console.log('RugWeatherArr Exists====>', this.RugWeatherArr.includes(this.formdata))
            this.firebaseServ.hideSpinner();
            this.formdata='';
            this.firebaseServ.toastErr(['This  '+ this.messagepop +'  name is already taken'])
          } else {
            console.log('RugWeatherArr else====>', this.RugWeatherArr.includes(this.formdata))
            if (this.formdata != '') {
              this.RugWeatherArr.push(this.formdata)
              console.log('RugWeatherArr', this.RugWeatherArr)
              this.updateRugtypeUseFunc(this.RugWeatherArr, 'Weather')
            }
          }
        }
        else if (this.contentname == 'When') {
          this.firebaseServ.showSpinner();
          if (this.RugWhenArr.includes(this.formdata)) {
            console.log('RugWhenArr Exists====>', this.RugWhenArr.includes(this.formdata))
            this.firebaseServ.hideSpinner();
            this.formdata='';
            this.firebaseServ.toastErr(['This  '+ this.messagepop +'  name is already taken'])
          } else {
            console.log('RugWhenArr else====>', this.RugWhenArr.includes(this.formdata))
            if (this.formdata != '') {
              this.RugWhenArr.push(this.formdata)
              console.log('RugWhenArr', this.RugWhenArr)
              this.updateRugtypeUseFunc(this.RugWhenArr, 'When')
            }
          }
        }
      }
    })
  }

  updateRugtypeUseFunc(newArr, condition) {
    this.firebaseServ.hideSpinner();
    console.log('ADD==>', newArr, condition)
    this.firebaseServ.addRugtypesFunc(newArr, condition).then(res => {
      console.log(res)
      this.firebaseServ.hideSpinner();
      this.firebaseServ.showSuccess('Your changes has been added successfully.')

      this.formdata = '';
    }).catch(err => {

      this.firebaseServ.hideSpinner()
      console.log(err)
    })
  }


  AddnewFeedTypeFunc() {
    this.unit=[];
    this.Feed=[];
    var ind = this.FeedTypeArr.findIndex((x) => x == this.addmachineForm.value.feedtype);
    console.log(ind, this.FeedTypeArr[5], this.addmachineForm.value.feedtype)
    if (ind == -1) {

      Swal.fire({
        title: 'Are you sure?',
        text: "You want to add this " + this.messagepop + " name",
        type: 'question',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes'
      }).then((result) => {
        if (result.value) {

          let data = this.addmachineForm.value;
          // console.log('formdata==>', data, data.nozzles)
          let doc = data.feedtype;


          // ************ Array for feed and unit type *************
          data.nozzles.forEach((ele) => {
            this.Feed.push(ele.feedname)
          })
          data.unitname.forEach((ele) => {
            
            this.unit.push(ele.unitdata)

          })

          this.dataArray = {
            Feed: this.Feed,
            unit: this.unit
          }
          let findDuplicatesunit = this.unit.filter((item, index) => this.unit.indexOf(item) != index)
          let findDuplicatesfeed = this.Feed.filter((item, index) => this.Feed.indexOf(item) != index)
          
              if(findDuplicatesunit.length!=0 || findDuplicatesfeed.length!=0){
               
                 return this.firebaseServ.toastErr('Please do not repeat same feed/unit name')
              }
          else{
 
          // form array creating a feed type data send to firebase
          firebase.firestore().collection('FeedType').doc(doc).set(this.dataArray).then(result => {
            console.log(result);
            this.firebaseServ.showSuccess('Your changes has been added successfully.')
            this.addmachineForm.reset();
           this.goviewdropdowndata()
          })

        }
      }


      })
    }
    else {
      this.firebaseServ.toastErr('This FeedType name is already taken')
    }

  }

  AddFeedUnitTypeFunc() {
    Swal.fire({
      title: 'Are you sure?',
      text: "You want to add this " + this.messagepop + " name",
      type: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes'
    }).then((result) => {
      if (result.value) {
        this.firebaseServ.showSpinner();
        if (this.FeedUnitArry.includes(this.formdata)) {
          console.log('FeedUnitArry Exists====>', this.FeedUnitArry.includes(this.formdata))
          this.firebaseServ.hideSpinner();
          this.formdata='';
          this.firebaseServ.toastErr(['This  '+ this.messagepop +'  name is already taken'])
        } else {
          console.log('FeedUnitArry else====>', this.FeedUnitArry.includes(this.formdata))
          if (this.formdata != '') {
            this.FeedUnitArry.push(this.formdata)
            console.log('FeedUnitArry', this.FeedUnitArry)
            this.updateFeedUnitUseFunc(this.FeedUnitArry)
          }
        }
      }
    })
  }
  updateFeedUnitUseFunc(newArr) {
    console.log('FEEDTYPE', this.contentname, this.docname, newArr)
    this.firebaseServ.addSubFeedType(this.docname, this.section, newArr).then(res => {
      console.log(res)
      this.firebaseServ.hideSpinner();
      this.firebaseServ.showSuccess('Your changes has been added successfully.')

      this.formdata = '';
    }).catch(err => {
      this.firebaseServ.hideSpinner()
      console.log(err)
    })
  }



  showAlertFunc() {
    Swal.fire({
      title: 'Are you sure?',
      text: "You want to add this brand.",
      type: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes'
    }).then((result) => {
      if (result.value) {
        Swal.fire(
          'Success!',
          'Your changes has been added successfully.',
          'success'
        )
      }
    })
  }


  // ********Go to 
  goSubfeeddata() {
    this.router.navigate(['/setting/view-feed-setting/' + this.contentname], {
      queryParams: { value:this.section , type: this.docname  }
    })
  }

  goviewdropdowndata(){
    this.router.navigate(['/setting/viewsetting/id'], {
      queryParams: { value: this.contentname, section: this.section }
    })

  }
}
