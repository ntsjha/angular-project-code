import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { ServiceService } from 'src/app/service/service.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { IMyDpOptions, IMyDateModel } from 'mydatepicker';
import { DatePipe } from '@angular/common';
import { AngularCsv } from 'angular7-csv/dist/Angular-csv';
declare var $: any;

@Component({
  selector: 'app-manage-customers',
  templateUrl: './manage-customers.component.html',
  styleUrls: ['./manage-customers.component.css']
})
export class ManageCustomersComponent implements OnInit {

  filterFunction: FormGroup;
  accountToTransfer: any;
  toDateInTimestamp: any = 0;
  fromDateInTimestamp: any = 0;
  getCustomer: any = [];
  total: any;
  page: any = 0;
  accountAlreadyTaken: boolean = false;
  p: any;
  transferAccount: FormGroup;
  google: any = { one: '', two: '', three: '', four: '', five: '', six: '' };
  tradingfee: any;
  public fromPickerOptions: IMyDpOptions = {
    disableSince: { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() },
    dateFormat: 'dd/mm/yyyy',
  };

  public toPickerOptions: IMyDpOptions = {
    disableSince: { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() },
    dateFormat: 'dd/mm/yyyy',
  };

  csvCustomerOptions = {
    fieldSeparator: ',',
    quoteStrings: '"',
    decimalseparator: '.',
    showLabels: true,
    showTitle: true,
    title: 'Customer List :',
    useBom: true,
    noDownload: false,
    headers: ['ID', 'Name', 'Email', 'phone', 'Type of Customer', 'Created By', 'Updated At', 'Updated By', 'Status', 'KYC Status', '2FA']
  };

  constructor(private service: ServiceService, private spinner: NgxSpinnerService, private router: Router, public datepipe: DatePipe) {
    this.filterFunction = new FormGroup({
      search: new FormControl(null),
      status: new FormControl(null),
      kycStatus: new FormControl(null),
      fromDate: new FormControl(null),
      toDate: new FormControl(null),
    });

    this.transferAccount = new FormGroup({
      newAccount: new FormControl(null),
    });
  }
  convertFormat(time) {
    if (time != null) {
      return this.datepipe.transform(time, 'MM/dd/yyy, hh:mm a');
    }
  }


  fromDateChanged(event: IMyDateModel) {
    this.fromDateInTimestamp = event.epoc;
    if (event.epoc === 0) {
      const date = new Date();
      this.filterFunction.patchValue({
        fromDate: {
          date: {
            year: date.getFullYear(),
            month: date.getMonth() + 1,
            day: date.getDate()
          }
        }
      });
      this.toPickerOptions = {
        disableUntil: event.date
      };
    } else {
      this.filterFunction.patchValue({
        fromDate: event.date
      });
      this.toPickerOptions = {
        disableUntil: event.date
      };
    }
  }

  toDateChanged(event: IMyDateModel) {
    this.toDateInTimestamp = event.epoc;
    if (event.epoc === 0) {
      const date = new Date();
      this.filterFunction.patchValue({
        toDate: {
          date: {
            year: date.getFullYear(),
            month: date.getMonth() + 1,
            day: date.getDate()
          }
        }
      });
      this.fromPickerOptions = {
        disableSince: {
          year: date.getFullYear(),
          month: date.getMonth() + 1,
          day: date.getDate()
        }
      };
    } else {
      this.filterFunction.patchValue({
        toDate: event.date
      });
      this.fromPickerOptions = {
        disableSince: event.date
      };

    }

  }

  exportData() {
    if (this.getCustomer.length > 0) {
      let data = [];
      this.getCustomer.forEach((ele) => {
        data.push({
          ID: ele.customerId,
          name: ele.firstName,
          email: ele.email,
          phone: ele.phoneNo,
          typeofCustomer: ele.userType,
          createdBy: ele.createdBy,
          createdAt: (ele.createdAt != null) ? this.convertFormat(ele.createdAt) : '',
          updatedBy: ele.updatedBy,
          status: ele.status,
          kycStatus: ele.kycStatus,
          twoFa: ele.twoFaType,

        });
      });
      new AngularCsv(data, 'GMO Customer Report', this.csvCustomerOptions);
    }
  }

  ngOnInit() {
    this.getCustomerList();
    window.scrollTo(0, 0);
  }

  getCustomerList() {
    this.getCustomer = [];
    this.total = 0;
    this.spinner.show();
    let data = {
      page: this.service.encrypt(String(this.page)),
      pageSize: this.service.encrypt('10'),
      search: (this.filterFunction.value.search != null) ? this.service.encrypt(this.filterFunction.value.search.trim()) : null,
      fromDate: (this.fromDateInTimestamp != 0) ? this.service.encrypt(this.fromDateInTimestamp) : null,
      status: (this.filterFunction.value.status != null) ? this.service.encrypt(this.filterFunction.value.status) : null,
      kycStatus: (this.filterFunction.value.kycStatus != null) ? this.service.encrypt(this.filterFunction.value.kycStatus) : null,
      toDate: (this.toDateInTimestamp != 0) ? this.service.encrypt(this.toDateInTimestamp) : null,
    };
    this.service.postMethod('account/admin/search-and-filter-customer', data, 1).subscribe((response: any) => {
      let responseData = this.service.decrypt(response.data);
      responseData = JSON.parse(responseData);
      this.spinner.hide();
      if (responseData.status == 568) {
        this.getCustomer = responseData.data.response;
        this.getCustomer.forEach(element => {
          if(element.updatedBy == null) {
            element.updatedAt = null;
          }
        });
        this.total = responseData.data.size;
      }
    }, (error) => {
      this.spinner.hide();
    });
  }

  deleteCustomer(customer) {
    let data = {};
    this.service.postMethod('account/admin/search-and-filter-customer', data, 1).subscribe((response: any) => {
    });
  }

  disableCustomer(customer) {
  }

  changePage(page) {
    this.p = page;
    this.page = page - 1;
    this.getCustomerList();
  }

  viewCustomer(customer) {
    this.router.navigate(['/customers-detail/' + customer.userId]);
  }

  transferAcc(customer) {
    this.accountToTransfer = customer;
    $('#transferAccount').modal('show');
  }

  checkForTransfer(account) {
    this.service.postMethod('account/admin/user-management/change-customer-email?customerId=' + this.service.encrypt(account.userId) + '&email=' + this.service.encrypt(this.transferAccount.value.newAccount), {}, 1)
      .subscribe((response) => {
        let res = JSON.parse(this.service.decrypt(response.data));
        if (res.status == 569) {
          this.accountAlreadyTaken = false;
          this.getCustomerList();
        }
        this.transferAccount.reset();
      }, (error) => {
        this.accountAlreadyTaken = true;
        this.transferAccount.reset();
      });
  }




  resetFilterFunction() {
    this.filterFunction.patchValue({
      search: null,
      kycStatus: null,
      status: null,
    });
    this.fromDateInTimestamp = 0;
    this.toDateInTimestamp = 0;
    this.p = 1;
    this.page = 0;
    this.fromPickerOptions = {
      disableSince: { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() + 1 },
      disableUntil: { year: 0, month: 0, day: 0 }
    };
    this.toPickerOptions = {
      disableSince: { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() + 1 },
      disableUntil: { year: 0, month: 0, day: 0 }
    };
    this.getCustomerList();

  }

  onKey(event) {
    if (event.key === 'Backspace') {
      event.target.value = '';
    } else {
      if (event.keyCode >= 48 && event.keyCode <= 57) {
        if (event.target.value.trim() !== '') {
        } else {
          event.target.value = '';
        }
      } else {
        event.target.value = '';
      }
    }
  }
}


