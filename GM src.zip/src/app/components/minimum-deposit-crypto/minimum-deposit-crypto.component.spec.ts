import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MinimumDepositCryptoComponent } from './minimum-deposit-crypto.component';

describe('MinimumDepositCryptoComponent', () => {
  let component: MinimumDepositCryptoComponent;
  let fixture: ComponentFixture<MinimumDepositCryptoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MinimumDepositCryptoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MinimumDepositCryptoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
