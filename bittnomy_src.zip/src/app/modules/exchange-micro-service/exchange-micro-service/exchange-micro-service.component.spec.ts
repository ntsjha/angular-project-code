import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExchangeMicroServiceComponent } from './exchange-micro-service.component';

describe('ExchangeMicroServiceComponent', () => {
  let component: ExchangeMicroServiceComponent;
  let fixture: ComponentFixture<ExchangeMicroServiceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExchangeMicroServiceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExchangeMicroServiceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
