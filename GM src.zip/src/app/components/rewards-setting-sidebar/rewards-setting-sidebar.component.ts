import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { DatePipe } from '@angular/common';
import { ServiceService } from 'src/app/service/service.service';

@Component({
  selector: 'app-rewards-setting-sidebar',
  templateUrl: './rewards-setting-sidebar.component.html',
  styleUrls: ['./rewards-setting-sidebar.component.css']
})
export class RewardsSettingSidebarComponent implements OnInit {
  getRewardsDefault: any;
  selectedId: any;
  getRewardsettingDefault: any = [];

  constructor(
    private service: ServiceService,
    public datepipe: DatePipe,
    private spinner: NgxSpinnerService,
    private route: Router
  ) { }

  ngOnInit() {
    this.getRewardDefault();
    window.scrollTo(0, 0);
  }

  goToUpdate() {
    if (this.service.sideMenuArr.includes('updateDefaultRewardPoints')) {
      this.route.navigate(['/update-reward-setting']);
    }
  }



  getRewardDefault() {
    this.spinner.show();
    this.service.getMethod('rewards/common-permit/get-default-reward-setting', 1).subscribe((response: any) => {
      this.spinner.hide();
      if (response.status === 1328) {
        this.getRewardsDefault = response.data.promotionData;
        this.getRewardsettingDefault = response.data.defaultRewardData;
      }
    }, (error) => {
      this.spinner.hide();
    });
    this.spinner.hide();
  }
}
