import { Component, OnInit } from '@angular/core';
import { ServerService } from '../../../service/server.service';
import { AppComponent } from '../../../app.component';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';

declare const TradingView: any;
declare const Datafeeds: any;

@Component({
    selector: 'app-dashboard',
    templateUrl: './dashboard.component.html',
    styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
    coinArr = [];
    user = {currCoinId:"", currCoinBal:"", totalBal:""};
    coinPair = "";
    recentTxnArr = [];

    constructor(private server: ServerService, private appC: AppComponent, private spinnerService: Ng4LoadingSpinnerService) { }

    ngOnInit() {
        this.getAllCoins();
        this.getRecentTransactions();
    }

    /** Function to get all coin list */
    getAllCoins() {
        // let data = {
        //     "eventExternal" : {
        //         "name" : "request_get_coin_list",
        //         "key" : "mykey"
        //     },
        //     "transferObjectMap" : {
        //         "loginToken": localStorage.getItem("token")
        //     }
        // }
        this.spinnerService.show();
        this.server.getApi('wallet/coin/get-coin-list', 0).subscribe(  (succ) => {
            this.spinnerService.hide();
            if(succ.body.status == 200) {
                this.coinArr = succ.body.data.filter((x) => x.coinType == "crypto");
                if(this.coinArr.length) {
                    this.user.currCoinId = this.coinArr[0].coinId;
                    // this.user.currCoinBal = this.coinArr[0].marketPriceInUsd;
                    this.coinPair = "EUR/"+this.coinArr[0].coinShortName;
                    this.showTradingChart();
                    this.getBalanceInEURO();
                    this.getCoinWalletBalance(this.coinArr[0].coinShortName); 
                }
            }
        }, (err) => {
            this.spinnerService.hide();
        });
    }
    getCoinWalletBalance(coin) {
            
            this.spinnerService.show();
            this.server.getApi("wallet/wallet/get-balance?coinName="+coin, localStorage.getItem('token')).subscribe((succ) => {
                this.spinnerService.hide();
                if (succ.status == 200) {
                let getdata=  succ.body.data?succ.body.data:'';
                this.user.currCoinBal=getdata.walletBalance?getdata.walletBalance:'';
                    
                } else if (succ.status == 403) {
                    // this.header.tokenExpire();
                } else {
                }
            }, (err) => {
                this.spinnerService.hide();
            });
        
    }


    /** Function to draw trading view chart */
    showTradingChart() {
        new TradingView.widget({
            fullscreen: true,
            symbol: this.coinPair,
            interval: 'D',
            container_id: "tradingview_cb72b",
            // datafeed: new Datafeeds.UDFCompatibleDatafeed("http://182.76.185.46:8082/LCXChart/exchange-feed",60000),
            datafeed: new Datafeeds.UDFCompatibleDatafeed(this.server.chartUrl,60000),
            //datafeed: new Datafeeds.UDFCompatibleDatafeed("http://35.178.242.39:8080/LCXChart/exchange-feed",60000),
            library_path: "assets/lib/charting_library/",
            locale: "en",
            drawings_access: { type: 'black', tools: [{ name: "Regression Trend" }] },
            disabled_features: ["use_localstorage_for_settings"],
            overrides: {
                "paneProperties.background": "#222222",
                "paneProperties.vertGridProperties.color": "#454545",
                "paneProperties.horzGridProperties.color": "#454545",
                "symbolWatermarkProperties.transparency": 90,
                "scalesProperties.textColor": "#AAA"
            }
        });
    }

    /** Function for coin change */
    coinChangeFunc() {
        // this.user.currCoinBal = this.coinArr.filter((x) => x.coinId == this.user.currCoinId)[0].balance;
        let currCoin = this.coinArr.filter((x) => x.coinId == this.user.currCoinId)[0].coinShortName;
        this.coinPair = "EUR/"+currCoin;
        this.showTradingChart();
        this.getBalanceInEURO();
        this.getCoinWalletBalance(currCoin)
    }

    /** Function to get balance in euro of selected coin */
    getBalanceInEURO() {
        let data = {
            "eventExternal": {
                "name": "request_wallet_balance_in_fiat",
                "key": "mykey"
            },
            "transferObjectMap": {
                "gatewayrequest": {
                    "baseCurrency": 17,
                    "executableCurrency": this.user.currCoinId
                },
                "loginToken": localStorage.getItem("token"),
                "coinId": this.user.currCoinId
            }
        }
        this.server.post('',data).subscribe((succ) => {
            if(succ.transferObjectMap.statusCode == 200) {
                this.user.totalBal = succ.transferObjectMap.fiatPrice;
            }
        }, (err) => {
        });
    }

    /** Function to get recent transaction from api */
    getRecentTransactions() {
        this.recentTxnArr = [];
        let data = {
            "eventExternal" : {
                "name" : "request_get_last_ten_transaction",
                "key" : "mykey"
            },
            "transferObjectMap" : {
                "gatewayrequest" : {
                    "loginToken": localStorage.getItem("token")
                }
            }
        }
        this.server.post('',data).subscribe((succ) => {
            if(succ.transferObjectMap.statusCode == 200) {
                this.recentTxnArr = succ.transferObjectMap.transactionList;
            }
        }, (err) => {
        });
    }
}
