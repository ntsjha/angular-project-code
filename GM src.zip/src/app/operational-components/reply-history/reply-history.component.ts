import { Component, OnInit } from '@angular/core';
import { ServiceService } from 'src/app/service/service.service';
declare var $: any;
@Component({
    selector: 'app-reply-history',
    templateUrl: './reply-history.component.html',
    styleUrls: ['./reply-history.component.css']
})
export class ReplyHistoryComponent implements OnInit {
    id: string;
    detailObj: any = {};
    error: boolean = false;
    fileData: any;
    profileImage: any;
    message: string;
    obj: any = {};

    constructor(public server: ServiceService) { }

    ngOnInit() {
        window.scrollTo(0, 0);
        this.callByUrl();
    }

    callByUrl() {
        let url = window.location.href;
        let arr = url.split('/');
        this.id = arr[arr.length - 1];
        this.getDetails();
    }

    getDetails() {
        this.server.getMethod(`static/common-permit/get-inquiry-detail?contactUsId=${encodeURIComponent(this.server.encrypt(this.id))}`, 1).subscribe((res:any) => {
            if (res.data) {
                this.detailObj = res.data;
            }
        });
    }

    handleFileInput(event) {
        this.error = false;
        var self = this;
        if (event.target.files && event.target.files[0]) {
            var type = event.target.files[0].type;
            if (type === 'image/png' || type === 'image/jpg' || type === 'image/jpeg') {
                this.fileData = event.target.files[0];
                if (this.fileData.size < 5000000) {
                    this.uploadSelfiImage();
                } else {
                    this.error = true;
                    this.message = "Size exceeded maximum limit(5 mb)";
                }
                var reader = new FileReader();
                reader.onload = (e) => {
                    self.profileImage = e.target['result'];
                };
            } else {
                this.message = "Select only jpg,jpeg and png file.";
                this.error = true;
                self.profileImage = '';
                self.fileData = "";
            }
        }
    }

    uploadSelfiImage() {
        let formdata = new FormData();
        formdata.append('file', this.fileData);
        if (navigator.onLine) {
            this.server.uploadMethod('account/uploadFile', formdata).subscribe((succ) => {
                if (succ.fileName) {
                    this.profileImage = succ.fileName;
                }
            }, error => {
            });
        }
    }

    getreplyMessage() {
    }

    sendMessage() {
        if (this.obj.message) {
            let req = {
                'message': this.obj.message
            };
            if (this.fileData) {
                let formdata = new FormData();
                formdata.append('file', this.fileData);
                req['data'] = formdata;
            }
            this.server.postMethod('support/send-enquiry-reply', req, 1).subscribe((res) => {
                if (res) {
                    this.obj.message = '';
                    this.profileImage = '';
                    $("#fileControl").val('');
                }

            });
        }
    }

}
