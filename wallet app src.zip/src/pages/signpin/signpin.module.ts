import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SignpinPage } from './signpin';

@NgModule({
  declarations: [
    SignpinPage,
  ],
  imports: [
    IonicPageModule.forChild(SignpinPage),
  ],
})
export class SignpinPageModule {}
