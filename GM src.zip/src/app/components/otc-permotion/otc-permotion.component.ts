import { Component, OnInit, NgZone } from '@angular/core';
import { ServiceService } from 'src/app/service/service.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { AppComponent } from 'src/app/app.component';
import { CookieService } from 'ngx-cookie-service';

declare var $: any;
@Component({
  selector: 'app-otc-permotion',
  templateUrl: './otc-permotion.component.html',
  styleUrls: ['./otc-permotion.component.css']
})
export class OTCPermotionComponent implements OnInit {

  modalType: any;
  promotionList: any = [];
  paginationData: any = {currPage: 1, total: 0, limit: 10};
  selectedData: any;
  selectedIndex: any;
  subscription: any;
  todayDate: any = new Date().toISOString();
  userIp: any;

  constructor(
    private service: ServiceService,
    private spinner: NgxSpinnerService,
    private zone: NgZone,
    private appC: AppComponent,
    private cookie: CookieService
  ) {
    this.subscription = this.service.authVerify.subscribe(val => {
      if (val == 'promotion-mgmt') {
        this.deletePromotion();
        this.service.authVerify.next('false');
      }
    });
  }

  ngOnInit() {
    this.getPromotionList();
    window.scrollTo(0, 0);
    this.userIp = (this.cookie.get('userInfo')) ? JSON.parse(this.cookie.get('userInfo')) : this.service.initialUserInfo;
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  getPromotionList() {
    this.spinner.show();
    this.service.getMethod(`rewards/common-permit/list-of-promotion?languageName=${encodeURIComponent(this.service.encrypt('en'))}&page=${this.paginationData.currPage - 1}&pageSize=${this.paginationData.limit}`, 1).subscribe((success: any) => {
      this.spinner.hide();
      if (success.status === 1337) {
        this.promotionList = success.data.data;
        this.paginationData.total = success.data.size;
      } else {
        this.promotionList = [];
      }
    }, error => {
      this.spinner.hide();
      this.promotionList = [];
    });
  }

  changePage(event) {
    this.paginationData.currPage = event;
    this.getPromotionList();
  }

  openModal(data, index, whichModal) {
    this.selectedData = data;
    this.modalType = whichModal;
    this.selectedIndex = index;
    $('#unPublishdeleteModal').modal({ backdrop: 'static', keyboard: false });
  }

  yesModal() {
    if (this.modalType === 'delete') {
      this.verifyGoogleAuth();
    } else if (this.modalType === 'enable' || this.modalType === 'disable') {
      this.changeStatus();
    }
  }


  /** Function to verify google authentication */
  verifyGoogleAuth() {
    $('#unPublishdeleteModal').modal('hide');
    this.appC.google = { one: '', two: '', three: '', four: '', five: '', six: '' };
    this.appC.response = { 'message': '' };
    this.service.googleAuthCalledFrom = 'promotion-mgmt';
    $('#google-auth-modal').modal({ keyboard: false, backdrop: 'static' });

  }

  deletePromotion() {
    this.spinner.show();
    this.service.getMethod(`rewards/marketing/delete-promotion?promotionId=${this.selectedData.rewardPromotionContentId}`, 1).subscribe((success: any) => {
      this.spinner.hide();
      this.getPromotionList();
    }, error => {
      this.spinner.hide();
    });
  }

  changeStatus() {
    this.spinner.show();
    this.service.getMethod(`rewards/marketing/enable-disable-promotion?promotionId=${this.selectedData.rewardPromotionContentId}&languageName='en'&ipAddress=${this.userIp.ip}&location=${this.userIp.city},${this.userIp.country_name}`, 1).subscribe((succ: any) => {
      this.spinner.hide();
      if (succ.status === 1357 || succ.status === 1356) {
        $('#unPublishdeleteModal').modal('hide');
        this.getPromotionList();
      } else if(succ.status === 1394) {
        $('#statusModal').modal('show');
      }
    }, error => {
      this.spinner.hide();
    });
  }

  noModal() {
    this.zone.run(() => {
      if(this.modalType == 'enable') {
        $('#status' + this.selectedIndex).toggleClass('active');
      } else if(this.modalType == 'disable') {
        $('#status' + this.selectedIndex).removeClass('active');
      }
      
    });
  }
}
