import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { JobTranslateListComponent } from './job-translate-list.component';

describe('JobTranslateListComponent', () => {
  let component: JobTranslateListComponent;
  let fixture: ComponentFixture<JobTranslateListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ JobTranslateListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(JobTranslateListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
