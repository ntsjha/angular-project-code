import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HeaderComponent } from './modules/header/header/header.component';
import { HomeComponent } from './modules/home/home/home.component';
import { LoginComponent } from './modules/login/login/login.component';
import { SignupComponent } from './modules/signup/signup/signup.component';
import { ForgetpasswordModule } from './modules/forgetpassword/forgetpassword.module';
import { ForgetpasswordComponent } from './modules/forgetpassword/forgetpassword/forgetpassword.component';
import { WalletComponent } from './modules/wallet/wallet/wallet.component';
import { TermsComponent } from './modules/terms/terms/terms.component';
import { TwofaComponent } from './modules/twofa/twofa/twofa.component';
import { PrivacypolicyComponent } from './modules/privacypolicy/privacypolicy/privacypolicy.component';
import { HomeModule } from './modules/home/home.module';
import { SupportComponent } from './modules/support/support/support.component';
import { AboutusComponent } from './modules/aboutus/aboutus/aboutus.component';
import { DashboardComponent } from './modules/dashboard/dashboard/dashboard.component';
import { ExchangeComponent } from './modules/exchange/exchange/exchange.component';
import { ProfileComponent } from './modules/profile/profile/profile.component';
import { EditprofileComponent } from './modules/editprofile/editprofile/editprofile.component';
import { ResetpasswordComponent } from './modules/resetpassword/resetpassword/resetpassword.component';
import { DeposithistoryComponent } from './modules/deposithistory/deposithistory/deposithistory.component';
import { EmailverifyComponent } from './modules/emailverify/emailverify/emailverify.component';
import { WithdrawhistoryComponent } from './modules/withdrawhistory/withdrawhistory/withdrawhistory.component';
import { ChangepasswordComponent } from './modules/changepassword/changepassword/changepassword.component';
import { FaqComponent } from './modules/faq/faq/faq.component';
import { FeesFeatureComponent } from './modules/fees-feature/fees-feature/fees-feature.component';
import { LegalComplianceComponent } from './modules/legal-compliance/legal-compliance/legal-compliance.component';
import { ContactUsComponent } from './modules/contact-us/contact-us/contact-us.component';
import { ExHeaderComponent } from './modules/ex-header/ex-header/ex-header.component';
import { PagenotfoundComponent } from './modules/pagenotfound/pagenotfound/pagenotfound.component';
import { KycComponent } from './modules/kyc/kyc/kyc.component';
import { AccountComponent } from './modules/account/account/account.component';
import { FiathistoryComponent } from './modules/fiathistory/fiathistory/fiathistory.component';
import { BuysellComponent } from './modules/buysell/buysell/buysell.component';
import { KycamlComponent } from './modules/kycaml/kycaml/kycaml.component';
import { WithdrawverifyComponent } from './modules/withdrawverify/withdrawverify/withdrawverify.component';
import { HowitworksComponent } from './modules/howitworks/howitworks/howitworks.component';
import { AirdropComponent } from './modules/airdrop/airdrop/airdrop.component';
import { OtcdeskComponent } from './modules/otcdesk/otcdesk/otcdesk.component';
import { RequestotcquoteComponent } from './modules/requestotcquote/requestotcquote/requestotcquote.component';
import { SuggestionComponent } from './modules/suggestion/suggestion/suggestion.component';
import { AddsuggestionComponent } from './modules/addsuggestion/addsuggestion/addsuggestion.component';
import { ExchangeMicroServiceComponent } from './modules/exchange-micro-service/exchange-micro-service.component';

const routes: Routes = [
    {
        path: '', redirectTo: 'header', pathMatch: 'full'
    },{ 
        path: 'header', component: HeaderComponent, 
        children: [              
            { path: '', component: HomeComponent},
            { path: 'home', component: HomeComponent},
            { path: 'login', component: LoginComponent},
            { path: 'signup', component: SignupComponent},
            { path: 'forgotpassword', component: ForgetpasswordComponent},
            { path: 'wallet', component:WalletComponent},
            { path: 'terms', component:TermsComponent},
            { path: 'twofa/:token', component:TwofaComponent},
            { path: 'privacy', component:PrivacypolicyComponent},
            { path: 'support', component:SupportComponent},
            { path: 'aboutus', component:AboutusComponent},
            { path: 'profile', component:ProfileComponent},
            { path: 'dashboard', component:DashboardComponent},
            { path: 'edit', component:EditprofileComponent},
            { path: 'reset', component:ResetpasswordComponent},
            { path: 'deposit', component:DeposithistoryComponent},
            { path: 'verify/:token', component:EmailverifyComponent},
            { path: 'withdraw', component:WithdrawhistoryComponent},
            { path: 'change', component:ChangepasswordComponent},
            { path: 'faq', component:FaqComponent},
            { path: 'fees', component:FeesFeatureComponent},
            { path: 'legal', component:LegalComplianceComponent},
            { path: 'contact', component:ContactUsComponent},
            { path: 'kyc', component:KycComponent},
            { path: 'account', component:AccountComponent},
            { path: 'fiathistory', component:FiathistoryComponent},
            { path: 'buySell', component:BuysellComponent},
            { path: 'kycAml', component:KycamlComponent},
            { path: 'withdrawverify/:token', component:WithdrawverifyComponent},
            { path: 'howitworks', component:HowitworksComponent},
            { path: 'airdrop', component:AirdropComponent},
            { path: 'otcdesk', component:OtcdeskComponent},
            { path: 'reqOtcQuote', component:RequestotcquoteComponent},
            { path: 'suggestion', component:SuggestionComponent},
            { path: 'addsuggestion', component:AddsuggestionComponent},
            { path: '**', component: PagenotfoundComponent}            
        ],
    },{ 
        path: 'exHeader', component: ExHeaderComponent,
            children: [
                { path: '', redirectTo: 'exchange', pathMatch: 'full'},
                { path: 'exchange', component: ExchangeComponent },
                // { path: 'exchange', component: ExchangeMicroServiceComponent },
                { path: '**', component: PagenotfoundComponent}              
            ]
    },{ 
        path: '**', component: PagenotfoundComponent
    }
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class AppRoutingModule { }

export const RoutingModule = [HomeModule]