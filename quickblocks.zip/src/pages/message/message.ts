import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { QBService } from '../../providers/qb/qb';

declare var QB: any;

/**
 * Generated class for the MessagePage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-message',
  templateUrl: 'message.html',
})
export class MessagePage {
  contacts: {};
  chatData: Array<any>;
  message: String;
  selectedUser: any;
  session: any;
  dialogId: Number;
  userDetails: any;
  messageObj: any;

  MessagesFromUsers = (userId, msg) => {
    this.messageObj = {
      from: userId,
      body: msg.body
    };
    this.qbService._notificationObj.emit(this.messageObj);
  }
  data: any;
  constructor(private qbService: QBService,public navCtrl: NavController, public navParams: NavParams) {
  }
 /**
   * On message send
   *
   * @param userId: To UserId
   * @param message: composed message
   */

  onEnter(userId, message) {
    QB.chat.send(userId, {
      type: 'chat',
      body: message,
      extension: { save_to_history: 1 }
    });
    this.chatData.push({ 'message': message, 'sender_id': this.session.user_id });
    this.message = '';
  }
  ngOnInit()
   {
    this.data=this.qbService.data;
    console.log(this.qbService.data);
    this.dialogId= this.qbService.data_id;
    console.log( this.dialogId);
      }
  
      retriveMessage() {
    this.qbService.retriveMessage(this.session.token, this.dialogId)
      .subscribe((res: any) => {
        this.chatData = res.items;
      });
  }
  
  

}
