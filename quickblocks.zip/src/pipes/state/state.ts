import { Pipe, PipeTransform } from '@angular/core';

/**
 * Generated class for the StatePipe pipe.
 *
 * See https://angular.io/api/core/Pipe for more info on Angular Pipes.
 */
@Pipe({
  name: 'state',
})
export class StatePipe implements PipeTransform {
  /**
   * Takes a value and makes it lowercase.
   */
  // transform(value: string, ...args) {
  //   return value.toLowerCase();
  // }
  public states: Object = {
    'WA':   'Western Australia',
    'SA':   'South Australia',
    'NT':   'Northern Territory',
    'QLD':  'Queensland',
    'TAS':  'Tasmania',
    'NSW':  'New South Wales',
    'VIC':  'Victoria',
    'ACT':  'Australian Capital Territory'
  };
  transform(value: string, ...args) {
    // This is our catch for data that hasn't interpolated
    // from its source yet, a basic async fix.
    if(value == null) return;
// Otherwise, lookup the state name from the acronym
    if(this.states[value]){
      return this.states[value];
    } else {
      return value;
    }
  }
}
