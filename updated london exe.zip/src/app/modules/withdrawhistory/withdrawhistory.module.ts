import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WithdrawhistoryComponent } from './withdrawhistory/withdrawhistory.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [WithdrawhistoryComponent]
})
export class WithdrawhistoryModule { }
