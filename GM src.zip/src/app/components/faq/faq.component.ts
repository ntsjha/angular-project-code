import { Component, OnInit } from '@angular/core';
import { ServiceService } from 'src/app/service/service.service';
import { ActivatedRoute, Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';

declare var $: any;
@Component({
  selector: 'app-faq',
  templateUrl: './faq.component.html',
  styleUrls: ['./faq.component.css']
})
export class FAQComponent implements OnInit {
  search: string;
  topic: string;
  status: string;
  modalType: any;
  modeOfAction: any;
  canEdit: boolean;
  canAdd: boolean;
  canView: boolean;
  topicArr: any;
  currentUser: any;
  selectedLanguage: string;
  translation: boolean;
  languageName: string;
  currentId: string;
  page: any = 0;
  pageSize: any = 0;
  total: any;
  p: any = 1;

  constructor(private service: ServiceService, private activatedRoutes: ActivatedRoute, private router: Router, private spinner: NgxSpinnerService) { }
  faqArr: any;
  ngOnInit() {
    window.scrollTo(0, 0);
    this.activatedRoutes.params.subscribe((data) => {
      this.modeOfAction = data.id1;
      this.languageSelection(data.id2);
    });
    this.getFAQ();
    this.getFaqTopic();
    this.modeSelection();
    this.service.currentUserInfo.subscribe((response) => {
      this.currentUser = response;
    });
  }
  addTopic() {
    this.router.navigate(['edit-topic/Add/en/no']);
  }

  modeSelection() {
    if (this.modeOfAction === 'edit') {
      this.canEdit = true;
      this.canAdd = false;
      this.canView = false;
    } else if (this.modeOfAction === 'add') {
      this.canEdit = false;
      this.canAdd = true;
      this.canView = false;
    } else {
      this.canEdit = false;
      this.canAdd = false;
      this.canView = true;
    }
  }
  resetFilter() {
    this.search = null;
    this.status = null;
    this.topic = null;
    this.p = 1;
    this.page = 0;
    this.getFAQ();
  }

  languageSelection(lang) {
    if (lang === 'th') {
      this.selectedLanguage = 'th';
      this.translation = true;
      this.languageName = 'Thai';
    } else if (lang === 'ch') {
      this.selectedLanguage = 'ch';
      this.translation = true;
      this.languageName = 'Chinese';
    } else {
      this.selectedLanguage = 'en';
      this.translation = false;
      this.languageName = 'English';
    }
  }


  getFAQ() {
    this.spinner.show();
    const obj = {
      page: this.service.encrypt(this.page),
      pageSize: this.service.encrypt('10'),
      search: (this.search != null) ? this.service.encrypt(this.search.trim()) : null,
      status: (this.status != null) ? this.service.encrypt(this.status) : null,
      topicName: (this.topic != null) ? this.service.encrypt(this.topic.trim()) : null,
    };
    this.service.postMethod('static/admin/search-and-filter-faq-content', obj, 1)
      .subscribe((response) => {
        this.spinner.hide();
        if (response.status === 179) {
          this.faqArr = [];
          this.total = 0;
        } else {
          this.faqArr = response.data.list;
          this.total = response.data.size;
          this.faqArr.forEach(element => {
            if(element.updatedBy == null) {
              element.updatedAt = null;
            }
          });
        }
      }, (error) => {
        this.spinner.hide();
      });
  }

  getFaqTopic() {
    const obj = {
      page: this.service.encrypt(this.page),
      pageSize: this.service.encrypt('10'),
      search: null,
      status: null,
    };
    this.service.postMethod('static/admin/search-and-filter-faq-topic', obj, 1)
      .subscribe((response) => {
        this.topicArr = response.data.list;
      });
  }

  publishUnpublish() {
    this.service.postMethod('static/admin/publish-unpublish-faq?faqContentId=' + encodeURIComponent(this.service.encrypt(this.currentId)) + '&ipAddress=' + encodeURIComponent(this.service.encrypt(this.currentUser.ip)) + '&location=' + encodeURIComponent(this.service.encrypt(this.currentUser.city)), {}, 1)
      .subscribe((response) => {
        $('#unPublishdeleteModal').modal('hide');
        this.getFAQ();
      }, (error) => {
        $('#unPublishdeleteModal').modal('hide');
        this.getFAQ();
      });
  }

  deleteThis() {
    this.service.postMethod('static/admin/delete-faq-content?faqContentId=' + encodeURIComponent(this.service.encrypt(this.currentId)) + '&ipAddress=' + encodeURIComponent(this.service.encrypt(this.currentUser.ip)) + '&location=' + encodeURIComponent(this.service.encrypt(this.currentUser.city)), {}, 1)
      .subscribe((response) => {
        $('#unPublishdeleteModal').modal('hide');
        this.getFAQ();
      }, (error) => {
        this.getFAQ();
        $('#unPublishdeleteModal').modal('hide');
      });
  }

  openModal(whichModal, id) {
    this.modalType = whichModal;
    this.currentId = id;
    $('#unPublishdeleteModal').modal({ backdrop: 'static', keyboard: false });
  }

  editFAQ(id) {
    this.router.navigate(['add-edit-faq/Edit/' + this.selectedLanguage + '/' + id]);
  }

  translateFAQ(id) {
    this.router.navigate(['faq-translation/' + id]);
  }

  changePage(page) {
    this.p = page;
    this.page = page - 1;
    this.getFAQ();
  }

  openTopics() {
    this.router.navigate(['/topics']);
  }

  addQuestion() {
    this.router.navigate(['/add-edit-faq/Add/en/no']);
  }

}
