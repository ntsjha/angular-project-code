import { FormGroup, FormControl } from '@angular/forms';
import { ServiceService } from 'src/app/service/service.service';
import { Component, OnInit } from '@angular/core';
import { IMyDpOptions } from 'mydatepicker';
import { NgxSpinnerService } from 'ngx-spinner';

declare var $: any;
@Component({
  selector: 'app-event-management',
  templateUrl: './event-management.component.html',
  styleUrls: ['./event-management.component.css']
})
export class EventManagementComponent implements OnInit {

  modalType: any;
  paginationData: any = {limit: 10, currPage: 1, total: 0};
  eventList: any = [];
  selectedData: any;
  public fromPickerOptions: IMyDpOptions = {
    disableSince: { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() + 1 },
    dateFormat: 'dd/mm/yyyy',
  };
  englishShortCode: any;
  public toPickerOptions: IMyDpOptions = {
    disableSince: { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() + 1 },
    dateFormat: 'dd/mm/yyyy',
  };
  searchForm: FormGroup;
  userData: any;
  errMsg: any = '';

  constructor(
    private service: ServiceService,    
    private spinner: NgxSpinnerService
  ) { }

  ngOnInit() {
    window.scrollTo(0, 0);
    this.englishShortCode = this.service.englishLanguageShortCode;
    this.form();
    this.getUserInfo();
    this.getEventList('reset');
  }

  form() {
    this.searchForm = new FormGroup({
      search   : new FormControl(null),
      eventType: new FormControl(null),
      status   : new FormControl(null),
      fromDate : new FormControl(null),
      toDate   : new FormControl(null),
    });
  }

  getUserInfo() {
    this.service.userInfo.subscribe(success => {
      this.userData = success;
    });
  }

  fromDateChanged(event) {
    if (event.epoc) {
      this.toPickerOptions = {
        disableUntil: { year: new Date(event.epoc * 1000).getFullYear(), month: new Date(event.epoc * 1000).getMonth() + 1, day: new Date(event.epoc * 1000).getDate() - 1 }
      };
    } else {
      this.toPickerOptions = {
        disableUntil: { year: 0, month: 0, day: 0 },
        disableSince: { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() + 1 }
      };
    }
  }

  toDateChanged(event) {
    if (event.epoc) {
      this.fromPickerOptions = {
        disableSince: { year: new Date(event.epoc * 1000).getFullYear(), month: new Date(event.epoc * 1000).getMonth() + 1, day: new Date(event.epoc * 1000).getDate() + 1 }
      };
    } else {
      this.fromPickerOptions = {
        disableSince: { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() + 1 },
        disableUntil: { year: 0, month: 0, day: 0 },
      };
    }
  }

  getEventList(event) {
    
    let apireq;
    this.spinner.show();
    if (event === 'reset') {
      apireq = {
        page       : this.service.encrypt(this.paginationData.currPage),
        pageSize   : this.service.encrypt(this.paginationData.limit),
        search     : null,
        eventStatus: null,
        eventType  : null,
        fromDate   : null,
        toDate     : null
      };
      this.paginationData.currPage = 1;
    } else {
      if (event === 'apply') {
        apireq = {
          page       : this.service.encrypt(this.paginationData.currPage),
          pageSize   : this.service.encrypt(this.paginationData.limit),
          search     : this.searchForm.value.search ? this.service.encrypt(this.searchForm.value.search.trim()) : null,
          eventStatus: this.searchForm.value.status ? this.service.encrypt(this.searchForm.value.status) : null,
          eventType  : this.searchForm.value.eventType ? (this.searchForm.value.eventType !== 'null' ? this.service.encrypt(this.searchForm.value.eventType) : null) : null,
          fromDate   : this.searchForm.value.fromDate ? (this.searchForm.value.fromDate.epoc ? this.service.encrypt(this.searchForm.value.fromDate.epoc * 1000) : null) : null,
          toDate     : this.searchForm.value.toDate ? (this.searchForm.value.toDate.epoc ? this.service.encrypt((this.searchForm.value.toDate.epoc * 1000) + (86400000 - 1)) : null) : null
        };
      }
    }
    this.service.postMethod('event/common-permit/get-event-list', apireq, 1).subscribe(success => {
      this.spinner.hide();
      if (success.status === 1038) {
        this.eventList = success.data.list;
        this.eventList.forEach(element => {
          if(element.updatedBy == null) {
            element.updatedAt = null;
          }
        });
        this.paginationData.total = success.data.size;
      } else {
        this.eventList = [];
      }
    }, error => {
      this.spinner.hide();
      this.eventList = [];
    });
  }

  changePage(event) {
    this.paginationData.currPage = event;
    this.getEventList('apply');
  }

  openModal(data, whichModal) {
    this.modalType = whichModal;
    this.selectedData = data;
    $('#unPublishdeleteModal').modal({backdrop: 'static', keyboard: false});
  }

  yesModal() {
    if (this.modalType === 'unpublish' || this.modalType === 'publish') {
      this.publishUnpublish();
    } else {
      if (this.modalType === 'delete') {
        this.deleteEvent();
      }
    }
  }

  publishUnpublish() {
    const apireq = {
      contentId : this.service.encrypt(this.selectedData.contentId),
      ipAddress : this.service.encrypt(this.userData.ip),
      location  : this.service.encrypt(this.userData.country_name)
    };
    this.service.postMethod('event/admin/change-event-status', apireq, 1).subscribe(success => {
      if (success.status === 1025) {
        $('#unPublishdeleteModal').modal('hide');
        this.getEventList('apply');
      } else {
        this.errMsg = success.message;
      }
    }, error => {
    });
  }

  deleteEvent() {
    this.service.getMethod(`event/admin/delete-event-details?contentId=${encodeURIComponent(this.service.encrypt(this.selectedData.contentId))}&ipAddress=${encodeURIComponent(this.service.encrypt(this.userData.ip))}&location=${encodeURIComponent(this.service.encrypt(this.userData.country_name))}`, 1).subscribe((success: any) => {
      if (success.status === 1022) {
        $('#unPublishdeleteModal').modal('hide');
        this.getEventList('apply');
      }
    }, error => {
    });
  }

}
  