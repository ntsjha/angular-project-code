import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HeaderComponent } from './modules/header/header/header.component';
import { HomeComponent } from './modules/home/home/home.component';
import { HomeModule } from './modules/home/home.module';
import { LoginComponent } from './modules/login/login/login.component';
import { SignupComponent } from './modules/signup/signup/signup.component';
import { ForgotpasswordComponent } from './modules/forgotpassword/forgotpassword/forgotpassword.component';
import { EmailverifyComponent } from './modules/emailverify/emailverify/emailverify.component';
import { ResetpasswordComponent } from './modules/resetpassword/resetpassword/resetpassword.component';
import { ProfileComponent } from './modules/profile/profile/profile.component';
import { EditprofileComponent } from './modules/editprofile/editprofile/editprofile.component';
import { ChangepasswordComponent } from './modules/changepassword/changepassword/changepassword.component';
import { KycComponent } from './modules/kyc/kyc/kyc.component';
import { TermandconditionsComponent } from './modules/termandconditions/termandconditions/termandconditions.component';
import { WalletComponent } from './modules/wallet/wallet/wallet.component';
import { DeposithistoryComponent } from './modules/deposithistory/deposithistory/deposithistory.component';
import { WithdrawhistoryComponent } from './modules/withdrawhistory/withdrawhistory/withdrawhistory.component';
import { AboutusComponent } from './modules/aboutus/aboutus/aboutus.component';
import { NewsComponent } from './modules/news/news/news.component';
import { ExchangeComponent } from './modules/exchange/exchange/exchange.component';
import { PrivacypolicyComponent } from './modules/privacypolicy/privacypolicy/privacypolicy.component';
import { AffiliateComponent } from './modules/affiliate/affiliate/affiliate.component';
import { AuthGuard } from './auth.guard';
import { ExheaderComponent } from './modules/exheader/exheader/exheader.component';
import { NewsdetailComponent } from './modules/newsdetail/newsdetail/newsdetail.component';


const routes: Routes = [
  { path: '', component: HeaderComponent, 
  children: [
      { path: '', component: HomeComponent},
      { path: 'login', component: LoginComponent, canActivate: [AuthGuard]},
      { path: 'signup/:code', component: SignupComponent, canActivate: [AuthGuard] },
      { path: 'forgetpassword', component: ForgotpasswordComponent, canActivate: [AuthGuard]},
      { path: 'emailverify/:page', component: EmailverifyComponent, canActivate: [AuthGuard]},
      { path: 'resetpassword', component: ResetpasswordComponent, canActivate: [AuthGuard]},
      { path: 'profile', component: ProfileComponent, canActivate: [AuthGuard]},
      { path: 'edit', component: EditprofileComponent, canActivate: [AuthGuard]},
      { path: 'changepassword', component: ChangepasswordComponent, canActivate: [AuthGuard]},
      { path: 'kyc', component: KycComponent, canActivate: [AuthGuard]},
      { path: 'TermsAndConditions', component: TermandconditionsComponent},
      { path: 'PrivacyPolicy', component: PrivacypolicyComponent},
      { path: 'wallet', component: WalletComponent, canActivate: [AuthGuard]},
      { path: 'aboutus', component: AboutusComponent},
      { path: 'news', component: NewsComponent},
      { path: 'deposithistory', component: DeposithistoryComponent, canActivate: [AuthGuard]},
      { path: 'withdrawhistory', component: WithdrawhistoryComponent, canActivate: [AuthGuard]},
      { path: 'affiliate', component: AffiliateComponent, canActivate: [AuthGuard]},
      { path: 'newsdetail/:id', component: NewsdetailComponent},


    
     
      
  ]
},{ path:'exchange', component: ExheaderComponent,
  children: [
      { path: '', component: ExchangeComponent},
  ]

}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

export const RoutingModule = [HomeModule]
