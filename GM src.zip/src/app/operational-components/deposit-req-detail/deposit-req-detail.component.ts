import { Component, OnInit } from '@angular/core';
import { IMyDpOptions, IMyDateModel } from 'mydatepicker';
import { ServiceService } from 'src/app/service/service.service';

@Component({
    selector: 'app-deposit-req-detail',
    templateUrl: './deposit-req-detail.component.html',
    styleUrls: ['./deposit-req-detail.component.css']
})
export class DepositReqDetailComponent implements OnInit {
    obj: any = {};
    public fromPickerOptions: IMyDpOptions = {
        dateFormat: 'dd.mm.yyyy',
    };
    public toPickerOptions: IMyDpOptions = {
        dateFormat: 'dd.mm.yyyy',
    };
    id: string;
    pageSize: any = 10;
    page: number = 1;
    transacArr: any = [];
    total: any = 0;
    search_key: any;
    customerObj: any;
    constructor(public server: ServiceService) { }

    ngOnInit() {
        this.callByUrl();
        window.scrollTo(0, 0);
    }

    callByUrl() {
        let url = window.location.href;
        let arr = url.split('/');
        this.id = arr[arr.length - 1];
        this.getTransacDetails();
    }

    getTransacDetails() {
        this.transacArr = [];
        let data = {
            "txnType": "USER_DEPOSIT",
            "page": this.page - 1,
            "pageSize": this.pageSize,
        };
        if (this.obj.fromDate && this.obj.toDate) {
            data['fromDate'] = this.obj.fromDate.epocl;
            data['toDate'] = this.obj.toDate.epoc;
        }
        if (this.search_key) {
            data['search'] = this.search_key;
        }
        this.server.postMethod(`wallet/admin/history/get-transaction-history-fiat-per-user?userId=${this.id}`, data, 1).subscribe((res) => {
            this.transacArr = res.data.resultlist;
            this.total = res.data.totalCount;
            this.customerObj = this.transacArr[0];
        });
    }

    onFromDateChanged(event: IMyDateModel) {
        let copy1 = this.getCopyOfOptions1();
        copy1.disableUntil = event.date;
        this.toPickerOptions = copy1;
    }

    getCopyOfOptions1(): IMyDpOptions {
        return JSON.parse(JSON.stringify(this.toPickerOptions));
    }

    getCopyOfOptions2(): IMyDpOptions {
        return JSON.parse(JSON.stringify(this.fromPickerOptions));
    }

    onToDateChanged(event: IMyDateModel) {
        let copy1 = this.getCopyOfOptions2();
        copy1.disableSince = event.date;
        this.fromPickerOptions = copy1;
    }

    managePagination(page) {
        this.page = page;
        this.total = 0;
        this.getTransacDetails();
    }

    applyFilter() {
        if (this.search_key || (this.obj.fromDate.epoc && this.obj.toDate.epoc)) {
            this.page = 1;
            this.total = 0;
            this.getTransacDetails();
        }
    }

    reset() {
        this.transacArr = [];
        this.total = 0;
        this.page = 1;
        this.search_key = '';
        this.obj.fromDate.epoc = '';
        this.obj.toDate.epoc = '';
        this.fromPickerOptions = {
            disableSince: { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() + 1 },
            disableUntil: { year: 0, month: 0, day: 0 }
        };
        this.toPickerOptions = {
            disableSince: { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() + 1 },
            disableUntil: { year: 0, month: 0, day: 0 }
        };
        this.getTransacDetails();
    }
}
