import { Component, OnInit } from '@angular/core';
import { ServiceService } from 'src/app/service/service.service';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-privacy-policy',
  templateUrl: './privacy-policy.component.html',
  styleUrls: ['./privacy-policy.component.css']
})
export class PrivacyPolicyComponent implements OnInit {
  privacyPolicy: any;
  modeOfAction: any;
  selectedLanguage: string;
  translate: boolean;
  currentUser: any;
  canEdit: boolean;
  canAdd: boolean;
  canView: boolean;
  privacyPolicyId: number;
  langId: any;
  translationId: any;
  privacyPolicyObj: any;
  privacyPolicyForm: FormGroup;
  showErrorForNull = false;
  showApiMessage = false;
  response: any;

  constructor(private service: ServiceService, private router: Router, private activatedRoutes: ActivatedRoute, private fb: FormBuilder, private spinner: NgxSpinnerService) { }

  ngOnInit() {
    this.activatedRoutes.params.subscribe((data) => {
      this.modeOfAction = data.id1;
      this.languageSelection(data.id2);
    });
    this.modeSelection();
    this.getPrivacyPolicy();
    this.service.currentUserInfo.subscribe((response) => {
      this.currentUser = response;
    });
    this.privacyPolicyForm = this.fb.group({
      updatedPrivacyPolicy: ['', [Validators.required]],
    });
    window.scrollTo(0, 0);
  }

  checkforSpaces() {
    const privacyData = (this.privacyPolicyForm.value.updatedPrivacyPolicy).trim();
    if (privacyData === null) {
      this.showErrorForNull = true;
    } else {
      this.showErrorForNull = false;
    }

  }

  cancelEdit() {
    this.router.navigate(['/manage-site-content']);
  }

  getPrivacyPolicy() {
    this.service.postMethod('static/admin/get-PrivacyPolicy-List', {}, 1)
      .subscribe((response) => {
        this.privacyPolicy = response.data[0];
        this.privacyPolicyId = response.data[0].privacyPolicyId;
        if (this.selectedLanguage !== 'en') {
          this.getPrivacyTranslation();
        } else {
          setTimeout(() => {
            this.privacyPolicyForm.patchValue({
              updatedPrivacyPolicy: this.privacyPolicy.description,
            });
          }, 500);
        }
      }, (error) => {
      });
  }

  getPrivacyTranslation() {
    this.service.postMethod('static/admin/get-privacypolicy-translation?privacyPolicyId=' + encodeURIComponent(this.service.encrypt(this.privacyPolicyId)), {}, 1)
      .subscribe((response) => {
        if (this.selectedLanguage !== 'en') {
          this.getThaiAndChaiTranslation(response);
        } else {
          setTimeout(() => {
            this.privacyPolicyForm.patchValue({
              updatedPrivacyPolicy: response.data[0].description,
            });
          }, 500);
        }
      }, (error) => {
      });
  }

  getThaiAndChaiTranslation(response) {
    const langList = response.data.languageList.data;
    langList.forEach(element => {
      if (element.languageShortName === this.selectedLanguage) {
        this.langId = element.languageId;
      }
    });
    const translationData = response.data.translationList;
    translationData.forEach(element => {
      if (element.fkLanguageId === this.langId) {
        this.translationId = element.privacyPolicyId;
        setTimeout(() => {
          this.privacyPolicyForm.patchValue({
            updatedPrivacyPolicy: element.description,
          });
        }, 500);
        this.privacyPolicyObj = element;
      }
    });
  }

  languageSelection(lang) {
    if (lang === 'th') {
      this.selectedLanguage = 'th';
      this.translate = true;
    } else if (lang === 'ch') {
      this.selectedLanguage = 'ch';
      this.translate = true;
    } else {
      this.selectedLanguage = 'en';
      this.translate = false;
    }
  }

  modeSelection() {
    if (this.modeOfAction === 'edit') {
      this.canEdit = true;
      this.canAdd = false;
      this.canView = false;
    } else if (this.modeOfAction === 'add') {
      this.canEdit = false;
      this.canAdd = true;
      this.canView = false;
    } else {
      this.canEdit = false;
      this.canAdd = false;
      this.canView = true;
    }
  }



  submit() {
    if (this.privacyPolicyForm.invalid) {
      return;
    }
    if (this.selectedLanguage !== 'en') {
      const data = {
        description: this.service.encrypt(this.privacyPolicyForm.value.updatedPrivacyPolicy),
        ipAddress: this.service.encrypt(this.currentUser.ip),
        location: this.service.encrypt(this.currentUser.city + ', ' + this.currentUser.country_name),
        translationId: this.service.encrypt(String(this.translationId)),
        title: this.service.encrypt(this.privacyPolicyObj.title)
      };
      this.spinner.show();
      this.service.postMethod('static/admin/edit-PrivacyPolicyTranslation-Data', data, 1)
        .subscribe((response) => {
          this.spinner.hide();
          if (response.status === 1064) {
            this.showApiMessage = true;
            this.response = response;
            this.response.message = 'Privacy Policy translation updated successfully.';
            window.scrollTo(0, 0);
            this.router.navigate(['/translation/privacy-policy']);
          }
        }, (error) => {
          this.spinner.hide();
          if (error.error) {
            this.showApiMessage = true;
            this.response = error.error;
          } else {
            this.showApiMessage = true;
            this.response = 'Something went wrong!';
          }
        });
    } else {
      const data = {
        description: this.service.encrypt(this.privacyPolicyForm.value.updatedPrivacyPolicy),
        ipAddress: this.service.encrypt(this.currentUser.ip),
        location: this.service.encrypt(this.currentUser.city + ', ' + this.currentUser.country_name),
        privacyPolicyId: this.service.encrypt(String(this.privacyPolicyId)),
        title: this.service.encrypt(this.privacyPolicy.title)
      };
      this.spinner.show();
      this.service.postMethod('static/admin/edit-PrivacyPolicy-Data', data, 1)
        .subscribe((res) => {
          this.spinner.hide();
          if (res.status === 1089) {
            this.showApiMessage = true;
            this.response = res;
            this.response.message = 'Privacy Policy updated successfully.';
            window.scrollTo(0, 0);
            this.router.navigate(['/translation/privacy-policy']);
          }
        }, (err) => {
          this.spinner.hide();
          if (err.error) {
            this.showApiMessage = true;
            this.response = err.error;
          } else {
            this.showApiMessage = true;
            this.response = 'Something went wrong!';
          }
        });
    }
  }
}
