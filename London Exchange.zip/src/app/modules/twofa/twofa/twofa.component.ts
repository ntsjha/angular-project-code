import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppComponent } from '../../../app.component';
import { ServerService } from '../../../service/server.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';``
import { Observable } from '../../../../../node_modules/rxjs/Observable';
import { HeaderComponent } from '../../header/header/header.component';

declare var $: any;

@Component({
    selector: 'app-twofa',
    templateUrl: './twofa.component.html',
    styleUrls: ['./twofa.component.css']
})
export class TwofaComponent implements OnInit {
    countryData: any;
    myCode: any = '';
    phone: any = '';
    myAngularxQrCode:any= null;
    otp = { one: "", two: "", three: "", four: "",five:"",six:"" };   
           
    qrCode = {Code1:""} 
    code: any;
    time: number;
    seconds: number = 60;
    auth: void;
    email: any;
    page: string;
    key: string;
    const: any;
    secretKey: any;
    

    constructor(private router: Router, private appC: AppComponent, private server: ServerService, private spinnerService: Ng4LoadingSpinnerService, public header: HeaderComponent) { 
       
    }

    checkUrl() {
       
        let url = window.location.href.split('/');
        let page = url[url.length - 1];
       
        if(page == 'login') {            
        }else {
            if(this.server.twoFAPage == "") {
               
                this.spinnerService.show();
                this.server.getApi('account/verify-user?token='+page,0).subscribe(response => {
                    this.spinnerService.hide();
                    if (response.body.status == 200) {
                        this.appC.showSuccToast(response.body.message);
                    } else {
                        this.appC.showInfoToast(response.body.message);                     
                    }
                }, error => {
                    this.spinnerService.hide();
                    this.appC.showErrToast('Something went wrong');
                });
            }
        }    
    }

    getprofile() {
        this.spinnerService.show();
        this.server.getApi("?key=" + this.page + "USER",0).subscribe((succ) => {
            this.spinnerService.hide();
            this.email = succ[0].email;
            this.phone = succ[0].phone;
            this.myCode = succ[0].phoneCountryCode;
        }, (err) => {
            this.spinnerService.hide();
        });
            
    }
    
    ngOnInit() {
       
        let url = window.location.href.split('/')
        this.page = url[url.length - 1]
        console.log('page',this.page)
        this.checkUrl();
        this.getprofile();
        //this.header.getprofile();
        window.scrollTo(0, 0);
        this.otp = { one: "", two: "", three: "", four: "",five:"",six:"" };   
           
        
        

    }

    myTimer() {
       this.const =  Observable.interval(1000)
        .takeWhile(() => this.seconds > 0 || (this.seconds != 60 && this.seconds > 0))
        .subscribe(i => { 
            // This will be called every 10 seconds until `stopCondition` flag is set to true
            
            --this.seconds;
        })
        if(this.seconds==0) {
            clearInterval(this.seconds);
        }
    }

    resendOtp() {
        clearInterval(this.const)
        this.seconds= 59;
        this.otpSend();
    }

    // Function to verify otp
    smsVerify() {
        this.code =  this.otp.one + this.otp.two + this.otp.three + this.otp.four +this.otp.five +this.otp.six ;
        let data = {
           
                    "code":this.code,                    
                    // "token": this.page,
                    // "clientTime":  new Date().getTime()
                }
           
        //console.log(this.otp.one+this.otp.two+this.otp.three+this.otp.four)
        this.spinnerService.show();
        this.server.postApi('account/verify-sms-code', data,this.page).subscribe(response => {
            this.spinnerService.hide();
            if (response.body.status == 200) {
                this.appC.showSuccToast(response.body.message);
                clearInterval(this.const);
                localStorage.setItem('token',response.body.data);
                // localStorage.setItem('userId',response.body.result[0].userId) ;
                this.header.checkLogin();
                $('#otpmodal').modal('hide');
                let data = {
                    messageType:"userUpdated",
                    token: response.body.data
                }
                this.server.wsExchange.send(JSON.stringify(data));
                this.router.navigate(['exHeader']);
             } else {
                this.otp = { one: "", two: "", three: "", four: "",five:"",six:"" };   
           
                this.appC.showErrToast(response.body.message);                     
            }
        }, error => {
            this.spinnerService.hide();
            this.appC.showErrToast('Something went wrong');
        });        
    }

    //Function for opening google auth modal
    openGoogleAuth() {
        this.qrCode = {Code1:""} 
        //this.appC.showWarnToast("Work in progress.");
        // let data= {
        //     "eventExternal": {
        //         "name": "request_google_auth",
        //         "key": "mykey"
        //     },
        //     "transferObjectMap": {
        //         "gatewayrequest": {
        //             "token": this.page,
        //         }
        //     }
        // }
        this.spinnerService.show();
        this.server.getApi('account/google-auth',this.page).subscribe(response => {
            this.spinnerService.hide();
            if (response.status== 200) { 
                $('#google').modal({backdrop: 'static',keyboard: false});
                // this.appC.showSuccToast("Qr Code generated successfully");
                localStorage.setItem('key',response.body.data.secretKey);
                this.key = localStorage.getItem('key') ;
                this.secretKey = response.body.data.secretKey;
                this.myAngularxQrCode = response.body.data.qrCode;
           
            } else {
                this.appC.showErrToast(response.body.message);
            }
        }, error => {
            this.spinnerService.hide();
            this.appC.showErrToast('Something went wrong');
        });
    }

    //Function to verify the otp send on registered phone number
    openotpmodal() {
        this.seconds = 59;
        this.otp = { one: "", two: "", three: "", four: "",five:"",six:"" };   
           
        //this.countryData = $("#phoneNum").intlTelInput("getSelectedCountryData");
        //this.myCode = this.countryData.dialCode;
        
        let data= {
           
                    "phoneCountryCode":this.myCode,
                    "phone":this.phone,
                    "token":this.page
                }
           
        //localStorage.setItem('phone',this.phone.phn);
        //localStorage.setItem('code',this.myCode);
        this.spinnerService.show();
        this.server.getApi('account/send-sms-code',this.page).subscribe(response => {
            this.spinnerService.hide();
            if (response.body.status == 200) {
                this.appC.showSuccToast(response.body.message);
                //$("#smsauthmodal").modal("hide");
                //$("#otpmodal").modal("show");
                $('#otpmodal').modal({
                    backdrop: 'static',
                    keyboard: false  // to prevent closing with Esc button (if you want this too)
                })
                this.myTimer();
            } else {
                this.appC.showErrToast(response.body.message);
                
            }
        }, error => {
            this.spinnerService.hide();
            this.appC.showErrToast('Something went wrong');
        });
    }

    /** Auto focus functionality */
    onKey(value, type) {
        if (type == 1) {
            if (value != "") {
                $('#otp2').focus();
            }
        } else if (type == 2) {
            if (value != "") {
                $('#otp3').focus();
            }
        } else if (type == 3) {
            if (value != "") {
                $('#otp4').focus();
            }
        } else if (type == 4) {
            if (value != "") {
                $('#otp5').focus();
            }
        } 
        else if (type == 5) {
            if (value != "") {
                $('#otp6').focus();
            }
            
        } 
        else if (type == 6) {
            if (value != "") {
                $('#otp6').focus();
            }
            
        } 
    }

    qrVerify() {
        let data= {
           
                    "code": this.qrCode.Code1,
                    "secretKey":localStorage.getItem('key'),
                  
                }
          
        this.spinnerService.show();
        this.server.postApi('account/verify-google-code', data,this.page).subscribe(response => {
            this.spinnerService.hide();
            console.log('verifyed',response)
            if (response.body.status == 200) {
                this.appC.showSuccToast("Qr Code verified successfully");
                $('#google').modal('hide')
                localStorage.setItem('token',this.page)
                // localStorage.setItem('userId',response.body.result[0].userId)
                
              
                this.router.navigate(['exHeader']);
                this.header.checkLogin();
                let data = {
                    messageType:"userUpdated",
                    token: this.page
                }
                this.server.wsExchange.send(JSON.stringify(data));                
                
                    
            } else {
                this.qrCode = {Code1:""} 
                this.appC.showErrToast("Qr Code not verified");                
            }
        }, error => {
            this.spinnerService.hide();
            this.appC.showErrToast('Something went wrong');
        });
    }

    otpSend() {
        this.myTimer();
       
        this.spinnerService.show();
        this.server.getApi('auth/send-sms-code',this.page).subscribe(response => {
            this.spinnerService.hide();
            if (response.body.status == 200) {
                
                
               this.otp = { one: "", two: "", three: "", four: "" ,five: "", six: ""};
                
            } else {
                this.otp = { one: "", two: "", three: "", four: "" ,five: "", six: ""};
       
                this.appC.showErrToast(response.body.message);                
            }
        }, error => {
            this.spinnerService.hide();
            this.appC.showErrToast('Something went wrong');
        });
    }

    login() {
        this.router.navigateByUrl('header/login');
    }

    copyToClipboard(data) {
        this.appC.showInfoToast("Text has been copied to clipboard.");
        let selBox = document.createElement('textarea');
        selBox.style.position = 'fixed';
        selBox.style.left = '0';
        selBox.style.top = '0';
        selBox.style.opacity = '0';
        selBox.value = data;
        document.body.appendChild(selBox);
        selBox.focus();
        selBox.select();
        document.execCommand('copy');
        document.body.removeChild(selBox);
    }
}
