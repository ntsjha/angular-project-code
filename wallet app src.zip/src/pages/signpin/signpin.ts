import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, AlertController, ToastController, ToastOptions, ModalController } from 'ionic-angular';
import { LoginPage } from '../login/login';
import { TabsPage } from '../tabs/tabs';
import { PinPage } from '../pin/pin';
import { ServiceServicesProvider } from '../../providers/service-services/service-services';
import { ForgotPage } from "../forgot/forgot";
import { SignupPage } from "../signup/signup";
declare var $: any;

@IonicPage()
@Component({
  selector: 'page-signpin',
  templateUrl: 'signpin.html',
})
export class SignpinPage {
  theCheckbox = true;
  pin1: any
  pin2: any
  pin3: any
  pin4: any
  pin: any
  toastoptions: ToastOptions

  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    public alerCtrl: AlertController,
    private toast: ToastController,
    private server: ServiceServicesProvider,
    public modalCtrl: ModalController) {
    if (!localStorage.getItem('userName') || localStorage.getItem('userName') == 'undefined') {
      let alert = this.alerCtrl.create({
        subTitle: 'Please set the PIN first ',
        buttons: [{
          text: 'Ok',
          handler: () => {
            this.navCtrl.setRoot(LoginPage)
          }
        }]
      });
      alert.present();
    }
  }

  loginWithUsername() {
    this.navCtrl.setRoot(LoginPage)
  }

  changeToggle(event) {
    if (event.target.checked == false) {
      this.navCtrl.setRoot(LoginPage)
    }

  }

  login() {
    if (navigator.onLine) {
      this.server.presentLoading();
      this.pin = this.pin1 + '' + this.pin2 + '' + this.pin3 + '' + this.pin4
      if (this.pin1 && this.pin2 && this.pin3 && this.pin4) {
        let data = {
          "loginType": "pin",
          "userName": localStorage.getItem('userName'),
          "password": this.pin
        }
        this.server.postApi(data, 'user/login', 0).subscribe((response: any) => {
          this.server.dismissLoading();
          if (response.response_code == 200) {
            localStorage.setItem('JWT', response.result.token)
            localStorage.setItem('userId', response.result.userDetail._id)
            this.server.presentToast(response.response_message)
            this.navCtrl.setRoot(TabsPage, { selectedTab: 2 })
          } else if (response.response_code == 201) {
            this.server.presentToast(response.response_message)
            let modalPage = this.modalCtrl.create('ModalPage');
            modalPage.present();
          } else {
            this.server.presentToast(response.response_message)
          }
        }, err => {
          this.server.dismissLoading();
          this.server.presentToast('Something went wrong')
        })

      } else {
        this.server.dismissLoading();
        this.server.presentToast('please enter the pin first')
        this.pin1 = '';
        this.pin2 = '';
        this.pin3 = '';
        this.pin4 = '';
      }
    } else
      this.server.presentToast('Your internet connection seems to be lost')

  }

  /** Auto focus functionality */
  onKey(value, type, nextElement) {
    if (type == 1) {
      if (value != "") {
        // $('#otp2').focus();
        nextElement.setFocus();
      }
    } else if (type == 2) {
      if (value != "") {
        // $('#otp3').focus();
        nextElement.setFocus();
      }
    } else if (type == 3) {
      if (value != "") {
        // $('#otp4').focus();
        nextElement.setFocus();
      }
    } else if (type == 4) {
      if (value.key == 'Backspace') {
        this.pin1 = '';
        this.pin2 = '';
        this.pin3 = '';
        this.pin4 = '';
        nextElement.setFocus();
      }
    }
  }

  forget() {
    this.navCtrl.push(ForgotPage, { forgot: 'PIN' })
  }

  signup() {
    this.navCtrl.push(SignupPage)
  }
}
