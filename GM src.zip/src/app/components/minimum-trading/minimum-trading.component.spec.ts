import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MinimumTradingComponent } from './minimum-trading.component';

describe('MinimumTradingComponent', () => {
  let component: MinimumTradingComponent;
  let fixture: ComponentFixture<MinimumTradingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MinimumTradingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MinimumTradingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
