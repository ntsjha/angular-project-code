import { Component, OnInit } from '@angular/core';
import { IMyDpOptions, IMyDateModel } from 'mydatepicker';
import { ServiceService } from 'src/app/service/service.service';
import { AngularCsv } from 'angular7-csv/dist/Angular-csv';

@Component({
    selector: 'app-report-fiat-withdraw',
    templateUrl: './report-fiat-withdraw.component.html',
    styleUrls: ['./report-fiat-withdraw.component.css']
})
export class ReportFiatWithdrawComponent implements OnInit {
    obj:any={};
    pageSize :any = 10;
    transacArr: any = [];
    public fromPickerOptions: IMyDpOptions = {
        dateFormat: 'dd.mm.yyyy',
    };
    public toPickerOptions: IMyDpOptions = {
        dateFormat: 'dd.mm.yyyy',
    };
    page: any=1;
    total: number=0;
    constructor(public server:ServiceService) { }

    ngOnInit() {
        this.getFiatWithdraw();
        window.scrollTo(0, 0);
    }

    onFromDateChanged(event: IMyDateModel) {
        let copy1 = this.getCopyOfOptions1();
        copy1.disableUntil = event.date;
        this.toPickerOptions = copy1; 
    }

    getCopyOfOptions1(): IMyDpOptions {
        return JSON.parse(JSON.stringify(this.toPickerOptions));
    }

    getCopyOfOptions2(): IMyDpOptions {
        return JSON.parse(JSON.stringify(this.fromPickerOptions));
    }
    
    onToDateChanged(event: IMyDateModel) {
        let copy1 = this.getCopyOfOptions2();
        copy1.disableSince = event.date;
        this.fromPickerOptions = copy1;
    }
    getFiatWithdraw() {
        let url, data = {};
        url = 'wallet/common-permit/history/get-transaction-history-fiat';
        data['txnType'] = "WITHDRAW";
        if(this.obj.fromDate && this.obj.toDate) {
            data['fromDate'] = this.obj.fromDate.epoc;
            data['toDate'] = this.obj.toDate.epoc;
        }
        data['page'] = this.page - 1;
        data['pageSize'] =  10;

        this.server.postMethod(url,data,1).subscribe((res)=>{
           this.transacArr = res.data.resultlist;
           this.total = res.totalCount; 
        }); 
    }

    managePagination(page) {
        this.page = page ;
        this.total = 0;  
        this.getFiatWithdraw();
    }

    applyFilter() {
        this.transacArr = [];
        this.page =1 ;
        this.total = 0;
        if(this.obj.fromDate && this.obj.toDate) {
            this.getFiatWithdraw();
        }
    }

    clearFilter() {
        this.transacArr = [];
        this.page =1 ;
        this.total = 0;
        this.obj.fromDate.epoc = '';
        this.obj.toDate.epoc = '';
        this.getFiatWithdraw();
    }

     exportList() {
        let headerArr = ['Date','Currency','To Address','Amount','Fee','Status','IP','Location'];
        var options = { 
            fieldSeparator: ',',
            quoteStrings: '"',
            decimalseparator: '.',
            showLabels: true,
            showTitle: true,
            title: 'Transaction List :',
            useBom: true,
            noDownload: false,
            headers: headerArr
        };

        
        let obj = {},data = [];
        this.transacArr.forEach((element,index) => {
            obj = {
                'date' : new Date(element.transactionTime),
                'currency':element.currencyShortName,
                'to_address': element.fromAddress,
                'amount': element.amount,
                'fee': element.fees,
                'status': element.status,
                'ip': element.ipAddress,
                'location': element.location
            };
        });
        data.push(obj);
        new AngularCsv(data, 'Transaction List', options);
    }

}
