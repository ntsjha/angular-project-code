import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { LoadingController, ToastController, App } from "ionic-angular";
import { LoginPage } from "../../pages/login/login";
import { SignpinPage } from "../../pages/signpin/signpin";

@Injectable()
export class ServiceServicesProvider {
  users: any;
  isLoggedIn: boolean = false;
  loading: any;
  userId: any;
  type: any;
  phoneNumber: any;
 // readonly rootUrl = 'http://162.222.32.20:1406/api/v1/'; //STAGING
 // readonly rootUrl = "http://172.16.1.122:1600/api/v1/"; //ABHAY LOCAL
  //readonly rootUrl = 'http://172.16.6.254:1600/api/v1/'; //LOCAL MANSI
  // readonly rootUrl = 'http://172.16.1.35:1600/api/v1/'; //LOCAL PRAKASH
  // readonly rootUrl = 'http://172.16.6.74:1406/api/v1/'; //LOCAL PRAMOD
 readonly rootUrl =     'http://172.16.1.122:1600/api/v1/' ; 
  //navigation to withdraw via home is left
  constructor(public http: HttpClient, private toastCtrl: ToastController, private loadingCtrl: LoadingController, private appCtrl : App) {
  }

  postApi(data, endPoint, isHeader) {
      if (isHeader == 0) {
        let reqHeader = {
          'Content-Type': 'application/json',
          "Authorization": "Basic " + btoa("walletapp:SFDSA78FSA7FFDSAFJRE32DSF98DSGFDGFDSH9H8FDSGFR4R549898DFDS")
        }
        return this.http.post(this.rootUrl + '' + endPoint, data, { headers: reqHeader });
      } else if (isHeader == 1) {
        let reqHeader = {
          'Content-Type': 'application/json',
          "Authorization": "Basic " + btoa("walletapp:SFDSA78FSA7FFDSAFJRE32DSF98DSGFDGFDSH9H8FDSGFR4R549898DFDS"),
          'token': localStorage.getItem('JWT'),
          'userid': localStorage.getItem('userId')
        }
        return this.http.post(this.rootUrl + '' + endPoint, data, { headers: reqHeader });
      }
  }

  getApi(endPoint, isHeader) {
      if (isHeader == 0) {
        let reqHeader = {
          'Content-Type': 'application/json',
          "Authorization": "Basic " + btoa("walletapp:SFDSA78FSA7FFDSAFJRE32DSF98DSGFDGFDSH9H8FDSGFR4R549898DFDS")
        }
        return this.http.get(this.rootUrl + endPoint, { headers: reqHeader })
      } else if (isHeader == 1) {
        let reqHeader = {
          'Content-Type': 'application/json',
          "Authorization": "Basic " + btoa("walletapp:SFDSA78FSA7FFDSAFJRE32DSF98DSGFDGFDSH9H8FDSGFR4R549898DFDS"),
          'token': localStorage.getItem('JWT'),
          'userid': localStorage.getItem('userId')
        }
        return this.http.get(this.rootUrl + endPoint, { headers: reqHeader })
      }
  }



  //----------------------------------------- GLOBAL CUSTOM TOAST(To notify user with necessary messages) STARTS -----------------------------------------//
  presentToast(msg) {
    let toast = this.toastCtrl.create({
      duration: 3000,
      position: 'top',
      cssClass: 'customToast'
    });
    toast.setMessage(msg);
    toast.present();
  }
  //----------------------------------------- GLOBAL CUSTOM TOAST(To notify user with necessary messages) ENDS -----------------------------------------//

  //----------------------------------------- GLOBAL CUSTOM PRESENT LOADING STARTS -----------------------------------------//
  presentLoading() {
    this.loading = this.loadingCtrl.create({
      spinner: 'ios',
      cssClass: 'customLoader'
    });
    this.loading.present();
  }
  //----------------------------------------- GLOBAL CUSTOM PRESENT LOADING ENDS -----------------------------------------//

  //----------------------------------------- GLOBAL DISMISS LOADING STARTS -----------------------------------------//
  dismissLoading() {
    if (this.loading) {
      this.loading.dismiss();
      this.loading = null;
    }
  }
  //----------------------------------------- GLOBAL DISMISS LOADING ENDS -----------------------------------------//

  getCurrencyAndFlag(country, isFull) {
    console.log('country service',country);
    if (isFull)
      return this.http.get('https://restcountries.eu/rest/v2/name/' + country + '?fullText=true')
    else
      return this.http.get('https://restcountries.eu/rest/v2/name/' + country)
  }

  getExchangeRate(currency) {
    return this.http.get('https://api.exchangeratesapi.io/latest?base=' + currency)
  }

  logout() {
    localStorage.removeItem('userId')
    localStorage.removeItem('JWT')
    this.checkPin();
  }

  checkPin() {
    this.presentLoading();
    let data = {
      userName: localStorage.getItem('userName')
    }
    this.postApi(data, 'user/pinExists',0).subscribe((resposne : any) =>{
      this.dismissLoading();
      if(resposne[`response_code`] == 200)
        this.appCtrl.getRootNav().setRoot(SignpinPage);
      else
        this.appCtrl.getRootNav().setRoot(LoginPage);
    }, err => {
      this.appCtrl.getRootNav().setRoot(LoginPage);
      this.dismissLoading();
      this.presentToast('Something went wrong');
    })
  }

  //------------------------------ GET LIST OF COUNTRIES ------------------------------//
	getCountryJson() {
		return this.http.get('assets/json/countries.json')
  }
  
  //------------------------------ GET LIST OF BANKS ------------------------------//
	getBankJson() {
		return this.http.get('assets/json/bank.json')
	}
}
