import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';
import { ServiceServicesProvider } from "../../providers/service-services/service-services";
import { TransactionStatusPage } from "../transaction-status/transaction-status";

@IonicPage()
@Component({
  selector: 'page-enter-cvc',
  templateUrl: 'enter-cvc.html',
})
export class EnterCvcPage {
  cvc: string;
  processDetails: any;
  cvcForm: FormGroup;
  usdAmount: any;

  constructor(public navCtrl: NavController, public navParams: NavParams, public fb: FormBuilder, public service: ServiceServicesProvider) {
    this.processDetails = JSON.parse(localStorage.addMoneyProcess)
    this.getUsdAmount();
  }

  getUsdAmount() {
    this.service.getExchangeRate(localStorage.countryCode).subscribe(
      (res: any) => {
        this.service.dismissLoading();
        if(res[`rates`]['USD'])
          this.usdAmount = res[`rates`]['USD']
        else {
          this.usdAmount = JSON.parse(localStorage.addMoneyProcess).amount;
        }
      },
      err => {
        this.service.dismissLoading();
        this.usdAmount = JSON.parse(localStorage.addMoneyProcess).amount;
      }
    );
  }

  confirmPayment() {
    if (navigator.onLine) {
      if (this.cvc.length == 3 && (/^\d+$/).test(this.cvc)) {
        this.service.presentLoading();
        let data = {
          "userId": localStorage.getItem('userId'),
          "holdersName": JSON.parse(localStorage.addMoneyProcess).cardDetails.cardHolderName,
          "number": JSON.parse(localStorage.addMoneyProcess).cardDetails.cardNumber,
          "exp_month": JSON.parse(localStorage.addMoneyProcess).cardDetails.expiry.split('-')[1],
          "exp_year": JSON.parse(localStorage.addMoneyProcess).cardDetails.expiry.split('-')[0],
          "cvc": this.cvc,
          "currency": "usd",
          "amount": Number(JSON.parse(localStorage.addMoneyProcess).amount),
          "usdAmount":Number(this.usdAmount)
        }
        this.service.postApi(data, 'transaction/smartContractTransaction', 0).subscribe(
          response => {
            this.service.dismissLoading();
            if (response[`response_code`] == 200) {
              this.navCtrl.setRoot(TransactionStatusPage, { type: 'addMoneyProcess', transactionDetail: response[`result`] })
              this.service.presentToast(response[`response_message`])
            } else if (response[`response_code`] == 403 || response[`response_code`] == 409 || response[`response_code`] == 401) {
              this.service.presentToast(response[`response_message`])
              this.service.logout();
            } else {
              this.service.presentToast(response[`response_message`])
            }
          },
          err => {
            this.service.dismissLoading();
            this.service.presentToast('Something went wrong')
          }
        )
      }
      else
        this.service.presentToast('Enter valid CVC Number')
    } else
      this.service.presentToast('Your internet connection seems to be lost')
  }

  back() {
    this.navCtrl.pop();
  }

}
