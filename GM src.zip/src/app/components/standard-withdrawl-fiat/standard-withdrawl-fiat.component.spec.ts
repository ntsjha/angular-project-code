import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StandardWithdrawlFiatComponent } from './standard-withdrawl-fiat.component';

describe('StandardWithdrawlFiatComponent', () => {
  let component: StandardWithdrawlFiatComponent;
  let fixture: ComponentFixture<StandardWithdrawlFiatComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StandardWithdrawlFiatComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StandardWithdrawlFiatComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
