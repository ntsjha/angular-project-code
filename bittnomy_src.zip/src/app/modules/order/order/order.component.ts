import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppComponent } from '../../../app.component';
import { ServerService } from '../../../service/server.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { HeaderComponent } from '../../header/header/header.component';
import { Angular5Csv } from 'angular5-csv/Angular5-csv';
import { DatePipe } from '@angular/common';

@Component({
    selector: 'app-order',
    templateUrl: './order.component.html',
    styleUrls: ['./order.component.css']
})
export class OrderComponent implements OnInit {
    activeTab = "";
    openOrderArr = [];
    orderHisArr = [];
    tradeHisArr = [];
    coinListArr: any;
    currentCoinObj = {coinShort:"BTC", coinFullName:"", coinId:""};    
    currentPairCoinObj = {coinShort:"", coinFullName:"", coinId:""};
    analyticData: any = {averageBuy:"0.00000000", totalBuy:"0.00000000", averageSell:"0.00000000",totalSell:"0.00000000"};;
    coinPairListArr: any[];

    constructor(private router: Router, private appC: AppComponent, private server: ServerService, private spinnerService: Ng4LoadingSpinnerService, public header: HeaderComponent, public datepipe: DatePipe) { }

    ngOnInit() {
        window.scrollTo(0, 0);
        this.activeTab = 'order';
        this.openOrderAPI();
    }

    /** Function for tab click */
    tabClick(val) {
        this.activeTab = val;
        switch(val) {
            case "order":
                this.openOrderAPI();
                break;
            case "history":
                // this.tradeHistoryAPI();
               this.orderHistoryAPI();
                  //this.getCoinList();
                break;
            case "trade":
                break;
        }
    }

    /** Function to get all open order of user's */
    openOrderAPI(){
        if(localStorage.getItem('token')){
            this.spinnerService.show();
            this.server.getApi('order/my-active-orders',localStorage.getItem('token')).subscribe(response => {
                this.spinnerService.hide();
                if (response.status== 200) {
                    // this.openOrderArr = response.openOrderList;
                    // this.openOrderArr.forEach((obj) => {
                    //     obj.click = false;
                    //     if(obj.triggerCondition == "0") {
                    //         obj.tri_cond = ">";
                    //     } else if(obj.triggerCondition == "1") {
                    //         obj.tri_cond = "<";
                    //     } else if(obj.triggerCondition == "2") {
                    //         obj.tri_cond = "----";
                    //     } else {
                    //         obj.tri_cond = "";
                    //     }
                    // });
                    this.appC.showSuccToast('Open order api Working')
                } else if(response.status == 403){
                    this.header.logOut();
                } else {
                    this.openOrderArr = [];
                    this.appC.showErrToast(response.message);
                }
            }, error => {
                this.spinnerService.hide();
                this.appC.showErrToast(error.error.message);
            });
        }
    }

    /** Function to get all order history data of user's */
    orderHistoryAPI(){
        if(localStorage.getItem('token')){
            // let openorderdata = {
            //     "eventExternal": {
            //         "name":"request_order_history_global",
            //         "key":"mykey"
            //     },
            //     "transferObjectMap": {
            //         "gatewayrequest": {
            //             "loginToken": localStorage.getItem("token")
            //         }
            //     }
            // }
            this.spinnerService.show();
            this.server.getApi('order/my-order-history',localStorage.getItem('token')).subscribe(response => {
                this.spinnerService.hide();
                if (response.status == 200) {
                    // this.orderHisArr = response.orderHistoryList;
                    // this.orderHisArr.forEach((obj) => {
                    //     switch(obj.orderStatus) {
                    //         case 'ACTIVE':
                    //             obj.amount = (obj.tradeHistoryAmount - obj.amount).toFixed(8);
                    //             obj.total = (obj.amount * obj.price).toFixed(8);
                    //             break;
                    //         case 'INACTIVE':
                    //             obj.amount = obj.tradeHistoryAmount.toFixed(8);
                    //             obj.total = (obj.amount * obj.price).toFixed(8);
                    //             break;
                    //         case 'CANCEL':
                    //             obj.amount = obj.amount.toFixed(8);
                    //             obj.total = (obj.amount * obj.price).toFixed(8);
                    //             break;
                        // }
                    // });
                    // this.orderHisArr.forEach((obj) => {
                    //     this.tradeHisArr.forEach(element => {
                    //         if(obj.userId == element.userId && obj.orderId == element.orderId) {
                    //             obj.fee  = element.commissionFee;
                    //             obj.grandTotal = Number(obj.total) - Number(element.commissionFee);
                    //         }
                    //     }); 
                    // });
                    this.appC.showSuccToast('Order history working')
                } else if(response.status == 403) {
                    this.header.logOut();
                } else {
                    this.orderHisArr = [];
                    this.appC.showErrToast(response.message);
                }
            }, error => {
                this.spinnerService.hide()
                this.appC.showErrToast(error.error.message);
            });
        }
    }

    /** Function to get all trade history data of user's */
    tradeHistoryAPI(){
        if(localStorage.getItem('token')){
            let data = {
                "eventExternal": {
                    "name": "request_get_user_commission",
                    "key": "mykey"
                },
                "transferObjectMap": {
                    "gatewayrequest": {
                        "token": localStorage.getItem("token")
                  }
                }
            }  
            this.spinnerService.show();
            this.server.getApi('order/order-history?userId='+localStorage.getItem('token'),localStorage.getItem('token')).subscribe(response => {
                this.spinnerService.hide();
                if (response.status == 200) {
                    // this.tradeHisArr = response.result;
                    // this.tradeHisArr.forEach(obj => {
                    //     obj.userShare = obj.totalVolume - obj.feeVolume
                    // });
                    this.appC.showSuccToast('trade history Working') 
                     this.orderHistoryAPI();
                    
                } else if(response.status == 403) {
                    this.header.logOut();
                } else {
                    this.tradeHisArr = [];
                    this.appC.showErrToast(response.transferObjectMap.message);
                }
            }, error => {
                this.spinnerService.hide()
                this.appC.showErrToast(error.error.message);
            });
        }
    }

    /** Function for cancel order */
    cancelOrder(obj) {
        obj.click = true;
        let data = {
            "eventExternal": {
                "name":"request_cancel_order",
                "key":"mykey"
            },
            "transferObjectMap": {
                "gatewayrequest": {
                    "loginToken": localStorage.getItem("token"),            
                    "orderList": [obj.orderId]
                }
            }
        }
        this.spinnerService.show();
        this.server.postApi("",data,0).subscribe((succ) => {
            this.spinnerService.hide();
            if(succ.status == 200) {
                this.appC.showSuccToast("Order cancelled successfully.");
                this.openOrderAPI();
            } else if(succ.status == 403) {
                this.header.logOut();
            } else {
                this.appC.showErrToast(succ.message);
                obj.click = false;
            }
        }, (err) => {
            this.spinnerService.hide();
        });
    }

    /** Function for export data */
    exportData() {
        if(this.activeTab == 'history') {
        let data = [];
        data.push({
            date: "Date",
            pair: "Pair",
            type: "Type",
            price: "Price",
            amount: "Amount",
            filled: "Filled",
            total: "Total",
            status: "Status"
        });
        this.orderHisArr.forEach((obj) => {
            data.push({
                date: this.convertFormat(obj.orderTime),
                pair: obj.pair,
                type: obj.orderType,
                price: obj.price,
                amount: obj.amount,
                filled: obj.orderStatus=="INACTIVE" ? "100" : obj.happening,
                total: obj.total,
                status: obj.orderStatus,
            });
        });
        new Angular5Csv(data, 'Bittnomy Order History Report');

        } else if(this.activeTab == 'trade') {
            let data = [];
            data.push({
                date: "Date",
                pair: "Pair",
                Ttype: "Trading Type",
                Otype: "Order Type",
                volume: "Volume",
                fee: "Fee",
                
            });
            this.tradeHisArr.forEach((obj) => {
                data.push({
                    date: this.convertFormat(obj.orderTime),
                    pair: obj.toCoin+'/'+obj.fromCoin,
                    Ttype: obj.tradingType,
                    Otype: obj.orderType,
                    volume: obj.totalVolume,
                    fee: obj.feeVolume,
                    
                });
            });
            new Angular5Csv(data, 'Bittnomy Trade History Report');
        }
    }

    /** Function to convert date format */
    convertFormat(time) {
        return this.datepipe.transform(time, 'MM/dd/yyy, hh:mm a');
    }

    /** Function to manage exponential data */
    manageExponential(num) {
        //if the number is in scientific notation remove it
        if(num != 'NaN') {
            if (/\d+\.?\d*e[\+\-]*\d+/i.test(num)) {
                var zero = '0',
                parts = String(num).toLowerCase().split('e'), //split into coeff and exponent
                es = Number(parts.pop()), //store the exponential part
                l = Math.abs(es), //get the number of zeros
                sign = es / l,
                coeff_array = parts[0].split('.');
                if (sign === -1) {
                    num = zero + '.' + new Array(l).join(zero) + coeff_array.join('');
                } else {
                    var dec = coeff_array[1];
                    if (dec) l = l - dec.length;
                    num = coeff_array.join('') + new Array(l + 1).join(zero);
                }
                return num;
            } else {
                return num;
            }
        } else {
            return 0.00000000;
        }
        
    };

    /** Function to get coin list from api */
    getCoinList() {
        let data = {
            "eventExternal":  {
                "name":"request_get_coin_list",
                "key":"mykey"
            },
            "transferObjectMap":{}
        }
        this.spinnerService.show();
        this.server.postApi('',data,0).subscribe((succ) => {
            this.spinnerService.hide();
            if(succ.transferObjectMap.statusCode == 200) {
                let data = succ.transferObjectMap.coinList;
                this.coinListArr = data.filter((x) => x.coinType=="crypto" && (x.coinShortName == 'IPR' ||x.coinShortName == 'BTC' || x.coinShortName == 'ETH' || x.coinShortName == 'USDT'));
                this.currentCoinObj.coinId = this.coinListArr[0].coinId;
                this.currentCoinObj.coinShort = this.coinListArr[0].coinShortName;
                this.getCoinPair();
            } else {
                this.appC.showErrToast(succ.transferObjectMap.message);
            }
        }, (err) => {
            this.spinnerService.hide();
        });
    }

    /** Function to get coin pair list from api*/
    getCoinPair() {
        this.coinPairListArr = [];
        let data = {
            "eventExternal": {
                "name": "request_coin_pair_list",
                "key": "mykey"
            },
            "transferObjectMap": {
                "gatewayrequest": {
                    "baseCurrency":this.currentCoinObj.coinId
                }
            }
        }
        this.spinnerService.show();
        this.server.postApi('',data,0).subscribe((succ) => {
            this.spinnerService.hide();
            if(succ.transferObjectMap.statusCode == 200) {
                // let data = succ.transferObjectMap.coinPairList;
                let data = [];
                succ.transferObjectMap.coinPairList.forEach(obj => {
                    if(obj.coin_short_name == 'BTC'|| obj.coin_short_name == 'ETH'|| obj.coin_short_name == 'XRP'|| obj.coin_short_name == 'BCH'|| obj.coin_short_name == 'XLM'|| obj.coin_short_name == 'LTC'|| obj.coin_short_name == 'IOTA' || obj.coin_short_name == 'USDT' || obj.coin_short_name == 'XVG' || obj.coin_short_name == 'IPR') {
                        data.push(obj);
                    }
                });
                // let cPairListArr = succ.transferObjectMap.coinLastPairList;
                data.forEach((obj) => {
                    this.coinPairListArr.push({
                        coinID: obj.coin_id,
                        coin: obj.coin_short_name,
                        coinFullName: obj.coin_full_name,
                        volume: obj.volume,
                        average: obj.average
                    });
                });
                    // if(this.currentCoinObj.coinShort == 'USDT') {
                    //     data.forEach((obj) => {
                    //         if(obj.coin_short_name == 'BTC'|| obj.coin_short_name == 'ETH'|| obj.coin_short_name == 'XRP'|| obj.coin_short_name == 'BCH'|| obj.coin_short_name == 'XLM'|| obj.coin_short_name == 'LTC'|| obj.coin_short_name == 'IOTA') {
                    //             this.coinPairListArr.push({
                    //                 coinID: obj.coin_id,
                    //                 coin: obj.coin_short_name,
                    //                 coinFullName: obj.coin_full_name,
                    //                 volume: obj.volume,
                    //                 average: obj.average
                    //             });
                    //         } 
                    //     });
                    // } else if(this.currentCoinObj.coinShort == 'IPR') {
                    //     data.forEach((obj) => {
                    //         if(obj.coin_short_name == 'XRP'|| obj.coin_short_name == 'XLM'|| obj.coin_short_name == 'LTC'|| obj.coin_short_name == 'IOTA') {
                    //             this.coinPairListArr.push({
                    //                 coinID: obj.coin_id,
                    //                 coin: obj.coin_short_name,
                    //                 coinFullName: obj.coin_full_name,
                    //                 volume: obj.volume,
                    //                 average: obj.average
                    //             });
                    //         } 
                    //     });

                    // } else {
                    //     data.forEach((obj) => {
                    //         if(obj.coinType == 'crypto' && obj.coin_id > this.currentCoinObj.coinId) {
                    //             this.coinPairListArr.push({
                    //                 coinID: obj.coin_id,
                    //                 coin: obj.coin_short_name,
                    //                 coinFullName: obj.coin_full_name,
                    //                 volume: obj.volume,
                    //                 average: obj.average
                    //             });
                    //         } 
                    //     });
                    // }
                    this.currentPairCoinObj.coinShort = this.coinPairListArr[0].coin;
                    this.getAnalysisFunc();
            } else {
                this.coinPairListArr = [];
            }
        }, (err) => {
            this.spinnerService.hide();
        });
    }

    getAnalysisFunc() {
        let data = {
            "eventExternal": {
                "name": "get_average_buy_sell",
                "key": "mykey"
            },
            "transferObjectMap": {
                "gatewayrequest": {
                    "loginToken": localStorage.getItem("token"),
                    "baseCurrency": this.currentCoinObj.coinShort,
                    "executableCurrency": this.currentPairCoinObj.coinShort,
                    "userId": localStorage.getItem("userId")
                }
            }
        }
        this.spinnerService.show();
        this.server.postApi('',data,0).subscribe((succ) => {
            this.spinnerService.hide();
            if(succ.transferObjectMap.statusCode == 200) {
                this.analyticData = succ.transferObjectMap.buySellDetails;
            } else {
                this.appC.showErrToast(succ.transferObjectMap.message);
            }
        }, (err) => {
            this.spinnerService.hide();
        });
    }

    /** Function for coin change */
    coinChangeFunc() {
        this.currentPairCoinObj.coinShort = '';
        this.currentCoinObj.coinId = this.coinListArr.filter((x) => x.coinShortName == this.currentCoinObj.coinShort)[0].coinId;
        this.getCoinPair();
    }


}


