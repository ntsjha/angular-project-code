import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddUserGuideComponent } from './add-user-guide.component';

describe('AddUserGuideComponent', () => {
  let component: AddUserGuideComponent;
  let fixture: ComponentFixture<AddUserGuideComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddUserGuideComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddUserGuideComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
