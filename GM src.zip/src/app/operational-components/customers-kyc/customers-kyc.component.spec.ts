import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomersKycComponent } from './customers-kyc.component';

describe('CustomersKycComponent', () => {
  let component: CustomersKycComponent;
  let fixture: ComponentFixture<CustomersKycComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomersKycComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomersKycComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
