import { Component, OnInit } from '@angular/core';
import { StoreService } from '../store.service';
import { Observable } from 'rxjs';
import { google } from '@agm/core/services/google-maps-types';

@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css'],
  providers: [StoreService]
})
export class TestComponent implements OnInit {
  months = ["January", "Feburary", "March", "April", "May", 
  "June", "July", "August", "September",
  "October", "November", "December"];
heroes = ['Tornado','hello'];
  
empinfo:any [];

lat: number = 28.5203773;
lng: number = 77.2807311;
  latitude: any;
  longitude: any;
  isTracking: boolean;
  currentLat: any;
  currentLong: any;
  map: any;
  marker: any;
  
  constructor(private _store:StoreService) { }

  ngOnInit() {
      var retrievedObject = localStorage.getItem('token');
    console.log('retrievedObject: ', JSON.parse(retrievedObject)); 
   // alert(retrievedObject);
      this.trackMe();

      this.empinfo=this._store.emp;
      
  }
  
  addHero(newHero: string) {
    if (newHero) {
      this.heroes.push(newHero);

      
    }
  }

  
  trackMe() {
    if (navigator.geolocation) {
      this.isTracking = true;
      navigator.geolocation.watchPosition((position) => {
        this.showTrackingPosition(position);
       
      }); 
    } else {
      alert("Geolocation is not supported by this browser.");
    }
  }
 

  showTrackingPosition(position) {
    console.log(`tracking postion:  ${position.coords.latitude} - ${position.coords.longitude}`);
   this.currentLat = position.coords.latitude;
   this.currentLong = position.coords.longitude;

     }

     

}
