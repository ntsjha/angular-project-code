import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouteReuseStrategy } from '@angular/router';

import { IonicModule, IonicRouteStrategy } from '@ionic/angular';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { HomeComponent } from './home/home.component';
import { SignupComponent } from './signup/signup.component';
import { IonicStorageModule } from '@ionic/storage';
import { ProfileComponent } from './profile/profile.component';
import { ViewComponent } from './profile/view/view.component';



@NgModule({
  declarations:
   [AppComponent, HomeComponent, SignupComponent, ProfileComponent, ViewComponent],
  
   entryComponents: [],
  
  imports: [BrowserModule, IonicModule.forRoot(), ReactiveFormsModule,
    FormsModule,AppRoutingModule,IonicStorageModule.forRoot({
      name: '__mydb',
driverOrder: ['indexeddb', 'sqlite', 'websql']
    })],
  providers: [
    StatusBar,
    SplashScreen,
    
    
    
    
    { provide: RouteReuseStrategy, useClass: IonicRouteStrategy }
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}
