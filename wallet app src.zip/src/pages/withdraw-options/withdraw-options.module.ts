import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { WithdrawOptionsPage } from './withdraw-options';

@NgModule({
  declarations: [
    WithdrawOptionsPage,
  ],
  imports: [
    IonicPageModule.forChild(WithdrawOptionsPage),
  ],
})
export class WithdrawOptionsPageModule {}
