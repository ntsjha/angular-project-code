import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AngularFirestore } from '@angular/fire/firestore';
import { ServiceService } from 'src/app/Shared/service.service';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-add-subscriptionplan',
  templateUrl: './add-subscriptionplan.component.html',
  styleUrls: ['./add-subscriptionplan.component.css']
})
export class AddSubscriptionplanComponent implements OnInit {
  contributorForm: FormGroup;
  

  constructor(private router: Router, private afb: AngularFirestore,public globalSer : ServiceService) { }

  ngOnInit() {
    this.contributorForm = new FormGroup({
      planType: new FormControl('', [ Validators.required,Validators.pattern(/^[a-z\d\-_\s]+$/i)]),
      duration: new FormControl('', [ Validators.required,Validators.pattern(/^[a-z\d\-_\s]+$/i)]),
      maxhorses: new FormControl('', [Validators.pattern(/^[#.0-9a-zA-Z\s,-]+$/), Validators.required]),
      price: new FormControl('',[Validators.required,]),
      // description:new FormControl('',[Validators.required,Validators.maxLength(200)])
  })
}

Submitsubscription(){
 
  let data = {
    planType     :   this.contributorForm.value.planType,
    duration  :   this.contributorForm.value.duration,
    maxHorses  :   this.contributorForm.value.maxhorses,
    price  :   Number(this.contributorForm.value.price),
    // description: this.contributorForm.value.description,
   }
   console.log(data) 
   this.globalSer.showSpinner();
   this.afb.collection('SubscriptionPlan').add(data);
   this.globalSer.showSuccess('Subscription plan has been added successfully.');
   this.globalSer.hideSpinner();
   this.contributorForm.reset();
   this.router.navigate(['/subscription']);
   }


   numberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    console.log('Char===',charCode)
    if (charCode > 31 && (charCode < 46 || charCode > 57  )) {
      return false;
    }
    return true;

  }
  preventSpace(event){
    if(event.charCode==32 && !event.target.value){
    event.preventDefault()
    } else{
    // console.log(event)
    }
    // console.log('event',event.charCode)
    }
}
