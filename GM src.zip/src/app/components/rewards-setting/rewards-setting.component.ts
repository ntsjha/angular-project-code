import { Component, OnInit } from '@angular/core';
import { ServiceService } from 'src/app/service/service.service';
import { DatePipe } from '@angular/common';
import { NgxSpinnerService } from 'ngx-spinner';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-rewards-setting',
  templateUrl: './rewards-setting.component.html',
  styleUrls: ['./rewards-setting.component.css']
})
export class RewardsSettingComponent implements OnInit {

  getRewardsetting: any[];
  getRewardsettingDefault: any[];
  rewardFunction: FormGroup;
  response: any = { message: '' };

  constructor(private service: ServiceService,
    public datepipe: DatePipe,
    private spinner: NgxSpinnerService,
  ) {
    this.rewardFunction = new FormGroup({
      day: new FormControl(null, [Validators.required, Validators.pattern(/^[0-9]*$/), Validators.minLength(1), Validators.maxLength(5)]),
      month: new FormControl(null, [Validators.required]),
      maxPointFriend: new FormControl(null, [Validators.required, Validators.pattern(/^[0-9]*$/), Validators.minLength(1), Validators.maxLength(10)]),
      maxPointKYC: new FormControl(null, [Validators.required, Validators.pattern(/^[0-9]*$/), Validators.minLength(1), Validators.maxLength(10)]),
      maxPercentageTrading: new FormControl(null, [Validators.required, Validators.pattern(/^(100(?:\.00)?|0(?:\.\d\d)?|\d?\d(?:\.\d\d)?)$/)]),
      dailyAvailRedeem: new FormControl(null, [Validators.required, Validators.pattern(/^[0-9]*$/), Validators.minLength(1), Validators.maxLength(10)]),
      dailyMaxPoint: new FormControl(null, [Validators.required, Validators.pattern(/^[0-9]*$/), Validators.minLength(1), Validators.maxLength(10)]),

    });
  }

  ngOnInit() {
    this.getReward();
    this.getRewardDefault();
    window.scrollTo(0, 0);
  }

  getReward() {
    this.spinner.show();
    this.service.getMethod('rewards/admin/get-reward-setting', 1).subscribe((response: any) => {
      this.spinner.hide();
      if (response.status === 1330) {
        this.getRewardsetting = response.data;
        this.rewardFunction.patchValue({
          dailyAvailRedeem: this.getRewardsetting[0].dailyAvailablePointForRedeemExchange,
          dailyMaxPoint: this.getRewardsetting[0].dailyMaxPointRedeemByUser,
          month: this.getRewardsetting[0].rewardExpiryUnit,
          day: this.getRewardsetting[0].rewardExpiryValue

        });
      }
      this.getRewardsetting = response.data;
    }, (error) => {
      this.spinner.hide();
    });
    this.spinner.hide();
  }

  getRewardDefault() {
    this.spinner.show();
    this.service.getMethod('rewards/common-permit/get-max-reward-setting', 1).subscribe((response: any) => {
      this.spinner.hide();
      if (response.status === 1328) {
        this.getRewardsettingDefault = response.data;
        this.rewardFunction.patchValue({
          maxPointFriend: this.getRewardsettingDefault[0].rewardPointOrpercentage,
          maxPointKYC: this.getRewardsettingDefault[1].rewardPointOrpercentage,
          maxPercentageTrading: this.getRewardsettingDefault[2].rewardPointOrpercentage,
        });
      }
      this.getRewardsetting = response.data;
    }, (error) => {
      this.spinner.hide();
    });
    this.spinner.hide();
  }

  updateReward() {
    if (this.rewardFunction.invalid || (this.rewardFunction.value.dailyMaxPoint > this.rewardFunction.value.dailyAvailRedeem)) {
      return;
    }
    this.spinner.show();
    const rewardSettingDto = {
      dailyAvailablePointForRedeemExchange: this.rewardFunction.value.dailyAvailRedeem,
      dailyMaxPointRedeemByUser: this.rewardFunction.value.dailyMaxPoint,
      percentageForTrading: this.rewardFunction.value.maxPercentageTrading,
      pointForRefering: this.rewardFunction.value.maxPointFriend,
      pointsForKyc: this.rewardFunction.value.maxPointKYC,
      rewardExpiryUnit: this.rewardFunction.value.month,
      rewardExpiryValue: this.rewardFunction.value.day
    };

    this.service.postMethod('rewards-service/admin/update-setting-reward', rewardSettingDto, 1).subscribe((response: any) => {
      this.spinner.hide();
      this.response.status = response.status;
      this.response.message = response.message;
      window.scrollTo(0,0);
    }, (error) => {
      window.scrollTo(0,0);
      this.response.status = error.error.status;
      this.response.message = error.error.message;
      this.spinner.hide();
    });
  }

  incrementDay() {
    this.rewardFunction.patchValue({
      day: this.rewardFunction.value.day + 1
    });
  }

  decrementDay() {
    this.rewardFunction.patchValue({
      day: this.rewardFunction.value.day - 1
    });
    if (this.rewardFunction.value.day < 0) {
      this.rewardFunction.patchValue({
        day: 0
      });
    }
  }

  /** Function to restrict negative and positive symbol */
  restrictChar(e) {
    if (!((e.keyCode > 95 && e.keyCode < 106)
      || (e.keyCode > 47 && e.keyCode < 58)
      || e.keyCode == 8)) {
      return false;
    }
  }
}
