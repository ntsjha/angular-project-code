import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OTCPermotionComponent } from './otc-permotion.component';

describe('OTCPermotionComponent', () => {
  let component: OTCPermotionComponent;
  let fixture: ComponentFixture<OTCPermotionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OTCPermotionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OTCPermotionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
