import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { ServerService } from '../../../service/server.service';
import { AppComponent } from '../../../app.component';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
//import { userInfo } from 'os';
declare var $: any;

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
    signupForm: FormGroup;
    countryData: any;
    myCode: any;
    recaptcha: string='';
    showEye: boolean = false;

    constructor(private router: Router, private server: ServerService, private appC: AppComponent, private spinnerService: Ng4LoadingSpinnerService, public myService: ServerService) { }

    ngOnInit() {
        window.scrollTo(0, 0);
        $("#phoneNum").intlTelInput({
            autoPlaceholder: true,
            autoFormat: false,
            autoHideDialCode: false,
            initialCountry: 'in',
            nationalMode: false,
            onlyCountries: [],
            preferredCountries: ["us"],
            formatOnInit: true,
            separateDialCode: true
        });
        this.checkInputs();
    }

    /** Function to validate form inputs */
    checkInputs() {
        this.signupForm = new FormGroup ({
            email: new FormControl('ex@mailinator.com', [Validators.required, Validators.pattern(/^[A-Z0-9_-]+([\.][A-Z0-9_]+)*@[A-Z0-9-]+(\.[a-zA-Z]{2,3})+$/i)]),
            password: new FormControl('qwert@11', [Validators.required, Validators.pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})/i)]),
            name: new FormControl('', [Validators.required, Validators.pattern(/^[a-z ,.'-]+$/i)]),
            phone: new FormControl('89865698896', [Validators.required,Validators.minLength(7), Validators.pattern(/^[1-9]{1}[0-9]*$/),Validators.maxLength(14),Validators.minLength(7)]),
            privacyPolicy: new FormControl('', [Validators.required]),
            terms: new FormControl('', [Validators.required]),
            confirmPassword: new FormControl('qwert@11', [Validators.required]),
        }, passwordMatchValidator);
        /** Function for password match and mismatch */
        function passwordMatchValidator(g: FormGroup) {
            let pass = g.get('password').value;
            let confPass = g.get('confirmPassword').value;
            if (pass != confPass) {
                g.get('confirmPassword').setErrors({ mismatch: true });
            } else {
                g.get('confirmPassword').setErrors(null)
                return null
            }
        }
    }

    /** to get the value of field  */
    get email(): any {
      return this.signupForm.get('email');
    }
    get password(): any {
        return this.signupForm.get('password');
    }
    get confirmPassword(): any {
        return this.signupForm.get('confirmPassword');
    }
    get name(): any {
        return this.signupForm.get('name');
    }
    get phone(): any {
        return this.signupForm.get('phone');
    }   
    get privacyPolicy(): any {
        return this.signupForm.get('privacyPolicy');
    } 
    get terms(): any {
        return this.signupForm.get('terms');
    }

    login() {
      this.router.navigateByUrl('header/login')
    }

    preventSpace(event)  {
        if (event.keyCode == 32 && event.target.value == '') {
            return false;
        }        
    }

    register()  { 
        let name=this.signupForm.value.name;
    
        if(this.signupForm.invalid || this.recaptcha=='') {
            this.appC.showErrToast('Please enter all details.');
            return;
        } else {
            this.countryData = $("#phoneNum").intlTelInput("getSelectedCountryData");
            this.myCode = this.countryData.dialCode; 
            let signupData = {
                "firstName": name.split(' ').slice(0, -1).join(' ')?name.split(' ').slice(0, -1).join(' '):name.split(' ').slice(-1).join(' '),
                "lastName" : name.split(' ').slice(-1).join(' '),
                "phoneNo": '+'+this.myCode+this.signupForm.value.phone,
                "email": this.signupForm.value.email.toLowerCase(),
                "password": this.signupForm.value.password,
                "roleStatus":"USER",
                "webUrl": this.server.websiteURL+"header/login",           
            }
            this.spinnerService.show();
            this.server.postApi('account/signup', signupData,0).subscribe(response => {
                this.spinnerService.hide();
                console.log(response)
                if (response.body.status == 200) {
                   
                    this.appC.showSuccToast('User created successfully.')
                    localStorage.setItem('email',this.signupForm.value.email);
                    this.router.navigateByUrl('header/verify/signup');
                } else {
                    this.appC.showErrToast(response.body.message);
                }
            }, error => {
                this.spinnerService.hide();
                this.appC.showErrToast(error);
            });
        }

    }

    /** to show and hide password */
    showHidePassword() {
        if(this.showEye == false) {
            this.showEye = true;
        } else if(this.showEye == true){
            this.showEye = false;
        }
    }

    resolved(e) {
        if(e)
            this.recaptcha = e;
        else{
            this.recaptcha = "";
        }
    }

}
