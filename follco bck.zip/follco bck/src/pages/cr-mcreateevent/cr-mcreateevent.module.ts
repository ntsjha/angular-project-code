import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CrMcreateeventPage } from './cr-mcreateevent';

@NgModule({
  declarations: [
    CrMcreateeventPage,
  ],
  imports: [
    IonicPageModule.forChild(CrMcreateeventPage),
  ],
})
export class CrMcreateeventPageModule {}
