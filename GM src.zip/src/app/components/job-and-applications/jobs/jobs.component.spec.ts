import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { JobsComponent } from './jobs.component';
import { SharedModuleModule } from 'src/app/shared-module/shared-module.module';
import { RouterModule } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { DeviceDetectorService } from 'ngx-device-detector';
import { AppComponent } from 'src/app/app.component';
import { MarketingSidebarComponent } from '../sidebar/sidebar.component';
import { FormGroup, FormControl } from '@angular/forms';

describe('JobsComponent', () => {
  let component: JobsComponent;
  let fixture: ComponentFixture<JobsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ JobsComponent, MarketingSidebarComponent ],
      imports: [SharedModuleModule, RouterModule,
        RouterTestingModule,],
        providers: [AppComponent, DeviceDetectorService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(JobsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
      this.jobFilter = new FormGroup({
        search: new FormControl(null),
        status: new FormControl(null),
      })
    });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('general form invalid when empty', async(() => {
    const emptyValue = component.jobFilterTest('','');
    expect(emptyValue).toBeFalsy();
  }));

  it('general form valid with all fields', async(() => {
    const value = component.jobFilterTest('123456','publish');
    expect(value).toBeTruthy();
  }));
});
