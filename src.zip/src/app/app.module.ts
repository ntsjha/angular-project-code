import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatAutocompleteModule} from '@angular/material/autocomplete';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {MatCardModule} from '@angular/material/card';
import {MatSortModule} from '@angular/material/sort';


import {MatButtonModule} from '@angular/material/button';
import {MatGridListModule} from '@angular/material/grid-list';
import {MatInputModule} from '@angular/material/input';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatIconModule} from '@angular/material/icon';
import {MatSidenavModule} from '@angular/material/sidenav';
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatSelectModule} from '@angular/material/select';
import {MatTableModule} from '@angular/material/table';
import {MatCheckboxModule} from '@angular/material/checkbox';
import {NgxPaginationModule} from 'ngx-pagination';
import { Ng4LoadingSpinnerModule } from 'ng4-loading-spinner';
import { CookieService } from 'ngx-cookie-service';
import { ToastrModule } from 'ngx-toastr';
import { PaymentComponent } from './payment/payment.component';
import {MatRadioModule} from '@angular/material/radio';
import { NgxStripeModule } from 'ngx-stripe';
import {MatSlideToggleModule} from '@angular/material/slide-toggle';
import {MatListModule} from '@angular/material/list';
import {MatDialogModule} from '@angular/material/dialog';

import { ContactComponent } from './contact/contact.component';
import { UsermgmtComponent } from './usermgmt/usermgmt.component';
import { MyprofileComponent } from './myprofile/myprofile.component';
import { EditProfileComponent } from './edit-profile/edit-profile.component';
import { MachinereadingComponent,  } from './machinereading/machinereading.component';
import { BuySubscriptionComponent } from './buy-subscription/buy-subscription.component';
import { LogoutComponent } from './logout/logout.component';

import { LogoutModalComponent } from './home/home.component';

import {  AddnewMachine } from './machinereading/machinereading.component';
import { SelectpetrolpumpComponent } from './selectpetrolpump/selectpetrolpump.component';
import { AddmachineReadingComponent } from './addmachine-reading/addmachine-reading.component';
import { UserManagmentComponent } from './pages/user-managment/user-managment.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import { SmsVerifyComponent } from './sms-verify/sms-verify.component';
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    MachinereadingComponent,
    PaymentComponent,
    ContactComponent,
    UsermgmtComponent,
    MyprofileComponent,
    EditProfileComponent,
    BuySubscriptionComponent,
    LogoutComponent,
    LogoutModalComponent,
    SelectpetrolpumpComponent,
    AddnewMachine,
    AddmachineReadingComponent,
    UserManagmentComponent,
    SignUpComponent,
    SmsVerifyComponent,
    
  ],
  imports: [Ng4LoadingSpinnerModule,ToastrModule.forRoot(),MatCheckboxModule,MatSlideToggleModule,MatDialogModule,
    BrowserModule,HttpClientModule, NgxStripeModule.forRoot('pk_test_APnREw1iEmZmCsR2JZQNjYbt00SL22MZy6'),MatTableModule,NgxPaginationModule,
    MatAutocompleteModule,FormsModule,MatCardModule,MatButtonModule,MatGridListModule,MatInputModule,MatFormFieldModule,MatIconModule,MatToolbarModule,
    ReactiveFormsModule,MatSortModule,MatSidenavModule,MatSelectModule,MatRadioModule,
    AppRoutingModule,HttpClientModule,MatListModule,
    BrowserAnimationsModule
  ],
  entryComponents: [
    LogoutModalComponent,AddnewMachine,
  ],
  exports: [
    MatAutocompleteModule,MatCardModule,MatSortModule,
  ],
  providers: [CookieService,],
  bootstrap: [AppComponent]
})
export class AppModule { }
