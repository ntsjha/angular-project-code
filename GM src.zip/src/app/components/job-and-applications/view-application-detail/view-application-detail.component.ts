import { NgxSpinnerService } from 'ngx-spinner';
import { ActivatedRoute } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { ServiceService } from 'src/app/service/service.service';

@Component({
  selector: 'app-view-application-detail',
  templateUrl: './view-application-detail.component.html',
  styleUrls: ['./view-application-detail.component.css']
})
export class ViewApplicationDetailComponent implements OnInit {

  paramData: any;
  applicationDetail: any;
  constructor(
    private activatedRoute: ActivatedRoute,
    private service: ServiceService,
    private spinner: NgxSpinnerService
  ) { }

  ngOnInit() {
    this.getParamData();
    window.scrollTo(0, 0);
  }

  getParamData() {
    this.activatedRoute.params.subscribe(param => {
      this.paramData = param;
      this.getApplicationDetail();
    });
  }

  getApplicationDetail() {
    this.spinner.show();
    this.service.getMethod(`career/admin/get-job-application-details?applicationId=${encodeURIComponent(this.service.encrypt(this.paramData.applicationId))}`, 1).subscribe((success: any) => {
      this.spinner.hide();
      this.applicationDetail = success.data ? JSON.parse(this.service.decrypt(success.data)) : {};
      this.getBase64Func(this.applicationDetail.data.file);
    }, error => {
      this.spinner.hide();
    });
  }

  getBase64Func(img) {
    this.applicationDetail.data.file = '';
    this.spinner.show();
    if (img) {
      this.service.getMethod('account/convert-image-base64?imageUrl=' + this.service.imageUrl + img, 1).subscribe((res: any) => {
        this.spinner.hide();
      }, error => {
        if (error && error.error.text) {
          this.spinner.hide();
          this.applicationDetail.data.file = 'data:image/jpg;base64,' + error.error.text;
        }

      });
    }
  }

  openImg() {
    var url = this.applicationDetail.data.file.replace(/^data:image\/[^;]+/, 'data:application/octet-stream');
    window.open(url);
  }

}
