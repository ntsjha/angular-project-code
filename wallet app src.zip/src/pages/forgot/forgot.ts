import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ModalController } from 'ionic-angular';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ServiceServicesProvider } from '../../providers/service-services/service-services';
import { ChangepassPage } from "../changepass/changepass";
import { ResetPage } from "../reset/reset";
import { LoginPage } from '../login/login';
import { ResetPinPage } from "../reset-pin/reset-pin";

@IonicPage()
@Component({
  selector: 'page-forgot',
  templateUrl: 'forgot.html',
})
export class ForgotPage {
  last: any;
  form: FormGroup
  constructor(public navCtrl: NavController, public navParams: NavParams, private server: ServiceServicesProvider, public modalCtrl: ModalController, ) {
  }

  ngOnInit() {
    this.form = new FormGroup({
      email: new FormControl('', [Validators.required, Validators.pattern(/^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/i)]),
    })
    this.last = this.navParams.get('forgot')
  }

  get email(): any {
    return this.form.get('email')
  }


  forget() {
    if (navigator.onLine) {
      this.server.presentLoading();
      let data = {
        'email': this.form.value.email
      }
      this.server.postApi(data, 'user/forgotPassword', 0).subscribe((response: any) => {
        this.server.dismissLoading();
        if (response.response_code == 201) {
          localStorage.setItem('userId', response.result[0])
          let modalPage = this.modalCtrl.create('ModalPage', {via: 'EMAIL'});
          modalPage.present();
          modalPage.onDidDismiss((data) => {
            if (data != 'failure') {
              if (this.navParams.get('forgot') == 'PIN')
                this.navCtrl.push(ResetPinPage)
              else
                this.navCtrl.push(ResetPage);
            }
          });
        } else {
          this.server.presentToast(response.response_message)
        }
      }, err => {
        this.server.dismissLoading();
        this.server.presentToast('Something went wrong')
      })
    } else
      this.server.presentToast('Your internet connection seems to be lost')
  }

  signin() {
    this.navCtrl.pop();
  }

  back() {
    this.navCtrl.pop();
  }
}
