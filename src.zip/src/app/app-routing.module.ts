import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { MachinereadingComponent } from './machinereading/machinereading.component';
import { PaymentComponent } from './payment/payment.component';
import { ContactComponent } from './contact/contact.component';
import { UsermgmtComponent } from './usermgmt/usermgmt.component';
import { MyprofileComponent } from './myprofile/myprofile.component';
import { EditProfileComponent } from './edit-profile/edit-profile.component';
import { BuySubscriptionComponent } from './buy-subscription/buy-subscription.component';
import { LogoutComponent } from './logout/logout.component';
import { SelectpetrolpumpComponent } from './selectpetrolpump/selectpetrolpump.component';
import { AddmachineReadingComponent } from './addmachine-reading/addmachine-reading.component';
import { UserManagmentComponent } from './pages/user-managment/user-managment.component';
import { SignUpComponent } from './sign-up/sign-up.component';

const routes: Routes = [
  {path: 'home', component: HomeComponent,
  children: [
    {path: 'myprofile', component: MyprofileComponent}, 

{path: 'editprofile', component: EditProfileComponent}
  ]},
 { path: '',
    redirectTo: '/login',
    pathMatch: 'full'
},

{ path : 'signUp', component: SignUpComponent},
{ path: 'login',        component: LoginComponent },
{path: 'machinereading', component: MachinereadingComponent}, 
{path: 'payment', component: PaymentComponent},
{path: 'contact', component: ContactComponent}, 
{path: 'usermgmt', component: UsermgmtComponent}, 
{path: 'editprofile', component: EditProfileComponent}, 
{path: 'buysubscription', component: BuySubscriptionComponent}, 
{path: 'logout', component: LogoutComponent},
{path: 'selectpetrolpump', component: SelectpetrolpumpComponent},
{path: 'addmachinereading', component: AddmachineReadingComponent}, 

{path: 'usermanagement', component: UserManagmentComponent}, 
]
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
