import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-fiathistory',
    templateUrl: './fiathistory.component.html',
    styleUrls: ['./fiathistory.component.css']
})
export class FiathistoryComponent implements OnInit {

    constructor() { }

    ngOnInit() {
        window.scrollTo(0, 0);
    }

}
