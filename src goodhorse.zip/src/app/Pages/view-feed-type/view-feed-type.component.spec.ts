import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewFeedTypeComponent } from './view-feed-type.component';

describe('ViewFeedTypeComponent', () => {
  let component: ViewFeedTypeComponent;
  let fixture: ComponentFixture<ViewFeedTypeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewFeedTypeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewFeedTypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
