import { MarketPanelSideBar } from './sidebarData.model';

export const sideBarDataSuperAdmin: MarketPanelSideBar[] = [
  {
    name: 'Dashboard',
    icon: 'fa fa-dashboard',
    subtopic: [],
    url: '',
    routing: 'dashboard'
  },
  {
    name: 'Roles & Permissions',
    icon: 'fa fa-book',
    subtopic: [],
    url: '',
    routing: 'roles-and-permissions'
  },
  {
    name: 'Manage Approvals',
    icon: 'fa fa-book',
    subtopic: [],
    url: '',
    routing: 'manage-approvals'
  },

  {
    name: 'Manage Administrator',
    icon: 'fa fa-users',
    subtopic: [],
    url: '',
    routing: 'manage-administrator'
  },
  {
    name: 'Logs',
    icon: 'fa fa-list',
    subtopic: [],
    url: '',
    routing: 'logs'
  },

];

export const sideBarDataArr: MarketPanelSideBar[] = [
  {
    name: 'Dashboard',
    icon: 'fa fa-dashboard',
    subtopic: [],
    url: '',
    routing: 'dashboard'
  },
  {
    name: 'Manage Customers',
    icon: 'fa fa-users',
    subtopic: [],
    url: 'manageCustomers',
    routing: 'manage-customers'
  },
  {
    name: '2FA Request',
    icon: 'fa fa-book',
    subtopic: [],
    url: 'manage2FaRequest',
    routing: 'fa-reset-detail'
  },
  {
    name: 'Bank Registrations',
    icon: 'fa fa-book',
    subtopic: [],
    url: 'manageBankRegistration',
    routing: 'manage-bank-registration'
  },
  {
    name: 'KYC',
    icon: 'fa fa-book',
    subtopic: [],
    url: 'manageKyc',
    routing: 'customers-kyc'
  },
  {
    name: 'Withdrawal Request',
    icon: 'fa fa-money',
    subtopic: [{
      subTopicName: 'Crypto Withdrawal',
      icon: 'fa fa-google-wallet',
      routing: 'crypto-withdrawl-req',
      url: 'crytoWithdrawalRequest'
    },
    {
      subTopicName: 'FIAT Withdrawal',
      icon: 'fa fa-money',
      routing: 'fiat-withdrawl-req',
      url: 'fiatWithdrawalRequest'
    }],
    url: 'manageWithdrawalRequest',
    routing: ''
  },
  {
    name: 'FIAT Deposit',
    icon: 'fa fa-money',
    subtopic: [{
      subTopicName: 'Request Pending',
      icon: 'fa fa-google-wallet',
      routing: 'fiat-deposit-req',
      url: 'depositMatching'
    },
    {
      subTopicName: 'Request Approval',
      icon: 'fa fa-money',
      routing: 'fiat-deposit-req',
      url: 'approve/RejectDepositRequest'
    }],
    url: 'manageFiatDeposit',
    routing: ''
  },
  {
    name: 'Support',
    icon: 'fa fa-users',
    subtopic: [{
      subTopicName: 'Inquiry',
      icon: 'fa fa-google-wallet',
      routing: 'inquiries',
      url: 'manageContactInquiries'
    },
    {
      subTopicName: 'Tickets',
      icon: 'fa fa-list',
      routing: 'tickets',
      url: 'manageSupport'
    }],
    url: 'manageSupport',
  },
  {
    name: 'Transactions',
    icon: 'fa fa-exchange',
    subtopic: [],
    url: 'transactions',
    routing: 'transfer-history'
  },
  // {
  //   name: 'Orders',
  //   icon: 'fa fa-list',
  //   routing: '',
  //   subtopic: [
  //     {
  //       subTopicName: 'Trade History',
  //       icon: 'fa fa-google-wallet',
  //       routing: '',
  //       url: 'tradeHistory'
  //     },
  //     {
  //       subTopicName: 'Open Orders',
  //       icon: 'fa fa-money',
  //       routing: '',
  //       url: 'openOrders'
  //     },
  //     {
  //       subTopicName: 'Order History',
  //       icon: 'fa fa-arrow-right',
  //       routing: '',
  //       url: 'orderHistory'
  //     },
  //   ],
  //   url: 'orders',

  // },
  {
    name: 'Export',
    icon: 'fa fa-user',
    subtopic: [{
      subTopicName: 'IM History',
      icon: 'fa fa-money',
      routing: '',
      url: ''
    },
    {
      subTopicName: 'Tickets',
      icon: 'fa fa-arrow-right',
      routing: '',
      url: ''
    }],
    url: '',
    routing: ''
  },

  // {
  //   name: 'Reports',
  //   icon: 'fa fa-file-text',
  //   subtopic: [{
  //     subTopicName: 'Deposit',
  //     icon: 'fa fa-money',
  //     routing: 'report-deposit',
  //     url: 'depsositHistory'
  //   },
  //   {
  //     subTopicName: 'Withdrawal',
  //     icon: 'fa fa-arrow-right',
  //     routing: 'report-withdraw',
  //     url: 'withdrawal'
  //   }, {
  //     subTopicName: 'Trade History',
  //     icon: 'fa fa-money',
  //     routing: '',
  //     url: ''
  //   },
  //   {
  //     subTopicName: 'FIAT Deposit',
  //     icon: 'fa fa-arrow-right',
  //     routing: '',
  //     url: 'depsositHistory'
  //   }, {
  //     subTopicName: 'FIAT Withdrawal',
  //     icon: 'fa fa-money',
  //     routing: '',
  //     url: 'withdrawal'
  //   },
  //   {
  //     subTopicName: 'Transactions',
  //     icon: 'fa fa-arrow-right',
  //     routing: 'transfer-history',
  //     url: 'transactionHistory'
  //   }, 
  //   {
  //     subTopicName: 'Commissions',
  //     icon: 'fa fa-money',
  //     routing: 'report-commission',
  //     url: 'commissions'
  //   }],
  //   url: 'reports',
  //   routing: ''
  // },
  {
    name: 'Market Makers',
    icon: 'fa fa-exchange',
    subtopic: [],
    url: '',
    routing: ''
  },


  {
    name: 'OTC',
    icon: 'fa fa-cog',
    routing: 'settingall',
    subtopic: [{
      subTopicName: 'Inbox',
      icon: 'fa fa-money',
      routing: '',
      url: ''
    },
    {
      subTopicName: 'OTC Request',
      icon: 'fa fa-arrow-right',
      routing: 'transfer-history',
      url: ''
    }, {
      subTopicName: 'Customers',
      icon: 'fa fa-money',
      routing: '',
      url: ''
    }],
    url: 'settingall'
  },

  {
    name: 'Jobs',
    icon: 'fa fa-money',
    subtopic: [],
    url: 'careers',
    routing: 'jobs'
  },

  {
    name: 'Roles & Permissions',
    icon: 'fa fa-book',
    subtopic: [],
    url: '',
    routing: 'roles-and-permissions'
  },
  {
    name: 'Manage Approvals',
    icon: 'fa fa-book',
    subtopic: [],
    url: '',
    routing: 'manage-approvals'
  },

  {
    name: 'Manage Administrator',
    icon: 'fa fa-users',
    subtopic: [],
    url: '',
    routing: 'manage-administrator'
  },


  {
    name: 'Manage Staff',
    icon: 'fa fa-users',
    subtopic: [],
    url: 'manageStaff',
    routing: 'manage-staff'
  },
  {
    name: 'Manage Customer',
    icon: 'fa fa-users',
    subtopic: [],
    url: 'manageCustomer',
    routing: 'manage-customer'
  },
  {
    name: 'Manage Site Content',
    icon: 'fa fa-file-text',
    subtopic: [],
    url: 'manageStaticContent',
    routing: 'manage-site-content'
  },
  {
    name: 'OTC',
    icon: 'fa fa-flag',
    subtopic: [
      {
        subTopicName: 'Working Hours',
        icon: 'fa fa-flag',
        routing: '',
        url: ''
      },
      {
        subTopicName: 'Desk Operators',
        icon: 'fa fa-flag',
        routing: '',
        url: ''
      },
      {
        subTopicName: 'Settings',
        icon: 'fa fa-cog',
        routing: '',
        url: ''
      },
    ],
    url: ''
  },
  {
    name: 'Exchange Wallet Management',
    icon: 'fa fa-money',
    routing: '',
    subtopic: [
      {
        subTopicName: 'Main Wallet',
        icon: 'fa fa-flag',
        routing: 'manage-exchange-wallet',
        url: 'exchangeWalletManagement'
      },
      {
        subTopicName: 'Fee Wallet',
        icon: 'fa fa-flag',
        routing: 'manage-exchange-fee-wallet',
        url: 'exchangeWalletManagement'
      },
      {
        subTopicName: 'Withdrawal History',
        icon: 'fa fa-flag',
        routing: 'transfer-history',
        url: 'exchangeWalletManagement'
      },
    ],
    url: 'exchangeWalletManagement',

  },
  {
    name: 'Withdrawal Settings',
    icon: 'fa fa-cog',
    routing: '',
    subtopic: [
      {
        subTopicName: 'Crypto Withdrawal',
        icon: 'fa fa-flag',
        routing: 'mimimum-withdrawl-crypto-sidebar',
        url: 'withdrawalSetting'
      },
      {
        subTopicName: 'Fiat Withdrawal',
        icon: 'fa fa-flag',
        routing: 'mimimum-withdrawl-fiat-sidebar',
        url: 'withdrawalSetting'
      },
    ],
    url: 'withdrawalSetting'
  },

  {
    name: 'Settings',
    icon: 'fa fa-cog',
    routing: 'settingall',
    subtopic: [],
    url: 'settings'
  },
  {
    name: 'Manage Notification',
    icon: 'fa fa-bell',
    routing: 'manage-notification',
    subtopic: [],
    url: 'manageNoitification'
  },
  {
    name: 'Export',
    icon: 'fa fa-flag',
    routing: '',
    subtopic: [
      {
        subTopicName: 'Schedule',
        icon: 'fa fa-flag',
        routing: 'export',
        url: 'exportSchedule'
      },
    ],
    url: 'exportSchedule'
  },

  {
    name: 'Logs',
    icon: 'fa fa-list',
    routing: '',
    subtopic: [
      {
        subTopicName: 'Customer Log',
        icon: 'fa fa-flag',
        routing: 'activity-log',
        url: 'viewCustomerLog'
      },
      {
        subTopicName: 'Staff Log',
        icon: 'fa fa-flag',
        routing: 'staff-log',
        url: 'viewStafflogs'
      },
      
    ],
    url: 'logs'
  },
  {
    name: 'Manage Banners',
    icon: 'fa fa-book',
    subtopic: [],
    url: 'manageBanners',
    routing: 'manage-banners'
  },
  {
    name: 'Manage Blog',
    icon: 'fa fa-book',
    routing: 'blog-management',
    subtopic: [],
    url: 'blogs'
  },
  {
    name: 'Manage Event',
    icon: 'fa fa-book',
    routing: 'event-management',
    subtopic: [],
    url: 'events'
  },
  {
    name: 'Promotions',
    icon: 'fa fa-book',
    routing: 'promotion-management',
    url: 'rewardsPromotion',
    subtopic: [],
  },
  {
    name: 'Offers',
    icon: 'fa fa-book',
    routing: 'offer-management',
    url: 'offers',
    subtopic: [],
  },
  {
    name: 'Customers',
    icon: 'fa fa-users',
    routing: 'reward-customer-list',
    url: 'rewardCustomerList',
    subtopic: [],
  },
  {
    name: 'Reward Transaction',
    icon: 'fa fa-list',
    routing: 'reward-transaction',
    url: 'rewardTransactionList',
    subtopic: [],
  },
  {
    name: 'OTC',
    icon: 'fa fa-flag',
    subtopic: [
      {
        subTopicName: 'Settings',
        icon: 'fa fa-cog',
        routing: '',
        url: ''
      },
      {
        subTopicName: 'Promotions',
        icon: 'fa fa-flag',
        routing: '',
        url: ''
      },
    ],
    url: ''
  },
  {
    name: 'Rewards',
    icon: 'fa fa-money',
    subtopic: [
      {
        subTopicName: 'Settings',
        icon: 'fa fa-cog',
        routing: 'reward-setting-sidebar',
        url: 'rewards'
      },
    ],
    url: 'rewards'
  },
  {
    name: 'OTC',
    icon: 'fa fa-money',
    subtopic: [
      {
        subTopicName: 'Settings',
        icon: 'fa fa-cog',
        routing: 'otc-setting',
        url: 'rewards'
      },
      {
        subTopicName: 'Promotion',
        icon: 'fa fa-cog',
        routing: 'otc-promotion',
        url: 'rewards'
      },
    ],
    url: 'rewards'
  },

];

// report-fiat-deposit
// report-fiat-withdraw