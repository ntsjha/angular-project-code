import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TraddetailComponent } from './traddetail.component';

describe('TraddetailComponent', () => {
  let component: TraddetailComponent;
  let fixture: ComponentFixture<TraddetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TraddetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TraddetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
