import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';

@Injectable()
export class AuthGuard implements CanActivate {
    constructor(private router: Router) {}
  
    /** Function for checking the token before routing */
    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot){
        let url = state.url.slice(1,state.url.length);
        if (localStorage.getItem('token')) {            
            if(url.includes("login")  || url == "forgetpassword" || url.includes("signup") || url.includes("resetpassword") || url.includes("newUser")) {
                this.router.navigate(['']);                
            }
            return true;
        } else {
            if(url.includes("login") || url == "forgetpassword" || url.includes("signup") || url.includes("resetpassword") || url.includes("newUser")) {
                return true;                
            } else {
                this.router.navigate(['']);
                return false;
            }
        }        
    }
}
