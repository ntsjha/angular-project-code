import { Component, OnInit } from '@angular/core';
import { Angular5Csv } from 'angular5-csv/Angular5-csv';
import { AppComponent } from '../../../app.component';
import { ServerService } from '../../../service/server.service';
import { Ng4LoadingSpinnerService } from '../../../../../node_modules/ng4-loading-spinner';
import { HeaderComponent } from '../../header/header/header.component';
import { DatePipe } from '@angular/common';
import { Router } from '@angular/router';

@Component({
  selector: 'app-usdtransaction',
  templateUrl: './usdtransaction.component.html',
  styleUrls: ['./usdtransaction.component.css']
})
export class UsdtransactionComponent implements OnInit {
    withdrawArr: any = [];
    depositArr: any = [];
    p: any = 1;
    page: any = 1;
    tab: any = 'deposit';

    constructor( private appC: AppComponent, private server: ServerService, private spinnerService: Ng4LoadingSpinnerService, public header: HeaderComponent, public datepipe: DatePipe, private router: Router) { }

    ngOnInit() {
        window.scrollTo(0, 0);
        this.activeTab('deposit');
    }

    activeTab(tab) {
        this.tab = tab;
        if(this.tab == 'deposit') {
            this.getConversionHistory();
        } else {
            this.page = 1;
            this.getWithdrawHistory();
        }

    }

    exportData() {
        let data = [];
        data.push({
            TransactionID: "Transaction Id",
            Coin: "Coin Symbol",
            Units: "Units",
            Status: "Status",
            Date: "Date & Time"
        });
        this.withdrawArr.forEach((obj) => {
            data.push({
                TransactionID: obj.txnId,
                Coin: obj.coinType,
                Units: obj.units,
                Status: obj.status,
                Date: this.convertFormat(obj.txnTime),
            });
        });
        new Angular5Csv(data, 'Bittnomy Withdraw History Report');
    }

    /** Function to convert date format */
    convertFormat(time) {
        return this.datepipe.transform(time, 'MM/dd/yyy, hh:mm a');
    }

    getWithdrawHistory() {
        let data = {
            "eventExternal": {
                "name": "withdrawlist_history",
                "key": "mykey"
            },
            "transferObjectMap": {
                "gatewayrequest": {
                    "coinType": 'USD',
                    "token": localStorage.getItem("token")
                }
            }
        }
        this.spinnerService.show();
        this.server.postApi('', data,0).subscribe(response => {
            this.spinnerService.hide();
            if (response.transferObjectMap.statusCode == 200) {
                this.withdrawArr = response.transferObjectMap.withdraws;
            } else if(response.transferObjectMap.statusCode == 403){
                this.appC.showErrToast(response.transferObjectMap.message); 
                this.header.tokenExpire();
            } else {
                this.appC.showErrToast(response.transferObjectMap.message);                     
            }
        }, error => {
            this.spinnerService.hide();
            this.appC.showErrToast('Something went wrong');
        });      
    }

    getConversionHistory() {
        let data = {
            "eventExternal": {
                "name":"get_currency_conversion_detail",
                "key":"mykey"
            },
           "transferObjectMap": {
                "gatewayrequest": {
                    "userId": localStorage.getItem("userId"),
                    "loginToken": localStorage.getItem("token")
                        
                }
            }
        }
        this.spinnerService.show();
        this.server.postApi('', data,0).subscribe(response => {
            this.spinnerService.hide();
            if (response.transferObjectMap.statusCode == 200) {
                this.depositArr = response.transferObjectMap.result;
            } else if(response.transferObjectMap.statusCode == 403){
                this.appC.showErrToast(response.transferObjectMap.message); 
                this.header.tokenExpire();
            } else {
                this.appC.showErrToast(response.transferObjectMap.message);                     
            }
        }, error => {
            this.spinnerService.hide();
            this.appC.showErrToast('Something went wrong');
        });      
    }
 
    backToPage() {
        this.router.navigateByUrl("header/wallet");
    }

    pageChange(val)  {
        this.page = val;
        this.getWithdrawHistory();
    }

    changePage(val)  {
        this.p = val;
        this.getConversionHistory();
    }
  


}
