import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageExchangeWalletComponent } from './manage-exchange-wallet.component';

describe('ManageExchangeWalletComponent', () => {
  let component: ManageExchangeWalletComponent;
  let fixture: ComponentFixture<ManageExchangeWalletComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManageExchangeWalletComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageExchangeWalletComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
