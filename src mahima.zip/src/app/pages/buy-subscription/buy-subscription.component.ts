import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-buy-subscription',
  templateUrl: './buy-subscription.component.html',
  styleUrls: ['./buy-subscription.component.css']
})
export class BuySubscriptionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
