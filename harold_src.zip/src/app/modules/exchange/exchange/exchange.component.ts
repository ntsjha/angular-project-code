import { Component, OnInit,  } from '@angular/core';
import { ServerService } from '../../../server.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { AppComponent } from '../../../app.component';
import { Router } from '@angular/router';
import { ExheaderComponent } from '../../exheader/exheader/exheader.component';

declare var $: any;
declare const AmCharts: any;
declare const TradingView: any;
declare const Datafeeds: any;


@Component({
    selector: 'app-exchange',
    templateUrl: './exchange.component.html',
    styleUrls: ['./exchange.component.css']
})
export class ExchangeComponent implements OnInit {

    button: boolean;
    coinList = [] ;
    buyOrderList = [] ;
    sellOrderList = [];
    tradeHistoryList = [];
    coinPairList = [];
    openOrderList = [];
    orderHistoryList = [];
    currSelectedCoinObj = {coin:"",coinID:""};
    currSelectedPairObj = {coin:"",coinID:""};
    searchText: string = '';
    regexForPrice = (/^[0-9]+(\.[0-9]{1,8})?$/);
    regexForAmount = (/^[0-9]+(\.[0-9]{1,8})?$/);
    marketEstimateAmount: any;
    marketEstimatePrice: any;
    marketSellPrice: number;
    marketBuyPrice: number;
    baseWalletBalance: any = "";
    exeWalletBalance: any = "";
    limitbuytotal: number;
    limitselltotal: number;
    sLimitBuy: any = {'buyStop':'','buyLimit':'','buyAmount':''}
    sLimitSell: any = {'sellStop':'','sellLimit':'','sellAmount':''}
    lastPrice: any;
    myTab: string = 'buy_market';
    myTab1: string = 'buy';
    ra: any = 'open';
    tickerData = [] ;
    orderBookData = [] ;
    regexForEightChar = (/^(\d+)?([.]?\d{0,8})?$/);

    /** Var for buy/sell form */
    limitBuyObj = {price:"", amount:""};
    limitSellObj = {price:"", amount:""};
    marketBuyObj = {amount:""};
    marketSellObj = {amount:""};
    sLimitBuyObj = {stop:"", price:"", amount:""};
    sLimitSellObj = {stop:"", price:"", amount:""};
    limitBuyTotal = "";
    limitSellTotal = "";
    marketBuyTotal = "";
    marketSellTotal = "";
    stopBuyTotal = "";
    stopSellTotal = "";
    tradeViewPair = "";
    currGraph = "";
    headerPriceObj = {currPrice:"", highest:"", average:"", lowest:"", volume:""};
    messageUnsubscribeArray: any = ['UNSUBSCRIBE_TICKER','UNSUBSCRIBE_ORDER_BOOK','UNSUBSCRIBE_TRADE_HISTORY'];
    messageSubscribeArray: any = ['SUBSCRIBE_TICKER','SUBSCRIBE_ORDER_BOOK','SUBSCRIBE_TRADE_HISTORY'];
    coin: any ='';

    constructor(private server: ServerService, private spinner: Ng4LoadingSpinnerService, private appC: AppComponent, private router: Router, private header: ExheaderComponent) {
        var self = this;
        this.server.wsExchange.addEventListener('message', function (event) {
                var data = JSON.parse(event.data);
                if(data.messageType == 'TICKER_UPDATE') {
                    if(data.symbol == self.currSelectedPairObj.coin + "_" + self.currSelectedCoinObj.coin) {
                        self.headerPriceObj = {currPrice:"", highest:"", average:"", lowest:"", volume:""};
                        self.headerPriceObj.currPrice = data.data.lastPrice;
                        self.headerPriceObj.highest = data.data.highest24HourPrice;
                        self.headerPriceObj.lowest = data.data.lowest24HourPrice;
                        self.headerPriceObj.volume = data.data.totalVolume;
                        self.headerPriceObj.average = data.data.volume24Hour;
                    } 
                    if(data.symbol.split('_')[1] == self.currSelectedCoinObj.coin) {
                        var exe = data.symbol.split('_')[0];
                        let ind = self.coinPairList.findIndex((x) => x.coinShortName == exe);
                        self.coinPairList[ind].volume = data.data.totalVolume;
                        self.coinPairList[ind].average = data.data.highest24HourPrice;
                        self.coinPairList[ind].price = data.data.lastPrice;
                    } 
                    
                } else if(data.messageType == 'ORDER_BOOK_UPDATE') {
                    let dataArray = data;
                    dataArray.data.forEach(element => {
                        if(element.side == 'BUY') {
                            var ind = self.buyOrderList.findIndex((x) => x.price == element.price);
                            if(ind != -1) {
                                self.buyOrderList[ind].amount = (Number(self.buyOrderList[ind].amount) + Number(element.amount));
                                if(self.buyOrderList[ind].amount <= 0) {
                                    self.buyOrderList.splice(ind,1);
                                    return;
                                } else {
                                    self.buyOrderList[ind].total = (self.buyOrderList[ind].price * self.buyOrderList[ind].amount);
                                }
                                
                            } else {
                                self.buyOrderList.push({
                                    price: element.price,
                                    amount: element.amount,
                                    total: (element.price*element.amount)
                                });
                            }
                        } else if(element.side == 'SELL') {
                            var ind = self.sellOrderList.findIndex((x) => x.price == element.price);
                            if(ind != -1) {
                                self.sellOrderList[ind].amount = (Number(self.sellOrderList[ind].amount) + Number(element.amount));
                                if(self.sellOrderList[ind].amount <= 0) {
                                    self.sellOrderList.splice(ind,1);
                                    return;
                                } else {
                                    self.sellOrderList[ind].total = (self.sellOrderList[ind].price * self.sellOrderList[ind].amount);
                                }
                                
                            } else {
                                self.sellOrderList.push({
                                    "price"     : element.price,
                                    "amount"    : element.amount,
                                    "total"     : (element.price * element.amount).toFixed(8),
                                }) ;
                            }
                        }
                    });
                } else if(data.messageType == 'TRADE_HISTORY_UPDATE') {
                    data.data.forEach(element => {
                        self.tradeHistoryList.push({
                            total : (element.price*element.amount),
                            price : element.price,
                            amount : element.amount,
                            side : element.side,
                        }) 
                    });
                }   
        });
    }

    ngOnInit() {
        this.getCoinList();
        this.loginFunc();
        this.selectGraph('trading');
        this.header.getprofile();
    }

    selectGraph(val) {
        this.currGraph = val;
        switch(val) {
            case 'depth':
                this.drawDepthChart();
                break;
            case 'trading':
                this.drawTradingChart();
                break;
        }

    }

    ngOnDestroy() {
        let data1 = {
            messageType:'UNSUBSCRIBE_TICKER',
            params: {
                symbol:this.currSelectedPairObj.coin+'_'+this.currSelectedCoinObj.coin
            }
        }
        this.server.wsExchange.send(JSON.stringify(data1));
        let data2 = {
            messageType:'UNSUBSCRIBE_ORDER_BOOK',
            params: {
                symbol:this.currSelectedPairObj.coin+'_'+this.currSelectedCoinObj.coin
            }
        }
        this.server.wsExchange.send(JSON.stringify(data2));
        let data3 = {
            messageType:'UNSUBSCRIBE_TRADE_HISTORY',
            params: {
                symbol:this.currSelectedPairObj.coin+'_'+this.currSelectedCoinObj.coin
            }
        }
        this.server.wsExchange.send(JSON.stringify(data3));
    }

    loginFunction() {
        this.router.navigate(['login']);
    }

    signupFunction() {
        this.router.navigate(['signup']);
    }

    /** Function to get coin list */
    getCoinList() { 
        this.spinner.show();
        this.server.getApi('wallet/coin/get-coin-list').subscribe (res => {
            this.spinner.hide();
            res.data.forEach(element => {
                if(element.coinShortName == 'BTC' || element.coinShortName == 'ETH' || element.coinShortName == 'USDT' ||element.coinShortName == 'HGG')
                this.coinList.push({
                    coinId : element.coinId,
                    coinShortName : element.coinShortName,
                    coinFullName : element.coinFullName,

                })
            });
            
            if(this.coinList.length) {
                this.currSelectedCoinObj.coin = this.coinList[0].coinShortName;
                localStorage.setItem('baseCoin',this.currSelectedCoinObj.coin);
                this.currSelectedCoinObj.coinID = this.coinList[0].coinId;
                if(localStorage.getItem('token')) {
                    this.getBaseCoinBalance();
                }
                this.getpaircoinList(); 
            }
        }, err => {
            this.spinner.hide();
            this.appC.showErrToast(err.error.message);

        });  
    }

    /** Function to get coin pair list */
    getpaircoinList() {
        this.coinPairList = [];
        this.spinner.show();
        this.server.getApi('wallet/coin/get-symbol-list?baseCoin='+this.currSelectedCoinObj.coin).subscribe (res => {
            this.spinner.hide();
            if(res.data != undefined) {
                res.data.forEach(element => {
                    this.coinPairList.push({
                        "coinId": element.coinPairId,
                        "coinShortName": element.executableCoin,
                        "price":'',
                        "volume":'',
                        "average":'',
                    });
                    this.subsribeCoinPairList(element.executableCoin);
                });
            }
            

            /**To unsubsribe previous pair */
            if(this.tradeViewPair != '') {
                for(let i = 0; i < this.messageUnsubscribeArray.length; i++){
                    let data = {
                        messageType:this.messageUnsubscribeArray[i],
                        params: {
                            symbol:this.currSelectedPairObj.coin+'_'+this.currSelectedCoinObj.coin
                        }
                    }
                    this.server.wsExchange.send(JSON.stringify(data));
                }
            }
            if(this.coinPairList.length) {
                this.coinPairList[0].selected = true;
                this.currSelectedPairObj.coinID = this.coinPairList[0].coinId;
                this.currSelectedPairObj.coin = this.coinPairList[0].coinShortName;
                localStorage.setItem('exeCoin',this.currSelectedPairObj.coin);
                this.tradeViewPair = this.currSelectedPairObj.coin + "_" + this.currSelectedCoinObj.coin;
                
                if(localStorage.getItem('token')) {
                    this.getOpenOrder();
                    this.getOrderHistory();
                    this.getExeCoinBalance();
                }
                this.drawTradingChart();
                this.drawDepthChart();
            }
            
            for(let i = 0; i < this.messageSubscribeArray.length; i++) {
                let data = {
                    messageType:this.messageSubscribeArray[i],
                    params: {
                        symbol:this.currSelectedPairObj.coin+'_'+this.currSelectedCoinObj.coin
                    }
                }
                this.server.wsExchange.send(JSON.stringify(data));
            }
            
        }, err => {
            this.spinner.hide();
            this.appC.showErrToast(err.error.message);

        });  
    }

    /**Function to subsribe coin pair list data */
    subsribeCoinPairList(coin) {
        this.coin = coin;
        let data = {
            messageType:'SUBSCRIBE_TICKER',
            params: {
                symbol:coin+'_'+this.currSelectedCoinObj.coin
            }
        }
        this.server.wsExchange.send(JSON.stringify(data));
        
        
    }

    /** Function to select coin */
    selectCoin(coin) {
        this.searchText = "";
        for(let i = 0; i < this.messageUnsubscribeArray.length; i++){
            let data = {
                messageType:this.messageUnsubscribeArray[i],
                params: {
                    symbol:this.currSelectedPairObj.coin+'_'+this.currSelectedCoinObj.coin
                }
            }
            this.server.wsExchange.send(JSON.stringify(data));
        }
        this.currSelectedCoinObj.coin = coin;
        // this.server.currSelectedCoinObj.coin = this.currSelectedCoinObj.coin;
        localStorage.setItem('baseCoin',this.currSelectedCoinObj.coin);
        let index = this.coinList.findIndex(x=> x.coinShortName == coin) 
        this.currSelectedCoinObj.coinID = this.coinList[index].coinId;
        if(localStorage.getItem('token')) {
            this.getBaseCoinBalance();
        }
        this.buyOrderList = [];
        this.sellOrderList = [];
        this.tradeHistoryList = [];
        this.getpaircoinList();
    }

    /** Function to select coinpair  */
    selectCoinPair(coin) {
        coin.selected = true;
        this.coinPairList.forEach((obj) => {
            if(coin.coinId != obj.coinId)
            obj.selected = false;
        });
        for(let i = 0; i < this.messageUnsubscribeArray.length; i++){
            let data = {
                messageType:this.messageUnsubscribeArray[i],
                params: {
                    symbol:this.currSelectedPairObj.coin+'_'+this.currSelectedCoinObj.coin
                }
            }
            this.server.wsExchange.send(JSON.stringify(data));
        }

        this.currSelectedPairObj.coin = coin.coinShortName;
        localStorage.setItem('exeCoin',this.currSelectedPairObj.coin);
        // this.server.currSelectedPairObj.coin = this.currSelectedPairObj.coin;
        this.currSelectedPairObj.coinID = coin.coinId;
        this.tradeViewPair = this.currSelectedPairObj.coin + "_" + this.currSelectedCoinObj.coin;
        
        
        if(localStorage.getItem('token')) {
            this.getOpenOrder();
            this.getExeCoinBalance();
            this.getOrderHistory();
            
        }
        this.drawTradingChart();
        this.drawDepthChart();
        this.buyOrderList = [];
        this.sellOrderList = [];
        this.tradeHistoryList = [];
        for(let i = 0; i < this.messageSubscribeArray.length; i++) {
            let data = {
                messageType:this.messageSubscribeArray[i],
                params: {
                    symbol:this.currSelectedPairObj.coin+'_'+this.currSelectedCoinObj.coin
                }
            }
            this.server.wsExchange.send(JSON.stringify(data));
        }

    }

    buy_sell(val) {
        if(val == 1) {
            this.myTab1 = 'buy';
            this.myTab = 'buy_market';
            this.marketBuyObj.amount = '';

        } else {
            this.myTab1 = 'sell';
            this.myTab = 'sell_market';
            this.marketSellObj.amount = '';
        }
    }

    buyTab(val) {
        if(val == 1) {
            this.myTab = 'buy_market';
            this.marketBuyObj.amount = '';
        } else if(val == 2){
            this.myTab = 'buy_limit';
            this.limitBuyObj.price = '';
            this.limitBuyObj.amount = '';
            this.limitBuyTotal = '';
        } else if(val == 3){
            this.myTab = 'buy_stopLimit';
            this.sLimitBuyObj.stop = '';
            this.sLimitBuyObj.price = '';
            this.sLimitBuyObj.amount = '';
            this.stopBuyTotal = '';
        } else if(val == 6){
            this.myTab = 'sell_market';
            this.marketSellObj.amount = '';
        } else if(val == 7){
            this.myTab = 'sell_limit';
            this.limitSellObj.price = '';
            this.limitSellObj.amount = '';
            this.limitSellTotal = '';
        } else if(val == 8){
            this.myTab = 'sell_stopLimit';
            this.sLimitSellObj.stop = '';
            this.sLimitSellObj.price = '';
            this.sLimitSellObj.amount = '';
            this.stopSellTotal = '';
        }
    }

    loginFunc() {
        if(localStorage.getItem('token')) {
            this.button = true;
        } else {
            this.button = false;
        }
    }

    myOrder(val) {
        this.ra = val;
    }

    marketBuyFunc() {
        if(this.marketBuyObj.amount == "") {
            this.appC.showErrToast("Enter amount value.");
            return;
        } else if(Number(this.marketBuyObj.amount) <= 0) {
            this.appC.showErrToast("Please enter valid amount.");
            return;
        } else {
            if(this.marketBuyObj.amount < this.baseWalletBalance) {
                this.spinner.show();
                let data = {
                    "orderSide": "BUY",
                    "orderType": "MARKET",
                    "quantity": this.marketBuyObj.amount,
                    "symbol": this.currSelectedPairObj.coin+'_'+this.currSelectedCoinObj.coin
                }
                this.server.postApi('order/place-order',data).subscribe(res => {
                    this.spinner.hide();
                    this.appC.showSuccToast(res.message);
                    this.getOpenOrder();
                    this.getOrderHistory();
                    this.getBaseCoinBalance();
                    this.getExeCoinBalance();
    
                },err =>{
                    this.spinner.hide();
                    this.appC.showErrToast(err.error.error);
    
                });
            } else {
                this.appC.showErrToast("You can't execute the market order because you don't have enough amount to your wallet balance.");
            }
        }
        
    }

    marketSellFunc() {
        if(this.marketSellObj.amount == "") {
            this.appC.showErrToast("Enter amount value.");
            return;
        } else if(Number(this.marketSellObj.amount) <= 0) {
            this.appC.showErrToast("Please enter valid amount.");
            return;
        } else {
            if(this.marketSellObj.amount < this.exeWalletBalance) {
                this.spinner.show();
                let data = {
                    "orderSide": "SELL",
                    "orderType": "MARKET",
                    "quantity": this.marketSellObj.amount,
                    "symbol": this.currSelectedPairObj.coin+'_'+this.currSelectedCoinObj.coin
                }
                this.server.postApi('order/place-order',data).subscribe(res => {
                    this.spinner.hide();
                    this.appC.showSuccToast(res.message);
                    this.getOpenOrder();
                    this.getOrderHistory();
                    this.getBaseCoinBalance();
                    this.getExeCoinBalance();

                },err =>{
                    this.spinner.hide();
                    this.appC.showErrToast(err.error.error);

                }); 
            } else {
                this.appC.showErrToast("You can't execute the market order because you don't have enough amount to your wallet balance.");
            }
        }
    }

    limitBuyOrder() {
        if(this.limitBuyObj.amount == "") {
            this.appC.showErrToast("Enter amount value.");
            return;
        } else if(Number(this.limitBuyObj.amount) <= 0) {
            this.appC.showErrToast("Please enter valid amount.");
            return;
        } if(this.limitBuyObj.price == "") {
            this.appC.showErrToast("Enter price value.");
            return;
        } else if(Number(this.limitBuyObj.price) <= 0) {
            this.appC.showErrToast("Please enter valid price.");
            return;
        } else {
            if(this.limitBuyTotal < this.baseWalletBalance) {
                this.spinner.show();
                let data = {
                    "orderSide": "BUY",
                    "orderType": "LIMIT",
                    "limitPrice": this.limitBuyObj.price,
                    "quantity": this.limitBuyObj.amount,
                    "symbol": this.currSelectedPairObj.coin+'_'+this.currSelectedCoinObj.coin
                }
                this.server.postApi('order/place-order',data).subscribe(res => {
                    this.spinner.hide();
                    this.appC.showSuccToast(res.message);
                    this.getOpenOrder();
                    this.getOrderHistory();
                    this.getBaseCoinBalance();
                    this.getExeCoinBalance();


                },err => {
                    this.spinner.hide();
                    this.appC.showErrToast(err.error.error);
                });
            } else {
                this.appC.showErrToast("You can't buy coins more than your wallet amount.");
            }
        }
    }


    limitSellOrder() {
        if(this.limitSellObj.amount == "") {
            this.appC.showErrToast("Enter amount value.");
            return;
        } else if(Number(this.limitSellObj.amount) <= 0) {
            this.appC.showErrToast("Please enter valid amount.");
            return;
        } if(this.limitSellObj.price == "") {
            this.appC.showErrToast("Enter price value.");
            return;
        } else if(Number(this.limitSellObj.price) <= 0) {
            this.appC.showErrToast("Please enter valid price.");
            return;
        } else {
            if(this.limitSellObj.amount < this.exeWalletBalance) {
                this.spinner.show();
                let data = {
                    "orderSide": "SELL",
                    "orderType": "LIMIT",
                    "limitPrice": this.limitSellObj.price,
                    "quantity": this.limitSellObj.amount,
                    "symbol": this.currSelectedPairObj.coin+'_'+this.currSelectedCoinObj.coin
                }
                this.server.postApi('order/place-order',data).subscribe(res => {
                    this.spinner.hide();
                    this.appC.showSuccToast(res.message);
                    this.getOpenOrder();
                    this.getOrderHistory();
                    this.getBaseCoinBalance();
                    this.getExeCoinBalance();


                },err =>{
                    this.spinner.hide();
                    this.appC.showErrToast(err.error.error);

                });
            } else {
                this.appC.showErrToast("You can't sell coins more than your wallet amount.");
            }
        }

    }

    stopLimitBuyOrder() {
        if(this.sLimitBuyObj.amount == "") {
            this.appC.showErrToast("Enter amount value.");
            return;
        } else if(Number(this.sLimitBuyObj.amount) <= 0) {
            this.appC.showErrToast("Please enter valid amount.");
            return;
        } if(this.sLimitBuyObj.price == "") {
            this.appC.showErrToast("Enter limit value.");
            return;
        } else if(Number(this.sLimitBuyObj.price) <= 0) {
            this.appC.showErrToast("Please enter valid limit value.");
            return;
        } if(this.sLimitBuyObj.stop == "") {
            this.appC.showErrToast("Enter stop value.");
            return;
        } else if(Number(this.sLimitBuyObj.stop) <= 0) {
            this.appC.showErrToast("Please enter valid stop value.");
            return;
        } else {
            if(this.stopBuyTotal < this.baseWalletBalance){
                this.spinner.show();
                let data = {
                    "orderSide": "BUY",
                    "orderType": "STOP_LIMIT",
                    "limitPrice": this.sLimitBuyObj.price,
                    "stopPrice" : this.sLimitBuyObj.stop,
                    "quantity": this.sLimitBuyObj.amount,
                    "symbol": this.currSelectedPairObj.coin+'_'+this.currSelectedCoinObj.coin
                }
                this.server.postApi('order/place-order',data).subscribe(res => {
                    this.spinner.hide();
                    this.appC.showSuccToast(res.message);
                    this.getOpenOrder();
                    this.getOrderHistory();
                    this.getBaseCoinBalance();
                    this.getExeCoinBalance();


                },err =>{
                    this.spinner.hide();
                    this.appC.showErrToast(err.error.error);

                });
            } else {
                this.appC.showErrToast("You can't buy coins more than your wallet amount.");
            }
        }
    }

    stopLimitSellOrder() {
        if(this.sLimitSellObj.amount == "") {
            this.appC.showErrToast("Enter amount value.");
            return;
        } else if(Number(this.sLimitSellObj.amount) <= 0) {
            this.appC.showErrToast("Please enter valid amount.");
            return;
        } if(this.sLimitSellObj.price == "") {
            this.appC.showErrToast("Enter limit value.");
            return;
        } else if(Number(this.sLimitSellObj.price) <= 0) {
            this.appC.showErrToast("Please enter valid limit value.");
            return;
        } if(this.sLimitSellObj.stop == "") {
            this.appC.showErrToast("Enter stop value.");
            return;
        } else if(Number(this.sLimitSellObj.stop) <= 0) {
            this.appC.showErrToast("Please enter valid stop value.");
            return;
        } else {
            if(this.sLimitSellObj.amount < this.exeWalletBalance) {
                this.spinner.show();
                let data = {
                    "orderSide": "SELL",
                    "orderType": "STOP_LIMIT",
                    "limitPrice": this.sLimitSellObj.price,
                    "stopPrice" : this.sLimitSellObj.stop,
                    "quantity": this.sLimitSellObj.amount,
                    "symbol": this.currSelectedPairObj.coin+'_'+this.currSelectedCoinObj.coin
                }
                this.server.postApi('order/place-order',data).subscribe(res => {
                    this.spinner.hide();
                    this.appC.showSuccToast(res.message);
                    this.getOpenOrder();
                    this.getOrderHistory();
                    this.getBaseCoinBalance();
                    this.getExeCoinBalance();


                },err =>{
                    this.spinner.hide();
                    this.appC.showErrToast(err.error.error);

                });
            } else {
                this.appC.showErrToast("You can't sell coins more than your wallet amount.");
            }
        }
    }

    /** Function to restrict space */
    restrictSpace(event) {
        var k = event.charCode;
        if (k === 32) return false;
    }

    /** Function to restrict character */
    restrictChar(event) {
        var k = event.charCode;
        if (event.key === 'Backspace')
            k = 8;
        if (k >= 48 && k <= 57 || k == 8 || k == 46)
            return true;
        else
            return false;    
    }

    /** Function to restrict length after dot */
    restrictLength(type) {
        switch(type) {
            case 1:
                if(this.marketBuyObj.amount.includes(".")) {
                    if (!this.regexForEightChar.test(this.marketBuyObj.amount)) {
                        let tempVal = this.marketBuyObj.amount.split('.');
                        this.marketBuyObj.amount = tempVal[0] + '.' + tempVal[1].slice(0, 8);
                    }
                }
                break;
            case 2:
                if(this.limitBuyObj.price.includes(".")) {
                    if (!this.regexForEightChar.test(this.limitBuyObj.price)) {
                        let tempVal = this.limitBuyObj.price.split('.');
                        this.limitBuyObj.price = tempVal[0] + '.' + tempVal[1].slice(0, 8);
                    }
                }
                break;
            case 3:
                if(this.limitBuyObj.amount.includes(".")) {
                    if (!this.regexForEightChar.test(this.limitBuyObj.amount)) {
                        let tempVal = this.limitBuyObj.amount.split('.');
                        this.limitBuyObj.amount = tempVal[0] + '.' + tempVal[1].slice(0, 8);
                    }
                }
                break;
            case 4:
                if(this.sLimitBuyObj.stop.includes(".")) {
                    if (!this.regexForEightChar.test(this.sLimitBuyObj.stop)) {
                        let tempVal = this.sLimitBuyObj.stop.split('.');
                        this.sLimitBuyObj.stop = tempVal[0] + '.' + tempVal[1].slice(0, 8);
                    }
                }
                break;
            case 5:
                if(this.sLimitBuyObj.price.includes(".")) {
                    if (!this.regexForEightChar.test(this.sLimitBuyObj.price)) {
                        let tempVal = this.sLimitBuyObj.price.split('.');
                        this.sLimitBuyObj.price = tempVal[0] + '.' + tempVal[1].slice(0, 8);
                    }
                }
                break;
            case 6:
                if(this.sLimitBuyObj.amount.includes(".")) {
                    if (!this.regexForEightChar.test(this.sLimitBuyObj.amount)) {
                        let tempVal = this.sLimitBuyObj.amount.split('.');
                        this.sLimitBuyObj.amount = tempVal[0] + '.' + tempVal[1].slice(0, 8);
                    }
                }
                break;
            case 7:
                if(this.marketSellObj.amount.includes(".")) {
                    if (!this.regexForEightChar.test(this.marketSellObj.amount)) {
                        let tempVal = this.marketSellObj.amount.split('.');
                        this.marketSellObj.amount = tempVal[0] + '.' + tempVal[1].slice(0, 8);
                    }
                }
                break;
            case 8:
                if(this.limitSellObj.price.includes(".")) {
                    if (!this.regexForEightChar.test(this.limitSellObj.price)) {
                        let tempVal = this.limitSellObj.price.split('.');
                        this.limitSellObj.price = tempVal[0] + '.' + tempVal[1].slice(0, 8);
                    }
                }
                break;
            case 9:
                if(this.limitSellObj.amount.includes(".")) {
                    if (!this.regexForEightChar.test(this.limitSellObj.amount)) {
                        let tempVal = this.limitSellObj.amount.split('.');
                        this.limitSellObj.amount = tempVal[0] + '.' + tempVal[1].slice(0, 8);
                    }
                }
                break;
            case 10:
                if(this.sLimitSellObj.stop.includes(".")) {
                    if (!this.regexForEightChar.test(this.sLimitSellObj.stop)) {
                        let tempVal = this.sLimitSellObj.stop.split('.');
                        this.sLimitSellObj.stop = tempVal[0] + '.' + tempVal[1].slice(0, 8);
                    }
                }
                break;
            case 11:
                if(this.sLimitSellObj.price.includes(".")) {
                    if (!this.regexForEightChar.test(this.sLimitSellObj.price)) {
                        let tempVal = this.sLimitSellObj.price.split('.');
                        this.sLimitSellObj.price = tempVal[0] + '.' + tempVal[1].slice(0, 8);
                    }
                }
                break;
            case 12:
                if(this.sLimitSellObj.amount.includes(".")) {
                    if (!this.regexForEightChar.test(this.sLimitSellObj.amount)) {
                        let tempVal = this.sLimitSellObj.amount.split('.');
                        this.sLimitSellObj.amount = tempVal[0] + '.' + tempVal[1].slice(0, 8);
                    }
                }
                break;            
        }
    }

    /** Function for to calculate total value */
    valueChangeFunc(type) {
        if(type == "LBP" || type == "LBA") {
            if(this.limitBuyObj.amount && this.limitBuyObj.price && Number(this.limitBuyObj.amount) >= 0 && Number(this.limitBuyObj.price) >= 0) {
                this.limitBuyTotal = (Number(this.limitBuyObj.amount) * Number(this.limitBuyObj.price)).toFixed(8);
            } else {
                this.limitBuyTotal = "";
            }
        }
        if(type == "LSP" || type == "LSA") {
            if(this.limitSellObj.amount && this.limitSellObj.price && Number(this.limitSellObj.amount) >= 0 && Number(this.limitSellObj.price) >= 0) {
                this.limitSellTotal = (Number(this.limitSellObj.amount) * Number(this.limitSellObj.price)).toFixed(8);
            } else {
                this.limitSellTotal = "";
            }
        }
        if(type == "SBP" || type == "SBA") {
            if(this.sLimitBuyObj.price && this.sLimitBuyObj.amount && Number(this.sLimitBuyObj.price) >= 0 && Number(this.sLimitBuyObj.amount) >= 0) {
                this.stopBuyTotal = (Number(this.sLimitBuyObj.price) * Number(this.sLimitBuyObj.amount)).toFixed(8);
            } else {
                this.stopBuyTotal = "";
            }
        }
        if(type == "SSP" || type == "SSA") {
            if(this.sLimitSellObj.price && this.sLimitSellObj.amount && Number(this.sLimitSellObj.price) >= 0 && Number(this.sLimitSellObj.amount) >= 0) {
                this.stopSellTotal = (Number(this.sLimitSellObj.price) * Number(this.sLimitSellObj.amount)).toFixed(8);
            } else {
                this.stopSellTotal = "";
            }
        }
    }

    /**Function to get coin balance */
    getBaseCoinBalance() {
        this.server.getApi('wallet/wallet/get-balance?coinName='+this.currSelectedCoinObj.coin).subscribe(res =>{
            this.baseWalletBalance = res.data.walletBalance;
        }, err =>{

        });
    }

    getExeCoinBalance() {
        this.server.getApi('wallet/wallet/get-balance?coinName='+this.currSelectedPairObj.coin).subscribe(res =>{
            this.exeWalletBalance = res.data.walletBalance;
        }, err =>{

        });
    }

    cancelOrder(data) {
        data.click = true;
        let cancelDetails = {
            "orderId" : data.orderId,
            "symbol"  : this.currSelectedPairObj.coin+'_'+this.currSelectedCoinObj.coin
        }
        this.server.postApi('order/cancel-order', cancelDetails).subscribe(res => {
            if(res.status == 200){
                this.appC.showSuccToast(res.message);
                data.click = false;
                this.getOpenOrder();
                this.getOrderHistory();
            } else {
                this.appC.showErrToast(res.message);
                data.click = false;
            }

        }, err =>{})
    }


    getOrderHistory() {
        this.orderHistoryList = []
        this.server.getApi('order/my-order-history?symbol='+this.tradeViewPair).subscribe(res =>{
            if(res.status == 200) {
                res.data.forEach(element => {
                    if(element.orderStatus == 'COMPLETED') {
                        this.orderHistoryList.push({
                            creationTime: element.creationTime,
                            limitPrice: element.avgExecutionPrice.toFixed(8),
                            quantity: element.quantity.toFixed(8),
                            total : (element.avgExecutionPrice*element.quantity).toFixed(8),
                            orderSide: element.orderSide,
                            orderStatus: element.orderStatus, 
                            instrument: element.instrument,
                            orderType: element.orderType,
                            taker: '',
                            maker: '',
                            orderId: element.orderId
                        });
                        this.getTakerMakerFee(element.orderId);
                    } else if(element.orderStatus == 'QUEUED') {
                        this.orderHistoryList.push({
                            creationTime: element.creationTime,
                            limitPrice: (element.limitPrice).toFixed(8),
                            quantity: (element.currentQuantity).toFixed(8),
                            total : (element.limitPrice*element.currentQuantity).toFixed(8),
                            orderSide: element.orderSide,
                            orderStatus: element.orderStatus, 
                            instrument: element.instrument,
                            orderType: element.orderType,
                            taker: '',
                            maker: '',
                            orderId: element.orderId
                        })
                        this.getTakerMakerFee(element.orderId)
                    } else if(element.orderStatus == 'CREATED') {
                        this.orderHistoryList.push({
                            creationTime: element.creationTime,
                            limitPrice: (element.stopPrice).toFixed(8),
                            quantity: (element.currentQuantity).toFixed(8),
                            total : (element.stopPrice*element.currentQuantity).toFixed(8),
                            orderSide: element.orderSide,
                            orderStatus: element.orderStatus, 
                            instrument: element.instrument,
                            orderType: element.orderType,
                            taker: '',
                            maker: '',
                            orderId: element.orderId
                        })
                        this.getTakerMakerFee(element.orderId)
                    }
                });
            }
            
        }, err =>{
        });
    }

    getTakerMakerFee(id) {
        this.server.getApi('wallet/orders/order-taker-maker-details?orderId='+id).subscribe(res =>{
            let ind = this.orderHistoryList.findIndex(x => x.orderId == id)
            if(res.data[0].action == 'TAKER_FEE') {
                this.orderHistoryList[ind].taker = res.data[0].amount;
            } else if(res.data[0].action == 'MAKER_FEE') {
                this.orderHistoryList[ind].maker = res.data[0].amount;
            }
        }, err =>{

        });
    }

    getOpenOrder() {
        this.openOrderList = [];
        this.server.getApi('order/my-active-orders?symbol='+this.tradeViewPair).subscribe(res => {
            if(res.status == 200) {
                res.data.forEach(element => {
                    if(element.orderStatus == 'PARTIALLY_EXECUTED') {
                        this.openOrderList.push({
                            total : (element.avgExecutionPrice*element.currentQuantity).toFixed(8),
                            creationTime : element.creationTime,
                            instrument : element.instrument,
                            orderSide : element.orderSide,
                            limitPrice : element.avgExecutionPrice.toFixed(8),
                            quantity : element.currentQuantity.toFixed(8),
                            orderStatus : element.orderStatus,
                            orderId: element.orderId,
                            orderType: element.orderType,
                            filled: (((element.quantity-element.currentQuantity)/element.quantity)*100).toFixed(8),
                            click : false
        
                        }) ;
                    } else if(element.orderStatus == 'QUEUED') {
                        this.openOrderList.push({
                            total : (element.limitPrice*element.currentQuantity).toFixed(8),
                            creationTime : element.creationTime,
                            instrument : element.instrument,
                            orderSide : element.orderSide,
                            limitPrice : element.limitPrice.toFixed(8),
                            quantity : element.currentQuantity.toFixed(8),
                            orderStatus : element.orderStatus,
                            orderId: element.orderId,
                            orderType: element.orderType,
                            filled: (((element.quantity-element.currentQuantity)/element.quantity)*100).toFixed(8),
                            click : false
        
                        }) ;
                    }
                    
                });
            }
        }, err =>{
        });

    }

    /** Function to draw trading chart */ 
    drawTradingChart() {
        let pair = this.tradeViewPair.split("_")[0]+"/"+this.tradeViewPair.split("_")[1];
        new TradingView.widget({
            fullscreen: true,
            symbol: pair,
            interval: 'D',
            container_id: "tradingview_cb72b",
            datafeed: new Datafeeds.UDFCompatibleDatafeed(this.server.chartUrl,60000),
            library_path: "assets/lib/charting_library/",
            locale: "en",
            enable_publishing: false,
            drawings_access: { type: 'white', tools: [ { name: "Regression Trend" } ] },
            disabled_features: ["use_localstorage_for_settings"],
            // overrides: {
            //     "paneProperties.background": "#000",
            //     "paneProperties.vertGridProperties.color": "#454545",
            //     "paneProperties.horzGridProperties.color": "#454545",
            //     "symbolWatermarkProperties.transparency": 90,
            //     "scalesProperties.textColor" : "#AAA"
            // }
        });
    }

    /**Function to draw Depth Chart */
    drawDepthChart() {
        let currVal = this.tradeViewPair.split("_")[1];
        let exeVal = this.tradeViewPair.split("_")[0];
        AmCharts.makeChart("depthChartID", {
            "type": "serial",
            "theme": "light",
            "dataLoader": {
                "url": this.server.chartUrl+"/depth-chart?currency="+currVal+"&exchangeCurrency="+exeVal,
                "format": "json",
                "reload": 30,
                "postProcess": function(data) {
                    var response = JSON.stringify(data);
                    var parsedData = JSON.parse(response);
                    var asks = parsedData.data.asks;
                    var bids = parsedData.data.bids;
                    // Function to process (sort and calculate cummulative volume)
                    function processData(list, type, desc) {
                        // Convert to data points
                        for(var i = 0; i < list.length; i++) {
                            list[i] = {
                                value: Number(list[i][0]),
                                volume: Number(list[i][1]),
                            }
                        }                 
                        // Sort list just in case
                        list.sort(function(a, b) {
                            if (a.value > b.value) {
                                return 1;
                            }
                            else if (a.value < b.value) {
                                return -1;
                            }
                            else {
                                return 0;
                            }
                        });                  
                        // Calculate cummulative volume
                        if (desc) {
                            for(var i = list.length - 1; i >= 0; i--) {
                                if (i < (list.length - 1)) {
                                    list[i].totalvolume = list[i+1].totalvolume + list[i].volume;
                                }
                                else {
                                    list[i].totalvolume = list[i].volume;
                                }
                                var dp = {};
                                dp["value"] = list[i].value;
                                dp[type + "volume"] = list[i].volume;
                                dp[type + "totalvolume"] = list[i].totalvolume;
                                res.unshift(dp);
                            }
                        } else {
                            for(var i = 0; i < list.length; i++) {
                                if (i > 0) {
                                    list[i].totalvolume = list[i-1].totalvolume + list[i].volume;
                                }
                                else {
                                    list[i].totalvolume = list[i].volume;
                                }
                                var dp = {};
                                dp["value"] = list[i].value;
                                dp[type + "volume"] = list[i].volume;
                                dp[type + "totalvolume"] = list[i].totalvolume;
                                res.push(dp);
                            }
                        }                 
                    }
                    
                    var res = [];
                    processData(bids, "bids", true);
                    processData(asks, "asks", false);
                    return res;
                }
            },
            "graphs": [{
                "id": "bids",
                "fillAlphas": 0.1,
                "lineAlpha": 1,
                "lineThickness": 2,
                "lineColor": "#0f0",
                "type": "step",
                "valueField": "bidstotalvolume",
                "balloonFunction": balloon
            }, {
                "id": "asks",
                "fillAlphas": 0.1,
                "lineAlpha": 1,
                "lineThickness": 2,
                "lineColor": "#f00",
                "type": "step",
                "valueField": "askstotalvolume",
                "balloonFunction": balloon
            }, {
                "lineAlpha": 0,
                "fillAlphas": 0.2,
                "lineColor": "#000",
                "type": "column",
                "clustered": false,
                "valueField": "bidsvolume",
                "showBalloon": false
            }, {
                "lineAlpha": 0,
                "fillAlphas": 0.2,
                "lineColor": "#000",
                "type": "column",
                "clustered": false,
                "valueField": "asksvolume",
                "showBalloon": false
            }],
            "categoryField": "value",
            "chartCursor": {},
            "balloon": {
                "textAlign": "left"
            },
            "categoryAxis": {
                "minHorizontalGap": 100,
                "startOnAxis": true,
                "showFirstLabel": false,
                "showLastLabel": false
            },
            "export": {
                "enabled": false
            }
        });
          
        function balloon(item, graph) {
            var txt;
            if (graph.id == "asks") {
                txt = "Ask: <strong>" + formatNumber(item.dataContext.value, graph.chart, 8) + "</strong><br />"
                + "Total volume: <strong>" + formatNumber(item.dataContext.askstotalvolume, graph.chart, 8) + "</strong><br />"
                + "Volume: <strong>" + formatNumber(item.dataContext.asksvolume, graph.chart, 8) + "</strong>";
            }
            else {
                txt = "Bid: <strong>" + formatNumber(item.dataContext.value, graph.chart, 8) + "</strong><br />"
                + "Total volume: <strong>" + formatNumber(item.dataContext.bidstotalvolume, graph.chart, 8) + "</strong><br />"
                + "Volume: <strong>" + formatNumber(item.dataContext.bidsvolume, graph.chart, 8) + "</strong>";
            }
            return txt;
        }
        
        function formatNumber(val, chart, precision) {
            return AmCharts.formatNumber(val, {
                precision: precision ? precision : chart.precision, 
                decimalSeparator: chart.decimalSeparator,
                thousandsSeparator: chart.thousandsSeparator
            });
        }
    }

    

   

    

    


}
