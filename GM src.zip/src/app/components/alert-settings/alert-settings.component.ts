import { Component, OnInit } from '@angular/core';
import { CookieService } from 'ngx-cookie-service';
import { ServiceService } from 'src/app/service/service.service';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-alert-settings',
  templateUrl: './alert-settings.component.html',
  styleUrls: ['./alert-settings.component.css']
})
export class AlertSettingsComponent implements OnInit {
  rolesPermissionsData: any = [];
  userIp: any;
  roles: any = [];
  alertData: any = [];
  success: any = { status: 742 };
  alertMatrix: any = [];
  adminId: any;
  operationId: any;
  accountsId: any;
  showApiMessage = false;
  rolesPermissions: { masterPermissionListId: string; rolesId: string; rolesPermissionsId: string; }[];

  constructor(
    private cookie: CookieService,
    private service: ServiceService,
    private spinner: NgxSpinnerService
  ) { }

  ngOnInit() {
    window.scrollTo(0, 0);
    this.userIp = (this.cookie.get('userInfo')) ? JSON.parse(this.cookie.get('userInfo')) : this.service.initialUserInfo;

    this.service.getMethod('setting/admin/exchange-control-alert/check-and-create', 1)
      .subscribe((response) => {
        this.getRoles();
      }, (error) => {
        this.getRoles();
      });
  }

  getRoles() {
    const data = {
      page: this.service.encrypt(String(0)),
      pageSize: this.service.encrypt('10'),
      search: null,
    };
    this.service.postMethod('account/superAdmin/user-management/search-and-filter-role', data, 1)
      .subscribe((response) => {
        const responseData = JSON.parse(this.service.decrypt(response.data));

        responseData.data.list.forEach((element) => {
          if ('admin' === (element.role).toLowerCase()) {
            this.adminId = element.roleId;
          }
          if ('operation' === (element.role).toLowerCase()) {
            this.operationId = element.roleId;
          }
          if ('accounts' === (element.role).toLowerCase()) {
            this.accountsId = element.roleId;
          }
        });
        this.getAlert();
      }, (error) => {
      });
  }

  getAlert() {
    this.spinner.show();
    this.service.getMethod('setting-service/admin/exchange-control-alert/get-alerts-compliance', 1)
      .subscribe((response: any) => {
        this.spinner.hide();
        if (response.status === 700 || response.status === 744) {
          this.alertData = response.data;
          this.createAlertMatrix();
        }
      }, (error) => {
        this.spinner.hide();
      });
  }

  createAlertMatrix() {
    this.alertMatrix = [];
    this.alertData.forEach(element => {
      const roleArray = ((element.alertTo != null) && element.alertTo !== '') ? (element.alertTo.split(',')) : [];
      const obj = {
        exchangeControlAlertsId: element.exchangeControlAlertsId,
        roles: roleArray
      };
      this.alertMatrix.push(obj);
    });
  }

  getCheckBoxData(index, type): boolean {
    const check = this.alertData[index];
    if (check.alertTo) {
      let rtn = 0;
      const data = check.alertTo.split(',');
      if (type === 'admin') {
        data.forEach((element) => {
          if (element === (this.adminId).toString()) {
            rtn++;
          }
        });
      } else if (type === 'operation') {
        data.forEach((element) => {
          if (element === (this.operationId).toString()) {
            rtn++;
          }
        });
      } else if (type === 'accounts') {
        data.forEach((element) => {
          if (element === (this.accountsId).toString()) {
            rtn++;
          }
        });
      }
      if (rtn !== 0) {
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }
  }

  alertChanged(i, type) {
    this.alertMatrix.forEach((element) => {
      if (element.exchangeControlAlertsId === this.alertData[i].exchangeControlAlertsId) {
        if (type === 'admin') {
          const index = element.roles.findIndex((obj) => obj === (this.adminId).toString());
          if (index === -1) {
            element.roles.push((this.adminId).toString());
          } else {
            element.roles.splice(index, 1);
          }
        } else if (type === 'operation') {
          const index = element.roles.findIndex((obj) => obj === (this.operationId).toString());
          if (index === -1) {
            element.roles.push((this.operationId).toString());
          } else {
            element.roles.splice(index, 1);
          }
        } else {
          const index = element.roles.findIndex((obj) => obj === (this.accountsId).toString());
          if (index === -1) {
            element.roles.push((this.accountsId).toString());
          } else {
            element.roles.splice(index, 1);
          }
        }
      }
    });
  }

  updateAlertSettings() {
    this.spinner.show();
    const data = {
      alertComplianceSubDto: this.alertMatrix,
      ipAddress: this.userIp.ip,
      location: this.userIp.city + ', ' + this.userIp.country_name
    };
    this.service.postMethod('setting-service/admin/exchange-control-alert/save-alert-compliance', data, 1)
      .subscribe((response) => {
        this.spinner.hide();
        if (response.status === 742) {
          this.success = response;
          this.success.message = 'Alert matrix updated successfully.';
          this.showApiMessage = true;
        } else {
          this.success = response;
          this.showApiMessage = true;
        }

      }, (error) => {
        if (error) {
          if (error.error) {
            this.success.status = error.error.status;
            this.success.message = error.error.message;
            this.showApiMessage = true;
          } else {
            this.success.status = 500;
            this.success.message = 'Something went wrong';
            this.showApiMessage = true;
          }
        } else {
          this.success.status = 500;
          this.success.message = 'Something went wrong';
          this.showApiMessage = true;
        }
      });
  }

}
