import { JobTranslateListComponent } from './components/job-and-applications/job-translate-list/job-translate-list.component';
import { BrowserModule } from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { OwlDateTimeModule, OwlNativeDateTimeModule } from 'ng-pick-datetime';

import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ServiceService, HttpModifierInterceptor } from './service/service.service';
import { RecaptchaModule } from 'ng-recaptcha';
import { RecaptchaFormsModule } from 'ng-recaptcha/forms';
import { LoginComponent } from './components/login/login.component';
import { ResetPasswordComponent } from './components/reset-password/reset-password.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { ChangePasswordComponent } from './components/change-password/change-password.component';
import { ManageRolesComponent } from './components/manage-roles/manage-roles.component';
import { ManageAdminComponent } from './components/manage-admin/manage-admin.component';
import { LogsComponent } from './components/logs/logs.component';
import { AddRoleComponent } from './components/add-role/add-role.component';
import { EditRoleComponent } from './components/edit-role/edit-role.component';
import { EditAdminComponent } from './components/edit-admin/edit-admin.component';
import { ViewAdminComponent } from './components/view-admin/view-admin.component';
import { SharedModuleModule } from './shared-module/shared-module.module';
import { CookieService } from 'ngx-cookie-service';
import { DeviceDetectorModule } from 'ngx-device-detector';
import { HTTP_INTERCEPTORS, HttpClient } from '@angular/common/http';
import { AddAdminComponent } from './components/add-admin/add-admin.component';
import { DatePipe } from '@angular/common';
import { MarketingSidebarComponent } from './components/sidebar/sidebar.component';
import { AdminChangePasswordComponent } from './components/admin-change-password/admin-change-password.component';
import { DecryptPipePipe } from './pipes/decrypt-pipe.pipe';
import { RolesAndPermissionsComponent } from './components/roles-and-permissions/roles-and-permissions.component';
import { ManageApprovalsComponent } from './components/manage-approvals/manage-approvals.component';
import { CKEditorModule } from 'ngx-ckeditor';
import { ManageStaffComponent } from './components/manage-staff/manage-staff.component';
import { ManageCustomerComponent } from './components/manage-customer/manage-customer.component';
import { FAQComponent } from './components/faq/faq.component';
import { TopicsComponent } from './components/topics/topics.component';
import { TransferHistoryComponent } from './components/transfer-history/transfer-history.component';
import { ActivityLogComponent } from './components/activity-log/activity-log.component';
import { EventManagementComponent } from './components/event-management/event-management.component';
import { PromotionManagementComponent } from './components/promotion-management/promotion-management.component';
import { OfferManagementComponent } from './components/offer-management/offer-management.component';
import { ViewStaffComponent } from './components/view-staff/view-staff.component';
import { EditStaffComponent } from './components/edit-staff/edit-staff.component';
import { AddStaffComponent } from './components/add-staff/add-staff.component';
import { PasswordChangeComponent } from './components/password-change/password-change.component';
import { ViewCustomerComponent } from './components/view-customer/view-customer.component';
import { ManageSiteContentComponent } from './components/manage-site-content/manage-site-content.component';
import { AboutUsComponent } from './components/about-us/about-us.component';
import { TermsAndContentComponent } from './components/terms-and-content/terms-and-content.component';
import { PrivacyPolicyComponent } from './components/privacy-policy/privacy-policy.component';
import { TranslationComponent } from './components/translation/translation.component';
import { SocialMediaLinkComponent } from './components/social-media-link/social-media-link.component';
import { EditTopicComponent } from './components/edit-topic/edit-topic.component';
import { AddEditFaqComponent } from './components/add-edit-faq/add-edit-faq.component';
import { TranslateFaqTopicComponent } from './components/translate-faq-topic/translate-faq-topic.component';
import { HomepageComponent } from './components/homepage/homepage.component';
import { ContactInfoComponent } from './components/contact-info/contact-info.component';
import { CountriesListComponent } from './components/countries-list/countries-list.component';
import { StateNameComponent } from './components/state-name/state-name.component';
import { BankListComponent } from './components/bank-list/bank-list.component';
import { AddEditBankComponent } from './components/add-edit-bank/add-edit-bank.component';

import { RewardsComponent } from './components/rewards/rewards.component';
import { SettingallComponent } from './components/settingall/settingall.component';
import { ExchangeFunctionComponent } from './components/exchange-function/exchange-function.component';
import { TwoFaComponent } from './components/two-fa/two-fa.component';
import { LiquidityComponent } from './components/liquidity/liquidity.component';
import { DeskoperatorsComponent } from './components/deskoperators/deskoperators.component';
import { TransactioncontrolComponent } from './components/transactioncontrol/transactioncontrol.component';
import { SupportTopicsComponent } from './components/support-topics/support-topics.component';
import { AlertSettingsComponent } from './components/alert-settings/alert-settings.component';
import { ManageTradingPairComponent } from './components/manage-trading-pair/manage-trading-pair.component';
import { MinimumDepositComponent } from './components/minimum-deposit/minimum-deposit.component';
import { MinimumDepositCryptoComponent } from './components/minimum-deposit-crypto/minimum-deposit-crypto.component';
import { MinimumDepositFiatComponent } from './components/minimum-deposit-fiat/minimum-deposit-fiat.component';
import { MinimumTradingComponent } from './components/minimum-trading/minimum-trading.component';
import { MinimumTradingFeeComponent } from './components/minimum-trading-fee/minimum-trading-fee.component';
import { MinimumWithdrawlComponent } from './components/minimum-withdrawl/minimum-withdrawl.component';
import { MinimumWithdrawlCryptoComponent } from './components/minimum-withdrawl-crypto/minimum-withdrawl-crypto.component';
import { MinimumWithdrawlFiatComponent } from './components/minimum-withdrawl-fiat/minimum-withdrawl-fiat.component';
import { StandardDepositComponent } from './components/standard-deposit/standard-deposit.component';
import { StandardDepositCryptoComponent } from './components/standard-deposit-crypto/standard-deposit-crypto.component';
import { StandardDepositFiatComponent } from './components/standard-deposit-fiat/standard-deposit-fiat.component';
import { StandardTradingComponent } from './components/standard-trading/standard-trading.component';
import { StandardTradingFeeComponent } from './components/standard-trading-fee/standard-trading-fee.component';
import { StandardWithdrawlComponent } from './components/standard-withdrawl/standard-withdrawl.component';
import { StandardWithdrawlCryptoComponent } from './components/standard-withdrawl-crypto/standard-withdrawl-crypto.component';
import { StandardWithdrawlFiatComponent } from './components/standard-withdrawl-fiat/standard-withdrawl-fiat.component';
import { RewardsSettingComponent } from './components/rewards-setting/rewards-setting.component';
import { ManageCoinsComponent } from './components/manage-coins/manage-coins.component';
import { ManageFeeComponent } from './components/manage-fee/manage-fee.component';
import { DailyClouserComponent } from './components/daily-clouser/daily-clouser.component';
import { UpdateCoinComponent } from './components/update-coin/update-coin.component';
import { SecComponent } from './components/sec/sec.component';
import { JobsComponent } from './components/job-and-applications/jobs/jobs.component';
import { AddJobComponent } from './components/job-and-applications/add-job/add-job.component';
import { JobApplicationComponent } from './components/job-and-applications/job-application/job-application.component';
import { EditJobComponent } from './components/job-and-applications/edit-job/edit-job.component';
import { BlogManagementComponent } from './components/blog/blog-management/blog-management.component';
import { AddJobTranslationComponent } from './components/job-and-applications/add-job-translation/add-job-translation.component';
import { ViewJobDetailComponent } from './components/job-and-applications/view-job-detail/view-job-detail.component';
import { ViewApplicationDetailComponent } from './components/job-and-applications/view-application-detail/view-application-detail.component';
import { AddBlogComponent } from './components/blog/add-blog/add-blog.component';
import { EditBlogComponent } from './components/blog/edit-blog/edit-blog.component';
import { BlogTranslationListComponent } from './components/blog/blog-translation-list/blog-translation-list.component';
import { WithdrawReqComponent } from './operational-components/withdraw-req/withdraw-req.component';
import { BasicDetailComponent } from './operational-components/basic-detail/basic-detail.component';
import { CompanyDetailComponent } from './operational-components/company-detail/company-detail.component';
import { BankDetailComponent } from './operational-components/bank-detail/bank-detail.component';
import { AddNewUserComponent } from './operational-components/add-new-user/add-new-user.component';
import { PlaceOrderComponent } from './operational-components/place-order/place-order.component';
import { SupportChatComponent } from './operational-components/support-chat/support-chat.component';
import { ViewHistoryComponent } from './operational-components/view-history/view-history.component';
import { TicketDetailsComponent } from './operational-components/ticket-details/ticket-details.component';
import { ReplyHistoryComponent } from './operational-components/reply-history/reply-history.component';
import { ManageCustomersComponent } from './operational-components/manage-customers/manage-customers.component';
import { TickesComponent } from './operational-components/tickes/tickes.component';
import { TicketReplyComponent } from './operational-components/ticket-reply/ticket-reply.component';
import { ReportDepositComponent } from './operational-components/report-deposit/report-deposit.component';
import { ReportWithdrawComponent } from './operational-components/report-withdraw/report-withdraw.component';
import { DepositReqDetailComponent } from './operational-components/deposit-req-detail/deposit-req-detail.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { NgxPaginationModule } from 'ngx-pagination';
import { ManageTransferExchangeWalletComponent } from './components/manage-transfer-exchange-wallet/manage-transfer-exchange-wallet.component';
import { ManageExchangeWalletComponent } from './components/manage-exchange-wallet/manage-exchange-wallet.component';
import { ManageExchangeFeeWalletComponent } from './components/manage-exchange-fee-wallet/manage-exchange-fee-wallet.component';
import { ManageSettingExchangeFeeWalletComponent } from './components/manage-setting-exchange-fee-wallet/manage-setting-exchange-fee-wallet.component';
import { EditBlogTranslateComponent } from './components/blog/edit-blog-translate/edit-blog-translate.component';
import { ViewBlogDetailComponent } from './components/blog/view-blog-detail/view-blog-detail.component';
import { ManageBannersComponent } from './components/banners/manage-banners/manage-banners.component';
import { EditBannersComponent } from './components/banners/edit-banners/edit-banners.component';
import { TranslateBannersComponent } from './components/banners/translate-banners/translate-banners.component';
import { ExportComponent } from './components/export/export.component';
import { AddScheduleComponent } from './components/add-schedule/add-schedule.component';
import { StaffLogComponent } from './components/staff-log/staff-log.component';
import { RewardsSettingSidebarComponent } from './components/rewards-setting-sidebar/rewards-setting-sidebar.component';
import { UpdateRewardSettingComponent } from './components/update-reward-setting/update-reward-setting.component';
import { MimimumWithdrawlCryptoSidebarComponent } from './components/mimimum-withdrawl-crypto-sidebar/mimimum-withdrawl-crypto-sidebar.component';
import { MimimumWithdrawlCryptoUpdateSidebarComponent } from './components/mimimum-withdrawl-crypto-update-sidebar/mimimum-withdrawl-crypto-update-sidebar.component';
import { MimimumWithdrawlFiatSidebarComponent } from './components/mimimum-withdrawl-fiat-sidebar/mimimum-withdrawl-fiat-sidebar.component';
import { MimimumWithdrawlFiatUpdateSidebarComponent } from './components/mimimum-withdrawl-fiat-update-sidebar/mimimum-withdrawl-fiat-update-sidebar.component';
import { ManageNotificationComponent } from './components/manage-notification/manage-notification.component';
import { ManageUpdateNotificationComponent } from './components/manage-update-notification/manage-update-notification.component';
import { FaqTranslationComponent } from './components/faq-translation/faq-translation.component';
import { EditBannerTranslationDataComponent } from './components/banners/edit-banner-translation-data/edit-banner-translation-data.component';
import { AddEventComponent } from './components/event/add-event/add-event.component';
import { EditEventComponent } from './components/event/edit-event/edit-event.component';
import { EventtranslationListComponent } from './components/event/eventtranslation-list/eventtranslation-list.component';
import { EditEventTranslationComponent } from './components/event/edit-event-translation/edit-event-translation.component';
import { ViewEventDetailsComponent } from './components/event/view-event-details/view-event-details.component';
import { AttendeesManagementComponent } from './components/attendees/attendees-management/attendees-management.component';
import { AddParticipantComponent } from './components/attendees/add-participant/add-participant.component';
import { AddPromotionComponent } from './components/promotion/add-promotion/add-promotion.component';

import { InternationalPhoneNumberModule } from 'ngx-international-phone-number';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { PermissionPipePipe } from './pipes/permission-pipe.pipe';
import { AccessControlDirective } from './directive/access-control.directive';
import { AddOfferComponent } from './components/offer/add-offer/add-offer.component';

import { CryptoWithdrawlReqComponent } from './operational-components/crypto-withdrawl-req/crypto-withdrawl-req.component';
import { FiatWithdrawlReqComponent } from './operational-components/fiat-withdrawl-req/fiat-withdrawl-req.component';
import { FiatDepositReqComponent } from './operational-components/fiat-deposit-req/fiat-deposit-req.component';
import { InquiriesComponent } from './operational-components/inquiries/inquiries.component';
import { ReportFiatDepositComponent } from './operational-components/report-fiat-deposit/report-fiat-deposit.component';
import { ReportFiatWithdrawComponent } from './operational-components/report-fiat-withdraw/report-fiat-withdraw.component';
import { ReportCommissionComponent } from './operational-components/report-commission/report-commission.component';
import { MarketMakersComponent } from './operational-components/market-makers/market-makers.component';
import { OtcCustomersComponent } from './operational-components/otc-customers/otc-customers.component';
import { ManageBankRegistrationComponent } from './operational-components/manage-bank-registration/manage-bank-registration.component';
import { DepositWithdrawTabComponent } from './operational-components/deposit-withdraw-tab/deposit-withdraw-tab.component';
import { FaResetDetailComponent } from './operational-components/fa-reset-detail/fa-reset-detail.component';
import { ParticularFaDetailComponent } from './operational-components/particular-fa-detail/particular-fa-detail.component';
import { EditExportComponent } from './components/edit-export/edit-export.component';
import { walletChart } from './components/dashboard/walletChart';
import { hrTradeChartService } from './components/dashboard/hrTradeChart';
import { hrTradeFIATChartService } from './components/dashboard/hrTradeFIATChart';
import { hrWithdrawalCryptoChartService } from './components/dashboard/hrWithdrawalCryptoChart';
import { hrWithdrawalFIATChartService } from './components/dashboard/hrWithdrawalFIATChart';
import { hrDepositeCryptoChartService } from './components/dashboard/hrDepositeCryptoChart';
import { hrDepositeFIATChartService } from './components/dashboard/hrDepositeFIATChart';
import { totalJobsService } from './components/dashboard/totalJobs';
import { totalApplicationService } from './components/dashboard/totalApplications';
import { marketingGraphService } from './components/dashboard/marketingGraph';
import { AddNewReqComponent } from './operational-components/add-new-req/add-new-req.component';
import { EditOfferComponent } from './components/offer/edit-offer/edit-offer.component';
import { OfferTranslationComponent } from './components/offer/offer-translation/offer-translation.component';
import { OfferTranslationListComponent } from './components/offer/offer-translation-list/offer-translation-list.component';
import { CustomerListComponent } from './components/reward/customer-list/customer-list.component';
import { OperationKycComponent } from './operational-components/operation-kyc/operation-kyc.component';
import { EditNotificationTranslationComponent } from './components/edit-notification-translation/edit-notification-translation.component';
import {WebcamModule} from 'ngx-webcam';
import { RewardTransactionComponent } from './components/reward/reward-transaction/reward-transaction.component';
import { CustomersKycComponent } from './operational-components/customers-kyc/customers-kyc.component';
import {TranslateModule, TranslateLoader} from '@ngx-translate/core';
import {TranslateHttpLoader} from '@ngx-translate/http-loader';
import { KycComponent } from './components/kyc/kyc.component';
import { GetBaseSixtyFourPipe } from './pipes/get-base-sixty-four.pipe';
import { GetKeysPipe } from './pipes/get-keys.pipe';
import { AddSupportTopicComponent } from './components/add-support-topic/add-support-topic.component';
import { AddEditSupportTopicComponent } from './components/add-edit-support-topic/add-edit-support-topic.component';
import { SupportTopicTranslationComponent } from './components/support-topic-translation/support-topic-translation.component';
import { SupportSubtopicComponent } from './components/support-subtopic/support-subtopic.component';
import { ManageSubtopicComponent } from './components/manage-subtopic/manage-subtopic.component';
import { ViewNotificationComponent } from './components/view-notification/view-notification.component';
import {TimeAgoPipe} from 'time-ago-pipe';
import { ViewParticipantComponent } from './components/attendees/view-participant/view-participant.component';
import { ViewMaintenanceComponent } from './components/view-maintenance/view-maintenance.component';
import { ViewofferComponent } from './components/viewoffer/viewoffer.component';
import { OTCPermotionComponent } from './components/otc-permotion/otc-permotion.component';
import { OTCSettingComponent } from './components/otc-setting/otc-setting.component';
import { AddOTCPermotionComponent } from './components/OTC-section/add-otc-permotion/add-otc-permotion.component';
import { UpdateOTCSettingComponent } from './components/OTC-section/update-otc-setting/update-otc-setting.component';

export function HttpLoaderFactory(http: HttpClient) {
    return new TranslateHttpLoader(http, './assets/i18n/', '.json');
}

@NgModule({
    declarations: [
        AppComponent,
        LoginComponent,
        RewardTransactionComponent,
        ResetPasswordComponent,
        DashboardComponent,
        ChangePasswordComponent,
        ManageRolesComponent,
        ManageAdminComponent,
        LogsComponent,
        AddRoleComponent,
        EditRoleComponent,
        EditAdminComponent,
        ViewAdminComponent,
        AddAdminComponent,
        MarketingSidebarComponent,
        JobsComponent,
        AddJobComponent,
        JobApplicationComponent,
        AdminChangePasswordComponent,
        DecryptPipePipe,
        RolesAndPermissionsComponent,
        ManageApprovalsComponent,
        EditJobComponent,
        ManageStaffComponent,
        ManageCustomerComponent,
        FAQComponent,
        TopicsComponent,
        TransferHistoryComponent,
        ActivityLogComponent,
        BlogManagementComponent,
        EventManagementComponent,
        PromotionManagementComponent,
        OfferManagementComponent,
        ViewStaffComponent,
        EditStaffComponent,
        AddStaffComponent,
        PasswordChangeComponent,
        ViewCustomerComponent,
        ManageSiteContentComponent,
        AboutUsComponent,
        TermsAndContentComponent,
        PrivacyPolicyComponent,
        TranslationComponent,
        SocialMediaLinkComponent,
        EditTopicComponent,
        AddEditFaqComponent,
        TranslateFaqTopicComponent,
        HomepageComponent,
        ContactInfoComponent,
        CountriesListComponent,
        StateNameComponent,
        BankListComponent,
        AddEditBankComponent,
        RewardsComponent,
        SettingallComponent,
        ExchangeFunctionComponent,
        TwoFaComponent,
        LiquidityComponent,
        DeskoperatorsComponent,
        TransactioncontrolComponent,
        SupportTopicsComponent,
        AlertSettingsComponent,
        ManageTradingPairComponent,
        MinimumDepositComponent,
        MinimumDepositCryptoComponent,
        MinimumDepositFiatComponent,
        MinimumTradingComponent,
        MinimumTradingFeeComponent,
        MinimumWithdrawlComponent,
        MinimumWithdrawlCryptoComponent,
        MinimumWithdrawlFiatComponent,
        StandardDepositComponent,
        StandardDepositCryptoComponent,
        StandardDepositFiatComponent,
        StandardTradingComponent,
        StandardTradingFeeComponent,
        StandardWithdrawlComponent,
        StandardWithdrawlCryptoComponent,
        StandardWithdrawlFiatComponent,
        RewardsSettingComponent,
        ManageCoinsComponent,
        ManageFeeComponent,
        DailyClouserComponent,
        UpdateCoinComponent,
        SecComponent,
        JobTranslateListComponent,
        AddJobTranslationComponent,
        ViewJobDetailComponent,
        ViewApplicationDetailComponent,
        AddBlogComponent,
        EditBlogComponent,
        BlogTranslationListComponent,
        WithdrawReqComponent,
        BasicDetailComponent,
        CompanyDetailComponent,
        BankDetailComponent,
        AddNewUserComponent,
        PlaceOrderComponent,
        SupportChatComponent,
        ViewHistoryComponent,
        TicketDetailsComponent,
        ReplyHistoryComponent,
        ManageCustomersComponent,
        TickesComponent,
        TicketReplyComponent,
        ReportDepositComponent,
        ReportWithdrawComponent,
        DepositReqDetailComponent,
        CryptoWithdrawlReqComponent,
        AddPromotionComponent,
        EditBlogTranslateComponent,
        ViewBlogDetailComponent,
        ManageBannersComponent,
        EditBannersComponent,
        TranslateBannersComponent,
        ExportComponent,
        AddScheduleComponent,
        StaffLogComponent,
        RewardsSettingSidebarComponent,
        UpdateRewardSettingComponent,
        MimimumWithdrawlCryptoSidebarComponent,
        MimimumWithdrawlCryptoUpdateSidebarComponent,
        MimimumWithdrawlFiatSidebarComponent,
        MimimumWithdrawlFiatUpdateSidebarComponent,
        ManageNotificationComponent,
        EditBannerTranslationDataComponent,
        ManageUpdateNotificationComponent,
        FaqTranslationComponent,
        AddEventComponent,
        EditEventComponent,
        EventtranslationListComponent,
        EditEventTranslationComponent,
        ViewEventDetailsComponent,
        AttendeesManagementComponent,
        AddParticipantComponent,
        AddPromotionComponent,
        ManageTransferExchangeWalletComponent,
        ManageExchangeWalletComponent,
        ManageExchangeFeeWalletComponent,
        ManageSettingExchangeFeeWalletComponent,
        PageNotFoundComponent,
        PermissionPipePipe,
        AccessControlDirective,
        AddOfferComponent,
        ResetPasswordComponent,
        DashboardComponent,
        ChangePasswordComponent,
        ManageRolesComponent,
        ManageAdminComponent,
        LogsComponent,
        AddRoleComponent,
        EditRoleComponent,
        EditAdminComponent,
        ViewAdminComponent,
        AddAdminComponent,
        MarketingSidebarComponent,
        JobsComponent,
        AddJobComponent,
        JobApplicationComponent,
        AdminChangePasswordComponent,
        DecryptPipePipe,
        RolesAndPermissionsComponent,
        ManageApprovalsComponent,
        EditJobComponent,
        ManageStaffComponent,
        ManageCustomerComponent,
        FAQComponent,
        TopicsComponent,
        TransferHistoryComponent,
        ActivityLogComponent,
        BlogManagementComponent,
        EventManagementComponent,
        PromotionManagementComponent,
        OfferManagementComponent,
        ViewStaffComponent,
        EditStaffComponent,
        AddStaffComponent,
        PasswordChangeComponent,
        ViewCustomerComponent,
        ManageSiteContentComponent,
        AboutUsComponent,
        TermsAndContentComponent,
        PrivacyPolicyComponent,
        TranslationComponent,
        SocialMediaLinkComponent,
        EditTopicComponent,
        AddEditFaqComponent,
        TranslateFaqTopicComponent,
        HomepageComponent,
        ContactInfoComponent,
        CountriesListComponent,
        StateNameComponent,
        BankListComponent,
        AddEditBankComponent,
        RewardsComponent,
        SettingallComponent,
        ExchangeFunctionComponent,
        TwoFaComponent,
        LiquidityComponent,
        DeskoperatorsComponent,
        TransactioncontrolComponent,
        SupportTopicsComponent,
        AlertSettingsComponent,
        ManageTradingPairComponent,
        MinimumDepositComponent,
        MinimumDepositCryptoComponent,
        MinimumDepositFiatComponent,
        MinimumTradingComponent,
        MinimumTradingFeeComponent,
        MinimumWithdrawlComponent,
        MinimumWithdrawlCryptoComponent,
        MinimumWithdrawlFiatComponent,
        StandardDepositComponent,
        StandardDepositCryptoComponent,
        StandardDepositFiatComponent,
        StandardTradingComponent,
        StandardTradingFeeComponent,
        StandardWithdrawlComponent,
        StandardWithdrawlCryptoComponent,
        StandardWithdrawlFiatComponent,
        RewardsSettingComponent,
        ManageCoinsComponent,
        ManageFeeComponent,
        DailyClouserComponent,
        UpdateCoinComponent,
        SecComponent,
        JobTranslateListComponent,
        AddJobTranslationComponent,
        ViewJobDetailComponent,
        ViewApplicationDetailComponent,
        AddBlogComponent,
        EditBlogComponent,
        BlogTranslationListComponent,
        WithdrawReqComponent,
        BasicDetailComponent,
        CompanyDetailComponent,
        BankDetailComponent,
        AddNewUserComponent,
        PlaceOrderComponent,
        SupportChatComponent,
        ViewHistoryComponent,
        TicketDetailsComponent,
        ReplyHistoryComponent,
        ManageCustomersComponent,
        TickesComponent,
        TicketReplyComponent,
        ReportDepositComponent,
        ReportWithdrawComponent,
        DepositReqDetailComponent,
        CryptoWithdrawlReqComponent,
        ReportFiatDepositComponent,
        ReportFiatWithdrawComponent,
        ReportCommissionComponent,
        MarketMakersComponent,
        OtcCustomersComponent,
        ManageBankRegistrationComponent,
        DepositWithdrawTabComponent,
        FaResetDetailComponent,
        ParticularFaDetailComponent,
        FiatDepositReqComponent,
        InquiriesComponent,
        FiatWithdrawlReqComponent,
        EditExportComponent,
        AddNewReqComponent,
        EditOfferComponent,
        OfferTranslationComponent,
        OfferTranslationListComponent,
        CustomerListComponent,
        OperationKycComponent,
        EditNotificationTranslationComponent,
        RewardTransactionComponent,
        CustomersKycComponent,
        KycComponent,
        GetBaseSixtyFourPipe,
        GetKeysPipe,
        AddSupportTopicComponent,
        AddEditSupportTopicComponent,
        SupportTopicTranslationComponent,
        SupportSubtopicComponent,
        ManageSubtopicComponent,
        ViewNotificationComponent,
        TimeAgoPipe,
        ViewParticipantComponent,
        ViewMaintenanceComponent,
        ViewofferComponent,
        OTCPermotionComponent,
        OTCSettingComponent,
        AddOTCPermotionComponent,
        UpdateOTCSettingComponent,
       

    ],
    imports: [
        BrowserModule,
        BrowserAnimationsModule,
        AppRoutingModule,
        DeviceDetectorModule.forRoot(),
        SharedModuleModule,
        CKEditorModule,
        RecaptchaModule,
        RecaptchaFormsModule,
        FormsModule,
        ReactiveFormsModule,
        NgxPaginationModule,
        InternationalPhoneNumberModule,
        WebcamModule,
        TranslateModule.forRoot({
            loader: { provide: TranslateLoader, useFactory: HttpLoaderFactory, deps: [HttpClient]}
        }),
        OwlDateTimeModule,
        OwlNativeDateTimeModule,
    ],
    exports : [
        TranslateModule
    ],
    providers: [ServiceService, CookieService, DatePipe,
        walletChart,
        hrTradeChartService,
        hrTradeFIATChartService,
        hrWithdrawalCryptoChartService,
        hrWithdrawalFIATChartService,
        hrDepositeCryptoChartService,
        hrDepositeFIATChartService,
        totalJobsService,
        totalApplicationService,
        marketingGraphService,
        {
            provide: HTTP_INTERCEPTORS,
            useClass: HttpModifierInterceptor,
            multi: true
        },
    ],
    bootstrap: [AppComponent]
})
export class AppModule { }
