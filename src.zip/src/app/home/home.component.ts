import { Component, OnInit } from '@angular/core';
import {FormControl} from '@angular/forms';
import {Observable} from 'rxjs';
import {map, startWith} from 'rxjs/operators';
import {DomSanitizer} from '@angular/platform-browser';
import {MatIconRegistry} from '@angular/material/icon';
import { Router } from '@angular/router';
import { Inject} from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { CookieService } from 'ngx-cookie-service';
import {  ChangeDetectorRef } from '@angular/core';
import { MediaMatcher } from '@angular/cdk/layout';
import { MainServiceService } from 'src/app/main-service.service';

export interface DialogData {
  animal: string;
  name: string;

}


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  animal: string;
  name: string;

  dashbordList: any;
  myControl = new FormControl();
  filteredOptions: Observable<string[]>;
  options: string[] = ['One', 'Two', 'Three'];

  
  

  constructor(changeDetectorRef: ChangeDetectorRef, media: MediaMatcher,public dialog: MatDialog,private service:MainServiceService,iconRegistry: MatIconRegistry, sanitizer: DomSanitizer, 
    public router: Router,  private spinnerService: Ng4LoadingSpinnerService, private cookie: CookieService) {
    iconRegistry.addSvgIcon(
        'thumbs-up',
        sanitizer.bypassSecurityTrustResourceUrl('assets/image/home.svg'));

        this.mobileQuery = media.matchMedia('(max-width: 200px)');
        this._mobileQueryListener = () => changeDetectorRef.detectChanges();
        this.mobileQuery.addListener(this._mobileQueryListener);
  }
  ngOnInit() {
  
  }
  userName="Mr. Stark";
  petrolPumpName="petrol pump 1";
 data=[{name:'Dashboard'},
 {name:'Daily Basic Report'},
 {name:'Daily Input'},
 {name:'Stock'},
 {name:'Sales'},
 {name:'Credit Customer'},
 {name:'Full Report'},
 {name:'Machine Reading'},
 {name:'Accounting'}
]
 
   mobileQuery: MediaQueryList;
 
   fillerNav = Array.from({length: 9}, (_, i) => `${this.data[i].name}`);
 
 
   private _mobileQueryListener: () => void;
 
   
   ngOnDestroy(): void {
     this.mobileQuery.removeListener(this._mobileQueryListener);
   }


  myprofile(){
    this.router.navigate(['home/myprofile']);
      }




      openDialog(): void {
        const dialogRef = this.dialog.open(LogoutModalComponent, {
          height: '200px',
        
  width: '400px',
  
  
          data: {name: this.name, animal: this.animal}
        });
    
        dialogRef.afterClosed().subscribe(result => {
          console.log('The dialog was closed');
          this.animal = result;
        });
      }

    
  }
  
// logout modalbox


@Component({
  selector: 'logout-modal-component',
  templateUrl: 'logout-modal-component.html',
  styleUrls: ['logout-modal.component.css']
})
export class LogoutModalComponent {

  constructor(public router: Router,private spinnerService: Ng4LoadingSpinnerService, private cookie: CookieService,
    public dialogRef: MatDialogRef<LogoutModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData) {}

  onNoClick(): void {
    this.dialogRef.close();
  }


  logout(){
    this.cookie.deleteAll();
    this.router.navigate(['login']); 


   }




}
