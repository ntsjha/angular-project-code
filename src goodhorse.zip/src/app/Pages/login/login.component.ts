import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms'
import { Router } from '@angular/router';
// import { CookieService } from 'ngx-cookie-service';
import { ServiceService } from 'src/app/Shared/service.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  LoginForm: FormGroup;
  cookies: any = "yoyo"
  constructor(private router: Router, private service: ServiceService, private spinner: NgxSpinnerService,private toastr: ToastrService) { }

  ngOnInit() {
    this.LoginForm = new FormGroup({
      email: new FormControl('ph-shivam@mobiloitte.com', [Validators.required]),
      password: new FormControl('Mobiloitte1', [Validators.required]),
      rememberme: new FormControl(false)
    })
 
  }

  loginFunc() {
    console.log(this.LoginForm.value)
    this.service.emailLogin(this.LoginForm.value.email, this.LoginForm.value.password);
  }
  
 
  
  forgot() {
    console.log(this.LoginForm.value.email);
    this.service.resetPassword(this.LoginForm.value.email);

  }

}
