import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, App } from 'ionic-angular';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { SelectContactPage } from '../select-contact/select-contact';
import { ContactsPage } from '../contacts/contacts';

@IonicPage()
@Component({
  selector: 'page-receive',
  templateUrl: 'receive.html',
})
export class ReceivePage {
  receiveAmount: FormGroup;

  constructor(public navCtrl: NavController, public navParams: NavParams, private app: App) {
    this.receiveAmount = new FormGroup({
      amount: new FormControl("", Validators.compose([
        Validators.required,
        Validators.pattern(/^(?=.*[1-9])\d+(\.\d{1,3})?$/)
      ])),
      message: new FormControl('')
    })
  }

  get amount(): any {
    return this.receiveAmount.get('amount')
  }

  receiveMoney() {
    let data = {
      message: this.receiveAmount.value.message,
      amount: this.receiveAmount.value.amount
    };
    localStorage.receiveMoneyProcess = JSON.stringify(data)
    this.app.getRootNav().push(ContactsPage, {process: 'RECEIVE'})
    // this.app.getRootNav().push(SelectContactPage)
  }



}
