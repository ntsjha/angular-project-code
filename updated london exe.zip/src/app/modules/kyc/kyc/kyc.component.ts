import { Component, OnInit } from '@angular/core';
import { ServerService } from '../../../service/server.service';
import { Ng4LoadingSpinnerService } from '../../../../../node_modules/ng4-loading-spinner';
import { HeaderComponent } from '../../header/header/header.component';
import { Router } from '../../../../../node_modules/@angular/router';
import { AppComponent } from '../../../app.component';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Observable } from '../../../../../node_modules/rxjs';
declare var $ : any;

@Component({
  selector: 'app-kyc',
  templateUrl: './kyc.component.html',
  styleUrls: ['./kyc.component.css']
})
export class KycComponent implements OnInit {
    isActive: any = 'kyc';
    name: any;
    email: any;
    phoneNo: any;
    phoneCountryCode: any;
    userImage: any;
    uploadForm: FormGroup;
    fileName1: any;
    fileName2: any;
    fileName3: any;
    authObj: any = {'docFile1':'','docFile2':'','docFile3':''};
    front:any='';
    back:any='';
    selfie:any='';
    fileData1: string;
    fileData2: string;
    fileData3: string;
    kyc: any=[];
    obj: { docName: any; docNum: any; attachmentDataFront: any; attachmentDataBack: any; attachmentDataselfie: any; };
    issueForm: FormGroup;
    fileName: any;
    fileSize: any;
    fileData: string;
    google: boolean;
    sms: boolean;
    googleEnabled: string;
    smsEnabled: string;
    myAngularxQrCode:any= null;
    otp = { one: "", two: "", three: "", four: "" ,five: "", six: ""};
    qrCode = {Code1:""} 
    // seconds: number;
    const: any;
    code: string;
    sms11: string;
    kycArr: any[];
    accountNo: any;
    display={front:false,back:false,selfie:false};
    fileSizefront: any;
    fileSizeback: any;
    fileSizeselfie: any;
    reUploadName: any;
    fileSizereUpload: any;
    reUploadData: any;
    counter: any;
    reUploadKyc = {frontName:"",backName:"",selfieName:"",frontData:"",backData:"",selfieData:""};
    fullName: any;
    contact: any;
    country: any;
    dob: any;
    firstDoc={status:"",pdfUrl:"",kycName:"",id:"",rejectReason:""};
    secondDoc={status:"",pdfUrl:"",kycName:"",id:"",rejectReason:""};
    thirdDoc={status:"",pdfUrl:"",kycName:"",id:"",rejectReason:""};
    count = 0;
    profileData: any;
    toggle: any = { 'sms': false, 'google':false}
    secretKey: any;
    seconds: number = 59;
    attachmentDataFront: any;
    attachmentDataBack: any;
    attachmentDataselfie: any;
    kycArrList: any = [];
    categoryname: string;
    constructor(private router:Router, public appC: AppComponent, private server: ServerService,  private spinnerService: Ng4LoadingSpinnerService,public header: HeaderComponent) { }

    ngOnInit() {
        window.scrollTo(0,0);
        this.getprofile();
        this.checkInputs();
        this.checkKycStatus();
        this.issueValidate();
        // this.getAccountDetails();
    }

    activeTab(val)  {
      this.isActive = val;
    }

    editProfile() {
      this.router.navigate(['header/edit']);
    }

    changePassword() {
      this.router.navigate(['header/change']);
    }

    getprofile() {
        this.spinnerService.show();
        this.server.getApi("account/my-account",localStorage.getItem('token')).subscribe((succ) => {
        this.spinnerService.hide();
        this.profileData = succ.body.data;
        // console.log('GEt Profile',this.profileData)
     
        this.name = succ.body.data.firstName;
        this.email = succ.body.data.email;
        this.phoneNo = succ.body.data.phoneNo;
        this.contact =  succ.body.data.phoneNo;
        this.fullName = succ.body.data.firstName + " " + succ.body.data.lastName
        this.phoneCountryCode = succ.body.data.phoneCountryCode;
       
        if(succ.body.data.country) {
            this.country = succ.body.data.country;
        } else {
            this.country = "----";
        }
        if(succ.body.data.dateOfBirth) {
            this.dob = succ.body.data.dateOfBirth;
        } else {
            this.dob = "----";
        }
        if(succ.body.data.imageUrl==null || succ.body.data.imageUrl=='')
            this.userImage = 'assets/images/user.png';

        else
            this.userImage = succ.body.data.imageUrl;
            localStorage.setItem('googleEnabled',succ.body.data.google2faEnabled)
            localStorage.setItem('smsEnabled',succ.body.data.smsEnabled)
        
            if(succ.body.data.twoFaType=='GOOGLE'){
                //console.log
                this.toggle.google=true
                console.log('TWOfa',succ.body.data.twoFaType)
            }
            else if(succ.body.data.twoFaType=='SMS'){
                 this.toggle.sms=true
                 console.log('TWOfa',succ.body.data.twoFaType)
            }
           
        
        }, (err) => {
        this.spinnerService.hide();
        });
        this.header.getprofile();
    }

    checkInputs() {
      this.uploadForm = new FormGroup ({
        docNameFront: new FormControl('', [Validators.required]),
        docNameBack: new FormControl('', [Validators.required]),
        docNameSelfie: new FormControl('', [Validators.required]),
        // docNum: new FormControl('', [Validators.required]),
        attachmentfront: new FormControl('', [Validators.required]),
        attachmentback: new FormControl('', [Validators.required]),
        attachmentselfie: new FormControl('', [Validators.required])
      })
    }

    issueValidate() {
      this.issueForm = new FormGroup({
          issuename: new FormControl('', [Validators.required, Validators.pattern(/^[a-zA-Z]*$/i)]),
          contactEmail: new FormControl('', [Validators.required, Validators.pattern(/^[A-Z0-9_-]+([\.][A-Z0-9_-]+)*@[A-Z0-9-]+(\.[a-zA-Z]{2,5})+$/i)]),
          subject: new FormControl('', [Validators.required, Validators.pattern(/^[a-zA-Z]*$/i)]),
          description: new FormControl('', [Validators.required, Validators.pattern(/^[a-zA-Z0-9]*$/i)]),
          attachment: new FormControl('')
      });
    }

    /** to get the value of field  */
    get docNameSelfie(): any {
        return this.uploadForm.get('docNameSelfie');
    }
    get docNameBack(): any {
        return this.uploadForm.get('docNameBack');
    }
    get docNameFront(): any {
        return this.uploadForm.get('docNameFront');
    }
    // get docNum(): any {
    //   return this.uploadForm.get('docNum');
    // }
    get attachmentNum(): any {
      return this.uploadForm.get('attachmentNum');
    }
    get attachmentback(): any {
      return this.uploadForm.get('attachmentback');
    }
    get attachmentselfie(): any {
      return this.uploadForm.get('attachmentselfie');
    }
    get issuename(): any {
      return this.issueForm.get('issuename');
    }
    get contactEmail(): any {
        return this.issueForm.get('contactEmail');
    }
    get subject(): any {
        return this.issueForm.get('subject');
    }
    get description(): any {
        return this.issueForm.get('description');
    }
    get attachment(): any {
        return this.issueForm.get('attachment');
    }

    /**Function To upload front side of pic */
    handleFileInputFront(event) {
      
        var self = this;
        let formData = new FormData();
        //formData.append('file', this.image);
        if (event.target.files && event.target.files[0]) {
            var type = event.target.files[0].type;
            var size = event.target.files[0].size;
            let count = 0;
            if (size < 2000000) {
                if (type === 'image/png' || type === 'image/jpg') {
                    //self.authObj.docFile1 = event.target.files[0].name;
                    this.fileName1 = event.target.files[0];
                    formData.append('file', this.fileName1);
                    console.log('image', this.fileName1)
                    count++;
                } else if (type === 'application/pdf') {
                    this.fileName1 = event.target.files[0];
                    formData.append('file', this.fileName1);
                 
                    count++;
                } else if (type === 'image/jpeg') {
                    this.fileName1 = event.target.files[0];
                    formData.append('file', this.fileName1);
                  
                    count++;
                } else {
                    this.appC.showErrToast("Select only pdf, jpg, jpeg and png file.");
                    self.authObj.docFile1 = "";
                    self.fileData1 = "";
                    self.front = "assets/images/upload-icon.png";
                }
            } else {
                this.appC.showErrToast("Size should be less than 2 MB.");
                self.authObj.docFile1 = "";
                self.fileData1 = "";
                self.front = "assets/images/upload-icon.png";

            }
            if (count != 0) {
                this.spinnerService.show();
                this.server.postApi('account/upload-file', formData, 1).subscribe(res => {
                    this.spinnerService.hide();
                    if (res.body.status == 200) {
                      
                   
                        this.attachmentDataFront = res.body.data;
                        // console.log('img',this.attachmentDataFront)
                      }
                    else {
                        this.appC.showErrToast('Please select valid file')
                    }

                }, err => {
                    this.spinnerService.hide();
                    this.appC.showErrToast('Please select valid file');
                })
            }
        }
    }

    /**Function To upload back side of pic */
    handleFileInputBack(event) {
       
        var self = this;
        let formData = new FormData();
        if (event.target.files && event.target.files[0]) {
            var type = event.target.files[0].type;
            var size = event.target.files[0].size;
            let count = 0;
            if (size < 2000000) {
                if (type === 'image/png' || type === 'image/jpg') {
                    self.authObj.docFile2 = event.target.files[0].name;
                    this.fileName2 = event.target.files[0];
                    formData.append('file', this.fileName2);
                   
                    count++;
                } else if (type === 'application/pdf') {
                    self.authObj.docFile2 = event.target.files[0].name;
                    this.fileName2 = event.target.files[0];
                    formData.append('file', this.fileName2);
                    count++;
                } else if (type === 'image/jpeg') {
                    self.authObj.docFile2 = event.target.files[0].name;
                    this.fileName2 = event.target.files[0];
                    formData.append('file', this.fileName2);
                    count++;
                } else {
                    this.appC.showErrToast("Select only pdf, jpg, jpeg and png file.");
                    self.authObj.docFile2 = "";
                    self.fileData2 = "";
                    self.back = "assets/images/upload-icon.png";
                }
            } else {
                this.appC.showErrToast("Size should be less than 2MB.");
                self.authObj.docFile2 = "";
                self.fileData2 = "";
                self.back = "assets/images/upload-icon.png";
            }
            if (count != 0) {
                this.spinnerService.show();
                this.server.postApi('account/upload-file', formData, 1).subscribe(res => {
                    this.spinnerService.hide();
                    if (res.status == 200) {
                        this.attachmentDataBack = res.body.data;
                    }
                    else {
                        this.appC.showErrToast('Please select valid file')
                    }
                }, err => {
                    this.spinnerService.hide();
                    this.appC.showErrToast('Please select valid file')
                })
            }
        }
    }

    /**Function To upload selfie  */
    handleFileInputSelfie(event) {
        // var self = this;
        // if (event.target.files && event.target.files[0]) {
        //     var type = event.target.files[0].type;
        //     if (type === 'image/png' || type === 'image/jpeg' || type === 'application/pdf') {
        //         self.fileName3 = event.target.files[0].name;
        //         self.fileSizeselfie = event.target.files[0].size;
        //         if(self.fileSizeselfie > 2000000) {
        //             this.appC.showErrToast("File can be uploaded upto 2mb.");
        //             self.fileData3 = "";
        //             self.fileName3 = "";
        //             this.display.selfie = false;
        //         } else {
        //             var reader = new FileReader()
        //             reader.onload = (e) => {
        //                 self.selfie = e.target['result'];
        //                 if (type === 'image/png' || type === 'image/jpg') {
        //                     self.fileData3 = e.target['result'].substring(22);
        //                 } else if (type === 'image/jpeg') {
        //                     self.fileData3 = e.target['result'].substring(23);
        //                 } else if (type === 'application/pdf') {
        //                     self.fileData3 = e.target['result'].substring(28);
        //                 }
        //             }
        //             reader.readAsDataURL(event.target.files[0]);
        //             this.display.selfie = true;
        //         }
        //     } else {
        //         this.appC.showErrToast("Select only pdf and png,jpeg file.");
        //         self.fileData3 = "";
        //         self.fileName3 = "";
        //         self.back = "";
        //         this.display.selfie = false;
        //     }
        // }
        var self = this;
        let formData = new FormData();
        if (event.target.files && event.target.files[0]) {
            var type = event.target.files[0].type;
            var size = event.target.files[0].size;
            let count = 0;
            if (size < 2000000) {
                if (type === 'image/png' || type === 'image/jpg') {
                    self.authObj.docFile2 = event.target.files[0].name;
                    this.fileName3 = event.target.files[0];
                    formData.append('file', this.fileName3);
                    console.log('image', this.fileName3)
                    count++;
                } else if (type === 'application/pdf') {
                    self.authObj.docFile2 = event.target.files[0].name;
                    this.fileName3 = event.target.files[0];
                    formData.append('file', this.fileName3);
                    count++;
                } else if (type === 'image/jpeg') {
                    self.authObj.docFile2 = event.target.files[0].name;
                    this.fileName3 = event.target.files[0];
                    formData.append('file', this.fileName3);
                    count++;
                } else {
                    this.appC.showErrToast("Select only pdf, jpg, jpeg and png file.");
                    self.authObj.docFile2 = "";
                    self.fileData2 = "";
                    self.back = "assets/images/upload-icon.png";
                }
            } else {
                this.appC.showErrToast("Size should be less than 2MB.");
                self.authObj.docFile2 = "";
                self.fileData2 = "";
                self.back = "assets/images/upload-icon.png";
            }
            if (count != 0) {
                this.spinnerService.show();
                this.server.postApi('account/upload-file', formData, 1).subscribe(res => {
                    this.spinnerService.hide();
                    if (res.status == 200) {
                        this.attachmentDataselfie= res.body.data;
                    }
                    else {
                        this.appC.showErrToast('Please select valid file')
                    }
                }, err => {
                    this.spinnerService.hide();
                    this.appC.showErrToast('Please select valid file')
                })
            }
        }

    }

    handleFileInputReupload(event,count,kyc) {
        console.log('Reimg==>',event,count,kyc)
        this.counter = count;
        var self = this;
        let formData = new FormData();
        if (event.target.files && event.target.files[0]) {
            var type = event.target.files[0].type;
            var size = event.target.files[0].size;
            if (type === 'image/png' || type === 'image/jpeg' || type === 'application/pdf') {
                if(kyc == "Front") {
                    self.reUploadKyc.frontName = event.target.files[0].name;
                } else if(kyc == "Back") {
                    self.reUploadKyc.backName = event.target.files[0].name;
                } else {
                    self.reUploadKyc.selfieName = event.target.files[0].name;
                }
                // self.fileSizereUpload = event.target.files[0].size;
                // if(self.fileSizereUpload > 2000000) {
                //     this.appC.showErrToast("File can be uploaded upto 2mb.");
                //     self.reUploadData = "";
                //     if(kyc == "Front") {
                //         self.reUploadKyc.frontName = "";
                //     } else if(kyc == "Back") {
                //         self.reUploadKyc.backName = "";
                //     } else {
                //         self.reUploadKyc.selfieName = "";
                //     }
                // } else {
                //     var reader = new FileReader()
                //     reader.onload = (e) => {
                //         self.selfie = e.target['result'];
                //         if (type === 'image/png' || type === 'image/jpg') {
                //             if(kyc == "Front") {
                //                 self.reUploadKyc.frontData = e.target['result'].substring(22);
                //                 // formData.append('file',  self.reUploadKyc.frontData);
                //             } else if(kyc == "Back") {
                //                 self.reUploadKyc.backData = e.target['result'].substring(22);
                //             } else {
                //                 self.reUploadKyc.selfieData = e.target['result'].substring(22);
                //             }
                //         } else if (type === 'image/jpeg') {
                //             if(kyc == "Front") {
                //                 self.reUploadKyc.frontData = e.target['result'].substring(23);
                //             } else if(kyc == "Back") {
                //                 self.reUploadKyc.backData = e.target['result'].substring(23);
                //             } else {
                //                 self.reUploadKyc.selfieData = e.target['result'].substring(23);
                //             }
                //         } else if (type === 'application/pdf') {
                //             if(kyc == "Front") {
                //                 self.reUploadKyc.frontData = e.target['result'].substring(28);
                //             } else if(kyc == "Back") {
                //                 self.reUploadKyc.backData = e.target['result'].substring(28);
                //             } else {
                //                 self.reUploadKyc.selfieData = e.target['result'].substring(28);
                //             }
                //         }
                //     }
                  //  reader.readAsDataURL(event.target.files[0]);
               // }
                if (size < 2000000) {
                if (type === 'image/png' || type === 'image/jpg') {
                    //self.authObj.docFile1 = event.target.files[0].name;
                    this.fileName1 = event.target.files[0];
                    formData.append('file', this.fileName1);
                    count++;
                } else if (type === 'application/pdf') {
                    this.fileName1 = event.target.files[0];
                    formData.append('file', this.fileName1);
                    count++;
                } else if (type === 'image/jpeg') {
                    this.fileName1 = event.target.files[0];
                    formData.append('file', this.fileName1);
                    count++;
                } else {
                    this.appC.showErrToast("Select only pdf, jpg, jpeg and png file.");
                    self.authObj.docFile1 = "";
                    self.fileData1 = "";
                    self.front = "assets/images/upload-icon.png";
                }
            } else {
                this.appC.showErrToast("Size should be less than 2 MB.");
                self.authObj.docFile1 = "";
                self.fileData1 = "";
                self.front = "assets/images/upload-icon.png";

            }
                if (count != 0) {
                  
                    this.spinnerService.show();
                    this.server.postApi('account/upload-file', formData, 1).subscribe(res => {
                        this.spinnerService.hide();
                        if (res.body.status == 200) {
                    if(kyc == "Front") {
                      
                    self.reUploadKyc.frontData =res.body.data;
                    console.log('img',self.reUploadKyc.frontData)
                   } else if(kyc == "Back") {
                  
                     self.reUploadKyc.backData =res.body.data;
                     console.log('img', self.reUploadKyc.backData)
                    } else {
                       
                      self.reUploadKyc.selfieData =res.body.data;
                      console.log('img',self.reUploadKyc.selfieData)
                    }
                            // this.obj.attachmentDataFront = res.body.data;
                        }
                        else {
                            this.appC.showErrToast('Please select valid file')
                        }
    
                    }, err => {
                        this.spinnerService.hide();
                        this.appC.showErrToast('Please select valid file');
                    })
                }
            } else {
                this.appC.showErrToast("Select only pdf and png,jpeg file.");
                if(kyc == "Front") {
                    self.reUploadKyc.frontName = "";
                    self.reUploadKyc.frontData = "";
                } else if(kyc == "Back") {
                    self.reUploadKyc.backName = "";
                    self.reUploadKyc.backData = "";
                } else {
                    self.reUploadKyc.selfieName = "";
                    self.reUploadKyc.selfieData = "";
                }
            }
        }
    }

    /** To check Kyc status */
    checkKycStatus() {
        this.kycArrList = [];
        this.kyc = [];
        this.spinnerService.show();
        this.server.getApi('account/get-kyc-details',localStorage.getItem('token')).subscribe(response => {
            this.spinnerService.hide();
            if (response.body.status == 200) {
               
                this.kyc = response.body.data;   
                console.log('KCY', this.kyc.document)
                if(this.kyc.document ==null){
                    this.kyc = false;
                    this.front = "assets/images/upload-icon.png";
                    this.back = "assets/images/upload-icon.png";
                    this.selfie = "assets/images/upload-icon.png";
                } else {
                    this.kyc = true;
                    console.log('KCY',response.body.data)
                    this.kycArrList=this.kyc.document
                    response.body.data.document.forEach(element => {
                        if(element.category=='photo' && element.frontIdUrl!='') {
                            this.selfie = "assets/images/pdf.png";
                            this.thirdDoc.kycName = element.docName;
                            this.thirdDoc.pdfUrl = element.frontIdUrl;
                            this.thirdDoc.status = element.documentStatus;
                            this.thirdDoc.id = element.documentId;
                            this.thirdDoc.rejectReason = element.reason;
                            if(this.thirdDoc.status == "VERIFIED") {
                                this.count = this.count + 1;
                            }
                        } else if(element.category=='photo' && element.frontIdUrl!=''){
                            this.selfie = element.frontIdUrl;
                            this.thirdDoc.kycName = element.docName;
                            this.thirdDoc.status = element.documentStatus;
                            this.thirdDoc.id =element.documentId;
                            this.thirdDoc.rejectReason = element.reason;
                            if(this.thirdDoc.status == "VERIFIED") {
                                this.count = this.count + 1;
                            }
                        }
                        if(element.category=='bill' && element.frontIdUrl!='') {
                            this.back = "assets/images/pdf.png";
                            this.secondDoc.kycName = element.docName;
                            this.secondDoc.pdfUrl = element.frontIdUrl;
                            this.secondDoc.status = element.documentStatus;
                            this.secondDoc.id = element.documentId;
                            this.secondDoc.rejectReason = element.reason;
                            if(this.secondDoc.status == "VERIFIED") {
                                this.count = this.count + 1;
                            }
                        } else if (element.category=='bill' && element.frontIdUrl!=''){
                            this.back = element.url;
                            this.secondDoc.kycName = element.docName;
                            this.secondDoc.status = element.documentStatus;
                            this.secondDoc.id = element.documentId;
                            this.secondDoc.rejectReason = element.reason;
                            if(this.secondDoc.status == "VERIFIED") {
                                this.count = this.count + 1;
                            }
                        }
                        if(element.category=='ID' && element.frontIdUrl!='') {
                            this.front = "assets/images/pdf.png";
                            this.firstDoc.kycName = element.docName;
                            this.firstDoc.pdfUrl = element.frontIdUrl;
                            this.firstDoc.status = element.documentStatus;
                            this.firstDoc.id = element.documentId;
                            this.firstDoc.rejectReason = element.reason;
                            if(this.firstDoc.status == "VERIFIED") {
                                this.count = this.count + 1;
                            }
                        } else if (element.category=='ID' && element.frontIdUrl!=''){
                            this.front = element.url;
                            this.firstDoc.kycName = element.docName;
                            this.firstDoc.status = element.documentStatus;
                            this.firstDoc.id = element.documentId;
                            this.firstDoc.rejectReason = element.reason;
                            if(this.firstDoc.status == "VERIFIED") {
                                this.count = this.count + 1;
                            }
                        }
                     });
                 }
            } else if(response.transferObjectMap.statusCode == 403) {
                this.appC.showErrToast(response.transferObjectMap.message);
                this.header.tokenExpire();
            } else {
            this.appC.showErrToast(response.transferObjectMap.message);
            }
        }, error => {
            this.appC.showErrToast('Something went wrong');
            this.spinnerService.hide();
        });
    }

    /** Function to submit KYC documents  */
    submitDoc() {
        alert('click')
        this.kycArr = [];
        if(this.fileData1 != '') {
            this.kycArr.push({
                name: this.uploadForm.get('docNameFront').value,
                "attachment": this.fileData1,
                "category":'ID',
                "level":"2"
            })

        }
        if(this.fileData2 != '') {
            this.kycArr.push({
                "name": this.uploadForm.get('docNameBack').value,
                "attachment": this.fileData2,
                "category":'bill',
                "level":"2"
            })

        }
        if(this.fileData3 != '') {
            this.kycArr.push({
                name: this.uploadForm.get('docNameSelfie').value,
                attachment: this.fileData3,
                "category":'photo',
                "level":"2"
            })
        }
       
        /**KYC API */
        let data = {
            "document": [
                {
                "docName": this.uploadForm.get('docNameFront').value,
                "frontIdUrl": this.attachmentDataFront,
                "category":'ID',
                "level":"2"
            },
            {
                "docName": this.uploadForm.get('docNameBack').value,
                "frontIdUrl": this.attachmentDataBack,
                "category":'bill',
                "level":"2"
            },
            {
                "docName": this.uploadForm.get('docNameSelfie').value,
                "frontIdUrl": this.attachmentDataselfie,
                "category":'photo',
                "level":"2"
            },
             ]
                              
                }

         
        this.spinnerService.show();
        this.server.postApi('account/save-kyc-details', data, localStorage.getItem('token')).subscribe(response => {
            this.spinnerService.hide();
            if (response.body.status == 200) {
                this.appC.showSuccToast(response.body.message)
                
                this.checkKycStatus();
                this.isActive = 'kyc';
            } else if(response.body.status == 403){
                this.appC.showErrToast('Session Expired'); 
                this.header.tokenExpire()
            }  else {
             
                this.appC.showErrToast(response.body.message);
            }
        }, error => {
            this.spinnerService.hide();
            this.appC.showErrToast('Something went wrong');
        });
    }

    handleFileInput(event) {
           
        var self = this;
        let fileData = new FormData();
        //formData.append('file', this.image);
        if (event.target.files && event.target.files[0]) {
            var type = event.target.files[0].type;
            var size = event.target.files[0].size;
            let count = 0;
            if (size < 2000000) {
                if (type === 'image/png' || type === 'image/jpg') {
                    //self.authObj.docFile1 = event.target.files[0].name;
                    this.fileName1 = event.target.files[0];
                    fileData.append('file', this.fileName1);
                    count++;
                } else if (type === 'application/pdf') {
                    this.fileName1 = event.target.files[0];
                    fileData.append('file', this.fileName1);
                    count++;
                } else if (type === 'image/jpeg') {
                    this.fileName1 = event.target.files[0];
                    fileData.append('file', this.fileName1);
                    count++;
                } else {
                    this.appC.showErrToast("Select only pdf, jpg, jpeg and png file.");
                    self.authObj.docFile1 = "";
                    self.fileData1 = "";
                    self.front = "assets/images/upload-icon.png";
                }
            } else {
                this.appC.showErrToast("Size should be less than 2 MB.");
                self.authObj.docFile1 = "";
                self.fileData1 = "";
                self.front = "assets/images/upload-icon.png";

            }
            if (count != 0) {
                this.spinnerService.show();
                this.server.postApi('account/upload-file', fileData, 1).subscribe(res => {
                    this.spinnerService.hide();
                    if (res.body.status == 200) {
                        this.fileData = res.body.data;
                    }
                    else {
                        this.appC.showErrToast('Please select valid file')
                    }

                }, err => {
                    this.spinnerService.hide();
                    this.appC.showErrToast('Please select valid file');
                })
            }
        }
    //   var self = this;
    //   self.fileData = "";
    //   self.fileName = "";
    //   let count = 0;
    //   if(event.target.files && event.target.files[0]){
    //       var type = event.target.files[0].type;
    //       if(type === 'image/png' || type === 'image/jpg') {
    //           self.authObj.docFile = event.target.files[0].name;
    //           this.fileName = self.authObj.docFile;
    //           var reader = new FileReader()
    //           reader.onload = (e) =>  {
    //               self.fileData = e.target['result'].substring(22);
    //               //console.log("fileURL -> "+self.fileData);
    //           }
    //           reader.readAsDataURL(event.target.files[0]);
    //           count++;
    //       } else if(type === 'application/pdf') {
    //           self.authObj.docFile = event.target.files[0].name;
    //           this.fileName = self.authObj.docFile;
    //           var reader = new FileReader()
    //           reader.onload = (e) =>  {
    //               self.fileData = e.target['result'].substring(28);
                  
    //           }
    //           reader.readAsDataURL(event.target.files[0]);
    //           count++;
    //       } else if(type === 'image/jpeg') {
    //           self.authObj.docFile = event.target.files[0].name;
    //           this.fileName = self.authObj.docFile;
    //           var reader = new FileReader()
    //           reader.onload = (e) =>  {
    //               self.fileData = e.target['result'].substring(23);
                  
    //           }
    //           reader.readAsDataURL(event.target.files[0]);
    //           count++;
    //       } else {
    //           this.appC.showErrToast("Select only pdf, jpg, jpeg and png file.");
    //           self.authObj.docFile = "";
    //           self.fileData = "";
    //       }

         
     // }

    }

    submitIssue( )  {
        let data = {
           
                    // "token": localStorage.getItem("token"),
                    "fromEmail":this.issueForm.value.contactEmail,
                    "subject":this.issueForm.value.subject,
                    "questionType":this.issueForm.value.issuename,
                    "description":this.issueForm.value.description,
                    "screenShot":this.fileData
                }
          
        this.spinnerService.show();
        this.server.postApi('static/contact-us', data, localStorage.getItem("token")).subscribe(response => {
          this.spinnerService.hide();
          if (response.body.status == 200) {
              this.appC.showSuccToast(response.body.message);   
              this.clearIssueForm(); 
          } else if(response.status == 403) {
              this.appC.showErrToast(response.body.message);
              this.header.tokenExpire();
  
          } else {
            this.appC.showErrToast(response.body.message);
          }
        }, error => {
          this.appC.showErrToast('Something went wrong');
          this.spinnerService.hide();
        }) ;

    }

    clearIssueForm()  {
      this.issueForm.reset();
      this.fileData='';
      this.fileName='';
    }

    errorToast(val)  {
        console.log('change value',val)
      if(val == 'google')
        this.appC.showErrToast("Google Auth already enabled.")
      else if(val == 'sms')
        this.appC.showErrToast("SMS Auth already enabled.")

    }

   
    myTimer() {
        Observable.interval(1000)
        .takeWhile(() => this.seconds > 0 || (this.seconds != 60 && this.seconds > 0))
        .subscribe(i => { 
            --this.seconds;
        })
        if(this.seconds==0) {
            clearInterval(this.seconds);
        }
    }
    

    
    changeToggle(val) {
      
        if (val == 1) {
           
           
            if(this.profileData.twoFaType !='SMS'){
                // this.otpVerification('google');
                console.log('value',this.profileData.twoFaType,val,this.toggle.google,this.toggle.sms)
                this.qrCode.Code1=''
                $('#googleAuth').modal({backdrop:'static',keyboard:false})
                // this.qrVerify()
            }else{
               console.log("google toggle", this.toggle.google)
                if (!this.toggle.google){
                    this.request_google();
                console.log('value',this.profileData.twoFaType,val,this.toggle.google,this.toggle.sms)
                   
                 } else {
                    this.appC.showErrToast('Google auth alreadyyy enabled');
                    // this.mytoggle(val);
                }
               
            }            
        } else {

  this.otp = { one: "", two: "", three: "", four: "" ,five: "", six: ""};
            if(this.profileData.twoFaType != 'GOOGLE'){
                $('#otpmodal').modal({backdrop: 'static',keyboard: false  // to prevent closing with Esc button (if you want this too)
                
            })
            this.seconds = 59;
            this.myTimer();
                this.sendSms();
            }else{
           
            if (!this.toggle.sms) {
                   
                this.otpVerification('sms');      
              
            }            
            else {
                this.appC.showErrToast('sms auth alreadyy enabled');
                // this.mytoggle(val);
            }
        }
        }
    }
    /**to show the activated authentication */
    mytoggle(val) {
        this.count = 1;
        this.const = setTimeout(() => {
            if (this.count < 2) {
                this.toggle.google = true;
            } else {
                this.toggle.sms = true;
                this.count++;
            }
        }, 1000);
    }
    // onSubmit(){

    //    console.log('>>>>>>>>>>>>>>>>>>>>>>>>>>>',this.otpVerification)
    // }
    /**to send otp for verification */
    otpVerification(val) {
        if(val == 'google')
        {
        this.spinnerService.show();
        this.server.getApi('auth/send-sms-code',localStorage.getItem('token')).subscribe(response => {
           console.log("send-sms-code response", response.body)
            this.spinnerService.hide();
            if (response.body.status == 200) {
                this.appC.showSuccToast("OTP sent successfully.");
                this.otp = { one: "", two: "", three: "", four: "", five:"", six:"" };
                // $('#otpmodal').modal.modal({
                //     backdrop: 'static',
                //     keyboard: false  // to prevent closing with Esc button (if you want this too)
                // })
                $('#otpmodal').modal({backdrop: 'static',keyboard: false  // to prevent closing with Esc button (if you want this too)
                           })
                 this.seconds = 59;
                this.myTimer();
               
            } else if (response.body.status == 403) {
                this.appC.showErrToast(response.body.message);
                // this.header.tokenExpired()
            } else {
                this.appC.showErrToast(response.body.message);
                this.googleEnabled = localStorage.getItem('googleEnabled');
                this.smsEnabled = localStorage.getItem('smsEnabled');
                if (this.googleEnabled == '1' || this.googleEnabled == 'true') {
                    this.toggle.google = true;
                    this.toggle.sms = false;
                    console
                } else {
                    this.toggle.google = false;
                    this.toggle.sms = true;
                }
            }
        }, error => {
          //  console.log('send-sms-code', error)
            this.spinnerService.hide();
            this.appC.showErrToast('Something went wrong');
            // this.googleEnabled = localStorage.getItem('googleEnabled');
            // this.smsEnabled = localStorage.getItem('smsEnabled');
            // if (this.googleEnabled == '1' || this.googleEnabled == 'true') {
            //     this.toggle.google = true;
            //     this.toggle.sms = false;
            // } else {
            //     this.toggle.google = false;
            //     this.toggle.sms = true;
            // }
        });
    }else {
       $('#googleAuth').modal.modal('show');
       // debugger;
    }
    }
    /**to verify the qr code */
    qrVerify() {
        var data = {}
        if(this.profileData.twoFaType != 'GOOGLE'){
           data = {
                "code": this.qrCode.Code1,
                "secretKey": this.secretKey
              }
              var url = 'account/verify-google-code'
        }else {
            data = {
                "otp": this.qrCode.Code1,
              }
              var url = 'auth/verify-google'
        }      
        this.spinnerService.show();
      //  debugger;
        this.server.postApi(url, data,localStorage.getItem('token')).subscribe(response => {
            this.spinnerService.hide();
            console.log('Google',response.body)
            if (response.body.status == 200) {
               $('#googleAuth').modal('hide')
                //this.appC.showSuccToast("Qr Code verified successfully");
                // if (this.google11 == 'google') {
                    this.toggle.sms = false;
                    this.toggle.google = true;
                    this.getprofile();
                    if(url == 'auth/verify-google'){
                       
                   this.req_user(this.qrCode.Code1,'sms');
                }
                    this.appC.showSuccToast(response.body.message);
                //   debugger;
                // } 
                // else
                    // this.otpVerification();
            } else {
                this.appC.showInfoToast(response.body['message']);
            } 
            // } else if (response == 403) {
            //     this.appC.showErrToast(response.transferObjectMap.message);
            //     this.header.tokenExpired()
            // } else {
            //     this.appC.showErrToast("Qr Code not verified");
            //     this.qrCode = { Code1: "" }
            //     this.googleEnabled = localStorage.getItem('googleEnabled');
            //     this.smsEnabled = localStorage.getItem('smsEnabled');
            //     if (this.googleEnabled == '1' || this.googleEnabled == 'true') {
            //         this.toggle.google = true;
            //         this.toggle.sms = false;
            //     }
            //     else {
            //         this.toggle.google = false;
            //         this.toggle.sms = true;
            //     }
            // }
        }, error => {
            this.spinnerService.hide();
            this.appC.showErrToast('Something went wrong');
            this.googleEnabled = localStorage.getItem('googleEnabled');
            this.smsEnabled = localStorage.getItem('smsEnabled');
            if (this.googleEnabled == '1' || this.googleEnabled == 'true') {
                this.toggle.google = true;
                this.toggle.sms = false;
            }
            else {
                this.toggle.google = false;
                this.toggle.sms = true;
            }
        });
    }
    /**request user setting */
    req_user(code,auth) {
        
        let data = {
           "code":code
        }
        this.spinnerService.show();
        this.server.postApi('account/twoFa-disable', data,localStorage.getItem('token')).subscribe((succ) => {
         //   console.log('res===>>.',succ);
            // debugger;
            this.spinnerService.hide();
            if (succ.body.status == 200) {
                this.qrCode.Code1
                this.otp = { one: "", two: "", three: "", four: "", five:"", six:"" };
                if(auth == 'sms')
                { 
               
                this.sendSms();
               $('#otpmodal').modal('show');
               $('#googleAuth').modal('hide');
               
            //    this.getprofile()
                localStorage.setItem('googleEnabled', succ.google2faEnabled);
                localStorage.setItem('smsEnabled', succ.smsEnabled)
                this.appC.showSuccToast(succ.message);
                
                // debugger;
               }else{
              
                $('#otpmodal').modal('hide');
               $('#googleAuth').modal('show');
                // localStorage.setItem('googleEnabled', succ.transferObjectMap.gatewayrequest.google2faEnabled);
                // localStorage.setItem('smsEnabled', succ.transferObjectMap.gatewayrequest.smsEnabled)
                this.appC.showSuccToast(succ.message);
                this.request_google();
               //this.qrVerify();
                // debugger;
               }
            }
            // } else if (succ.transferObjectMap.statusCode == 403) {
            //     this.appC.showErrToast(succ.transferObjectMap.message);
            //     this.header.tokenExpired()
            // } 
            else {
                this.appC.showErrToast(succ['message']);
            }
        }, (err) => {
            this.spinnerService.hide();
        });
    }
    //Send SMS Code
    sendSms(){
        this.server.getApi('account/send-sms-code',localStorage.getItem('token')).subscribe(res=>{
         //   console.log('SMS res--->>>',res);
            this.appC.showSuccToast(res.body['message']);
            
            // this.getprofile()
        }, err=>{
        //    console.log('SMS err--->>>',err);
        })
    }
    // Function to verify otp
    smsVerify() {
        var data = {}
        if(this.profileData.twoFaType != 'SMS'){
            this.code = this.otp.one + this.otp.two + this.otp.three + this.otp.four+ this.otp.five + this.otp.six;
           data = {
                "code": this.code,               
              }
              var url = 'account/verify-sms-code'
        }else {
            this.code = this.otp.one + this.otp.two + this.otp.three + this.otp.four+ this.otp.five + this.otp.six;
            data = {
                "code": this.code,
              }
              var url = 'auth/verify-sms'
        }            
        this.spinnerService.show();
        this.server.postApi(url,data,localStorage.getItem('token')).subscribe(response => {
            this.spinnerService.hide();
            if (response.body.status == 200) {
                // if (this.sms11 == "sms") {
                    this.toggle.google = false;
                    this.toggle.sms = true;
                    this.getprofile();
                    if(url == 'auth/verify-sms'){
                       
                    this.req_user(this.code,'google');
                   }
                  //  debugger;
                // }
                // else {
                    $('#otpmodal').modal('hide');
                   //this.qrVerify();
                    // this.request_google();
                // }
            } else if (response.body.status == 403) {
                this.appC.showErrToast(response.message);
                // this.header.tokenExpired()
            } else {
                this.appC.showErrToast(response.body.message);
                this.otp = { one: "", two: "", three: "", four: "",five:'' ,six:'' };
                this.googleEnabled = localStorage.getItem('googleEnabled');
                this.smsEnabled = localStorage.getItem('smsEnabled');
                if (this.googleEnabled == '1' || this.googleEnabled == 'true') {
                    this.toggle.google = true;
                    this.toggle.sms = false;
                } else {
                    this.toggle.google = false;
                    this.toggle.sms = true;
                }
            }
        }, error => {
            this.spinnerService.hide();
            this.appC.showErrToast('Something went wrong');
            this.googleEnabled = localStorage.getItem('googleEnabled');
            this.smsEnabled = localStorage.getItem('smsEnabled');
            if (this.googleEnabled == '1' || this.googleEnabled == 'true') {
                this.toggle.google = true;
                this.toggle.sms = false;
            } else {
                this.toggle.google = false;
                this.toggle.sms = true;
            }
        });
    }
/*----------------------------------------- */
//     toggle1 = true;
// status = 'Enable'; 
// enableDisableRule(job) {
//     this.toggle = !this.toggle;
//     this.status = this.toggle ? 'Enable' : 'Disable';
// }
/*----------------------------------------- */
    /**requesting google authentication  */
    request_google() {
        this.qrCode.Code1=''
        this.spinnerService.show();
        this.server.getApi('account/google-auth',localStorage.getItem('token')).subscribe(response => {
            this.spinnerService.hide();
            if (response.body.status == 200) {
                // this.qrCode = { Code1: "" }
                $('#googleAuth').modal({ backdrop: 'static', keyboard: false })
                this.secretKey = response.body.data.secretKey;
                this.myAngularxQrCode = response.body.data.qrCode;
             
                //localStorage.setItem('key', response.data.secretKey);
               // this.code =  this.qrCode.Code1
               // this.key = response.data.secretKey;
                console.log('>>>>>>>>>>>>>.LI',response.body.data.secretKey)
                
                
               // this.myAngularxQrCode = response.data.qrCode;
               // console.log('>>>>>>>>AB',this.myAngularxQrCode);
            } else if (response.body.status == 403) {
                this.appC.showErrToast(response.body.message);
                // this.header.tokenExpired()
            } else {
                this.appC.showErrToast(response.body.message);
                this.googleEnabled = localStorage.getItem('googleEnabled');
                this.smsEnabled = localStorage.getItem('smsEnabled');
                if (this.googleEnabled == '1' || this.googleEnabled == 'true') {
                    this.toggle.google = true;
                    this.toggle.sms = false;
                } else {
                    this.toggle.google = false;
                    this.toggle.sms = true;
                }
            }
        }, error => {
            this.spinnerService.hide();
            this.appC.showErrToast('Something went wrong');
            this.googleEnabled = localStorage.getItem('googleEnabled');
            this.smsEnabled = localStorage.getItem('smsEnabled');
            if (this.googleEnabled == '1' || this.googleEnabled == 'true') {
                this.toggle.google = true;
                this.toggle.sms = false;
            }
            else {
                this.toggle.google = false;
                this.toggle.sms = true;
            }
        });
    }
    /** Toggle management on closing modal by clicking on close button */
    closeModal() {
        $('#otpmodal').modal.modal('hide');
       $('#googleAuth').modal.modal('hide');
        this.qrCode.Code1 = '';
        this.googleEnabled = localStorage.getItem('googleEnabled');
        this.smsEnabled = localStorage.getItem('smsEnabled');
        if (this.googleEnabled == '1' || this.googleEnabled == 'true') {
            this.toggle.google = true;
            this.toggle.sms = false;
        }
        else {
            this.toggle.google = false;
            this.toggle.sms = true;
        }
    }
    /**Function to request OTP */
    otpSend() { 
        let data = {
            "eventExternal": {
                "name": "request_sms_auth",
                "key": "mykey"
            },
            "transferObjectMap": {
                "gatewayrequest": {
                    "phoneCountryCode": this.phoneCountryCode,
                    "phone": this.phoneNo,
                    "token": localStorage.getItem('token')
                }
            }
        }
        this.spinnerService.show();
        this.server.post('', data).subscribe(response => {
            this.spinnerService.hide();
            if (response.transferObjectMap.statusCode == 200) {
                this.seconds = 59;
                this.myTimer();
            } else if (response.transferObjectMap.statusCode == 403) {
                this.appC.showErrToast(response.transferObjectMap.message);
                // this.header.tokenExpired()
            } else {
                this.appC.showErrToast(response.transferObjectMap.message);
                this.googleEnabled = localStorage.getItem('googleEnabled');
                this.smsEnabled = localStorage.getItem('smsEnabled');
                if (this.googleEnabled == '1' || this.googleEnabled == 'true') {
                    this.toggle.google = true;
                    this.toggle.sms = false;
                } else {
                    this.toggle.google = false;
                    this.toggle.sms = true;
                }
            }
        }, error => {
            this.spinnerService.hide();
            this.appC.showErrToast('Something went wrong');
            this.googleEnabled = localStorage.getItem('googleEnabled');
            this.smsEnabled = localStorage.getItem('smsEnabled');
            if (this.googleEnabled == '1' || this.googleEnabled == 'true') {
                this.toggle.google = true;
                this.toggle.sms = false;
            } else {
                this.toggle.google = false;
                this.toggle.sms = true;
            }
        });
    }
    /** Auto focus functionality */
    onKey(value, type) {
        if (type == 1) {
            if (value != "") {
                $('#otp2').focus();
            }
        } else if (type == 2) {
            if (value != "") {
                $('#otp3').focus();
            }
        } else if (type == 3) {
            if (value != "") {
                $('#otp4').focus();
            }
        } else if (type == 4) {
            if (value != "") {
                $('#otp5').focus();
            }
        }
        else if (type == 5) {
            if (value != "") {
                $('#otp6').focus();
            }
        }
        
    }
    /**Function for timer functionality */
    // myTimer() {
    //     this.const = setTimeout(() => {
    //         if (this.seconds > 0) {
    //             this.hiddenTimer = false;
    //             this.seconds = this.seconds - 1;
    //             if (this.seconds < 10) {
    //                 this.hiddenTimer = true;
    //             }
    //             this.myTimer();
    //         } else {
    //             clearInterval(this.const);
    //         }
    //     }, 1000);
    // }
    /** Function to get account details of admin */
    getAccountDetails() {
        let data = {
            "eventExternal" : {
                "name" : "get_admin_account_detail",
                "key" : "mykey"
            },
            "transferObjectMap" : {
                "gatewayrequest": {
                    "loginToken": localStorage.getItem("token"),
                    "paymentType": "LCX"
                }
            }
        }
        this.server.post('',data).subscribe((succ) => {
            if(succ.transferObjectMap.statusCode == 200) {
                if(succ.transferObjectMap.result.length) {
                    this.accountNo = succ.transferObjectMap.uniqueReferrenceNumber;
                }
            }
        }, (err) => {
        });
    }
    
    reUpload(val,documnetname,kyc) {
       
        if(kyc == "Front") {
            this.reUploadData = this.reUploadKyc.frontData;
         this.categoryname='ID';
         
        } else if(kyc == "Back") {
            this.reUploadData = this.reUploadKyc.backData;
             this.categoryname='bill';
           
        } else {
            this.reUploadData = this.reUploadKyc.selfieData;
            this.categoryname='photo';
           
        }
        let data = {
            "document": [
                {
                "docName":documnetname,
                "frontIdUrl": this.reUploadData,
                "documentId":val,
                "category": this.categoryname,
                "level": "2"
            },
        ]  
                    // "kycId": val,
                    // "proofAttachment": this.reUploadData,
                  
        }
        console.log('data-=>',data,this.reUploadKyc.selfieData)
        this.spinnerService.show();
        this.server.postApi('account/save-kyc-details', data, localStorage.getItem('token')).subscribe(response => {
            if (response.body.status == 200) {
                this.appC.showSuccToast(response.body.message)
                this.spinnerService.hide();
                this.checkKycStatus();
                // this.isActive = 'userDetails';
            } else if(response.body.statusCode == 403){
                this.spinnerService.hide();
                this.appC.showErrToast('Session Expired'); 
                this.header.tokenExpire()
            }  else {
                this.spinnerService.hide();
                this.appC.showErrToast(response.body.message);
            }
        }, error => {
            this.spinnerService.hide();
            this.appC.showErrToast('Something went wrong');
        });
    }
    
 
    resendOtp() {
      
      
        this.spinnerService.show();
        this.server.getApi('auth/send-sms-code',localStorage.getItem('token')).subscribe(response => {
            this.spinnerService.hide();
            if (response.body.status == 200) {
                
                
               this.otp = { one: "", two: "", three: "", four: "" ,five: "", six: ""};
               this.seconds = 59;
               this.myTimer();
            } else {
                this.otp = { one: "", two: "", three: "", four: "" ,five: "", six: ""};
       
                this.appC.showErrToast(response.body.message);                
            }
        }, error => {
            this.spinnerService.hide();
            this.appC.showErrToast('Something went wrong');
        });
    }
}
